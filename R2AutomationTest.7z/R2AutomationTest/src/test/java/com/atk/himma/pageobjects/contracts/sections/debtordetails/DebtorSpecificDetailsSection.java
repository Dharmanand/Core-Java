package com.atk.himma.pageobjects.contracts.sections.debtordetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class DebtorSpecificDetailsSection extends DriverWaitClass {
	public static final String DEBTORSPECDETAILSSEC_LINKTEXT = "Debtor Specific Details";
	private final static String ACNTNUM_NAME = "debtor.specificDetails.accountNum";
	private final static String COSTCENTER_NAME = "debtor.specificDetails.costCenter";
	private final static String CURRENCY_NAME = "debtor.specificDetails.currency";
	private final static String PERFORMANCEGRADE_NAME = "debtor.specificDetails.performanceGrade";

	@FindBy(linkText = DEBTORSPECDETAILSSEC_LINKTEXT)
	private WebElement dbtrSpecDetailsSec;

	@FindBy(name = ACNTNUM_NAME)
	private WebElement acntNum;

	@FindBy(name = COSTCENTER_NAME)
	private WebElement costCenter;

	@FindBy(name = CURRENCY_NAME)
	private WebElement currency;

	@FindBy(name = PERFORMANCEGRADE_NAME)
	private WebElement performanceGrade;

	public boolean isMandCurrency() {
		waitForElementName(CURRENCY_NAME);
		return isMandatoryField(currency);
	}

	public void fillDebtorSpecificDetailsData(String[] debtorListData) {
		acntNum.clear();
		acntNum.sendKeys(debtorListData[21]);

		costCenter.clear();
		costCenter.sendKeys(debtorListData[22]);

		if (!debtorListData[23].isEmpty()) {
			new Select(currency).selectByVisibleText(debtorListData[23]);
		}
		if (!debtorListData[24].isEmpty()) {
			new Select(performanceGrade)
					.selectByVisibleText(debtorListData[24]);
		}

	}

	public String getSelectedCurrency() {
		return new Select(currency).getFirstSelectedOption().getText();
	}

	public WebElement getDbtrSpecDetailsSec() {
		return dbtrSpecDetailsSec;
	}

	public WebElement getAcntNum() {
		return acntNum;
	}

	public WebElement getCostCenter() {
		return costCenter;
	}

	public WebElement getCurrency() {
		return currency;
	}

	public WebElement getPerformanceGrade() {
		return performanceGrade;
	}

}
