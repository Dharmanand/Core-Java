package com.atk.himma.pageobjects.contracts.sections.classdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;

public class ClassGeneralParametersSection extends DriverWaitClass {
	public static final String CLSGENPARAMSEC_LINKTEXT = "Class General Parameters";
	public final static String CLSVISITCOVCHKBOX_ID = "CLASS_VISIT_COVERAGE";
	public final static String ADDVISITCOVRECORDPLUSBTN_XPATH = "//span[@class='ui-icon ui-icon-plus']";
	public final static String ADDVISITCOVPOPUPFORM_ID = "CLASS_VISIT_COVERAGE_ADD_NEW_POPUP";
	public final static String VISITCOVPOPUPVISITCATEG_ID = "VISIT_CAT_ID_COVERAGE";
	public final static String VISITCOVPOPUPPREAUTHCHKBOX_ID = "PRE_AUTHORIZATION_REQUIRED";
	public final static String VISITCOVPOPUPNOTES_NAME = "notes";
	public final static String VISITCOVPOPUPSUBMITBTN_XPATH = "//form[@id='CLASS_VISIT_COVERAGE_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String VISITCOVPOPUPCANCELBTN_XPATH = "//form[@id='CLASS_VISIT_COVERAGE_ADD_NEW_POPUP']//input[@value='Cancel']";
	public final static String VISITCOVGRIDDIV_ID = "CLASS_VISIT_COVERAGE_GRID_DIV";
	public final static String AGECOVCHKBOX_ID = "CLASS_AGE_COVERAGE_LIMIT";
	public final static String AGECOVFROM_ID = "AGE_COV_FROM";
	public final static String AGECOVFROMLIMIT_ID = "AGE_COV_LIMIT_DROPDOWN_FROM";
	public final static String AGECOVTO_ID = "AGE_COV_TO";
	public final static String AGECOVTOLIMIT_ID = "AGE_COV_LIMIT_DROPDOWN_TO";
	public final static String CLSCDTLIMITCHKBOX_ID = "CLASS_CREDIT_LIMIT";
	public final static String GENERAL_ID = "RADIO_BUTTONG";
	public final static String VISITSPEC_ID = "RADIO_BUTTONV";
	public final static String GAMOUNTVAL_ID = "CLASS_TOTAL_AMT";
	public final static String GAMOUNTTYPE_ID = "TOTAL_AMOUNT_DROPDOWN";
	public final static String SERVLIMITINCLCHKBOX_NAME = "multiselect_LIMIT_INCLUSION_GENERAL";
	public final static String ITEMLIMITINCLCHKBOX_NAME = "multiselect_LIMIT_INCLUSION_GENERAL_ITEM";
	public final static String VISITSPEC_ADDRECORDPLUSBTN_XPATH = "//div[@id='CLASS_VISIT_SPECIFIC_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String VISITSPECPOPUPFORM_ID = "CLASS_VISIT_SPECIFIC_ADD_NEW_POPUP";
	public final static String VISITSPECGRIDDIV_ID = "VISIT_SPECIFIC_GRID_DIV";
	public final static String VISITSPECVISITCAT_ID = "VISIT_CAT_ID_SPECIFIC";
	public final static String VISITSPECAMOUNT_ID = "AMOUNT_VISIT_SPC";
	public final static String VISITSPECAMOUNTTYPE_ID = "TOTAL_AMOUNT_DROPDOWN_VISIT_SPC";
	public final static String VISITSPEC_SERVLIMITINCLCHKBOX_NAME = "multiselect_LIMITINCLUSION_VISIT_SPC";
	public final static String VISITSPEC_ITEMLIMITINCLCHKBOX_NAME = "multiselect_LIMITINCLUSION_VISIT_SPC_ITEM";
	public final static String VISITSPECPOPUPSUBMITBTN_XPATH = "//form[@id='CLASS_VISIT_SPECIFIC_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String VISITSPECPOPUPCANCELBTN_XPATH = "//form[@id='CLASS_VISIT_SPECIFIC_ADD_NEW_POPUP']//input[@value='Cancel']";
	public final static String CDTLIMITDUR_ID = "CLASS_CREDIT_LIMIT_DURATION";
	public final static String AGRMNTCDTLIMITDUR_ID = "RADIO_BUTTON_CREDIT_LIMIT_DURagreement";
	public final static String POLCDTLIMITDUR_ID = "RADIO_BUTTON_CREDIT_LIMIT_DURpolicy";
	public final static String OTHERCDTLIMITDUR_ID = "RADIO_BUTTON_CREDIT_LIMIT_DURothers";
	public final static String CRDTLIMITSTARTDATE_ID = "datepicker_credit_start_dur";
	public final static String CRDTLIMITENDDATE_ID = "datepicker_credit_end_dur";

	private final static String GENERAL = "General",
			VISIT_SPEC = "Visit Specific", OTH = "Others";
	

	@FindBy(linkText = CLSGENPARAMSEC_LINKTEXT)
	private WebElement clsGenParamSec;

	@FindBy(id = CLSVISITCOVCHKBOX_ID)
	private WebElement clsVisitCovChkBox;
	
	@FindBy(xpath = ADDVISITCOVRECORDPLUSBTN_XPATH)
	private WebElement addVisitCovRecPlusbtn;

	@FindBy(id = ADDVISITCOVPOPUPFORM_ID)
	private WebElement addVisitCovPopupForm;

	@FindBy(id = VISITCOVPOPUPVISITCATEG_ID)
	private WebElement visitCovPopupVisitCategory;

	@FindBy(id = VISITCOVPOPUPPREAUTHCHKBOX_ID)
	private WebElement visitCovPopupPreAuthChkBox;

	@FindBy(name = VISITCOVPOPUPNOTES_NAME)
	private WebElement visitCovPopupNotes;

	@FindBy(xpath = VISITCOVPOPUPSUBMITBTN_XPATH)
	private WebElement visitCovPopupSubmitBtn;

	@FindBy(xpath = VISITCOVPOPUPCANCELBTN_XPATH)
	private WebElement visitCovPopupCancelBtn;

	@FindBy(id = VISITCOVGRIDDIV_ID)
	private WebElement visitCovGridDiv;

	@FindBy(id = AGECOVCHKBOX_ID)
	private WebElement ageCovChkBox;

	@FindBy(id = AGECOVFROM_ID)
	private WebElement ageCovFrom;

	@FindBy(id = AGECOVFROMLIMIT_ID)
	private WebElement ageCovFromLimit;

	@FindBy(id = AGECOVTO_ID)
	private WebElement ageCovTo;

	@FindBy(id = AGECOVTOLIMIT_ID)
	private WebElement ageCovToLimit;

	@FindBy(id = CLSCDTLIMITCHKBOX_ID)
	private WebElement clsCdtLimitChkBox;

	@FindBy(id = GENERAL_ID)
	private WebElement general;

	@FindBy(id = VISITSPEC_ID)
	private WebElement visitSpecific;

	@FindBy(id = GAMOUNTVAL_ID)
	private WebElement generalAmountVal;

	@FindBy(id = GAMOUNTTYPE_ID)
	private WebElement generalAmountType;

	@FindBy(name = SERVLIMITINCLCHKBOX_NAME)
	private WebElement genServiceLimitInclChkBox;

	@FindBy(name = ITEMLIMITINCLCHKBOX_NAME)
	private WebElement genItemLimitInclChkBox;

	@FindBy(xpath = VISITSPEC_ADDRECORDPLUSBTN_XPATH)
	private WebElement visitSpec_addRecPlusBtn;

	@FindBy(id = VISITSPECPOPUPFORM_ID)
	private WebElement visitSpecPopupForm;

	@FindBy(id = VISITSPECGRIDDIV_ID)
	private WebElement visitSpecGridDiv;

	@FindBy(id = VISITSPECVISITCAT_ID)
	private WebElement visitSpecVisitCat;

	@FindBy(id = VISITSPECAMOUNT_ID)
	private WebElement visitSpecAmount;

	@FindBy(id = VISITSPECAMOUNTTYPE_ID)
	private WebElement visitSpecAmountType;

	@FindBy(name = VISITSPEC_SERVLIMITINCLCHKBOX_NAME)
	private WebElement visitSpecServiceLimitInclChkBox;

	@FindBy(name = VISITSPEC_ITEMLIMITINCLCHKBOX_NAME)
	private WebElement visitSpecItemLimitInclChkBox;

	@FindBy(xpath = VISITSPECPOPUPSUBMITBTN_XPATH)
	private WebElement visitSpecPopupSubmitBtn;

	@FindBy(xpath = VISITSPECPOPUPCANCELBTN_XPATH)
	private WebElement visitSpecPopupCancelBtn;

	@FindBy(id = CDTLIMITDUR_ID)
	private WebElement cdtLimitDurChkBox;

	@FindBy(id = AGRMNTCDTLIMITDUR_ID)
	private WebElement agrmntCdtLimitDur;

	@FindBy(id = POLCDTLIMITDUR_ID)
	private WebElement polCdtLimitDur;

	@FindBy(id = OTHERCDTLIMITDUR_ID)
	private WebElement otherCdtLimitDur;

	@FindBy(id = CRDTLIMITSTARTDATE_ID)
	private WebElement cdtLimitStartDate;

	@FindBy(id = CRDTLIMITENDDATE_ID)
	private WebElement cdtLimitEndDate;

	public void addGeneralParamData(String[] classListData) throws Exception {
		if (Boolean.valueOf(classListData[8])) {
			ageCovChkBox.click();
			ageCovFrom.clear();
			ageCovFrom.sendKeys(classListData[9]);
			if (!classListData[10].isEmpty()) {
				new Select(ageCovFromLimit)
						.selectByVisibleText(classListData[10]);
			}
			ageCovTo.clear();
			ageCovTo.sendKeys(classListData[11]);
			if (!classListData[12].isEmpty()) {
				new Select(ageCovToLimit)
						.selectByVisibleText(classListData[12]);
			}
		}

		if (Boolean.valueOf(classListData[13])) {
			clsCdtLimitChkBox.click();
			selectRadioButtonAsLabelText(classListData[14]);

			if (GENERAL.equals(classListData[14])) {
				generalAmountVal.clear();
				generalAmountVal.sendKeys(classListData[15]);
				if (!classListData[15].isEmpty()) {
					new Select(generalAmountType)
							.selectByVisibleText(classListData[16]);
				}
				String[] temp;
				String delimiter = "\\,";
				temp = classListData[17].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMIT_INCLUSION_GENERAL", temp[i]);
				}

				temp = classListData[18].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMIT_INCLUSION_GENERAL_ITEM", temp[i]);
				}

			} else if (VISIT_SPEC.equals(classListData[14])) {
				waitForElementId(VISITSPECGRIDDIV_ID);
				visitSpec_addRecPlusBtn.click();
				sleepVeryShort();
				waitForElementId(VISITSPECPOPUPFORM_ID);
				if (!classListData[30].isEmpty()) {
					new Select(visitSpecVisitCat)
							.selectByVisibleText(classListData[19]);
				}
				visitSpecAmount.clear();
				visitSpecAmount.sendKeys(classListData[20]);
				if (!classListData[21].isEmpty()) {
					new Select(visitSpecAmountType)
							.selectByVisibleText(classListData[21]);
				}
				String[] temp;
				String delimiter = "\\,";
				temp = classListData[22].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMITINCLUSION_VISIT_SPC", temp[i]);
				}

				temp = classListData[23].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMITINCLUSION_VISIT_SPC_ITEM",
							temp[i]);
				}
				visitSpecPopupSubmitBtn.click();
			}
		}

		if (Boolean.valueOf(classListData[24])) {
			cdtLimitDurChkBox.click();
			selectRadioButtonAsLabelText(classListData[25]);
			if (OTH.equals(classListData[25])) {
				cdtLimitStartDate.clear();
				cdtLimitStartDate.sendKeys(DateTimeConverter.currentISTDateFormat());
				cdtLimitEndDate.clear();
				cdtLimitEndDate.sendKeys(classListData[27]);

			}
		}

	}

	public boolean checkVisitSpecGridData(String[] classListData)
			throws Exception {
		try {
			waitForElementXpathExpression("//td[@aria-describedby='CLASS_VISIT_SPECIFIC_GRID_visitCategoryText' and @title='"
					+ classListData[19] + "']");
			return webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='CLASS_VISIT_SPECIFIC_GRID_visitCategoryText' and @title='"
									+ classListData[19] + "']")).isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}

	public WebElement getClsGenParamSec() {
		return clsGenParamSec;
	}

	public WebElement getClsVisitCovChkBox() {
		return clsVisitCovChkBox;
	}

	public WebElement getAddVisitCovRecPlusbtn() {
		return addVisitCovRecPlusbtn;
	}

	public WebElement getAddVisitCovPopupForm() {
		return addVisitCovPopupForm;
	}

	public WebElement getVisitCovPopupVisitCategory() {
		return visitCovPopupVisitCategory;
	}

	public WebElement getVisitCovPopupPreAuthChkBox() {
		return visitCovPopupPreAuthChkBox;
	}

	public WebElement getVisitCovPopupNotes() {
		return visitCovPopupNotes;
	}

	public WebElement getVisitCovPopupSubmitBtn() {
		return visitCovPopupSubmitBtn;
	}

	public WebElement getVisitCovPopupCancelBtn() {
		return visitCovPopupCancelBtn;
	}

	public WebElement getVisitCovGridDiv() {
		return visitCovGridDiv;
	}

	public WebElement getAgeCovChkBox() {
		return ageCovChkBox;
	}

	public WebElement getAgeCovFrom() {
		return ageCovFrom;
	}

	public WebElement getAgeCovFromLimit() {
		return ageCovFromLimit;
	}

	public WebElement getAgeCovTo() {
		return ageCovTo;
	}

	public WebElement getAgeCovToLimit() {
		return ageCovToLimit;
	}

	public WebElement getClsCdtLimitChkBox() {
		return clsCdtLimitChkBox;
	}

	public WebElement getGeneral() {
		return general;
	}

	public WebElement getVisitSpecific() {
		return visitSpecific;
	}

	public WebElement getGeneralAmountVal() {
		return generalAmountVal;
	}

	public WebElement getGeneralAmountType() {
		return generalAmountType;
	}

	public WebElement getGenServiceLimitInclChkBox() {
		return genServiceLimitInclChkBox;
	}

	public WebElement getGenItemLimitInclChkBox() {
		return genItemLimitInclChkBox;
	}

	public WebElement getVisitSpec_addRecPlusBtn() {
		return visitSpec_addRecPlusBtn;
	}

	public WebElement getVisitSpecPopupForm() {
		return visitSpecPopupForm;
	}

	public WebElement getVisitSpecGridDiv() {
		return visitSpecGridDiv;
	}

	public WebElement getVisitSpecVisitCat() {
		return visitSpecVisitCat;
	}

	public WebElement getVisitSpecAmount() {
		return visitSpecAmount;
	}

	public WebElement getVisitSpecAmountType() {
		return visitSpecAmountType;
	}

	public WebElement getVisitSpecServiceLimitInclChkBox() {
		return visitSpecServiceLimitInclChkBox;
	}

	public WebElement getVisitSpecItemLimitInclChkBox() {
		return visitSpecItemLimitInclChkBox;
	}

	public WebElement getVisitSpecPopupSubmitBtn() {
		return visitSpecPopupSubmitBtn;
	}

	public WebElement getVisitSpecPopupCancelBtn() {
		return visitSpecPopupCancelBtn;
	}

	public WebElement getCdtLimitDurChkBox() {
		return cdtLimitDurChkBox;
	}

	public WebElement getAgrmntCdtLimitDur() {
		return agrmntCdtLimitDur;
	}

	public WebElement getPolCdtLimitDur() {
		return polCdtLimitDur;
	}

	public WebElement getOtherCdtLimitDur() {
		return otherCdtLimitDur;
	}

	public WebElement getCdtLimitStartDate() {
		return cdtLimitStartDate;
	}

	public WebElement getCdtLimitEndDate() {
		return cdtLimitEndDate;
	}

}
