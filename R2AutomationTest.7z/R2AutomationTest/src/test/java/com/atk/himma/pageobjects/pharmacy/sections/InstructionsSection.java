package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InstructionsSection {

	public final static String SECTIONNAME_LINKTEXT = "Instructions";
	public final static String INSTRUTOPHARMA_NAME = "brandedDrug.phrmacistInfo";
	public final static String INSTRUTOPATIENT_CSS = "#BRANDED_DRUG_himma_pharmacy_brandedDrug_instructions_patientInstruction + input";
	public final static String DISPLAYPATINST_ID = "DISP_PAT_INST_LABEL";
	public final static String PATINSTTXTEN_ID = "PAT_INST_TXT_EN";
	public final static String PATINSTTXTAR_ID = "PAT_INST_TXT_AR";
	public final static String PHYSICIANINST_NAME = "brandedDrug.physicianInst";

//	-----------Advisory/Cautionary Instructions...(POP UP)-------------------
	public final static String POPUPDIV_XPATH = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable']";
	public final static String INSTRUCTIONTYPE_NAME = "searchCriteria.instructionType";
	public final static String INSTRUCTIONDESC_NAME = "searchCriteria.instructionDesc";
	public final static String SEARCHBUTTON_ID = "PAT_INST_SRCH_BTN";
	public final static String RESETBUTTON_CSS = "#PAT_INST_SRCH_BTN + input";
	
//	--------------------------Pop up GRID------------------------
	public final static String GRID_ID = "PAT_INST_SEARCH_GRID";
	public final static String GRID_INSTRUTYPE_ARIA_DESCRIBEDBY = "PAT_INST_SEARCH_GRID_instructionTypeText";
	public final static String GRID_INSTRUDESC_ARIA_DESCRIBEDBY = "PAT_INST_SEARCH_GRID_instructionDesc";
	public final static String GRID_INSTRUDESCAR_ARIA_DESCRIBEDBY = "PAT_INST_SEARCH_GRID_instructionDescAr";
	
	public final static String SUBMITBUTTON_ID = "PAT_INST_SUBMIT_BTN";
	public final static String CANCELBUTTON_CSS = "#PAT_INST_SUBMIT_BTN + input";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(name = INSTRUTOPHARMA_NAME)
	private WebElement instruToPharma;
	
	@FindBy(css = INSTRUTOPATIENT_CSS)
	private WebElement instruToPatient;
	
	@FindBy(id = DISPLAYPATINST_ID)
	private WebElement displayPatInst;
	
	@FindBy(id = PATINSTTXTAR_ID)
	private WebElement patInstTxtAr;
	
	@FindBy(id = PATINSTTXTEN_ID)
	private WebElement patInstTxtEng;
	
	@FindBy(name = PHYSICIANINST_NAME)
	private WebElement physicianInst;
	
	@FindBy(id = GRID_ID)
	private WebElement grid;
	
	@FindBy(xpath = POPUPDIV_XPATH)
	private WebElement popupDiv;
	
	@FindBy(name = INSTRUCTIONTYPE_NAME)
	private WebElement instructionType;
	
	@FindBy(name = INSTRUCTIONDESC_NAME)
	private WebElement instructionDesc;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;
	
	@FindBy(css = SUBMITBUTTON_ID)
	private WebElement submitButton;
	
	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButton;

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the instruToPharma
	 */
	public WebElement getInstruToPharma() {
		return instruToPharma;
	}

	/**
	 * @return the instruToPatient
	 */
	public WebElement getInstruToPatient() {
		return instruToPatient;
	}

	/**
	 * @return the displayPatInst
	 */
	public WebElement getDisplayPatInst() {
		return displayPatInst;
	}

	/**
	 * @return the patInstTxtAr
	 */
	public WebElement getPatInstTxtAr() {
		return patInstTxtAr;
	}

	/**
	 * @return the patInstTxtEng
	 */
	public WebElement getPatInstTxtEng() {
		return patInstTxtEng;
	}

	/**
	 * @return the physicianInst
	 */
	public WebElement getPhysicianInst() {
		return physicianInst;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the popupDiv
	 */
	public WebElement getPopupDiv() {
		return popupDiv;
	}

	/**
	 * @return the instructionType
	 */
	public WebElement getInstructionType() {
		return instructionType;
	}

	/**
	 * @return the instructionDesc
	 */
	public WebElement getInstructionDesc() {
		return instructionDesc;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}
	
}
