package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class BillingScenarioSec extends DriverWaitClass {
	public final static String BILLINGSCENARIOSEC_XPATH = "//a[text()='Billing Scenario']";
	@FindBy(xpath = BILLINGSCENARIOSEC_XPATH)
	private WebElement billingScenarioSec;

	public final static String BILLINGADDROWBTN_ID = "BILLING_ADD_ROW_ID";
	@FindBy(id = BILLINGADDROWBTN_ID)
	private WebElement billingAddRowBtn;

	public final static String VISITCATGRIDBTN_XPATH = "//button[@class='ui-multiselect ui-state-default']";
	@FindBy(xpath = VISITCATGRIDBTN_XPATH)
	private WebElement visitCatGridBtn;

	public final static String STAGE_NAME = "stage";
	@FindBy(name = STAGE_NAME)
	private WebElement stage;

	public WebElement getBillingScenarioSec() {
		return billingScenarioSec;
	}

	public WebElement getBillingAddRowBtn() {
		return billingAddRowBtn;
	}

	public WebElement getVisitCatGridBtn() {
		return visitCatGridBtn;
	}

	public WebElement getStage() {
		return stage;
	}

}
