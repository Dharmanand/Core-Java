package com.atk.himma.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ExcelReader {
	List<String[]> excelList;
	String[][] stExcelList;
	String[] excel;
	private String inputFile;

	public void setInputFile(String inputFile) {
		this.inputFile = inputFile;
	}

	public List<String[]> read(String sheetName) throws IOException {
		excelList = new ArrayList<String[]>();
		File inputWorkbook = new File(inputFile);
		Workbook w;
		try {
			w = Workbook.getWorkbook(inputWorkbook);
			// Get the first sheet
			Sheet sheet = w.getSheet(sheetName);
			// Loop over first 10 column and lines
			for (int j = 1; j < sheet.getRows(); j++) {
				excel = new String[sheet.getColumns()];
				for (int i = 0; i < sheet.getColumns(); i++) {
					Cell cell = sheet.getCell(i, j);
					excel[i] = cell.getContents();
				}
				excelList.add(excel);
			}
			return excelList;
		} catch (BiffException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void main(String[] args) throws IOException {
		ExcelReader excelReader = new ExcelReader();
		excelReader.setInputFile("src//test//resources//excels//PREG.xls");
		List<String[]> abc = excelReader.read("Base LV");
		for (String[] ab : abc) {
			for (int a = 0; a < ab.length; a++) {
				System.out.println(a + ": --->> " + ab[a]);
			}
		}
	}

}