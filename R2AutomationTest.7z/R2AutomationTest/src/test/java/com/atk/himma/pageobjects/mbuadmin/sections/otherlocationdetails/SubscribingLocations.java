package com.atk.himma.pageobjects.mbuadmin.sections.otherlocationdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SubscribingLocations extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Subscribing Locations";

	public final static String ADDBUTTONGRID_XPATH = "//td[@id='SUBSCRIBING_LOCATIONS_GRID_pager_left']//div[@class='ui-pg-div']/span";

	// Lookup Window

	public final static String LOOKUPFORM_ID = "addSubscribingLocationForm";
	public final static String LOOKUPTITLE_ID = "ui-dialog-title-subscribingLocationDialog";
	public final static String MBU_ID = "MBU_LIST_TAB2PP2";
	public final static String DEPARTMENT_ID = "DEPARTMENT_LIST_TAB2PP2";
	public final static String LOCCATEGORY_ID = "LOC_CATEGORY_LIST_TAB2PP2";
	public final static String LOCATIONCODE_ID = "LOCATION_CODE_TAB2PP2";
	public final static String LOCATIONNAME_ID = "LOCATION_NAME_TAB2PP2";
	public final static String SEARCHBUTTON_XPATH = "//form[@id='addSubscribingLocationForm']//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//form[@id='addSubscribingLocationForm']//span[@class='buttoncontainer_mid']//input[@value='Reset']";

	// PopUp Grid

	public final static String PUPGRIDID_ID = "SEARCH_SUBSCRIBING_LOCATIONS_GRID";
	public final static String PUPGRID_CKBOX_ARIA_DESCRIBEDBY = "SEARCH_SUBSCRIBING_LOCATIONS_GRID_cb";
	public final static String PUPGRID_LOCATIONCODE_ARIA_DESCRIBEDBY = "SEARCH_SUBSCRIBING_LOCATIONS_GRID_locationCode";
	public final static String PUPGRID_locationName_ARIA_DESCRIBEDBY = "SEARCH_SUBSCRIBING_LOCATIONS_GRID_locationName";
	public final static String PUPGRID_CATEGORYTEXT_ARIA_DESCRIBEDBY = "SEARCH_SUBSCRIBING_LOCATIONS_GRID_categoryText";
	public final static String PUPGRID_primaryPhone_ARIA_DESCRIBEDBY = "SEARCH_SUBSCRIBING_LOCATIONS_GRID_primaryPhone";
	public final static String PUPGRID_PAGERID = "sp_1_SEARCH_SUBSCRIBING_LOCATIONS_GRID_pager";
	public final static String PUPGRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_SUBSCRIBING_LOCATIONS_GRID_pager']";

	public final static String SUBMITBUTTON_XPATH = ".//form[@id='addSubscribingLocationForm']//span[@class='buttoncontainer_vlrg_rgt']//input[@class='input_button' and @value='Submit']";
	public final static String CANCELBUTTON_XPATH = ".//form[@id='addSubscribingLocationForm']//span[@class='buttoncontainer_vlrg_rgt']//input[@class='input_cancel' and @value='Cancel']";

	public final static String GRIDID_ID = "SUBSCRIBING_LOCATIONS_GRID";
	public final static String GRID_LOCATIONCODE_ID = "SUBSCRIBING_LOCATIONS_GRID_locationInfo.locationCode";
	public final static String GRID_LOCATIONNAME_ARIA_DESCRIBEDBY = "SUBSCRIBING_LOCATIONS_GRID_locationInfo.locationName";
	public final static String GRID_LOCATIONCATEGORY_ARIA_DESCRIBEDBY = "SUBSCRIBING_LOCATIONS_GRID_locationInfo.categoryText";
	public final static String GRID_PRIMARYPHONE_ARIA_DESCRIBEDBY = "SUBSCRIBING_LOCATIONS_GRID_locationInfo.primaryPhone";
	public final static String GRID_PAGERID = "sp_1_SUBSCRIBING_LOCATIONS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SUBSCRIBING_LOCATIONS_GRID_pager']";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Subscribing Locations')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButtonGrid;

	@FindBy(id = LOOKUPFORM_ID)
	private WebElement lookUpForm;

	@FindBy(id = LOOKUPTITLE_ID)
	private WebElement lookUpTitle;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	@FindBy(id = LOCCATEGORY_ID)
	private WebElement locCategory;

	@FindBy(id = LOCATIONCODE_ID)
	private WebElement locationCode;

	@FindBy(id = LOCATIONNAME_ID)
	private WebElement locationName;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	// PopUp Grid

	@FindBy(id = PUPGRIDID_ID)
	private WebElement pupGridID;

	@FindBy(id = PUPGRID_PAGERID)
	private WebElement pupGridPager;

	@FindBy(xpath = PUPGRID_NEXTPAGE_XPATH)
	private WebElement pupGridNextPage;

	// PopUp Grid

	@FindBy(xpath = SUBMITBUTTON_XPATH)
	private WebElement submitButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(id = GRIDID_ID)
	private WebElement grid;

	@FindBy(id = GRID_PAGERID)
	private WebElement gridPager;

	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement gridNextPage;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkSubscriLocSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatas(String[] otherLocDatas)
			throws InterruptedException {
		waitForElementXpathExpression(ADDBUTTONGRID_XPATH);
		addButtonGrid.click();
		waitForElementId(LOOKUPTITLE_ID);
		sleepVeryShort();
		locationName.clear();
		locationName.sendKeys(otherLocDatas[23].trim());
		searchButton.click();
		sleepShort();
		clickOnCheckBoxGridItem(PUPGRIDID_ID, otherLocDatas[23].trim());
		waitForElementXpathExpression(SUBMITBUTTON_XPATH);
		sleepShort();
		submitButton.click();
		sleepShort();
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addButtonGrid
	 */
	public WebElement getAddButtonGrid() {
		return addButtonGrid;
	}

	/**
	 * @return the lookUpForm
	 */
	public WebElement getLookUpForm() {
		return lookUpForm;
	}

	/**
	 * @return the lookUpTitle
	 */
	public WebElement getLookUpTitle() {
		return lookUpTitle;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the locCategory
	 */
	public WebElement getLocCategory() {
		return locCategory;
	}

	/**
	 * @return the locationCode
	 */
	public WebElement getLocationCode() {
		return locationCode;
	}

	/**
	 * @return the locationName
	 */
	public WebElement getLocationName() {
		return locationName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the pupGridID
	 */
	public WebElement getPupGridID() {
		return pupGridID;
	}

	/**
	 * @return the pupGridPager
	 */
	public WebElement getPupGridPager() {
		return pupGridPager;
	}

	/**
	 * @return the pupGridNextPage
	 */
	public WebElement getPupGridNextPage() {
		return pupGridNextPage;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the gridNextPage
	 */
	public WebElement getGridNextPage() {
		return gridNextPage;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
