package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class DosageInformationSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Dosage Information";
	public final static String DRUGDOSAGEFORM_NAME = "brandedDrug.drugDosageForm";
	public final static String ACTIONNAME_ID = "DOSAGE_ACTION";
	public final static String ACTIONQUANTITY_ID = "DOSAGE_QUANTITY";
	public final static String ACTIONQUANTTYPE_ID = "DOSAGE_QUANTITY_TYPE";
	public final static String FREQUENCY_NAME = "brandedDrug.frequency";
	public final static String DURATIONPERIOD_NAME = "DOSAGE_PERIOD";
	public final static String DURPERIODTYPE_NAME = "DOSAGE_PERIOD_TYPE";
	public final static String DOSAGEDETAILEDITABLE_ID = "DOSAGE_DETAIL_EDITABLE";
	public final static String FORMULARY_ID = "FORMULARY";
	public final static String RETURNABLE_ID = "RETURNABLE";
	public final static String REFUNDABLE_ID = "REFUNDABLE";
	public final static String DESKPENSEPACK_ID = "DESKPENSE_PACK";
	public final static String NEDDORDERDETAIL_ID = "NEDD_ORDER_DETAIL";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(name = DRUGDOSAGEFORM_NAME)
	private WebElement drugDosageForm;

	@FindBy(id = ACTIONNAME_ID)
	private WebElement actionName;

	@FindBy(id = ACTIONQUANTITY_ID)
	private WebElement actionQuantity;

	@FindBy(id = ACTIONQUANTTYPE_ID)
	private WebElement actionQuantType;

	@FindBy(name = FREQUENCY_NAME)
	private WebElement frequency;

	@FindBy(name = DURATIONPERIOD_NAME)
	private WebElement durationPeriod;

	@FindBy(name = DURPERIODTYPE_NAME)
	private WebElement durPeriodType;

	@FindBy(id = DOSAGEDETAILEDITABLE_ID)
	private WebElement dosageDetailEditable;

	@FindBy(id = FORMULARY_ID)
	private WebElement formulary;

	@FindBy(id = RETURNABLE_ID)
	private WebElement returnable;

	@FindBy(id = REFUNDABLE_ID)
	private WebElement refundable;

	@FindBy(id = DESKPENSEPACK_ID)
	private WebElement deskpensePack;

	@FindBy(id = NEDDORDERDETAIL_ID)
	private WebElement needOrderDetail;

	public void selectRouteOfAdmin(String routeAdminName, boolean isSelect) {

		WebElement element = webDriver
				.findElement(By
						.xpath("//ul[@class='ui-multiselect-checkboxes ui-helper-reset']//label[@title='"
								+ routeAdminName.trim() + "']/input"));
		if ((!element.isSelected() && isSelect)
				|| (element.isSelected() && !isSelect))
			element.click();
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the drugDosageForm
	 */
	public WebElement getDrugDosageForm() {
		return drugDosageForm;
	}

	/**
	 * @return the actionName
	 */
	public WebElement getActionName() {
		return actionName;
	}

	/**
	 * @return the actionQuantity
	 */
	public WebElement getActionQuantity() {
		return actionQuantity;
	}

	/**
	 * @return the actionQuantType
	 */
	public WebElement getActionQuantType() {
		return actionQuantType;
	}

	/**
	 * @return the frequency
	 */
	public WebElement getFrequency() {
		return frequency;
	}

	/**
	 * @return the durationPeriod
	 */
	public WebElement getDurationPeriod() {
		return durationPeriod;
	}

	/**
	 * @return the durPeriodType
	 */
	public WebElement getDurPeriodType() {
		return durPeriodType;
	}

	/**
	 * @return the dosageDetailEditable
	 */
	public WebElement getDosageDetailEditable() {
		return dosageDetailEditable;
	}

	/**
	 * @return the formulary
	 */
	public WebElement getFormulary() {
		return formulary;
	}

	/**
	 * @return the returnable
	 */
	public WebElement getReturnable() {
		return returnable;
	}

	/**
	 * @return the refundable
	 */
	public WebElement getRefundable() {
		return refundable;
	}

	/**
	 * @return the deskpensePack
	 */
	public WebElement getDeskpensePack() {
		return deskpensePack;
	}

	/**
	 * @return the needOrderDetail
	 */
	public WebElement getNeedOrderDetail() {
		return needOrderDetail;
	}
}
