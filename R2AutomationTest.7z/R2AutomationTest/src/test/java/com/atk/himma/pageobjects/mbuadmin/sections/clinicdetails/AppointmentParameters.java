package com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AppointmentParameters extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Appointment Parameters";
	public final static String ADDBUTTONGRID_XPATH = "//td[@id='VISIT_PARAMETERS_GRID_pager_left']//div[@class='ui-pg-div']/span";
	public final static String OVERRIDEMBUPARAM_ID = "OVERRIDE_MBU_PARAM";
	public final static String POPUPFORMID_ID = "addVisitParameterForm";
	public final static String POPUPTITLE_ID = "ui-dialog-title-visitParametersDialog";
	public final static String VISITCATEPOPUP_ID = "VISIT_CATEGORY";
	public final static String VISITTYPEPOPUP_ID = "VISIT_TYPE";
	public final static String NUMALLOWPERVISIT_ID = "NUMBER_ALLOWED_PER_VISIT";
	public final static String DURAFORELIGIBILITY_ID = "DURATION_FOR_ELIGIBILITY";

	public final static String SUBMITBUTTON_ID = "//span[@class='buttoncontainer_sml']//input[@value='Submit']";
	public final static String CANCELBUTTON_ID = "//span[@class='buttoncontainer_sml']//input[@value='Cancel']";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Appointment Parameters')]/..";

	public final static String GRIDID_ID = "VISIT_PARAMETERS_GRID";
	public final static String GRID_VISITCATEGORY_ID = "VISIT_PARAMETERS_GRID_visitCategoryText";
	public final static String GRID_VISITTYPE_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_visitTypeText";
	public final static String GRID_NOALLOWEDPERVISIT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_allowedPerVisit";
	public final static String GRID_ELIGIBILITYDURATION_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_eligibilityDuration";
	public final static String GRID_PAGERID = "sp_1_VISIT_PARAMETERS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_VISIT_PARAMETERS_GRID_pager']";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = OVERRIDEMBUPARAM_ID)
	private WebElement overrideMBUParam;

	@FindBy(id = VISITCATEPOPUP_ID)
	private WebElement visitCatePopup;

	@FindBy(id = VISITTYPEPOPUP_ID)
	private WebElement visitTypePopup;

	@FindBy(id = NUMALLOWPERVISIT_ID)
	private WebElement numAllowPeRVisit;

	@FindBy(id = DURAFORELIGIBILITY_ID)
	private WebElement duraForEligibility;

	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButtonGrid;

	@FindBy(id = POPUPFORMID_ID)
	private WebElement popupFormid;

	@FindBy(id = POPUPTITLE_ID)
	private WebElement popupTitle;

	@FindBy(id = SUBMITBUTTON_ID)
	private WebElement submitButton;

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	@FindBy(id = GRIDID_ID)
	private WebElement gridID;

	@FindBy(id = GRID_PAGERID)
	private WebElement gridPager;

	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement gridNextPage;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkAppointParamSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatas(String[] clinicDatas) throws InterruptedException {
		selectOrUnSelectCheckBox(clinicDatas[25].trim(), overrideMBUParam);
		if (overrideMBUParam.isSelected()) {
			addButtonGrid.click();
			waitForElementId(POPUPFORMID_ID);
			sleepVeryShort();
			new Select(visitCatePopup).selectByVisibleText(clinicDatas[26]
					.trim());
			new Select(visitTypePopup).selectByVisibleText(clinicDatas[27]
					.trim());
			numAllowPeRVisit.sendKeys(clinicDatas[28].trim());
			duraForEligibility.clear();
			duraForEligibility.sendKeys(clinicDatas[29].trim());
		}
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the overrideMBUParam
	 */
	public WebElement getOverrideMBUParam() {
		return overrideMBUParam;
	}

	/**
	 * @return the visitCatePopup
	 */
	public WebElement getVisitCatePopup() {
		return visitCatePopup;
	}

	/**
	 * @return the visitTypePopup
	 */
	public WebElement getVisitTypePopup() {
		return visitTypePopup;
	}

	/**
	 * @return the numAllowPeRVisit
	 */
	public WebElement getNumAllowPeRVisit() {
		return numAllowPeRVisit;
	}

	/**
	 * @return the duraForEligibility
	 */
	public WebElement getDuraForEligibility() {
		return duraForEligibility;
	}

	/**
	 * @return the addButtonGrid
	 */
	public WebElement getAddButtonGrid() {
		return addButtonGrid;
	}

	/**
	 * @return the popupFormid
	 */
	public WebElement getPopupFormid() {
		return popupFormid;
	}

	/**
	 * @return the popupTitle
	 */
	public WebElement getPopupTitle() {
		return popupTitle;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the gridID
	 */
	public WebElement getGridID() {
		return gridID;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the gridNextPage
	 */
	public WebElement getGridNextPage() {
		return gridNextPage;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
