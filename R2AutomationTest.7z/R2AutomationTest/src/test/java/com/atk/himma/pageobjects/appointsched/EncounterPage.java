package com.atk.himma.pageobjects.appointsched;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class EncounterPage extends DriverWaitClass implements StatusMessages,
		TopControls {

	public static String encounterNumber;
	public final static String FORM_ID = "ENCOUNTERFORM";
	public final static String SAVEBUTTON_XPATH = "//form[@id='ENCOUNTERFORM']//span[@class='buttoncontainer_vlrg_top']//input[@value='Save ']";
	public final static String CANCELBUTTON_XPATH = "//form[@id='ENCOUNTERFORM']//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String URGENCY_ID = "urgencyid";
	public final static String ENCOUNTERNO_ID = "ENCOUNTER_NUMBER_ID";
	public final static String COMMENTS_NAME = "encounterInfo.comments";
	public final static String SAVEMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(), 'Encounter Created')]";
	public final static String UPDATEMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(), 'Encounter Updated')]";
	public final static String ENCOUNTNOMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(), 'Encounter Number is :')]";

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(id = ENCOUNTERNO_ID)
	private WebElement encounterNo;

	@FindBy(id = URGENCY_ID)
	private WebElement urgency;

	@FindBy(name = COMMENTS_NAME)
	private WebElement comments;

	public void fillDatas(String[] encounterDatas) throws InterruptedException {

		waitForElementId(URGENCY_ID);
		sleepVeryShort();
		new Select(urgency).selectByVisibleText(encounterDatas[1].trim());
		comments.clear();
		comments.sendKeys(encounterDatas[2].trim());

	}

	public String saveEncounter() throws Exception {
		sleepShort();
		waitForElementXpathExpression(SAVEBUTTON_XPATH);
		sleepShort();
		saveButton.click();
		waitForElementXpathExpression(SAVEMSG_XPATH);
		sleepVeryShort();
		waitForElementId(ENCOUNTERNO_ID);
		String msg = webDriver.findElement(By.xpath(SAVEMSG_XPATH)).getText();
		encounterNumber = encounterNo.getAttribute("value").trim();
		webDriver.close();
		webDriver.switchTo().window(parentWindowHandle);
		sleepVeryShort();
		return msg;
	}

	public String updateEncounter(String[] encounterDatas) throws Exception {
		fillDatas(encounterDatas);
		sleepVeryShort();
		saveButton.click();
		waitForElementXpathExpression(UPDATEMSG_XPATH);
		sleepVeryShort();
		String msg = webDriver.findElement(By.xpath(UPDATEMSG_XPATH)).getText();
		webDriver.close();
		webDriver.switchTo().window(parentWindowHandle);
		return msg;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the urgency
	 */
	public WebElement getUrgency() {
		return urgency;
	}

	/**
	 * @return the comments
	 */
	public WebElement getComments() {
		return comments;
	}

	/**
	 * @return the encounterNo
	 */
	public WebElement getEncounterNo() {
		return encounterNo;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}
}
