package com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;

public class FinancialParametersSection extends DriverWaitClass {
	public final static String FINANCIALPARAMETERSSEC_LINKTEXT = "Financial Parameters";
	public final static String CREDITLIMITCHKBOX_ID = "CREDIT_LIMIT_CHBOX";
	public final static String MAXCREDITLIMIT_ID = "max_credit_limit";
	public final static String MAXCREDITLIMITCURRENCY_NAME = "debtorAgreement.financeParams.maxCreditLimitCur";
	public final static String CURRENTCREDITAMNT_ID = "cur_credit_limit";
	public final static String CURRENTCREDITAMNTCURRENCY_NAME = "debtorAgreement.financeParams.currentCreditLimitCur";
	public final static String CREDITDAYS_ID = "credit_days";
	public final static String AGRMNTDUR_ID = "Agreement_Duration1";
	public final static String OTHERDUR_ID = "Agreement_Duration2";
	public final static String STARTDATECREDITLIMIT_ID = "start_date_creditLimit";
	public final static String ENDDATECREDITLIMIT_ID = "end_date_creditLimit";

	public final static String DEPOSITCHKBOX_ID = "DEPOSIT_CHBOX";
	public final static String MINDEPOAMNT_ID = "min_dep_amt";
	public final static String MINDEPOAMNTCURRENCY_NAME = "debtorAgreement.financeParams.minDepositAmtCur";

	public final static String PAYMENTCALCULATIONS_ID = "PAY_AND_CALC_CHBOX";
	public final static String PAYMENTDUEAFTERVAL_ID = "pay_due_after_val";
	public final static String PAYMENTDUEAFTERTYPE_NAME = "debtorAgreement.financeParams.payDueAfterType";

	public final static String CLAIMDOCREQ_ID = "CLAIM_DOC_REQ_CHBOX";
	public final static String CLAIMFORMREQ_ID = "AGMNT_CLAIM_FORM_REQ";
	public final static String TEMPLATE_NAME = "debtorAgreement.financeParams.templateId";
	public final static String CODINGFORMATCHKBOX_ID = "AGMNT_CODING_FORMAT_CHBOX";
	public final static String CODINGFORMATDIV_ID = "AGMNT_CODING_FORMAT_DIV";
	public final static String ADDROWCODEFORMAT_ID = "AddRow_CodForForm_Action";
	public final static String TEMPLATEITEMS_ID = "COD_TEMPLATE_ITEMS";
	public final static String CODINGFORMAT_ID = "COD_FORMAT_DATA";
	public final static String ADDCODEFORMATBTN_ID = "ADD_CODING_FORMAT";
	public final static String CANCELADDROW_ID = "CancelRow_CodForForm_Action";
	public final static String CODINGFORMATGRIDDIV_ID = "CODING_FORMAT_GRID_DIV";
	public final static String STDDISCPATTDIV_ID = "STANDARD_DISCOUNT_DIV";
	public final static String AGRMNTRATEPLANDIV_ID = "AGREEMENT_SPECIFIC_DIV";

	private final static String AGRMNT_DUR = "Agreement Duration",
			OTHERS = "Others";

	@FindBy(linkText = FINANCIALPARAMETERSSEC_LINKTEXT)
	private WebElement financialParamSec;

	@FindBy(id = CREDITLIMITCHKBOX_ID)
	private WebElement creditLimitChkBox;

	@FindBy(id = MAXCREDITLIMIT_ID)
	private WebElement maxCreditLimit;

	@FindBy(name = MAXCREDITLIMITCURRENCY_NAME)
	private WebElement maxCreditLimitCurrency;

	@FindBy(id = CURRENTCREDITAMNT_ID)
	private WebElement currentCreditAmount;

	@FindBy(name = CURRENTCREDITAMNTCURRENCY_NAME)
	private WebElement currentCreditAmountCurrency;

	@FindBy(id = CREDITDAYS_ID)
	private WebElement creditDays;

	@FindBy(id = AGRMNTDUR_ID)
	private WebElement agrmntDuration;

	@FindBy(id = OTHERDUR_ID)
	private WebElement otherDuration;

	@FindBy(id = STARTDATECREDITLIMIT_ID)
	private WebElement startDate;

	@FindBy(id = ENDDATECREDITLIMIT_ID)
	private WebElement endDate;

	@FindBy(id = DEPOSITCHKBOX_ID)
	private WebElement depositChkBox;

	@FindBy(id = MINDEPOAMNT_ID)
	private WebElement minDepositAmount;

	@FindBy(name = MINDEPOAMNTCURRENCY_NAME)
	private WebElement minDepositAmountCurrency;

	@FindBy(id = PAYMENTCALCULATIONS_ID)
	private WebElement paymentCalculationsChkBox;

	@FindBy(id = PAYMENTDUEAFTERVAL_ID)
	private WebElement paymentDueAfterValue;

	@FindBy(name = PAYMENTDUEAFTERTYPE_NAME)
	private WebElement paymentDueAfterType;

	@FindBy(id = CLAIMDOCREQ_ID)
	private WebElement claimDocReqmnt;

	@FindBy(id = CLAIMFORMREQ_ID)
	private WebElement claimFormReqd;

	@FindBy(name = TEMPLATE_NAME)
	private WebElement template;

	@FindBy(id = CODINGFORMATCHKBOX_ID)
	private WebElement codingFormatChkBox;

	@FindBy(id = CODINGFORMATDIV_ID)
	private WebElement codingFormatDiv;

	@FindBy(id = ADDROWCODEFORMAT_ID)
	private WebElement addRowCodeFormat;

	@FindBy(id = TEMPLATEITEMS_ID)
	private WebElement templateItems;

	@FindBy(id = CODINGFORMAT_ID)
	private WebElement codingFormat;

	@FindBy(id = ADDCODEFORMATBTN_ID)
	private WebElement addBtn;

	@FindBy(id = CANCELADDROW_ID)
	private WebElement cancelBtn;

	@FindBy(id = CODINGFORMATGRIDDIV_ID)
	private WebElement codingFormatGridDiv;

	@FindBy(id = STDDISCPATTDIV_ID)
	private WebElement stdDiscPatternDiv;

	@FindBy(id = AGRMNTRATEPLANDIV_ID)
	private WebElement agrmntRatePlanDiv;

	public void addFinancialParamData(String[] debtorAgrmntListData) {
		if (Boolean.valueOf(debtorAgrmntListData[22])) {
			creditLimitChkBox.click();
			maxCreditLimit.clear();
			maxCreditLimit.sendKeys(debtorAgrmntListData[23]);
			if (!debtorAgrmntListData[24].isEmpty()) {
				new Select(maxCreditLimitCurrency)
						.selectByVisibleText(debtorAgrmntListData[24]);
			}
			currentCreditAmount.clear();
			currentCreditAmount.sendKeys(debtorAgrmntListData[25]);
			if (!debtorAgrmntListData[26].isEmpty()) {
				new Select(currentCreditAmountCurrency)
						.selectByVisibleText(debtorAgrmntListData[26]);
			}
			creditDays.clear();
			creditDays.sendKeys(debtorAgrmntListData[27]);
			selectRadioButtonAsLabelText(debtorAgrmntListData[28]);
			if (OTHERS.equals(debtorAgrmntListData[28])) {
				startDate.clear();
				startDate.sendKeys(DateTimeConverter.currentISTDateFormat());
				endDate.clear();
				endDate.sendKeys(debtorAgrmntListData[30]);
			}
		}

		if (Boolean.valueOf(debtorAgrmntListData[31])) {
			depositChkBox.click();
			minDepositAmount.clear();
			minDepositAmount.sendKeys(debtorAgrmntListData[32]);
			if (!debtorAgrmntListData[33].isEmpty()) {
				new Select(minDepositAmountCurrency)
						.selectByVisibleText(debtorAgrmntListData[33]);
			}
		}

		if (Boolean.valueOf(debtorAgrmntListData[34])) {
			paymentCalculationsChkBox.click();
			selectRadioButtonAsLabelText(debtorAgrmntListData[35]);
			selectRadioButtonAsLabelText(debtorAgrmntListData[36]);
			paymentDueAfterValue.clear();
			paymentDueAfterValue.sendKeys(debtorAgrmntListData[37]);
			if (!debtorAgrmntListData[38].isEmpty()) {
				new Select(paymentDueAfterType)
						.selectByVisibleText(debtorAgrmntListData[38]);
			}
			selectRadioButtonAsLabelText(debtorAgrmntListData[39]);

		}

		if (Boolean.valueOf(debtorAgrmntListData[40])) {
			claimDocReqmnt.click();
			if (Boolean.valueOf(debtorAgrmntListData[41])) {
				claimFormReqd.click();
				if (!debtorAgrmntListData[42].isEmpty()) {
					new Select(template)
							.selectByVisibleText(debtorAgrmntListData[42]);
				}
			}
			if (Boolean.valueOf(debtorAgrmntListData[43])) {
				codingFormatChkBox.click();
				waitForElementId(CODINGFORMATDIV_ID);
				addRowCodeFormat.click();
				waitForElementId(TEMPLATEITEMS_ID);
				templateItems.clear();
				templateItems.sendKeys(debtorAgrmntListData[44]);
				if (!debtorAgrmntListData[45].isEmpty()) {
					new Select(codingFormat)
							.selectByVisibleText(debtorAgrmntListData[45]);
				}
				addBtn.click();
				waitForElementId(CODINGFORMATGRIDDIV_ID);
			}
		}

		selectRadioButtonAsLabelText(debtorAgrmntListData[46]);

	}

	public WebElement getFinancialParamSec() {
		return financialParamSec;
	}

	public WebElement getCreditLimitChkBox() {
		return creditLimitChkBox;
	}

	public WebElement getMaxCreditLimit() {
		return maxCreditLimit;
	}

	public WebElement getMaxCreditLimitCurrency() {
		return maxCreditLimitCurrency;
	}

	public WebElement getCurrentCreditAmount() {
		return currentCreditAmount;
	}

	public WebElement getCurrentCreditAmountCurrency() {
		return currentCreditAmountCurrency;
	}

	public WebElement getCreditDays() {
		return creditDays;
	}

	public WebElement getAgrmntDuration() {
		return agrmntDuration;
	}

	public WebElement getOtherDuration() {
		return otherDuration;
	}

	public WebElement getStartDate() {
		return startDate;
	}

	public WebElement getEndDate() {
		return endDate;
	}

	public WebElement getDepositChkBox() {
		return depositChkBox;
	}

	public WebElement getMinDepositAmount() {
		return minDepositAmount;
	}

	public WebElement getMinDepositAmountCurrency() {
		return minDepositAmountCurrency;
	}

	public WebElement getPaymentCalculationsChkBox() {
		return paymentCalculationsChkBox;
	}

	public WebElement getPaymentDueAfterValue() {
		return paymentDueAfterValue;
	}

	public WebElement getPaymentDueAfterType() {
		return paymentDueAfterType;
	}

	public WebElement getClaimDocReqmnt() {
		return claimDocReqmnt;
	}

	public WebElement getClaimFormReqd() {
		return claimFormReqd;
	}

	public WebElement getTemplate() {
		return template;
	}

	public WebElement getCodingFormatChkBox() {
		return codingFormatChkBox;
	}

	public WebElement getCodingFormatDiv() {
		return codingFormatDiv;
	}

	public WebElement getAddRowCodeFormat() {
		return addRowCodeFormat;
	}

	public WebElement getTemplateItems() {
		return templateItems;
	}

	public WebElement getCodingFormat() {
		return codingFormat;
	}

	public WebElement getAddBtn() {
		return addBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getCodingFormatGridDiv() {
		return codingFormatGridDiv;
	}

	public WebElement getStdDiscPatternDiv() {
		return stdDiscPatternDiv;
	}

	public WebElement getAgrmntRatePlanDiv() {
		return agrmntRatePlanDiv;
	}

}
