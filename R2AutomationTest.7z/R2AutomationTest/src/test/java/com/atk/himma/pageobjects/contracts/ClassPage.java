package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.classdetails.ClassDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.classdetails.ClassGeneralParametersSection;
import com.atk.himma.pageobjects.contracts.sections.classdetails.PatientDeductibleAndLimitsSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.ClassListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ClassPage extends DriverWaitClass implements StatusMessages,
		RecordStatus, TopControls {
	private ClassListTab classListTab;
	private ClassDetailsFirstSection classDetailsFirstSection;
	private ClassGeneralParametersSection classGeneralParametersSection;
	private PatientDeductibleAndLimitsSection patientDeductibleAndLimitsSection;
	private ExclusionListDetailsSection exclusionListDetailsSection;
	private ApprovalListDetailsSection approvalListDetailsSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[text()= 'Class']";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String CLSDETAILSFORM_ID = "CLASS_DETAILS_FORM";
	public final static String ADDNEWBTN_ID = "ADD_NEW_CLASS_UPPER_BTN";
	public final static String COPYBTN_ID = "COPY_CLASS_UPPER_BTN";
	public final static String SAVEBTN_ID = "CLASS_SAVE_UPPER_BTN";
	public final static String CANCELBTN_ID = "CLASS_CANCEL_UPPER_BTN";
	public final static String UPDATEBTN_ID = "CLASS_UPDATE_UPPER_BTN";
	public final static String GOTOPOLBTN_ID = "GO_TO_POLICY";

	public final static String EXCLISTDETAILSSECTION_ID = "CLASS_EX_SECTION_title";
	public final static String EXCSECTIONDIV_ID = "CLASS_EX_SECTION";
	public final static String APPRVLLISTDETAILSSECTION_ID = "CLASS_APP_SECTION_title";
	public final static String APPRVLSECTIONDIV_ID = "CLASS_APP_SECTION";
	

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = CLSDETAILSFORM_ID)
	private WebElement clsDetailsForm;

	@FindBy(id = ADDNEWBTN_ID)
	private WebElement addNewBtn;

	@FindBy(id = COPYBTN_ID)
	private WebElement copyBtn;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(id = CANCELBTN_ID)
	private WebElement cancelBtn;

	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	@FindBy(id = GOTOPOLBTN_ID)
	private WebElement goToPolBtn;

	@FindBy(id = EXCLISTDETAILSSECTION_ID)
	private WebElement excListDetailsSection;

	@FindBy(id = EXCSECTIONDIV_ID)
	private WebElement excSectionDiv;

	@FindBy(id = APPRVLLISTDETAILSSECTION_ID)
	private WebElement apprvlListDetailsSection;

	@FindBy(id = APPRVLSECTIONDIV_ID)
	private WebElement apprvlSectionDiv;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		classListTab = PageFactory.initElements(webDriver, ClassListTab.class);
		classListTab.setWebDriver(webDriver);
		classListTab.setWebDriverWait(webDriverWait);

		classDetailsFirstSection = PageFactory.initElements(webDriver,
				ClassDetailsFirstSection.class);
		classDetailsFirstSection.setWebDriver(webDriver);
		classDetailsFirstSection.setWebDriverWait(webDriverWait);

		classGeneralParametersSection = PageFactory.initElements(webDriver,
				ClassGeneralParametersSection.class);
		classGeneralParametersSection.setWebDriver(webDriver);
		classGeneralParametersSection.setWebDriverWait(webDriverWait);

		patientDeductibleAndLimitsSection = PageFactory.initElements(webDriver,
				PatientDeductibleAndLimitsSection.class);
		patientDeductibleAndLimitsSection.setWebDriver(webDriver);
		patientDeductibleAndLimitsSection.setWebDriverWait(webDriverWait);

		exclusionListDetailsSection = PageFactory.initElements(webDriver,
				ExclusionListDetailsSection.class);
		exclusionListDetailsSection.setWebDriver(webDriver);
		exclusionListDetailsSection.setWebDriverWait(webDriverWait);

		approvalListDetailsSection = PageFactory.initElements(webDriver,
				ApprovalListDetailsSection.class);
		approvalListDetailsSection.setWebDriver(webDriver);
		approvalListDetailsSection.setWebDriverWait(webDriverWait);

	}

	public ClassPage clickOnClassMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "Class");
		ClassPage classPage = PageFactory.initElements(webDriver,
				ClassPage.class);
		classPage.setWebDriver(webDriver);
		classPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return classPage;
	}

	public void collapseExpandExcSection() throws Exception {
		waitForElementId(EXCLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getExcListDetailsSection().getAttribute(
				"class"))) {
			excListDetailsSection.click();
			sleepMedium();
			waitForElementId(EXCSECTIONDIV_ID);
		}

	}

	public void collapseExpandApprvlSection() throws Exception {
		waitForElementId(APPRVLSECTIONDIV_ID);
		sleepShort();
		if ("CollapseExpand".equals(getApprvlListDetailsSection().getAttribute(
				"class"))) {
			apprvlListDetailsSection.click();
			sleepMedium();
			waitForElementId(APPRVLSECTIONDIV_ID);
		}

	}

	public void saveClass() throws Exception {
		saveBtn.click();
		sleepVeryShort();
		waitForElementId(UPDATEBTN_ID);
		sleepShort();
	}

	public String activateRecord() throws Exception {
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickOnGoToPolicyBtn() throws Exception {
		waitForElementId(GOTOPOLBTN_ID);
		sleepVeryShort();
		goToPolBtn.click();
		doDirtyPopUpCheck();
	}

	public boolean verifyPolicyAssociatedClasses(String[] classListData)
			throws Exception {
		PolicyPage policyPage = PageFactory.initElements(webDriver,
				PolicyPage.class);
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		policyPage.initPages(webDriver, webDriverWait);
		return policyPage.getAssociatedClassesSection().checkAssociatedClsData(
				classListData);

	}

	public void collapseExpandPolicyExcSection() throws Exception {
		PolicyPage policyPage = PageFactory.initElements(webDriver,
				PolicyPage.class);
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		policyPage.initPages(webDriver, webDriverWait);
		policyPage.collapseExpandExcSection();

	}

	public void collapseExpandPolicyApprvlSection() throws Exception {
		PolicyPage policyPage = PageFactory.initElements(webDriver,
				PolicyPage.class);
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		policyPage.initPages(webDriver, webDriverWait);
		policyPage.collapseExpandApprvlSection();
	}

	public void updatePolicyDetails() throws Exception {
		PolicyPage policyPage = PageFactory.initElements(webDriver,
				PolicyPage.class);
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		policyPage.getUpdateBtn().click();
		doDirtyPopUpCheck();
		sleepShort();
		waitForPageLoaded(webDriver);
	}

	public ClassListTab getClassListTab() {
		return classListTab;
	}

	public ClassDetailsFirstSection getClassDetailsFirstSection() {
		return classDetailsFirstSection;
	}

	public ClassGeneralParametersSection getClassGeneralParametersSection() {
		return classGeneralParametersSection;
	}

	public PatientDeductibleAndLimitsSection getPatientDeductibleAndLimitsSection() {
		return patientDeductibleAndLimitsSection;
	}

	public ExclusionListDetailsSection getExclusionListDetailsSection() {
		return exclusionListDetailsSection;
	}

	public ApprovalListDetailsSection getApprovalListDetailsSection() {
		return approvalListDetailsSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getClsDetailsForm() {
		return clsDetailsForm;
	}

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getGoToPolBtn() {
		return goToPolBtn;
	}

	public WebElement getExcListDetailsSection() {
		return excListDetailsSection;
	}

	public WebElement getExcSectionDiv() {
		return excSectionDiv;
	}

	public WebElement getApprvlListDetailsSection() {
		return apprvlListDetailsSection;
	}

	public WebElement getApprvlSectionDiv() {
		return apprvlSectionDiv;
	}

	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

}
