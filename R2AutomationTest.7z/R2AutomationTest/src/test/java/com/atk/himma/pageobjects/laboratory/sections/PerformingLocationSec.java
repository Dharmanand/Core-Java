package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PerformingLocationSec extends DriverWaitClass {
	public final static String PERFORMINGLOCSEC_XPATH = "//a[text()='Performing Location']";
	@FindBy(xpath = PERFORMINGLOCSEC_XPATH)
	private WebElement performingLocSec;

	public final static String PERFORMINGLOCADDROWBTN_ID = "PERFORMING_LOCATION_ADD_ROW_ID";
	@FindBy(id = PERFORMINGLOCADDROWBTN_ID)
	private WebElement performingLocAddRowBtn;

	public final static String PERFORMINGLOCGRIDTBL_ID = "LAB_TEST_PERFOMING_LOCATION_GRID";
	@FindBy(id = PERFORMINGLOCGRIDTBL_ID)
	private WebElement performingLocGridTbl;

	public final static String LOCLOOKUP_XPATH = "//a[@name='locationName']";
	@FindBy(xpath = LOCLOOKUP_XPATH)
	private WebElement loclookUp;

	public final static String VISITCATEGORY_XPATH = "//td[@aria-describedby='LAB_TEST_PERFOMING_LOCATION_GRID_visitCategory']//button[@class='ui-multiselect ui-state-default']";
	@FindBy(xpath = VISITCATEGORY_XPATH)
	private WebElement visitCategory;

	public final static String DAYS_XPATH = "//td[@aria-describedby='LAB_TEST_PERFOMING_LOCATION_GRID_days']//button[@class='ui-multiselect ui-state-default']";
	@FindBy(xpath = DAYS_XPATH)
	private WebElement days;

	public final static String FROMTIME_NAME = "fromTime";
	@FindBy(name = FROMTIME_NAME)
	private WebElement fromTime;

	public final static String TOTIME_NAME = "toTime";
	@FindBy(name = TOTIME_NAME)
	private WebElement toTime;

	public WebElement getPerformingLocSec() {
		return performingLocSec;
	}

	public WebElement getPerformingLocAddRowBtn() {
		return performingLocAddRowBtn;
	}

	public WebElement getPerformingLocGridTbl() {
		return performingLocGridTbl;
	}

	public WebElement getLoclookUp() {
		return loclookUp;
	}

	public WebElement getVisitCategory() {
		return visitCategory;
	}

	public WebElement getDays() {
		return days;
	}

	public WebElement getFromTime() {
		return fromTime;
	}

	public WebElement getToTime() {
		return toTime;
	}

}
