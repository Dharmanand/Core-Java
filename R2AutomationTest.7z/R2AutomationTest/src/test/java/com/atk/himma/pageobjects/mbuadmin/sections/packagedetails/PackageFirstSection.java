package com.atk.himma.pageobjects.mbuadmin.sections.packagedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PackageFirstSection extends DriverWaitClass{
	
	public final static String SERVICECODE_NAME = "packageInfo.serviceInfo.serviceCode";
	public final static String SHORTNAME_NAME = "packageInfo.serviceInfo.shortName";
	public final static String SPECIALTY_XPATH = "//label[@id='packagesDetails_packageSpeciality']/..//input";
	public final static String SERVICENAME_NAME = "packageInfo.serviceInfo.serviceName";
	public final static String DEPARTMENT_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div/div[2]/div[13]/div/form/div/div[2]/span[2]/input";
	public final static String PKGTYPE_ID = "PACKAGE_TYPE_DD";
	
	@FindBy(name = SERVICECODE_NAME)
	private WebElement serviceCode;
	
	@FindBy(name = SHORTNAME_NAME)
	private WebElement shortName;
	
	@FindBy(xpath = SPECIALTY_XPATH)
	private WebElement specialty;
	
	@FindBy(name = SERVICENAME_NAME)
	private WebElement serviceName;
	
	@FindBy(xpath = DEPARTMENT_XPATH)
	private WebElement department;
	
	@FindBy(id = PKGTYPE_ID)
	private WebElement packageType;

	
// 	Please enter no more than 50 characters.
	public boolean isMandatoryPkgType() throws Exception {
		waitForElementId(PKGTYPE_ID);
		return isMandatoryField(packageType);
	}

	public boolean fillDatas(String[] pkgDatas) throws InterruptedException
			  {
		waitForElementId(PKGTYPE_ID);
		sleepShort();
		new Select(packageType).selectByVisibleText(pkgDatas[7].trim());
		return new Select(packageType).getFirstSelectedOption().getText().trim().equals(pkgDatas[7].trim());
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the shortName
	 */
	public WebElement getShortName() {
		return shortName;
	}

	/**
	 * @return the specialty
	 */
	public WebElement getSpecialty() {
		return specialty;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the packageType
	 */
	public WebElement getPackageType() {
		return packageType;
	}
	
	
	
}
