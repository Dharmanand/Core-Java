package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class BusinessTimings extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Business Timings";

	public final static String WEEKSTARTDAY_ID = "WEEK_START_DAY";
	public final static String WEEKENDDAY_ID = "WEEK_END_DAY";
	public final static String STARTTIME_ID = "BUSINESS_START_TIME";
	public final static String ENDTIME_ID = "BUSINESS_END_TIME";

	public final static String OPDSTARTTIME_ID = "OPD_START_TIME";
	public final static String OPDENDTIME_ID = "OPD_END_TIME";
	public final static String EMERSTARTTIME_ID = "BUSINESS_EMR_START_TIME";
	public final static String EMERENDTIME_ID = "BUSINESS_EMR_END_TIME";

	public final static String ADDSESSBUTTON_XPATH = "//td[@id='sessionGrid_pager_left']//div[@class='ui-pg-div']/span";
	public final static String SESSIONTB_ID = "POP_UP_SESSION_NAME";
	public final static String STARTTIMETB_ID = "START_TIME";
	public final static String ENDTIMETB_ID = "END_TIME";

	public final static String SUBMITBUTTON_XPATH = "//form[@id='SESSION_FORM']//span[@class='buttoncontainer_sml']//input[@value='Submit']";
	public final static String CANCELBUTTON_XPATH = "//form[@id='SESSION_FORM']//span[@class='buttoncontainer_sml']//input[@value='Cancel']";

	public final static String GRID_ID = "sessionGrid";
	public final static String GRID_SESSION_ARIA_DESCRIBEDBY = "sessionGrid_sessionText";
	public final static String GRID_STARTTIME_ARIA_DESCRIBEDBY = "sessionGrid_startTime";
	public final static String GRID_ENDTIME_ARIA_DESCRIBEDBY = "sessionGrid_endTime";
	public final static String GRID_PAGERID = "sp_1_sessionGrid_pager";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Business Timings')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = WEEKSTARTDAY_ID)
	private WebElement weekStartDay;

	@FindBy(id = WEEKENDDAY_ID)
	private WebElement weekEndDay;

	@FindBy(id = STARTTIME_ID)
	private WebElement startTime;

	@FindBy(id = ENDTIME_ID)
	private WebElement endTime;

	@FindBy(id = OPDSTARTTIME_ID)
	private WebElement opdStartTime;

	@FindBy(id = OPDENDTIME_ID)
	private WebElement opdEndTime;

	@FindBy(id = EMERSTARTTIME_ID)
	private WebElement emerStartTime;

	@FindBy(xpath = SUBMITBUTTON_XPATH)
	private WebElement submitButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(xpath = ADDSESSBUTTON_XPATH)
	private WebElement addSessionButton;

	@FindBy(id = SESSIONTB_ID)
	private WebElement sessionTBL;

	@FindBy(id = STARTTIMETB_ID)
	private WebElement startTimeTBL;

	@FindBy(id = ENDTIMETB_ID)
	private WebElement endTimeTBL;

	@FindBy(id = EMERENDTIME_ID)
	private WebElement emerEndTime;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	// public void fillDatasOfOtherlDetailsSection(String[] excelData,
	// WebDriverWait webDriverWait) throws InterruptedException {
	// if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
	// "class").trim()))
	// getSectionName().click();
	// webDriverWait.until(ExpectedConditions.visibilityOf(sessionTBL));
	// new Select(sessionTBL)
	// getSponsorName().sendKeys(excelData[88].trim());
	// getAddress().clear();
	// getAddress().sendKeys(excelData[89].trim());
	// new Select(getPhoneCode()).selectByVisibleText(excelData[90].trim());
	// getPhoneNumber().clear();
	// getPhoneNumber().sendKeys(excelData[91].trim());
	// }

	public boolean checkBusTimSection() throws InterruptedException {
		waitForElementLinkText(GeneralDetails.SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatasMBUTimings(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(BusinessTimings.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		new Select(weekStartDay).selectByVisibleText(mbuDatas[26]);
		new Select(weekEndDay).selectByVisibleText(mbuDatas[27]);
		startTime.clear();
		startTime.sendKeys(mbuDatas[28]);
		endTime.clear();
		endTime.sendKeys(mbuDatas[29]);
		return endTime.getAttribute("value").trim().equals(mbuDatas[29]);
	}

	public boolean fillDatasOtherTimings(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(BusinessTimings.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();

		opdStartTime.clear();
		opdStartTime.sendKeys(mbuDatas[30]);

		opdEndTime.clear();
		opdEndTime.sendKeys(mbuDatas[31]);

		emerStartTime.clear();
		emerStartTime.sendKeys(mbuDatas[32]);

		emerEndTime.clear();
		emerEndTime.sendKeys(mbuDatas[33]);

		addSessionButton.click();
		waitForElementId(SESSIONTB_ID);
		return emerEndTime.getAttribute("value").trim().equals(mbuDatas[33]);
	}

	public boolean fillDatasDailySession(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(BusinessTimings.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();

		String[] sessions = mbuDatas[34].split("\\,");
		String[] stTimes = mbuDatas[35].split("\\,");
		String[] edTimes = mbuDatas[36].split("\\,");

		waitForElementId(SESSIONTB_ID);
		new Select(sessionTBL).selectByVisibleText(sessions[0].trim());
		startTimeTBL.clear();
		startTimeTBL.sendKeys(stTimes[0].trim());
		endTimeTBL.clear();
		endTimeTBL.sendKeys(edTimes[0].trim());
		submitButton.click();
		sleepShort();

		addSessionButton.click();
		waitForElementId(SESSIONTB_ID);
		new Select(sessionTBL).selectByVisibleText(sessions[1].trim());
		startTimeTBL.clear();
		startTimeTBL.sendKeys(stTimes[1].trim());
		endTimeTBL.clear();
		endTimeTBL.sendKeys(edTimes[1].trim());
		submitButton.click();
		sleepShort();

		addSessionButton.click();
		waitForElementId(SESSIONTB_ID);
		new Select(sessionTBL).selectByVisibleText(sessions[2].trim());
		startTimeTBL.clear();
		startTimeTBL.sendKeys(stTimes[2].trim());
		endTimeTBL.clear();
		endTimeTBL.sendKeys(edTimes[2].trim());
		submitButton.click();
		sleepShort();

		return checkGridEmpty(GRID_ID, GRID_PAGERID);
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the weekStartDay
	 */
	public WebElement getWeekStartDay() {
		return weekStartDay;
	}

	/**
	 * @return the weekEndDay
	 */
	public WebElement getWeekEndDay() {
		return weekEndDay;
	}

	/**
	 * @return the startTime
	 */
	public WebElement getStartTime() {
		return startTime;
	}

	/**
	 * @return the endTime
	 */
	public WebElement getEndTime() {
		return endTime;
	}

	/**
	 * @return the opdStartTime
	 */
	public WebElement getOpdStartTime() {
		return opdStartTime;
	}

	/**
	 * @return the opdEndTime
	 */
	public WebElement getOpdEndTime() {
		return opdEndTime;
	}

	/**
	 * @return the emerStartTime
	 */
	public WebElement getEmerStartTime() {
		return emerStartTime;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the addSessionButton
	 */
	public WebElement getAddSessionButton() {
		return addSessionButton;
	}

	/**
	 * @return the sessionTab
	 */
	public WebElement getSessionTBL() {
		return sessionTBL;
	}

	/**
	 * @return the startTimeTB
	 */
	public WebElement getStartTimeTBL() {
		return startTimeTBL;
	}

	/**
	 * @return the endTimeTB
	 */
	public WebElement getEndTimeTBL() {
		return endTimeTBL;
	}

	/**
	 * @return the emerEndTime
	 */
	public WebElement getEmerEndTime() {
		return emerEndTime;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
