package com.atk.himma.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.PrivilegeGroupsPage;
import com.atk.himma.pageobjects.sa.tabs.PrivilegeGroupListTab;
import com.atk.himma.setup.SeleniumDriverSetup;

public class PrivilegesDataExecutor {

	public static Map<String, Map<String, Boolean>> formPrivileges;
	public static Map<String, Map<String, Map<String, Boolean>>> allModCollecPrivileges;

	public static List<String> readPrivileges(List<String[]> editPrivGrpList,
			PrivilegeGroupsPage privilegeGroupsPage) throws Exception {
		ExcelReader excelReader = new ExcelReader();
		excelReader.setInputFile(SeleniumDriverSetup.properties.getProperty("loginExcel"));
		List<String[]> loginDatas = excelReader.read(SeleniumDriverSetup.properties.getProperty("loginSheetName"));
		excelReader.setInputFile(SeleniumDriverSetup.properties.getProperty("SAExcel"));
		editPrivGrpList = excelReader.read(SeleniumDriverSetup.properties.getProperty("applicationUser"));
		String primPosition = null;
		for (String[] st : editPrivGrpList) {
			if (loginDatas.get(7)[0].equals(st[37].trim())) {
				primPosition = st[19].trim();
				break;
			}
		}
		String role = null;
		editPrivGrpList = excelReader.read(SeleniumDriverSetup.properties.getProperty("otherUsersPositions"));
		for (String[] st : editPrivGrpList) {
			if (primPosition.equals(st[0].trim())) {
				role = st[4].trim();
				break;
			}
		}
		editPrivGrpList = excelReader.read(SeleniumDriverSetup.properties.getProperty("otherUsersJobs"));
		List<String> privGrpNames = new ArrayList<String>();
		boolean flag = false;
		for (String[] st : editPrivGrpList) {
			if (role.equals(st[0].trim())) {
				flag = true;
				privGrpNames.add(st[3].trim());
			} else if (flag && st[0].trim().isEmpty()) {
				privGrpNames.add(st[3].trim());
			} else if (flag && !st[0].trim().isEmpty()) {
				break;
			}
		}
		return privGrpNames;
	}

	public static boolean chekFullPrivileges(
			PrivilegeGroupsPage privilegeGroupsPage) throws Exception {
		allModCollecPrivileges = new HashMap<String, Map<String, Map<String, Boolean>>>();
		boolean flag = false, privFlag = true;
		ExcelReader excelReader = new ExcelReader();
		excelReader.setInputFile(SeleniumDriverSetup.properties.getProperty("SAExcel"));
		List<String[]> editPrivGrpList = excelReader
				.read(SeleniumDriverSetup.properties.getProperty("privilegesForUserpr"));
		List<String> privGrpNames = PrivilegesDataExecutor.readPrivileges(
				editPrivGrpList, privilegeGroupsPage);
		flag = false;
		List<String> privNames = null, formNames = null;
		String moduleName = null;
		int j = 0;
		for (String pn : privGrpNames) {
			privNames = new ArrayList<String>();
			formNames = new ArrayList<String>();
			// for all form of each privileges
			int i = 0;
			for (String[] st : editPrivGrpList.subList(j,
					editPrivGrpList.size())) {
				j++;
				formNames.add(st[2].trim());
				if (i > 0 && !st[1].trim().isEmpty()) {
					privFlag = privFlag
							&& privilegeGroupsPage
									.getPrivilegeGroupInformationTab()
									.setPrivilegeForCheck(privNames,
											moduleName, formNames);
					j = j - 1;
					privilegeGroupsPage.getPrivGrpsListTab().click();
					privilegeGroupsPage
							.waitForElementId(PrivilegeGroupListTab.GRID_ID);
					privilegeGroupsPage.sleepVeryShort();
					break;
				}
				if (pn.equals(st[1].trim())) {
					flag = true;
					privilegeGroupsPage.getPrivilegeGroupListTab()
							.searchPrivilegeGroup(pn);
					privilegeGroupsPage.getPrivilegeGroupListTab().clickOnEdit(
							pn);
					privNames.add(st[3].trim());
					moduleName = st[0].trim();
					i++;
				} else if (flag && st[1].trim().isEmpty()) {
					privNames.add(st[3].trim());
				}
			}
		}
		return privFlag = privFlag
				&& privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.setPrivilegeForCheck(privNames, moduleName, formNames);
	}

	public static boolean chekMenuPrivileges(
			PrivilegeGroupsPage privilegeGroupsPage) throws Exception {
		allModCollecPrivileges = new HashMap<String, Map<String, Map<String, Boolean>>>();
		boolean flag = false, privFlag = true;
		ExcelReader excelReader = new ExcelReader();
		excelReader.setInputFile(SeleniumDriverSetup.properties.getProperty("SAExcel"));
		List<String[]> editPrivGrpList = excelReader
				.read(SeleniumDriverSetup.properties.getProperty("privilegesForUserpr"));
		List<String> privGrpNames = PrivilegesDataExecutor.readPrivileges(
				editPrivGrpList, privilegeGroupsPage);
		flag = false;
		List<String> privNames = null, formNames = null;
		String moduleName = null;
		int j = 0;
		for (String pn : privGrpNames) {
			privNames = new ArrayList<String>();
			formNames = new ArrayList<String>();
			// for all form of each privileges
			int i = 0;
			for (String[] st : editPrivGrpList.subList(j,
					editPrivGrpList.size())) {
				j++;
				formNames.add(st[2].trim());
				if (i > 0 && !st[1].trim().isEmpty()) {
					privFlag = privFlag
							&& privilegeGroupsPage
									.getPrivilegeGroupInformationTab()
									.setMenuPrivilegeForCheck(privNames,
											moduleName, formNames);
					j = j - 1;
					privilegeGroupsPage.getPrivGrpsListTab().click();
					privilegeGroupsPage
							.waitForElementId(PrivilegeGroupListTab.GRID_ID);
					privilegeGroupsPage.sleepVeryShort();
					break;
				}
				if (pn.equals(st[1].trim())) {
					flag = true;
					privilegeGroupsPage.getPrivilegeGroupListTab()
							.searchPrivilegeGroup(pn);
					privilegeGroupsPage.getPrivilegeGroupListTab().clickOnEdit(
							pn);
					privNames.add(st[3].trim());
					moduleName = st[0].trim();
					i++;
				} else if (flag && st[1].trim().isEmpty()) {
					privNames.add(st[3].trim());
				}
			}
		}
		return privFlag = privFlag
				&& privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.setMenuPrivilegeForCheck(privNames, moduleName,
								formNames);
	}

	public static boolean testPrivilege(WebDriver webDriver, By locator) {
		try {
			new WebDriverWait(webDriver, 1).until(ExpectedConditions
					.presenceOfElementLocated(locator));
			if (webDriver.findElement(locator).isDisplayed()) {
				System.out
						.println("-------------From Try block if------------");
				return true;
			} else {
				System.out
						.println("-------------From Try block else------------");
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}
}
