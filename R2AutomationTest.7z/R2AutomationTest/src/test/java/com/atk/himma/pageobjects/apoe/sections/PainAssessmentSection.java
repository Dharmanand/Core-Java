package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PainAssessmentSection extends DriverWaitClass {
	public final static String ONSETPAIN_NAME = "consultationSummary.newReason.onsetPain";
	@FindBy(name = ONSETPAIN_NAME)
	private WebElement onSetPain;

	public final static String SEVERITYOFPAIN_NAME = "consultationSummary.newReason.severityPainId";
	@FindBy(name = SEVERITYOFPAIN_NAME)
	private WebElement severityOfPain;

	public final static String LOCATIONOFPAIN_NAME = "consultationSummary.newReason.locationPainId";
	@FindBy(name = LOCATIONOFPAIN_NAME)
	private WebElement locationOfPain;

	public final static String DURATIONOFPAIN_NAME = "consultationSummary.newReason.durationPain";
	@FindBy(name = DURATIONOFPAIN_NAME)
	private WebElement durationOfPain;

	public final static String PAINLOCANOTES_NAME = "consultationSummary.newReason.locationNotes";
	@FindBy(name = PAINLOCANOTES_NAME)
	private WebElement painLocationNotes;

	public final static String PAINDURNOTES_NAME = "consultationSummary.newReason.durationNotes";
	@FindBy(name = PAINDURNOTES_NAME)
	private WebElement painDurationNotes;

	public final static String QLTYOFPAIN_NAME = "consultationSummary.newReason.qualityPainId";
	@FindBy(name = QLTYOFPAIN_NAME)
	private WebElement qualityOfPain;

	public final static String RADIATIONOFPAIN_NAME = "consultationSummary.newReason.radiationPain";
	@FindBy(name = RADIATIONOFPAIN_NAME)
	private WebElement radiationOfPain;

	public final static String QLTYOFPAINNOTES_NAME = "consultationSummary.newReason.qualityNotes";
	@FindBy(name = QLTYOFPAINNOTES_NAME)
	private WebElement qualityOfPainNotes;

	public final static String RELIEVAGGRVTFACTORS_NAME = "consultationSummary.newReason.relievingAggravatingFactors";
	@FindBy(name = RELIEVAGGRVTFACTORS_NAME)
	private WebElement relieveAggrvtFactors;

	public final static String DAILYPAINAFFECTS_NAME = "consultationSummary.newReason.dailyPainAffects";
	@FindBy(name = DAILYPAINAFFECTS_NAME)
	private WebElement dailyPainAffects;
	
	public void fillPainAssessmentSec(String[] outPatientListData) {
		onSetPain.clear();
		onSetPain.sendKeys(outPatientListData[25]);
		if (!outPatientListData[26].isEmpty()) {
			new Select(severityOfPain)
					.selectByVisibleText(outPatientListData[26]);
		}
		if (!outPatientListData[27].isEmpty()) {
			new Select(locationOfPain)
					.selectByVisibleText(outPatientListData[27]);
		}
		painLocationNotes.clear();
		painLocationNotes.sendKeys(outPatientListData[28]);
		durationOfPain.clear();
		durationOfPain.sendKeys(outPatientListData[29]);
		painDurationNotes.clear();
		painDurationNotes.sendKeys(outPatientListData[30]);
		if (!outPatientListData[31].isEmpty()) {
			new Select(qualityOfPain)
					.selectByVisibleText(outPatientListData[31]);
		}
		qualityOfPainNotes.clear();
		qualityOfPainNotes.sendKeys(outPatientListData[32]);
		radiationOfPain.clear();
		radiationOfPain.sendKeys(outPatientListData[33]);
		relieveAggrvtFactors.clear();
		relieveAggrvtFactors.sendKeys(outPatientListData[34]);
		dailyPainAffects.clear();
		dailyPainAffects.sendKeys(outPatientListData[35]);

	}

	public WebElement getOnSetPain() {
		return onSetPain;
	}

	public WebElement getSeverityOfPain() {
		return severityOfPain;
	}

	public WebElement getLocationOfPain() {
		return locationOfPain;
	}

	public WebElement getDurationOfPain() {
		return durationOfPain;
	}

	public WebElement getPainLocationNotes() {
		return painLocationNotes;
	}

	public WebElement getPainDurationNotes() {
		return painDurationNotes;
	}

	public WebElement getQualityOfPain() {
		return qualityOfPain;
	}

	public WebElement getRadiationOfPain() {
		return radiationOfPain;
	}

	public WebElement getQualityOfPainNotes() {
		return qualityOfPainNotes;
	}

	public WebElement getRelieveAggrvtFactors() {
		return relieveAggrvtFactors;
	}

	public WebElement getDailyPainAffects() {
		return dailyPainAffects;
	}

}
