package com.atk.himma.pageobjects.nursing.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class TriageSection extends DriverWaitClass {
	public final static String HEIGHT_ID = "HEIGHT";
	public final static String WEIGHT_ID = "WEIGHT";
	public final static String TEMPERATURE_ID = "TEMPERATURE";
	public final static String PULSE_ID = "PULSE";
	public final static String BPSYSTOLIC_ID = "BPSYSTONIC";
	public final static String BPDIASTOLIC_ID = "BPDIASTOLIC";
	public final static String RESPIRATORY_ID = "RESPIRATORY";
	public final static String BMI_ID = "BMI";
	public final static String KNOWN_ALLERGIES_ID = "KNOWN_ALLERGIES";
	public final static String TAKENBY_ID = "VITAL_CONSULTANT";
	public final static String DATETIMEIMG_XPATH = "//input[@id='PATIENT_READING_TIME']/../img";
	public final static String ADDVITALSIGNSBTN_ID = "ADD_VITAL_SIGNS";
	public final static String CANCELVITALSIGNSBTN_ID = "CANCEL_VITAL_SIGNS";
	public final static String VITALSIGNSGRIDTBL_ID = "VITAL_SIGNS_GRID";
	public final static String NOWBUTTON_XPATH = "//div[@id='ui-datepicker-div']//button[@class='ui-datepicker-current ui-state-default ui-priority-primary ui-corner-all']";
	public static final String EDITTRIAGELINK_XPATH = ".//table[@id='VITAL_SIGNS_GRID']//../a[text()='Edit']";
	public static final String REMOVETRIAGELINK_XPATH = ".//table[@id='VITAL_SIGNS_GRID']//../a[text()='Remove']";

	@FindBy(xpath = NOWBUTTON_XPATH)
	private WebElement nowButton;

	@FindBy(id = HEIGHT_ID)
	private WebElement height;

	@FindBy(id = WEIGHT_ID)
	private WebElement weight;

	@FindBy(id = TEMPERATURE_ID)
	private WebElement temperature;

	@FindBy(id = PULSE_ID)
	private WebElement pulse;

	@FindBy(id = BPSYSTOLIC_ID)
	private WebElement bpSystolic;

	@FindBy(id = BPDIASTOLIC_ID)
	private WebElement bpDiastolic;

	@FindBy(id = RESPIRATORY_ID)
	private WebElement respiratory;

	@FindBy(id = BMI_ID)
	private WebElement bmi;

	@FindBy(id = KNOWN_ALLERGIES_ID)
	private WebElement knownAllergies;

	@FindBy(id = TAKENBY_ID)
	private WebElement takenBy;

	@FindBy(xpath = DATETIMEIMG_XPATH)
	private WebElement dateTimeIMG;

	@FindBy(id = ADDVITALSIGNSBTN_ID)
	private WebElement addVitalSignsBtn;

	@FindBy(id = CANCELVITALSIGNSBTN_ID)
	private WebElement cancelVitalSignsBtn;

	@FindBy(id = VITALSIGNSGRIDTBL_ID)
	private WebElement vitalSignsGridTbl;

	public void addTriageData(String[] outPatientListData) throws Exception {
		height.clear();
		height.sendKeys(outPatientListData[23]);
		weight.clear();
		weight.sendKeys(outPatientListData[24]);
		temperature.clear();
		temperature.sendKeys(outPatientListData[25]);
		pulse.clear();
		pulse.sendKeys(outPatientListData[26]);
		bpSystolic.clear();
		bpSystolic.sendKeys(outPatientListData[27]);
		bpDiastolic.clear();
		bpDiastolic.sendKeys(outPatientListData[28]);
		respiratory.clear();
		respiratory.sendKeys(outPatientListData[29]);
		bmi.clear();
		bmi.sendKeys(outPatientListData[30]);
		knownAllergies.clear();
		knownAllergies.sendKeys(outPatientListData[31]);
		waitForElementXpathExpression(DATETIMEIMG_XPATH);
		dateTimeIMG.click();
		sleepVeryShort();
		waitForElementXpathExpression(NOWBUTTON_XPATH);
		nowButton.click();
		sleepVeryShort();
		addVitalSignsBtn.click();
		waitForElementId(VITALSIGNSGRIDTBL_ID);
		sleepVeryShort();

	}

	public boolean checkVitalSignsGridData(String[] outPatientListData) {
		waitForElementXpathExpression("//td[@aria-describedby='VITAL_SIGNS_GRID_pulse' and @title='"
				+ outPatientListData[26] + "']");
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='VITAL_SIGNS_GRID_pulse' and @title='"
								+ outPatientListData[26] + "']")).isDisplayed();
	}

	public WebElement getHeight() {
		return height;
	}

	public WebElement getWeight() {
		return weight;
	}

	public WebElement getTemperature() {
		return temperature;
	}

	public WebElement getPulse() {
		return pulse;
	}

	public WebElement getBpSystolic() {
		return bpSystolic;
	}

	public WebElement getBpDiastolic() {
		return bpDiastolic;
	}

	public WebElement getRespiratory() {
		return respiratory;
	}

	public WebElement getBmi() {
		return bmi;
	}

	public WebElement getKnownAllergies() {
		return knownAllergies;
	}

	public WebElement getTakenBy() {
		return takenBy;
	}

	public WebElement getAddVitalSignsBtn() {
		return addVitalSignsBtn;
	}

	public WebElement getCancelVitalSignsBtn() {
		return cancelVitalSignsBtn;
	}

	public WebElement getVitalSignsGridTbl() {
		return vitalSignsGridTbl;
	}

	/**
	 * @return the dateTimeIMG
	 */
	public WebElement getDateTimeIMG() {
		return dateTimeIMG;
	}

	/**
	 * @return the nowButton
	 */
	public WebElement getNowButton() {
		return nowButton;
	}

}
