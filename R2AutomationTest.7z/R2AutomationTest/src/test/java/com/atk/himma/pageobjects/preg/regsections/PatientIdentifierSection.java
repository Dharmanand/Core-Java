package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class PatientIdentifierSection extends DriverWaitClass{
	
	private final static String SECTIONNAME_LINKTEXT = "Patient Identifier";
	
	@FindBy(linkText=SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	private final static String TITLE_NAME = "patiIdentifiDetails.title";
	
	@FindBy(name=TITLE_NAME)
	private WebElement title;
	
	private final static String GIVENNAME_ID = "firstGivenName";
	
	@FindBy(id=GIVENNAME_ID)
	private WebElement givenName;
	
	private final static String FATHERNAME_ID = "fatherName";
	
	@FindBy(id=FATHERNAME_ID)
	private WebElement fatherName;
	
	private final static String GRANDFATHERNAME_ID = "gfatherName";
	
	@FindBy(id=GRANDFATHERNAME_ID)
	private WebElement grandFatherName;
	
	private final static String FAMILYNAME_ID = "familyName";
	
	@FindBy(id=FAMILYNAME_ID)
	private WebElement familyName;
	
	private final static String GIVENNAMEAR_ID = "givenNameAr";
	
	@FindBy(id=GIVENNAMEAR_ID)
	private WebElement givenNameAr;
	
	private final static String FATHERNAMEAR_ID = "fatherNameAr";
	
	@FindBy(id=FATHERNAMEAR_ID)
	private WebElement fatherNameAr;
	
	private final static String GRANDFATHERNAMEAR_ID = "gfatherNameAr";
	
	@FindBy(id=GRANDFATHERNAMEAR_ID)
	private WebElement grandFatherNameAr;
	
	private final static String FAMILYNAMEAR_ID = "familyNameAr";
	
	@FindBy(id=FAMILYNAMEAR_ID)
	private WebElement familyNameAr;
	
	private final static String SUFFIX_NAME = "patiIdentifiDetails.suffix";
	
	@FindBy(name=SUFFIX_NAME)
	private WebElement suffix;
	
	private final static String GENDER_ID = "gender";
	
	@FindBy(id=GENDER_ID)
	private WebElement gender;
	
	private final static String dateOfBirth_ID = "dobDatePick";
	
	@FindBy(id=dateOfBirth_ID)
	private WebElement dateOfBirth;
	
	private final static String NATIONALITY_ID = "patientNationality";
	
	@FindBy(id=NATIONALITY_ID)
	private WebElement nationality;
	
	private final static String PRIMARYMOBILECODE_ID = "PRIMARY_MOB_COUNT_CODE";
	
	@FindBy(id=PRIMARYMOBILECODE_ID)
	private WebElement primaryMobileCode;
	
	private final static String PRIMARYMOBILENUMBER_ID = "PRIMARY_MOB_NUM";
	
	@FindBy(id=PRIMARYMOBILENUMBER_ID)
	private WebElement primaryMobileNumber;
	
	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Patient Identifier')]/..";
	
	@FindBy(xpath=SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	public void fillDatasOfPatientIdentifier(String[] excelData, WebDriverWait webDriverWait) throws InterruptedException {
//		getSectionName().click();
//		sleepVeryShort();
		if(!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute("class").trim()))
			getSectionName().click();
		waitForElementName(TITLE_NAME);
		sleepVeryShort();
		new Select(getTitle()).selectByVisibleText(excelData[3].trim());
		waitForElementId(GENDER_ID);
		new Select(getGender()).selectByVisibleText(excelData[4].trim());
		getGivenName().clear();
		getGivenName().sendKeys(excelData[5].trim());
		getFatherName().clear();
		getFatherName().sendKeys(excelData[6].trim());
		getGrandFatherName().clear();
		getGrandFatherName().sendKeys(excelData[7].trim());
		getFamilyName().clear();
		getFamilyName().sendKeys(excelData[8].trim());
		getGivenNameAr().clear();
		getGivenNameAr().sendKeys(excelData[9].trim());
		getFatherNameAr().clear();
		getFatherNameAr().sendKeys(excelData[10].trim());
		getGrandFatherNameAr().clear();
		getGrandFatherNameAr().sendKeys(excelData[11].trim());
		getFamilyNameAr().clear();
		getFamilyNameAr().sendKeys(excelData[12].trim());
		getDateOfBirth().clear();
		getDateOfBirth().sendKeys(excelData[13].trim());
		new Select(getNationality()).selectByVisibleText(excelData[14].trim());
		new Select(getSuffix()).selectByVisibleText(excelData[15].trim());
		new Select(getPrimaryMobileCode()).selectByVisibleText(excelData[16].trim());
		getPrimaryMobileNumber().clear();
		getPrimaryMobileNumber().sendKeys(excelData[17].trim());
	}
	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}
	/**
	 * @return the title
	 */
	public WebElement getTitle() {
		return title;
	}
	/**
	 * @return the givenName
	 */
	public WebElement getGivenName() {
		return givenName;
	}
	/**
	 * @return the fatherName
	 */
	public WebElement getFatherName() {
		return fatherName;
	}
	/**
	 * @return the grandFatherName
	 */
	public WebElement getGrandFatherName() {
		return grandFatherName;
	}
	/**
	 * @return the familyName
	 */
	public WebElement getFamilyName() {
		return familyName;
	}
	/**
	 * @return the givenNameAr
	 */
	public WebElement getGivenNameAr() {
		return givenNameAr;
	}
	/**
	 * @return the fatherNameAr
	 */
	public WebElement getFatherNameAr() {
		return fatherNameAr;
	}
	/**
	 * @return the grandFatherNameAr
	 */
	public WebElement getGrandFatherNameAr() {
		return grandFatherNameAr;
	}
	/**
	 * @return the familyNameAr
	 */
	public WebElement getFamilyNameAr() {
		return familyNameAr;
	}
	/**
	 * @return the suffix
	 */
	public WebElement getSuffix() {
		return suffix;
	}
	/**
	 * @return the gender
	 */
	public WebElement getGender() {
		return gender;
	}
	/**
	 * @return the dateOfBirth
	 */
	public WebElement getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @return the nationality
	 */
	public WebElement getNationality() {
		return nationality;
	}
	/**
	 * @return the primaryMobileCode
	 */
	public WebElement getPrimaryMobileCode() {
		return primaryMobileCode;
	}
	/**
	 * @return the primaryMobileNumber
	 */
	public WebElement getPrimaryMobileNumber() {
		return primaryMobileNumber;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the titleName
	 */
	public static String getTitleName() {
		return TITLE_NAME;
	}

	/**
	 * @return the givennameId
	 */
	public static String getGivennameId() {
		return GIVENNAME_ID;
	}

	/**
	 * @return the fathernameId
	 */
	public static String getFathernameId() {
		return FATHERNAME_ID;
	}

	/**
	 * @return the grandfathernameId
	 */
	public static String getGrandfathernameId() {
		return GRANDFATHERNAME_ID;
	}

	/**
	 * @return the familynameId
	 */
	public static String getFamilynameId() {
		return FAMILYNAME_ID;
	}

	/**
	 * @return the givennamearId
	 */
	public static String getGivennamearId() {
		return GIVENNAMEAR_ID;
	}

	/**
	 * @return the fathernamearId
	 */
	public static String getFathernamearId() {
		return FATHERNAMEAR_ID;
	}

	/**
	 * @return the grandfathernamearId
	 */
	public static String getGrandfathernamearId() {
		return GRANDFATHERNAMEAR_ID;
	}

	/**
	 * @return the familynamearId
	 */
	public static String getFamilynamearId() {
		return FAMILYNAMEAR_ID;
	}

	/**
	 * @return the suffixName
	 */
	public static String getSuffixName() {
		return SUFFIX_NAME;
	}

	/**
	 * @return the genderId
	 */
	public static String getGenderId() {
		return GENDER_ID;
	}

	/**
	 * @return the dateofbirthId
	 */
	public static String getDateofbirthId() {
		return dateOfBirth_ID;
	}

	/**
	 * @return the nationalityId
	 */
	public static String getNationalityId() {
		return NATIONALITY_ID;
	}

	/**
	 * @return the primarymobilecodeId
	 */
	public static String getPrimarymobilecodeId() {
		return PRIMARYMOBILECODE_ID;
	}

	/**
	 * @return the primarymobilenumberId
	 */
	public static String getPrimarymobilenumberId() {
		return PRIMARYMOBILENUMBER_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
