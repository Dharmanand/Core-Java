package com.atk.himma.pageobjects.laboratory.masters;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.laboratory.masters.tabs.InstructionDetailsTabPage;
import com.atk.himma.pageobjects.laboratory.masters.tabs.InstructionListTabPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class InstructionPage extends DriverWaitClass {
	private InstructionListTabPage instructionListTabPage;
	private InstructionDetailsTabPage instructionDetailsTabPage;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String INSTRLISTTAB_XPATH = "//a[@title='Instruction List']";
	@FindBy(xpath = INSTRLISTTAB_XPATH)
	private WebElement instructionListTab;

	public final static String INSTRDTLTAB_XPATH = "//a[@title='Instruction Details']";
	@FindBy(xpath = INSTRDTLTAB_XPATH)
	private WebElement instructionDetailsTab;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		instructionListTabPage = PageFactory.initElements(webDriver,
				InstructionListTabPage.class);
		instructionListTabPage.setWebDriver(webDriver);
		instructionListTabPage.setWebDriverWait(webDriverWait);

		instructionDetailsTabPage = PageFactory.initElements(webDriver,
				InstructionDetailsTabPage.class);
		instructionDetailsTabPage.setWebDriver(webDriver);
		instructionDetailsTabPage.setWebDriverWait(webDriverWait);

	}

	public InstructionPage clickOnOrganismMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> instrMenuList = new LinkedList<String>();
		instrMenuList.add("Laboratory");
		instrMenuList.add("Masters ");
		menuSelector.clickOnTargetMenu(instrMenuList, "Instruction");
		InstructionPage instructionPage = PageFactory.initElements(webDriver,
				InstructionPage.class);
		instructionPage.setWebDriver(webDriver);
		instructionPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return instructionPage;

	}

	public InstructionListTabPage getInstructionListTabPage() {
		return instructionListTabPage;
	}

	public InstructionDetailsTabPage getInstructionDetailsTabPage() {
		return instructionDetailsTabPage;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getInstructionListTab() {
		return instructionListTab;
	}

	public WebElement getInstructionDetailsTab() {
		return instructionDetailsTab;
	}

}
