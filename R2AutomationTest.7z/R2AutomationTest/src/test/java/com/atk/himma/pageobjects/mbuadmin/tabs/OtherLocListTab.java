package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class OtherLocListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "OTHER_LOCATION_LIST";
	public final static String EXPORTTOEXCEL_ID = "otherLocationResults_export_btn";
	public final static String OTHERLOCLISTTAB_XPATH = "//a[@title='Other Location List']";
	public final static String ADDNEWOTHERLOCBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Add New Other Location']";
	public final static String MBUNAME_ID = "MBU_LIST_TAB1";
	public final static String DEPARTMENT_ID = "DEPARTMENT_LIST_TAB1";
	public final static String LOCATIONNAME_ID = "LOC_NAME_TAB1";
	public final static String LOCATIONCODE_ID = "LOC_CODE_TAB1";
	public final static String LOCATIONCATEGORY_ID = "LOC_CATEGORY_LIST_TAB1";
	public final static String STATUS_ID = "STATUS_LIST_TAB1";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "otherLocationResults";
	public final static String GRID_LOCCODE_ARIA_DESCRIBEDBY = "otherLocationResults_locationCode";
	public final static String GRID_LOCNAME_ARIA_DESCRIBEDBY = "otherLocationResults_locationName";
	public final static String GRID_LOCCATEGORY_ARIA_DESCRIBEDBY = "otherLocationResults_categoryText";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "otherLocationResults_mbuText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "otherLocationResults_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_otherLocationResults_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_otherLocationResults_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = EXPORTTOEXCEL_ID)
	private WebElement exportToExcel;

	@FindBy(xpath = OTHERLOCLISTTAB_XPATH)
	private WebElement otherLocListTab;
	
	@FindBy(xpath = ADDNEWOTHERLOCBUTTON_XPATH)
	private WebElement addNewOtherLocButton;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = LOCATIONNAME_ID)
	private WebElement locationName;
	
	@FindBy(id = LOCATIONCODE_ID)
	private WebElement locationCode;
	
	@FindBy(id = LOCATIONCATEGORY_ID)
	private WebElement locationCategory;
	
	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the formId
	 */
	public static String getFormId() {
		return FORM_ID;
	}

	/**
	 * @return the addnewotherlocbuttonXpath
	 */
	public static String getAddnewotherlocbuttonXpath() {
		return ADDNEWOTHERLOCBUTTON_XPATH;
	}

	/**
	 * @return the departmentId
	 */
	public static String getDepartmentId() {
		return DEPARTMENT_ID;
	}

	/**
	 * @return the gridId
	 */
	public static String getGridId() {
		return GRID_ID;
	}

	/**
	 * @return the gridLoccodeAriaDescribedby
	 */
	public static String getGridLoccodeAriaDescribedby() {
		return GRID_LOCCODE_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridLoccategoryAriaDescribedby
	 */
	public static String getGridLoccategoryAriaDescribedby() {
		return GRID_LOCCATEGORY_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the otherLocListTab
	 */
	public WebElement getOtherLocListTab() {
		return otherLocListTab;
	}

	/**
	 * @return the addNewOtherLocButton
	 */
	public WebElement getAddNewOtherLocButton() {
		return addNewOtherLocButton;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the locationName
	 */
	public WebElement getLocationName() {
		return locationName;
	}

	/**
	 * @return the locationCode
	 */
	public WebElement getLocationCode() {
		return locationCode;
	}

	/**
	 * @return the locationCategory
	 */
	public WebElement getLocationCategory() {
		return locationCategory;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	/**
	 * @return the exportToExcel
	 */
	public WebElement getExportToExcel() {
		return exportToExcel;
	}

}
