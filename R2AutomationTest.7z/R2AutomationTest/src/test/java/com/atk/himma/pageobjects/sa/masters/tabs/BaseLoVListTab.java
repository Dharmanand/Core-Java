package com.atk.himma.pageobjects.sa.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class BaseLoVListTab extends DriverWaitClass {
	public final static String BASELVSEARCHFORM_ID = "baselvformSearch";
	@FindBy(id = BASELVSEARCHFORM_ID)
	private WebElement baseLVSearchForm;

	public final static String ADDNEWBASELOVBTN_ID = "ADDNEW_BASELV_ID";
	@FindBy(id = ADDNEWBASELOVBTN_ID)
	private WebElement addNewBaseLoVBtn;

	public final static String MODULENAME_ID = "moduleId";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String ENTITY_ID = "entityTypeId";
	@FindBy(id = ENTITY_ID)
	private WebElement entity;

	public final static String LANGUAGE_ID = "langCode";
	@FindBy(id = LANGUAGE_ID)
	private WebElement language;

	public final static String STATUS_NAME = "searchBaseLV.status";
	@FindBy(name = STATUS_NAME)
	private WebElement status;

	public final static String SHORTNAME_NAME = "searchBaseLV.dispShortDesc";
	@FindBy(name = SHORTNAME_NAME)
	private WebElement shortName;

	public final static String LONGNAME_NAME = "searchBaseLV.longDesc";
	@FindBy(name = LONGNAME_NAME)
	private WebElement longName;

	public final static String SEARCHBTN_ID = "SEARCH_BASELV_ID";
	@FindBy(id = SEARCHBTN_ID)
	private WebElement searchBtn;

	public final static String RESETBTN_ID = "RESET_BASELV_ID";
	@FindBy(id = RESETBTN_ID)
	private WebElement resetBtn;

	public final static String BASELVGRID_ID = "BASELV_GRID";
	@FindBy(id = BASELVGRID_ID)
	private WebElement baseLVGrid;

	public void clickOnAddBaseLoVBtn() throws Exception {
		addNewBaseLoVBtn.click();
		sleepShort();
	}

	public WebElement getBaseLVSearchForm() {
		return baseLVSearchForm;
	}

	public WebElement getAddNewBaseLoVBtn() {
		return addNewBaseLoVBtn;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getEntity() {
		return entity;
	}

	public WebElement getLanguage() {
		return language;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getShortName() {
		return shortName;
	}

	public WebElement getLongName() {
		return longName;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getBaseLVGrid() {
		return baseLVGrid;
	}

}
