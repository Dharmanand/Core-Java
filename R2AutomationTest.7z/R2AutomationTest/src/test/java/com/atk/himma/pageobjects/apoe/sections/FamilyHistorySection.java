package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class FamilyHistorySection extends DriverWaitClass {
	public final static String FAMILYHISTORYSEC_XPATH = "//a[text()='Family History']";
	@FindBy(xpath = FAMILYHISTORYSEC_XPATH)
	private WebElement familyHistorySec;

	public final static String ADDFAMILYHISTORYBTN_XPATH = ".//a[@class='AddListItem' and @onclick='javascript:addFamilyHistroy();']";
	@FindBy(xpath = ADDFAMILYHISTORYBTN_XPATH)
	private WebElement addFamilyHistoryBtn;

	public final static String NOTSIGNIFICANTFAMCHKBOX_ID = "NOT_SIGNIFICIANT_FAM_CHK	";
	@FindBy(id = NOTSIGNIFICANTFAMCHKBOX_ID)
	private WebElement notSignificantFamChkBox;

	public final static String FAMHISTORYGRIDTBL_ID = "FAMILY_HISTROY_GRID";
	@FindBy(id = FAMHISTORYGRIDTBL_ID)
	private WebElement familyHistoryGridTbl;

	public final static String DESCRIPTION_NAME = "descriptionId";
	@FindBy(name = DESCRIPTION_NAME)
	private WebElement description;

	public final static String COMORBIDITY_NAME = "coMorbidity";
	@FindBy(name = COMORBIDITY_NAME)
	private WebElement coMorbidity;

	public final static String APPROXDATE_NAME = "approximateDate";
	@FindBy(name = APPROXDATE_NAME)
	private WebElement approximateDate;

	public final static String NOTES_NAME = "notes";
	@FindBy(name = NOTES_NAME)
	private WebElement notes;

	public boolean checkFamilyHistorySec() {
		return familyHistorySec.isDisplayed();
	}

	public void fillFamilyHistoryInfo(String[] outPatientListData)
			throws Exception {
		if (Boolean.valueOf(outPatientListData[46])) {
			notSignificantFamChkBox.click();
		} else {
			addFamilyHistoryBtn.click();
			sleepVeryShort();
			waitForElementId(FAMHISTORYGRIDTBL_ID);
			if (!outPatientListData[47].isEmpty()) {
				new Select(description)
						.selectByVisibleText(outPatientListData[47]);
			}
			if (Boolean.valueOf(outPatientListData[48])) {
				coMorbidity.click();
			}
			approximateDate.clear();
			approximateDate.sendKeys(outPatientListData[49]);
			notes.clear();
			notes.sendKeys(outPatientListData[50]);

		}

	}

	public WebElement getFamilyHistorySec() {
		return familyHistorySec;
	}

	public WebElement getAddFamilyHistoryBtn() {
		return addFamilyHistoryBtn;
	}

	public WebElement getNotSignificantFamChkBox() {
		return notSignificantFamChkBox;
	}

	public WebElement getFamilyHistoryGridTbl() {
		return familyHistoryGridTbl;
	}

	public WebElement getDescription() {
		return description;
	}

	public WebElement getCoMorbidity() {
		return coMorbidity;
	}

	public WebElement getApproximateDate() {
		return approximateDate;
	}

	public WebElement getNotes() {
		return notes;
	}

}
