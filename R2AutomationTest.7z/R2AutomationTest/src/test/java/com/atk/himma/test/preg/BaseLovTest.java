package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.HomePage;
import com.atk.himma.pageobjects.baselov.BaseLovPage;
import com.atk.himma.pageobjects.baselov.tabs.BaseLoVListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class BaseLovTest extends SeleniumDriverSetup {

	List<String[]> baseLovDatas;
	BaseLovPage baseLovPage;

	@Test(description = "Open Base Lov Page")
	public void openBaseLovPage() throws InterruptedException {
		HomePage homePage = PageFactory.initElements(webDriver, HomePage.class);
		baseLovPage = homePage.clickOnBaseLovMenu(webDriver, webDriverWait,
				"Patient Registration");
		baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(baseLovPage);
		baseLovPage.waitForElementVisibilityOf(baseLovPage.getBaseLoVListTab()
				.getForm());

		baseLovPage.waitForElementId(BaseLoVListTab.ADDNEWBASELOVBUTTON_ID);
		baseLovPage.sleepVeryShort();
		masterDatas = baseLovPage.getDataFromMasters("Race", "English");
		baseLovPage.waitForElementVisibilityOf(baseLovPage.getBaseLoVListTab()
				.getAddNewBaseLoVButton());
		Assert.assertEquals(baseLovPage.getBaseLoVListTab().getBaseLoVListTab()
				.getAttribute("title").trim(), "Base LoV List");
	}

	// [Base LV] Open Form
	@Test(description = "Open Base LV Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkBaseLovMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		baseLovPage = PageFactory.initElements(webDriver, BaseLovPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		baseLVParentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList, "Base LV");
		baseLovPage.setWebDriver(webDriver);
		baseLovPage.setWebDriverWait(webDriverWait);
		baseLovPage
				.waitForElementXpathExpression(BaseLovPage.PREGBASELOVMENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("Base LV")
				.get("[Base LV] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(BaseLovPage.PREGBASELOVMENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Base LV] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			baseLovPage = baseLovPage.clickOnBaseLovMenu(webDriver,
					webDriverWait, "Patient Registration");
			baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(baseLovPage);
			baseLovPage.waitForElementVisibilityOf(baseLovPage
					.getBaseLoVListTab().getAddNewBaseLoVButton());
			baseLovPage.sleepShort();
			Assert.assertEquals(baseLovPage.getPageTitle().getText(),
					"Base LoV");
		}
	}

	@Test(dependsOnMethods = { "openBaseLovPage" }, description = "Save Base Lov Page")
	public void test1SaveBaseLovPage() throws Exception {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		baseLovDatas = excelReader.read(properties.getProperty("PREGBaseLV"));
		baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
		for (String[] st : baseLovDatas) {

			baseLovPage.saveBaseLovPage(st, webDriver, webDriverWait);
			Assert.assertNotNull(baseLovPage);
			baseLovPage
					.waitForElementXpathExpression(BaseLovPage.MSGENABLE_XPATH);
			baseLovPage.sleepVeryShort();
			baseLovPage.waitForElementVisibilityOf(baseLovPage
					.getStatusMessage());
			Assert.assertEquals(baseLovPage.getStatusMessage().getText()
					.contains("values saved successfully."), true);
			baseLovPage.waitForElementVisibilityOf(baseLovPage
					.getBaseLoVDetailsTab().getUpdateButton());
			Assert.assertEquals(baseLovPage.getBaseLoVDetailsTab()
					.getUpdateButton().getAttribute("value"), "Update", "");
		}
	}

	@Test(dependsOnMethods = { "test1SaveBaseLovPage" }, description = "Update Base Lov Page")
	public void test2UpdateBaseLovPage() throws IOException,
			InterruptedException {
		baseLovDatas = excelReader.read(properties
				.getProperty("updatePREGBaseLV"));
		baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
		for (String[] st : baseLovDatas) {
			baseLovPage.waitForElementId(BaseLoVListTab.ADDNEWBASELOVBUTTON_ID);
			baseLovPage.sleepVeryShort();
			baseLovPage.updateBaseLovPage(st);
			Assert.assertNotNull(baseLovPage);
			baseLovPage
					.waitForElementXpathExpression(BaseLovPage.MSGENABLE_XPATH);
			baseLovPage.waitForElementVisibilityOf(baseLovPage
					.getStatusMessage());
			Assert.assertEquals(baseLovPage.getStatusMessage().getText()
					.contains("values updated successfully"), true);
			baseLovPage.waitForElementVisibilityOf(baseLovPage
					.getBaseLoVDetailsTab().getUpdateButton());
			Assert.assertEquals(baseLovPage.getBaseLoVDetailsTab()
					.getUpdateButton().getAttribute("value"), "Update");
		}
	}

	@Test(description = "Check Duplicate Base Lov Data", dependsOnMethods = { "test1SaveBaseLovPage" })
	public void test3SaveDuplicateOtherLoc() throws InterruptedException,
			IOException {
		for (String st[] : baseLovDatas) {
			Assert.assertTrue(baseLovPage.saveDuplicateData(st),
					"Fail to Check Duplicate Base Lov Data");
			break;
		}
	}
}
