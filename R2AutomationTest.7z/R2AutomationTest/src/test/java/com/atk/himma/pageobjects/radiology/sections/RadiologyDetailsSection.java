package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RadiologyDetailsSection extends DriverWaitClass{
	
	public final static String ADDROWBUTTON_CSS = "#editRadiologyDetailsAuth + input[value='Add row']";
	
//	-----------GRID--------------
	public final static String GRID_ID = "SERV_GRID";
	public final static String GRID_SERCODE_ARIA_DESCRIBEDBY = "SERV_GRID_serviceCode";
	public final static String GRID_SERVNAME_ARIA_DESCRIBEDBY = "SERV_GRID_serviceName";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "SERV_GRID_action";
	public final static String GRID_PAGERID = "sp_1_SERV_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SERV_GRID_pager']";

//	-----------GRID's Fields--------------
	public final static String ITEMNAMETXT_CSS = "td[aria-describedby='"+GRID_SERCODE_ARIA_DESCRIBEDBY+"'] span input[name='serviceCode']";
	public final static String SERVNAMETXT_CSS = "td[aria-describedby='"+GRID_SERVNAME_ARIA_DESCRIBEDBY+"'] span input[name='serviceName']";
	public final static String LOOKUP_CSS = "td[aria-describedby='"+GRID_SERVNAME_ARIA_DESCRIBEDBY+"'] span a[name='serviceName']";
	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_SERCODE_ARIA_DESCRIBEDBY+"']/span/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";

	@FindBy(css = ADDROWBUTTON_CSS)
	private WebElement addRowButton;
	
	@FindBy(css = ITEMNAMETXT_CSS)
	private WebElement itemNameTxt;
	
	@FindBy(css = SERVNAMETXT_CSS)
	private WebElement servNameTxt;
	
	@FindBy(css = LOOKUP_CSS)
	private WebElement lookUp;
	
	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the itemNameTxt
	 */
	public WebElement getItemNameTxt() {
		return itemNameTxt;
	}

	/**
	 * @return the servNameTxt
	 */
	public WebElement getServNameTxt() {
		return servNameTxt;
	}

	/**
	 * @return the lookUp
	 */
	public WebElement getLookUp() {
		return lookUp;
	}

	/**
	 * @return the deleteAction
	 */
	public WebElement getDeleteAction() {
		return deleteAction;
	}

	@FindBy(css = DELETEACTION_GE_XPATH)
	private WebElement deleteAction;
	
}
