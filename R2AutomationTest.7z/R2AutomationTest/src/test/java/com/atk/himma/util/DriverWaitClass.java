package com.atk.himma.util;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.util.interfaces.GridInfo;
import com.atk.himma.util.interfaces.TopControls;

public class DriverWaitClass implements GridInfo, TopControls {

	public static final int shortTimeInterval = 3;

	protected WebDriver webDriver;

	protected WebDriverWait webDriverWait;

	protected static Set<String> parentWindowHandles;
	protected static String parentWindowHandle;

	public void waitForElementId(final String locatorId) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.id(locatorId)));
	}

	public void waitForElementName(final String locatorName) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.name(locatorName)));
	}

	public void waitForElementClassName(final String locatorClassName) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.className(locatorClassName)));
	}

	public void waitForElementTagName(final String locatorTagName) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.tagName(locatorTagName)));
	}

	public void waitForElementLinkText(final String locatorLinkText) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.linkText(locatorLinkText)));
	}

	public void waitForElementPartialLinkText(
			final String locatorPartialLinkText) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.partialLinkText(locatorPartialLinkText)));
	}

	public void waitForElementCssSelector(final String locatorCssSelector) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.cssSelector(locatorCssSelector)));
	}

	public void waitForElementXpathExpression(
			final String locatorXpathExpression) {
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By
				.xpath(locatorXpathExpression)));
	}

	public void waitForElementVisibilityOf(WebElement element) {
		webDriverWait.until(ExpectedConditions.visibilityOf(element));
	}

	public void waitForElementClickable(final String locatorXpathExpression) {
		webDriverWait.until(ExpectedConditions.elementToBeClickable(By
				.xpath(locatorXpathExpression)));

	}

	public void sleepTooShort() throws InterruptedException {
		Thread.sleep(200);
	}

	public void sleepVeryShort() throws InterruptedException {
		Thread.sleep(500);
	}

	public void sleepShort() throws InterruptedException {
		Thread.sleep(1000);
	}

	public void sleepMedium() throws InterruptedException {
		Thread.sleep(2000);
	}

	public void sleepLong() throws InterruptedException {
		Thread.sleep(5000);
	}

	// Grid(Start)-----------------------------------------

	@Override
	public String waitForGridFirstDuplicateCellText(String gridID,
			String tdAriaDescribedby) {
		waitForElementXpathExpression(".//table[@id='" + gridID
				+ "']//tr[2]//td[@aria-describedby='" + tdAriaDescribedby
				+ "']");
		return webDriver
				.findElement(
						By.xpath(".//table[@id='" + gridID
								+ "']//tr[2]//td[@aria-describedby='"
								+ tdAriaDescribedby + "']")).getText().trim();
	}

	@Override
	public String waitAndGetGridFirstCellText(String gridID,
			String textOutPutTdAriaDescribedby, String searchText) {
		waitForElementXpathExpression(".//table[@id='" + gridID
				+ "']//tr[2]//td[@title='" + searchText.trim() + "']");
		return webDriver
				.findElement(
						By.xpath(".//table[@id='" + gridID
								+ "']//tr[2]//td[@title='" + searchText.trim()
								+ "']/..//td[@aria-describedby='"
								+ textOutPutTdAriaDescribedby + "']"))
				.getText().trim();
	}

	@Override
	public boolean clickOnCheckBoxGridItem(String gridID, String searchText) {
		waitForElementXpathExpression(".//table[@id='" + gridID
				+ "']//td[@title='" + searchText.trim()
				+ "']//..//input[@class='cbox' and @type='checkbox']");
		webDriver.findElement(
				By.xpath(".//table[@id='" + gridID + "']//tr[2]//td[@title='"
						+ searchText.trim()
						+ "']//..//input[@class='cbox' and @type='checkbox']"))
				.click();
		return webDriver.findElement(
				By.xpath(".//table[@id='" + gridID + "']//tr[2]//td[@title='"
						+ searchText.trim()
						+ "']//..//input[@class='cbox' and @type='checkbox']"))
				.isSelected();
	}

	@Override
	public List<WebElement> waitForGridAllDuplicateCellText(
			String tdAriaDescribedby) {
		waitForGridAllDuplicateCellText(".//td[@aria-describedby='"
				+ tdAriaDescribedby + "']");
		return webDriver.findElements(By.xpath(".//td[@aria-describedby='"
				+ tdAriaDescribedby + "']"));
	}

	@Override
	public boolean checkGridEmpty(String gridID, String gridPagerID) {
		try {
			sleepShort();
			waitForElementId(gridID);
			waitForElementId(gridPagerID);
			List<WebElement> trs = webDriver.findElement(By.id(gridID))
					.findElements(By.tagName("tr"));
			Integer noOfPages = Integer.getInteger(webDriver
					.findElement(By.id(gridPagerID)).getText().trim());
			if ((trs.size() == 1) || (noOfPages == 0))
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public void clickOnGridAction(String tdAriaDescribedby, String searchText,
			String actionLink) {
		waitForElementXpathExpression(".//td[@aria-describedby='"
				+ tdAriaDescribedby + "' and @title='" + searchText.trim()
				+ "']/..//a[text()='" + actionLink + "']");
		webDriver.findElement(
				By.xpath(".//td[@aria-describedby='" + tdAriaDescribedby
						+ "' and @title='" + searchText.trim()
						+ "']/..//a[text()='" + actionLink + "']")).click();
	}

	@Override
	public boolean waitForGridAction(String searchText, String actionLink) {
		try {
			new WebDriverWait(webDriver, shortTimeInterval)
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By
							.xpath(".//td[@title='" + searchText.trim()
									+ "']/..//a[text()='" + actionLink + "']")));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public void clickOnGridAction(String searchText, String actionLink) {
		waitForElementXpathExpression(".//td[@title='" + searchText.trim()
				+ "']/..//a[text()='" + actionLink + "']");
		webDriver.findElement(
				By.xpath(".//td[@title='" + searchText.trim()
						+ "']/..//a[text()='" + actionLink + "']")).click();
	}

	@Override
	public void waitForGridSearchText(String searchText) {
		waitForElementXpathExpression(".//td[@title='" + searchText.trim()
				+ "']");
	}

	@Override
	public String getGridCellData(String gridID, String inputIdAriaDescribedby,
			String inputText, String outputIdAriaDescribedby) {
		By locator = By.xpath(".//table[@id='" + gridID
				+ "']//td[@aria-describedby='" + inputIdAriaDescribedby
				+ "'][text()='" + inputText.trim()
				+ "']/..//td[@aria-describedby='" + outputIdAriaDescribedby
				+ "']");
		webDriverWait.until(ExpectedConditions
				.presenceOfElementLocated(locator));
		return webDriver.findElement(locator).getText().trim();
	}

	@Override
	public int countGridAllRows(String gridID, String tdAriaDescribedby) {
		By locator = By.xpath(".//table[@id='" + gridID
				+ "']//td[@aria-describedby='" + tdAriaDescribedby + "']");
		webDriverWait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(locator));
		return webDriver.findElements(locator).size();
	}

	// Grid(End)-----------------------------------------
	// Select or Unselect Checkboxes

	public void selectOrUnSelectCheckBox(String trueOrFalseValue,
			WebElement element) {
		if ((Boolean.valueOf(trueOrFalseValue.trim()) && !element.isSelected())
				|| (!Boolean.valueOf(trueOrFalseValue.trim()) && element
						.isSelected()))
			element.click();
	}

	// Check Mandatory Fields
	public boolean isMandatoryField(WebElement element) {
		return element.getAttribute("class").contains("required");
	}
	
	// Check Readonly Fields
	public boolean isReadonlyField(WebElement element) {
		return element.getAttribute("readonly").contains("readonly");
	}

	// Check Text Length Validation
	public String checkTxtLengValidation(WebElement element, int maxTxtLength,
			int caseNo) throws Exception {
		element.clear();
		element.sendKeys(RandomStringGenerator.generateRandomString(
				maxTxtLength + 1, caseNo));
		element.submit();
		String st = element.getAttribute("id").trim();
		waitForElementXpathExpression("//..//label[@class='error' and @for='"
				+ st + "']");
		sleepVeryShort();
		return element
				.findElement(
						By.xpath("//..//label[@class='error' and @for='" + st
								+ "']")).getText().trim();
	}

	public String activateRecord(String ACTIVATE_ID, String MAINSTATUSLABEL_ID)
			throws InterruptedException {
		waitForElementId(ACTIVATE_ID);
		webDriver.findElement(By.id(ACTIVATE_ID)).click();
		waitForElementId(MAINSTATUSLABEL_ID);
		waitForPageLoaded(webDriver);
		sleepShort();
		return webDriver.findElement(By.id(MAINSTATUSLABEL_ID)).getText()
				.trim();
	}

	public boolean selectValueOfMultiselect(String ELEMENT_NAME,
			String elemTitleValue) throws InterruptedException {
		String elementXpath = "//input[@title='" + elemTitleValue
				+ "' and @name='" + ELEMENT_NAME + "']";
		waitForElementXpathExpression(elementXpath);
		sleepVeryShort();
		WebElement element = webDriver.findElement(By.xpath(elementXpath));
		if (!element.isSelected())
			element.click();
		return element.isSelected();
	}

	public boolean unSelectValOfMultiselect(String ELEMENT_NAME,
			String elemTitleValue) {
		WebElement element = webDriver.findElement(By.xpath("//input[@title='"
				+ elemTitleValue + "' and @name='" + ELEMENT_NAME + "']"));
		if (element.isSelected())
			element.click();
		return element.isSelected();
	}

	public boolean checkMandatoryOfMultiselect(String ELEMENT_NAME,
			String elemTitleValue) {
		WebElement element = webDriver.findElement(By.xpath("//input[@title='"
				+ elemTitleValue + "' and @name='" + ELEMENT_NAME + "']"));
		return element.getAttribute("class").trim().contains("required");
	}

	// Radio Button Select
	public boolean selectRadioButtonAsLabelText(String labelText) {
		WebElement radioButton = webDriver.findElement(By.id(webDriver
				.findElement(
						By.xpath("//label[text()='" + labelText.trim() + "']"))
				.getAttribute("for")));
		radioButton.click();
		return radioButton.isSelected();
	}

	protected void doDirtyPopUpCheck() {
		try {
			new WebDriverWait(webDriver, 2).until(ExpectedConditions
					.presenceOfAllElementsLocatedBy(By.id("MSG_DIALOG_YES")));
			webDriver.findElement(By.id("MSG_DIALOG_YES")).click();
		} catch (Exception e) {
			Reporter.log("... We can ignore following exception as it is related to dirty form checking.");
		}
	}

	protected void deleteRecord() {
		try {
			new WebDriverWait(webDriver, 2).until(ExpectedConditions
					.presenceOfAllElementsLocatedBy(By
							.id("ConfirmationMessage")));
			webDriver.findElement(By.id("MSG_DIALOG_YES")).click();
		} catch (Exception e) {
			Reporter.log("... We can ignore following exception as it is related to dirty form checking.");
		}
	}

	protected void confirmOkDialogBox() {
		try {
			new WebDriverWait(webDriver, 2).until(ExpectedConditions
					.presenceOfElementLocated(By.id("ConfirmationMessage")));
			webDriver
					.findElement(
							By.xpath("//span[@class='buttoncontainer_StatusMessage']//input[@id='MSG_DIALOG_OK']"))
					.click();
		} catch (Exception e) {

		}
	}

	public void waitForPageLoaded(WebDriver webDriver)
			throws InterruptedException {
		sleepVeryShort();
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				return ((JavascriptExecutor) webDriver).executeScript(
						"return document.readyState").equals("complete");
			}
		};

		Wait<WebDriver> wait = new WebDriverWait(webDriver, 30);
		try {
			wait.until(expectation);
		} catch (Throwable error) {
			Assert.assertFalse(true,
					"Timeout waiting for Page Load Request to complete.");
		}
	}

	public LoginPage signOut() throws Exception {
		waitForElementXpathExpression(SIGNOUT_XPATH);
		sleepVeryShort();
		webDriver.findElement(By.xpath(SIGNOUT_XPATH)).click();
		doDirtyPopUpCheck();
		waitForElementXpathExpression(LoginPage.LOGINBUTTON_XPATH);
		sleepVeryShort();
		LoginPage loginPage = PageFactory.initElements(webDriver,
				LoginPage.class);
		loginPage.setWebDriver(webDriver);
		loginPage.setWebDriverWait(webDriverWait);
		return loginPage;
	}

	/**
	 * @return the webDriverWait
	 */
	public WebDriverWait getWebDriverWait() {
		return webDriverWait;
	}

	/**
	 * @param webDriverWait
	 *            the webDriverWait to set
	 */
	public void setWebDriverWait(WebDriverWait webDriverWait) {
		this.webDriverWait = webDriverWait;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @param webDriver
	 *            the webDriver to set
	 */
	public void setWebDriver(WebDriver webDriver) {
		this.webDriver = webDriver;
	}

}
