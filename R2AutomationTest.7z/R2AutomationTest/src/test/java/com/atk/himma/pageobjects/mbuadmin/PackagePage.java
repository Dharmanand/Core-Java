package com.atk.himma.pageobjects.mbuadmin;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.packagedetails.PackageFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.packagedetails.PackageInclusionDetails;
import com.atk.himma.pageobjects.mbuadmin.sections.packagedetails.PackageParameters;
import com.atk.himma.pageobjects.mbuadmin.tabs.MBUSetupListTab;
import com.atk.himma.pageobjects.mbuadmin.tabs.PackageListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class PackagePage extends DriverWaitClass implements StatusMessages, TopControls, RecordStatus{
	
	private PackageListTab packageListTab;
	private PackageFirstSection packageFirstSection;
	private PackageInclusionDetails packageInclusionDetails;
	private PackageParameters packageParameters;
	
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";

	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement packageDetailsPageTitle;
	
	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;
	
	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;
	
	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		
		packageListTab = PageFactory.initElements(webDriver,
				PackageListTab.class);
		packageListTab.setWebDriver(webDriver);
		packageListTab.setWebDriverWait(webDriverWait);

		packageFirstSection = PageFactory.initElements(webDriver,
				PackageFirstSection.class);
		packageFirstSection.setWebDriver(webDriver);
		packageFirstSection.setWebDriverWait(webDriverWait);
		
		packageInclusionDetails = PageFactory.initElements(webDriver,
				PackageInclusionDetails.class);
		packageInclusionDetails.setWebDriver(webDriver);
		packageInclusionDetails.setWebDriverWait(webDriverWait);

		packageParameters = PageFactory.initElements(webDriver,
				PackageParameters.class);
		packageParameters.setWebDriver(webDriver);
		packageParameters.setWebDriverWait(webDriverWait);
		
	}
	
	public PackagePage clickOnServiceMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Other Location");
		PackagePage packagePage = PageFactory.initElements(webDriver, PackagePage.class);
		packagePage.setWebDriver(webDriver);
		packagePage.setWebDriverWait(webDriverWait);
		return packagePage;
	}

	public String searchMBU(String[] packageDatas) throws InterruptedException {
		waitForElementId(PackageListTab.MBUNAME_ID);
		sleepVeryShort();
		packageListTab.getPackageName().sendKeys(packageDatas[7].trim());
		packageListTab.getSearchButton().click();
		waitForElementId(PackageListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(MBUSetupListTab.GRID_ID,
				MBUSetupListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY, packageDatas[7]);
	}

	public boolean editMBUSetup(String[] packageDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(PackageListTab.GRID_ID,
				PackageListTab.GRID_PKGNAME_ARIA_DESCRIBEDBY, packageDatas[7]);
		sleepShort();
		clickOnGridAction(packageDatas[7], "Edit");
		waitForElementId(PackageFirstSection.SERVICENAME_NAME);
		sleepVeryShort();
		return packageFirstSection.getServiceName().getAttribute("value").trim().equals(packageDatas[7].trim());
	}

	/**
	 * @return the packageFirstSection
	 */
	public PackageFirstSection getPackageFirstSection() {
		return packageFirstSection;
	}

	/**
	 * @return the packageInclusionDetails
	 */
	public PackageInclusionDetails getPackageInclusionDetails() {
		return packageInclusionDetails;
	}

	/**
	 * @return the packageParameters
	 */
	public PackageParameters getPackageParameters() {
		return packageParameters;
	}

	/**
	 * @return the packageDetailsPageTitle
	 */
	public WebElement getPackageDetailsPageTitle() {
		return packageDetailsPageTitle;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the packageListTab
	 */
	public PackageListTab getPackageListTab() {
		return packageListTab;
	}
}
