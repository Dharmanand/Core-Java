package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.PositionHierarchyPage;
import com.atk.himma.pageobjects.sa.tabs.PositionListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class PositionHierarchyTest extends SeleniumDriverSetup {
	PositionHierarchyPage positionHierarchyPage;
	List<String[]> posHierarchyList;

	@Test(description = "Open Position Hierarchy Page")
	public void test01OpenPositionHierarchy() throws Exception {
		positionHierarchyPage = PageFactory.initElements(webDriver,
				PositionHierarchyPage.class);
		positionHierarchyPage = positionHierarchyPage
				.clickOnPositionHierarchyMenu(webDriver, webDriverWait);
		positionHierarchyPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		Assert.assertNotNull(positionHierarchyPage);
		positionHierarchyPage.waitForElementVisibilityOf(positionHierarchyPage
				.getPositionListTab().getPositionListForm());
		Assert.assertTrue(positionHierarchyPage.getPositionListTab()
				.getPositionNameCode().isDisplayed());
	}

	@Test(description = "Add New Position for Admin", dependsOnMethods = { "test01OpenPositionHierarchy" }, groups={"superAdminTestsGrp"})
	public void test02AddNewPosition() throws Exception {
		posHierarchyList = excelReader.read(properties.getProperty("positionHierarchy"));
		if (posHierarchyList != null && !posHierarchyList.isEmpty()) {
			positionHierarchyPage.getPositionListTab().clickAddNewPosition();
			for (String[] posHierarchyData : posHierarchyList) {
				positionHierarchyPage.getPositionInformationTab().addPosition(
						posHierarchyData);
				Assert.assertTrue(positionHierarchyPage
						.getPositionInformationTab().getUpdateBtn().isEnabled()
						&& positionHierarchyPage.getPositionInformationTab()
								.getAddNewPosBtn().isEnabled());
				Assert.assertEquals(positionHierarchyPage.getStatus()
						.getMainStatusText().getText(), "New");
				positionHierarchyPage.getStatus().activateRecord();
				Assert.assertEquals(positionHierarchyPage.getStatus()
						.getMainStatusText().getText(), "Active");
				positionHierarchyPage.getPositionInformationTab()
						.clickAddNewPos();
			}
			positionHierarchyPage.getPositionInformationTab().clickCancel();
		}
	}

	@Test(description = "Add New Position for Other Users", dependsOnMethods = { "test01OpenPositionHierarchy" }, groups={"adminTestsGrp"})
	public void test03AddNewPosOtherUsers() throws Exception {
		posHierarchyList = excelReader.read(properties.getProperty("otherUsersPositions"));
		if (posHierarchyList != null && !posHierarchyList.isEmpty()) {
			positionHierarchyPage.getPositionListTab().clickAddNewPosition();
			for (String[] posHierarchyData : posHierarchyList) {
				positionHierarchyPage.getPositionInformationTab().addPosition(
						posHierarchyData);
				Assert.assertTrue(positionHierarchyPage
						.getPositionInformationTab().getUpdateBtn().isEnabled()
						&& positionHierarchyPage.getPositionInformationTab()
								.getAddNewPosBtn().isEnabled());
				Assert.assertEquals(positionHierarchyPage.getStatus()
						.getMainStatusText().getText(), "New");
				positionHierarchyPage.getStatus().activateRecord();
				Assert.assertEquals(positionHierarchyPage.getStatus()
						.getMainStatusText().getText(), "Active");
				positionHierarchyPage.getPositionInformationTab()
						.clickAddNewPos();
			}
			positionHierarchyPage.getPositionInformationTab().clickCancel();
		}
	}

	@Test(description = "Edit Position", dependsOnMethods = { "test03AddNewPosOtherUsers" }, groups={"adminTestsGrp"})
	public void test04EditPosition() throws Exception {
		posHierarchyList = excelReader.read(properties.getProperty("editPositionHierarchy"));
		if (posHierarchyList != null && !posHierarchyList.isEmpty()) {
			for (String[] editPosData : posHierarchyList) {
				positionHierarchyPage.getPositionListTab().searchPos(
						editPosData);
				Assert.assertTrue(positionHierarchyPage.getPositionListTab()
						.searchGridData(editPosData[0]));
				positionHierarchyPage.getPositionListTab().clickOnEdit(
						editPosData);
				positionHierarchyPage.getPositionInformationTab()
						.updatePosition(editPosData);
				positionHierarchyPage.getPositionInformationTab()
						.clickOnUpdate();
				Assert.assertEquals(positionHierarchyPage
						.getPositionInformationTab().getPositionName()
						.getAttribute("value"), editPosData[0]);
				Assert.assertEquals(new Select(positionHierarchyPage
						.getPositionInformationTab().getJob())
						.getFirstSelectedOption().getText(), editPosData[4]);
				Assert.assertEquals(positionHierarchyPage.getStatus()
						.getMainStatusText().getText(), "Active");
				positionHierarchyPage.getStatus().InactivateRecord();
				positionHierarchyPage.getPositionInformationTab()
						.clickOnUpdate();
				Assert.assertEquals(positionHierarchyPage.getStatus()
						.getMainStatusText().getText(), "Inactive");
				positionHierarchyPage.getStatus().activateRecord();
			}
			positionHierarchyPage.getPositionInformationTab().clickCancel();
		}
	}

	@Test(description = "Delete Position", dependsOnMethods = { "test03AddNewPosOtherUsers" }, groups={"adminTestsGrp"})
	public void test05DeletePosition() throws Exception {
		posHierarchyList = excelReader.read(properties.getProperty("deletePosition"));
		if (posHierarchyList != null && !posHierarchyList.isEmpty()) {
			for (String[] editPosData : posHierarchyList) {
				positionHierarchyPage.getPositionListTab().searchPos(
						editPosData);
				Assert.assertTrue(positionHierarchyPage.getPositionListTab()
						.searchGridData(editPosData[0]));
				positionHierarchyPage.getPositionListTab().clickOnDelete(
						editPosData);
				Assert.assertFalse(positionHierarchyPage.getPositionListTab()
						.searchGridData(editPosData[0]));
			}
		}
	}

	/*
	 * @Test(description = "search Job at Position", dependsOnMethods = {
	 * "openPositionHierarchy" }, groups="") public void searchJobAtPosition()
	 * throws Exception { String jobName =
	 * positionHierarchyPage.searchPosition(fullPrivUserDatas
	 * .get("primaryPosition").get(0)); List<String> jobNameList = new
	 * ArrayList<String>(); Assert.assertNotNull(jobName);
	 * jobNameList.add(jobName); fullPrivUserDatas.put("jobName", jobNameList);
	 * }
	 */

	// [Position Hierarchy] Open Form
	@Test(description = "Open Position Hierarchy Page", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkPositionHierarchyMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		positionHierarchyPage = PageFactory.initElements(webDriver,
				PositionHierarchyPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> posParentMenuList = new LinkedList<String>();
		posParentMenuList.add("System Administration");
		menuSelector.mouseOverOnTargetMenu(posParentMenuList,
				"Position Hierarchy");
		positionHierarchyPage.setWebDriver(webDriver);
		positionHierarchyPage.setWebDriverWait(webDriverWait);
		positionHierarchyPage
				.waitForElementXpathExpression(PositionHierarchyPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Position Form")
				.get("[Position Hierarchy] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PositionHierarchyPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Position Hierarchy] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			positionHierarchyPage = positionHierarchyPage
					.clickOnPositionHierarchyMenu(webDriver, webDriverWait);
			positionHierarchyPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(positionHierarchyPage);
			positionHierarchyPage
					.waitForElementVisibilityOf(positionHierarchyPage
							.getPositionListTab().getPositionListForm());
			positionHierarchyPage.sleepShort();
			Assert.assertEquals(positionHierarchyPage.getPageTitle().getText(),
					"Position Hierarchy");
		}
	}

	// [List Tab] Include Child Organisations (CheckBox in search criteria Group)
	@Test(description = "Check Include Child Organisations chkbox", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPositionHierarchyMenuLink")
	public void checkIncludeChildOrgChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Position Form")
				.get("[List Tab] Include Child Organisations (CheckBox in search criteria Group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PositionListTab.INCLUDECHILDORG_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Include Child Organisations (CheckBox in search criteria Group) privilege");
	}

	// [List Tab] Add New (Button)
	@Test(description = "Check Add New Position Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPositionHierarchyMenuLink")
	public void checkAddNewPosBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Position Form")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PositionListTab.ADDNEWPOSITIONBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(description = "Check Edit Position Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPositionHierarchyMenuLink")
	public void checkEditPosLink() throws Exception {
		posHierarchyList = excelReader.read(properties.getProperty("otherUsersPositions"));
		for (String[] posHierarchyData : posHierarchyList.subList(0, 1)) {
			positionHierarchyPage.getPositionListTab().privSearchPos(
					posHierarchyData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Position Form")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PositionListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
	}

	// [List Tab] Delete (Link in the search result grid)
	@Test(description = "Check Delete Position Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPositionHierarchyMenuLink")
	public void checkDeletePosLink() throws Exception {
		posHierarchyList = excelReader.read(properties.getProperty("otherUsersPositions"));
		for (String[] posHierarchyData : posHierarchyList.subList(0, 1)) {
			positionHierarchyPage.getPositionListTab().privSearchPos(
					posHierarchyData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Position Form")
				.get("[List Tab] Delete (Link in the search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PositionListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete (Link in the search result grid) privilege");
	}

	// [Details Tab][Section: Audit Trail] View

}