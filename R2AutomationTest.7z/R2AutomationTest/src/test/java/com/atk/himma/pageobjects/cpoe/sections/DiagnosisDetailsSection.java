package com.atk.himma.pageobjects.cpoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class DiagnosisDetailsSection extends DriverWaitClass {
	public final static String PHYSDIAGNOSISLOOKUP_ID = "DIAG_CODE_SEARCH_LOOKUP";
	public final static String DIAGNOSISLOOKUPFORM_ID = "icdSearchPopup";
	public final static String SICDMBU_ID = "S_ICD_MBU_NAME";
	public final static String SICDCODE_XPATH = "//form[@id='icdSearchPopup']//input[@id='S_ICD_CODE']";
	public final static String SICDDESC_XPATH = "//form[@id='icdSearchPopup']//input[@id='S_ICD_DESC']";
	public final static String ICDSEARCHBTN_ID = "ICD_SEARCH";
	public final static String ICDCANCELBTN_ID = "CANCEL_ICD_SEARCH";
	public final static String ICDSEARCHGRIDDIV_ID = "DIV_ICD_SEARCH_POPUP";

	@FindBy(id = PHYSDIAGNOSISLOOKUP_ID)
	private WebElement physDiagnosisLookup;

	@FindBy(id = DIAGNOSISLOOKUPFORM_ID)
	private WebElement diagnosisLookupForm;

	@FindBy(id = SICDMBU_ID)
	private WebElement lookupIcdMBU;

	@FindBy(xpath = SICDCODE_XPATH)
	private WebElement lookupIcdCode;

	@FindBy(xpath = SICDDESC_XPATH)
	private WebElement lookupIcdDesc;

	@FindBy(id = ICDSEARCHBTN_ID)
	private WebElement lookupIcdSearchBtn;

	@FindBy(id = ICDCANCELBTN_ID)
	private WebElement lookupIcdCancelBtn;

	@FindBy(id = ICDSEARCHGRIDDIV_ID)
	private WebElement lookupIcdSearchGrid;

	public void clickOnDiagnosisLookup() throws Exception {
		physDiagnosisLookup.click();
		waitForElementId(DIAGNOSISLOOKUPFORM_ID);
		sleepVeryShort();

	}

	public void selectPhysDiagnosis(String[] outPatientListData)
			throws Exception {
		sleepMedium();
		waitForElementXpathExpression(SICDCODE_XPATH);
		lookupIcdCode.clear();
		lookupIcdCode.sendKeys(outPatientListData[26]);
		lookupIcdDesc.clear();
		lookupIcdDesc.sendKeys(outPatientListData[27]);
		lookupIcdSearchGrid.click();
		waitForElementId(ICDSEARCHGRIDDIV_ID);
		sleepVeryShort();
		clickOnGridAction("ICD_SEARCH_POPUP_GRID_icdDesc",
				outPatientListData[27], "Select");

	}

	public WebElement getPhysDiagnosisLookup() {
		return physDiagnosisLookup;
	}

	public WebElement getDiagnosisLookupForm() {
		return diagnosisLookupForm;
	}

	public WebElement getLookupIcdMBU() {
		return lookupIcdMBU;
	}

	public WebElement getLookupIcdCode() {
		return lookupIcdCode;
	}

	public WebElement getLookupIcdDesc() {
		return lookupIcdDesc;
	}

	public WebElement getLookupIcdSearchBtn() {
		return lookupIcdSearchBtn;
	}

	public WebElement getLookupIcdCancelBtn() {
		return lookupIcdCancelBtn;
	}

	public WebElement getLookupIcdSearchGrid() {
		return lookupIcdSearchGrid;
	}

}
