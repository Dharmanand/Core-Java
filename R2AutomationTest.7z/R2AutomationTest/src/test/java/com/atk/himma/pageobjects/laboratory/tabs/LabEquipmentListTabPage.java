package com.atk.himma.pageobjects.laboratory.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LabEquipmentListTabPage extends DriverWaitClass {
	public final static String LABEQUIPQSEARCHTXT_ID = "equipmentSearchField";
	@FindBy(id = LABEQUIPQSEARCHTXT_ID)
	private WebElement labEquipQSearchTxt;

	public final static String LABEQUIPQSEARCHBTN_ID = "equipmentSearchBtn";
	@FindBy(id = LABEQUIPQSEARCHBTN_ID)
	private WebElement labEquipQSearchBtn;

	public final static String ADVANCEDSEARCHBTN_ID = "LAB_EQUIP_ADV_SEARCH";
	@FindBy(id = ADVANCEDSEARCHBTN_ID)
	private WebElement advancedSearchBtn;

	public final static String ADVANCEDSEARCHDIV_ID = "LAB_EQUIP_ADV_SEARCH_DIV";
	@FindBy(id = ADVANCEDSEARCHDIV_ID)
	private WebElement advancedSearchDiv;

	public final static String ADVANCEDSEARCHMBU_NAME = "searchCriteria.mbuId";
	@FindBy(name = ADVANCEDSEARCHMBU_NAME)
	private WebElement advancedSearchMBU;

	public final static String ADVANCEDSEARCHEQUIPSHNAME_NAME = "searchCriteria.shortName";
	@FindBy(name = ADVANCEDSEARCHEQUIPSHNAME_NAME)
	private WebElement advancedSearchEquipShName;

	public final static String ADVANCEDSEARCHEQUIPNAME_NAME = "searchCriteria.resourceName";
	@FindBy(name = ADVANCEDSEARCHEQUIPNAME_NAME)
	private WebElement advancedSearchEquipName;

	public final static String ADVANCEDSEARCHEQUIPSTATUS_NAME = "searchCriteria.status";
	@FindBy(name = ADVANCEDSEARCHEQUIPSTATUS_NAME)
	private WebElement advancedSearchEquipStatus;

	public final static String EQUIPADVANCEDSEARCHBTN_ID = "equipAdvSearch";
	@FindBy(id = EQUIPADVANCEDSEARCHBTN_ID)
	private WebElement equipAdvancedSearchBtn;

	public final static String EQUIPADVANCEDRESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = EQUIPADVANCEDRESETBTN_XPATH)
	private WebElement equipAdvancedResetBtn;

	public final static String EQUIPLISTEXPORTBTN_ID = "equipmentList_grid_export_btn";
	@FindBy(id = EQUIPLISTEXPORTBTN_ID)
	private WebElement equipListExportBtn;

	public final static String EQUIPLISTGRIDTBL_ID = "equipmentList_grid";
	@FindBy(id = EQUIPLISTGRIDTBL_ID)
	private WebElement equipListGridTbl;

	public WebElement getLabEquipQSearchTxt() {
		return labEquipQSearchTxt;
	}

	public WebElement getLabEquipQSearchBtn() {
		return labEquipQSearchBtn;
	}

	public WebElement getAdvancedSearchBtn() {
		return advancedSearchBtn;
	}

	public static String getAdvancedsearchdivId() {
		return ADVANCEDSEARCHDIV_ID;
	}

	public WebElement getAdvancedSearchDiv() {
		return advancedSearchDiv;
	}

	public WebElement getAdvancedSearchMBU() {
		return advancedSearchMBU;
	}

	public WebElement getAdvancedSearchEquipShName() {
		return advancedSearchEquipShName;
	}

	public WebElement getAdvancedSearchEquipName() {
		return advancedSearchEquipName;
	}

	public WebElement getAdvancedSearchEquipStatus() {
		return advancedSearchEquipStatus;
	}

	public WebElement getEquipAdvancedSearchBtn() {
		return equipAdvancedSearchBtn;
	}

	public WebElement getEquipAdvancedResetBtn() {
		return equipAdvancedResetBtn;
	}

	public WebElement getEquipListExportBtn() {
		return equipListExportBtn;
	}

	public WebElement getEquipListGridTbl() {
		return equipListGridTbl;
	}

}
