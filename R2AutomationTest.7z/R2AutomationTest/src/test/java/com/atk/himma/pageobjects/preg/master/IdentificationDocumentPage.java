package com.atk.himma.pageobjects.preg.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class IdentificationDocumentPage extends DriverWaitClass implements
		StatusMessages {

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String MENULINK_XPATH = "//a[contains(text(),'Patient Registration')]/..//a[contains(text(),'Identification Document')]";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;
	
	public final static String CODE_ID = "idCode";

	@FindBy(id = CODE_ID)
	private WebElement code;

	public final static String DOCUMENTNAME_ID = "IdName";

	@FindBy(id = DOCUMENTNAME_ID)
	private WebElement documentName;

	public final static String STATUS_ID = "IDOC_STATUS";

	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String ISISSUEDATEMANDATORY_ID = "IsIssueDateMandatory";

	@FindBy(id = ISISSUEDATEMANDATORY_ID)
	private WebElement isIssueDateMandatory;

	public final static String ISEXPIRYDATEMANDATORY_ID = "IsExpiryDateMandatory";

	@FindBy(id = ISEXPIRYDATEMANDATORY_ID)
	private WebElement isExpiryDateMandatory;

	public final static String IDENTIFICATIONGRID_ID = "sample_grid";

	@FindBy(id = IDENTIFICATIONGRID_ID)
	private WebElement identificationGrid;

	public final static String ADDNEW_XPATH = "//input[@value='Add New']";

	@FindBy(xpath = ADDNEW_XPATH)
	private WebElement addNew;

	public final static String SAVE_XPATH = "//input[@value='Save']";

	@FindBy(xpath = SAVE_XPATH)
	private WebElement save;

	public final static String CANCEL_XPATH = "//input[@value='Cancel']";

	@FindBy(xpath = CANCEL_XPATH)
	private WebElement cancel;
	
	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	
	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;
	
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'created successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'modified successfully')]";
	public final static String DELETECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'deleted successfully')]";
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = DELETECONFMSG_XPATH)
	private WebElement deleteConfMsg;
	
	public final static String DELETECONFBUTTON_ID = "MSG_DIALOG_YES";
	
	@FindBy(id = DELETECONFBUTTON_ID)
	private WebElement deleteYesButton;
	
	// ---------------------------------------------- Grid Start

	public final static String GRID_ID= "sample_grid";
	public final static String GRID_CODE_ARIA_DESCRIBEDBY = "sample_grid_code";
	public final static String GRID_DOCNAME_ARIA_DESCRIBEDBY = "sample_grid_name";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "sample_grid_id";

	// ---------------------------------------------- Grid End

	public IdentificationDocumentPage clickOnIdentificationDocMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Patient Registration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Identification Document");
		IdentificationDocumentPage identificationDocumentPage = PageFactory
				.initElements(webDriver, IdentificationDocumentPage.class);
		identificationDocumentPage.setWebDriver(webDriver);
		identificationDocumentPage.setWebDriverWait(webDriverWait);
		return identificationDocumentPage;
	}

	public boolean saveIdentificationDocPage(String[] identDocDatas,
			WebDriver webDriver, WebDriverWait webDriverWait) throws InterruptedException {
		waitForElementId(CODE_ID);
		sleepVeryShort();
		waitForElementId(DOCUMENTNAME_ID);
		code.sendKeys(identDocDatas[0].trim());
		sleepVeryShort();
		documentName.sendKeys(identDocDatas[1].trim());
		new Select(status).selectByVisibleText(identDocDatas[2].trim());
		if (!(Boolean.getBoolean(identDocDatas[3].trim()) == isIssueDateMandatory
				.isSelected()))
			isIssueDateMandatory.click();
		if (!(Boolean.getBoolean(identDocDatas[3].trim()) == isExpiryDateMandatory
				.isSelected()))
			isExpiryDateMandatory.click();
		save.click();
		waitForElementXpathExpression(SAVECONFMSG_XPATH);
		sleepVeryShort();
		return waitAndGetGridFirstCellText(GRID_ID, GRID_DOCNAME_ARIA_DESCRIBEDBY, identDocDatas[1].trim()).trim().equals(identDocDatas[1].trim());
	}

	// public void updateIdentificationDocPage(String[] identDocDatas, WebDriver
	// webDriver, WebDriverWait webDriverWait)
	// {
	// code.clear();
	// code.sendKeys(identDocDatas[0].trim());
	// documentName.clear();
	// documentName.sendKeys(identDocDatas[1].trim());
	// new Select(status).selectByVisibleText(identDocDatas[2].trim());
	// isIssueDateMandatory.click();
	// isExpiryDateMandatory.click();
	// baseLoVDetailsTab.getUpdateButton().click();
	// waitForElementVisibilityOf(baseLoVDetailsTab.getUpdateButton());
	// }

	public boolean cancelEntry(String[] identDocDatas, String IdentificationCode)
			throws InterruptedException {
		boolean flag = false;
		waitForElementId(CODE_ID);
		sleepVeryShort();
		waitForElementId(DOCUMENTNAME_ID);
		code.sendKeys(identDocDatas[0].trim());
		sleepVeryShort();
		documentName.sendKeys(identDocDatas[1].trim());
		new Select(status).selectByVisibleText(identDocDatas[2].trim());
		if (!(Boolean.getBoolean(identDocDatas[3].trim()) == isIssueDateMandatory
				.isSelected()))
			isIssueDateMandatory.click();
		if (!(Boolean.getBoolean(identDocDatas[3].trim()) == isExpiryDateMandatory
				.isSelected()))
			isExpiryDateMandatory.click();
		cancel.click();
		waitForElementId(IDENTIFICATIONGRID_ID);
		if (code.getAttribute("value").isEmpty()
				&& documentName.getAttribute("value").isEmpty())
			flag = true;
		if (new Select(status).getFirstSelectedOption().getText().trim()
				.equals("Select"))
			flag = flag && true;
		if (isIssueDateMandatory.isSelected()
				&& isExpiryDateMandatory.isSelected())
			flag = flag && true;
		return flag;
	}

	public String editRow(String[] identDocDatas, String IdentificationCode)
			throws InterruptedException {

		clickOnGridAction(GRID_CODE_ARIA_DESCRIBEDBY,
				IdentificationCode.trim(), "Edit");
		waitForElementXpathExpression(UPDATEBUTTON_XPATH);
		waitForElementVisibilityOf(addNew);

		documentName.clear();
		documentName.sendKeys(identDocDatas[1].trim());
		new Select(status).selectByVisibleText(identDocDatas[2].trim());
		if (!(Boolean.getBoolean(identDocDatas[3].trim()) == isIssueDateMandatory
				.isSelected()))
			isIssueDateMandatory.click();
		if (!(Boolean.getBoolean(identDocDatas[3].trim()) == isExpiryDateMandatory
				.isSelected()))
			isExpiryDateMandatory.click();
		updateButton.click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		sleepVeryShort();
		return updateConfMsg.getText().trim();

	}

	public boolean viewRow(String[] identDocDatas, String identificationCode)
			throws InterruptedException {
		waitForElementId(GRID_ID);
		sleepShort();
		WebDriverWait driverWait = webDriverWait;
		try {
			webDriverWait = new WebDriverWait(webDriver, 1);
			clickOnGridAction(GRID_CODE_ARIA_DESCRIBEDBY,
					identificationCode.trim(), "View");
			waitForElementId(IDENTIFICATIONGRID_ID);
			waitForElementXpathExpression(ADDNEW_XPATH);
			sleepVeryShort();
			webDriverWait = driverWait;
			return true;
		} catch (Exception e) {
			webDriverWait = driverWait;
			return false;
		}
	}

	public boolean searchRecord(String identificationName,
			String identificationCode) throws InterruptedException {
		waitForElementId(GRID_ID);
		sleepShort();
		WebDriverWait driverWait = webDriverWait;
		try {
			webDriverWait = new WebDriverWait(webDriver, 1);
			waitForGridSearchText(identificationCode.trim());
			waitForGridSearchText(identificationName.trim());
			sleepVeryShort();
			webDriverWait = driverWait;
			return true;
		} catch (Exception e) {
			webDriverWait = driverWait;
			return false;
		}
	}

	public String deleteRow(String[] identDocDatas, String identificationCode)
			throws InterruptedException {
		clickOnGridAction(GRID_CODE_ARIA_DESCRIBEDBY,
				identificationCode.trim(), "Delete");
		waitForElementId(DELETECONFBUTTON_ID);
		getDeleteYesButton().click();
		waitForElementXpathExpression(DELETECONFMSG_XPATH);
		sleepVeryShort();
		return deleteConfMsg.getText().trim();
	}

	/**
	 * @return the code
	 */
	public WebElement getCode() {
		return code;
	}

	/**
	 * @return the documentName
	 */
	public WebElement getDocumentName() {
		return documentName;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the isIssueDateMandatory
	 */
	public WebElement getIsIssueDateMandatory() {
		return isIssueDateMandatory;
	}

	/**
	 * @return the isExpiryDateMandatory
	 */
	public WebElement getIsExpiryDateMandatory() {
		return isExpiryDateMandatory;
	}

	/**
	 * @return the identificationGrid
	 */
	public WebElement getIdentificationGrid() {
		return identificationGrid;
	}

	/**
	 * @return the addNew
	 */
	public WebElement getAddNew() {
		return addNew;
	}

	/**
	 * @return the save
	 */
	public WebElement getSave() {
		return save;
	}

	/**
	 * @return the cancel
	 */
	public WebElement getCancel() {
		return cancel;
	}

	/**
	 * @return the codeId
	 */
	public static String getCodeId() {
		return CODE_ID;
	}

	/**
	 * @return the documentnameId
	 */
	public static String getDocumentnameId() {
		return DOCUMENTNAME_ID;
	}

	/**
	 * @return the statusId
	 */
	public static String getStatusId() {
		return STATUS_ID;
	}

	/**
	 * @return the isissuedatemandatoryId
	 */
	public static String getIsissuedatemandatoryId() {
		return ISISSUEDATEMANDATORY_ID;
	}

	/**
	 * @return the isexpirydatemandatoryId
	 */
	public static String getIsexpirydatemandatoryId() {
		return ISEXPIRYDATEMANDATORY_ID;
	}

	/**
	 * @return the identificationgridId
	 */
	public static String getIdentificationgridId() {
		return IDENTIFICATIONGRID_ID;
	}

	/**
	 * @return the addnewXpath
	 */
	public static String getAddnewXpath() {
		return ADDNEW_XPATH;
	}

	/**
	 * @return the saveXpath
	 */
	public static String getSaveXpath() {
		return SAVE_XPATH;
	}


	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the gridCodeAriaDescribedby
	 */
	public static String getGridCodeAriaDescribedby() {
		return GRID_CODE_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridDocnameAriaDescribedby
	 */
	public static String getGridDocnameAriaDescribedby() {
		return GRID_DOCNAME_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridActionAriaDescribedby
	 */
	public static String getGridActionAriaDescribedby() {
		return GRID_ACTION_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the updatebuttonXpath
	 */
	public static String getUpdatebuttonXpath() {
		return UPDATEBUTTON_XPATH;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the deleteconfbuttonId
	 */
	public static String getDeleteconfbuttonId() {
		return DELETECONFBUTTON_ID;
	}

	/**
	 * @return the deleteYesButton
	 */
	public WebElement getDeleteYesButton() {
		return deleteYesButton;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the deleteConfMsg
	 */
	public WebElement getDeleteConfMsg() {
		return deleteConfMsg;
	}

}
