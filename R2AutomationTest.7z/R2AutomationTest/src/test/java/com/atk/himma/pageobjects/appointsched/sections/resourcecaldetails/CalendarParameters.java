package com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class CalendarParameters extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Calendar Parameters";
	public final static String BILLINGTYPE_ID = "RES_BILLING_TYPE";
	public final static String APPOINTSLOTDETAILS_ID = "OVERRIDE_SLOT_DURATION";
	public final static String STANDSLOTINTERVAL_ID = "defaultSlotIntervalDD";
	public final static String SERVICELOOKUP_ID = "SERACH_SERVICE";
	public final static String VIEWCALENDAR_ID = "VIEW_CALENDAR_LINK2";
	public final static String RESSPECTIMEDURCONSUL_ID = "OVERRIDE_SERVICE_DURATION";
	public final static String SLOTBASEDDURATION_ID = "resCalParamServiceIntervalDD0";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Calendar Parameters')]/..";
	
//	Pop Up Search Consultation Services

	public final static String POPUPFORM_ID = "SERVICE_LOOKUP";
	public final static String POPUPTITLE_ID = "ui-dialog-title-SEARCH_SERVICE_POPUP";
	public final static String MBUPOPUP_ID = "servicePopUpMbuId";
	public final static String DEPARTMENTPOPUP_ID = "servicePopupDeptId";
	public final static String SERSPECIALITYPOPUP_ID = "servicePopupSpecId";
	public final static String SERsubSPECPOPUP_ID = "servicePopupSubSpecId";
	public final static String SERVICENAMEPOPUP_ID = "serviceSearchCriteria.serviceName";
	public final static String SERVICECODEPOPUP_ID = "serviceSearchCriteria.serviceCode";

	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESTBUTTON_XPATH = "//span[@class='buttoncontainer_mid']//input[@title='reset']";
	public final static String SELECTBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_left']//input[@value='Select']";

	public final static String GRIDID_ID = "VISIT_PARAMETERS_GRID";
	public final static String GRID_VISITCATEGORY_ID = "VISIT_PARAMETERS_GRID_visitCategoryText";
	public final static String GRID_VISITTYPE_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_visitTypeText";
	public final static String GRID_ALLOWEDPERVISIT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_allowedPerVisit";
	public final static String GRID_ELIGDUR_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_eligibilityDuration";
	public final static String GRID_PAGERID = "sp_1_VISIT_PARAMETERS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_VISIT_PARAMETERS_GRID_pager']";
	
//	Pop Up End

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = BILLINGTYPE_ID)
	private WebElement billingType;
	
	@FindBy(id = APPOINTSLOTDETAILS_ID)
	private WebElement appointSlotDetails;
	
	@FindBy(id = STANDSLOTINTERVAL_ID)
	private WebElement stAndSlotInterval;
	
	@FindBy(id = SERVICELOOKUP_ID)
	private WebElement serviceLookUp;
	
	@FindBy(id = VIEWCALENDAR_ID)
	private WebElement viewCalendar;
	
	@FindBy(id = RESSPECTIMEDURCONSUL_ID)
	private WebElement resSpecTimeDurConsul;
	
	@FindBy(id = SLOTBASEDDURATION_ID)
	private WebElement slotBasedDuration;
	
	@FindBy(id = POPUPFORM_ID)
	private WebElement popupForm;
	
	@FindBy(id = POPUPTITLE_ID)
	private WebElement popupTitle;
	
	@FindBy(id = MBUPOPUP_ID)
	private WebElement mbuPopup;
	
	@FindBy(id = DEPARTMENTPOPUP_ID)
	private WebElement departmentPopup;
	
	@FindBy(id = SERSPECIALITYPOPUP_ID)
	private WebElement serSpecialityPopup;
	
	@FindBy(id = SERsubSPECPOPUP_ID)
	private WebElement serSubSpecPopup;
	
	@FindBy(id = SERVICENAMEPOPUP_ID)
	private WebElement serviceNamePopup;
	
	@FindBy(id = SERVICECODEPOPUP_ID)
	private WebElement serviceCodePopup;

	public boolean checkCalParamOpen() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatasOfCalParamSec(String[] resCalDatas)
			throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(BILLINGTYPE_ID);
		sleepVeryShort();
		if(!resCalDatas[21].isEmpty())
			new Select(billingType).selectByVisibleText(resCalDatas[21].trim());
		selectOrUnSelectCheckBox(resCalDatas[22].trim(), appointSlotDetails);
		if(!appointSlotDetails.isSelected() && !resCalDatas[23].isEmpty())
		{
		new Select(stAndSlotInterval).selectByVisibleText(resCalDatas[23].trim());
		}
		selectOrUnSelectCheckBox(resCalDatas[24].trim(), resSpecTimeDurConsul);
		if(!resSpecTimeDurConsul.isSelected() && !resCalDatas[25].isEmpty())
		{
			new Select(slotBasedDuration).selectByVisibleText(resCalDatas[25].trim());
		}
		return resSpecTimeDurConsul.isSelected() == Boolean.valueOf(resCalDatas[24].trim());
	}
	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the billingType
	 */
	public WebElement getBillingType() {
		return billingType;
	}

	/**
	 * @return the appointSlotDetails
	 */
	public WebElement getAppointSlotDetails() {
		return appointSlotDetails;
	}

	/**
	 * @return the stAndSlotInterval
	 */
	public WebElement getStAndSlotInterval() {
		return stAndSlotInterval;
	}

	/**
	 * @return the serviceLookUp
	 */
	public WebElement getServiceLookUp() {
		return serviceLookUp;
	}

	/**
	 * @return the viewCalendar
	 */
	public WebElement getViewCalendar() {
		return viewCalendar;
	}

	/**
	 * @return the popupForm
	 */
	public WebElement getPopupForm() {
		return popupForm;
	}

	/**
	 * @return the popupTitle
	 */
	public WebElement getPopupTitle() {
		return popupTitle;
	}

	/**
	 * @return the mbuPopup
	 */
	public WebElement getMbuPopup() {
		return mbuPopup;
	}

	/**
	 * @return the departmentPopup
	 */
	public WebElement getDepartmentPopup() {
		return departmentPopup;
	}

	/**
	 * @return the serSpecialityPopup
	 */
	public WebElement getSerSpecialityPopup() {
		return serSpecialityPopup;
	}

	/**
	 * @return the serSubSpecPopup
	 */
	public WebElement getSerSubSpecPopup() {
		return serSubSpecPopup;
	}

	/**
	 * @return the serviceNamePopup
	 */
	public WebElement getServiceNamePopup() {
		return serviceNamePopup;
	}

	/**
	 * @return the serviceCodePopup
	 */
	public WebElement getServiceCodePopup() {
		return serviceCodePopup;
	}

	/**
	 * @return the resSpecTimeDurConsul
	 */
	public WebElement getResSpecTimeDurConsul() {
		return resSpecTimeDurConsul;
	}

	/**
	 * @return the slotBasedDuration
	 */
	public WebElement getSlotBasedDuration() {
		return slotBasedDuration;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}
	
}
