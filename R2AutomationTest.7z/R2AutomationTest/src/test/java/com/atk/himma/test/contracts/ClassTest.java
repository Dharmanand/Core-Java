package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.contracts.ClassPage;
import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.classdetails.ClassGeneralParametersSection;
import com.atk.himma.pageobjects.contracts.sections.classdetails.PatientDeductibleAndLimitsSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.ClassListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class ClassTest extends SeleniumDriverSetup {
	LoginPage loginPage;
	ClassPage classPage;
	List<String[]> classList;
	List<String[]> policyList;
	List<String[]> serviceExclusionList;
	List<String[]> icdExclusionList;
	List<String[]> itemExclusionList;
	List<String[]> serviceApprvlList;
	List<String[]> icdApprvlList;
	List<String[]> itemApprvlList;

	@Test(description = "Open Class Page")
	public void test001OpenClassPage() throws Exception {
		classPage = PageFactory.initElements(webDriver, ClassPage.class);
		classPage = classPage.clickOnClassMenu(webDriver, webDriverWait);
		classPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		classList = excelReader.read(properties.getProperty("contractsClass"));
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		icdExclusionList = excelReader.read(properties
				.getProperty("ICDExcListDetails"));
		itemExclusionList = excelReader.read(properties
				.getProperty("itemExcListDetails"));
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		icdApprvlList = excelReader.read(properties
				.getProperty("ICDApprvListDetails"));
		itemApprvlList = excelReader.read(properties
				.getProperty("itemApprvListDetails"));
		policyList = excelReader.read(properties.getProperty("policy"));

		Assert.assertNotNull(classPage);
		classPage.waitForElementVisibilityOf(classPage.getClassListTab()
				.getClassListForm());
		classPage.waitForElementVisibilityOf(classPage.getClassListTab()
				.getSearchClsMbu());
		Assert.assertTrue(classPage.getClassListTab().getSearchClsMbu()
				.isDisplayed());

	}

	@Test(description = "Check For Add New Class Button", dependsOnMethods = { "test001OpenClassPage" })
	public void test002CheckForAddNewClassBtn() throws Exception {
		Assert.assertTrue(classPage.getClassListTab().getAddNewClassBtn()
				.isDisplayed());
	}

	@Test(description = "Click On Add New Class Button", dependsOnMethods = { "test002CheckForAddNewClassBtn" })
	public void test003ClickOnAddNewClassBtn() throws Exception {
		classPage.getClassListTab().clickAddNewClass();
		classPage.waitForElementVisibilityOf(classPage.getClsDetailsForm());
		classPage.waitForElementVisibilityOf(classPage
				.getClassDetailsFirstSection().getClsName());
		Assert.assertTrue(classPage.getClassDetailsFirstSection().getClsName()
				.isDisplayed());

	}

	@Test(description = "Validate Mandatory for Class Name Field", dependsOnMethods = { "test003ClickOnAddNewClassBtn" })
	public void test004ValidateClassNameMandatoryField() throws Exception {
		Assert.assertTrue(classPage.getClassDetailsFirstSection()
				.isMandClassName());

	}

	@Test(description = "Validate Mandatory for Policy Name Field", dependsOnMethods = { "test003ClickOnAddNewClassBtn" })
	public void test005ValidatePolicyNameMandatoryField() throws Exception {
		Assert.assertTrue(classPage.getClassDetailsFirstSection()
				.isMandPolicyName());

	}

	@Test(description = "Validate Mandatory for MBU Name Field", dependsOnMethods = { "test003ClickOnAddNewClassBtn" })
	public void test006ValidateMBUNameMandatoryField() throws Exception {
		Assert.assertTrue(classPage.getClassDetailsFirstSection()
				.isMandMBUName());

	}

	@Test(description = "Fill Class First Section Fields", dependsOnMethods = { "test003ClickOnAddNewClassBtn" })
	public void test007AddClassFirstSectionData() throws Exception {
		if (classList != null && !classList.isEmpty()) {
			for (String[] classListData : classList.subList(0, 1)) {
				classPage.getClassDetailsFirstSection().fillData(classListData);
				Assert.assertEquals(classPage.getClassDetailsFirstSection()
						.getSelectedMBU(), classListData[6]);

			}
		}

	}

	@Test(description = "Fill Class General Parameters Section Fields", dependsOnMethods = { "test007AddClassFirstSectionData" })
	public void test016AddClassGeneralParamSectionData() throws Exception {
		if (classList != null && !classList.isEmpty()) {
			for (String[] classListData : classList.subList(0, 1)) {
				classPage.getClassGeneralParametersSection()
						.addGeneralParamData(classListData);
				Assert.assertTrue(classPage.getClassGeneralParametersSection()
						.checkVisitSpecGridData(classListData));

			}
		}
	}

	@Test(description = "Fill Patient Deductible and Limits Section Fields", dependsOnMethods = { "test007AddClassFirstSectionData" })
	public void test017AddPatDeductLimitSectionData() throws Exception {
		if (classList != null && !classList.isEmpty()) {
			for (String[] classListData : classList.subList(0, 1)) {
				classPage.getPatientDeductibleAndLimitsSection()
						.addPatDeductLimitData(classListData);

			}
		}
	}

	@Test(description = "Expand Exclusion List Details Section", dependsOnMethods = { "test003ClickOnAddNewClassBtn" })
	public void test008ExpandExclusionListDetailsSection() throws Exception {
		classPage.collapseExpandExcSection();
		Assert.assertTrue(classPage.getExcSectionDiv().isDisplayed());

	}

	@Test(description = "Expand Approval List Details Section", dependsOnMethods = { "test003ClickOnAddNewClassBtn" })
	public void test009ExpandApprovalListDetailsSection() throws Exception {
		classPage.collapseExpandApprvlSection();
		Assert.assertTrue(classPage.getApprvlSectionDiv().isDisplayed());

	}

	@Test(description = "Add Service Pattern Exclusion List Details", dependsOnMethods = { "test008ExpandExclusionListDetailsSection" })
	public void test010AddServiceExclusionListDetailsData() throws Exception {
		if (serviceExclusionList != null && !serviceExclusionList.isEmpty()) {
			for (String[] serviceExclusionListData : serviceExclusionList
					.subList(4, 5)) {
				classPage.getExclusionListDetailsSection()
						.addServiceExclusionData(serviceExclusionListData);
				Assert.assertEquals(classPage.getExclusionListDetailsSection()
						.getServiceLvlName().getAttribute("value"),
						serviceExclusionListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Exclusion List Details", dependsOnMethods = { "test008ExpandExclusionListDetailsSection" })
	public void test011AddICDExclusionListDetailsData() throws Exception {
		if (icdExclusionList != null && !icdExclusionList.isEmpty()) {
			for (String[] icdExclusionListData : icdExclusionList.subList(4, 5)) {
				classPage.getExclusionListDetailsSection().addICDExclusionData(
						icdExclusionListData);
				Assert.assertEquals(classPage.getExclusionListDetailsSection()
						.getIcdPatternDesc().getAttribute("value"),
						icdExclusionListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Exclusion List Details", dependsOnMethods = { "test008ExpandExclusionListDetailsSection" })
	public void test012AddItemExclusionListDetailsData() throws Exception {
		if (itemExclusionList != null && !itemExclusionList.isEmpty()) {
			for (String[] itemExclusionListData : itemExclusionList.subList(4,
					5)) {
				classPage.getExclusionListDetailsSection()
						.addItemExclusionData(itemExclusionListData);
				Assert.assertEquals(classPage.getExclusionListDetailsSection()
						.checkItemLevelData(itemExclusionListData),
						itemExclusionListData[1]);
			}
		}
	}

	@Test(description = "Add Service Pattern Approval List Details", dependsOnMethods = { "test009ExpandApprovalListDetailsSection" })
	public void test013AddServiceApprovalListDetailsData() throws Exception {
		if (serviceApprvlList != null && !serviceApprvlList.isEmpty()) {
			for (String[] serviceApprvlListData : serviceApprvlList.subList(4,
					5)) {
				classPage.getApprovalListDetailsSection().addServiceApprvlData(
						serviceApprvlListData);
				Assert.assertEquals(classPage.getApprovalListDetailsSection()
						.getServiceLvlName().getAttribute("value"),
						serviceApprvlListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Approval List Details", dependsOnMethods = { "test009ExpandApprovalListDetailsSection" })
	public void test014AddICDApprvlListDetailsData() throws Exception {
		if (icdApprvlList != null && !icdApprvlList.isEmpty()) {
			for (String[] icdApprvlListData : icdApprvlList.subList(4, 5)) {
				classPage.getApprovalListDetailsSection().addICDApprvlData(
						icdApprvlListData);
				Assert.assertEquals(classPage.getApprovalListDetailsSection()
						.getIcdDescription().getAttribute("value"),
						icdApprvlListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Approval List Details", dependsOnMethods = { "test009ExpandApprovalListDetailsSection" })
	public void test015AddItemApprvlListDetailsData() throws Exception {
		if (itemApprvlList != null && !itemApprvlList.isEmpty()) {
			for (String[] itemApprvlListData : itemApprvlList.subList(4, 5)) {
				classPage.getApprovalListDetailsSection().addItemApprvlData(
						itemApprvlListData);
				Assert.assertEquals(classPage.getApprovalListDetailsSection()
						.checkItemLevelData(itemApprvlListData),
						itemApprvlListData[1]);
			}
		}
	}

	@Test(description = "Save Class Details", dependsOnMethods = { "test007AddClassFirstSectionData" })
	public void test018SaveClassDetails() throws Exception {
		classPage.saveClass();
		Assert.assertTrue(classPage.getUpdateBtn().isEnabled()
				&& classPage.getAddNewBtn().isEnabled());
	}

	@Test(description = "Activate Record", dependsOnMethods = { "test018SaveClassDetails" })
	public void test019ActivateRecord() throws Exception {
		Assert.assertEquals(classPage.activateRecord().contains("Active"),
				true, "Failed Activate Record");

	}

	@Test(description = "Verify Class Associated to Policy", dependsOnMethods = { "test019ActivateRecord" })
	public void test020VerifyPolicyAssociatedClasses() throws Exception {
		if (classList != null && !classList.isEmpty()) {
			classPage.clickOnGoToPolicyBtn();
			for (String[] classListData : classList.subList(0, 1)) {
				Assert.assertTrue(classPage
						.verifyPolicyAssociatedClasses(classListData));

			}
		}

	}

	@Test(description = "Apply Exclusion List to Class", dependsOnMethods = { "test020VerifyPolicyAssociatedClasses" })
	public void test021ApplyExcListToClass() throws Exception {
		classPage.collapseExpandPolicyExcSection();
		for (String[] policyData : policyList.subList(0, 1)) {
			classPage.getExclusionListDetailsSection().applyExcListToClasses(
					policyData);
		}

	}

	@Test(description = "Apply Approval List to Class", dependsOnMethods = { "test020VerifyPolicyAssociatedClasses" })
	public void test022ApplyApprvlListToClass() throws Exception {
		classPage.collapseExpandPolicyApprvlSection();
		for (String[] policyData : policyList.subList(0, 1)) {
			classPage.getApprovalListDetailsSection().applyApprvlListToClasses(
					policyData);
		}

	}

	@Test(description = "Update Policy Details", dependsOnMethods = { "test020VerifyPolicyAssociatedClasses" })
	public void test023UpdatePolicyDetails() throws Exception {
		classPage.updatePolicyDetails();
	}

	@Test(description = "Search Class", dependsOnMethods = { "test020VerifyPolicyAssociatedClasses" })
	public void test024SearchClass() throws Exception {
		classPage.clickOnClassMenu(webDriver, webDriverWait);
		for (String[] classListData : classList.subList(0, 1)) {
			classPage.getClassListTab().searchClass(classListData);
		}

	}

	@Test(description = "Verify Policy Exclusion List Details in Class", dependsOnMethods = { "test024SearchClass" })
	public void test025VerifyPolicyExcListInClass() throws Exception {
		for (String[] serviceExcListData : serviceExclusionList.subList(3, 4)) {
			classPage.collapseExpandExcSection();
			Assert.assertTrue(classPage.getExclusionListDetailsSection()
					.checkExcGrid(serviceExcListData));
		}

	}

	@Test(description = "Verify Agreement Approval List Details in Policy", dependsOnMethods = { "test024SearchClass" })
	public void test026VerifyPolicyApprvlListInClass() throws Exception {
		for (String[] serviceApprvlListData : serviceApprvlList.subList(3, 4)) {
			classPage.collapseExpandApprvlSection();
			Assert.assertTrue(classPage.getApprovalListDetailsSection()
					.checkApprvlGrid(serviceApprvlListData));

		}

	}

	@Test(description = "Sign Out", dependsOnMethods = "test026VerifyPolicyApprvlListInClass", alwaysRun = true)
	public void test027SignOut() throws Exception {
		loginPage = classPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = { "test027SignOut" })
	public void test028Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(9,
				excelReader.read(properties.getProperty("loginSheetName"))),
				"User Home", "Failed Login");
	}

	// [Class] Open Form
	@Test(description = "Check Class Page Menu Lick", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckClassPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		classPage = PageFactory.initElements(webDriver, ClassPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> clsParentMenuList = new LinkedList<String>();
		clsParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(clsParentMenuList, "Class");
		classPage.setWebDriver(webDriver);
		classPage.setWebDriverWait(webDriverWait);
		classPage.waitForElementXpathExpression(ClassPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class").get("[Class] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ClassPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Class] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			classPage = classPage.clickOnClassMenu(webDriver, webDriverWait);
			classPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(classPage);
			classPage.waitForElementVisibilityOf(classPage.getClassListTab()
					.getClassListForm());
			classPage.sleepShort();
			Assert.assertEquals(classPage.getPageTitle().getText(), "Class");
		}

	}

	// [List Tab] Add New Class (Button)
	@Test(description = "Check Add New Class Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckClassPageMenuLink")
	public void test02CheckAddNewClassBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[List Tab] Add New Class (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(ClassListTab.ADDNEWCLASSBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Add New Class (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link in Class List grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckClassPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		classList = excelReader.read(properties.getProperty("contractsClass"));
		for (String[] classData : classList) {
			classPage.getClassListTab().searchClassList(classData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ClassListTab.VIEWCLSLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link in Class List grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckClassPageMenuLink")
	public void test04CheckLink2Delete() throws Exception {
		classList = excelReader.read(properties.getProperty("contractsClass"));
		for (String[] classData : classList) {
			classPage.getClassListTab().searchClassList(classData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ClassListTab.DELCLSLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link in Class List grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckClassPageMenuLink")
	public void test05CheckLink3Edit() throws Exception {
		classList = excelReader.read(properties.getProperty("contractsClass"));
		for (String[] classData : classList) {
			classPage.getClassListTab().searchClassList(classData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ClassListTab.EDITCLSLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		classPage.getClassListTab().clickEditClsLink(classList.get(0));
	}

	// [Details Tab][Section: Class General Parameters] View
	@Test(description = "Check Class General Param Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test06CheckClsGenParamSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[Details Tab][Section: Class General Parameters] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ClassGeneralParametersSection.CLSGENPARAMSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Class General Parameters] View privilege");

	}

	// [Details Tab][Section: Class General Parameters] Visit Coverage (Check
	// box group)
	@Test(description = "Check Visit Coverage Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckClsGenParamSec")
	public void test10CheckVisitCoverageChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Class General Parameters] Visit Coverage (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ClassGeneralParametersSection.CLSVISITCOVCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Class General Parameters] Visit Coverage (Check box group) privilege");

	}

	// [Details Tab][Section: Class General Parameters] Age Coverage Limit
	// (Check box group)
	@Test(description = "Check Age Coverage Limit Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckClsGenParamSec")
	public void test11CheckAgeCoverageLimitChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Class General Parameters] Age Coverage Limit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.id(ClassGeneralParametersSection.AGECOVCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Class General Parameters] Age Coverage Limit (Check box group) privilege");

	}

	// [Details Tab][Section: Class General Parameters] Class Credit Limit
	// (Check box group)
	@Test(description = "Check Class Credit Limit Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckClsGenParamSec")
	public void test12CheckClsCreditLimitChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Class General Parameters] Class Credit Limit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ClassGeneralParametersSection.CLSCDTLIMITCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Class General Parameters] Class Credit Limit (Check box group) privilege");

	}

	// [Details Tab][Section: Class General Parameters] Credit Limit Duration
	// (Check box group)
	@Test(description = "Check Credit Limit Duration Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckClsGenParamSec")
	public void test13CheckCreditLimitDurChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Class General Parameters] Credit Limit Duration (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(ClassGeneralParametersSection.CDTLIMITDUR_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Class General Parameters] Credit Limit Duration (Check box group) privilege");

	}

	// [Details Tab][Section: Patient Deductible and Limits] View
	@Test(description = "Check Patient Deductible and Limits Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test07CheckPatDeductLimitSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Patient Deductible and Limits] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(PatientDeductibleAndLimitsSection.PATDEDUCTLIMITSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Patient Deductible and Limits] View privilege");

	}

	// [Details Tab][Section: Patient Deductible and Limits] Apply Deductible
	// (Check box group)
	@Test(description = "Check Apply Deductible Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test07CheckPatDeductLimitSec")
	public void test14CheckApplyDeductChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Patient Deductible and Limits] Apply Deductible (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PatientDeductibleAndLimitsSection.APPLYDEDUCTCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Patient Deductible and Limits] Apply Deductible (Check box group) privilege");

	}

	// [Details Tab][Section: Patient Deductible and Limits] Apply Maximum
	// Patient Deductible Limit (Check box group)
	@Test(description = "Check Apply Max Patient Deductible Limit Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test07CheckPatDeductLimitSec")
	public void test15CheckApplyMaxPatDeductLimitChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Patient Deductible and Limits] Apply Maximum Patient Deductible Limit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.id(PatientDeductibleAndLimitsSection.APPLYMAXDEDUCTCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Patient Deductible and Limits] Apply Maximum Patient Deductible Limit (Check box group) privilege");

	}

	// [Details Tab][Section: Patient Deductible and Limits] Visit Limit
	// Pre-Authorization (Check box group)
	@Test(description = "Check Visit Limit Pre-Auth Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test07CheckPatDeductLimitSec")
	public void test16CheckVisitLimitPreAuthChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Patient Deductible and Limits] Visit Limit Pre-Authorization (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.id(PatientDeductibleAndLimitsSection.VISITLIMITPREAUTHCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Patient Deductible and Limits] Visit Limit Pre-Authorization (Check box group) privilege");

	}

	// [Details Tab][Section: Exclusion List Details] View
	@Test(description = "Check Exclusion List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test08CheckExcListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[Details Tab][Section: Exclusion List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ExclusionListDetailsSection.EXCLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] View privilege");
		if (actualPrivilage)
			classPage.collapseExpandExcSection();
	}

	// [Details Tab][Section: Exclusion List Details] Add Record (Button)
	@Test(description = "Check Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckExcListDetailsSec")
	public void test17CheckExcAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Exclusion List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Edit Record (Inline
	// editing in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckExcListDetailsSec")
	public void test18CheckExcInlineEditRecord() throws Exception {
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		classPage.getExclusionListDetailsSection().clickExcListRecord(
				serviceExclusionList.get(4));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.name(ExclusionListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link In Exc Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckExcListDetailsSec")
	public void test19CheckDelLinkInExcGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVEXCDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] View
	@Test(description = "Check Approval List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test09CheckApprvlListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Class")
				.get("[Details Tab][Section: Approval List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ApprovalListDetailsSection.APPRVLLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] View privilege");
		if (actualPrivilage)
			classPage.collapseExpandApprvlSection();
	}

	// [Details Tab][Section: Approval List Details] Add Record (Button)
	@Test(description = "Check Approval List Details Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckApprvlListDetailsSec")
	public void test20CheckAppAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Approval List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Approval List Details] Edit Record (Inline editing
	// in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckApprvlListDetailsSec")
	public void test21CheckInlineEditRecord() throws Exception {
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		classPage.getApprovalListDetailsSection().clickApprvlListRecord(
				serviceApprvlList.get(4));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.name(ApprovalListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link in Approval List Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckApprvlListDetailsSec")
	public void test22CheckDelLinkInApprvlGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Class")
				.get("[Details Tab][Section: Approval List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVAPPRVLDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Applicable Main Business Units] View

	// [Details Tab][Section: Audit Trail] View

}
