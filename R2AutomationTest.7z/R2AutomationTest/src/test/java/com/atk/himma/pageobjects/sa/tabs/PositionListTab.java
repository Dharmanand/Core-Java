package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.atk.himma.util.DriverWaitClass;

public class PositionListTab extends DriverWaitClass {
	public final static String POSITIONLISTFORM_ID = "POSITION_LIST_FORM";
	@FindBy(id = POSITIONLISTFORM_ID)
	private WebElement positionListForm;

	public final static String ADDNEWPOSITIONBTN_ID = "ADD_NEW_POS_BTN";
	@FindBy(id = ADDNEWPOSITIONBTN_ID)
	private WebElement addNewPositionBtn;

	public final static String POSITIONNAMECODE_ID = "posNameCode";
	@FindBy(id = POSITIONNAMECODE_ID)
	private WebElement positionNameCode;

	public final static String REPORTINGPOSITION_ID = "repPosition";
	@FindBy(id = REPORTINGPOSITION_ID)
	private WebElement reportingPosition;

	public final static String STATUS_ID = "POSITION_STATUS";
	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String ORGUNITLOOKUP_ID = "ORG_LOOKUP_ID";
	@FindBy(id = ORGUNITLOOKUP_ID)
	private WebElement orgUnitLookup;

	public final static String INCLUDECHILDORG_ID = "Child_Organizations";
	@FindBy(id = INCLUDECHILDORG_ID)
	private WebElement includeChildOrg;

	public final static String SEARCHBTN_XPATH = "//form[@id='POSITION_LIST_FORM']//input[@value='Search']";
	@FindBy(xpath = SEARCHBTN_XPATH)
	private WebElement searchBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String POSITIONGRID_ID = "gbox_POSTIONS_GRID";
	@FindBy(id = POSITIONGRID_ID)
	private WebElement positionGrid;

	public final static String CONFIRMATIONMSG_ID = "ConfirmationMessage";
	@FindBy(id = CONFIRMATIONMSG_ID)
	private WebElement confirmMsg;

	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";
	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public final static String EDITLINK_XPATH = ".//table[@id='POSTIONS_GRID']/..//a[text()='Edit']";
	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	public final static String DELETELINK_XPATH = ".//table[@id='POSTIONS_GRID']/..//a[text()='Delete']";
	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public final static String GRID_ID = "POSTIONS_GRID";
	public final static String GRID_POSITIONCODE_ARIA_DESCRIBEDBY = "POSTIONS_GRID_positionCode";
	public final static String GRID_POSITIONNAME_ARIA_DESCRIBEDBY = "POSTIONS_GRID_positionTitle";
	public final static String GRID_ROLENAME_ARIA_DESCRIBEDBY = "POSTIONS_GRID_roleInfo.roleName";
	public final static String GRID_PAGERID = "sp_1_POSTIONS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_POSTIONS_GRID_pager']";

	public void clickAddNewPosition() throws Exception {
		addNewPositionBtn.click();
		sleepShort();
	}

	public void searchPos(String[] editPosData) throws Exception {
		positionNameCode.clear();
		positionNameCode.sendKeys(editPosData[0]);

		orgUnitLookup.click();
		sleepShort();
		OrgUnitSearchPopupPage orgUnitSearchPopupPage = PageFactory
				.initElements(webDriver, OrgUnitSearchPopupPage.class);
		orgUnitSearchPopupPage.setWebDriver(webDriver);
		orgUnitSearchPopupPage.setWebDriverWait(webDriverWait);
		orgUnitSearchPopupPage.searchUnit(editPosData[1], editPosData[2],
				editPosData[3]);
		sleepShort();
		includeChildOrg.click();
		searchBtn.click();
		sleepShort();
	}
	
	public void privSearchPos(String[] editPosData) throws Exception {
		positionNameCode.clear();
		positionNameCode.sendKeys(editPosData[0]);
		includeChildOrg.click();
		searchBtn.click();
		sleepShort();
	}

	public void clickOnEdit(String[] editPosData) throws Exception {
		clickOnGridAction("POSTIONS_GRID_positionTitle", editPosData[0], "Edit");
		sleepShort();
	}

	public void clickOnDelete(String[] editPosData) throws Exception {
		clickOnGridAction("POSTIONS_GRID_positionTitle", editPosData[0],
				"Delete");
		sleepShort();
		waitForElementId(CONFIRMATIONMSG_ID);
		confirmYes.click();
		sleepShort();
	}

	public boolean searchGridData(String posName) {
		boolean result = false;
		try {
			waitForElementXpathExpression("//td[@aria-describedby='POSTIONS_GRID_positionTitle' and @title='"
					+ posName.trim() + "']");
			result = webDriver
					.findElements(
							By.xpath("//td[@aria-describedby='POSTIONS_GRID_positionTitle' and @title='"
									+ posName.trim() + "']")).get(1)
					.isDisplayed();
			return result;
		} catch (Exception e) {

			return result;
		}
	}

	public WebElement getPositionListForm() {
		return positionListForm;
	}

	public WebElement getAddNewPositionBtn() {
		return addNewPositionBtn;
	}

	public WebElement getPositionNameCode() {
		return positionNameCode;
	}

	public WebElement getReportingPosition() {
		return reportingPosition;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getOrgUnitLookup() {
		return orgUnitLookup;
	}

	public WebElement getIncludeChildOrg() {
		return includeChildOrg;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getPositionGrid() {
		return positionGrid;
	}

	public WebElement getConfirmMsg() {
		return confirmMsg;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
