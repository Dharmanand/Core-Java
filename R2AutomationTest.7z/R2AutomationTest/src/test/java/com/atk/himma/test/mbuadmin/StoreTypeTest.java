package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.master.StoreTypePage;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.StoreTypeMBUListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class StoreTypeTest extends SeleniumDriverSetup{
	
	List<String[]> storeTypeDatas;
	StoreTypePage storeTypePage;

	@Test(description = "Click On Store Type Menu")
	public void clickOnStoreTypeMenu() {
		storeTypePage = PageFactory.initElements(webDriver, StoreTypePage.class);
		storeTypePage = storeTypePage.clickOnStoreTypeMenu(webDriver, webDriverWait);
		storeTypePage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(storeTypePage);
		storeTypePage
				.waitForElementVisibilityOf(storeTypePage.getStoreTypeMBUListTab().getForm());
		storeTypePage
				.waitForElementXpathExpression(StoreTypeMBUListTab.MBULISTTAB_XPATH);
		Assert.assertEquals(storeTypePage.getPageTitle().getText().trim(),
				"Store Type");
	}
	
	// [Store Type ] Open Form
	@Test(description = "Open Store Type Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkStoreTypeMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		storeTypePage = PageFactory
				.initElements(webDriver, StoreTypePage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		parentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Store Type");
		storeTypePage.setWebDriver(webDriver);
		storeTypePage.setWebDriverWait(webDriverWait);
		storeTypePage
				.waitForElementXpathExpression(StoreTypePage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Store Type")
				.get("[Store Type ] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(StoreTypePage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Store Type ] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			storeTypePage = storeTypePage.clickOnStoreTypeMenu(webDriver,
					webDriverWait);
			storeTypePage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(storeTypePage);
			storeTypePage.waitForElementVisibilityOf(storeTypePage
					.getStoreTypeMBUListTab().getForm());
			storeTypePage
					.waitForElementXpathExpression(StoreTypeMBUListTab.MBULISTTAB_XPATH);
			Assert.assertEquals(storeTypePage.getPageTitle().getText().trim(),
					"Store Type");
		}
	}

	@Test(description = "Search Visit Category", dependsOnMethods={"clickOnStoreTypeMenu"})
	public void test1SearchVisitCategory() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		storeTypeDatas = excelReader.read(properties.getProperty("storeType"));
		Assert.assertNotNull(storeTypePage);
		storeTypePage
		.waitForElementVisibilityOf(storeTypePage.getStoreTypeMBUListTab().getForm());
		storeTypePage
		.waitForElementXpathExpression(StoreTypeMBUListTab.MBULISTTAB_XPATH);
		for(String st[] : storeTypeDatas)
		Assert.assertEquals(storeTypePage.searchVisitCategory(st).trim(), st[0].trim(),
				st[0].trim()+" Search failed.");
	}
	@Test(description = "Click On Edit Link", dependsOnMethods={"test1SearchVisitCategory"})
	public void test2ClickOnEditLink() throws IOException {
		for(String st[] : storeTypeDatas)
			Assert.assertEquals(storeTypePage.clickOnEditLink(st).trim(), st[0].trim(),
					"'Edit link' click failed.");
	}
	@Test(description = "Click On Add Record Grid Button", dependsOnMethods={"test2ClickOnEditLink"})
	public void test3ClickOnAddRecordGridButton() throws IOException, InterruptedException {
		
			Assert.assertEquals(storeTypePage.clickOnAddRecordGridButton().trim(), "Add Record",
					"'click On Add Button of grid' failed.");
	}
	@Test(description = "Save Store Type", dependsOnMethods={"test3ClickOnAddRecordGridButton"})
	public void test4SaveVisitCategory() throws IOException, InterruptedException {
		for(String st[] : storeTypeDatas)
		Assert.assertEquals(storeTypePage.saveVisitCategory(st).trim().contains("is Saved Successfully."), true,
				"'Save Store Type' failed.");
	}
	@Test(description = "Edit Store Type", dependsOnMethods={"test4SaveVisitCategory"})
	public void test5EditVisitCategory() throws IOException, InterruptedException {
		for(String st[] : storeTypeDatas)
			Assert.assertEquals(storeTypePage.editVisitCategory(st).trim().contains("is Saved Successfully."), true,
					"'Edit Store TypeStore Type' failed.");
	}
	@Test(description = "Cancel Store Type", dependsOnMethods={"test2ClickOnEditLink"}, alwaysRun = true)
	public void test6CancelVisitCategory() throws IOException, InterruptedException {
		for(String st[] : storeTypeDatas)
		{
			Assert.assertEquals(storeTypePage.cancelVisitCategory(st).trim(), st[0].trim(),
					"'Cancel Store Type' failed.");
			storeTypePage.clickOnEditLink(st);
		}
	}
}
