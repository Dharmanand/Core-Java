package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class DiagVitalSignsAllergiesDetailsSec extends DriverWaitClass {
	public final static String DIAGVITALSALRGYSEC_XPATH = "//a[text()='Diagnosis, Vital Signs, Allergies Details']";
	@FindBy(xpath = DIAGVITALSALRGYSEC_XPATH)
	private WebElement diagVitalsAlrgySec;

	public final static String LASTDIAGNOSISTYPE_ID = "DIAGNOSIS_STATUS_TYPE";
	@FindBy(id = LASTDIAGNOSISTYPE_ID)
	private WebElement lastDiagType;

	public final static String LASTDIAGNOSIS_ID = "LAST_DIAGNOSIS";
	@FindBy(id = LASTDIAGNOSIS_ID)
	private WebElement lastDiagnosis;

	public final static String CAPTUREDON_ID = "LAST_DIAGNOSIS_CAPTURED_ON";
	@FindBy(id = CAPTUREDON_ID)
	private WebElement capturedOn;

	public final static String ADDVIEWDIAGNOSISBTN_ID = "ADD_DIAGNOSIS";
	@FindBy(id = ADDVIEWDIAGNOSISBTN_ID)
	private WebElement addViewDiagnosisBtn;

	public final static String ADDVIEWALRGYBTN_XPATH = "//input[@onclick='AddNewAllergyPopup();']";
	@FindBy(xpath = ADDVIEWALRGYBTN_XPATH)
	private WebElement addViewAllergyBtn;

	public final static String ADDVIEWVITALSBTN_ID = "ADD_VITAL_SIGNS";
	@FindBy(id = ADDVIEWVITALSBTN_ID)
	private WebElement addViewVitalsBtn;

	public final static String O2SAT_NAME = "triageDetail.o2Saturation";
	@FindBy(name = O2SAT_NAME)
	private WebElement o2Saturation;

	public final static String ACTIVEMEDICATIONSGRIDTBL_ID = "ACTIVE_MEDICATIONS";
	@FindBy(id = ACTIVEMEDICATIONSGRIDTBL_ID)
	private WebElement activeMedicationsGridTbl;

	public boolean checkDiagVitalsAllergiesSec() {
		return diagVitalsAlrgySec.isDisplayed();
	}

	public boolean checkAddViewDiagnosisBtn() {
		return addViewDiagnosisBtn.isDisplayed();
	}

	public boolean checkAddViewAlrgyBtn() {
		return addViewAllergyBtn.isDisplayed();
	}

	public boolean checkAddViewVitalsBtn() {
		return addViewVitalsBtn.isDisplayed();
	}

	public void clickAddViewAllergiesBtn() throws Exception {
		addViewAllergyBtn.click();
		sleepShort();
	}

	public void clickAddViewVitalsBtn() throws Exception {
		addViewVitalsBtn.click();
		sleepShort();

	}

	public String getAllergyData(String[] orderEntryListData) {
		return webDriver
				.findElement(
						By.xpath("//select[@class='input_multiselect_vl']//option[text()='"
								+ orderEntryListData[0] + "']")).getText();
	}

	public WebElement getDiagVitalsAlrgySec() {
		return diagVitalsAlrgySec;
	}

	public WebElement getLastDiagType() {
		return lastDiagType;
	}

	public WebElement getLastDiagnosis() {
		return lastDiagnosis;
	}

	public WebElement getCapturedOn() {
		return capturedOn;
	}

	public WebElement getAddViewDiagnosisBtn() {
		return addViewDiagnosisBtn;
	}

	public WebElement getAddViewAllergyBtn() {
		return addViewAllergyBtn;
	}

	public WebElement getAddViewVitalsBtn() {
		return addViewVitalsBtn;
	}

	public WebElement getO2Saturation() {
		return o2Saturation;
	}

	public WebElement getActiveMedicationsGridTbl() {
		return activeMedicationsGridTbl;
	}

}
