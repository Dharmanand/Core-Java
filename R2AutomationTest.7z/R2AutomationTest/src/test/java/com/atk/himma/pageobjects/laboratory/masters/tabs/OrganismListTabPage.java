package com.atk.himma.pageobjects.laboratory.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class OrganismListTabPage extends DriverWaitClass {
	public final static String ADDNEWORGANISMBTN_XPATH = "//input[@value='Add New Organism']";
	@FindBy(xpath = ADDNEWORGANISMBTN_XPATH)
	private WebElement addNewOrganismBtn;

	public final static String QUICKSEARCHORGANISMTXT_NAME = "searchString";
	@FindBy(name = QUICKSEARCHORGANISMTXT_NAME)
	private WebElement quickSearchOrganismTxt;

	public final static String ORGANISMQSEARCHBTN_CSS = "span.input_holder_auto > input[value='Search']";
	@FindBy(css = ORGANISMQSEARCHBTN_CSS)
	private WebElement organismQSearchBtn;

	public final static String ADVSEARCHBTN_ID = "ORGANISMLIST_ADVANCED_SEARCH";
	@FindBy(id = ADVSEARCHBTN_ID)
	private WebElement advSearchBtn;

	public final static String ADVSEARCHDIV_ID = "ORGANISM_ADV_SEARCH_DIV";
	@FindBy(id = ADVSEARCHDIV_ID)
	private WebElement advSearchDiv;

	public final static String ORGANISMSHNAME_ID = "ORGANISM_SHORT_NAME";
	@FindBy(id = ORGANISMSHNAME_ID)
	private WebElement organismShName;

	public final static String ORGANISMTYPE_ID = "ORGANISM_TYPE_ID";
	@FindBy(id = ORGANISMTYPE_ID)
	private WebElement organismType;

	public final static String ORGANISMDESC_ID = "ORGANISM_DESC";
	@FindBy(id = ORGANISMDESC_ID)
	private WebElement organismDesc;

	public final static String STATUS_ID = "MAINSTATUS_ID";
	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String ORGANISMSEARCHADV_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='Search']";
	@FindBy(xpath = ORGANISMSEARCHADV_XPATH)
	private WebElement organismSearchAdv;

	public final static String ORGANISMRESETADV_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = ORGANISMRESETADV_XPATH)
	private WebElement organismResetAdv;

	public final static String ORGEXPORTTOEXCELBTN_ID = "SEARCH_ORGANISMS_LIST_export_btn";
	@FindBy(id = ORGEXPORTTOEXCELBTN_ID)
	private WebElement orgExportTpExcelBtn;

	public final static String ORGANISMLISTTBL_ID = "SEARCH_ORGANISMS_LIST";
	@FindBy(id = ORGANISMLISTTBL_ID)
	private WebElement organismListTbl;

	public WebElement getAddNewOrganismBtn() {
		return addNewOrganismBtn;
	}

	public WebElement getQuickSearchOrganismTxt() {
		return quickSearchOrganismTxt;
	}

	public WebElement getOrganismQSearchBtn() {
		return organismQSearchBtn;
	}

	public WebElement getAdvSearchBtn() {
		return advSearchBtn;
	}

	public WebElement getAdvSearchDiv() {
		return advSearchDiv;
	}

	public WebElement getOrganismShName() {
		return organismShName;
	}

	public WebElement getOrganismType() {
		return organismType;
	}

	public WebElement getOrganismDesc() {
		return organismDesc;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getOrganismSearchAdv() {
		return organismSearchAdv;
	}

	public WebElement getOrganismResetAdv() {
		return organismResetAdv;
	}

	public WebElement getOrgExportTpExcelBtn() {
		return orgExportTpExcelBtn;
	}

	public WebElement getOrganismListTbl() {
		return organismListTbl;
	}

}
