package com.atk.himma.pageobjects.desktop;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.EncounterPage;
import com.atk.himma.pageobjects.cpoe.ConsultationPage;
import com.atk.himma.pageobjects.nursing.TriagePage;
import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class DesktopDataPage extends DriverWaitClass implements StatusMessages {
	private ConsultationPage consultationPage;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String OPDFORM_ID = "searchOPDeskForm";
	public final static String MBU_ID = "SEARCH_USER_MBU_ID";
	public final static String FROMDATE_ID = "DATEID1";
	public final static String TODATE_ID = "DATEID2";
	public final static String OPSEARCHBTN_ID = "SEARCH_PATIENT_PHYSICIAN_SEARCH";
	public final static String OPRESETBTN_ID = "SEARCH_RESET_PHYSICIAN_SEARCH";
	public final static String SEARCHRESGRIDTBL_ID = "drDeskGridList";

	public final static String FILTERCRITBTN_ID = "FLOTING_CRITERIA_BT_ID";
	public final static String FLOTINGFILTERCRITDIV_ID = "FLOTING_CRITERIA_DIV_ID";
	public final static String FILTERBYPHYS_ID = "PHYSICIAN";
	public final static String SPECIALTY_ID = "SPEC_ID";
	public final static String PHYSLOOKUP_ID = "PHYSICIAN_LOOKUP_FILTER";
	public final static String PHYSSEARCHFORM_ID = "PHYSICIAN_SEARCH_FORM_POPUP";
	public final static String SPHYSMBU_ID = "mbusId";
	public final static String SPHYSDEPT_ID = "deptId";
	public final static String SPHYSSPLTY_ID = "specId";
	public final static String SPHYSSUBSPLTY_ID = "subSpecId";
	public final static String SPHYSDESIG_ID = "designationId";
	public final static String SPHYSNAME_ID = "physicianId";
	public final static String SPHYSCODE_ID = "physicianCodeId";
	public final static String SPHYSSEARCHBTN_ID = "SEARCH_PHYSICIAN";
	public final static String SPHYSRESETBTN_XPATH = "//form[@id='PHYSICIAN_SEARCH_FORM_POPUP']//input[@value='Reset']";
	public final static String SPHYGRIDDIV_ID = "SEARCH_RESULT_PHYSICIAN_POPUP";
	public final static String FLOTINGPHYSSEARCHBTN_ID = "SEARCH_PATIENT_PHYSICIAN";
	public final static String FLOTINGPHYSRESETBTN_ID = "SEARCH_RESET_PHYSICIAN";

	public final static String FILTERBYRES_ID = "RESOURCE";
	public final static String FILTERBYLOC_ID = "LOCATION";
	public final static String LOCCAT_ID = "LOC_CATGORY_FILTER";
	public final static String LOCLOOKUP_ID = "LOCATION_LOOKUP_FILTER";
	public final static String LOCSEARCHFORM_ID = "LOCATION_SEARCH_FORM_POPUP";
	public final static String SLOCMBU_ID = "mbuId";
	public final static String SLOCCAT_ID = "LOC_CATGORY_FILTER";
	public final static String SLOCCODE_ID = "locationCode";
	public final static String SLOCNAME_ID = "locationNameId";
	public final static String LOCSEARCHBTN_ID = "SEARCH_LOCATION";
	public final static String SLOCRESETBTN_XPATH = "//form[@id='LOCATION_SEARCH_FORM_POPUP']//input[@value='Reset']";
	public final static String SLOCGRIDDIV_ID = "SEARCH_RESULT_LOCATION_POPUP";
	public final static String FLOTINGLOCSEARCHBTN_ID = "SEARCH_PATIENT_LOCATION";
	public final static String FLOTINGLOCRESETBTN_ID = "SEARCH_RESET_LOCATION";

	public final static String FILTERBYPAT_ID = "PATIENT";
	public final static String PATLOOKUP_ID = "PATIENT_LOOKUP_FILTER";
	public final static String PATSEARCHFORM_ID = "PATIENT_SEARCH_FID";
	public final static String QUICKSEARCHFIELD_ID = "searchTextName";
	public final static String QUICKSEARCHBTN_ID = "quickSearch";
	public final static String PATSEARCHGRIDDIV_ID = "SEARCH_RESULT";
	public final static String FLOTINGPATSEARCHBTN_ID = "SEARCH_PATIENT_PATIENT";

	public final static String FILTERBYSERV_ID = "SERVICE";
	public final static String SERVLOOKUP_ID = "SERVICE_LOOKUP_FILTER";
	public final static String SERVSEARCHFORM_ID = "SERVICES_SEARCH_FORM_POPUP";
	public final static String SSERVMBU_ID = "mbusId";
	public final static String SSERVDEPT_ID = "deptId";
	public final static String SSERVSPLTY_ID = "specId";
	public final static String SSERVSUBSPLTY_ID = "subSpecId";
	public final static String SSERVTYPE_ID = "serviceTypeId";
	public final static String SSERVCODE_ID = "serviceCodeId";
	public final static String SSERVNAME_ID = "serviceName";
	public final static String SERVSEARCHBTN_ID = "SEARCH_SERVICE";
	public final static String SSERVRESETBTN_XPATH = "//form[@id='SERVICES_SEARCH_FORM_POPUP']//input[@value='Reset']";
	public final static String SSERVGRIDDIV_ID = "SEARCH_RESULT_SERVICE_POPUP";
	public final static String FLOTINGSERVSEARCHBTN_ID = "SEARCH_PATIENT_SERVICE";
	public final static String FLOTINGSERVRESETBTN_ID = "SEARCH_RESET_SERVICE";
	public final static String NURSGRIDTBL_ID = "nursingDeskGridList";

	public final static String PHYSRESGRIDDIV_ID = "SEARCH_RESULT_DIV_GRID";
	private final static String PHYS = "Physician", RES = "Resource",
			LOC = "Location", PAT = "Patient", SERV = "Service";

	public static final String NURMENULINK_XPATH = "//a[contains(text(),'Nursing')]/..//a[text()= 'Nursing Desktop']";
	public static final String TRIAGELINK_XPATH = ".//table[@id='nursingDeskGridList']/..//a[text()='Triage']";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = OPDFORM_ID)
	private WebElement opdForm;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = FROMDATE_ID)
	private WebElement fromDate;

	@FindBy(id = TODATE_ID)
	private WebElement toDate;

	@FindBy(id = OPSEARCHBTN_ID)
	private WebElement opSearchBtn;

	@FindBy(id = OPRESETBTN_ID)
	private WebElement opResetBtn;

	@FindBy(id = SEARCHRESGRIDTBL_ID)
	private WebElement searchResGridTbl;

	@FindBy(id = FILTERCRITBTN_ID)
	private WebElement filterCriteriaBtn;

	@FindBy(id = FLOTINGFILTERCRITDIV_ID)
	private WebElement flotingFilterCriteriaDiv;

	@FindBy(id = FILTERBYPHYS_ID)
	private WebElement filterByPhys;

	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;

	@FindBy(id = PHYSLOOKUP_ID)
	private WebElement physLookup;

	@FindBy(id = PHYSSEARCHFORM_ID)
	private WebElement physSearchForm;

	@FindBy(id = SPHYSMBU_ID)
	private WebElement sPhysMbu;

	@FindBy(id = SPHYSDEPT_ID)
	private WebElement sPhysDept;

	@FindBy(id = SPHYSSPLTY_ID)
	private WebElement sPhysSplty;

	@FindBy(id = SPHYSSUBSPLTY_ID)
	private WebElement sPhysSubSplty;

	@FindBy(id = SPHYSDESIG_ID)
	private WebElement sPhysDesig;

	@FindBy(id = SPHYSNAME_ID)
	private WebElement sPhysName;

	@FindBy(id = SPHYSCODE_ID)
	private WebElement sPhysCode;

	@FindBy(id = SPHYSSEARCHBTN_ID)
	private WebElement sPhysSearchBtn;

	@FindBy(xpath = SPHYSRESETBTN_XPATH)
	private WebElement sPhysResetBtn;

	@FindBy(id = SPHYGRIDDIV_ID)
	private WebElement sPhysGridDiv;

	@FindBy(id = FLOTINGPHYSSEARCHBTN_ID)
	private WebElement flotingPhysSearchBtn;

	@FindBy(id = FLOTINGPHYSRESETBTN_ID)
	private WebElement flotingPhysResetBtn;

	@FindBy(id = FILTERBYRES_ID)
	private WebElement filterByResource;

	@FindBy(id = FILTERBYLOC_ID)
	private WebElement filterByLocation;

	@FindBy(id = LOCCAT_ID)
	private WebElement locationCategory;

	@FindBy(id = LOCLOOKUP_ID)
	private WebElement locationLookup;

	@FindBy(id = LOCSEARCHFORM_ID)
	private WebElement locationSearchForm;

	@FindBy(id = SLOCMBU_ID)
	private WebElement sLocationMbu;

	@FindBy(id = SLOCCAT_ID)
	private WebElement sLocationCategory;

	@FindBy(id = SLOCCODE_ID)
	private WebElement sLocationCode;

	@FindBy(id = SLOCNAME_ID)
	private WebElement sLocationName;

	@FindBy(id = LOCSEARCHBTN_ID)
	private WebElement sLocationSearchBtn;

	@FindBy(xpath = SLOCRESETBTN_XPATH)
	private WebElement sLocationResetBtn;

	@FindBy(id = SLOCGRIDDIV_ID)
	private WebElement sLocationGridDiv;

	@FindBy(id = FLOTINGLOCSEARCHBTN_ID)
	private WebElement flotingLocSearchBtn;

	@FindBy(id = FLOTINGLOCRESETBTN_ID)
	private WebElement flotingLocResetBtn;

	@FindBy(id = FILTERBYPAT_ID)
	private WebElement filterByPatient;

	@FindBy(id = PATLOOKUP_ID)
	private WebElement patLookup;

	@FindBy(id = PATSEARCHFORM_ID)
	private WebElement patSearchForm;

	@FindBy(id = QUICKSEARCHFIELD_ID)
	private WebElement quickSearchField;

	@FindBy(id = QUICKSEARCHBTN_ID)
	private WebElement quickSearchBtn;

	@FindBy(id = PATSEARCHGRIDDIV_ID)
	private WebElement patSearchGridDiv;

	@FindBy(id = FLOTINGPATSEARCHBTN_ID)
	private WebElement flotingPatSearchBtn;

	@FindBy(id = FILTERBYSERV_ID)
	private WebElement filterByService;

	@FindBy(id = SERVLOOKUP_ID)
	private WebElement serviceLookup;

	@FindBy(id = SERVSEARCHFORM_ID)
	private WebElement serviceSearchForm;

	@FindBy(id = SSERVMBU_ID)
	private WebElement sServiceMBU;

	@FindBy(id = SSERVDEPT_ID)
	private WebElement sServiceDept;

	@FindBy(id = SSERVSPLTY_ID)
	private WebElement sServiceSpecialty;

	@FindBy(id = SSERVSUBSPLTY_ID)
	private WebElement sServiceSubSpecialty;

	@FindBy(id = SSERVTYPE_ID)
	private WebElement sServiceType;

	@FindBy(id = SSERVCODE_ID)
	private WebElement sServiceCode;

	@FindBy(id = SSERVNAME_ID)
	private WebElement sServiceName;

	@FindBy(id = SERVSEARCHBTN_ID)
	private WebElement searchServiceBtn;

	@FindBy(xpath = SSERVRESETBTN_XPATH)
	private WebElement sServiceResetBtn;

	@FindBy(id = SSERVGRIDDIV_ID)
	private WebElement sServiceGriidDiv;

	@FindBy(id = FLOTINGSERVSEARCHBTN_ID)
	private WebElement flotingServSearchBtn;

	@FindBy(id = FLOTINGSERVRESETBTN_ID)
	private WebElement flotingServResetBtn;

	@FindBy(id = PHYSRESGRIDDIV_ID)
	private WebElement physResourceGridDiv;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		consultationPage = PageFactory.initElements(webDriver,
				ConsultationPage.class);
		consultationPage.setWebDriver(webDriver);
		consultationPage.setWebDriverWait(webDriverWait);

	}

	public DesktopDataPage clickOnOutpatDesktopMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Appointment Scheduling");
		menuSelector.clickOnTargetMenu(menuList, "Outpatient Desktop");
		DesktopDataPage desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage.setWebDriver(webDriver);
		desktopDataPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return desktopDataPage;
	}

	public DesktopDataPage clickOnDrWorkBenchMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Dr. Workbench");
		menuSelector.clickOnTargetMenu(menuList, "Dr. Desktop");
		DesktopDataPage desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage.setWebDriver(webDriver);
		desktopDataPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return desktopDataPage;
	}

	public DesktopDataPage clickOnNursingDesktopMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Nursing");
		menuSelector.clickOnTargetMenu(menuList, "Nursing Desktop");
		DesktopDataPage desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage.setWebDriver(webDriver);
		desktopDataPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return desktopDataPage;
	}

	public boolean isMandFromDate() {
		waitForElementId(FROMDATE_ID);
		return isMandatoryField(fromDate);
	}

	public String fillSearchCriteria(String[] outPatientListData)
			throws Exception {
		waitForElementId(MBU_ID);
		sleepShort();
		if (!outPatientListData[0].isEmpty()) {
			new Select(mbu).selectByVisibleText(outPatientListData[0]);
		}
		waitForElementId(FROMDATE_ID);
		sleepShort();
		fromDate.clear();
		fromDate.sendKeys(DateTimeConverter.currentISTDateFormat());
		waitForElementId(TODATE_ID);
		sleepShort();
		toDate.clear();
		toDate.sendKeys(DateTimeConverter.currentISTDateFormat());
		return new Select(mbu).getFirstSelectedOption().getText();
	}

	public void quickSearchOutPatients() throws Exception {
		opSearchBtn.click();
		waitForElementId(SEARCHRESGRIDTBL_ID);
		sleepVeryShort();

	}

	public void quickSearchByLoc(String[] outPatientListData) throws Exception {
		waitForElementId(FILTERCRITBTN_ID);
		sleepVeryShort();
		filterCriteriaBtn.click();
		waitForElementId(FLOTINGFILTERCRITDIV_ID);
		sleepVeryShort();
		if (LOC.equals(outPatientListData[3])) {
			filterByLocation.click();
			if (!outPatientListData[4].isEmpty()) {
				new Select(sLocationCategory)
						.selectByVisibleText(outPatientListData[4]);
			}
			flotingLocSearchBtn.click();
		}

	}

	public void searchOutPatientsByLocation(String[] outPatientListData)
			throws Exception {
		waitForElementId(FILTERCRITBTN_ID);
		sleepVeryShort();
		filterCriteriaBtn.click();
		waitForElementId(FLOTINGFILTERCRITDIV_ID);
		sleepVeryShort();
		if (LOC.equals(outPatientListData[3])) {
			filterByLocation.click();
			waitForElementId(LOCLOOKUP_ID);
			sleepVeryShort();
			locationLookup.click();
			waitForElementId(LOCSEARCHFORM_ID);
			sleepVeryShort();
			if (!outPatientListData[4].isEmpty()) {
				new Select(sLocationCategory)
						.selectByVisibleText(outPatientListData[4]);
			}
			sLocationCode.clear();
			sLocationCode.sendKeys(outPatientListData[5]);
			sLocationName.clear();
			sLocationName.sendKeys(outPatientListData[6]);
			sLocationSearchBtn.click();
			waitForElementId(SLOCGRIDDIV_ID);
			sleepVeryShort();
			clickOnGridAction("locationSearchGridList_locationName",
					outPatientListData[6], "Select");
			flotingLocSearchBtn.click();
		}

	}

	public void searchOutPatientsByPhysician(String[] outPatientListData)
			throws Exception {
		waitForElementId(FILTERCRITBTN_ID);
		sleepVeryShort();
		filterCriteriaBtn.click();
		waitForElementId(FLOTINGFILTERCRITDIV_ID);
		sleepVeryShort();
		if (PHYS.equals(outPatientListData[7])) {
			filterByPhys.click();
			waitForElementId(PHYSLOOKUP_ID);
			physLookup.click();
			sleepShort();
			waitForElementId(PHYSSEARCHFORM_ID);
			if (!outPatientListData[8].isEmpty()) {
				new Select(sPhysDept)
						.selectByVisibleText(outPatientListData[8]);
			}
			waitForElementId(SPHYSSPLTY_ID);
			sleepVeryShort();
			if (!outPatientListData[9].isEmpty()) {
				new Select(sPhysSplty)
						.selectByVisibleText(outPatientListData[9]);
			}
			waitForElementId(SPHYSSUBSPLTY_ID);
			sleepVeryShort();
			if (!outPatientListData[10].isEmpty()) {
				new Select(sPhysSubSplty)
						.selectByVisibleText(outPatientListData[10]);
			}
			waitForElementId(SPHYSDESIG_ID);
			if (!outPatientListData[11].isEmpty()) {
				new Select(sPhysDesig)
						.selectByVisibleText(outPatientListData[11]);
			}
			sPhysName.clear();
			sPhysName.sendKeys(outPatientListData[12]);

			sPhysCode.clear();
			sPhysCode.sendKeys(outPatientListData[13]);
			sPhysSearchBtn.click();
			waitForElementId(SPHYGRIDDIV_ID);
			sleepVeryShort();
			clickOnGridAction("physicianSearchGridList_resourceName.fullName",
					outPatientListData[12], "Select");
			flotingPhysSearchBtn.click();

		}

	}

	public void searchOutPatientsByPatient(String[] outPatientListData)
			throws Exception {
		waitForElementId(FILTERCRITBTN_ID);
		sleepVeryShort();
		filterCriteriaBtn.click();
		sleepShort();
		waitForElementId(FLOTINGFILTERCRITDIV_ID);
		sleepShort();
		if (PAT.equals(outPatientListData[14])) {
			waitForElementId(FILTERBYPAT_ID);
			filterByPatient.click();
			patLookup.click();
			waitForElementId(PATSEARCHFORM_ID);
			sleepVeryShort();
			quickSearchField.clear();
			quickSearchField.sendKeys(outPatientListData[15]);
			quickSearchBtn.click();
			waitForElementId(PATSEARCHGRIDDIV_ID);
			sleepVeryShort();
			clickOnGridAction(outPatientListData[15], "Select");
			flotingPatSearchBtn.click();
		}

	}

	public void searchOutPatientsByService(String[] outPatientListData)
			throws Exception {
		waitForElementId(FILTERCRITBTN_ID);
		sleepVeryShort();
		filterCriteriaBtn.click();
		waitForElementId(FLOTINGFILTERCRITDIV_ID);
		sleepVeryShort();
		if (SERV.equals(outPatientListData[16])) {
			filterByService.click();
			waitForElementId(SERVLOOKUP_ID);
			sleepVeryShort();
			serviceLookup.click();
			waitForElementId(SERVSEARCHFORM_ID);
			sleepShort();
			if (!outPatientListData[17].isEmpty()) {
				new Select(sServiceDept)
						.selectByVisibleText(outPatientListData[17]);
			}
			waitForElementId(SSERVSPLTY_ID);
			sleepVeryShort();
			if (!outPatientListData[18].isEmpty()) {
				new Select(sServiceSpecialty)
						.selectByVisibleText(outPatientListData[18]);
			}
			waitForElementId(SSERVSUBSPLTY_ID);
			sleepVeryShort();
			if (!outPatientListData[19].isEmpty()) {
				new Select(sServiceSubSpecialty)
						.selectByVisibleText(outPatientListData[19]);
			}
			waitForElementId(SSERVTYPE_ID);
			sleepVeryShort();
			if (!outPatientListData[20].isEmpty()) {
				new Select(sServiceType)
						.selectByVisibleText(outPatientListData[20]);
			}
			sServiceCode.clear();
			sServiceCode.sendKeys(outPatientListData[21]);
			sServiceName.clear();
			sServiceName.sendKeys(outPatientListData[22]);
			searchServiceBtn.click();
			waitForElementId(SSERVGRIDDIV_ID);
			sleepVeryShort();
			clickOnGridAction("serviceSearchGridList_serviceName",
					outPatientListData[22], "Select");
			flotingServSearchBtn.click();

		}

	}

	public boolean checkGridData(String tblId, String outPatientListData)
			throws Exception {
		sleepMedium();
		waitForElementXpathExpression("//table[@id='"
				+ tblId
				+ "']//tr//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),  '"
				+ outPatientListData + "')]");
		sleepShort();
		return webDriver
				.findElement(
						By.xpath("//table[@id='"
								+ tblId
								+ "']//tr//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),  '"
								+ outPatientListData + "')]")).isDisplayed();

	}

	public void clickOnTriageLink(String[] outPatientListData) throws Exception {
		parentWindowHandle = webDriver.getWindowHandle();
		clickOnGridAction("nursingDeskGridList_pateintName",
				outPatientListData[15], "Triage");
		for (String winHandle : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(winHandle);
		}
		waitForElementId(TriagePage.TRIAGEFORM_ID);
		waitForElementId(TriagePage.SAVEBTN_ID);
		sleepShort();
	}

	public EncounterPage clickOnEncounterLink(String pateintName)
			throws Exception {
		parentWindowHandle = webDriver.getWindowHandle();
		clickOnGridAction(pateintName.trim(), "Encounter");
		for (String winHandle : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(winHandle);
		}
		waitForElementId(EncounterPage.FORM_ID);
		waitForElementXpathExpression(EncounterPage.SAVEBUTTON_XPATH);
		EncounterPage encounterPage = PageFactory.initElements(webDriver,
				EncounterPage.class);
		encounterPage.setWebDriver(webDriver);
		encounterPage.setWebDriverWait(webDriverWait);
		return encounterPage;
	}

	public String clickOnConsultationLink(String[] outPatientListData)
			throws Exception {
		parentWindowHandle = webDriver.getWindowHandle();
		clickOnGridAction("drDeskGridList_pateintName", outPatientListData[15],
				"Consultation");
		for (String winHandle : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(winHandle);
		}
		waitForPageLoaded(webDriver);
		waitForElementId(ConsultationPage.PAGETITLE_ID);
		sleepShort();
		return pageTitle.getText();

	}

	public ConsultationPage getConsultationPage() {
		return consultationPage;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getOpdForm() {
		return opdForm;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getFromDate() {
		return fromDate;
	}

	public WebElement getToDate() {
		return toDate;
	}

	public WebElement getOpSearchBtn() {
		return opSearchBtn;
	}

	public WebElement getOpResetBtn() {
		return opResetBtn;
	}

	public WebElement getSearchResGridTbl() {
		return searchResGridTbl;
	}

	public WebElement getFilterCriteriaBtn() {
		return filterCriteriaBtn;
	}

	public WebElement getFlotingFilterCriteriaDiv() {
		return flotingFilterCriteriaDiv;
	}

	public WebElement getFilterByPhys() {
		return filterByPhys;
	}

	public WebElement getSpecialty() {
		return specialty;
	}

	public WebElement getPhysLookup() {
		return physLookup;
	}

	public WebElement getPhysSearchForm() {
		return physSearchForm;
	}

	public WebElement getsPhysMbu() {
		return sPhysMbu;
	}

	public WebElement getsPhysDept() {
		return sPhysDept;
	}

	public WebElement getsPhysSplty() {
		return sPhysSplty;
	}

	public WebElement getsPhysSubSplty() {
		return sPhysSubSplty;
	}

	public WebElement getsPhysDesig() {
		return sPhysDesig;
	}

	public WebElement getsPhysName() {
		return sPhysName;
	}

	public WebElement getsPhysCode() {
		return sPhysCode;
	}

	public WebElement getsPhysSearchBtn() {
		return sPhysSearchBtn;
	}

	public WebElement getsPhysResetBtn() {
		return sPhysResetBtn;
	}

	public WebElement getsPhysGridDiv() {
		return sPhysGridDiv;
	}

	public WebElement getFlotingPhysSearchBtn() {
		return flotingPhysSearchBtn;
	}

	public WebElement getFlotingPhysResetBtn() {
		return flotingPhysResetBtn;
	}

	public WebElement getFilterByResource() {
		return filterByResource;
	}

	public WebElement getFilterByLocation() {
		return filterByLocation;
	}

	public WebElement getLocationCategory() {
		return locationCategory;
	}

	public WebElement getLocationLookup() {
		return locationLookup;
	}

	public WebElement getLocationSearchForm() {
		return locationSearchForm;
	}

	public WebElement getsLocationMbu() {
		return sLocationMbu;
	}

	public WebElement getsLocationCategory() {
		return sLocationCategory;
	}

	public WebElement getsLocationCode() {
		return sLocationCode;
	}

	public WebElement getsLocationName() {
		return sLocationName;
	}

	public WebElement getsLocationSearchBtn() {
		return sLocationSearchBtn;
	}

	public WebElement getsLocationResetBtn() {
		return sLocationResetBtn;
	}

	public WebElement getsLocationGridDiv() {
		return sLocationGridDiv;
	}

	public WebElement getFlotingLocSearchBtn() {
		return flotingLocSearchBtn;
	}

	public WebElement getFlotingLocResetBtn() {
		return flotingLocResetBtn;
	}

	public WebElement getFilterByPatient() {
		return filterByPatient;
	}

	public WebElement getPatLookup() {
		return patLookup;
	}

	public WebElement getPatSearchForm() {
		return patSearchForm;
	}

	public WebElement getQuickSearchField() {
		return quickSearchField;
	}

	public WebElement getQuickSearchBtn() {
		return quickSearchBtn;
	}

	public WebElement getPatSearchGridDiv() {
		return patSearchGridDiv;
	}

	public WebElement getFlotingPatSearchBtn() {
		return flotingPatSearchBtn;
	}

	public WebElement getFilterByService() {
		return filterByService;
	}

	public WebElement getServiceLookup() {
		return serviceLookup;
	}

	public WebElement getServiceSearchForm() {
		return serviceSearchForm;
	}

	public WebElement getsServiceMBU() {
		return sServiceMBU;
	}

	public WebElement getsServiceDept() {
		return sServiceDept;
	}

	public WebElement getsServiceSpecialty() {
		return sServiceSpecialty;
	}

	public WebElement getsServiceSubSpecialty() {
		return sServiceSubSpecialty;
	}

	public WebElement getsServiceType() {
		return sServiceType;
	}

	public WebElement getsServiceCode() {
		return sServiceCode;
	}

	public WebElement getsServiceName() {
		return sServiceName;
	}

	public WebElement getSearchServiceBtn() {
		return searchServiceBtn;
	}

	public WebElement getsServiceResetBtn() {
		return sServiceResetBtn;
	}

	public WebElement getsServiceGriidDiv() {
		return sServiceGriidDiv;
	}

	public WebElement getFlotingServSearchBtn() {
		return flotingServSearchBtn;
	}

	public WebElement getFlotingServResetBtn() {
		return flotingServResetBtn;
	}

	public WebElement getPhysResourceGridDiv() {
		return physResourceGridDiv;
	}

}
