package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.itemdetails.ItemFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.itemdetails.ItemGeneralDetails;
import com.atk.himma.pageobjects.mbuadmin.tabs.ItemListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ItemPage extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	private ItemListTab itemListTab;
	private ItemFirstSection itemFirstSection;
	private ItemGeneralDetails itemGeneralDetails;

	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Updated successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Record activated successfully')]";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Item']";

	@FindBy(xpath = DETAILSADDNEWBUTTON_XPATH)
	private WebElement addNewButton;

	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;

	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;

	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;

	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement itemDetailsPageTitle;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;

	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		itemListTab = PageFactory.initElements(webDriver, ItemListTab.class);
		itemListTab.setWebDriver(webDriver);
		itemListTab.setWebDriverWait(webDriverWait);

		itemFirstSection = PageFactory.initElements(webDriver,
				ItemFirstSection.class);
		itemFirstSection.setWebDriver(webDriver);
		itemFirstSection.setWebDriverWait(webDriverWait);

		itemGeneralDetails = PageFactory.initElements(webDriver,
				ItemGeneralDetails.class);
		itemGeneralDetails.setWebDriver(webDriver);
		itemGeneralDetails.setWebDriverWait(webDriverWait);

	}

	public ItemPage clickOnItemMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Item");
		ItemPage itemPage = PageFactory.initElements(webDriver, ItemPage.class);
		itemPage.setWebDriver(webDriver);
		itemPage.setWebDriverWait(webDriverWait);
		return itemPage;
	}

	public boolean clickOnAddNewItem(String[] itemDatas)
			throws InterruptedException {
		waitForElementXpathExpression(ItemListTab.ADDNEWITEMBUTTON_XPATH);
		sleepVeryShort();
		itemListTab.getAddNewItemButton().click();
		waitForElementId(ItemFirstSection.MBU_ID);
		sleepVeryShort();
		return new Select(itemFirstSection.getMbu()).getFirstSelectedOption()
				.getText().trim().equals(itemDatas[0].trim());
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		return detailsUpdateButton.getAttribute("value").trim();

	}

	public boolean saveDuplicateData(String[] itemDatas)
			throws InterruptedException, IOException {
		try {
			waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
			detailsSaveButton.click();
			new WebDriverWait(webDriver, shortTimeInterval)
					.until(ExpectedConditions.presenceOfElementLocated(By
							.xpath(DETAILSUPDATEBUTTON_XPATH)));
			sleepVeryShort();
			return false;
		} catch (Exception e) {
			return searchData(itemDatas).equals(itemDatas[9].trim());
		}
	}

	public String searchData(String[] itemDatas) {
		waitForElementXpathExpression(ItemListTab.ITEMLISTTAB_XPATH);
		itemListTab.getItemListTab().click();
		waitForElementId(ItemListTab.GRID_ID);
		itemListTab.getItemName().clear();
		itemListTab.getItemName().sendKeys(itemDatas[9].trim());
		itemListTab.getSearchButton().click();
		return waitForGridFirstDuplicateCellText(ItemListTab.GRID_ID,
				ItemListTab.GRID_ITEMNAME_ARIA_DESCRIBEDBY);
	}

	public String searchItemPage(String itemName) throws InterruptedException,
			IOException {
		waitForElementXpathExpression(ItemListTab.SEARCHBUTTON_XPATH);
		itemListTab.getItemName().clear();
		itemListTab.getItemName().sendKeys(itemName.trim());
		itemListTab.getSearchButton().click();
		waitForElementId(ItemListTab.GRID_ID);
		waitForGridSearchText(itemName.trim());
		sleepVeryShort();
		return waitAndGetGridFirstCellText(ItemListTab.GRID_ID,
				ItemListTab.GRID_ITEMNAME_ARIA_DESCRIBEDBY, itemName.trim())
				.trim();
	}

	public String activateItem() throws InterruptedException, IOException {

		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);

	}

	public void clickClinicListTab() throws InterruptedException {
		waitForElementId(ItemFirstSection.MBU_ID);
		itemListTab.getItemListTab().click();
		waitForElementXpathExpression(ItemListTab.SEARCHBUTTON_XPATH);
		sleepVeryShort();
	}

	/**
	 * @return the itemListTab
	 */
	public ItemListTab getItemListTab() {
		return itemListTab;
	}

	/**
	 * @return the itemFirstSection
	 */
	public ItemFirstSection getItemFirstSection() {
		return itemFirstSection;
	}

	/**
	 * @return the itemGeneralDetails
	 */
	public ItemGeneralDetails getItemGeneralDetails() {
		return itemGeneralDetails;
	}

	/**
	 * @return the itemDetailsPageTitle
	 */
	public WebElement getItemDetailsPageTitle() {
		return itemDetailsPageTitle;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	// public String searchService(String[] serviceDatas) throws
	// InterruptedException {
	// waitForElementId(ServiceListTab.MBU_ID);
	// new Select(serviceListTab.getMbu()).selectByVisibleText(serviceDatas[0]);
	// serviceListTab.getServiceName().clear();
	// serviceListTab.getServiceName().sendKeys(serviceDatas[4]);
	// new
	// Select(serviceListTab.getStatus()).selectByVisibleText(serviceDatas[8]);
	// serviceListTab.getSearchButton().click();
	// waitForElementId(ServiceListTab.GRID_ID);
	// sleepShort();
	// return waitAndGetGridFirstCellText(ServiceListTab.GRID_ID,
	// ServiceListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serviceDatas[4]);
	// }
}
