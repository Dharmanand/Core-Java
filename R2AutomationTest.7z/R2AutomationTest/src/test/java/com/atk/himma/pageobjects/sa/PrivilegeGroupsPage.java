package com.atk.himma.pageobjects.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.tabs.PrivilegeGroupInformationTab;
import com.atk.himma.pageobjects.sa.tabs.PrivilegeGroupListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class PrivilegeGroupsPage extends DriverWaitClass implements
		StatusMessages {
	private PrivilegeGroupListTab privilegeGroupListTab;
	private PrivilegeGroupInformationTab privilegeGroupInformationTab;

	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Privilege Groups')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String PRIVGRPSLISTTAB_XPATH = "//a[@title='Privilege Group List']";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;
	
	@FindBy(xpath = PRIVGRPSLISTTAB_XPATH)
	private WebElement privGrpsListTab;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		this.webDriver = webDriver;
		this.webDriverWait = webDriverWait;
		
		privilegeGroupListTab = PageFactory.initElements(webDriver,
				PrivilegeGroupListTab.class);
		privilegeGroupListTab.setWebDriver(webDriver);
		privilegeGroupListTab.setWebDriverWait(webDriverWait);

		privilegeGroupInformationTab = PageFactory.initElements(webDriver,
				PrivilegeGroupInformationTab.class);
		privilegeGroupInformationTab.setWebDriver(webDriver);
		privilegeGroupInformationTab.setWebDriverWait(webDriverWait);
	}

	public PrivilegeGroupsPage clickOnPrivilegeGroupsMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("System Administration");
		menuSelector.clickOnTargetMenu(menuList, "Privilege Groups");
		PrivilegeGroupsPage privilegeGroupsPage = PageFactory.initElements(
				webDriver, PrivilegeGroupsPage.class);
		privilegeGroupsPage.setWebDriver(webDriver);
		privilegeGroupsPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return privilegeGroupsPage;
	}

	/*public String searchJobName(String privGrpName) throws InterruptedException
	{
		waitForElementId(PrivilegeGroupListTab.PRIVGROUPNAME_ID);
		sleepVeryShort();
		privilegeGroupListTab.searchGridData(privGrpName);
		return waitAndGetGridFirstCellText(PrivilegeGroupListTab.GRID_ID, PrivilegeGroupListTab.GRID_PRIVGRPNAME_ARIA_DESCRIBEDBY, privGrpName);
	}*/
	
	public PrivilegeGroupListTab getPrivilegeGroupListTab() {
		return privilegeGroupListTab;
	}

	public PrivilegeGroupInformationTab getPrivilegeGroupInformationTab() {
		return privilegeGroupInformationTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the privGrpsListTab
	 */
	public WebElement getPrivGrpsListTab() {
		return privGrpsListTab;
	}

}
