package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ResultingAttributesSec extends DriverWaitClass {
	public final static String RESATTRSEC_XPATH = "//a[text()='Resulting Attributes']";
	@FindBy(xpath = RESATTRSEC_XPATH)
	private WebElement resAttrSec;

	public final static String REPORTFORMAT_NAME = "labTest.reportFormatId";
	@FindBy(name = REPORTFORMAT_NAME)
	private WebElement reportFormat;

	public final static String REPORTON_NAME = "labTest.reportOnId";
	@FindBy(name = REPORTON_NAME)
	private WebElement reportOn;

	public final static String METHOD_NAME = "labTest.methodId";
	@FindBy(name = METHOD_NAME)
	private WebElement method;

	public final static String ADDRESDTLBTN_ID = "LAB_TEST_RESULT_ATTR_ADD_RESULT_BUT";
	@FindBy(id = ADDRESDTLBTN_ID)
	private WebElement addResDtlBtn;

	public final static String RESDTLFORMPOPUP_ID = "LAB_TEST_RESULT_DETAIL_FORM";
	@FindBy(id = RESDTLFORMPOPUP_ID)
	private WebElement resDtlFormPopUp;

	public final static String RESDTLPOPUP_RESTYPE_ID = "LAB_TEST_RESULT_TYPE_ID";
	@FindBy(id = RESDTLPOPUP_RESTYPE_ID)
	private WebElement resDtlPopUpResType;

	public final static String RESMAND_ID = "MANDATORY_RESULT";
	@FindBy(id = RESMAND_ID)
	private WebElement resMandatory;

	public final static String RESDTLSPECIMEN_ID = "LAB_TEST_RESULT_DETAIL_SPECIMEN_ID";
	@FindBy(id = RESDTLSPECIMEN_ID)
	private WebElement resDtlSpecimen;

	public final static String RESDTLSUBPARAM_ID = "LAB_TEST_RESULT_DETAIL_SUB_PARAMETER_ID";
	@FindBy(id = RESDTLSUBPARAM_ID)
	private WebElement resDtlSubParam;

	public final static String RESDTLSTAB_XPATH = "//a[@title='Result Details']";
	@FindBy(xpath = RESDTLSTAB_XPATH)
	private WebElement resDtlsTab;

	public final static String REFLEXTESTTAB_XPATH = "//a[@title='Reflex Test']";
	@FindBy(xpath = REFLEXTESTTAB_XPATH)
	private WebElement reflexTestTab;

	public final static String DELTACHECKTAB_XPATH = "//a[@title='Delta Check']";
	@FindBy(xpath = DELTACHECKTAB_XPATH)
	private WebElement deltaCheckTab;

	public final static String AUTOVERIFTAB_XPATH = "//a[@title='Auto Verification']";
	@FindBy(xpath = AUTOVERIFTAB_XPATH)
	private WebElement autoVerifTab;

	public final static String AVAILRESULTDTLSPAN_ID = "prevGrpsHolder";
	@FindBy(id = AVAILRESULTDTLSPAN_ID)
	private WebElement availResultDtlsSpan;

	public final static String AVAILTOASSIGNBTN_ID = "LAB_TEST_CODED_DETAIL_ORG_SRC_BUTTON";
	@FindBy(id = AVAILTOASSIGNBTN_ID)
	private WebElement availToAassignBtn;

	public final static String ASSIGNTOAVAILBTN_ID = "LAB_TEST_CODED_DETAIL_ORG_DEST_BUTTON";
	@FindBy(id = ASSIGNTOAVAILBTN_ID)
	private WebElement assignToAvailBtn;

	public final static String RESULTSUBMITBTN_XPATH = "//form[@id='LAB_TEST_RESULT_DETAIL_FORM']//input[@value='Submit']";
	@FindBy(xpath = RESULTSUBMITBTN_XPATH)
	private WebElement resultSubmitBtn;

	public final static String RESULTCANCELBTN_XPATH = "//form[@id='LAB_TEST_RESULT_DETAIL_FORM']//input[@value='Cancel']";
	@FindBy(xpath = RESULTCANCELBTN_XPATH)
	private WebElement resultCancelBtn;

	public final static String REFLEXTESTADDROWBTN_ID = "LAB_TEST_RESULT_REFLEX_TEST_ADD_ROW_BUTTON";
	@FindBy(id = REFLEXTESTADDROWBTN_ID)
	private WebElement reflexTestAddRowBtn;

	public final static String REFLEXCHECKING_NAME = "checkId";
	@FindBy(name = REFLEXCHECKING_NAME)
	private WebElement reflexChecking;

	public final static String CONDITION_NAME = "conditionText";
	@FindBy(name = CONDITION_NAME)
	private WebElement condition;

	public final static String OTHER_NAME = "otherId";
	@FindBy(name = OTHER_NAME)
	private WebElement other;

	public final static String SERVICE_NAME = "serviceName";
	@FindBy(name = SERVICE_NAME)
	private WebElement service;

	public final static String GENDER_NAME = "genderId";
	@FindBy(name = GENDER_NAME)
	private WebElement gender;

	public final static String STARTAGEVAL_NAME = "startAge.ageInDays";
	@FindBy(name = STARTAGEVAL_NAME)
	private WebElement startAgeVal;

	public final static String STARTAGEUNIT_NAME = "startAge.ageType";
	@FindBy(name = STARTAGEUNIT_NAME)
	private WebElement startAgeUnit;

	public final static String ENDAGEVAL_NAME = "endAge.ageInDays";
	@FindBy(name = ENDAGEVAL_NAME)
	private WebElement endAgeVal;

	public final static String ENDAGEUNIT_NAME = "endAge.ageType";
	@FindBy(name = ENDAGEUNIT_NAME)
	private WebElement endAgeUnit;

	public final static String GLOBALSERVCHKBOX_ID = "REFLEX_MBU_ID";
	@FindBy(id = GLOBALSERVCHKBOX_ID)
	private WebElement globalServChkBox;

	public final static String REFLEXMBU_ID = "REFLEX_GLOBAL_SERVICE_SEARCH";
	@FindBy(id = REFLEXMBU_ID)
	private WebElement reflexMBU;

	public final static String REFLEXDEPT_ID = "REFLEX_DEPT_ID";
	@FindBy(id = REFLEXDEPT_ID)
	private WebElement reflexDept;

	public final static String REFLEXSPEC_ID = "REFLEX_SPEC_ID";
	@FindBy(id = REFLEXSPEC_ID)
	private WebElement reflexSpec;

	public final static String REFLEXSUBSPEC_ID = "REFLEX_SUB_SPEC_ID";
	@FindBy(id = REFLEXSUBSPEC_ID)
	private WebElement reflexSubSpec;

	public final static String REFLEXSERVTYPE_ID = "REFLEX_SERVICE_TYPE_ID";
	@FindBy(id = REFLEXSERVTYPE_ID)
	private WebElement reflexServType;

	public final static String REFLEXSERVCODE_ID = "REFLEX_SERVICE_CODE_ID";
	@FindBy(id = REFLEXSERVCODE_ID)
	private WebElement reflexServCode;

	public final static String REFLEXSERVNAME_ID = "REFLEX_SERVICE_NAME_ID";
	@FindBy(id = REFLEXSERVNAME_ID)
	private WebElement reflexServName;

	public final static String REFLEXSERVSEARCHBTN_ID = "LAB_TEST_RESULT_ATTR_REFLEX_SERVICE_SRCG_BUT";
	@FindBy(id = REFLEXSERVSEARCHBTN_ID)
	private WebElement reflexServSearchBtn;

	public final static String REFLEXSERVRESETBTN_XPATH = "//div[@id='LAB_RESULT_REFLEX_ADD_SERVICE']//input[@value='Reset']";
	@FindBy(xpath = REFLEXSERVRESETBTN_XPATH)
	private WebElement reflexServResetBtn;

	public final static String REFLEXSERVCANCELBTN_ID = "LAB_TEST_RESULT_ATTR_REFLEX_SERVICE_CANCEL_BUT";
	@FindBy(id = REFLEXSERVCANCELBTN_ID)
	private WebElement reflexServCancelBtn;

	public final static String SERVRESULTGRIDTBL_ID = "LAB_TEST_RESULT_ATTR_SERVICE_RESULT_GRID";
	@FindBy(id = SERVRESULTGRIDTBL_ID)
	private WebElement servResultGridTbl;

	public final static String CANCELRESDTLSBTN_XPATH = "//form[@id='LAB_TEST_RESULT_DETAIL_FORM']//span[@class='buttoncontainer_vlrg_rgt']//input[@class='input_cancel']";
	@FindBy(xpath = CANCELRESDTLSBTN_XPATH)
	private WebElement cancelResDtlsBtn;

	public final static String RESULTDESC_ID = "RESULT_DESCRIPTION_ID";
	@FindBy(id = RESULTDESC_ID)
	private WebElement resultDesc;

	public final static String ADDUPDATELONGTXTBTN_ID = "LONG_TEXT_RESULT_ADD_EDIT_BUT";
	@FindBy(id = ADDUPDATELONGTXTBTN_ID)
	private WebElement addUpdateLongTxtBtn;

	public final static String LONGTXTGRIDTBL_ID = "LAB_TEST_RESULT_ATTR_LONG_TEXT_GRID";
	@FindBy(id = LONGTXTGRIDTBL_ID)
	private WebElement longTxtGridTbl;

	public final static String RESULTINGUOM_NAME = "resultAttribute.numericResultDetail.uomId";
	@FindBy(name = RESULTINGUOM_NAME)
	private WebElement resultingUOM;

	public final static String MAXDIGITS_NAME = "resultAttribute.numericResultDetail.maxDigit";
	@FindBy(name = MAXDIGITS_NAME)
	private WebElement maxDigits;

	public final static String MAXDECIMAL_NAME = "resultAttribute.numericResultDetail.maxDecimal";
	@FindBy(name = MAXDECIMAL_NAME)
	private WebElement maxDecimal;

	public final static String ADDREFBTN_NAME = "LAB_TEST_RESULT_ADD_REFERENCE";
	@FindBy(name = ADDREFBTN_NAME)
	private WebElement addRefBtn;

	public final static String REFGENDER_ID = "REFERECNCE_RANGE_GENDER";
	@FindBy(id = REFGENDER_ID)
	private WebElement refGender;

	public final static String REFSTARTAGE_ID = "NUMERIC_START_DAY_VAL";
	@FindBy(id = REFSTARTAGE_ID)
	private WebElement refStartingAge;

	public final static String REFSTARTAGETYPE_ID = "NUMERIC_START_DAY_TYPE";
	@FindBy(id = REFSTARTAGETYPE_ID)
	private WebElement refStartAgeType;

	public final static String REFENDAGE_ID = "NUMERIC_END_DAY_VAL";
	@FindBy(id = REFENDAGE_ID)
	private WebElement refEndAge;

	public final static String REFENDAGETYPE_ID = "NUMERIC_END_DAY_TYPE";
	@FindBy(id = REFENDAGETYPE_ID)
	private WebElement refEndAgeType;

	public final static String REFRANGEADDBTN_ID = "LAB_TEST_RESULT_RANGES_ADD_ROW_BUTTON";
	@FindBy(id = REFRANGEADDBTN_ID)
	private WebElement refRangeAddBtn;

	public final static String REFRANGEOPERATOR_NAME = "refRangeOperatorId";
	@FindBy(name = REFRANGEOPERATOR_NAME)
	private WebElement refRangeOperator;

	public final static String LOW_NAME = "low";
	@FindBy(name = LOW_NAME)
	private WebElement low;

	public final static String HIGH_NAME = "high";
	@FindBy(name = HIGH_NAME)
	private WebElement high;

	public final static String INDICATOR_NAME = "indicatorId";
	@FindBy(name = INDICATOR_NAME)
	private WebElement indicator;

	public final static String AUTOREMARKS_NAME = "autoRemarks";
	@FindBy(name = AUTOREMARKS_NAME)
	private WebElement autoRemarks;

	public final static String RANGESGRIDTBL_ID = "LAB_TEST_RESULT_ATTR_RANGES_GRID";
	@FindBy(id = RANGESGRIDTBL_ID)
	private WebElement rangesGridTbl;

	public final static String ADDTOREFBTN_ID = "LAB_TEST_RESULT_ATTR_ADD_REFERENCE_BUT";
	@FindBy(id = ADDTOREFBTN_ID)
	private WebElement addToRefBtn;

	public final static String CANCELREFBTN_ID = "LAB_TEST_RESULT_ATTR_CANCEL_REFERENCE_BUT";
	@FindBy(id = CANCELREFBTN_ID)
	private WebElement cancelRefBtn;

	public final static String REFGRIDTBL_ID = "LAB_TEST_RESULT_ATTR_REFERENCE_GRID";
	@FindBy(id = REFGRIDTBL_ID)
	private WebElement REFGRIDTBL;

	public final static String RESATTRGRIDTBL_ID = "LAB_TEST_RESULT_ATTRIBUTE_GRID";
	@FindBy(id = RESATTRGRIDTBL_ID)
	private WebElement resAttrGridTbl;

	public WebElement getResAttrSec() {
		return resAttrSec;
	}

	public WebElement getReportFormat() {
		return reportFormat;
	}

	public WebElement getReportOn() {
		return reportOn;
	}

	public WebElement getMethod() {
		return method;
	}

	public WebElement getAddResDtlBtn() {
		return addResDtlBtn;
	}

	public WebElement getResDtlFormPopUp() {
		return resDtlFormPopUp;
	}

	public WebElement getResDtlPopUpResType() {
		return resDtlPopUpResType;
	}

	public WebElement getResMandatory() {
		return resMandatory;
	}

	public WebElement getResDtlSpecimen() {
		return resDtlSpecimen;
	}

	public WebElement getResDtlSubParam() {
		return resDtlSubParam;
	}

	public WebElement getResDtlsTab() {
		return resDtlsTab;
	}

	public WebElement getReflexTestTab() {
		return reflexTestTab;
	}

	public WebElement getDeltaCheckTab() {
		return deltaCheckTab;
	}

	public WebElement getAutoVerifTab() {
		return autoVerifTab;
	}

	public WebElement getAvailResultDtlsSpan() {
		return availResultDtlsSpan;
	}

	public WebElement getAvailToAassignBtn() {
		return availToAassignBtn;
	}

	public WebElement getAssignToAvailBtn() {
		return assignToAvailBtn;
	}

	public WebElement getResultSubmitBtn() {
		return resultSubmitBtn;
	}

	public WebElement getResultCancelBtn() {
		return resultCancelBtn;
	}

	public WebElement getReflexTestAddRowBtn() {
		return reflexTestAddRowBtn;
	}

	public WebElement getReflexChecking() {
		return reflexChecking;
	}

	public WebElement getCondition() {
		return condition;
	}

	public WebElement getOther() {
		return other;
	}

	public WebElement getService() {
		return service;
	}

	public WebElement getGender() {
		return gender;
	}

	public WebElement getStartAgeVal() {
		return startAgeVal;
	}

	public WebElement getStartAgeUnit() {
		return startAgeUnit;
	}

	public WebElement getEndAgeVal() {
		return endAgeVal;
	}

	public WebElement getEndAgeUnit() {
		return endAgeUnit;
	}

	public WebElement getGlobalServChkBox() {
		return globalServChkBox;
	}

	public WebElement getReflexMBU() {
		return reflexMBU;
	}

	public WebElement getReflexDept() {
		return reflexDept;
	}

	public WebElement getReflexSpec() {
		return reflexSpec;
	}

	public WebElement getReflexSubSpec() {
		return reflexSubSpec;
	}

	public WebElement getReflexServType() {
		return reflexServType;
	}

	public WebElement getReflexServCode() {
		return reflexServCode;
	}

	public WebElement getReflexServName() {
		return reflexServName;
	}

	public WebElement getReflexServSearchBtn() {
		return reflexServSearchBtn;
	}

	public WebElement getReflexServResetBtn() {
		return reflexServResetBtn;
	}

	public WebElement getReflexServCancelBtn() {
		return reflexServCancelBtn;
	}

	public WebElement getServResultGridTbl() {
		return servResultGridTbl;
	}

	public WebElement getCancelResDtlsBtn() {
		return cancelResDtlsBtn;
	}

	public WebElement getResultDesc() {
		return resultDesc;
	}

	public WebElement getAddUpdateLongTxtBtn() {
		return addUpdateLongTxtBtn;
	}

	public WebElement getLongTxtGridTbl() {
		return longTxtGridTbl;
	}

	public WebElement getResultingUOM() {
		return resultingUOM;
	}

	public WebElement getMaxDigits() {
		return maxDigits;
	}

	public WebElement getMaxDecimal() {
		return maxDecimal;
	}

	public WebElement getAddRefBtn() {
		return addRefBtn;
	}

	public WebElement getRefGender() {
		return refGender;
	}

	public WebElement getRefStartingAge() {
		return refStartingAge;
	}

	public WebElement getRefStartAgeType() {
		return refStartAgeType;
	}

	public WebElement getRefEndAge() {
		return refEndAge;
	}

	public WebElement getRefEndAgeType() {
		return refEndAgeType;
	}

	public WebElement getRefRangeAddBtn() {
		return refRangeAddBtn;
	}

	public WebElement getRefRangeOperator() {
		return refRangeOperator;
	}

	public WebElement getLow() {
		return low;
	}

	public WebElement getHigh() {
		return high;
	}

	public WebElement getIndicator() {
		return indicator;
	}

	public WebElement getAutoRemarks() {
		return autoRemarks;
	}

	public WebElement getRangesGridTbl() {
		return rangesGridTbl;
	}

	public WebElement getAddToRefBtn() {
		return addToRefBtn;
	}

	public WebElement getCancelRefBtn() {
		return cancelRefBtn;
	}

	public WebElement getREFGRIDTBL() {
		return REFGRIDTBL;
	}

	public WebElement getResAttrGridTbl() {
		return resAttrGridTbl;
	}

}
