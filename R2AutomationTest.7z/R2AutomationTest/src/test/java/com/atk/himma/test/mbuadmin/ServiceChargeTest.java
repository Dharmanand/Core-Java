package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.ServiceChargePage;
import com.atk.himma.pageobjects.mbuadmin.tabs.ServiceChargeListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class ServiceChargeTest extends SeleniumDriverSetup {

	List<String[]> serviceChargeDatas;
	ServiceChargePage serviceChargePage;

	@Test(description = "Open Service Charge Page")
	public void clickOnServiceChargeMenu() throws InterruptedException {
		serviceChargePage = PageFactory.initElements(webDriver,
				ServiceChargePage.class);
		serviceChargePage = serviceChargePage.clickOnServiceChargeMenu(
				webDriver, webDriverWait);
		serviceChargePage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(serviceChargePage);
		serviceChargePage
				.waitForElementXpathExpression(ServiceChargeListTab.SEARCHBUTTON_XPATH);
		serviceChargePage.sleepShort();
		Assert.assertEquals(serviceChargePage.getServiceChargeListTab()
				.getSerCharListTab().getAttribute("title").trim(),
				"Charges List", "Fail to open Service Charge page.");
	}

	// [Service Charge] Open Form
	@Test(description = "Open Service Charge Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkServiceChargeMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		serviceChargePage = PageFactory.initElements(webDriver,
				ServiceChargePage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"Service Charge");
		serviceChargePage.setWebDriver(webDriver);
		serviceChargePage.setWebDriverWait(webDriverWait);
		serviceChargePage
				.waitForElementXpathExpression(ServiceChargePage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service Charge")
				.get("[Service Charge] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ServiceChargePage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Service Charge] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			serviceChargePage = serviceChargePage.clickOnServiceChargeMenu(
					webDriver, webDriverWait);
			serviceChargePage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(serviceChargePage);
			serviceChargePage
					.waitForElementXpathExpression(ServiceChargeListTab.SEARCHBUTTON_XPATH);
			serviceChargePage.sleepShort();
			Assert.assertEquals(serviceChargePage.getServiceChargeListTab()
					.getSerCharListTab().getAttribute("title").trim(),
					"Charges List", "Fail to open Service Charge page.");
		}
	}

	@Test(description = "search Service Charge", dependsOnMethods = "clickOnServiceChargeMenu")
	public void test1SearchSerCharge() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		serviceChargeDatas = excelReader.read(properties
				.getProperty("serviceCharge"));
		for (String st[] : serviceChargeDatas.subList(0, 1))
			Assert.assertEquals(serviceChargePage.searchServCharge(st).trim(),
					st[7].trim(), "Fail to Search Service Charge");
	}

	@Test(description = "Define Service Charge", dependsOnMethods = "test1SearchSerCharge")
	public void test2DefineServiceCharge() throws InterruptedException,
			IOException {
		for (String st[] : serviceChargeDatas.subList(0, 1))
			Assert.assertEquals(serviceChargePage.defineServiceCharge(st),
					true, "Fail to Define Service Charge.");
	}

	@Test(description = "Fill Tariff Definition Datas", dependsOnMethods = "test2DefineServiceCharge")
	public void test3FillTariffDefDatas() throws Exception {
		for (String st[] : serviceChargeDatas.subList(0, 1))
			Assert.assertEquals(serviceChargePage
					.getTariffDefinitionIndividual().fillTariffDefDatas(st),
					true, "Fail to Fill Tariff Definition Datas.");
	}

	@Test(description = "Save Service Charge Datas", dependsOnMethods = "test3FillTariffDefDatas")
	public void test4SaveDatas() throws InterruptedException, IOException {
		Assert.assertEquals(
				serviceChargePage.saveDetailsPage().contains("Update"), true,
				"Failed to Save Service Charge Datas");
	}

	@Test(description = "Add All Save Service Charge Datas", dependsOnMethods = {
			"test4SaveDatas", "clickOnServiceChargeMenu" }, alwaysRun = true)
	public void test5SaveMoreSerChargeDatas() throws Exception {
		for (String st[] : serviceChargeDatas.subList(1, 2)) {
			serviceChargePage.getServiceChargeListTab().getSerCharListTab()
					.click();
			Assert.assertEquals(serviceChargePage.searchServCharge(st).trim(),
					st[7].trim(), "Fail to Search Service Charge");
			Assert.assertEquals(serviceChargePage.defineServiceCharge(st),
					true, "Fail to Define Service Charge.");
			Assert.assertEquals(serviceChargePage
					.getTariffDefinitionIndividual().fillTariffDefDatas(st),
					true, "Fail to Fill Tariff Definition Datas.");
			Assert.assertEquals(
					serviceChargePage.saveDetailsPage().contains("Update"),
					true, "Failed to Save Service Charge Datas");
		}
	}

	@Test(dependsOnMethods = { "checkServiceChargeMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "check the serach service Charge privilege")
	public void searchSerCharForprivilage() throws Exception {
		for (String st[] : serviceChargeDatas.subList(2, 3)) {
			serviceChargePage.getServiceChargeListTab().getSerCharListTab()
					.click();
			Assert.assertEquals(serviceChargePage.searchServCharge(st).trim(),
					st[7].trim(), "Fail to Search Service Charge");
			Assert.assertEquals(serviceChargePage.defineServiceCharge(st),
					true, "Fail to Define Service Charge.");
		}
	}

	// [List Tab] Define Charge(Link in the search result grid)
	@Test(dependsOnMethods = { "searchSerCharForprivilage" }, groups = { "checkPrivilegesGrp" }, description = "save service charge data")
	public void searchSerCharForPrivilage() throws Exception {
		for (String st[] : serviceChargeDatas.subList(2, 3)) {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("MBU Administration").get("Service Charge")
					.get("[List Tab] View (Link in the search result grid)");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver,
					By.xpath(".//td[@title='" + st[7].trim()
							+ "']/..//a[text()='View']"));
			System.out.println("ExpectedPrivilage --------->> "
					+ expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [List Tab] View (Link in the search result grid) privilege");
		}
	}

	@Test(dependsOnMethods = { "searchSerCharForPrivilage" }, groups = { "checkPrivilegesGrp" }, description = "save service charge data")
	public void saveSerChargeData() throws Exception {
		for (String st[] : serviceChargeDatas.subList(2, 3)) {
			Assert.assertEquals(serviceChargePage.defineServiceCharge(st),
					true, "Fail to Define Service Charge.");
			Assert.assertEquals(serviceChargePage
					.getTariffDefinitionIndividual().fillTariffDefDatas(st),
					true, "Fail to Fill Tariff Definition Datas.");
			Assert.assertEquals(
					serviceChargePage.saveDetailsPage().contains("Update"),
					true, "Failed to Save Service Charge Datas");
			serviceChargePage.getServiceChargeListTab().getSerCharListTab()
					.click();
			serviceChargePage.waitForElementId(ServiceChargeListTab.GRID_ID);
		}
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "saveSerChargeData" }, groups = { "checkPrivilegesGrp" }, description = "[List Tab] Edit (Link in the search result grid)")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service Charge")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ serviceChargeDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");
	}

	// [List Tab] Export to Excel (Button)
	@Test(dependsOnMethods = { "saveSerChargeData" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Export to Excel (Button) for Privilege")
	public void checkExpToExcelButPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service Charge")
				.get("[List Tab] Export to Excel (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(ServiceChargePage.EXPORTTOEXCEL_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Export to Excel (Button) privilege");
	}

	// [Details Tab] [Section: Audit Trail] View

}
