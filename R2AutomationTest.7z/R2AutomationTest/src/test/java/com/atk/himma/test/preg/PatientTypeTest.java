package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.preg.master.PatientTypePage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class PatientTypeTest extends SeleniumDriverSetup {
	List<String[]> patientTypeDatas;
	PatientTypePage patientTypePage;
	LoginPage loginPage;
	String code;

	@Test(description = "Open Patient Type Page")
	public void openPatientTypePage() throws InterruptedException {	
		patientTypePage = PageFactory.initElements(webDriver,
				PatientTypePage.class);
		patientTypePage = patientTypePage.clickOnpatientTypeMenu(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(patientTypePage);
		patientTypePage.waitForElementXpathExpression(PatientTypePage
				.getSavebuttonXpath());
		patientTypePage.sleepVeryShort();
		Assert.assertEquals(patientTypePage.getPageTitle().getText().trim(),
				"Patient Type");
	}

	// [Patient Type] Open Form
	@Test(description = "Open Patient Type Page Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkPatTypeMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		patientTypePage = PageFactory.initElements(webDriver,
				PatientTypePage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		baseLVParentMenuList.add("Masters ");
		menuSelector
				.mouseOverOnTargetMenu(baseLVParentMenuList, "Patient Type");
		patientTypePage.setWebDriver(webDriver);
		patientTypePage.setWebDriverWait(webDriverWait);
		patientTypePage
				.waitForElementXpathExpression(PatientTypePage.MENULINK_XPATH);
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("Patient Type")
				.get("[Patient Type] Open Form");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PatientTypePage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Type] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			patientTypePage = patientTypePage.clickOnpatientTypeMenu(webDriver,
					webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(patientTypePage);
			patientTypePage.waitForElementXpathExpression(PatientTypePage
					.getSavebuttonXpath());
			patientTypePage.sleepShort();
			Assert.assertEquals(patientTypePage.getPageTitle().getText(),
					"Patient Type");
		}
	}

	@Test(dependsOnMethods = { "openPatientTypePage" }, description = "Save Patient Type record")
	public void test1SavePatientTypePage() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		patientTypeDatas = excelReader.read(properties.getProperty("patientType"));
		for (String[] st : patientTypeDatas) {
			code = st[0].trim();
			Assert.assertTrue(patientTypePage.savePatientTypePage(st, webDriver, webDriverWait), "created successfully.");
		}
	}

	@Test(dependsOnMethods = { "test1SavePatientTypePage" }, description = "View Patient Type record")
	public void test2ViewPatTypePage() throws IOException, InterruptedException {
		for (String[] st : patientTypeDatas) {
			Assert.assertEquals(patientTypePage.viewRow(st, code), true);
		}
	}

	@Test(dependsOnMethods = { "test1SavePatientTypePage" }, description = "Edit Patient Type Record")
	public void test3EditPatTypePage() throws IOException, InterruptedException {
		patientTypeDatas = excelReader.read(properties.getProperty("updatePatientType"));
		for (String[] st : patientTypeDatas) {
			String getMsg = patientTypePage.editRow(st, code);
			if (getMsg.contains("modified successfully.")) {
				Assert.assertTrue(true);
			} else if (getMsg
					.contains("already exist, please try with other name.")) {
				Assert.assertTrue(true);
			} else
				Assert.assertTrue(false);
		}
	}

	@Test(dependsOnMethods = { "test1SavePatientTypePage" }, description = "Delete Patient Type Record")
	public void test4DeletePatTypePage() throws IOException,
			InterruptedException {
		for (String[] st : patientTypeDatas) {
			String getMsg = patientTypePage.deleteRow(st, code);
			if (getMsg.contains("deleted successfully.")) {
				Assert.assertTrue(true);
			} else if (getMsg
					.contains("is already in use, you can not delete it.")) {
				Assert.assertTrue(true);
			} else
				Assert.assertTrue(false);
		}
	}
	
	@Test(description = "Sign Out", dependsOnMethods = "test4DeletePatTypePage", alwaysRun = true)
	public void test5SignOut() throws Exception {
		loginPage = patientTypePage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = { "test5SignOut" })
	public void test6Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(4,
				excelReader.read(properties.getProperty("loginSheetName"))),
				"User Home", "Failed Login");
	}
	

	@Test(dependsOnMethods = { "checkPatTypeMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Save Identification Doc Page")
	@Parameters("patTypeAction")
	public void savePatTypePage(String patTypeAction) throws IOException,
			InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		patientTypeDatas = excelReader.read(properties.getProperty("patientType"));
		for (String[] st : patientTypeDatas.subList(1, 2)) {
			if (patTypeAction.equalsIgnoreCase("Save"))
				Assert.assertEquals(patientTypePage.savePatientTypePage(st,
						webDriver, webDriverWait), true,
						"Fail to Save Identification Document");
			else if (patTypeAction.equalsIgnoreCase("Save")
					|| patTypeAction.equalsIgnoreCase("Search")) {
				Assert.assertTrue(patientTypePage.searchRecord(st[1].trim(),
						st[0].trim()), "Fail to Search");
			}
		}
	}

	// [Patient Type] View (Link in the search result grid)
	@Test(description = "Open Patient Type Add New Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "savePatTypePage")
	public void checkViewLinkPrivilege() throws InterruptedException,
			IOException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("Patient Type")
				.get("[Patient Type] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ patientTypeDatas.subList(1, 2).get(0)[1].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Type] View (Link in the search result grid)");
	}

	// [Patient Type] Delete(Link in the search result grid)
	@Test(description = "Open Patient Type Delete Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "savePatTypePage")
	public void checkDeleteLinkPrivilege() throws InterruptedException,
			IOException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Type")
				.get("[Patient Type] Delete(Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ patientTypeDatas.subList(1, 2).get(0)[1].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Patient Type] Delete(Link in the search result grid) privilege");
	}

	// [Patient Type] Edit (Link in the search result grid)
	@Test(description = "Open Patient Type Edit Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "savePatTypePage")
	public void checkEditLinkPrivilege() throws InterruptedException,
			IOException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Type")
				.get("[Patient Type] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+patientTypeDatas.subList(1, 2).get(0)[1].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Patient Type] Edit (Link in the search result grid) privilege");
		if (expectedPrivilage) {
			patientTypePage.clickOnGridAction(patientTypeDatas
					.subList(1, 2).get(0)[1].trim(), "Edit");
			patientTypePage
					.waitForElementXpathExpression(PatientTypePage.UPDATEBUTTON_XPATH);
		}
	}

	// [Patient Type] Add New (Button)
	@Test(description = "Open Patient Type Add New Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = {
			"savePatTypePage", "checkEditLinkPrivilege" })
	public void checkAddNewButtonPrivilege() throws InterruptedException,
			IOException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Type")
				.get("[Patient Type] Add New (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PatientTypePage.ADDNEW_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Type] Add New (Button) Form privilege");
	}

}
