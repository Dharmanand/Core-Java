package com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class TimeDuraConsulServices extends DriverWaitClass {

	public final static String OVERRCLISPECPARAM_ID = "OVERRIDE_CLINIC_SPECIFIC_PARAM";
	public final static String APPOISLOTINTERVAL_ID = "APPOINTMENT_SLOT_INTERVAL";

	public final static String SECTIONNAME_LINKTEXT = "Time Duration for Consultation Services";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Time Duration for Consultation Services')]/..";

	@FindBy(id = OVERRCLISPECPARAM_ID)
	private WebElement overrCliSpecParam;

	@FindBy(id = APPOISLOTINTERVAL_ID)
	private WebElement appoiSlotInterval;

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatas(String[] clinicDatas) throws InterruptedException {
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			sectionName.click();
		waitForElementId(OVERRCLISPECPARAM_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(clinicDatas[23].trim(), overrCliSpecParam);
		if (overrCliSpecParam.isSelected()) {
			appoiSlotInterval.clear();
			appoiSlotInterval.sendKeys(clinicDatas[24].trim());
		}
		return overrCliSpecParam.isSelected() == Boolean
				.valueOf(clinicDatas[23].trim());
	}

	/**
	 * @return the overrCliSpecParam
	 */
	public WebElement getOverrCliSpecParam() {
		return overrCliSpecParam;
	}

	/**
	 * @return the appoiSlotInterval
	 */
	public WebElement getAppoiSlotInterval() {
		return appoiSlotInterval;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
