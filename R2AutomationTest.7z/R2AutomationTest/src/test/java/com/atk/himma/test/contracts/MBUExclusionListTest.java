package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.contracts.MBUExclusionListPage;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.ExclusionListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class MBUExclusionListTest extends SeleniumDriverSetup {
	MBUExclusionListPage mbuExclusionListPage;
	List<String[]> mbuExclusionList;
	List<String[]> serviceExclusionList;
	List<String[]> icdExclusionList;
	List<String[]> itemExclusionList;

	@Test(description = "Open MBU Exclusion List page")
	public void test1OpenMBUExclusionListPage() throws Exception {
		mbuExclusionListPage = PageFactory.initElements(webDriver,
				MBUExclusionListPage.class);
		mbuExclusionListPage = mbuExclusionListPage
				.clickOnMBUExclusionListMenu(webDriver, webDriverWait);
		mbuExclusionListPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		Assert.assertNotNull(mbuExclusionListPage);
		mbuExclusionListPage.waitForElementVisibilityOf(mbuExclusionListPage
				.getExclusionListTab().getExclListForm());
		mbuExclusionListPage.waitForElementVisibilityOf(mbuExclusionListPage
				.getExclusionListTab().getMbuList());
		Assert.assertTrue(mbuExclusionListPage.getExclusionListTab()
				.getMbuList().isDisplayed());
	}

	@Test(description = "Check for Add New Exclusion List Button", dependsOnMethods = { "test1OpenMBUExclusionListPage" })
	public void test2CheckForAddNewExcListBtn() throws Exception {
		Assert.assertTrue(mbuExclusionListPage.getExclusionListTab()
				.getAddNewExclBtn().isDisplayed());
	}

	@Test(description = "Click On Add New Exclusion List Button", dependsOnMethods = { "test2CheckForAddNewExcListBtn" })
	public void test3ClickOnAddNewExcListBtn() throws Exception {
		mbuExclusionListPage.getExclusionListTab().clickAddNewExcList();
		mbuExclusionListPage.waitForElementVisibilityOf(mbuExclusionListPage
				.getExcListDetailsForm());
		mbuExclusionListPage.waitForElementVisibilityOf(mbuExclusionListPage
				.getExclDetailsFirstSection().getExcListName());
		Assert.assertTrue(mbuExclusionListPage.getExclDetailsFirstSection()
				.getExcListName().isDisplayed());
	}

	@Test(description = "Validate Exclusion List Name Mandatory Field in First Section", dependsOnMethods = { "test3ClickOnAddNewExcListBtn" })
	public void test4ValidateExcListNameMandatoryField() throws Exception {
		Assert.assertTrue(mbuExclusionListPage.getExclDetailsFirstSection()
				.isMandExcListName());
	}

	@Test(description = "Validate MBU Mandatory Field in First Section", dependsOnMethods = { "test3ClickOnAddNewExcListBtn" })
	public void test5ValidateMBUMandatoryField() throws Exception {
		Assert.assertTrue(mbuExclusionListPage.getExclDetailsFirstSection()
				.isMandMBU());
	}

	@Test(description = "Add Data for Exclusion Details First section", dependsOnMethods = { "test3ClickOnAddNewExcListBtn" })
	public void test6AddExclusionListFistSectionData() throws Exception {
		mbuExclusionList = excelReader.read(properties.getProperty("MBUExclusionList"));
		if (mbuExclusionList != null && !mbuExclusionList.isEmpty()) {
			mbuExclusionListPage.getExclDetailsFirstSection().fillData(
					mbuExclusionList.get(0));

		}
	}

	@Test(description = "Add Service Pattern Exclusion List Details", dependsOnMethods = { "test6AddExclusionListFistSectionData" })
	public void test7AddServiceExclusionListDetailsData() throws Exception {
		serviceExclusionList = excelReader.read(properties.getProperty("serviceExcListDetails"));
		if (serviceExclusionList != null && !serviceExclusionList.isEmpty()) {
			for (String[] serviceExclusionListData : serviceExclusionList
					.subList(0, 1)) {
				mbuExclusionListPage.getExclusionListDetailsSection()
						.addServiceExclusionData(serviceExclusionListData);
				Assert.assertEquals(mbuExclusionListPage
						.getExclusionListDetailsSection().getServiceLvlName()
						.getAttribute("value"), serviceExclusionListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Exclusion List Details", dependsOnMethods = { "test6AddExclusionListFistSectionData" })
	public void test8AddICDExclusionListDetailsData() throws Exception {
		icdExclusionList = excelReader.read(properties.getProperty("ICDExcListDetails"));
		if (icdExclusionList != null && !icdExclusionList.isEmpty()) {
			for (String[] icdExclusionListData : icdExclusionList.subList(0, 1)) {
				mbuExclusionListPage.getExclusionListDetailsSection()
						.addICDExclusionData(icdExclusionListData);
				Assert.assertEquals(mbuExclusionListPage
						.getExclusionListDetailsSection().getIcdPatternDesc()
						.getAttribute("value"), icdExclusionListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Exclusion List Details", dependsOnMethods = { "test6AddExclusionListFistSectionData" })
	public void test9AddItemExclusionListDetailsData() throws Exception {
		itemExclusionList = excelReader.read(properties.getProperty("itemExcListDetails"));
		if (itemExclusionList != null && !itemExclusionList.isEmpty()) {
			for (String[] itemExclusionListData : itemExclusionList.subList(0,
					1)) {
				mbuExclusionListPage.getExclusionListDetailsSection()
						.addItemExclusionData(itemExclusionListData);
				Assert.assertEquals(
						mbuExclusionListPage.getExclusionListDetailsSection()
								.checkItemLevelData(itemExclusionListData),
						itemExclusionListData[1]);
			}
		}
	}

	@Test(description = "Save Exclusion List", dependsOnMethods = { "test9AddItemExclusionListDetailsData" })
	public void test10SaveExclusionListDetails() throws Exception {
		mbuExclusionListPage.saveExclusionListDetails();
		Assert.assertTrue(mbuExclusionListPage.getUpdateBtn().isEnabled()
				&& mbuExclusionListPage.getAddNewBtn().isEnabled());
	}

	@Test(description = "Activate Record", dependsOnMethods = { "test10SaveExclusionListDetails" })
	public void test11ActivateRecord() throws Exception {
		Assert.assertEquals(
				mbuExclusionListPage.activateRecord().contains("Active"), true,
				"Failed Activate Record");

	}

	@Test(description = "Check Copy Exclucion List Details Functionality", dependsOnMethods = { "test11ActivateRecord" })
	public void test12CheckCopyFun() throws Exception {
		if (serviceExclusionList != null && !serviceExclusionList.isEmpty()) {
			for (String[] serviceExclusionListData : serviceExclusionList
					.subList(0, 1)) {
				mbuExclusionListPage.clickCopy();
				Assert.assertTrue(mbuExclusionListPage
						.getExclusionListDetailsSection().checkExcGrid(
								serviceExclusionListData));
			}
		}
	}

	@Test(description = "Add More New Exclusion Lists", dependsOnMethods = { "test11ActivateRecord" })
	public void test13AddMoreNewExclusionList() throws Exception {
		mbuExclusionListPage.clickAddMoreNewExcList();
		Assert.assertEquals(mbuExclusionListPage.getExclDetailsFirstSection()
				.checkFieldValue(), "");
	}

	@Test(description = "Check Global Exclusion", dependsOnMethods = { "test13AddMoreNewExclusionList" })
	public void test14CheckGlobalExclusion() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		List<String[]> saOrgStructList = excelReader.read(properties.getProperty("orgStruct"));
		Assert.assertEquals(mbuExclusionListPage.getExclDetailsFirstSection()
				.checkGlobalExc(), saOrgStructList.get(0)[0]);
	}

	@Test(description = "Check Cancel Functionality", dependsOnMethods = { "test14CheckGlobalExclusion" }, alwaysRun = true)
	public void test15CheckCancelFun() throws Exception {
		mbuExclusionListPage.clickCancel();
		Assert.assertTrue(mbuExclusionListPage.getExclusionListTab()
				.getExclListGridDiv().isDisplayed());
	}

	// [MBU Exclusion List] Open Form
	@Test(description = "Check MBU Exclusion List page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckMBUExclusionListPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		mbuExclusionListPage = PageFactory.initElements(webDriver,
				MBUExclusionListPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> excParentMenuList = new LinkedList<String>();
		excParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(excParentMenuList,
				"MBU Exclusion List");
		mbuExclusionListPage.setWebDriver(webDriver);
		mbuExclusionListPage.setWebDriverWait(webDriverWait);
		mbuExclusionListPage
				.waitForElementXpathExpression(MBUExclusionListPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Exclusion List")
				.get("[MBU Exclusion List] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(MBUExclusionListPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [MBU Exclusion List] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			mbuExclusionListPage = mbuExclusionListPage
					.clickOnMBUExclusionListMenu(webDriver, webDriverWait);
			mbuExclusionListPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(mbuExclusionListPage);
			mbuExclusionListPage
					.waitForElementVisibilityOf(mbuExclusionListPage
							.getExclusionListTab().getExclListForm());
			mbuExclusionListPage.sleepShort();
			Assert.assertEquals(mbuExclusionListPage.getPageTitle().getText(),
					"Main Business Unit Exclusion List");
		}
	}

	// [List Tab] Add New Exclusion List (Button)
	@Test(description = "Check Add New Exclusion List Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUExclusionListPageMenuLink")
	public void test02CheckAddNewExcListBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Exclusion List")
				.get("[List Tab] Add New Exclusion List (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(ExclusionListTab.ADDNEWEXCLLISTBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [List Tab] Add New Exclusion List (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUExclusionListPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		mbuExclusionList = excelReader.read(properties.getProperty("MBUExclusionList"));
		for (String[] mbuExclusionData : mbuExclusionList) {
			mbuExclusionListPage.getExclusionListTab().searchExcList(
					mbuExclusionData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Exclusion List")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ExclusionListTab.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUExclusionListPageMenuLink")
	public void test04CheckLink2Delete() throws Exception {
		mbuExclusionList = excelReader.read(properties.getProperty("MBUExclusionList"));
		for (String[] mbuExclusionData : mbuExclusionList) {
			mbuExclusionListPage.getExclusionListTab().searchExcList(
					mbuExclusionData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Exclusion List")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ExclusionListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUExclusionListPageMenuLink")
	public void test05CheckLink3Edit() throws Exception {
		mbuExclusionList = excelReader.read(properties.getProperty("MBUExclusionList"));
		for (String[] mbuExclusionData : mbuExclusionList) {
			mbuExclusionListPage.getExclusionListTab().searchExcList(
					mbuExclusionData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Exclusion List")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ExclusionListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		mbuExclusionListPage.getExclusionListTab().clickEditLink(
				mbuExclusionList.get(0));
	}

	// [Details Tab][Section: Exclusion List Details] View
	@Test(description = "Check Exclusion List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test06CheckExcListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Exclusion List")
				.get("[Details Tab][Section: Exclusion List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ExclusionListDetailsSection.EXCLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] View privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Add Record (Button)
	@Test(description = "Check Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckExcListDetailsSec")
	public void test07CheckAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("MBU Exclusion List")
				.get("[Details Tab][Section: Exclusion List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid))
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckExcListDetailsSec")
	public void test08CheckInlineEditRecord() throws Exception {
		serviceExclusionList = excelReader
				.read(properties.getProperty("serviceExcListDetails"));
		mbuExclusionListPage.getExclusionListDetailsSection()
				.clickExcListRecord(serviceExclusionList.get(0));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("MBU Exclusion List")
				.get("[Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.name(ExclusionListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid)) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid)
	@Test(description = "Check Delete Link In Exc Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckExcListDetailsSec")
	public void test09CheckDelLinkInExcGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("MBU Exclusion List")
				.get("[Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVEXCDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Applicable Main Business Units] View

	// [Details Tab][Section: Audit Trail] View

}