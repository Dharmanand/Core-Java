package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AppUserDefaultSection extends DriverWaitClass {
	public final static String APPUSERINFOFORM_ID = "employeeInfo";
	@FindBy(id = APPUSERINFOFORM_ID)
	private WebElement appUserInfoForm;

	public final static String ADDNEWAPPUSERBTNTOP_ID = "addNewButton_top";
	@FindBy(id = ADDNEWAPPUSERBTNTOP_ID)
	private WebElement addNewAppUserBtnTop;

	public final static String SAVEBTNTOP_ID = "saveButton_top";
	@FindBy(id = SAVEBTNTOP_ID)
	private WebElement saveBtnTop;

	public final static String CANCELBTNTOP_XPATH = "//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTNTOP_XPATH)
	private WebElement cancelBtnTop;

	public final static String UPDATEBTNTOP_ID = "updateButton_top";
	@FindBy(id = UPDATEBTNTOP_ID)
	private WebElement updateBtnTop;

	public final static String APPUSERCODE_ID = "empIDOrNo";
	@FindBy(id = APPUSERCODE_ID)
	private WebElement appUserCode;

	public final static String APPUSERIDNUMBER_ID = "systemIdCode";
	@FindBy(id = APPUSERIDNUMBER_ID)
	private WebElement appUserIdNumber;

	public final static String CONFIRMATIONMSG_ID = "ConfirmationMessage";
	@FindBy(id = CONFIRMATIONMSG_ID)
	private WebElement confirmMsg;

	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";
	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public void addDefaultSectionData(String[] appUserData) throws Exception {
		sleepVeryShort();
		appUserIdNumber.clear();
		appUserIdNumber.sendKeys(appUserData[0]);
	}

	public void clickSave() throws Exception {
		saveBtnTop.click();
		sleepMedium();
	}

	public void clickUpdate() throws Exception {
		updateBtnTop.click();
		sleepMedium();
	}

	public void clickAddNewAppUser() throws Exception {
		addNewAppUserBtnTop.click();
		sleepShort();
		doDirtyPopUpCheck();
		sleepShort();
	}

	public void clickCancel() throws Exception {
		cancelBtnTop.click();
		waitForPageLoaded(webDriver);
		sleepShort();
		try {
			waitForElementId(CONFIRMYES_ID);
			confirmYes.click();
		} catch (Exception e) {

		}
	}

	public WebElement getAppUserInfoForm() {
		return appUserInfoForm;
	}

	public WebElement getAddNewAppUserBtnTop() {
		return addNewAppUserBtnTop;
	}

	public WebElement getSaveBtnTop() {
		return saveBtnTop;
	}

	public WebElement getCancelBtnTop() {
		return cancelBtnTop;
	}

	public WebElement getUpdateBtnTop() {
		return updateBtnTop;
	}

	public WebElement getAppUserCode() {
		return appUserCode;
	}

	public WebElement getAppUserIdNumber() {
		return appUserIdNumber;
	}

	public WebElement getConfirmMsg() {
		return confirmMsg;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

}
