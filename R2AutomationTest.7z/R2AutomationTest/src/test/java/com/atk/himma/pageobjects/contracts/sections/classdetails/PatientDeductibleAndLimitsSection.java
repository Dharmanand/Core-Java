package com.atk.himma.pageobjects.contracts.sections.classdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PatientDeductibleAndLimitsSection extends DriverWaitClass {
	public static final String PATDEDUCTLIMITSEC_LINKTEXT = "Patient Deductible and Limits";
	public final static String APPLYDEDUCTCHKBOX_ID = "APPLY_DEDUCT";
	public final static String APPLYDEDUCT_ADDRECORDPLUSBTN_XPATH = "//div[@id='PAT_DEDUCT_LIMIT_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String APPLYDEDUCTADDRECFORM_ID = "CLASS_PAT_DEDUCT_LIMIT_ADD_NEW_POPUP";
	public final static String APPLYDEDUCT_VISITCAT_ID = "VISIT_CAT_ID_PAT_DEDUCT";
	public final static String APPLYDEDUCT_PATDEDUCTTYPE_ID = "PAT_DEDUCT_DROPDOWN";
	public final static String APPLYDEDUCT_PATDEDUCTVAL_ID = "PAT_DEDUCT_VAL";
	public final static String APPLYDEDUCT_SERVLIMITINC_NAME = "multiselect_LIMITINCLUSION_DEDUCT_LIMIT";
	public final static String APPLYDEDUCT_ITEMLIMITINC_NAME = "multiselect_LIMITINCLUSION_DEDUCT_LIMIT_ITEM";
	public final static String APPLYDEDUCT_NOTES_ID = "PAT_DEDUCT_NOTES";
	public final static String APPLYDEDUCT_SUBMITBTN_XPATH = "//form[@id='CLASS_PAT_DEDUCT_LIMIT_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String APPLYDEDUCT_CANCELBTN_XPATH = "//form[@id='CLASS_PAT_DEDUCT_LIMIT_ADD_NEW_POPUP']//input[@value='Cancel']";
	public final static String APPLYDEDUCTGRIDDIV_ID = "PATIENT_DEDUCT_LIMIT_GRID_DIV";
	public final static String APPLYMAXDEDUCTCHKBOX_ID = "APPLY_MAX_DEDUCT";
	public final static String APPLYMAXDEDUCT_ADDRECORDPLUSBTN_XPATH = "//div[@id='PAT_MAX_DEDUCT_LIMIT_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String APPLYMAXDEDUCTADDRECFORM_ID = "CLASS_PAT_MAX_DEDUCT_LIMIT_ADD_NEW_POPUP";
	public final static String APPLYMAXDEDUCT_VISITCAT_ID = "VISIT_CAT_ID_PAT_MAX_DEDUCT";
	public final static String APPLYMAXDEDUCT_PATMAXAMNT_ID = "PAT_DEDUCT_MAX_AMT";
	public final static String APPLYMAXDEDUCT_NOTES_ID = "PAT_MAX_DEDUCT_NOTES";
	public final static String APPLYMAXDEDUCT_SUBMITBTN_XPATH = "//form[@id='CLASS_PAT_MAX_DEDUCT_LIMIT_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String APPLYMAXDEDUCT_CANCELBTN_XPATH = "//form[@id='CLASS_PAT_MAX_DEDUCT_LIMIT_ADD_NEW_POPUP']//input[@value='Cancel']";
	public final static String MAXDEUCTGRIDDIV_ID = "PATIENT_MAX_DEDUCT_LIMIT_GRID_DIV";
	public final static String VISITLIMITPREAUTHCHKBOX_ID = "VISIT_LIMIT_PRE_AUTH";
	public final static String VISITLIMITPREAUTHGRIDDIV_ID = "VISIT_LIMIT_PRE_AUTH_GRID_DIV";
	public final static String VISITLIMITPREAUTH_ADDRECPLUSBTN_XPATH = "//div[@id='VISIT_LIMIT_PRE_AUTH_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String VISITLMTPREAUTHADDRECFORM_ID = "CLASS_VISIT_LIMIT_PRE_AUTH_ADD_NEW_POPUP";
	public final static String PREAUTH_VISITCAT_ID = "VISIT_CAT_ID_PRE_AUTH";
	public final static String PREAUTH_AMNT_ID = "VISIT_LIM_PRE_AUTH_AMT";
	public final static String PREAUTH_SERVLIMITINC_NAME = "multiselect_LIMITINCLUSION_PRE_AUTH";
	public final static String PREAUTH_ITEMLIMITINC_NAME = "multiselect_LIMITINCLUSION_PRE_AUTH_ITEM";
	public final static String PREAUTH_NOTES_ID = "PRE_AUTH_NOTES";
	public final static String PREAUTHREC_SUBMITBTN_XPATH = "//form[@id='CLASS_VISIT_LIMIT_PRE_AUTH_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String PREAUTHREC_CANCELBTN_XPATH = "//form[@id='CLASS_VISIT_LIMIT_PRE_AUTH_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String DEDUCTLIMNOTES_NAME = "classInfo.deductibleLimits.notes";
	public final static String IGNOREINSURGAPCHKBOX_ID = "IGNORE_INSURANCE_GAP";
	

	@FindBy(linkText = PATDEDUCTLIMITSEC_LINKTEXT)
	private WebElement patDeductLimitSec;

	@FindBy(id = APPLYDEDUCTCHKBOX_ID)
	private WebElement applyDeductChkBox;
	
	@FindBy(xpath = APPLYDEDUCT_ADDRECORDPLUSBTN_XPATH)
	private WebElement applyDeduct_addRecPlusBtn;

	@FindBy(id = APPLYDEDUCTADDRECFORM_ID)
	private WebElement applyDeductAddRecForm;

	@FindBy(id = APPLYDEDUCT_VISITCAT_ID)
	private WebElement applyDeductVisitCat;

	@FindBy(id = APPLYDEDUCT_PATDEDUCTTYPE_ID)
	private WebElement applyDeductPatDeductType;

	@FindBy(id = APPLYDEDUCT_PATDEDUCTVAL_ID)
	private WebElement applyDeductPatDeductValue;

	@FindBy(name = APPLYDEDUCT_SERVLIMITINC_NAME)
	private WebElement applyDeductServiceLimInc;

	@FindBy(name = APPLYDEDUCT_ITEMLIMITINC_NAME)
	private WebElement applyDeductItemLimInc;

	@FindBy(id = APPLYDEDUCT_NOTES_ID)
	private WebElement applyDeductNotes;

	@FindBy(xpath = APPLYDEDUCT_SUBMITBTN_XPATH)
	private WebElement applyDeductSubmitBtn;

	@FindBy(xpath = APPLYDEDUCT_CANCELBTN_XPATH)
	private WebElement applyDeductCancelBtn;

	@FindBy(id = APPLYDEDUCTGRIDDIV_ID)
	private WebElement applyDeductGridDiv;

	@FindBy(id = APPLYMAXDEDUCTCHKBOX_ID)
	private WebElement applyMaxDeductChkBox;

	@FindBy(xpath = APPLYMAXDEDUCT_ADDRECORDPLUSBTN_XPATH)
	private WebElement applyMaxDeductAddRecBtn;

	@FindBy(id = APPLYMAXDEDUCTADDRECFORM_ID)
	private WebElement applyMaxDeductAddRecForm;

	@FindBy(id = APPLYMAXDEDUCT_VISITCAT_ID)
	private WebElement applyMaxDeductVisitCat;

	@FindBy(id = APPLYMAXDEDUCT_PATMAXAMNT_ID)
	private WebElement applyMaxDeductPatMaxAmnt;

	@FindBy(id = APPLYMAXDEDUCT_NOTES_ID)
	private WebElement applyMaxDeductNotes;

	@FindBy(xpath = APPLYMAXDEDUCT_SUBMITBTN_XPATH)
	private WebElement applyMaxDeductSubmitBtn;

	@FindBy(xpath = APPLYMAXDEDUCT_CANCELBTN_XPATH)
	private WebElement applyMaxDeductCancelBtn;

	@FindBy(id = MAXDEUCTGRIDDIV_ID)
	private WebElement applyMaxDeductGridDiv;

	@FindBy(id = VISITLIMITPREAUTHCHKBOX_ID)
	private WebElement visitLimPreAuthChkBox;

	@FindBy(id = VISITLIMITPREAUTHGRIDDIV_ID)
	private WebElement visitLimPreAuthGridDiv;

	@FindBy(xpath = VISITLIMITPREAUTH_ADDRECPLUSBTN_XPATH)
	private WebElement visitLimPreAuth_addRecPlusBtn;

	@FindBy(id = VISITLMTPREAUTHADDRECFORM_ID)
	private WebElement visitLimPreAuthAddRecForm;

	@FindBy(id = PREAUTH_VISITCAT_ID)
	private WebElement preAuthVisitCat;

	@FindBy(id = PREAUTH_AMNT_ID)
	private WebElement preAuthAmnt;

	@FindBy(name = PREAUTH_SERVLIMITINC_NAME)
	private WebElement preAuthServLimInc;

	@FindBy(name = PREAUTH_ITEMLIMITINC_NAME)
	private WebElement preAuthItemLimInc;

	@FindBy(id = PREAUTH_NOTES_ID)
	private WebElement preAuthNotes;

	@FindBy(xpath = PREAUTHREC_SUBMITBTN_XPATH)
	private WebElement preAuthSubmitBtn;

	@FindBy(xpath = PREAUTHREC_CANCELBTN_XPATH)
	private WebElement preAuthCancelBtn;

	@FindBy(name = DEDUCTLIMNOTES_NAME)
	private WebElement deductLimNotes;

	@FindBy(id = IGNOREINSURGAPCHKBOX_ID)
	private WebElement ignoreInsurGapChkBox;

	public void addPatDeductLimitData(String[] classListData) throws Exception {
		if (Boolean.valueOf(classListData[28])) {
			applyDeductChkBox.click();
			waitForElementId(APPLYDEDUCTGRIDDIV_ID);
			applyDeduct_addRecPlusBtn.click();
			sleepVeryShort();
			waitForElementId(APPLYDEDUCTADDRECFORM_ID);
			if (!classListData[29].isEmpty()) {
				new Select(applyDeductVisitCat)
						.selectByVisibleText(classListData[29]);
			}
			if (!classListData[30].isEmpty()) {
				new Select(applyDeductPatDeductType)
						.selectByVisibleText(classListData[30]);
			}
			applyDeductPatDeductValue.clear();
			applyDeductPatDeductValue.sendKeys(classListData[31]);
			String[] temp;
			String delimiter = "\\,";
			temp = classListData[32].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				selectValueOfMultiselect(
						"multiselect_LIMITINCLUSION_DEDUCT_LIMIT", temp[i]);
			}
			temp = classListData[33].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				selectValueOfMultiselect(
						"multiselect_LIMITINCLUSION_DEDUCT_LIMIT_ITEM", temp[i]);
			}
			applyDeductNotes.clear();
			applyDeductNotes.sendKeys(classListData[34]);

			applyDeductSubmitBtn.click();

		}

		if (Boolean.valueOf(classListData[35])) {
			applyMaxDeductChkBox.click();
			sleepVeryShort();
			waitForElementId(MAXDEUCTGRIDDIV_ID);
			applyMaxDeductAddRecBtn.click();
			waitForElementId(APPLYMAXDEDUCTADDRECFORM_ID);
			if (!classListData[36].isEmpty()) {
				new Select(applyMaxDeductVisitCat)
						.selectByVisibleText(classListData[36]);
			}
			applyMaxDeductPatMaxAmnt.clear();
			applyMaxDeductPatMaxAmnt.sendKeys(classListData[37]);
			applyMaxDeductNotes.clear();
			applyMaxDeductNotes.sendKeys(classListData[38]);
			applyMaxDeductSubmitBtn.click();

		}

		if (Boolean.valueOf(classListData[39])) {
			visitLimPreAuthChkBox.click();
			waitForElementId(VISITLIMITPREAUTHGRIDDIV_ID);
			visitLimPreAuth_addRecPlusBtn.click();
			waitForElementId(VISITLMTPREAUTHADDRECFORM_ID);
			if (!classListData[40].isEmpty()) {
				new Select(preAuthVisitCat)
						.selectByVisibleText(classListData[40]);
			}
			preAuthAmnt.clear();
			preAuthAmnt.sendKeys(classListData[41]);
			String[] temp;
			String delimiter = "\\,";
			temp = classListData[42].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				selectValueOfMultiselect("multiselect_LIMITINCLUSION_PRE_AUTH",
						temp[i]);
			}
			temp = classListData[43].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				selectValueOfMultiselect(
						"multiselect_LIMITINCLUSION_PRE_AUTH_ITEM", temp[i]);
			}
			preAuthNotes.clear();
			preAuthNotes.sendKeys(classListData[44]);

			preAuthSubmitBtn.click();

		}
		deductLimNotes.clear();
		deductLimNotes.sendKeys(classListData[45]);

		if (Boolean.valueOf(classListData[46])) {
			ignoreInsurGapChkBox.click();
		}

	}

	public WebElement getPatDeductLimitSec() {
		return patDeductLimitSec;
	}

	public WebElement getApplyDeductChkBox() {
		return applyDeductChkBox;
	}

	public WebElement getApplyDeduct_addRecPlusBtn() {
		return applyDeduct_addRecPlusBtn;
	}

	public WebElement getApplyDeductAddRecForm() {
		return applyDeductAddRecForm;
	}

	public WebElement getApplyDeductVisitCat() {
		return applyDeductVisitCat;
	}

	public WebElement getApplyDeductPatDeductType() {
		return applyDeductPatDeductType;
	}

	public WebElement getApplyDeductPatDeductValue() {
		return applyDeductPatDeductValue;
	}

	public WebElement getApplyDeductServiceLimInc() {
		return applyDeductServiceLimInc;
	}

	public WebElement getApplyDeductItemLimInc() {
		return applyDeductItemLimInc;
	}

	public WebElement getApplyDeductNotes() {
		return applyDeductNotes;
	}

	public WebElement getApplyDeductSubmitBtn() {
		return applyDeductSubmitBtn;
	}

	public WebElement getApplyDeductCancelBtn() {
		return applyDeductCancelBtn;
	}

	public WebElement getApplyDeductGridDiv() {
		return applyDeductGridDiv;
	}

	public WebElement getApplyMaxDeductChkBox() {
		return applyMaxDeductChkBox;
	}

	public WebElement getApplyMaxDeductAddRecBtn() {
		return applyMaxDeductAddRecBtn;
	}

	public WebElement getApplyMaxDeductAddRecForm() {
		return applyMaxDeductAddRecForm;
	}

	public WebElement getApplyMaxDeductVisitCat() {
		return applyMaxDeductVisitCat;
	}

	public WebElement getApplyMaxDeductPatMaxAmnt() {
		return applyMaxDeductPatMaxAmnt;
	}

	public WebElement getApplyMaxDeductNotes() {
		return applyMaxDeductNotes;
	}

	public WebElement getApplyMaxDeductSubmitBtn() {
		return applyMaxDeductSubmitBtn;
	}

	public WebElement getApplyMaxDeductCancelBtn() {
		return applyMaxDeductCancelBtn;
	}

	public WebElement getApplyMaxDeductGridDiv() {
		return applyMaxDeductGridDiv;
	}

	public WebElement getVisitLimPreAuthChkBox() {
		return visitLimPreAuthChkBox;
	}

	public WebElement getVisitLimPreAuthGridDiv() {
		return visitLimPreAuthGridDiv;
	}

	public WebElement getVisitLimPreAuth_addRecPlusBtn() {
		return visitLimPreAuth_addRecPlusBtn;
	}

	public WebElement getVisitLimPreAuthAddRecForm() {
		return visitLimPreAuthAddRecForm;
	}

	public WebElement getPreAuthVisitCat() {
		return preAuthVisitCat;
	}

	public WebElement getPreAuthAmnt() {
		return preAuthAmnt;
	}

	public WebElement getPreAuthServLimInc() {
		return preAuthServLimInc;
	}

	public WebElement getPreAuthItemLimInc() {
		return preAuthItemLimInc;
	}

	public WebElement getPreAuthNotes() {
		return preAuthNotes;
	}

	public WebElement getPreAuthSubmitBtn() {
		return preAuthSubmitBtn;
	}

	public WebElement getPreAuthCancelBtn() {
		return preAuthCancelBtn;
	}

	public WebElement getDeductLimNotes() {
		return deductLimNotes;
	}

	public WebElement getIgnoreInsurGapChkBox() {
		return ignoreInsurGapChkBox;
	}

}
