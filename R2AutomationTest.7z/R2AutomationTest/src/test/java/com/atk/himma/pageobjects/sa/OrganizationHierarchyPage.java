package com.atk.himma.pageobjects.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.sa.tabs.OrganizationHierarchyTab;
import com.atk.himma.pageobjects.sa.tabs.RootOrganizationTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class OrganizationHierarchyPage extends DriverWaitClass implements
		StatusMessages, TopControls {
	private RootOrganizationTab rootOrganizationTab;
	private OrganizationHierarchyTab organizationHierarchyTab;

	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Organization Hierarchy')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		rootOrganizationTab = PageFactory.initElements(webDriver,
				RootOrganizationTab.class);
		rootOrganizationTab.setWebDriver(webDriver);
		rootOrganizationTab.setWebDriverWait(webDriverWait);

		organizationHierarchyTab = PageFactory.initElements(webDriver,
				OrganizationHierarchyTab.class);
		organizationHierarchyTab.setWebDriver(webDriver);
		organizationHierarchyTab.setWebDriverWait(webDriverWait);

	}

	public OrganizationHierarchyPage clickOnOrganizationHierarchyMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("System Administration");
		menuSelector.clickOnTargetMenu(menuList, "Organization Hierarchy");
		OrganizationHierarchyPage organizationHierarchyPage = PageFactory
				.initElements(webDriver, OrganizationHierarchyPage.class);
		organizationHierarchyPage.setWebDriver(webDriver);
		organizationHierarchyPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return organizationHierarchyPage;
	}

	public LoginPage signOut() throws Exception {
		waitForElementXpathExpression(SIGNOUT_XPATH);
		sleepVeryShort();
		signOut.click();
		doDirtyPopUpCheck();
		waitForElementXpathExpression(LoginPage.LOGINBUTTON_XPATH);
		sleepVeryShort();
		LoginPage loginPage = PageFactory.initElements(webDriver,
				LoginPage.class);
		loginPage.setWebDriver(webDriver);
		loginPage.setWebDriverWait(webDriverWait);
		return loginPage;
	}

	public RootOrganizationTab getRootOrganizationTab() {
		return rootOrganizationTab;
	}

	public OrganizationHierarchyTab getOrganizationHierarchyTab() {
		return organizationHierarchyTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getSignOut() {
		return signOut;
	}

}
