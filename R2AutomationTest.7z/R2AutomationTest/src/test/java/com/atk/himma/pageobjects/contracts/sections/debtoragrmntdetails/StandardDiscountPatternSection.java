package com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class StandardDiscountPatternSection extends DriverWaitClass {
	public final static String STDDISCPATTERNSEC_LINKTEXT = "Standard Discount Pattern";
	public final static String STDMODIFVALUE_ID = "SER_STND_MOD_VALUE";
	public final static String STDMODIFTYPE_ID = "SER_STND_MOD_TYPE";
	public final static String SERVTARIFFLISTVIEWBTN_ID = "SERVICE_TARIFF_VIEW_BTN";
	public final static String STDMODIFDISC_XPATH = "//input[@value='1' and @name='debtorAgreement.standardTariff.itemModPattern']";
	public final static String STDMODIFADDON_XPATH = "//input[@value='2' and @name='debtorAgreement.standardTariff.itemModPattern']";
	public final static String ITEMSTDMODIFVALUE_ID = "ITM_STND_MOD_VALUE";
	public final static String ITEMSTDMODIFTYPE_ID = "ITM_STND_MOD_TYPE";

	private final static String ITMDISC = "Discount", ITMADDON = "Add-On";

	@FindBy(linkText = STDDISCPATTERNSEC_LINKTEXT)
	private WebElement stdDiscPatternSec;
	
	@FindBy(id = STDMODIFVALUE_ID)
	private WebElement stdModifValue;

	@FindBy(id = STDMODIFTYPE_ID)
	private WebElement stdModifType;

	@FindBy(id = SERVTARIFFLISTVIEWBTN_ID)
	private WebElement servTariffListViewBtn;

	@FindBy(xpath = STDMODIFDISC_XPATH)
	private WebElement stdModifDiscount;

	@FindBy(xpath = STDMODIFADDON_XPATH)
	private WebElement stdModifAddOn;

	@FindBy(id = ITEMSTDMODIFVALUE_ID)
	private WebElement itemStdModifValue;

	@FindBy(id = ITEMSTDMODIFTYPE_ID)
	private WebElement itemStdModifType;

	public void addStdDiscPatternData(String[] debtorAgrmntListData) {
		selectRadioButtonAsLabelText(debtorAgrmntListData[47]);
		stdModifValue.clear();
		stdModifValue.sendKeys(debtorAgrmntListData[48]);
		if (!debtorAgrmntListData[49].isEmpty()) {
			new Select(stdModifType)
					.selectByVisibleText(debtorAgrmntListData[49]);
		}
		selectRadioButtonAsLabelText(debtorAgrmntListData[50]);
		if (ITMDISC.equals(debtorAgrmntListData[51])) {
			stdModifDiscount.click();
		} else if (ITMADDON.equals(debtorAgrmntListData[51])) {
			stdModifAddOn.click();
		}

		itemStdModifValue.clear();
		itemStdModifValue.sendKeys(debtorAgrmntListData[52]);
		if (!debtorAgrmntListData[53].isEmpty()) {
			new Select(itemStdModifType)
					.selectByVisibleText(debtorAgrmntListData[53]);
		}

	}

	public WebElement getStdDiscPatternSec() {
		return stdDiscPatternSec;
	}

	public WebElement getStdModifValue() {
		return stdModifValue;
	}

	public WebElement getStdModifType() {
		return stdModifType;
	}

	public WebElement getServTariffListViewBtn() {
		return servTariffListViewBtn;
	}

	public WebElement getStdModifDiscount() {
		return stdModifDiscount;
	}

	public WebElement getStdModifAddOn() {
		return stdModifAddOn;
	}

	public WebElement getItemStdModifValue() {
		return itemStdModifValue;
	}

	public WebElement getItemStdModifType() {
		return itemStdModifType;
	}

}
