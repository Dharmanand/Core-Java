package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.rateplandetails.PriceModifParametersSection;
import com.atk.himma.pageobjects.contracts.sections.rateplandetails.RPDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.rateplandetails.RatePlanTariffSection;
import com.atk.himma.pageobjects.contracts.tabs.RatePlanListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class RatePlanPage extends DriverWaitClass implements StatusMessages {
	private RatePlanListTab ratePlanListTab;
	private RPDetailsFirstSection rpDetailsFirstSection;
	private PriceModifParametersSection priceModifParametersSection;
	private RatePlanTariffSection ratePlanTariffSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[text()= 'Rate Plan']";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String RPDETAILSFORM_ID = "RATE_PLAN_DETAILS_FORM";
	public final static String ADDNEWBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='Add New']";
	public final static String COPYBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='Copy']";
	public final static String SAVEBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='Save']";
	public final static String UPDATEBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='Update']";
	public final static String PRINTBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='print']";
	public final static String CANCELBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='Cancel']";
	public final static String APPLYVERSIONBTN_XPATH = "//form[@id='RATE_PLAN_DETAILS_FORM']//input[@value='Apply Version']";
	public final static String GOTODBTRAGRMNT_ID = "ADD_NEW_AGR";
	public final static String APPLYVERFORM_ID = "applyVersionForm";
	public final static String NOTES_ID = "STATUS_NOTES";
	public final static String APPLYBTN_XPATH = "//form[@id='applyVersionForm']//input[@value='Apply']";
	public final static String CLOSE_ID = "CLOSE_POPUP";
	public final static String PUBLISHEDLBL_XPATH = "//span[@id='STATUS_ID']//label[contains(text(), 'Published')]";
	

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = RPDETAILSFORM_ID)
	private WebElement ratePlanDetailsForm;

	@FindBy(xpath = ADDNEWBTN_XPATH)
	private WebElement addNewBtn;

	@FindBy(xpath = COPYBTN_XPATH)
	private WebElement copyBtn;

	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	@FindBy(xpath = APPLYVERSIONBTN_XPATH)
	private WebElement applyVersionBtn;

	@FindBy(id = GOTODBTRAGRMNT_ID)
	private WebElement goToDebtorAgrmntBtn;

	@FindBy(id = APPLYVERFORM_ID)
	private WebElement applyVersionForm;

	@FindBy(id = NOTES_ID)
	private WebElement notes;

	@FindBy(xpath = APPLYBTN_XPATH)
	private WebElement applyBtn;

	@FindBy(id = CLOSE_ID)
	private WebElement closeBtn;

	@FindBy(xpath = PUBLISHEDLBL_XPATH)
	private WebElement publishedLbl;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		ratePlanListTab = PageFactory.initElements(webDriver,
				RatePlanListTab.class);
		ratePlanListTab.setWebDriver(webDriver);
		ratePlanListTab.setWebDriverWait(webDriverWait);

		rpDetailsFirstSection = PageFactory.initElements(webDriver,
				RPDetailsFirstSection.class);
		rpDetailsFirstSection.setWebDriver(webDriver);
		rpDetailsFirstSection.setWebDriverWait(webDriverWait);

		priceModifParametersSection = PageFactory.initElements(webDriver,
				PriceModifParametersSection.class);
		priceModifParametersSection.setWebDriver(webDriver);
		priceModifParametersSection.setWebDriverWait(webDriverWait);

		ratePlanTariffSection = PageFactory.initElements(webDriver,
				RatePlanTariffSection.class);
		ratePlanTariffSection.setWebDriver(webDriver);
		ratePlanTariffSection.setWebDriverWait(webDriverWait);

	}

	public RatePlanPage clickOnRatePlanMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "Rate Plan");
		RatePlanPage ratePlanPage = PageFactory.initElements(webDriver,
				RatePlanPage.class);
		ratePlanPage.setWebDriver(webDriver);
		ratePlanPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return ratePlanPage;
	}

	public void saveRatePlanDetails() throws Exception {
		saveBtn.click();
		waitForElementXpathExpression(UPDATEBTN_XPATH);
		sleepShort();

	}

	public void applyVersion() throws Exception {
		applyVersionBtn.click();
		waitForElementId(APPLYVERFORM_ID);
		sleepVeryShort();
		notes.clear();
		notes.sendKeys("New Version");
		applyBtn.click();
		waitForElementXpathExpression(PUBLISHEDLBL_XPATH);
		sleepShort();

	}

	public RatePlanListTab getRatePlanListTab() {
		return ratePlanListTab;
	}

	public RPDetailsFirstSection getRpDetailsFirstSection() {
		return rpDetailsFirstSection;
	}

	public PriceModifParametersSection getPriceModifParametersSection() {
		return priceModifParametersSection;
	}

	public RatePlanTariffSection getRatePlanTariffSection() {
		return ratePlanTariffSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getRatePlanDetailsForm() {
		return ratePlanDetailsForm;
	}

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getApplyVersionBtn() {
		return applyVersionBtn;
	}

	public WebElement getGoToDebtorAgrmntBtn() {
		return goToDebtorAgrmntBtn;
	}

	public WebElement getApplyVersionForm() {
		return applyVersionForm;
	}

	public WebElement getNotes() {
		return notes;
	}

	public WebElement getApplyBtn() {
		return applyBtn;
	}

	public WebElement getCloseBtn() {
		return closeBtn;
	}

	public WebElement getPublishedLbl() {
		return publishedLbl;
	}

}
