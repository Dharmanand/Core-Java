package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.sa.PrivilegeGroupsPage;
import com.atk.himma.pageobjects.sa.tabs.PrivilegeGroupInformationTab;
import com.atk.himma.pageobjects.sa.tabs.PrivilegeGroupListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class PrivilegeGroupsTest extends SeleniumDriverSetup {
	PrivilegeGroupsPage privilegeGroupsPage;
	List<String[]> privGrpList;
	List<String[]> editPrivGrpList;
	LoginPage loginPage;

	@Test(description = "Open Privilege Groups Page", groups="openPrivGrp")
	public void openPrivilegeGroups() throws Exception {
		privilegeGroupsPage = PageFactory.initElements(webDriver,
				PrivilegeGroupsPage.class);
		privilegeGroupsPage
				.clickOnPrivilegeGroupsMenu(webDriver, webDriverWait);
		privilegeGroupsPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		Assert.assertNotNull(privilegeGroupsPage);
		privilegeGroupsPage
				.waitForElementName(PrivilegeGroupListTab.VIEWPRIVGRPFORM_NAME);
		Assert.assertTrue(privilegeGroupsPage.getPrivilegeGroupListTab()
				.getPrivGroupName().isDisplayed());
	}

	@Test(description = "Add New Privilege Group for Admin User", dependsOnMethods = { "openPrivilegeGroups" }, groups={"superAdminTestsGrp"})
	public void addNewPrivilegeGroup() throws Exception {
		privGrpList = excelReader.read(properties.getProperty("privilegeGroups").trim());
		if (privGrpList != null && !privGrpList.isEmpty()) {
			privilegeGroupsPage.getPrivilegeGroupListTab()
					.clickOnAddNewPrivGrp();
			privilegeGroupsPage
					.getPrivilegeGroupInformationTab()
					.waitForElementId(
							PrivilegeGroupInformationTab.PRIVGRPNAME_ID);
			for (String[] privGrpData : privGrpList) {
				privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.addNewPrivGrp(privGrpData);
				Assert.assertTrue(privilegeGroupsPage
						.getPrivilegeGroupInformationTab().getUpdateBtn()
						.isEnabled());
				privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.clickOnAddNewPrivGrpBtn();
			}
			privilegeGroupsPage.getPrivilegeGroupInformationTab()
					.clickOnCancel();
		}
	}

	@Test(description = "Add New Privilege Group for Other Users", dependsOnMethods = { "openPrivilegeGroups" }, groups={"adminTestsGrp"})
	public void addNewPrivGrpOtherUsers() throws Exception {
		privGrpList = excelReader.read(properties.getProperty("otherUsersPrivilegeGroups").trim());
		if (privGrpList != null && !privGrpList.isEmpty()) {
			privilegeGroupsPage.getPrivilegeGroupListTab()
					.clickOnAddNewPrivGrp();
			privilegeGroupsPage
					.getPrivilegeGroupInformationTab()
					.waitForElementId(
							PrivilegeGroupInformationTab.PRIVGRPNAME_ID);
			for (String[] privGrpData : privGrpList) {
				privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.addNewPrivGrp(privGrpData);
				Assert.assertTrue(privilegeGroupsPage
						.getPrivilegeGroupInformationTab().getUpdateBtn()
						.isEnabled());
				privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.clickOnAddNewPrivGrpBtn();
			}
			privilegeGroupsPage.getPrivilegeGroupInformationTab()
					.clickOnCancel();
		}
	}

	@Test(description = "Edit Privilege Group", dependsOnMethods = { "addNewPrivGrpOtherUsers" }, groups={"adminTestsGrp"})
	public void editPrivilegeGroup() throws Exception {
		editPrivGrpList = excelReader.read(properties.getProperty("editPrivilegeGroups"));
		if (editPrivGrpList != null && !editPrivGrpList.isEmpty()) {
			for (String[] editPrivGrpData : editPrivGrpList.subList(0, 1)) {
				privilegeGroupsPage.getPrivilegeGroupListTab()
						.searchPrivilegeGroup(editPrivGrpData);
				Assert.assertTrue(privilegeGroupsPage
						.getPrivilegeGroupListTab().searchGridData(
								editPrivGrpData[0]));
				privilegeGroupsPage.getPrivilegeGroupListTab().clickOnEdit(
						editPrivGrpData);
				privilegeGroupsPage.getPrivilegeGroupInformationTab()
						.updatePrivGrpData(editPrivGrpData);
				Assert.assertTrue(privilegeGroupsPage
						.getPrivilegeGroupInformationTab().getUpdateBtn()
						.isEnabled());
				Assert.assertTrue(privilegeGroupsPage
						.getPrivilegeGroupInformationTab()
						.getAddNewPrivGrpBtn().isEnabled());
			}
			privilegeGroupsPage.getPrivilegeGroupInformationTab()
					.clickOnCancel();
		}
	}

	@Test(description = "Delete Privilege Group", dependsOnMethods = { "addNewPrivGrpOtherUsers" }, groups={"adminTestsGrp"})
	public void deletePrivilegeGroup() throws Exception {
		if (editPrivGrpList != null && !editPrivGrpList.isEmpty()) {
			for (String[] delPrivGrpData : editPrivGrpList.subList(1, 2)) {
				privilegeGroupsPage.getPrivilegeGroupListTab()
						.searchPrivilegeGroup(delPrivGrpData);
				Assert.assertTrue(privilegeGroupsPage
						.getPrivilegeGroupListTab().searchGridData(
								delPrivGrpData[0]));
				privilegeGroupsPage.getPrivilegeGroupListTab().clickOnDelete(
						delPrivGrpData);
				try {
					Assert.assertFalse(privilegeGroupsPage
							.getPrivilegeGroupListTab().searchGridData(
									delPrivGrpData[0]));
				} catch (Exception e) {
					Reporter.log("Element not Found....");
				}
			}
		}
	}

	@Test(description = "Set Privileges Group", dependsOnMethods = { "openPrivilegeGroups" }, groups = "checkPrivilegesGrp")
	@Parameters("flag")
	public void setFullPrivileges(boolean flag) throws Exception {
		if (flag)
			Assert.assertEquals(PrivilegesDataExecutor
					.chekFullPrivileges(privilegeGroupsPage), true,
					"Fail to Set All Privileges");
		else {
			privilegeGroupsPage.clickOnPrivilegeGroupsMenu(webDriver,
					webDriverWait);
			privilegeGroupsPage.waitForElementId(PrivilegeGroupListTab.GRID_ID);
			privilegeGroupsPage.sleepVeryShort();
			Assert.assertEquals(PrivilegesDataExecutor
					.chekMenuPrivileges(privilegeGroupsPage), true,
					"Fail to Set Menu Privileges");

		}
	}

	@Test(description = "Sign Out", dependsOnMethods = "setFullPrivileges", groups = "checkPrivilegesGrp")
	public void signOut() throws Exception {
		loginPage = privilegeGroupsPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "signOut", groups = "checkPrivilegesGrp")
	public void login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(8,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}

	// [Privilege Groups] Open Form
	@Test(description = "Check Privilege Groups Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "login")
	public void checkPrivilegeGroupsMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		privilegeGroupsPage = PageFactory.initElements(webDriver,
				PrivilegeGroupsPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> privParentMenuList = new LinkedList<String>();
		privParentMenuList.add("System Administration");
		menuSelector.mouseOverOnTargetMenu(privParentMenuList,
				"Privilege Groups");
		privilegeGroupsPage.setWebDriver(webDriver);
		privilegeGroupsPage.setWebDriverWait(webDriverWait);
		privilegeGroupsPage
				.waitForElementXpathExpression(PrivilegeGroupsPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Privilege Groups")
				.get("[Privilege Groups] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PrivilegeGroupsPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Privilege Groups] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			privilegeGroupsPage = privilegeGroupsPage
					.clickOnPrivilegeGroupsMenu(webDriver, webDriverWait);
			privilegeGroupsPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(privilegeGroupsPage);
			privilegeGroupsPage.waitForElementVisibilityOf(privilegeGroupsPage
					.getPrivilegeGroupListTab().getViewPrivGrpForm());
			privilegeGroupsPage.sleepShort();
			Assert.assertEquals(privilegeGroupsPage.getPageTitle().getText(),
					"Privilege Groups");
		}
	}

	// [List Tab] Add New (Button)
	@Test(description = "Check Add New Privilege Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPrivilegeGroupsMenuLink")
	public void checkAddNewPrivBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Privilege Groups")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PrivilegeGroupListTab.ADDNEWPRIVGROUPBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(description = "Check Edit privilege Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPrivilegeGroupsMenuLink")
	public void checkEditPrivLink() throws Exception {
		privGrpList = excelReader.read(properties.getProperty("privilegeGroups"));
		for (String[] privGrpData : privGrpList.subList(0, 1)) {
			privilegeGroupsPage.getPrivilegeGroupListTab()
					.searchPrivilegeGroup(privGrpData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Privilege Groups")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PrivilegeGroupListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
	}

	// [List Tab] Delete (Link in the search result grid)
	@Test(description = "Check Delete privilege Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkPrivilegeGroupsMenuLink")
	public void checkDeletePrivLink() throws Exception {
		privGrpList = excelReader.read(properties.getProperty("privilegeGroups"));
		for (String[] privGrpData : privGrpList.subList(0, 1)) {
			privilegeGroupsPage.getPrivilegeGroupListTab()
					.searchPrivilegeGroup(privGrpData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Privilege Groups")
				.get("[List Tab] Delete (Link in the search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PrivilegeGroupListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete (Link in the search result grid) privilege");
	}

	// [Details Tab][Section: Audit Trail] View

}
