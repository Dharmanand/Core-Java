package com.atk.himma.pageobjects.pharmacy;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.pageobjects.pharmacy.sections.AlternativeMedicinesSection;
import com.atk.himma.pageobjects.pharmacy.sections.BrandedDrugFirstSection;
import com.atk.himma.pageobjects.pharmacy.sections.DosageInformationSection;
import com.atk.himma.pageobjects.pharmacy.sections.GenericDrugsCompSection;
import com.atk.himma.pageobjects.pharmacy.sections.InstructionsSection;
import com.atk.himma.pageobjects.pharmacy.tabs.BrandedDrugListTab;
import com.atk.himma.util.DriverWaitClass;

public class BrandedDrugPage extends DriverWaitClass{
	
	private BrandedDrugListTab brandedDrugListTab;
	private BrandedDrugFirstSection brandedDrugFirstSection;
	private GenericDrugsCompSection genericDrugsCompSection;
	private DosageInformationSection dosageInformationSection;
	private InstructionsSection instructionsSection;
	private AlternativeMedicinesSection alternativeMedicinesSection;
	
	public final String FORM_ID = "BRANDED_DRUG";
	public final String UPDATEBUTTON_CSS = ".buttoncontainer_vlrg_top > input[value=Update]";
	public final String CANCELBUTTON_CSS = ".buttoncontainer_vlrg_top > input[value=Cancel]";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = UPDATEBUTTON_CSS)
	private WebElement updateButton;

	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButton;
	
	/**
	 * @return the brandedDrugListTab
	 */
	public BrandedDrugListTab getBrandedDrugListTab() {
		return brandedDrugListTab;
	}
	/**
	 * @return the brandedDrugFirstSection
	 */
	public BrandedDrugFirstSection getBrandedDrugFirstSection() {
		return brandedDrugFirstSection;
	}
	/**
	 * @return the genericDrugsCompSection
	 */
	public GenericDrugsCompSection getGenericDrugsCompSection() {
		return genericDrugsCompSection;
	}
	/**
	 * @return the dosageInformationSection
	 */
	public DosageInformationSection getDosageInformationSection() {
		return dosageInformationSection;
	}
	/**
	 * @return the instructionsSection
	 */
	public InstructionsSection getInstructionsSection() {
		return instructionsSection;
	}
	/**
	 * @return the alternativeMedicinesSection
	 */
	public AlternativeMedicinesSection getAlternativeMedicinesSection() {
		return alternativeMedicinesSection;
	}
	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}
	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}
	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

}
