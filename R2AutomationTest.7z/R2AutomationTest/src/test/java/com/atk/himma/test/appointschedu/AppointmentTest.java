package com.atk.himma.test.appointschedu;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.appointsched.Appointments;
import com.atk.himma.pageobjects.appointsched.sections.appointSections.PhysicianAvailability;
import com.atk.himma.pageobjects.appointsched.tabs.FreezeTab;
import com.atk.himma.pageobjects.appointsched.tabs.UnFreezeTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class AppointmentTest extends SeleniumDriverSetup {

	LoginPage loginPage;
	List<String[]> appointmentsDatas;
	Appointments appointmentsPage;
	FreezeTab freezeTab;
	UnFreezeTab unFreezeTab;

	@Test(description = "Open Appointments Page")
	public void clickOnAppointmentsMenu() throws InterruptedException {
		appointmentsPage = PageFactory.initElements(webDriver,
				Appointments.class);
		appointmentsPage = appointmentsPage.clickOnAppointmentsMenu(webDriver,
				webDriverWait);
		appointmentsPage.setInstance(webDriver, webDriverWait);
		doDirtyFormCheck();
		appointmentsPage.waitForElementId(PhysicianAvailability.FORM_ID);
		appointmentsPage.waitForElementId(PhysicianAvailability.GRID_ID);
		appointmentsPage.sleepShort();
		Assert.assertNotNull(appointmentsPage.getPhysicianAvailability()
				.getFormId(), "Fail to open Appointments Page");
	}

	@Test(description = "Search Physician", dependsOnMethods = "clickOnAppointmentsMenu")
	public void test001QuickSearchPhysician() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("AppSchedExcel"));
		appointmentsDatas = excelReader.read(properties.getProperty("appointments"));
		for (String[] st : appointmentsDatas.subList(0, 1))
			Assert.assertEquals(appointmentsPage.getPhysicianAvailability()
					.quickSearchPhysician(st[0].trim()), true,
					"Fail to Search Physician");
	}

	@Test(description = "Click on Available Session", dependsOnMethods = "test001QuickSearchPhysician")
	public void test002ClickOnAvailableSession() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(0, 1))
			Assert.assertEquals(
					appointmentsPage
							.getPhysicianAvailability()
							.clickOnAvailableSession(st[0].trim(), st[1].trim())
							.getBackToAppointButton().getAttribute("value")
							.contains("Back to Appointments"), true,
					"Fail to Click on Available Session");
	}

	/*@Test(description = "Click Back on Appointment Button")
	public void test00ClickBackOnAppointButton() throws InterruptedException {
		Assert.assertEquals(appointmentsPage.getAppointmentDairy()
				.clickBackOnAppointButton().getPageTitle().getText().trim()
				.equals("Physician Availability"), true,
				"Fail to Click Back on Appointment Button");
	}*/

	@Test(description = "Click on Available Date Session", dependsOnMethods = "test001QuickSearchPhysician")
	public void test003ClickOnAvailDateSession() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(0, 1))
			Assert.assertEquals(
					appointmentsPage
							.getPhysicianAvailability()
							.clickOnAvailDateSession(st[0].trim(),
									st[1].trim(), st[2].trim(), st[3].trim())
							.getBackToAppointButton().getAttribute("value")
							.contains("Back to Appointments"), true,
					"Fail to Click on Available Date Session");
	}

	// Book
	@Test(description = "Click on Available Appointment Slot", dependsOnMethods = "test003ClickOnAvailDateSession")
	public void test004ClickOnAppSlotForBook() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(0, 1))
			Assert.assertEquals(appointmentsPage.getAppointmentDairy()
					.clickOnAppSlotForBook(st[3].trim(), st[4].trim())
					.getRegisterResPatient().getAttribute("value").trim()
					.equals("Register Reserved Patient"), true,
					"Fail to Click on Available Appointment Slot");
	}

	@Test(description = "Select a Patient From Manage Booking Page", dependsOnMethods = "test004ClickOnAppSlotForBook")
	public void test005DoQuickSearchForBook() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(0, 1))
			Assert.assertEquals(appointmentsPage.getManageBooking()
					.getBookTab()
					.doQuickSearchPage(st[5].trim(), st[18].trim()), true,
					"Fail to Select a Patient From Manage Booking Page");
	}

	@Test(description = "Save Booking Details", dependsOnMethods = "test005DoQuickSearchForBook")
	public void test006SaveBookingDetails() throws InterruptedException {
		Assert.assertEquals(
				appointmentsPage.getManageBooking().getBookTab()
						.saveBookingDetails().getBackToAppointButton()
						.getAttribute("value").contains("Back to Appointments"),
				true, "Fail to Save Booking Details");
	}

	@Test(description = "Check Appointment Slip Page", dependsOnMethods = "test006SaveBookingDetails")
	public void test007CheckAppointmentSlip() throws InterruptedException {
		Assert.assertEquals(appointmentsPage.getManageBooking().getBookTab()
				.checkAppointmentSlip(), true,
				"Fail to Check Appointment Slip Page");
	}

	@Test(description = "Check Cancel Booked Slot", dependsOnMethods = { "test007CheckAppointmentSlip" }, alwaysRun = true)
	public void test008CancelBookedSlot() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(0, 1))
			Assert.assertEquals(appointmentsPage.getAppointmentDairy()
					.cancelBookedSlot(st[4].trim(), st[5].trim()), true,
					"Fail to Check Appointment Booked Slot");
	}

	// Freeze

	@Test(description = "Click on Available Appointment Slot For Freeze", dependsOnMethods = {
			"test008CancelBookedSlot"}, alwaysRun = true)
	public void test009ClickOnAppSlotForFreeze() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(1, 2)) {
			freezeTab = appointmentsPage.getAppointmentDairy()
					.clickOnAppSlotForFreeze(st[3].trim(), st[4].trim());
			Assert.assertEquals(freezeTab.getSaveButton().getAttribute("value")
					.equals("Save"), true,
					"Fail to Click on Available Appointment Slot For Freeze");
		}
	}

	@Test(description = "Fill datas For Freeze", dependsOnMethods = "test009ClickOnAppSlotForFreeze")
	public void test010FillDatasForFreeze() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(1, 2)) {
			Assert.assertEquals(freezeTab.fillDatas(st), true,
					"Fail to Fill datas For Freeze");
		}
	}

	@Test(description = "Save Freeze Slot", dependsOnMethods = "test010FillDatasForFreeze")
	public void test011DoFreezeSlot() throws InterruptedException {
		Assert.assertEquals(freezeTab.saveDatas(), true,
				"Fail to Save Freeze Slot");
	}

	@Test(description = "check Freeze Slot", dependsOnMethods = "test011DoFreezeSlot")
	public void test012CheckFreezeSlot() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(1, 2)) {
			Assert.assertEquals(appointmentsPage.getAppointmentDairy()
					.checkFreezeSlot(st[3].trim(), st[4].trim()), true,
					"Fail to Click on Available Appointment Slot For Freeze");
		}
	}

	// UnFreeze Slot
	@Test(description = "Click on Available Freeze Slot For Un Freeze", dependsOnMethods = "test012CheckFreezeSlot", alwaysRun = true)
	public void test013ClickOnAppoSlotUnFreeze() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(1, 2)) {
			unFreezeTab = appointmentsPage.getAppointmentDairy()
					.clickOnAppSlotForUnFreeze(st[3].trim(), st[4].trim());
			Assert.assertEquals(
					unFreezeTab.getSaveButton().getAttribute("value")
							.equals("Save"), true,
					"Fail to Click on Available Appointment Slot For Un Freeze");
		}
	}

	@Test(description = "Fill datas For un Freeze", dependsOnMethods = "test013ClickOnAppoSlotUnFreeze")
	public void test014FillDatasForUnFreeze() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(1, 2)) {
			Assert.assertEquals(unFreezeTab.fillDatas(st), true,
					"Fail to Fill datas For Un Freeze");
		}
	}

	@Test(description = "Save Un Freeze Slot", dependsOnMethods = "test013ClickOnAppoSlotUnFreeze")
	public void test015DoUnFreezeSlot() throws InterruptedException {
		Assert.assertEquals(unFreezeTab.saveDatas(), true,
				"Fail to Save Un Freeze Slot");
	}

	@Test(description = "check Un Freeze Slot", dependsOnMethods = "test015DoUnFreezeSlot")
	public void test016CheckUnFreezeSlot() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(1, 2)) {
			Assert.assertEquals(appointmentsPage.getAppointmentDairy()
					.checkUnFreezeSlot(st[3].trim(), st[4].trim()), true,
					"Fail to Click on Available Appointment Slot For Un Freeze");
		}
	}

	// More Booking
	@Test(description = "Click on Available Appointment Slot", dependsOnMethods = { "test016CheckUnFreezeSlot" }, alwaysRun = true)
	public void test017BookMoreAppSlots() throws InterruptedException {
		for (String[] st : appointmentsDatas.subList(2,
				appointmentsDatas.size())) {
			Assert.assertEquals(appointmentsPage.getAppointmentDairy()
					.clickOnAppSlotForBook(st[3].trim(), st[4].trim())
					.getRegisterResPatient().getAttribute("value").trim()
					.equals("Register Reserved Patient"), true,
					"Fail to Click on Available Appointment Slot");
			Assert.assertEquals(appointmentsPage.getManageBooking()
					.getBookTab()
					.doQuickSearchPage(st[5].trim(), st[18].trim()), true,
					"Fail to Select a Patient From Manage Booking Page");
			Assert.assertEquals(appointmentsPage.getManageBooking()
					.getBookTab().saveBookingDetails().getBackToAppointButton()
					.getAttribute("value").contains("Back to Appointments"),
					true, "Fail to Save Booking Details");
			Assert.assertEquals(appointmentsPage.getManageBooking()
					.getBookTab().checkAppointmentSlip(), true,
					"Fail to Check Appointment Slip Page");
		}
	}

	/*@Test(description = "Sign Out", dependsOnMethods = "test017BookMoreAppSlots")
	public void test018SignOut() throws Exception {
		loginPage = appointmentsPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "test018SignOut")
	public void test019Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(4,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}*/

//	-----------Appointments Privileges----------
//	[Appointments] Open Form
	@Test(description = "Open [Appointments] Open Form Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	@Parameters("flag")
	public void test01CheckAppointMenuLink(boolean flag) throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("AppSchedExcel"));
		appointmentsPage = PageFactory.initElements(webDriver,
				Appointments.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("Appointment Scheduling");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Appointments");
		appointmentsPage.setWebDriver(webDriver);
		appointmentsPage.setWebDriverWait(webDriverWait);
		appointmentsPage.waitForElementXpathExpression(Appointments.MENULINK_XPATH);
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Appointment Scheduling").get("Appointments")
				.get("[Appointments] Open Form");
		System.out.println("privFilter----------> " + actualPrivilege);
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(Appointments.MENULINK_XPATH));
		System.out
				.println("expectedPrivilege --------->> " + expectedPrivilege);
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail to check [Appointments] Open Form privilege");
		if (actualPrivilege && expectedPrivilege) {
			appointmentsPage = appointmentsPage.clickOnAppointmentsMenu(webDriver, webDriverWait);
			appointmentsPage.setInstance(webDriver, webDriverWait);
			doDirtyFormCheck();
		}
	}
	
	
	
//	[Appointments][Physician Availability] Search By Physician (Radio button in the page))
	
		@Test(description = "Check Search By Physician (Radio button in the page)", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckAppointMenuLink")
		public void test02CheckSearchByPhyRadioBut() throws Exception {
			boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Appointment Scheduling").get("Appointments")
					.get("[Appointments][Physician Availability] Search By Physician (Radio button in the page))");
			System.out.println("privFilter----------> " + actualPrivilage);
			boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.id(PhysicianAvailability.SEARCHBYPHYSICIAN_ID));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Physician Availability] Search By Physician (Radio button in the page) privilege");
		}

	
/*//	[Appointments][Clinics Availability] Search By Clinic (Radio button in the page))
		
		@Test(description = "Check Search By Clinic (Radio button in the page)", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckAppointMenuLink")
		public void test02CheckSearchByCliRadioBut() throws Exception {
			boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Appointment Scheduling").get("Appointments")
					.get("[Appointments][Clinics Availability] Search By Clinic (Radio button in the page))");
			System.out.println("privFilter----------> " + actualPrivilage);
			boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.id(PhysicianAvailability.SEARCHBYCLINIC_ID));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Appointments][Clinics Availability] Search By Clinic (Radio button in the page) privilege");
		}

//		-----------Appointment Diary Privileges----------
//		[Appointment Dairy] View Dairy
		@Test(description = "Check Search By Physician (Radio button in the page)", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckAppointMenuLink")
		public void test03CheckViewDairy() throws Exception {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Appointment Scheduling").get("Appointment Diary")
					.get("[Appointment Dairy] View Dairy");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.xpath(AppointmentDairy.APPDAIRYVIEWDAIRY_XPATH));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Appointment Dairy] View Dairy");
		}

//		[Appointment Dairy][Popup: View Waiting List]
		
		@Test(description = "Check [Appointment Dairy][Popup: View Waiting List]", groups = "checkPrivilegesGrp", dependsOnMethods = "test03CheckViewDairy")
		public void test03CheckViewWaitingListBut() throws Exception {
			boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Appointment Scheduling").get("Appointment Dairy")
					.get("[Appointment Dairy][Popup: View Waiting List]");
			System.out.println("privFilter----------> " + actualPrivilage);
			boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.id(AppointmentDairy.VIEWWAITLISTBUTTON_ID));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Appointment Dairy][Popup: View Waiting List] privilege");
		}
		
//		[Appointment Dairy][Popup: Add Patient to Waiting List]
		@Test(description = "Check [Appointment Dairy][Popup: Add Patient to Waiting List]", groups = "checkPrivilegesGrp", dependsOnMethods = "test03CheckViewDairy")
		public void test03CheckAddPatWaitListBut() throws Exception {
			boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Appointment Scheduling").get("Appointment Dairy")
					.get("[Appointment Dairy][Popup: Add Patient to Waiting List]");
			System.out.println("privFilter----------> " + actualPrivilage);
			boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.id(AppointmentDairy.ADDTOWAITLISTBUTTON_ID));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Appointment Dairy][Popup: Add Patient to Waiting List] privilege");
		}*/
//		[Appointment Dairy] View Patient Name (Information displayed in the booked slot in Appointment Dairy)
//		[Appointment Dairy] View Patient Phone Number (Information displayed in the booked slot in Appointment Dairy)
//		[Appointment Dairy][Audit Trail] View (Tab in Manage Booking Page)
//		[Appointment Dairy][Popup: Pick From Waiting List] 	

//	-----------Appointment Booking Privileges----------
//	[Manage Booking] Normal Book (Tab in Manage Booking Page)
//	[Manage Booking] Register Reserved Patient (Button/Tab in Manage Booking Page)
//	[Manage Booking] No-Session Booking (Slot in the Appointment Diary)
//	[Manage Booking] Over Flow Booking (Slot in the Appointment Diary)
//	[Manage Booking] Over Booking (Tab in Manage Booking Page)
//	[Manage Booking] Executive Booking (Temporarily held slot in Appointment Dairy)
//	[Manage Booking] Proceed to Booking Screen (Button in No Show Warning popup)
//	[Manage Booking] Edit Appointment (Booked slot in the Appointment Diary)
//	[Manage Booking] Cancel Appointment (Popup Button in Booking Page)
//	[Manage Booking] Reschedule Appointment (Popup Button in Booking Page & Enable Drag/Drop in the Appointment Diary)
//	[Manage Booking] Print Appointment Slip (Popup Button  in Booking Page)



//	-----------Freezing/Unfreezing---------------
//	[Freezing] Freeze Slots (Tab in Manage Booking Page)
//	[Un-Freezing] Un-Freeze Slots (Tab in Manage Booking Page)
	
}
