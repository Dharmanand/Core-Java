package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class ReferralDetailsSection extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Referral Details";
	
	@FindBy(linkText=SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	private final static String REFERRALTYPE_ID = "REFERRAL_TYPE_LIST";
	
	@FindBy(id=REFERRALTYPE_ID)
	private WebElement referralType;
	
	private final static String REFERRALBY_ID = "REFERRED_BY";
	
	@FindBy(id=REFERRALBY_ID)
	private WebElement referralBy;
	
	private final static String REFERRALTODEPARTMENT_NAME = "refDetails.referralToDepartment";
	
	@FindBy(name=REFERRALTODEPARTMENT_NAME)
	private WebElement referralToDepartment;
	
	private final static String DATE_ID = "REFERRED_DATE";
	
	@FindBy(id=DATE_ID)
	private WebElement date;
	
	private final static String LANDPHONECODE_ID = "refHomePh";
	
	@FindBy(id=LANDPHONECODE_ID)
	private WebElement landPhoneCode;

	private final static String LANDPHONENUMBER_ID = "refHomePhNo";
	
	@FindBy(id=LANDPHONENUMBER_ID)
	private WebElement landPhoneNumber;
	
	private final static String MOBILECODE_ID = "refMobile";
	
	@FindBy(id=MOBILECODE_ID)
	private WebElement mobileCode;
	
	private final static String MOBILENUMBER_ID = "refMobileNo";
	
	@FindBy(id=MOBILENUMBER_ID)
	private WebElement mobileNumber;
	
	private final static String EMAIL_ID = "email";
	
	@FindBy(id=EMAIL_ID)
	private WebElement email;
	
	private final static String PROBLEM_NAME = "refDetails.problem";
	
	@FindBy(name=PROBLEM_NAME)
	private WebElement problem;
	
	private final static String ADDRESS_NAME = "refDetails.referralAddress";
	
	@FindBy(name=ADDRESS_NAME)
	private WebElement address;
	
	private final static String UPLOADDOCUMENT_ID = "refDetails_documentPath";
	
	@FindBy(id=UPLOADDOCUMENT_ID)
	private WebElement uploadDocument;
	
	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Referral Details')]/..";
	
	@FindBy(xpath=SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	public void fillDatasOfReferralDetailsSection(String[] excelData, WebDriverWait webDriverWait) throws InterruptedException
	{
//		getSectionName().click();
//		sleepVeryShort();
		if(!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute("class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getReferralType()));
		new Select(getReferralType()).selectByVisibleText(excelData[76].trim());
		getDate().clear();
		getDate().sendKeys(excelData[77].trim());
		getEmail().clear();
		getEmail().sendKeys(excelData[78].trim());
		getReferralBy().clear();
		getReferralBy().sendKeys(excelData[79].trim());
		new Select(getLandPhoneCode()).selectByVisibleText(excelData[80].trim());
		getLandPhoneNumber().clear();
		getLandPhoneNumber().sendKeys(excelData[81].trim());
		getProblem().clear();
		getProblem().sendKeys(excelData[82].trim());
		new Select(getReferralToDepartment()).selectByVisibleText(excelData[83].trim());
		new Select(getMobileCode()).selectByVisibleText(excelData[84].trim());
		getMobileNumber().clear();
		getMobileNumber().sendKeys(excelData[85].trim());
		getAddress().clear();
		getAddress().sendKeys(excelData[86].trim());
		getUploadDocument().sendKeys(excelData[87].trim());
	}
	
	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the referralType
	 */
	public WebElement getReferralType() {
		return referralType;
	}

	/**
	 * @return the referralBy
	 */
	public WebElement getReferralBy() {
		return referralBy;
	}

	/**
	 * @return the referralToDepartment
	 */
	public WebElement getReferralToDepartment() {
		return referralToDepartment;
	}

	/**
	 * @return the date
	 */
	public WebElement getDate() {
		return date;
	}

	/**
	 * @return the landPhoneCode
	 */
	public WebElement getLandPhoneCode() {
		return landPhoneCode;
	}

	/**
	 * @return the landPhoneNumber
	 */
	public WebElement getLandPhoneNumber() {
		return landPhoneNumber;
	}

	/**
	 * @return the mobileCode
	 */
	public WebElement getMobileCode() {
		return mobileCode;
	}

	/**
	 * @return the mobileNumber
	 */
	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the email
	 */
	public WebElement getEmail() {
		return email;
	}

	/**
	 * @return the problem
	 */
	public WebElement getProblem() {
		return problem;
	}

	/**
	 * @return the address
	 */
	public WebElement getAddress() {
		return address;
	}

	/**
	 * @return the uploadDocument
	 */
	public WebElement getUploadDocument() {
		return uploadDocument;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the referraltypeId
	 */
	public static String getReferraltypeId() {
		return REFERRALTYPE_ID;
	}

	/**
	 * @return the referralbyId
	 */
	public static String getReferralbyId() {
		return REFERRALBY_ID;
	}

	/**
	 * @return the referraltodepartmentName
	 */
	public static String getReferraltodepartmentName() {
		return REFERRALTODEPARTMENT_NAME;
	}

	/**
	 * @return the dateId
	 */
	public static String getDateId() {
		return DATE_ID;
	}

	/**
	 * @return the landphonecodeId
	 */
	public static String getLandphonecodeId() {
		return LANDPHONECODE_ID;
	}

	/**
	 * @return the landphonenumberId
	 */
	public static String getLandphonenumberId() {
		return LANDPHONENUMBER_ID;
	}

	/**
	 * @return the mobilecodeId
	 */
	public static String getMobilecodeId() {
		return MOBILECODE_ID;
	}

	/**
	 * @return the mobilenumberId
	 */
	public static String getMobilenumberId() {
		return MOBILENUMBER_ID;
	}

	/**
	 * @return the emailId
	 */
	public static String getEmailId() {
		return EMAIL_ID;
	}

	/**
	 * @return the problemName
	 */
	public static String getProblemName() {
		return PROBLEM_NAME;
	}

	/**
	 * @return the addressName
	 */
	public static String getAddressName() {
		return ADDRESS_NAME;
	}

	/**
	 * @return the uploaddocumentId
	 */
	public static String getUploaddocumentId() {
		return UPLOADDOCUMENT_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}
	
}
