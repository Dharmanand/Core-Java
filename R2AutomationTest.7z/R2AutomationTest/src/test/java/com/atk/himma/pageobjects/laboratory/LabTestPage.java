package com.atk.himma.pageobjects.laboratory;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.laboratory.sections.BillingScenarioSec;
import com.atk.himma.pageobjects.laboratory.sections.InstructionsSec;
import com.atk.himma.pageobjects.laboratory.sections.LabTestDetailsDefaultSec;
import com.atk.himma.pageobjects.laboratory.sections.OrderingAttributesSec;
import com.atk.himma.pageobjects.laboratory.sections.PerformingLocationSec;
import com.atk.himma.pageobjects.laboratory.sections.ResultingAttributesSec;
import com.atk.himma.pageobjects.laboratory.sections.SpecimenAttributesSec;
import com.atk.himma.pageobjects.laboratory.sections.TATAttributesSec;
import com.atk.himma.pageobjects.laboratory.tabs.LabTestListTabPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class LabTestPage extends DriverWaitClass {
	private LabTestListTabPage labTestListTabPage;
	private LabTestDetailsDefaultSec labTestDetailsDefaultSec;
	private OrderingAttributesSec orderingAttributesSec;
	private BillingScenarioSec billingScenarioSec;
	private SpecimenAttributesSec specimenAttributesSec;
	private InstructionsSec instructionsSec;
	private ResultingAttributesSec resultingAttributesSec;
	private PerformingLocationSec performingLocationSec;
	private TATAttributesSec tatAttributesSec;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String LABTESTLISTTAB_XPATH = "//a[@title='Lab Test List']";
	@FindBy(xpath = LABTESTLISTTAB_XPATH)
	private WebElement labTestListTab;

	public final static String LABTESTDTLTAB_XPATH = "//a[@title='Lab Test Details']";
	@FindBy(xpath = LABTESTDTLTAB_XPATH)
	private WebElement labTestDetailsTab;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		labTestListTabPage = PageFactory.initElements(webDriver,
				LabTestListTabPage.class);
		labTestListTabPage.setWebDriver(webDriver);
		labTestListTabPage.setWebDriverWait(webDriverWait);

		labTestDetailsDefaultSec = PageFactory.initElements(webDriver,
				LabTestDetailsDefaultSec.class);
		labTestDetailsDefaultSec.setWebDriver(webDriver);
		labTestDetailsDefaultSec.setWebDriverWait(webDriverWait);

		orderingAttributesSec = PageFactory.initElements(webDriver,
				OrderingAttributesSec.class);
		orderingAttributesSec.setWebDriver(webDriver);
		orderingAttributesSec.setWebDriverWait(webDriverWait);

		billingScenarioSec = PageFactory.initElements(webDriver,
				BillingScenarioSec.class);
		billingScenarioSec.setWebDriver(webDriver);
		billingScenarioSec.setWebDriverWait(webDriverWait);

		specimenAttributesSec = PageFactory.initElements(webDriver,
				SpecimenAttributesSec.class);
		specimenAttributesSec.setWebDriver(webDriver);
		specimenAttributesSec.setWebDriverWait(webDriverWait);

		instructionsSec = PageFactory.initElements(webDriver,
				InstructionsSec.class);
		instructionsSec.setWebDriver(webDriver);
		instructionsSec.setWebDriverWait(webDriverWait);

		resultingAttributesSec = PageFactory.initElements(webDriver,
				ResultingAttributesSec.class);
		resultingAttributesSec.setWebDriver(webDriver);
		resultingAttributesSec.setWebDriverWait(webDriverWait);

		performingLocationSec = PageFactory.initElements(webDriver,
				PerformingLocationSec.class);
		performingLocationSec.setWebDriver(webDriver);
		performingLocationSec.setWebDriverWait(webDriverWait);

		tatAttributesSec = PageFactory.initElements(webDriver,
				TATAttributesSec.class);
		tatAttributesSec.setWebDriver(webDriver);
		tatAttributesSec.setWebDriverWait(webDriverWait);

	}

	public LabTestPage clickOnLabTestMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> labTestMenuList = new LinkedList<String>();
		labTestMenuList.add("Laboratory");
		menuSelector.clickOnTargetMenu(labTestMenuList, "Lab Test");
		LabTestPage labTestPage = PageFactory.initElements(webDriver,
				LabTestPage.class);
		labTestPage.setWebDriver(webDriver);
		labTestPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return labTestPage;

	}

	public LabTestListTabPage getLabTestListTabPage() {
		return labTestListTabPage;
	}

	public LabTestDetailsDefaultSec getLabTestDetailsDefaultSec() {
		return labTestDetailsDefaultSec;
	}

	public OrderingAttributesSec getOrderingAttributesSec() {
		return orderingAttributesSec;
	}

	public BillingScenarioSec getBillingScenarioSec() {
		return billingScenarioSec;
	}

	public SpecimenAttributesSec getSpecimenAttributesSec() {
		return specimenAttributesSec;
	}

	public InstructionsSec getInstructionsSec() {
		return instructionsSec;
	}

	public ResultingAttributesSec getResultingAttributesSec() {
		return resultingAttributesSec;
	}

	public PerformingLocationSec getPerformingLocationSec() {
		return performingLocationSec;
	}

	public TATAttributesSec getTatAttributesSec() {
		return tatAttributesSec;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getLabTestListTab() {
		return labTestListTab;
	}

	public WebElement getLabTestDetailsTab() {
		return labTestDetailsTab;
	}

}
