package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PriceListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "PRICE_LIST_FORM";
	public final static String PRICELISTTAB_XPATH = "//a[@title='Price List']";
	public final static String ADDNEWPLBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Add New Price List']";
	public final static String MBU_ID = "PRI_MBU";
	public final static String PRICELISTNAME_ID = "PRI_NAME";
	public final static String STARTDATE_ID = "PRI_START_DATE";
	public final static String ENDDATE_ID = "PRI_END_DATE";
	public final static String SEARCHGLOBALPL_ID = "SEARCH_GLOBAL_PL";
	public final static String PRICODE_ID = "PRI_CODE";
	public final static String STATUS_ID = "PRI_STATUS";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "PRICE_LIST_GRID";
	public final static String GRID_PLCODE_ARIA_DESCRIBEDBY = "PRICE_LIST_GRID_priceListCode";
	public final static String GRID_PLNAME_ARIA_DESCRIBEDBY = "PRICE_LIST_GRID_priceListName";
	public final static String GRID_PLSTARTDATE_ARIA_DESCRIBEDBY = "PRICE_LIST_GRID_effectiveStartDateText";
	public final static String GRID_PLENDDATE_ARIA_DESCRIBEDBY = "PRICE_LIST_GRID_effectiveEndDateText";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "PRICE_LIST_GRID_mbuText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "PRICE_LIST_GRID_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_PRICE_LIST_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_PRICE_LIST_GRID_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = PRICELISTTAB_XPATH)
	private WebElement priceListTab;
	
	@FindBy(xpath = ADDNEWPLBUTTON_XPATH)
	private WebElement addNewPLButton;

	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = PRICELISTNAME_ID)
	private WebElement priceListName;
	
	@FindBy(id = STARTDATE_ID)
	private WebElement startDate;
	
	@FindBy(id = ENDDATE_ID)
	private WebElement endDate;
	
	@FindBy(id = SEARCHGLOBALPL_ID)
	private WebElement searchGlobalPL;
	
	@FindBy(id = PRICODE_ID)
	private WebElement priceCode;
	
	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the priceListTab
	 */
	public WebElement getPriceListTab() {
		return priceListTab;
	}

	/**
	 * @return the addNewPLButton
	 */
	public WebElement getAddNewPLButton() {
		return addNewPLButton;
	}

	/**
	 * @return the priceListName
	 */
	public WebElement getPriceListName() {
		return priceListName;
	}

	/**
	 * @return the startDate
	 */
	public WebElement getStartDate() {
		return startDate;
	}

	/**
	 * @return the endDate
	 */
	public WebElement getEndDate() {
		return endDate;
	}

	/**
	 * @return the searchGlobalPL
	 */
	public WebElement getSearchGlobalPL() {
		return searchGlobalPL;
	}

	/**
	 * @return the priceCode
	 */
	public WebElement getPriceCode() {
		return priceCode;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

}
