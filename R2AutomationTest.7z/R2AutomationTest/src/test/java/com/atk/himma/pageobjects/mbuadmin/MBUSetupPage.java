package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.HomePage;
import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.BusinessTimings;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.DWMParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.GeneralDetails;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.MBUFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.MoreAppParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.OPDParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.RegConfiguration;
import com.atk.himma.pageobjects.mbuadmin.tabs.MBUSetupListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.ExcelReader;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class MBUSetupPage extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	private MBUSetupListTab mbuSetupListTab;

	private MBUFirstSection mbuFirstSection;
	private GeneralDetails generalDetails;
	private BusinessTimings businessTimings;
	private RegConfiguration regConfiguration;
	private OPDParameters opdParameters;
	private MoreAppParameters moreAppParameters;
	private DWMParameters dwmParameters;

	public final static String MENULINK_XPATH = "(//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'MBU Setup')])[1]";
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";

	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'updated successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Record activated successfully')]";

	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;

	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;

	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;

	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement MbuDetailsPageTitle;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;

	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		mbuSetupListTab = PageFactory.initElements(webDriver,
				MBUSetupListTab.class);
		mbuSetupListTab.setWebDriver(webDriver);
		mbuSetupListTab.setWebDriverWait(webDriverWait);

		mbuFirstSection = PageFactory.initElements(webDriver,
				MBUFirstSection.class);
		mbuFirstSection.setWebDriver(webDriver);
		mbuFirstSection.setWebDriverWait(webDriverWait);

		generalDetails = PageFactory.initElements(webDriver,
				GeneralDetails.class);
		generalDetails.setWebDriver(webDriver);
		generalDetails.setWebDriverWait(webDriverWait);

		businessTimings = PageFactory.initElements(webDriver,
				BusinessTimings.class);
		businessTimings.setWebDriver(webDriver);
		businessTimings.setWebDriverWait(webDriverWait);

		regConfiguration = PageFactory.initElements(webDriver,
				RegConfiguration.class);
		regConfiguration.setWebDriver(webDriver);
		regConfiguration.setWebDriverWait(webDriverWait);

		opdParameters = PageFactory
				.initElements(webDriver, OPDParameters.class);
		opdParameters.setWebDriver(webDriver);
		opdParameters.setWebDriverWait(webDriverWait);

		moreAppParameters = PageFactory.initElements(webDriver,
				MoreAppParameters.class);
		moreAppParameters.setWebDriver(webDriver);
		moreAppParameters.setWebDriverWait(webDriverWait);

		dwmParameters = PageFactory
				.initElements(webDriver, DWMParameters.class);
		dwmParameters.setWebDriver(webDriver);
		dwmParameters.setWebDriverWait(webDriverWait);
	}

	public MBUSetupPage clickOnMBUSetupMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "MBU Setup");
		MBUSetupPage mbuSetupPage = PageFactory.initElements(webDriver,
				MBUSetupPage.class);
		mbuSetupPage.setWebDriver(webDriver);
		mbuSetupPage.setWebDriverWait(webDriverWait);
		return mbuSetupPage;
	}

	public String searchMBU(String[] mbuDatas) throws InterruptedException {
		waitForElementId(MBUSetupListTab.MBUNAME_ID);
		mbuSetupListTab.getMbuName().clear();
		mbuSetupListTab.getMbuName().sendKeys(mbuDatas[0]);
		mbuSetupListTab.getSearchButton().click();
		waitForElementId(MBUSetupListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(MBUSetupListTab.GRID_ID,
				MBUSetupListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY, mbuDatas[0]);
	}

	public String configureMBU(String[] mbuDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(MBUSetupListTab.GRID_ID,
				MBUSetupListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY, mbuDatas[0]);
		sleepShort();
		clickOnGridAction(mbuDatas[0], "Configure");
		waitForElementId(MBUFirstSection.MBUNAME_ID);
		sleepVeryShort();
		return mbuFirstSection.getMbuName().getAttribute("value").trim();
	}

	public String editMBUSetup(String[] mbuDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(MBUSetupListTab.GRID_ID,
				MBUSetupListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY, mbuDatas[0]);
		sleepShort();
		clickOnGridAction(mbuDatas[0], "Edit");
		waitForElementId(MBUFirstSection.MBUNAME_ID);
		sleepVeryShort();
		return mbuFirstSection.getMbuName().getAttribute("value").trim();
	}

	public String updateMBUDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepShort();
		detailsUpdateButton.click();
		sleepMedium();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		System.out.println("updateMBUDetails: "
				+ updateConfMsg.getText().trim());
		return updateConfMsg.getText().trim();
	}

	public String login() throws InterruptedException, IOException {

		List<String[]> loginDatas = null;
		ExcelReader excelReader = new ExcelReader();
		HomePage homePage = null;
		LoginPage loginPage = PageFactory.initElements(webDriver,
				LoginPage.class);
		loginPage.setWebDriverWait(webDriverWait);
		excelReader.setInputFile("src//test//resources//excels//Login.xls");
		loginDatas = excelReader.read("LoginDetails");
		sleepVeryShort();
		for (String st[] : loginDatas.subList(4, 5))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		waitForElementXpathExpression(HomePage.HOMETITLE_XPATH);
		homePage.setWebDriverWait(webDriverWait);
		return homePage.getHomeTitle().getAttribute("title").trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {
		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		sleepVeryShort();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		return detailsUpdateButton.getAttribute("value").trim();
	}

	public String activateRecord() throws InterruptedException {
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	/**
	 * @return the mbuSetupListTab
	 */
	public MBUSetupListTab getMbuSetupListTab() {
		return mbuSetupListTab;
	}

	/**
	 * @return the mbuDetailsPageTitle
	 */
	public WebElement getMbuDetailsPageTitle() {
		return MbuDetailsPageTitle;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCanceButton
	 */
	public WebElement getDetailsCanceButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the mbuFirstSection
	 */
	public MBUFirstSection getMbuFirstSection() {
		return mbuFirstSection;
	}

	/**
	 * @return the generalDetails
	 */
	public GeneralDetails getGeneralDetails() {
		return generalDetails;
	}

	/**
	 * @return the regConfiguration
	 */
	public RegConfiguration getRegConfiguration() {
		return regConfiguration;
	}

	/**
	 * @return the opdParameters
	 */
	public OPDParameters getOpdParameters() {
		return opdParameters;
	}

	/**
	 * @return the moreAppParameters
	 */
	public MoreAppParameters getMoreAppParameters() {
		return moreAppParameters;
	}

	/**
	 * @return the dwmParameters
	 */
	public DWMParameters getDwmParameters() {
		return dwmParameters;
	}

	/**
	 * @return the businessTimings
	 */
	public BusinessTimings getBusinessTimings() {
		return businessTimings;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

}
