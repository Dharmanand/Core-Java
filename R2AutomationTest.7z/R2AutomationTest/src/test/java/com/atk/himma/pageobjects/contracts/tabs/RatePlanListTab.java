package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class RatePlanListTab extends DriverWaitClass {
	public final static String RPLISTFORM_ID = "RATE_PLAN_LIST_FORM";
	public final static String ADDNEWRPBTN_ID = "ADD_NEW_RATE_PLAN";
	public final static String MBU_ID = "mainBusinessUnit_id";
	public final static String GLOBALRPCHKBOX_ID = "RP_GLOBAL_CHBOX";
	public final static String DEBTORNAME_ID = "search_by_debtorName";
	public final static String DEBTORTYPE_ID = "debtorType_id";
	public final static String AGRMNTNAME_ID = "agreementName_id";
	public final static String RPYR_ID = "year_id";
	public final static String RPNAME_ID = "ratePlanName_search";
	public final static String RPREFNUM_ID = "referenceNumber_search";
	public final static String RPSEARCHBTN_XPATH = "//form[@id='RATE_PLAN_LIST_FORM']//input[@value='Search']";
	public final static String RPRESETBTN_XPATH = "//form[@id='RATE_PLAN_LIST_FORM']//input[@value='Reset']";
	public final static String RPGRIDDIV_ID = "RATE_PLAN_GRID";
	public final static String VIEWLINK_XPATH = ".//table[@id='RATEPLAN_GRID']/..//a[text()='View']";
	public final static String EDITLINK_XPATH = ".//table[@id='RATEPLAN_GRID']/..//a[text()='Edit']";

	@FindBy(id = RPLISTFORM_ID)
	private WebElement ratePlanForm;

	@FindBy(id = ADDNEWRPBTN_ID)
	private WebElement addNewRPBtn;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = GLOBALRPCHKBOX_ID)
	private WebElement globalRPChkBox;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = AGRMNTNAME_ID)
	private WebElement agrmntName;

	@FindBy(id = RPYR_ID)
	private WebElement RPYear;

	@FindBy(id = RPNAME_ID)
	private WebElement RPName;

	@FindBy(id = RPREFNUM_ID)
	private WebElement RPRefNum;

	@FindBy(xpath = RPSEARCHBTN_XPATH)
	private WebElement RPSearchBtn;

	@FindBy(xpath = RPRESETBTN_XPATH)
	private WebElement RPResetBtn;

	@FindBy(xpath = RPGRIDDIV_ID)
	private WebElement RPGridDiv;

	@FindBy(xpath = VIEWLINK_XPATH)
	private WebElement viewLink;

	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	public void clickAddNewRatePlan() throws Exception {
		addNewRPBtn.click();
		sleepShort();

	}

	public void searchRatePlanList(String[] ratePlanData) throws Exception {
		if (!ratePlanData[9].isEmpty()) {
			new Select(mbu).selectByVisibleText(ratePlanData[9]);
		}

		if (!ratePlanData[7].isEmpty()) {
			new Select(debtorName).selectByVisibleText(ratePlanData[7]);
		}

		if (!ratePlanData[5].isEmpty()) {
			new Select(debtorType).selectByVisibleText(ratePlanData[5]);
		}

		if (!ratePlanData[8].isEmpty()) {
			new Select(agrmntName).selectByVisibleText(ratePlanData[8]);
		}

		RPName.clear();
		RPName.sendKeys(ratePlanData[2]);

		RPRefNum.clear();
		RPRefNum.sendKeys(ratePlanData[0]);

		RPSearchBtn.click();
		waitForElementId(RPGRIDDIV_ID);
		sleepShort();

	}
	
	public void clickEditLink(String[] ratePlanData) throws Exception {
		clickOnGridAction("RATEPLAN_GRID_name", ratePlanData[2], "Edit");
		sleepShort();
		
	}

	public WebElement getRatePlanForm() {
		return ratePlanForm;
	}

	public WebElement getAddNewRPBtn() {
		return addNewRPBtn;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getGlobalRPChkBox() {
		return globalRPChkBox;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getAgrmntName() {
		return agrmntName;
	}

	public WebElement getRPYear() {
		return RPYear;
	}

	public WebElement getRPName() {
		return RPName;
	}

	public WebElement getRPRefNum() {
		return RPRefNum;
	}

	public WebElement getRPSearchBtn() {
		return RPSearchBtn;
	}

	public WebElement getRPResetBtn() {
		return RPResetBtn;
	}

	public WebElement getRPGridDiv() {
		return RPGridDiv;
	}

	public WebElement getViewLink() {
		return viewLink;
	}

	public WebElement getEditLink() {
		return editLink;
	}

}
