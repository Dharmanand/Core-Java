package com.atk.himma.pageobjects.contracts.sections.approvallistdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ApprovalListDetailsSection extends DriverWaitClass {
	public static final String APPRVLLISTDETAILSSEC_LINKTXT = "Approval List Details";
	public final static String SERVDEFPATTERN_ID = "APP_DEF_PATTERN_RADIO2";
	public final static String ICDDEFPATTERN_ID = "APP_DEF_PATTERN_RADIO1";
	public final static String ITEMDEFPATTERN_ID = "APP_DEF_PATTERN_RADIO3";

	public final static String SERVAPPGRIDDIV_ID = "AppServiceApproval";
	public final static String ICDAPPGRIDDIV_ID = "AppICDApproval";
	public final static String ITEMAPPGRIDDIV_ID = "AppItemApproval";

	public final static String SERVADDROWBTN_XPATH = "//div[@id='AppServiceApproval']//input[@id='AddRow_ServiceForm_Action']";
	public final static String ICDADDROWBTN_XPATH = "//div[@id='AppICDApproval']//input[@id='AddRow_ICDForm_Action']";
	public final static String ITEMADDROWBTN_XPATH = "//div[@id='AppItemApproval']//input[@id='AddRow_ItemForm_Action']";

	public final static String SERVLVLLIST_NAME = "serviceLevelCol";
	public final static String SERVLVLCODE_NAME = "serviceLevelCd";
	public final static String SERVLVLNAME_NAME = "serviceLevelName";
	public final static String GRIDSEARCHLOOKUP_ID = "gridSearchLookup";

	public final static String SERVLVLFORM_ID = "APP_SERV_LEVEL_POPUP";
	public final static String SERVLVLDEPT_ID = "APP_SERV_LEVEL";
	public final static String SERVLVLSPLTY_ID = "APP_SERV_LEVEL_SERVSPEC";
	public final static String SERVLVLSUBSPLTY_ID = "APP_SERV_LEVEL_SERVSUBSPEC";
	public final static String SERVLVLTYPE_ID = "APP_SERV_LEVEL_SERTYPE";
	public final static String SERVLVLCODE_ID = "APP_SERV_LEVEL_CODE";
	public final static String SERVLVLNAME_ID = "APP_SERV_LEVEL_NAME";
	public final static String SERVLVLSEARCH_ID = "APP_SERV_LEVEL_SEARCH";
	public final static String SERVLVLRESET_ID = "APP_SERV_LEVEL_RESET";
	public final static String SERVLVLGRIDDIV_ID = "SRV_LEVEL_SEARCH_APP_POPUP_DIV";
	public final static String SERVLVLGRID_ID = "APPROVAL_SERV_LEVEL_GRID";
	public final static String SERVLVLSUBMITBTN_ID = "APP_SERV_LEVEL_SUBMIT";
	public final static String SERVLVLCANCEL_ID = "APP_SERV_LEVEL_CANCEL";

	public final static String SERVTYPEFORM_ID = "APP_SERV_TYPE_POPUP";
	public final static String SERVTYPENAME_ID = "APP_SERV_TYPE_NAME";
	public final static String SERVTYPECODE_ID = "APP_SERV_TYPE_CODE";
	public final static String SERVTYPESEARCHBTN_ID = "SRV_SEARCH_APP_BUTTON";
	public final static String SERVTYPERESETBTN_ID = "APP_SERV_TYPE_RESET";
	public final static String SERVTYPEGRIDDIV_ID = "SRV_SEARCH_APP_POPUP_DIV";
	public final static String SERVTYPEGRID_ID = "APPROVAL_SERV_TYPE_GRID";
	public final static String SERVTYPESUBMITBTN_ID = "APP_SERV_TYPE_SUBMIT";
	public final static String SERVTYPECANCELBTN_ID = "APP_SERV_TYPE_CANCEL";

	public final static String SERVSPLTYFORM_ID = "APP_SERV_SPEC_POPUP";
	public final static String SERVSPLTYDEPT_ID = "APP_SERV_SPEC";
	public final static String SERVSPLTYNAME_ID = "APP_SERV_SPEC_NAME";
	public final static String SERVSPLTYCODE_ID = "APP_SERV_SPEC_CODE";
	public final static String SERVSPLTYSEARCHBTN_ID = "APP_SERV_SPEC_SEARCH";
	public final static String SERVSPLTYRESETBTN_ID = "APP_SERV_SPEC_RESET";
	public final static String SERVSPLTYGRIDDIV_ID = "SRV_SPEC_SEARCH_APP_POPUP_DIV";
	public final static String SERVSPLTYGRID_ID = "APPROVAL_SERV_SPECIALITY_GRID";
	public final static String SERVSPLTYSUBMITBTN_ID = "APP_SERV_SPEC_SUBMIT";
	public final static String SERVSPLTYCANCEL_ID = "APP_SERV_SPEC_CANCEL";

	public final static String SERVSUBSPLTYFORM_ID = "APP_SERV_SUB_SPEC_POPUP";
	public final static String SERVSUBSPLTYDEPT_ID = "APP_SERV_SUB_DEPT";
	public final static String SERVSUBSPLTY_SERVSPLTY_ID = "APP_SERV_SUB_SPEC_SERVSPEC";
	public final static String SERVSUBSPLTYNAME_ID = "APP_SERV_SUB_SPEC_NAME";
	public final static String SERVSUBSPLTYCODE_ID = "APP_SERV_SUB_SPEC_CODE";
	public final static String SERVSUBSPLTYSEARCHBTN_ID = "APP_SERV_SUB_SPEC_SEARCH";
	public final static String SERVSUBSPLTYRESETBTN_ID = "APP_SERV_SUB_SPEC_RESET";
	public final static String SERVSUBSPLTYGRIDDIV_ID = "SRV_SUB_SPEC_SEARCH_APP_POPUP_DIV";
	public final static String SERVSUBSPLTYGRID_ID = "APPROVAL_SERV_SUB_SPECIALITY_GRID";
	public final static String SERVSUBSPLTYSUBMITBTN_ID = "APP_SERV_SUB_SPEC_SUBMIT";
	public final static String SERVSUBSPLTYCANCELBTN_ID = "APP_SERV_SUB_SPEC_CANCEL";

	public final static String SERVISITCATEG_XPATH = "//div[@id='AppServiceApproval']//button[@class='ui-multiselect ui-state-default']";
	public final static String ICDVISITCATEG_XPATH = "//div[@id='AppICDApproval']//button[@class='ui-multiselect ui-state-default']";
	public final static String ITVISITCATEG_XPATH = "//div[@id='AppItemApproval']//button[@class='ui-multiselect ui-state-default']";
	public final static String VISITLIMITTYPE_NAME = "patVisitLimitType";
	public final static String VISITLIMITVALUE_NAME = "patVisitLimit";
	public final static String DURLIMITPERIOD_NAME = "durLimitPeriod";
	public final static String DURLIMITPERIODVALUE_NAME = "durLimitPeriodValue";
	public final static String DURLIMITTYPE_NAME = "durLimitType";
	public final static String DURLIMITTYPEVALUE_NAME = "durLimitTypeValue";
	public final static String SERVAPPRVLDELLINK_XPATH = ".//table[@id='APPROVAL_SERVICE_GRID']/..//a[text()='Delete']";

	public final static String ICDLOOKUPDIV_ID = "icdAppLookup";
	public final static String ICDCODE_ID = "APP_ICD_CODE";
	public final static String ICDDESC_ID = "APP_ICD_DESC";
	public final static String ICDSEARCHBTN_ID = "ICD_SEARCH_APP_BUTTON";
	public final static String ICDRESETBTN_ID = "RESET_APP_ICD";
	public final static String ICDGRIDDIV_ID = "ICD_SEARCH_APP_POPUP_DIV";
	public final static String ICDGRID_ID = "APPROVAL_ICD_SEARCH_POPUP_GRID";
	public final static String ICDSUBMITBTN_ID = "SUBMIT_APP_ICD_SEARCH";
	public final static String ICDCANCELBTN_ID = "CANCEL_APP_ICD_SEARCH";

	public final static String ITEMLVLLIST_NAME = "itemLevelCol";
	public final static String ITEMLVLCODE_NAME = "itemLevelCd";
	public final static String ITEMLVLNAME_NAME = "itemLevelName";
	public final static String ITEMLOOKUP_ID = "APP_ITEM_LEVEL_POPUP";
	public final static String ITEMTYPE_ID = "APP_ITEM_LEVEL_TYPE";
	public final static String ITEMCATEGORY_ID = "APP_ITEM_LEVEL_CAT";
	public final static String ITEMSUBCATEGORY_NAME = "searchCriteriaAppItem.itemSubCategoryId";
	public final static String ITEMCODE_NAME = "searchCriteriaAppItem.itemCode";
	public final static String ITEMNAME_NAME = "searchCriteriaAppItem.itemName";
	public final static String ITEMLVLSEARCH_ID = "ITEM_LEVEL_SEARCH_APP_BUTTON";
	public final static String ITEMLVLRESET_ID = "APP_ITEM_LEVEL_RESET";
	public final static String ITEMLVLGRIDDIV_ID = "ITEM_LEVEL_SEARCH_APP_POPUP_DIV";
	public final static String ITEMLVLGRI_ID = "APPROVAL_ITEM_LEVEL_GRID";
	public final static String ITEMLVLSUBMITBTN_ID = "APP_ITEM_LEVEL_SUBMIT";
	public final static String ITEMLVLCANCELBTN_ID = "APP_ITEM_LEVEL_CANCEL";

	public final static String ITEMTYPEFORM_ID = "APP_ITEM_TYPE_POPUP";
	public final static String ITEMTYPENAME_ID = "APP_ITEM_TYPE_NAME";
	public final static String ITEMTYPECODE_ID = "APP_ITEM_TYPE_CODE";
	public final static String ITEMTYPESEARCHBTN_ID = "ITEM_SEARCH_APP_BUTTON";
	public final static String ITEMTYPERESETBTN_ID = "APP_ITEM_TYPE_RESET";
	public final static String ITEMTYPEGRIDDIV_ID = "ITEM_SEARCH_APP_POPUP_DIV";
	public final static String ITEMTYPEGRID_ID = "APPROVAL_ITEM_TYPE_GRID";
	public final static String ITEMTYPESUBMITBTN_ID = "APP_ITEM_TYPE_SUBMIT";
	public final static String ITEMTYPECANCELBTN_ID = "APP_ITEM_TYPE_CANCEL";

	public final static String ITEMCATEGORYFORM_ID = "APP_ITEM_CAT_POPUP";
	public final static String ITEMCAT_ITEMTYPE_ID = "APP_ITEM_CAT_TYPE";
	public final static String ITEMCATNAME_ID = "APP_ITEM_CAT_NAME";
	public final static String ITEMCATCODE_ID = "APP_ITEM_CAT_CODE";
	public final static String ITEMCATSEARCHBTN_ID = "ITEM_CAT_SEARCH_APP_BUTTON";
	public final static String ITEMCATRESETBTN_ID = "APP_ITEM_CAT_RESET";
	public final static String ITEMCATGRIDDIV_ID = "ITEM_CAT_SEARCH_APP_POPUP_DIV";
	public final static String ITEMCATGRID_ID = "APPROVAL_ITEM_CATEGORY_GRID";
	public final static String ITEMCATSUBMITBTN_ID = "APP_ITEM_CAT_SUBMIT";
	public final static String ITEMCATCANCELBTN_ID = "APP_ITEM_CAT_CANCEL";

	public final static String ITEMSUBCATFORM_ID = "APP_ITEM_SUB_CAT_POPUP";
	public final static String ITEMSUBCAT_ITMTYPE_ID = "APP_ITEM_SUB_CAT_TYPE";
	public final static String ITEMSUBCAT_ITMCAT_ID = "APP_ITEM_SUB_CAT_CATEGORY";
	public final static String ITEMSUBCATNAME_ID = "APP_ITEM_SUB_CAT_NAME";
	public final static String ITEMSUBCATCODE_ID = "APP_ITEM_SUB_CAT_CODE";
	public final static String ITEMSUBCATSEARCHBTN_ID = "ITEM_SUB_CAT_SEARCH_APP_BUTTON";
	public final static String ITEMSUBCATRESETBTN_ID = "APP_ITEM_SUB_CAT_RESET";
	public final static String ITEMSUBCATGRIDDIV_ID = "ITEM_SUB_CAT_SEARCH_APP_POPUP_DIV";
	public final static String ITEMSUBCATGRID_ID = "APPROVAL_ITEM_SUB_CATEGORY_GRID";
	public final static String ITEMSUBCATSUBMITBTN_ID = "APP_ITEM_SUB_CAT_SUBMIT";
	public final static String ITEMSUBCATCANCELBTN_ID = "APP_ITEM_SUB_CAT_CANCEL";

	public final static String APPLYAPPRVLLISTTOCHKBOX_ID = "Apply_Approval_List_To";
	public final static String APPLYAPPRVLLISTTOPOLCHKBOX_ID = "Apply_Approval_List_To_AGMNT";
	public final static String APPLYAPPRVLLISTTOCLSCHKBOX_ID = "Apply_the_Above_Approval_List_To";
	public final static String AGRMNTSMULTISELECT_NAME = "multiselect_ASSO_APPROVAL_LIST";
	public final static String POLICYMULTISELECT_NAME = "multiselect_ASSO_AGG_APPROVAL_LIST";
	public final static String CLASSMULTISELECT_NAME = "multiselect_POLICY_APPL_TO_CLASSES_APP";

	private final static String SERVICE = "Service",
			SERVICE_TYPE = "Service Type",
			SERVICE_SPECIALTY = "Service Specialty",
			SERVICE_SUB_SPECIALTY = "Service Sub Specialty", ITEM = "Item",
			ITEM_TYPE = "Item Type", ITEM_CATEGORY = "Item Category",
			ITEM_SUB_CATEGORY = "Item Sub Category",
			SELECTED_AGRMNTS = "Selected Agreements",
			SELECTED_POL = "Selected Policies",
			SELECTED_CLS = "Selected Classes";

	@FindBy(id = SERVDEFPATTERN_ID)
	private WebElement servDefPattern;

	@FindBy(id = ICDDEFPATTERN_ID)
	private WebElement icdDefPattern;

	@FindBy(id = ITEMDEFPATTERN_ID)
	private WebElement itemDefPattern;

	@FindBy(id = SERVAPPGRIDDIV_ID)
	private WebElement servAppGridDiv;

	@FindBy(id = ICDAPPGRIDDIV_ID)
	private WebElement icdAppGridDiv;

	@FindBy(id = ITEMAPPGRIDDIV_ID)
	private WebElement itemAppGridDiv;

	@FindBy(xpath = SERVADDROWBTN_XPATH)
	private WebElement addServiceButton;

	@FindBy(xpath = ICDADDROWBTN_XPATH)
	private WebElement addIcdButton;

	@FindBy(xpath = ITEMADDROWBTN_XPATH)
	private WebElement addItemButton;

	@FindBy(name = SERVLVLLIST_NAME)
	private WebElement serviceLvlList;

	@FindBy(name = SERVLVLNAME_NAME)
	private WebElement serviceLvlName;

	@FindBy(id = GRIDSEARCHLOOKUP_ID)
	private WebElement gridSearchLookup;

	@FindBy(id = SERVLVLFORM_ID)
	private WebElement serviceLvlForm;

	@FindBy(id = SERVLVLDEPT_ID)
	private WebElement department;

	@FindBy(id = SERVLVLSPLTY_ID)
	private WebElement serviceSpecialty;

	@FindBy(id = SERVLVLSUBSPLTY_ID)
	private WebElement serviceSubSpecialty;

	@FindBy(id = SERVLVLTYPE_ID)
	private WebElement serviceType;

	@FindBy(id = SERVLVLCODE_ID)
	private WebElement serviceCode;

	@FindBy(id = SERVLVLNAME_ID)
	private WebElement serviceName;

	@FindBy(id = SERVLVLSEARCH_ID)
	private WebElement serviceSearchBtn;

	@FindBy(id = SERVLVLRESET_ID)
	private WebElement serviceResetBtn;

	@FindBy(id = SERVLVLGRIDDIV_ID)
	private WebElement serviceGridDiv;

	@FindBy(id = SERVLVLSUBMITBTN_ID)
	private WebElement serviceSubmitBtn;

	@FindBy(id = SERVLVLCANCEL_ID)
	private WebElement serviceCancelBtn;

	@FindBy(id = SERVTYPEFORM_ID)
	private WebElement serviceTypeForm;

	@FindBy(id = SERVTYPENAME_ID)
	private WebElement serviceTypeName;

	@FindBy(id = SERVTYPECODE_ID)
	private WebElement serviceTypeCode;

	@FindBy(id = SERVTYPESEARCHBTN_ID)
	private WebElement serviceTypeSearchBtn;

	@FindBy(id = SERVTYPERESETBTN_ID)
	private WebElement serviceTypeResetBtn;

	@FindBy(id = SERVTYPEGRIDDIV_ID)
	private WebElement serviceTypeGridDiv;

	@FindBy(id = SERVTYPESUBMITBTN_ID)
	private WebElement serviceTypeSubmitBtn;

	@FindBy(id = SERVTYPECANCELBTN_ID)
	private WebElement serviceTypeCancelBtn;

	@FindBy(id = SERVSPLTYFORM_ID)
	private WebElement serviceSpltyForm;

	@FindBy(id = SERVSPLTYDEPT_ID)
	private WebElement serviceSpltyDept;

	@FindBy(id = SERVSPLTYNAME_ID)
	private WebElement serviceSpltyName;

	@FindBy(id = SERVSPLTYCODE_ID)
	private WebElement serviceSpltyCode;

	@FindBy(id = SERVSPLTYSEARCHBTN_ID)
	private WebElement serviceSpltySearchBtn;

	@FindBy(id = SERVSPLTYRESETBTN_ID)
	private WebElement serviceSpltyResetBtn;

	@FindBy(id = SERVSPLTYGRIDDIV_ID)
	private WebElement serviceSpltyGridDiv;

	@FindBy(id = SERVSPLTYSUBMITBTN_ID)
	private WebElement serviceSpltySubmitBtn;

	@FindBy(id = SERVSPLTYCANCEL_ID)
	private WebElement serviceSpltyCancelBtn;

	@FindBy(id = SERVSUBSPLTYFORM_ID)
	private WebElement serviceSubSpltyForm;

	@FindBy(id = SERVSUBSPLTYDEPT_ID)
	private WebElement serviceSubSpltyDept;

	@FindBy(id = SERVSUBSPLTY_SERVSPLTY_ID)
	private WebElement serviceSubSplty_ServSplty;

	@FindBy(id = SERVSUBSPLTYNAME_ID)
	private WebElement serviceSubSpltyName;

	@FindBy(id = SERVSUBSPLTYCODE_ID)
	private WebElement serviceSubSpltyCode;

	@FindBy(id = SERVSUBSPLTYSEARCHBTN_ID)
	private WebElement serviceSubSpltySearchBtn;

	@FindBy(id = SERVSUBSPLTYRESETBTN_ID)
	private WebElement serviceSubSpltyResetBtn;

	@FindBy(id = SERVSUBSPLTYGRIDDIV_ID)
	private WebElement serviceSubSpltyGridDiv;

	@FindBy(id = SERVSUBSPLTYSUBMITBTN_ID)
	private WebElement serviceSubSpltySubmitBtn;

	@FindBy(id = SERVSUBSPLTYCANCELBTN_ID)
	private WebElement serviceSubSpltyCancelBtn;

	@FindBy(xpath = SERVISITCATEG_XPATH)
	private WebElement serVisitCategory;

	@FindBy(xpath = ICDVISITCATEG_XPATH)
	private WebElement icdVisitCategory;

	@FindBy(xpath = ITVISITCATEG_XPATH)
	private WebElement itmVisitCategory;

	@FindBy(name = VISITLIMITTYPE_NAME)
	private WebElement visitLimitType;

	@FindBy(name = VISITLIMITVALUE_NAME)
	private WebElement visitLimitTypeValue;

	@FindBy(name = DURLIMITPERIOD_NAME)
	private WebElement durLimitPeriod;

	@FindBy(name = DURLIMITPERIODVALUE_NAME)
	private WebElement durLimitPeriodValue;

	@FindBy(name = DURLIMITTYPE_NAME)
	private WebElement durLimitType;

	@FindBy(name = DURLIMITTYPEVALUE_NAME)
	private WebElement durLimitTypeValue;

	@FindBy(xpath = SERVAPPRVLDELLINK_XPATH)
	private WebElement servApprvlDelLink;

	@FindBy(id = ICDLOOKUPDIV_ID)
	private WebElement icdLookup;

	@FindBy(id = ICDCODE_ID)
	private WebElement icdCode;

	@FindBy(id = ICDDESC_ID)
	private WebElement icdDescription;

	@FindBy(id = ICDSEARCHBTN_ID)
	private WebElement icdSearchBtn;

	@FindBy(id = ICDRESETBTN_ID)
	private WebElement icdResetBtn;

	@FindBy(id = ICDGRIDDIV_ID)
	private WebElement icdGridDiv;

	@FindBy(id = ICDSUBMITBTN_ID)
	private WebElement icdSubmitBtn;

	@FindBy(id = ICDCANCELBTN_ID)
	private WebElement icdCancelBtn;

	@FindBy(name = ITEMLVLLIST_NAME)
	private WebElement itemLvlList;

	@FindBy(id = ITEMLOOKUP_ID)
	private WebElement itemLvlLookup;

	@FindBy(id = ITEMTYPE_ID)
	private WebElement itemType;

	@FindBy(id = ITEMCATEGORY_ID)
	private WebElement itemCategory;

	@FindBy(name = ITEMSUBCATEGORY_NAME)
	private WebElement itemSubCategory;

	@FindBy(name = ITEMCODE_NAME)
	private WebElement itemCode;

	@FindBy(name = ITEMNAME_NAME)
	private WebElement itemName;

	@FindBy(id = ITEMLVLSEARCH_ID)
	private WebElement itemSearchBtn;

	@FindBy(id = ITEMLVLRESET_ID)
	private WebElement itemResetBtn;

	@FindBy(id = ITEMLVLGRIDDIV_ID)
	private WebElement itemGridDiv;

	@FindBy(id = ITEMLVLSUBMITBTN_ID)
	private WebElement itemSubmitBtn;

	@FindBy(id = ITEMLVLCANCELBTN_ID)
	private WebElement itemCancelBtn;

	@FindBy(id = ITEMTYPEFORM_ID)
	private WebElement itemTypeForm;

	@FindBy(id = ITEMTYPENAME_ID)
	private WebElement itemTypeName;

	@FindBy(id = ITEMTYPECODE_ID)
	private WebElement itemTypeCode;

	@FindBy(id = ITEMTYPESEARCHBTN_ID)
	private WebElement itemTypeSearchBtn;

	@FindBy(id = ITEMTYPERESETBTN_ID)
	private WebElement itemTypeResetBtn;

	@FindBy(id = ITEMTYPEGRIDDIV_ID)
	private WebElement itemTypeGridDiv;

	@FindBy(id = ITEMTYPESUBMITBTN_ID)
	private WebElement itemTypeSubmitBtn;

	@FindBy(id = ITEMTYPECANCELBTN_ID)
	private WebElement itemTypeCancelBtn;

	@FindBy(id = ITEMCATEGORYFORM_ID)
	private WebElement itemCategoryForm;

	@FindBy(id = ITEMCAT_ITEMTYPE_ID)
	private WebElement itemCatItemType;

	@FindBy(id = ITEMCATNAME_ID)
	private WebElement itemCatName;

	@FindBy(id = ITEMCATCODE_ID)
	private WebElement itemCatCode;

	@FindBy(id = ITEMCATSEARCHBTN_ID)
	private WebElement itemCatSearchBtn;

	@FindBy(id = ITEMCATRESETBTN_ID)
	private WebElement itemCatResetBtn;

	@FindBy(id = ITEMCATGRIDDIV_ID)
	private WebElement itemCatGridDiv;

	@FindBy(id = ITEMCATSUBMITBTN_ID)
	private WebElement itemCatSubmitBtn;

	@FindBy(id = ITEMCATCANCELBTN_ID)
	private WebElement itemCatCancelBtn;

	@FindBy(id = ITEMSUBCATFORM_ID)
	private WebElement itemSubCatForm;

	@FindBy(id = ITEMSUBCAT_ITMTYPE_ID)
	private WebElement itemSubCatItemType;

	@FindBy(id = ITEMSUBCAT_ITMCAT_ID)
	private WebElement itemSubCatItemCategory;

	@FindBy(id = ITEMSUBCATNAME_ID)
	private WebElement itemSubCatName;

	@FindBy(id = ITEMSUBCATCODE_ID)
	private WebElement itemSubCatCode;

	@FindBy(id = ITEMSUBCATSEARCHBTN_ID)
	private WebElement itemSubCatSearchBtn;

	@FindBy(id = ITEMSUBCATRESETBTN_ID)
	private WebElement itemSubCatResetBtn;

	@FindBy(id = ITEMSUBCATGRIDDIV_ID)
	private WebElement itemSubCatGridDiv;

	@FindBy(id = ITEMSUBCATSUBMITBTN_ID)
	private WebElement itemSubCatSubmitBtn;

	@FindBy(id = ITEMSUBCATCANCELBTN_ID)
	private WebElement itemSubCatCancelBtn;

	@FindBy(id = APPLYAPPRVLLISTTOCHKBOX_ID)
	private WebElement applyApprvlListToChkBox;

	@FindBy(id = APPLYAPPRVLLISTTOPOLCHKBOX_ID)
	private WebElement applyApprvlListToPolicyChkBox;

	@FindBy(id = APPLYAPPRVLLISTTOCLSCHKBOX_ID)
	private WebElement applyApprvlListToClassChkBox;

	@FindBy(id = AGRMNTSMULTISELECT_NAME)
	private WebElement agrmntsMultiselectChkBox;

	@FindBy(id = POLICYMULTISELECT_NAME)
	private WebElement policyMultiselectChkBox;

	@FindBy(id = CLASSMULTISELECT_NAME)
	private WebElement classMultiselectChkBox;

	public void addServiceApprvlData(String[] serviceApprvlListData)
			throws Exception {
		servDefPattern.click();
		sleepVeryShort();
		waitForElementId(SERVAPPGRIDDIV_ID);
		addServiceButton.click();
		sleepVeryShort();
		if (!serviceApprvlListData[1].isEmpty()) {
			new Select(serviceLvlList)
					.selectByVisibleText(serviceApprvlListData[1]);
		}
		gridSearchLookup.click();
		selectServiceLevelName(serviceApprvlListData);
		sleepMedium();
		selectVisitCategory(serVisitCategory,
				"multiselect_new_service_appl_1_visitCategory",
				serviceApprvlListData[17]);
		if (!serviceApprvlListData[18].isEmpty()) {
			new Select(visitLimitType)
					.selectByVisibleText(serviceApprvlListData[18]);
		}
		visitLimitTypeValue.clear();
		visitLimitTypeValue.sendKeys(serviceApprvlListData[19]);

		if (!serviceApprvlListData[20].isEmpty()) {
			new Select(durLimitPeriod)
					.selectByVisibleText(serviceApprvlListData[20]);
		}
		durLimitPeriodValue.clear();
		durLimitPeriodValue.sendKeys(serviceApprvlListData[21]);

		if (!serviceApprvlListData[22].isEmpty()) {
			new Select(durLimitType)
					.selectByVisibleText(serviceApprvlListData[22]);
		}
		durLimitTypeValue.clear();
		durLimitTypeValue.sendKeys(serviceApprvlListData[23]);

	}

	public void addICDApprvlData(String[] icdApprvlListData) throws Exception {
		icdDefPattern.click();
		sleepVeryShort();
		waitForElementId(ICDAPPGRIDDIV_ID);
		addIcdButton.click();
		sleepVeryShort();
		gridSearchLookup.click();
		waitForElementId(ICDLOOKUPDIV_ID);
		icdCode.clear();
		icdCode.sendKeys(icdApprvlListData[1]);
		icdDescription.clear();
		icdDescription.sendKeys(icdApprvlListData[2]);
		icdSearchBtn.click();
		// sleepShort();
		// waitForElementId(ICDGRIDDIV_ID);
		// webDriver
		// .findElement(
		// By.xpath("//td[@aria-describedby='APPROVAL_ICD_SEARCH_POPUP_GRID_icdDesc' and @title='"
		// + icdApprvlListData[2]
		// +
		// "']/..//td[@aria-describedby='APPROVAL_ICD_SEARCH_POPUP_GRID_cb']/input"))
		// .click();

		clickOnCheckBoxGridItem(ICDGRID_ID, icdApprvlListData[2].trim());
		icdSubmitBtn.click();
		sleepMedium();
		selectVisitCategory(icdVisitCategory,
				"multiselect_new_app_icd_row1_visitCategory",
				icdApprvlListData[3]);
		if (!icdApprvlListData[4].isEmpty()) {
			new Select(visitLimitType)
					.selectByVisibleText(icdApprvlListData[4]);
		}
		visitLimitTypeValue.clear();
		visitLimitTypeValue.sendKeys(icdApprvlListData[5]);

		if (!icdApprvlListData[6].isEmpty()) {
			new Select(durLimitPeriod)
					.selectByVisibleText(icdApprvlListData[6]);
		}
		durLimitPeriodValue.clear();
		durLimitPeriodValue.sendKeys(icdApprvlListData[7]);

		if (!icdApprvlListData[8].isEmpty()) {
			new Select(durLimitType).selectByVisibleText(icdApprvlListData[8]);
		}
		durLimitTypeValue.clear();
		durLimitTypeValue.sendKeys(icdApprvlListData[9]);

	}

	public void addItemApprvlData(String[] itemApprvlListData) throws Exception {
		itemDefPattern.click();
		waitForElementId(ITEMAPPGRIDDIV_ID);
		sleepVeryShort();
		addItemButton.click();
		sleepVeryShort();
		if (!itemApprvlListData[1].isEmpty()) {
			new Select(itemLvlList).selectByVisibleText(itemApprvlListData[1]);
		}
		gridSearchLookup.click();
		selectItemLevelName(itemApprvlListData);
		sleepMedium();
		selectVisitCategory(itmVisitCategory,
				"multiselect_new_item_appl_1_visitCategory",
				itemApprvlListData[16]);
		if (!itemApprvlListData[17].isEmpty()) {
			new Select(visitLimitType)
					.selectByVisibleText(itemApprvlListData[17]);
		}
		visitLimitTypeValue.clear();
		visitLimitTypeValue.sendKeys(itemApprvlListData[18]);

		if (!itemApprvlListData[19].isEmpty()) {
			new Select(durLimitPeriod)
					.selectByVisibleText(itemApprvlListData[19]);
		}
		durLimitPeriodValue.clear();
		durLimitPeriodValue.sendKeys(itemApprvlListData[20]);

		if (!itemApprvlListData[21].isEmpty()) {
			new Select(durLimitType)
					.selectByVisibleText(itemApprvlListData[21]);
		}
		durLimitTypeValue.clear();
		durLimitTypeValue.sendKeys(itemApprvlListData[22]);

	}

	private void selectServiceLevelName(String[] serviceApprvlListData)
			throws Exception {
		if (SERVICE.equals(serviceApprvlListData[1])) {
			waitForElementId(SERVLVLFORM_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[2].isEmpty()) {
				new Select(department)
						.selectByVisibleText(serviceApprvlListData[2]);
			}
			waitForElementId(SERVLVLSPLTY_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[3].isEmpty()) {
				new Select(serviceSpecialty)
						.selectByVisibleText(serviceApprvlListData[3]);
			}
			waitForElementId(SERVLVLSUBSPLTY_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[4].isEmpty()) {
				new Select(serviceSubSpecialty)
						.selectByVisibleText(serviceApprvlListData[4]);
			}
			waitForElementId(SERVLVLTYPE_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[5].isEmpty()) {
				new Select(serviceType)
						.selectByVisibleText(serviceApprvlListData[5]);
			}
			waitForElementId(SERVLVLCODE_ID);
			serviceCode.clear();
			serviceCode.sendKeys(serviceApprvlListData[6]);

			waitForElementId(SERVLVLNAME_ID);
			serviceName.clear();
			serviceName.sendKeys(serviceApprvlListData[7]);
			serviceSearchBtn.click();
			// sleepShort();
			// waitForElementId(SERVLVLGRIDDIV_ID);
			// sleepVeryShort();
			// webDriver
			// .findElement(
			// By.xpath("//td[@aria-describedby='APPROVAL_SERV_LEVEL_GRID_serviceName' and @title='"
			// + serviceApprvlListData[7]
			// +
			// "']/..//td[@aria-describedby='APPROVAL_SERV_LEVEL_GRID_cb']/input"))
			// .click();

			clickOnCheckBoxGridItem(SERVLVLGRID_ID,
					serviceApprvlListData[7].trim());
			serviceSubmitBtn.click();

		} else if (SERVICE_TYPE.equals(serviceApprvlListData[1])) {
			waitForElementId(SERVTYPEFORM_ID);
			serviceTypeName.clear();
			serviceTypeName.sendKeys(serviceApprvlListData[8]);

			serviceTypeCode.clear();
			serviceTypeCode.sendKeys(serviceApprvlListData[9]);
			serviceTypeSearchBtn.click();
			// waitForElementId(SERVTYPEGRIDDIV_ID);
			// sleepVeryShort();
			// webDriver
			// .findElement(
			// By.xpath("//td[@aria-describedby='APPROVAL_SERV_TYPE_GRID_serviceName' and @title='"
			// + serviceApprvlListData[8]
			// +
			// "']/..//td[@aria-describedby='APPROVAL_SERV_TYPE_GRID_cb']/input"))
			// .click();

			clickOnCheckBoxGridItem(SERVTYPEGRID_ID,
					serviceApprvlListData[8].trim());
			serviceTypeSubmitBtn.click();

		} else if (SERVICE_SPECIALTY.equals(serviceApprvlListData[1])) {
			waitForElementId(SERVSPLTYFORM_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[10].isEmpty()) {
				new Select(serviceSpltyDept)
						.selectByVisibleText(serviceApprvlListData[10]);
			}
			waitForElementId(SERVSPLTYNAME_ID);
			serviceSpltyName.clear();
			serviceSpltyName.sendKeys(serviceApprvlListData[11]);
			waitForElementId(SERVSPLTYCODE_ID);
			serviceSpltyCode.clear();
			serviceSpltyCode.sendKeys(serviceApprvlListData[12]);
			serviceSpltySearchBtn.click();
			clickOnCheckBoxGridItem(SERVSPLTYGRID_ID,
					serviceApprvlListData[11].trim());
			serviceSpltySubmitBtn.click();

		} else if (SERVICE_SUB_SPECIALTY.equals(serviceApprvlListData[1])) {
			waitForElementId(SERVSUBSPLTYFORM_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[13].isEmpty()) {
				new Select(serviceSubSpltyDept)
						.selectByVisibleText(serviceApprvlListData[13]);
			}
			waitForElementId(SERVSUBSPLTY_SERVSPLTY_ID);
			sleepVeryShort();
			if (!serviceApprvlListData[14].isEmpty()) {
				new Select(serviceSubSplty_ServSplty)
						.selectByVisibleText(serviceApprvlListData[14]);
			}
			waitForElementId(SERVSUBSPLTYNAME_ID);
			serviceSubSpltyName.clear();
			serviceSubSpltyName.sendKeys(serviceApprvlListData[15]);

			waitForElementId(SERVSUBSPLTYCODE_ID);
			serviceSubSpltyCode.clear();
			serviceSubSpltyCode.sendKeys(serviceApprvlListData[16]);
			serviceSubSpltySearchBtn.click();
			clickOnCheckBoxGridItem(SERVSUBSPLTYGRID_ID,
					serviceApprvlListData[15].trim());
			serviceSubSpltySubmitBtn.click();

		}

	}

	private void selectItemLevelName(String[] itemApprvlListData)
			throws Exception {
		if (ITEM.equals(itemApprvlListData[1])) {
			waitForElementId(ITEMLOOKUP_ID);
			sleepVeryShort();
			if (!itemApprvlListData[2].isEmpty()) {
				new Select(itemType).selectByVisibleText(itemApprvlListData[2]);
			}
			waitForElementId(ITEMCATEGORY_ID);
			sleepVeryShort();
			if (!itemApprvlListData[3].isEmpty()) {
				new Select(itemCategory)
						.selectByVisibleText(itemApprvlListData[3]);
			}
			waitForElementName(ITEMSUBCATEGORY_NAME);
			sleepVeryShort();
			if (!itemApprvlListData[4].isEmpty()) {
				new Select(itemSubCategory)
						.selectByVisibleText(itemApprvlListData[4]);
			}
			waitForElementName(ITEMCODE_NAME);
			itemCode.clear();
			itemCode.sendKeys(itemApprvlListData[5]);

			waitForElementName(ITEMNAME_NAME);
			itemName.clear();
			itemName.sendKeys(itemApprvlListData[6]);
			itemSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMLVLGRI_ID, itemApprvlListData[6].trim());
			itemSubmitBtn.click();

		} else if (ITEM_TYPE.equals(itemApprvlListData[1])) {
			waitForElementId(ITEMTYPEFORM_ID);
			itemTypeName.clear();
			itemTypeName.sendKeys(itemApprvlListData[7]);

			itemTypeCode.clear();
			itemTypeCode.sendKeys(itemApprvlListData[8]);
			itemTypeSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMTYPEGRID_ID,
					itemApprvlListData[8].trim());
			itemTypeSubmitBtn.click();

		} else if (ITEM_CATEGORY.equals(itemApprvlListData[1])) {
			waitForElementId(ITEMCATEGORYFORM_ID);
			sleepVeryShort();
			if (!itemApprvlListData[9].isEmpty()) {
				new Select(itemCatItemType)
						.selectByVisibleText(itemApprvlListData[9]);
			}
			waitForElementId(ITEMCATNAME_ID);
			itemCatName.clear();
			itemCatName.sendKeys(itemApprvlListData[10]);

			waitForElementId(ITEMCATCODE_ID);
			itemCatCode.clear();
			itemCatCode.sendKeys(itemApprvlListData[11]);
			itemCatSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMCATGRID_ID,
					itemApprvlListData[10].trim());
			itemCatSubmitBtn.click();

		} else if (ITEM_SUB_CATEGORY.equals(itemApprvlListData[1])) {
			waitForElementId(ITEMSUBCATFORM_ID);
			sleepVeryShort();
			if (!itemApprvlListData[13].isEmpty()) {
				new Select(itemSubCatItemType)
						.selectByVisibleText(itemApprvlListData[12]);
			}
			waitForElementId(ITEMSUBCAT_ITMCAT_ID);
			sleepVeryShort();
			if (!itemApprvlListData[13].isEmpty()) {
				new Select(itemSubCatItemCategory)
						.selectByVisibleText(itemApprvlListData[13]);
			}
			waitForElementId(ITEMSUBCATNAME_ID);
			itemSubCatName.clear();
			itemSubCatName.sendKeys(itemApprvlListData[14]);

			waitForElementId(ITEMSUBCATCODE_ID);
			itemSubCatCode.clear();
			itemSubCatCode.sendKeys(itemApprvlListData[15]);
			itemSubCatSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMSUBCATGRID_ID,
					itemApprvlListData[14].trim());
			itemSubCatSubmitBtn.click();

		}
	}

	public void applyApprvlListToAgrmnts(String[] debtorListData)
			throws Exception {
		applyApprvlListToChkBox.click();
		sleepShort();
		selectRadioButtonAsLabelText(debtorListData[39]);
		if (SELECTED_AGRMNTS.equals(debtorListData[39])) {
			String[] temp;
			String delimiter = "\\,";
			temp = debtorListData[40].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				webDriver.findElement(
						By.xpath("//input[@name='" + AGRMNTSMULTISELECT_NAME
								+ "' and @title='" + temp[i] + "']")).click();
			}
		}
	}

	public void applyApprvlListToPolicies(String[] policyListData)
			throws Exception {
		applyApprvlListToPolicyChkBox.click();
		sleepShort();
		selectRadioButtonAsLabelText(policyListData[75]);
		if (SELECTED_POL.equals(policyListData[75])) {
			String[] temp;
			String delimiter = "\\,";
			temp = policyListData[76].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				webDriver.findElement(
						By.xpath("//input[@name='" + POLICYMULTISELECT_NAME
								+ "' and @title='" + temp[i] + "']")).click();
			}
		}

	}

	public void applyApprvlListToClasses(String[] classListData)
			throws Exception {
		applyApprvlListToClassChkBox.click();
		sleepShort();
		selectRadioButtonAsLabelText(classListData[42]);
		if (SELECTED_CLS.equals(classListData[42])) {
			String[] temp;
			String delimiter = "\\,";
			temp = classListData[43].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				webDriver.findElement(
						By.xpath("//input[@name='" + CLASSMULTISELECT_NAME
								+ "' and @title='" + temp[i] + "']")).click();
			}
		}

	}

	private void selectVisitCategory(WebElement catBtn, String name,
			String visitCat) throws Exception {
		sleepShort();
		catBtn.click();
		String[] temp;
		String delimiter = "\\,";
		temp = visitCat.split(delimiter);
		for (int i = 0; i < temp.length; i++) {
			webDriver.findElement(
					By.xpath("//input[@name='" + name + "' and @title='"
							+ temp[i] + "']")).click();
		}
	}

	public boolean checkApprvlGrid(String[] serviceApprvlListData) {
		try {
			waitForElementXpathExpression("//td[@aria-describedby='APPROVAL_SERVICE_GRID_serviceLevelName' and @title='"
					+ serviceApprvlListData[7] + "']");
			sleepVeryShort();
			return webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='APPROVAL_SERVICE_GRID_serviceLevelName' and @title='"
									+ serviceApprvlListData[7] + "']"))
					.isDisplayed();

		} catch (Exception e) {
			return false;
		}

	}

	public void clickApprvlListRecord(String[] servApprvlListData)
			throws Exception {
		waitForElementXpathExpression(".//td[@aria-describedby='APPROVAL_SERVICE_GRID_serviceLevelName' and @title='"
				+ servApprvlListData[7] + "']");
		webDriver
				.findElement(
						By.xpath(".//td[@aria-describedby='APPROVAL_SERVICE_GRID_serviceLevelName' and @title='"
								+ servApprvlListData[7] + "']")).click();
		sleepShort();
	}

	public WebElement getServDefPattern() {
		return servDefPattern;
	}

	public WebElement getIcdDefPattern() {
		return icdDefPattern;
	}

	public WebElement getItemDefPattern() {
		return itemDefPattern;
	}

	public WebElement getServAppGridDiv() {
		return servAppGridDiv;
	}

	public WebElement getIcdAppGridDiv() {
		return icdAppGridDiv;
	}

	public WebElement getItemAppGridDiv() {
		return itemAppGridDiv;
	}

	public WebElement getAddServiceButton() {
		return addServiceButton;
	}

	public WebElement getAddIcdButton() {
		return addIcdButton;
	}

	public WebElement getAddItemButton() {
		return addItemButton;
	}

	public WebElement getServiceLvlList() {
		return serviceLvlList;
	}

	public WebElement getServiceLvlName() {
		return serviceLvlName;
	}

	public WebElement getGridSearchLookup() {
		return gridSearchLookup;
	}

	public WebElement getServiceLvlForm() {
		return serviceLvlForm;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getServiceSpecialty() {
		return serviceSpecialty;
	}

	public WebElement getServiceSubSpecialty() {
		return serviceSubSpecialty;
	}

	public WebElement getServiceType() {
		return serviceType;
	}

	public WebElement getServiceCode() {
		return serviceCode;
	}

	public WebElement getServiceName() {
		return serviceName;
	}

	public WebElement getServiceSearchBtn() {
		return serviceSearchBtn;
	}

	public WebElement getServiceResetBtn() {
		return serviceResetBtn;
	}

	public WebElement getServiceGridDiv() {
		return serviceGridDiv;
	}

	public WebElement getServiceSubmitBtn() {
		return serviceSubmitBtn;
	}

	public WebElement getServiceCancelBtn() {
		return serviceCancelBtn;
	}

	public WebElement getServiceTypeForm() {
		return serviceTypeForm;
	}

	public WebElement getServiceTypeName() {
		return serviceTypeName;
	}

	public WebElement getServiceTypeCode() {
		return serviceTypeCode;
	}

	public WebElement getServiceTypeSearchBtn() {
		return serviceTypeSearchBtn;
	}

	public WebElement getServiceTypeResetBtn() {
		return serviceTypeResetBtn;
	}

	public WebElement getServiceTypeGridDiv() {
		return serviceTypeGridDiv;
	}

	public WebElement getServiceTypeSubmitBtn() {
		return serviceTypeSubmitBtn;
	}

	public WebElement getServiceTypeCancelBtn() {
		return serviceTypeCancelBtn;
	}

	public WebElement getServiceSpltyForm() {
		return serviceSpltyForm;
	}

	public WebElement getServiceSpltyDept() {
		return serviceSpltyDept;
	}

	public WebElement getServiceSpltyName() {
		return serviceSpltyName;
	}

	public WebElement getServiceSpltyCode() {
		return serviceSpltyCode;
	}

	public WebElement getServiceSpltySearchBtn() {
		return serviceSpltySearchBtn;
	}

	public WebElement getServiceSpltyResetBtn() {
		return serviceSpltyResetBtn;
	}

	public WebElement getServiceSpltyGridDiv() {
		return serviceSpltyGridDiv;
	}

	public WebElement getServiceSpltySubmitBtn() {
		return serviceSpltySubmitBtn;
	}

	public WebElement getServiceSpltyCancelBtn() {
		return serviceSpltyCancelBtn;
	}

	public WebElement getServiceSubSpltyForm() {
		return serviceSubSpltyForm;
	}

	public WebElement getServiceSubSpltyDept() {
		return serviceSubSpltyDept;
	}

	public WebElement getServiceSubSplty_ServSplty() {
		return serviceSubSplty_ServSplty;
	}

	public WebElement getServiceSubSpltyName() {
		return serviceSubSpltyName;
	}

	public WebElement getServiceSubSpltyCode() {
		return serviceSubSpltyCode;
	}

	public WebElement getServiceSubSpltySearchBtn() {
		return serviceSubSpltySearchBtn;
	}

	public WebElement getServiceSubSpltyResetBtn() {
		return serviceSubSpltyResetBtn;
	}

	public WebElement getServiceSubSpltyGridDiv() {
		return serviceSubSpltyGridDiv;
	}

	public WebElement getServiceSubSpltySubmitBtn() {
		return serviceSubSpltySubmitBtn;
	}

	public WebElement getServiceSubSpltyCancelBtn() {
		return serviceSubSpltyCancelBtn;
	}

	public WebElement getSerVisitCategory() {
		return serVisitCategory;
	}

	public WebElement getIcdVisitCategory() {
		return icdVisitCategory;
	}

	public WebElement getItmVisitCategory() {
		return itmVisitCategory;
	}

	public WebElement getVisitLimitType() {
		return visitLimitType;
	}

	public WebElement getVisitLimitTypeValue() {
		return visitLimitTypeValue;
	}

	public WebElement getDurLimitPeriod() {
		return durLimitPeriod;
	}

	public WebElement getDurLimitPeriodValue() {
		return durLimitPeriodValue;
	}

	public WebElement getDurLimitType() {
		return durLimitType;
	}

	public WebElement getDurLimitTypeValue() {
		return durLimitTypeValue;
	}

	public WebElement getServApprvlDelLink() {
		return servApprvlDelLink;
	}

	public WebElement getIcdLookup() {
		return icdLookup;
	}

	public WebElement getIcdCode() {
		return icdCode;
	}

	public WebElement getIcdDescription() {
		return icdDescription;
	}

	public WebElement getIcdSearchBtn() {
		return icdSearchBtn;
	}

	public WebElement getIcdResetBtn() {
		return icdResetBtn;
	}

	public WebElement getIcdGridDiv() {
		return icdGridDiv;
	}

	public WebElement getIcdSubmitBtn() {
		return icdSubmitBtn;
	}

	public WebElement getIcdCancelBtn() {
		return icdCancelBtn;
	}

	public WebElement getItemLvlList() {
		return itemLvlList;
	}

	public WebElement getItemLvlLookup() {
		return itemLvlLookup;
	}

	public WebElement getItemType() {
		return itemType;
	}

	public WebElement getItemCategory() {
		return itemCategory;
	}

	public WebElement getItemSubCategory() {
		return itemSubCategory;
	}

	public WebElement getItemCode() {
		return itemCode;
	}

	public WebElement getItemName() {
		return itemName;
	}

	public WebElement getItemSearchBtn() {
		return itemSearchBtn;
	}

	public WebElement getItemResetBtn() {
		return itemResetBtn;
	}

	public WebElement getItemGridDiv() {
		return itemGridDiv;
	}

	public WebElement getItemSubmitBtn() {
		return itemSubmitBtn;
	}

	public WebElement getItemCancelBtn() {
		return itemCancelBtn;
	}

	public WebElement getItemTypeForm() {
		return itemTypeForm;
	}

	public WebElement getItemTypeName() {
		return itemTypeName;
	}

	public WebElement getItemTypeCode() {
		return itemTypeCode;
	}

	public WebElement getItemTypeSearchBtn() {
		return itemTypeSearchBtn;
	}

	public WebElement getItemTypeResetBtn() {
		return itemTypeResetBtn;
	}

	public WebElement getItemTypeGridDiv() {
		return itemTypeGridDiv;
	}

	public WebElement getItemTypeSubmitBtn() {
		return itemTypeSubmitBtn;
	}

	public WebElement getItemTypeCancelBtn() {
		return itemTypeCancelBtn;
	}

	public WebElement getItemCategoryForm() {
		return itemCategoryForm;
	}

	public WebElement getItemCatItemType() {
		return itemCatItemType;
	}

	public WebElement getItemCatName() {
		return itemCatName;
	}

	public WebElement getItemCatCode() {
		return itemCatCode;
	}

	public WebElement getItemCatSearchBtn() {
		return itemCatSearchBtn;
	}

	public WebElement getItemCatResetBtn() {
		return itemCatResetBtn;
	}

	public WebElement getItemCatGridDiv() {
		return itemCatGridDiv;
	}

	public WebElement getItemCatSubmitBtn() {
		return itemCatSubmitBtn;
	}

	public WebElement getItemCatCancelBtn() {
		return itemCatCancelBtn;
	}

	public WebElement getItemSubCatForm() {
		return itemSubCatForm;
	}

	public WebElement getItemSubCatItemType() {
		return itemSubCatItemType;
	}

	public WebElement getItemSubCatItemCategory() {
		return itemSubCatItemCategory;
	}

	public WebElement getItemSubCatName() {
		return itemSubCatName;
	}

	public WebElement getItemSubCatCode() {
		return itemSubCatCode;
	}

	public WebElement getItemSubCatSearchBtn() {
		return itemSubCatSearchBtn;
	}

	public WebElement getItemSubCatResetBtn() {
		return itemSubCatResetBtn;
	}

	public WebElement getItemSubCatGridDiv() {
		return itemSubCatGridDiv;
	}

	public WebElement getItemSubCatSubmitBtn() {
		return itemSubCatSubmitBtn;
	}

	public WebElement getItemSubCatCancelBtn() {
		return itemSubCatCancelBtn;
	}

	public String checkItemLevelData(String[] itemApprvlListData) {
		return new Select(itemLvlList).getFirstSelectedOption().getText();

	}

	public WebElement getApplyApprvlListToChkBox() {
		return applyApprvlListToChkBox;
	}

	public WebElement getApplyApprvlListToPolicyChkBox() {
		return applyApprvlListToPolicyChkBox;
	}

	public WebElement getApplyApprvlListToClassChkBox() {
		return applyApprvlListToClassChkBox;
	}

	public WebElement getPolicyMultiselectChkBox() {
		return policyMultiselectChkBox;
	}

	public WebElement getClassMultiselectChkBox() {
		return classMultiselectChkBox;
	}

	public WebElement getAgrmntsMultiselectChkBox() {
		return agrmntsMultiselectChkBox;
	}

}
