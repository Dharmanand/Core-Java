package com.atk.himma.pageobjects.baselov;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.baselov.tabs.BaseLoVDetailsTab;
import com.atk.himma.pageobjects.baselov.tabs.BaseLoVListTab;
import com.atk.himma.pageobjects.mbuadmin.tabs.OtherLocListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class BaseLovPage extends DriverWaitClass implements StatusMessages {

	private BaseLoVListTab baseLoVListTab;

	private BaseLoVDetailsTab baseLoVDetailsTab;

	private final static String PAGETITLE_ID = "PAGE_TITLE";

	private Map<String, List<String>> pregMasterDatas;

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'updated successfully')]";
	public final static String DELETECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'deleted successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Record activated successfully')]";

	public final static String PREGBASELOVMENULINK_XPATH = "//a[contains(text(),'Patient Registration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Base LV')]";
	public final static String MBUBASELOVMENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Base LV')]";
	public final static String APPOINTBASELOVMENULINK_XPATH = "//a[contains(text(),'Appointment Scheduling')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Base LV')]";

	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;

	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;

	@FindBy(xpath = DELETECONFMSG_XPATH)
	private WebElement deleteConfMsg;

	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		this.baseLoVListTab = PageFactory.initElements(webDriver,
				BaseLoVListTab.class);
		this.baseLoVListTab.setWebDriver(webDriver);
		this.baseLoVListTab.setWebDriverWait(webDriverWait);

		this.baseLoVDetailsTab = PageFactory.initElements(webDriver,
				BaseLoVDetailsTab.class);
		this.baseLoVDetailsTab.setWebDriver(webDriver);
		this.baseLoVDetailsTab.setWebDriverWait(webDriverWait);

	}

	public BaseLovPage clickOnBaseLovMenu(WebDriver webDriver,
			WebDriverWait webDriverWait, String moduleName) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add(moduleName);
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Base LV");
		BaseLovPage baseLov = PageFactory.initElements(webDriver,
				BaseLovPage.class);
		baseLov.setWebDriver(webDriver);
		baseLov.setWebDriverWait(webDriverWait);
		return baseLov;
	}

	public void saveBaseLovPage(String[] baseLovDatas, WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		fillBaseLovData(baseLovDatas, webDriver, webDriverWait);
		baseLoVDetailsTab.getSaveButton().click();
		waitForElementId(BaseLoVDetailsTab.getUpdatebuttonId());
	}

	public void fillBaseLovData(String[] baseLovDatas, WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		waitForElementId(BaseLoVListTab.ADDNEWBASELOVBUTTON_ID);
		sleepVeryShort();
		getBaseLoVListTab().getAddNewBaseLoVButton().click();
		waitForElementId(BaseLoVDetailsTab.getSavebuttonId());
		new Select(baseLoVDetailsTab.getEntity())
				.selectByVisibleText(baseLovDatas[0].trim());
		new Select(baseLoVDetailsTab.getLanguage())
				.selectByVisibleText(baseLovDatas[1].trim());
		new Select(baseLoVDetailsTab.getStatus())
				.selectByVisibleText(baseLovDatas[2].trim());
		baseLoVDetailsTab.getShortName().sendKeys(baseLovDatas[3].trim());
		baseLoVDetailsTab.getLongName().sendKeys(baseLovDatas[4].trim());
	}

	public String updateBaseLovPage(String[] baseLovDatas)
			throws InterruptedException {
		waitForElementId(BaseLoVDetailsTab.UPDATEBUTTON_ID);
		sleepVeryShort();
		new Select(baseLoVDetailsTab.getStatus())
				.selectByVisibleText(baseLovDatas[2].trim());
		baseLoVDetailsTab.getShortName().clear();
		baseLoVDetailsTab.getShortName().sendKeys(baseLovDatas[3].trim());
		baseLoVDetailsTab.getLongName().clear();
		baseLoVDetailsTab.getLongName().sendKeys(baseLovDatas[4].trim());
		baseLoVDetailsTab.getUpdateButton().click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		sleepVeryShort();
		return updateConfMsg.getText().trim();
	}

	public boolean saveDuplicateData(String[] baseLovDatas)
			throws InterruptedException, IOException {
		try {
			fillBaseLovData(baseLovDatas, webDriver, webDriverWait);
			baseLoVDetailsTab.getSaveButton().click();
			new WebDriverWait(webDriver, shortTimeInterval)
					.until(ExpectedConditions.presenceOfElementLocated(By
							.xpath(BaseLoVDetailsTab.getUpdatebuttonId())));
			sleepVeryShort();
			return false;
		} catch (Exception e) {
			return searchBaseLovRecord(baseLovDatas);
		}
	}

	

	public boolean resetEntry(String[] baseLovDatas) {
		baseLoVListTab.getBaseLoVListTab().click();
		waitForElementId(BaseLoVListTab.getAddnewbaselovbuttonId());
		new Select(baseLoVListTab.getEntity())
				.selectByVisibleText(baseLovDatas[0].trim());
		// new Select(baseLoVListTab.getLanguage())
		// .selectByVisibleText(baseLovDatas[1].trim());
		// new Select(baseLoVListTab.getStatus())
		// .selectByVisibleText(baseLovDatas[2].trim());
		// baseLoVListTab.getShortName().sendKeys(baseLovDatas[3].trim());
		// baseLoVListTab.getLongName().sendKeys(baseLovDatas[4].trim());
		baseLoVListTab.getSearchButton().click();
		checkGridEmpty(BaseLoVListTab.getGridId(),
				BaseLoVListTab.getGridPagerid());
		baseLoVListTab.getResetButton().click();
		return checkGridEmpty(BaseLoVListTab.getGridId(),
				BaseLoVListTab.getGridPagerid());
	}

	public boolean searchBaseLovRecord(String[] baseLovDatas) {
		baseLoVListTab.getBaseLoVListTab().click();
		waitForElementId(BaseLoVListTab.getSearchbuttonId());

		new Select(baseLoVListTab.getEntity())
				.selectByVisibleText(baseLovDatas[0].trim());
		new Select(baseLoVListTab.getLanguage())
				.selectByVisibleText(baseLovDatas[1].trim());
		new Select(baseLoVListTab.getStatus())
				.selectByVisibleText(baseLovDatas[2].trim());
		baseLoVListTab.getShortName().sendKeys(baseLovDatas[3].trim());
		baseLoVListTab.getLongName().sendKeys(baseLovDatas[4].trim());
		baseLoVListTab.getSearchButton().click();
		return waitAndGetGridFirstCellText(BaseLoVListTab.getGridId(),
				BaseLoVListTab.getGridDispshortdescAriaDescribedby(),
				baseLovDatas[3].trim()).equals(baseLovDatas[3].trim());
	}

	public String editSelectedRow(String[] baseLovDatas)
			throws InterruptedException {
		searchBaseLovRecord(baseLovDatas);
		clickOnGridAction(BaseLoVListTab.getGridDispshortdescAriaDescribedby(),
				baseLovDatas[3].trim(), "Edit");
		waitForElementId(BaseLoVDetailsTab.getUpdatebuttonId());
		return updateBaseLovPage(baseLovDatas);
	}

	public String deleteSelectedRow(String[] baseLovDatas) {
		searchBaseLovRecord(baseLovDatas);
		waitAndGetGridFirstCellText(BaseLoVListTab.getGridId(),
				BaseLoVListTab.getGridDispshortdescAriaDescribedby(),
				baseLovDatas[3].trim());
		clickOnGridAction(BaseLoVListTab.getGridDispshortdescAriaDescribedby(),
				baseLovDatas[3].trim(), "Delete");
		waitForElementXpathExpression(DELETECONFMSG_XPATH);
		return deleteConfMsg.getText().trim();
	}

	public String addLanguageEntry(String[] baseLovDatas)
			throws InterruptedException {
		searchBaseLovRecord(baseLovDatas);
		new Select(baseLoVDetailsTab.getLanguage())
				.selectByVisibleText(baseLovDatas[1].trim());
		new Select(baseLoVDetailsTab.getStatus())
				.selectByVisibleText(baseLovDatas[2].trim());
		baseLoVDetailsTab.getShortName().sendKeys(baseLovDatas[3].trim());
		baseLoVDetailsTab.getLongName().sendKeys(baseLovDatas[4].trim());
		baseLoVDetailsTab.getSaveButton().click();
		waitForElementId(BaseLoVDetailsTab.UPDATEBUTTON_ID);
		sleepVeryShort();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		return getStatusMessage().getText().trim();
	}

	// For Preg Start -----

	public Map<String, List<String>> getDataFromMasters(String entiryTypeNames,
			String language) throws InterruptedException {
		// setInstanceOfAllSection(webDriver, webDriverWait);
		pregMasterDatas = new HashMap<String, List<String>>();
		String[] etNames = entiryTypeNames.split("\\,");
		for (int i = 0; i < etNames.length; i++) {
			new Select(baseLoVListTab.getEntity())
					.selectByVisibleText(etNames[i].trim());
			new Select(baseLoVListTab.getLanguage())
					.selectByVisibleText(language.trim());
			new Select(baseLoVListTab.getStatus())
					.selectByVisibleText("Active");
			baseLoVListTab.getSearchButton().click();
			pregMasterDatas.put(etNames[i].trim(), getAllLongName(language));
		}
		return pregMasterDatas;
	}

	public List<String> getAllLongName(String language)
			throws InterruptedException {
		waitForElementId(BaseLoVListTab.GRID_ID);
		sleepShort();
		List<String> longNames = new ArrayList<String>();
		int pageCount = Integer.parseInt(baseLoVListTab.getSearchPager()
				.getText().trim());
		List<WebElement> lnElements = webDriver
				.findElements(By.xpath("//td[@aria-describedby='"
						+ BaseLoVListTab.GRID_LANGCODE_ARIA_DESCRIBEDBY
						+ "' and @title='" + language.trim()
						+ "']/..//td[@aria-describedby='"
						+ BaseLoVListTab.GRID_LONGDESC_ARIA_DESCRIBEDBY + "']"));
		for (int i = 0; i < pageCount; i++) {
			lnElements = webDriver.findElements(By
					.xpath("//td[@aria-describedby='"
							+ BaseLoVListTab.GRID_LANGCODE_ARIA_DESCRIBEDBY
							+ "' and @title='" + language.trim()
							+ "']/..//td[@aria-describedby='"
							+ BaseLoVListTab.GRID_LONGDESC_ARIA_DESCRIBEDBY
							+ "']"));
			for (WebElement we : lnElements) {
				longNames.add(we.getAttribute("title").trim());
			}

			if (pageCount - 1 > i) {
				baseLoVListTab.getNextPage().click();
			}
		}
		return longNames;
	}

	// Preg End -----

	/**
	 * @return the baseLoVListTab
	 */
	public BaseLoVListTab getBaseLoVListTab() {
		return baseLoVListTab;
	}

	/**
	 * @return the baseLoVDetailsTab
	 */
	public BaseLoVDetailsTab getBaseLoVDetailsTab() {
		return baseLoVDetailsTab;
	}

	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @param baseLoVListTab
	 *            the baseLoVListTab to set
	 */
	public void setBaseLoVListTab(BaseLoVListTab baseLoVListTab) {
		this.baseLoVListTab = baseLoVListTab;
	}

	/**
	 * @param baseLoVDetailsTab
	 *            the baseLoVDetailsTab to set
	 */
	public void setBaseLoVDetailsTab(BaseLoVDetailsTab baseLoVDetailsTab) {
		this.baseLoVDetailsTab = baseLoVDetailsTab;
	}

	/**
	 * @return the msgenableXpath
	 */
	public static String getMsgenableXpath() {
		return MSGENABLE_XPATH;
	}

	/**
	 * @return the statusMessageSave
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	/**
	 * @return the deleteConfMsg
	 */
	public WebElement getDeleteConfMsg() {
		return deleteConfMsg;
	}
}
