package com.atk.himma.pageobjects.mbuadmin.master.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class UOMListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "UOM_LIST_PAGE";
	public final static String UOMLISTTAB_XPATH = "//a[@title='Unit Of measurement List']";
	public final static String ADDNEWUOMBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Add New Unit of Measurement']";
	public final static String UOMCODE_ID = "UOM_CODE_SEARCH";
	public final static String UOMNAME_ID = "UOM_NAME";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "SEARCH_UOM_LIST";
	public final static String GRID_UOMCODE_ARIA_DESCRIBEDBY = "SEARCH_UOM_LIST_uomCode";
	public final static String GRID_UOMNAME_ARIA_DESCRIBEDBY = "SEARCH_UOM_LIST_uomName";
	public final static String GRID_MAINSTATUSTEXT_ARIA_DESCRIBEDBY = "SEARCH_UOM_LIST_recordStatus.mainStatusText";
	public final static String GRID_PAGER_ID = "sp_1_SEARCH_UOM_LIST_pager";
	public final static String CONFMESSAGE_ID = "ui-dialog-title-dialog";
	public final static String CONFMESSYESBUTTON_ID = "MSG_DIALOG_YES";

	
	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = CONFMESSAGE_ID)
	private WebElement confMessageTitle;
	
	@FindBy(id = CONFMESSYESBUTTON_ID)
	private WebElement confMessYesButton;

	@FindBy(xpath = UOMLISTTAB_XPATH)
	private WebElement uomListTab;

	@FindBy(xpath = ADDNEWUOMBUTTON_XPATH)
	private WebElement addNewUOMButton;
	
	@FindBy(id = UOMCODE_ID)
	private WebElement uomCode;
	
	@FindBy(id = UOMNAME_ID)
	private WebElement uomName;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement grid;

	@FindBy(name = GRID_PAGER_ID)
	private WebElement gridPager;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the uomListTab
	 */
	public WebElement getUomListTab() {
		return uomListTab;
	}

	/**
	 * @return the addNewUOMButton
	 */
	public WebElement getAddNewUOMButton() {
		return addNewUOMButton;
	}

	/**
	 * @return the uomCode
	 */
	public WebElement getUomCode() {
		return uomCode;
	}

	/**
	 * @return the uomName
	 */
	public WebElement getUomName() {
		return uomName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the confMessageTitle
	 */
	public WebElement getConfMessageTitle() {
		return confMessageTitle;
	}

	/**
	 * @return the confMessYesButton
	 */
	public WebElement getConfMessYesButton() {
		return confMessYesButton;
	}
	
}
