package com.atk.himma.pageobjects.mbuadmin.sections.itemdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.RegConfiguration;
import com.atk.himma.util.DriverWaitClass;

public class ItemGeneralDetails extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Item General Details";

	public final static String COSTPRICE_ID = "COST_PRICE";
	public final static String SALEPRICE_ID = "SALE_PRICE";
	public final static String STOCKINGUOM_NAME = "itemInfo.itemGeneralDetail.stockingUOMId";
	public final static String PURCHASEUOM_NAME = "itemInfo.itemGeneralDetail.purchageUOMId";
	public final static String SELLINGUOM_NAME = "itemInfo.itemGeneralDetail.sellingUOMId";
	public final static String SELLINGPRICE_NAME = "itemInfo.itemGeneralDetail.salesPrice";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Item General Details')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = COSTPRICE_ID)
	private WebElement costPrice;

	@FindBy(id = SALEPRICE_ID)
	private WebElement salePrice;

	@FindBy(name = STOCKINGUOM_NAME)
	private WebElement stockingUOM;

	@FindBy(name = PURCHASEUOM_NAME)
	private WebElement purchaseUOM;

	@FindBy(name = SELLINGUOM_NAME)
	private WebElement sellingUOM;

	@FindBy(name = SELLINGPRICE_NAME)
	private WebElement sellingPrice;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkGenDetailsSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean isMandatoryStockUOM() {
		waitForElementLinkText(RegConfiguration.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementName(STOCKINGUOM_NAME);
		return isMandatoryField(stockingUOM);
	}

	public boolean fillDatas(String[] itemDatas) throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		sleepVeryShort();
		costPrice.clear();
		costPrice.sendKeys(itemDatas[17].trim());
		sellingPrice.clear();
		sellingPrice.sendKeys(itemDatas[18].trim());
		if (!itemDatas[19].trim().isEmpty())
			new Select(stockingUOM).selectByVisibleText(itemDatas[19].trim());
		if (!itemDatas[20].trim().isEmpty())
			new Select(purchaseUOM).selectByVisibleText(itemDatas[20].trim());
		if (!itemDatas[21].trim().isEmpty())
			new Select(sellingUOM).selectByVisibleText(itemDatas[21].trim());
		return sellingPrice.getAttribute("value").trim()
				.equals(itemDatas[18].trim());
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the costPrice
	 */
	public WebElement getCostPrice() {
		return costPrice;
	}

	/**
	 * @return the salePrice
	 */
	public WebElement getSalePrice() {
		return salePrice;
	}

	/**
	 * @return the stockingUOM
	 */
	public WebElement getStockingUOM() {
		return stockingUOM;
	}

	/**
	 * @return the purchaseUOM
	 */
	public WebElement getPurchaseUOM() {
		return purchaseUOM;
	}

	/**
	 * @return the sellingUOM
	 */
	public WebElement getSellingUOM() {
		return sellingUOM;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the sellingPrice
	 */
	public WebElement getSellingPrice() {
		return sellingPrice;
	}

}
