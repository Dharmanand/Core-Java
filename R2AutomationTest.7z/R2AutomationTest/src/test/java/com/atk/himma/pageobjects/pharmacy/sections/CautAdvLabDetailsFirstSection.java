package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class CautAdvLabDetailsFirstSection extends DriverWaitClass{
	
	public final static String FORM_ID = "PCY_INST_DETAILS";
	public final static String SAVEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Save']";
	public final static String CANCELBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Cancel']";
	public final static String UPDATEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Update']";
	public final static String COPYBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Copy']";
	public final static String ADDNEWBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Add New']";
	public final static String LABELCODE_NAME = "pcyInstructions.instructionCode";
	public final static String LABELTYPE_NAME = "pcyInstructions.instructionType";
	public final static String LABELDESCRIPTION_NAME = "pcyInstructions.instructionDesc";
	public final static String LABELDESCRIPTIONAR_NAME = "pcyInstructions.instructionDescAr";

	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(css = SAVEBUTTON_CSS)
	private WebElement saveButton;
	
	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButton;
	
	@FindBy(css = UPDATEBUTTON_CSS)
	private WebElement updateButton;
	
	@FindBy(css = COPYBUTTON_CSS)
	private WebElement copyButton;
	
	@FindBy(css = ADDNEWBUTTON_CSS)
	private WebElement addNewButton;
	
	@FindBy(name = LABELCODE_NAME)
	private WebElement labelCode;
	
	@FindBy(name = LABELTYPE_NAME)
	private WebElement labelType;
	
	@FindBy(name = LABELDESCRIPTION_NAME)
	private WebElement labelDescription;
	
	@FindBy(name = LABELDESCRIPTIONAR_NAME)
	private WebElement labelDescriptionAr;

	public WebElement getForm() {
		return form;
	}

	public WebElement getSaveButton() {
		return saveButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getLabelCode() {
		return labelCode;
	}

	public WebElement getLabelType() {
		return labelType;
	}

	public WebElement getLabelDescription() {
		return labelDescription;
	}

	public WebElement getLabelDescriptionAr() {
		return labelDescriptionAr;
	}
	
	public WebElement getUpdateButton() {
		return updateButton;
	}

	public WebElement getCopyButton() {
		return copyButton;
	}

	public WebElement getAddNewButton() {
		return addNewButton;
	}
}
