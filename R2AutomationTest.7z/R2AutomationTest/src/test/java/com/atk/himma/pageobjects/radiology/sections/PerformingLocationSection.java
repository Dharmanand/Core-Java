package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PerformingLocationSection extends DriverWaitClass{
	
	public final static String ADDROWBUTTON_ID = "addNewPerformingLocationInfo";
	
//	-----------GRID--------------
	public final static String GRID_ID = "rspl_GRID";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "rspl_GRID_mainBusinessUnit";
	public final static String GRID_LOCCATEGORY_ARIA_DESCRIBEDBY = "rspl_GRID_locationCategory";
	public final static String GRID_LOCATION_ARIA_DESCRIBEDBY = "rspl_GRID_location";
	public final static String GRID_VISITCATIDS_ARIA_DESCRIBEDBY = "rspl_GRID_visitCatIds.value";
	public final static String GRID_DAY_ARIA_DESCRIBEDBY = "rspl_GRID_dayIds.value";
	public final static String GRID_FROMDATE_ARIA_DESCRIBEDBY = "rspl_GRID_fromTime";
	public final static String GRID_TODATE_ARIA_DESCRIBEDBY = "rspl_GRID_toTime";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "rspl_GRID_action";
	public final static String GRID_PAGERID = "sp_1_rspl_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rspl_GRID_pager']";

//	-----------GRID's Fields--------------
	public final static String MBUTXT_CSS = "td[aria-describedby='"+GRID_MBU_ARIA_DESCRIBEDBY+"'] input[name='mainBusinessUnit']";
	public final static String LOCCATEGORYTXT_CSS = "td[aria-describedby='"+GRID_LOCCATEGORY_ARIA_DESCRIBEDBY+"'] span input[name='locationCategory']";
	public final static String LOCATIONTXT_CSS = "td[aria-describedby='"+GRID_LOCATION_ARIA_DESCRIBEDBY+"'] span input[name='location']";
	public final static String SERVICELOOKUP_CSS = "td[aria-describedby='"+GRID_LOCATION_ARIA_DESCRIBEDBY+"'] span a[name='location']";
	public final static String VISITCATIDSBTN_CSS = "td[aria-describedby='"+GRID_VISITCATIDS_ARIA_DESCRIBEDBY+"'] button";
	public final static String VISITCATDD_CSS = "td[aria-describedby='"+GRID_VISITCATIDS_ARIA_DESCRIBEDBY+"'] select[name='visitCatIds.value']";
	public final static String DAYBTN_CSS = "td[aria-describedby='"+GRID_DAY_ARIA_DESCRIBEDBY+"'] button";
	public final static String DAYDD_CSS = "td[aria-describedby='"+GRID_DAY_ARIA_DESCRIBEDBY+"'] select[name='dayIds.value']";
	public final static String FROMTIMETXT_CSS = "td[aria-describedby='"+GRID_FROMDATE_ARIA_DESCRIBEDBY+"'] input[name='fromTime']";
	public final static String TOTIMETXT_CSS = "td[aria-describedby='"+GRID_TODATE_ARIA_DESCRIBEDBY+"'] input[name='toTime']";
	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_LOCCATEGORY_ARIA_DESCRIBEDBY+"']/span/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";
	public final static String DELETEACTION_XPATH = "//td[@aria-describedby='"+GRID_LOCCATEGORY_ARIA_DESCRIBEDBY+"']/..//a[text()='Delete']";

	@FindBy(id = ADDROWBUTTON_ID)
	private WebElement addRowButton;
	
	@FindBy(css = MBUTXT_CSS)
	private WebElement mbuTxt;
	
	@FindBy(css = LOCCATEGORYTXT_CSS)
	private WebElement locCategoryTxt;
	
	@FindBy(css = LOCATIONTXT_CSS)
	private WebElement locationTxt;
	
	@FindBy(css = SERVICELOOKUP_CSS)
	private WebElement serviceLookup;
	
	@FindBy(css = VISITCATDD_CSS)
	private WebElement visitCatDD;
	
	@FindBy(css = DAYBTN_CSS)
	private WebElement dayBtn;
	
	@FindBy(css = DAYDD_CSS)
	private WebElement dayDD;
	
	@FindBy(css = FROMTIMETXT_CSS)
	private WebElement fromTimeTxt;
	
	@FindBy(css = TOTIMETXT_CSS)
	private WebElement toTimeTxt;
	
	@FindBy(xpath = DELETEACTION_GE_XPATH)
	private WebElement deleteActionGE;
	
	@FindBy(xpath = DELETEACTION_XPATH)
	private WebElement deleteAction;

	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the mbuTxt
	 */
	public WebElement getMbuTxt() {
		return mbuTxt;
	}

	/**
	 * @return the locCategoryTxt
	 */
	public WebElement getLocCategoryTxt() {
		return locCategoryTxt;
	}

	/**
	 * @return the locationTxt
	 */
	public WebElement getLocationTxt() {
		return locationTxt;
	}

	/**
	 * @return the serviceLookup
	 */
	public WebElement getServiceLookup() {
		return serviceLookup;
	}

	/**
	 * @return the visitCatDD
	 */
	public WebElement getVisitCatDD() {
		return visitCatDD;
	}

	/**
	 * @return the dayBtn
	 */
	public WebElement getDayBtn() {
		return dayBtn;
	}

	/**
	 * @return the dayDD
	 */
	public WebElement getDayDD() {
		return dayDD;
	}

	/**
	 * @return the fromTimeTxt
	 */
	public WebElement getFromTimeTxt() {
		return fromTimeTxt;
	}

	/**
	 * @return the toTimeTxt
	 */
	public WebElement getToTimeTxt() {
		return toTimeTxt;
	}

	/**
	 * @return the deleteActionGE
	 */
	public WebElement getDeleteActionGE() {
		return deleteActionGE;
	}

	/**
	 * @return the deleteAction
	 */
	public WebElement getDeleteAction() {
		return deleteAction;
	}
	
}
