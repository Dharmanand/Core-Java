package com.atk.himma.test.appointschedu;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.appointsched.ResourceCalendarPage;
import com.atk.himma.pageobjects.appointsched.tabs.ResourceCalendarListTab;
import com.atk.himma.setup.SeleniumDriverSetup;

@Test(groups={"functionalTestGrp"})
public class ResourceCalenderTest extends SeleniumDriverSetup {

	List<String[]> resCalDatas;
	ResourceCalendarPage resourceCalendarPage;
	LoginPage loginPage;

	@Test(description = "Open Resource Calendar Page")
	public void test00ClickOnResCalMenu() throws InterruptedException {
		resourceCalendarPage = PageFactory.initElements(webDriver,
				ResourceCalendarPage.class);
		resourceCalendarPage = resourceCalendarPage.clickOnResCalenMenu(
				webDriver, webDriverWait);
		resourceCalendarPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		resourceCalendarPage
				.waitForElementId(ResourceCalendarListTab.SEARCHBUTTON_ID);
		Assert.assertEquals(resourceCalendarPage.getResourceCalendarListTab()
				.getResCalListTab().getAttribute("title").trim(),
				"Resource Calendar List",
				"Fail to open Resource Calendar page.");
	}

	@Test(description = "Search Resource", dependsOnMethods = "test00ClickOnResCalMenu")
	public void test001SearchResourceName() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("AppSchedExcel"));
		resCalDatas = excelReader.read(properties.getProperty("resourceCalendar"));
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.searchResource(st),
					st[7].trim(), "Fail to Search Resource.");
	}

	@Test(description = "click On Configure Link", dependsOnMethods = "test001SearchResourceName")
	public void test002ClickOnConfigureLink() throws InterruptedException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.clickOnConfigureLink(st),
					true, "click On Configure Link");
	}

	@Test(description = "Check Resource Calender First Section", dependsOnMethods = "test002ClickOnConfigureLink")
	public void test003CheckResCalFirstSection() throws InterruptedException {
		Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
				.checkResCalFirstSection(), true,
				"Fail to Check Resource Calender First Section.");
	}

	// Calendar Parameters
	@Test(description = "check to open Calender Parameter Section", dependsOnMethods = {
			"test002ClickOnConfigureLink" }, alwaysRun = true)
	public void test004CheckCalParamOpen() throws InterruptedException {
		Assert.assertEquals(resourceCalendarPage.getCalendarParameters()
				.checkCalParamOpen(), true,
				"Fail to open Calender Parameter Section");
	}

	// Appointment Parameters
	@Test(description = "check Administration Parameter Section", dependsOnMethods = {
			"test002ClickOnConfigureLink" }, alwaysRun = true)
	public void test005CheckAppointParamSection() throws InterruptedException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.checkAppointParamSection(), false,
				"check Administration Parameter Section");
	}

	// Availability Configuration
	@Test(description = "Check Avilability Configuration Section", dependsOnMethods = {
			"test002ClickOnConfigureLink" }, alwaysRun = true)
	public void test006CheckAvilConfiSection() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.checkAvilConfiSection(), false,
				"fail to Check Avilability Configuration Section");
	}

	// Non Availability Configuration
	@Test(description = "Check Avilability Configuration Section", dependsOnMethods = {
			"test002ClickOnConfigureLink"}, alwaysRun = true)
	public void test007CheckNonAvailRegSection() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage
				.getNonAvailabilityConfiguration().checkNonAvailRegSection(),
				false, "fail to Check Avilability Configuration Section");
	}

	@Test(description = "click From Date Validation", dependsOnMethods = "test003CheckResCalFirstSection")
	public void test008FromDateValidation() throws Exception {

		Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
				.calFromDateValid(), VALMSG_ISTDATEFORMAT,
				"Fail to click From Date Validation.");
	}

	@Test(description = "click To Date Validation", dependsOnMethods = "test003CheckResCalFirstSection")
	public void test009ToDateValidation() throws Exception {
		Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
				.calToDateValid(), VALMSG_ISTDATEFORMAT,
				"Fail to click To Date Validation.");
	}

	@Test(description = "Fill datas of Resource Calendar's First Section", dependsOnMethods = "test003CheckResCalFirstSection")
	public void test010FillDatasOfFirstSection() throws InterruptedException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
					.fillDatasOfFirstSection(st), true,
					"Fail to Fill datas of Resource Calendar's First Section");
	}

	// Calendar Parameters
	
	@Test(description = "fill Datas Of Calender Parameter Section", dependsOnMethods = {"test004CheckCalParamOpen","test010FillDatasOfFirstSection"}, alwaysRun=true)
	public void test011FillDatasOfCalParamSec() throws InterruptedException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.getCalendarParameters()
					.fillDatasOfCalParamSec(st), true,
					"Fail to fill Datas Of Calender Parameter Section");
	}
	
	// Appointment Parameters
	
	@Test(description = "click On Add Button", dependsOnMethods = {"test005CheckAppointParamSection","test011FillDatasOfCalParamSec"}, alwaysRun=true)
	public void test012ClickOnAddButton() throws InterruptedException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
					.clickOnAddButton(st), "Add Record",
					"fail to click On Add Button");
	}

	@Test(description = "chech Mandatory Visit Category", dependsOnMethods = "test012ClickOnAddButton")
	public void test013IsMandVisitCategory() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandVisitCategory(), true,
				"fail to chech Mandatory Visit Category");
	}

	@Test(description = "chech Mandatory Visit Type", dependsOnMethods = "test012ClickOnAddButton")
	public void test014IsMandVisitType() throws InterruptedException, IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandVisitType(), true, "fail to chech Mandatory Visit type");
	}

	@Test(description = "chech Mandatory Number Allowed Per Visit", dependsOnMethods = "test012ClickOnAddButton")
	public void test015IsMandNumAllPerVisit() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandNumAllPerVisit(), true,
				"fail to chech Mandatory Number Allowed Per Visit");
	}

	@Test(description = "chech Mandatory Follow-up Duration", dependsOnMethods = "test012ClickOnAddButton")
	public void test016IsMandFollowUpsDuration() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandFollowUpsDuration(), true,
				"fail to chech Mandatory Follow-up Duration");
	}

	@Test(description = "fill Datas of Appoint Parameter PopUp", dependsOnMethods = "test012ClickOnAddButton")
	public void test017FillDatasToPopUp() throws InterruptedException, IOException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
					.fillDatasToPopUp(st), true,
					"fail to fill Datas of Appoint Parameter PopUp");
	}

	@Test(description = "submit Follow Up Datas", dependsOnMethods = "test017FillDatasToPopUp")
	public void test018SubmitFollowUpDatas() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.submitFollowUpDatas(), true, "fail to submit Follow Up Datas");
	}

	@Test(description = "Cancel Follow Up Datas", dependsOnMethods = "test018SubmitFollowUpDatas")
	public void test019CancelFollowUpDatas() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.cancelFollowUpDatas(), true, "fail to Cancel Follow Up Datas");
	}
	
	// Availability Configuration
	
	@Test(description = "click On Add Availability Button", dependsOnMethods = {"test006CheckAvilConfiSection","test019CancelFollowUpDatas"}, alwaysRun=true)
	public void test020ClickOnAddAvailButton() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.clickOnAddAvailButton(), true,
				"fail to click On Add Availability Button");
	}

	@Test(description = "check Mandatory Availability From Date", dependsOnMethods = "test020ClickOnAddAvailButton")
	public void test021IsMandAvailFromDate() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandFromDate(), true, "fail to check Mandatory From Date");
	}

	@Test(description = "check Mandatory Availability To Date", dependsOnMethods = "test020ClickOnAddAvailButton")
	public void test022IsMandAvaiToDate() throws InterruptedException, IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandToDate(), true, "fail to check Mandatory To Date");
	}

	// Non Availability Configuration
	
	@Test(description = "click On Add Availability Button", dependsOnMethods = {"test007CheckNonAvailRegSection", "test022IsMandAvaiToDate"}, alwaysRun=true)
	public void test023ClickOnAddNonAvailButton() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage
				.getNonAvailabilityConfiguration().clickOnAddNonAvailButton(),
				true, "fail to click On Add Availability Button");
	}

	@Test(description = "check Mandatory From Date", dependsOnMethods = "test023ClickOnAddNonAvailButton")
	public void test024IsMandNonAvailFromDate() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandFromDate(), true, "fail to check Mandatory From Date");
	}

	@Test(description = "check Mandatory To Date", dependsOnMethods = "test023ClickOnAddNonAvailButton")
	public void test025IsMandNonAvailToDate() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandToDate(), true, "fail to check Mandatory To Date");
	}

	@Test(description = "Save Resource Calender Datas", dependsOnMethods = {
			"test023ClickOnAddNonAvailButton", "test025IsMandNonAvailToDate" })
	public void test026SaveDatas() throws InterruptedException, IOException {
		Assert.assertEquals(
				resourceCalendarPage.saveDetailsPage().contains(
						"saved successfully"), true,
				"Failed to Save Resource Calender Datas");
	}

	@Test(description = "Activate Resource Calender", dependsOnMethods = "test026SaveDatas")
	public void test027ActivateCalender() throws InterruptedException, IOException {
		Assert.assertEquals(
				resourceCalendarPage.activateRecord().contains("Active"), true,
				"Fail to Activate Resource Calender");
	}

	@Test(description = "click on Resource Calender List Tab", dependsOnMethods = { "test027ActivateCalender" }, alwaysRun = true)
	public void test028ClickOnRCListTab() throws InterruptedException, IOException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.clickOnRCListTab(st),
					true, "Failed to click on Resource Calender List Tab");
	}

	@Test(description = "click on Edit Link of Resource Calender List", dependsOnMethods = { "test028ClickOnRCListTab" })
	public void test029ClickOnEditLink() throws InterruptedException, IOException {
		for (String st[] : resCalDatas.subList(0, 1))
			Assert.assertEquals(resourceCalendarPage.clickOnEditLink(st), true,
					"Failed to Click on Edit Link of Resource Calender List");
	}
//
	
	
	// Calender By Location
	@Test(description = "Open Resource Calendar Page", dependsOnMethods="test029ClickOnEditLink", alwaysRun=true)
	public void test030ClickOnLocResCalMenu() throws InterruptedException {
		resourceCalendarPage = PageFactory.initElements(webDriver,
				ResourceCalendarPage.class);
		resourceCalendarPage = resourceCalendarPage.clickOnResCalenMenu(
				webDriver, webDriverWait);
		resourceCalendarPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		resourceCalendarPage
				.waitForElementId(ResourceCalendarListTab.SEARCHBUTTON_ID);
		Assert.assertEquals(resourceCalendarPage.getResourceCalendarListTab()
				.getResCalListTab().getAttribute("title").trim(),
				"Resource Calendar List",
				"Fail to open Resource Calendar page.");
	}

	@Test(description = "Search Resource", dependsOnMethods = "test030ClickOnLocResCalMenu")
	public void test031SearchLocName() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("AppSchedExcel"));
		resCalDatas = excelReader.read(properties.getProperty("resourceCalendar"));
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.searchLocation(st),
					st[7].trim(), "Fail to Search Resource.");
	}

	@Test(description = "click On Configure Link", dependsOnMethods = "test031SearchLocName")
	public void test032ClickOnLocConfLink() throws InterruptedException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.clickOnConfigureLink(st),
					true, "click On Configure Link");
	}
	@Test(description = "Check Resource Calender First Section", dependsOnMethods = "test032ClickOnLocConfLink")
	public void test033CheckLocResCalFirstSec() throws InterruptedException {
		Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
				.checkResCalFirstSection(), true,
				"Fail to Check Resource Calender First Section.");
	}

	// Calendar Parameters
	@Test(description = "check to open Calender Parameter Section", dependsOnMethods = {
			"test032ClickOnLocConfLink" })
	public void test034LocCheckCalParamOpen() throws InterruptedException {
		Assert.assertEquals(resourceCalendarPage.getCalendarParameters()
				.checkCalParamOpen(), true,
				"Fail to open Calender Parameter Section");
	}

	// Appointment Parameters
	@Test(description = "check Administration Parameter Section", dependsOnMethods = {
			"test032ClickOnLocConfLink" })
	public void test035LocCheckAppParamSec() throws InterruptedException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.checkAppointParamSection(), false,
				"check Administration Parameter Section");
	}

	// Availability Configuration
	@Test(description = "Check Avilability Configuration Section", dependsOnMethods = {
			"test032ClickOnLocConfLink" })
	public void test036LocCheckAvilConfiSection() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.checkAvilConfiSection(), false,
				"fail to Check Avilability Configuration Section");
	}

	// Non Availability Configuration
	@Test(description = "Check Avilability Configuration Section", dependsOnMethods = {
			"test032ClickOnLocConfLink" })
	public void test037LocCheckNonAvailRegSec() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage
				.getNonAvailabilityConfiguration().checkNonAvailRegSection(),
				false, "fail to Check Avilability Configuration Section");
	}

	@Test(description = "click From Date Validation", dependsOnMethods = "test033CheckLocResCalFirstSec")
	public void test038LocFromDateValidation() throws Exception {

		Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
				.calFromDateValid(), VALMSG_ISTDATEFORMAT,
				"Fail to click From Date Validation.");
	}

	@Test(description = "click To Date Validation", dependsOnMethods = "test033CheckLocResCalFirstSec")
	public void test039LocToDateValidation() throws Exception {
		Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
				.calToDateValid(), VALMSG_ISTDATEFORMAT,
				"Fail to click To Date Validation.");
	}

	@Test(description = "Fill datas of Resource Calendar's First Section", dependsOnMethods = "test033CheckLocResCalFirstSec")
	public void test040LocfillDatasOfFirstSection() throws InterruptedException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.getResCalDetFirstSec()
					.fillDatasOfFirstSection(st), true,
					"Fail to Fill datas of Resource Calendar's First Section");
	}

	// Calendar Parameters

	@Test(description = "fill Datas Of Calender Parameter Section", dependsOnMethods = "test034LocCheckCalParamOpen")
	public void test041LocFillDatasOfCalParamSec() throws InterruptedException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.getCalendarParameters()
					.fillDatasOfCalParamSec(st), true,
					"Fail to fill Datas Of Calender Parameter Section");
	}

	// Appointment Parameters

	@Test(description = "click On Add Button", dependsOnMethods = "test036LocCheckAvilConfiSection")
	public void test042LocClickOnAddButton() throws InterruptedException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
					.clickOnAddButton(st), "Add Record",
					"fail to click On Add Button");
	}

	@Test(description = "chech Mandatory Visit Category", dependsOnMethods = "test042LocClickOnAddButton")
	public void test043LocIsMandVisitCategory() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandVisitCategory(), true,
				"fail to chech Mandatory Visit Category");
	}

	@Test(description = "chech Mandatory Visit Type", dependsOnMethods = "test042LocClickOnAddButton")
	public void test044LocIsMandVisitType() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandVisitType(), true, "fail to chech Mandatory Visit type");
	}

	@Test(description = "chech Mandatory Number Allowed Per Visit", dependsOnMethods = "test042LocClickOnAddButton")
	public void test045LocIsMdNumAllPerVisit() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandNumAllPerVisit(), true,
				"fail to chech Mandatory Number Allowed Per Visit");
	}

	@Test(description = "chech Mandatory Follow-up Duration", dependsOnMethods = "test042LocClickOnAddButton")
	public void test046LocIsMandFollowUpsDuration() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.isMandFollowUpsDuration(), true,
				"fail to chech Mandatory Follow-up Duration");
	}

	@Test(description = "fill Datas of Appoint Parameter PopUp", dependsOnMethods = "test042LocClickOnAddButton")
	public void test047LocFillDatasToPopUp() throws InterruptedException,
			IOException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
					.fillDatasToPopUp(st), true,
					"fail to fill Datas of Appoint Parameter PopUp");
	}

	@Test(description = "submit Follow Up Datas", dependsOnMethods = "test047LocFillDatasToPopUp")
	public void test048LocSubmitFollowUpDatas() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.submitFollowUpDatas(), true, "fail to submit Follow Up Datas");
	}

	@Test(description = "Cancel Follow Up Datas", dependsOnMethods = "test048LocSubmitFollowUpDatas")
	public void test049LocCancelFollowUpDatas() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAppointmentParameters()
				.cancelFollowUpDatas(), true, "fail to Cancel Follow Up Datas");
	}

	// Availability Configuration

	@Test(description = "click On Add Availability Button", dependsOnMethods = {"test036LocCheckAvilConfiSection", "test049LocCancelFollowUpDatas"}, alwaysRun = true)
	public void test050LocClickAddAvailButton() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.clickOnAddAvailButton(), true,
				"fail to click On Add Availability Button");
	}

	@Test(description = "check Mandatory Availability From Date", dependsOnMethods = "test050LocClickAddAvailButton")
	public void test051LocIsMandAvailFromDate() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandFromDate(), true, "fail to check Mandatory From Date");
	}

	@Test(description = "check Mandatory Availability To Date", dependsOnMethods = "test050LocClickAddAvailButton")
	public void test052LocIsMandAvaiToDate() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandToDate(), true, "fail to check Mandatory To Date");
	}

	// Non Availability Configuration

	@Test(description = "click On Add Availability Button", dependsOnMethods = {"test037LocCheckNonAvailRegSec", "test052LocIsMandAvaiToDate"}, alwaysRun = true)
	public void test053LocClickOnAddNonAvailButton() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage
				.getNonAvailabilityConfiguration().clickOnAddNonAvailButton(),
				true, "fail to click On Add Availability Button");
	}

	@Test(description = "check Mandatory From Date", dependsOnMethods = "test053LocClickOnAddNonAvailButton")
	public void test054LocIsMandFromDate() throws InterruptedException,
			IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandFromDate(), true, "fail to check Mandatory From Date");
	}

	@Test(description = "check Mandatory To Date", dependsOnMethods = "test053LocClickOnAddNonAvailButton")
	public void test055LocIsMandToDate() throws InterruptedException, IOException {
		Assert.assertEquals(resourceCalendarPage.getAvailabilityConfiguration()
				.isMandToDate(), true, "fail to check Mandatory To Date");
	}

	@Test(description = "Save Resource Calender Datas", dependsOnMethods = {
			"test053LocClickOnAddNonAvailButton" })
	public void test056LocSaveDatas() throws InterruptedException, IOException {
		Assert.assertEquals(
				resourceCalendarPage.saveDetailsPage().contains(
						"saved successfully"), true,
				"Failed to Save Resource Calender Datas");
	}

	@Test(description = "Activate Resource Calender", dependsOnMethods = "test056LocSaveDatas")
	public void test057LocActivateCalender() throws InterruptedException,
			IOException {
		Assert.assertEquals(
				resourceCalendarPage.activateRecord().contains("Active"), true,
				"Fail to Activate Resource Calender");
	}

	@Test(description = "click on Resource Calender List Tab", dependsOnMethods = { "test057LocActivateCalender" }, alwaysRun = true)
	public void test058LocClickOnRCListTab() throws InterruptedException,
			IOException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.clickOnRCListTab(st),
					true, "Failed to click on Resource Calender List Tab");
	}

	@Test(description = "click on Edit Link of Resource Calender List", dependsOnMethods = { "test058LocClickOnRCListTab" })
	public void test059LocClickOnEditLink() throws InterruptedException,
			IOException {
		for (String st[] : resCalDatas.subList(1, 2))
			Assert.assertEquals(resourceCalendarPage.clickOnEditLink(st), true,
					"Failed to Click on Edit Link of Resource Calender List");
	}
	
	@Test(description = "Sign Out", dependsOnMethods = "test059LocClickOnEditLink", alwaysRun = true)
	public void test060SignOut() throws Exception {
		loginPage = resourceCalendarPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "test060SignOut")
	public void test061Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(5,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}
	
	/*[List Tab] Search By Clinic (Radio button in the page);
				
	[List Tab] Search By Resource (Radio button in the page);
	[List Tab] Configure  (Link in the Search Result grid);
	[List Tab] Edit (Link in the Search Result grid);
	[List Tab] Delete (Link in the Search Result grid);
	[Details Tab] Add More Calendar (Button in the page);
	[Details Tab] Copy Calendar (Button in the page);
	[Details Tab][Section: Calendar Parameters] Manage;
	[Details Tab][Section: Appointment Parameters] Manage;
	[Details Tab][Section: Availability Configuration] Manage;
	[Details Tab][Section: Non-Availability Configuration] Manage;
	[Details Tab][Section: Audit Trail] View*/
	
}
