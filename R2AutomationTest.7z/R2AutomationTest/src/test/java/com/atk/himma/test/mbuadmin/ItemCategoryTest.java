package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.master.ItemCategoryPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ItemCategoryTest extends SeleniumDriverSetup {

	List<String[]> itemCategoryDatas;
	ItemCategoryPage itemCategoryPage;

	@Test(description = "Open Visit Category Page")
	public void openItemCategoryPage() {
		itemCategoryPage = PageFactory.initElements(webDriver,
				ItemCategoryPage.class);
		itemCategoryPage = itemCategoryPage.clickOnItemCategoryMenu(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(itemCategoryPage);
		itemCategoryPage.waitForElementVisibilityOf(itemCategoryPage.getForm());
		itemCategoryPage.waitForElementId(ItemCategoryPage.PAGETITLE_ID);
		Assert.assertEquals(itemCategoryPage.getPageTitle().getText().trim(),
				"Item Category");
	}

	// [Item Category ] Open Form
	@Test(description = "Open Item Category Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkItemCatMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		itemCategoryPage = PageFactory.initElements(webDriver,
				ItemCategoryPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		parentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Item Category");
		itemCategoryPage.setWebDriver(webDriver);
		itemCategoryPage.setWebDriverWait(webDriverWait);
		itemCategoryPage
				.waitForElementXpathExpression(ItemCategoryPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Item Type")
				.get("[Item Category ] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ItemCategoryPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Item Category ] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			itemCategoryPage = itemCategoryPage.clickOnItemCategoryMenu(
					webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(itemCategoryPage);
			itemCategoryPage.waitForElementVisibilityOf(itemCategoryPage
					.getForm());
			itemCategoryPage.waitForElementId(ItemCategoryPage.PAGETITLE_ID);
			Assert.assertEquals(itemCategoryPage.getPageTitle().getText()
					.trim(), "Item Category");
		}
	}
	
	@Test(description = "Open Visit Category Page", dependsOnMethods = { "openItemCategoryPage" })
	public void test1AddItemCategoryInGrid() throws IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		itemCategoryDatas = excelReader.read(properties.getProperty("itemCategory"));
		for (String st[] : itemCategoryDatas.subList(0, 1))
			Assert.assertEquals(itemCategoryPage.addItemCategoryInGrid(st)
					.trim(), st[0].trim(), st[0].trim() + " Add failed");
	}

	@Test(description = "Save Visit Category", dependsOnMethods = { "test1AddItemCategoryInGrid" })
	public void test2SaveItemCategory() throws IOException, InterruptedException {
		for (String st[] : itemCategoryDatas.subList(0, 1))
			Assert.assertEquals(itemCategoryPage.saveItemCategory(st), true,
					st[0].trim() + " Save failed");
	}

	@Test(description = "Edit Visit Category", dependsOnMethods = { "test2SaveItemCategory" })
	public void test3EditItemCategory() throws IOException, InterruptedException {
		for (String st[] : itemCategoryDatas.subList(1, 2)) {
			// itemCategoryPage.addItemCategoryInGrid(st).trim();
			Assert.assertEquals(itemCategoryPage.editItemCategory(st), true,
					st[0].trim() + " Edit Visit Category");
		}
	}

	@Test(description = "Delete Visit Category Page", dependsOnMethods = { "test3EditItemCategory" }, alwaysRun = true)
	public void deleteItemCategory() throws IOException, InterruptedException {
		for (String st[] : itemCategoryDatas.subList(2, 3)) {
			Assert.assertEquals(itemCategoryPage.addItemCategoryInGrid(st)
					.trim(), st[0].trim(), st[0].trim() + " Add failed");
			Assert.assertEquals(itemCategoryPage.saveItemCategory(st), true,
					st[0].trim() + " Save failed");
			Assert.assertEquals(itemCategoryPage.deleteItemCategory(st), true,
					st[0].trim() + " Save failed");
		}
	}
}
