package com.atk.himma.test.mrd;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.pageobjects.appointsched.Appointments;
import com.atk.himma.pageobjects.mrd.MRDDesktopPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class MRDDesktopTest extends SeleniumDriverSetup implements
StatusMessages, RecordStatus{

	MRDDesktopPage mrdDesktopPage;
	Appointments appointmentsPage;
	AppointmentDairy appointmentDairy;
	List<String[]> mrdDeskTopDatas;

	@Test
	public void checkMRDDesktopLink() {

		mrdDesktopPage = PageFactory.initElements(webDriver,
				MRDDesktopPage.class);
		mrdDesktopPage = mrdDesktopPage.checkMRDDesktopLink(webDriver,
				webDriverWait);
		mrdDesktopPage
				.waitForElementXpathExpression(MRDDesktopPage.MRDDESKTOPMENULINK_XPATH);
		Assert.assertEquals(mrdDesktopPage.getMrdDesktopMenuLink().getText(),
				"MRD Desktop", "Fail to Appear MRD Desktop Link");

	}

	@Test(dependsOnMethods = { "checkMRDDesktopLink" })
	public void clickMRDDeskMenuLink() throws Exception {

		mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		mrdDesktopPage.waitForElementId(MRDDesktopPage.GRIDDUMMY_ID);
		Assert.assertEquals(mrdDesktopPage.getPageTitle().getText().trim(),
				"MRD Desktop", "Fail: to open MRD Desktop page");
		excelReader.setInputFile(properties.getProperty("mrdExcel"));
		mrdDeskTopDatas = excelReader
				.read(properties.getProperty("mrdDesktop"));
	}

	@Test
	public void verifyAutoReqMRDVolume() {

		Assert.assertEquals(mrdDesktopPage.verifyAutoReqestMRDVolume(
				"patientName", "MRStatus"), true,
				"Fail to Automatic Request MR Volume");

	}

	@Test
	public void verifySendLink() {

		Assert.assertEquals(
				mrdDesktopPage.verifySendLinkMRDVolume("patientName", "Send"),
				true, "Fail to Verify Send Link");

	}

	@Test
	public void impactOfCanTdAppWOSend() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(0, 1)) {
			appointmentsPage = PageFactory.initElements(webDriver,
					Appointments.class);
			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			Assert.assertTrue(mrdDesktopPage.verifyAutoReqestMRDVolume(
					st[1].trim(), "Requested"));
			mrdDesktopPage.cancelAppointment(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			Assert.assertFalse(mrdDesktopPage.verifyAutoReqestMRDVolume("", ""));

		}
	}

	@Test
	public void impactOfCanTdAppWithSend() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(0, 1)) {

			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			mrdDesktopPage.clickOnGridAction(st[1].trim(), "Send");
			Assert.assertTrue(mrdDesktopPage.verifyAutoReqestMRDVolume(
					st[1].trim(), "Dispatched"));
			mrdDesktopPage.cancelAppointment(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			Assert.assertFalse(mrdDesktopPage.verifyAutoReqestMRDVolume(
					st[1].trim(), "Dispatched"));

		}
	}

	@Test
	public void impactOfReschTDDTWDS() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(1, 2)) {
			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			String dateTimeBefore = mrdDesktopPage.getGridCellData(
					MRDDesktopPage.GRID_ID,
					MRDDesktopPage.GRID_PATNAME_ARIA_DESCRIBEDBY, st[1].trim(),
					MRDDesktopPage.GRID_REQDATANDTIME_ARIA_DESCRIBEDBY);
			appointmentDairy = PageFactory.initElements(webDriver,
					AppointmentDairy.class);
			mrdDesktopPage.reschAppointment(appointmentsPage, appointmentDairy,
					st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			String dateTimeAfter = mrdDesktopPage.getGridCellData(
					MRDDesktopPage.GRID_ID,
					MRDDesktopPage.GRID_PATNAME_ARIA_DESCRIBEDBY, st[1].trim(),
					MRDDesktopPage.GRID_REQDATANDTIME_ARIA_DESCRIBEDBY);
			Assert.assertNotEquals(dateTimeBefore, dateTimeAfter);
		}
	}

	@Test
	public void impactOfReschTDDTWS() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(2, 3)) {
			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			mrdDesktopPage.clickOnGridAction(st[1].trim(), "Send");
			String dateTimeBefore = mrdDesktopPage.getGridCellData(
					MRDDesktopPage.GRID_ID,
					MRDDesktopPage.GRID_PATNAME_ARIA_DESCRIBEDBY, st[1].trim(),
					MRDDesktopPage.GRID_REQDATANDTIME_ARIA_DESCRIBEDBY);
			appointmentDairy = PageFactory.initElements(webDriver,
					AppointmentDairy.class);
			mrdDesktopPage.reschAppointment(appointmentsPage, appointmentDairy,
					st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			String dateTimeAfter = mrdDesktopPage.getGridCellData(
					MRDDesktopPage.GRID_ID,
					MRDDesktopPage.GRID_PATNAME_ARIA_DESCRIBEDBY, st[1].trim(),
					MRDDesktopPage.GRID_REQDATANDTIME_ARIA_DESCRIBEDBY);
			Assert.assertNotEquals(dateTimeBefore, dateTimeAfter);
		}
	}

	@Test
	public void impactOfReschTDTFDWDS() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(2, 3)) {
			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			appointmentDairy = PageFactory.initElements(webDriver,
					AppointmentDairy.class);
			mrdDesktopPage.reschAppointment(appointmentsPage, appointmentDairy,
					st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			Assert.assertFalse(mrdDesktopPage.verifyAutoReqestMRDVolume("", ""));
		}
	}

	@Test
	public void impactOfReschTDTFDWS() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(2, 3)) {
			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			mrdDesktopPage.clickOnGridAction(st[1].trim(), "Send");
			appointmentDairy = PageFactory.initElements(webDriver,
					AppointmentDairy.class);
			mrdDesktopPage.reschAppointment(appointmentsPage, appointmentDairy,
					st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			Assert.assertFalse(mrdDesktopPage.verifyAutoReqestMRDVolume("", ""));
		}
	}

	@Test
	public void impactOfReschFDTTD() throws Exception {
		for (String[] st : mrdDeskTopDatas.subList(2, 3)) {
			mrdDesktopPage.bookAppoint(appointmentsPage, st);
			appointmentDairy = PageFactory.initElements(webDriver,
					AppointmentDairy.class);
			mrdDesktopPage.reschAppointment(appointmentsPage, appointmentDairy,
					st);
			mrdDesktopPage.clickOnMRDDesktopMenu(webDriver, webDriverWait);
			Assert.assertFalse(mrdDesktopPage.verifyAutoReqestMRDVolume(
					st[1].trim(), "Requested"));
		}
	}

	// Verify the respective MR volume status refreshing the grid
	@Test
	public void sendMRVolume() {
		
	}

	@Test
	public void cancelTheDispatch() {
		
	}

	// --------------------Nursing Desktop----------------
	// ------------Receive
	@Test
	public void receiveLatestMRVolume() {
		
	}

	@Test
	public void receivePastMRVolume() {
		
	}

	@Test
	public void checkReceiveAfterCancel() {
		
	}

	// ------------Return
	@Test
	public void checkRturnAutRequest() {
		
	}

	@Test
	public void checkRturnPastReq() {
		
	}

	// -------------------------------------MR
	// Desktop------------------------------
	@Test
	public void checkRecBackToMRVolume() {
		
	}

	@Test
	public void quickSearchWOData() {

	}

	@Test
	public void quickSearchWithMRN() {

	}

	@Test
	public void quickSearchWithReqNo() {

	}

	@Test
	public void verifyReset() {

	}

	@Test
	public void searchByAdvSearch() {

	}

	@Test
	public void restInAdvSearch() {

	}

	@Test
	public void VerfySearchByDefaultInSR() {

	}

	/*
	 * Verfiy the default count attached with each of the status link in left
	 * panel when navigated to the MRD desktop
	 */

	@Test
	public void verfyAllCountSL() {

	}

	@Test
	public void verfyReqiredCountSL() {

	}

	@Test
	public void verfyDispatchedCountSL() {

	}

	@Test
	public void verfyReqReceivedCountSL() {

	}

	@Test
	public void verfyReqReturnedCountSL() {

	}

	@Test
	public void verfyMRDReceivedCountSL() {

	}

	@Test
	public void verfyDispCanceledCountSL() {

	}
	
	/* See the MR volume file movement requested under a request */
	
	@Test
	public void verfyMRVolFileMovement() {
		
	}
	
}
