package com.atk.himma.pageobjects.laboratory.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class InstructionDetailsTabPage extends DriverWaitClass {
	public final static String ADDNEWINSTRUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	@FindBy(xpath = ADDNEWINSTRUPBTN_XPATH)
	private WebElement addNewInstrUpBtn;

	public final static String SAVEINSTRUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	@FindBy(xpath = SAVEINSTRUPBTN_XPATH)
	private WebElement saveUpBtn;

	public final static String CANCELINSTRUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	@FindBy(id = CANCELINSTRUPBTN_XPATH)
	private WebElement cancelUpBtn;

	public final static String UPDATEINSTRUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	@FindBy(id = UPDATEINSTRUPBTN_XPATH)
	private WebElement updateUpBtn;

	public final static String INSTRCODE_ID = "instrCodeId";
	@FindBy(id = INSTRCODE_ID)
	private WebElement instrCode;

	public final static String INSTRSHNAME_ID = "instrShortNameId";
	@FindBy(id = INSTRSHNAME_ID)
	private WebElement instrShName;

	public final static String INSTRTYPE_ID = "instrTypeId";
	@FindBy(id = INSTRTYPE_ID)
	private WebElement instrType;

	public final static String INSTRDESC_ID = "instrDescId";
	@FindBy(id = INSTRDESC_ID)
	private WebElement instrDesc;

	public final static String INSTRDESCAR_ID = "instrDescArId";
	@FindBy(id = INSTRDESCAR_ID)
	private WebElement instrDescAr;

	public WebElement getAddNewInstrUpBtn() {
		return addNewInstrUpBtn;
	}

	public WebElement getSaveUpBtn() {
		return saveUpBtn;
	}

	public WebElement getCancelUpBtn() {
		return cancelUpBtn;
	}

	public WebElement getUpdateUpBtn() {
		return updateUpBtn;
	}

	public WebElement getInstrCode() {
		return instrCode;
	}

	public WebElement getInstrShName() {
		return instrShName;
	}

	public WebElement getInstrType() {
		return instrType;
	}

	public WebElement getInstrDesc() {
		return instrDesc;
	}

	public WebElement getInstrDescAr() {
		return instrDescAr;
	}

}
