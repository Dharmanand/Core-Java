package com.atk.himma.pageobjects.laboratory.masters;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.laboratory.masters.tabs.OrganismDetailsTabPage;
import com.atk.himma.pageobjects.laboratory.masters.tabs.OrganismListTabPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class OrganismPage extends DriverWaitClass {
	private OrganismListTabPage organismListTabPage;
	private OrganismDetailsTabPage organismDetailsTabPage;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String ORGANISMLISTTAB_XPATH = ".//a[@href='#organismListDiv']";
	@FindBy(xpath = ORGANISMLISTTAB_XPATH)
	private WebElement organismListTab;

	public final static String ORGANISMDTLTAB_XPATH = ".//a[@href='#organismDetailsDiv']";
	@FindBy(xpath = ORGANISMDTLTAB_XPATH)
	private WebElement organismDetailsTab;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		organismListTabPage = PageFactory.initElements(webDriver,
				OrganismListTabPage.class);
		organismListTabPage.setWebDriver(webDriver);
		organismListTabPage.setWebDriverWait(webDriverWait);

		organismDetailsTabPage = PageFactory.initElements(webDriver,
				OrganismDetailsTabPage.class);
		organismDetailsTabPage.setWebDriver(webDriver);
		organismDetailsTabPage.setWebDriverWait(webDriverWait);

	}

	public OrganismPage clickOnOrganismMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> organismMenuList = new LinkedList<String>();
		organismMenuList.add("Laboratory");
		organismMenuList.add("Masters ");
		menuSelector.clickOnTargetMenu(organismMenuList, "Organism");
		OrganismPage organismPage = PageFactory.initElements(webDriver,
				OrganismPage.class);
		organismPage.setWebDriver(webDriver);
		organismPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return organismPage;

	}

	public OrganismListTabPage getOrganismListTabPage() {
		return organismListTabPage;
	}

	public OrganismDetailsTabPage getOrganismDetailsTabPage() {
		return organismDetailsTabPage;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getOrganismListTab() {
		return organismListTab;
	}

	public WebElement getOrganismDetailsTab() {
		return organismDetailsTab;
	}

}
