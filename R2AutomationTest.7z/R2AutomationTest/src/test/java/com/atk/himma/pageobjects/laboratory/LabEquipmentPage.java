package com.atk.himma.pageobjects.laboratory;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.laboratory.sections.LabEquipmentDetailsDefaultSec;
import com.atk.himma.pageobjects.laboratory.tabs.LabEquipmentListTabPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class LabEquipmentPage extends DriverWaitClass {
	private LabEquipmentListTabPage labEquipmentListTabPage;
	private LabEquipmentDetailsDefaultSec labEquipmentDetailsDefaultSec;
	private LabEquipmentDetailsDefaultSec labDetailsSec;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String LABEQUIPLISTTAB_XPATH = "//a[@title='Lab Equipment List']";
	@FindBy(xpath = LABEQUIPLISTTAB_XPATH)
	private WebElement labEquipListTab;

	public final static String LABEQUIPDTLTAB_XPATH = "//a[@title='Lab Equipment Details']";
	@FindBy(xpath = LABEQUIPDTLTAB_XPATH)
	private WebElement labEquipDetailsTab;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		labEquipmentListTabPage = PageFactory.initElements(webDriver,
				LabEquipmentListTabPage.class);
		labEquipmentListTabPage.setWebDriver(webDriver);
		labEquipmentListTabPage.setWebDriverWait(webDriverWait);

		labEquipmentDetailsDefaultSec = PageFactory.initElements(webDriver,
				LabEquipmentDetailsDefaultSec.class);
		labEquipmentListTabPage.setWebDriver(webDriver);
		labEquipmentListTabPage.setWebDriverWait(webDriverWait);

		labDetailsSec = PageFactory.initElements(webDriver,
				LabEquipmentDetailsDefaultSec.class);
		labDetailsSec.setWebDriver(webDriver);
		labDetailsSec.setWebDriverWait(webDriverWait);
	}

	public LabEquipmentPage clickOnLabTestMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> labEquipMenuList = new LinkedList<String>();
		labEquipMenuList.add("Laboratory");
		menuSelector.clickOnTargetMenu(labEquipMenuList, "Lab Equipment");
		LabEquipmentPage labEquipmentPage = PageFactory.initElements(webDriver,
				LabEquipmentPage.class);
		labEquipmentPage.setWebDriver(webDriver);
		labEquipmentPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return labEquipmentPage;

	}

	public LabEquipmentListTabPage getLabEquipmentListTabPage() {
		return labEquipmentListTabPage;
	}

	public LabEquipmentDetailsDefaultSec getLabEquipmentDetailsDefaultSec() {
		return labEquipmentDetailsDefaultSec;
	}

	public LabEquipmentDetailsDefaultSec getLabDetailsSec() {
		return labDetailsSec;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getLabEquipListTab() {
		return labEquipListTab;
	}

	public WebElement getLabEquipDetailsTab() {
		return labEquipDetailsTab;
	}

}
