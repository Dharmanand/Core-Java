package com.atk.himma.test.appointschedu;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.appointsched.EncounterPage;
import com.atk.himma.pageobjects.desktop.DesktopDataPage;
import com.atk.himma.setup.SeleniumDriverSetup;

@Test(groups={"functionalTestGrp"})
public class OutpatientDesktopTest extends SeleniumDriverSetup {

	LoginPage loginPage;
	List<String[]> outPatientDesktopDatas;
	DesktopDataPage desktopDataPage;
	EncounterPage encounterPage;

	@Test(description = "Open Service Page")
	public void clickOnOutpatDesktopMenu() throws Exception {
		desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage = desktopDataPage.clickOnOutpatDesktopMenu(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		desktopDataPage.waitForElementId(DesktopDataPage.PAGETITLE_ID);
		desktopDataPage.sleepShort();
		Assert.assertEquals(desktopDataPage.getPageTitle().getText().trim()
				.equals("Outpatient Desktop"), true,
				"Fail to open Appointments Page");
	}

	@Test(description = "Open Encounter page", dependsOnMethods={"clickOnOutpatDesktopMenu"})
	public void test1ClickOnEncounterLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("AppSchedExcel"));
		outPatientDesktopDatas = excelReader.read(properties.getProperty("outPatientDesktop"));
		for (String[] st : outPatientDesktopDatas.subList(0, 1)) {
			encounterPage = desktopDataPage.clickOnEncounterLink(st[0].trim());
			Assert.assertEquals(encounterPage.getPageTitle().getText().trim()
					.equals("Encounter"), true, "Fail to Open Encounter page");
		}
	}

	@Test(description = "Fill Datas on Encounter page", dependsOnMethods={"test1ClickOnEncounterLink"})
	public void test2FillDatas() throws Exception {
		for (String[] st : outPatientDesktopDatas.subList(0, 1)) {
			encounterPage.fillDatas(st);
			Assert.assertEquals(
					encounterPage.getComments().getAttribute("value").trim()
							.equals(st[2].trim()), true,
					"Fail to fill Datas on Encounter page");
		}
	}

	@Test(description = "Save Encounter page", dependsOnMethods={"test2FillDatas"})
	public void test3SaveEncounterPage() throws Exception {
		Assert.assertEquals(
				encounterPage.saveEncounter().contains("Encounter Created"),
				true, "Fail to Save Encounter page");
	}

	@Test(description = "Update Encounter page", dependsOnMethods={"test3SaveEncounterPage"})
	public void test4UpdateEncounterPage() throws Exception {
		for (String[] st : outPatientDesktopDatas.subList(0, 1)) {
			encounterPage.updateEncounter(st);
			Assert.assertEquals(
					encounterPage.getComments().getAttribute("value").trim()
							.equals(st[2].trim()), true,
					"Fail to Update Encounter page");
		}
	}

	@Test(description = "Sign Out", dependsOnMethods = "test3SaveEncounterPage", alwaysRun=true)
	public void test5SignOut() throws Exception {
		loginPage = encounterPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "test5SignOut")
	public void test6Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(6,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}

}
