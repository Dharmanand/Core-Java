package com.atk.himma.test;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.HomePage;
import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.setup.SeleniumDriverSetup;

@Test(groups={"functionalTestGrp"})
public class LoginFunctionTest extends SeleniumDriverSetup {

	List<String[]> loginDatas;
	LoginPage loginPage;

	@Test(description = "check login Url", groups={"checkUrl"})
	public void checkUrl() throws Exception {
		webDriver.get(properties.getProperty("loginURL").trim());
		loginPage = PageFactory.initElements(webDriver, LoginPage.class);
		loginPage.setWebDriverWait(webDriverWait);
		excelReader.setInputFile(properties.getProperty("loginExcel").trim());
		loginDatas = excelReader.read(properties.getProperty("loginSheetName").trim());
		Assert.assertNotNull(loginPage);
		Assert.assertNotNull(loginPage.getFormTitle());
	}

	/*@Test(description = "login No Success", dependsOnMethods = { "checkUrl" })
	public void loginNoSuccess() throws Exception {
		for (String st[] : loginDatas.subList(0, 1))
			loginPage = loginPage.doLoginWithIncorrectUserAndPassword(
					webDriver, st[0].trim(), st[1].trim());
		loginPage.setWebDriverWait(webDriverWait);
		loginPage.loginErrorMsg();
		Assert.assertNotNull(loginPage);
		Assert.assertNotNull(loginPage.getFormTitle());
		loginPage.waitForElementName(LoginPage.USERNAME_NAME);
		// waitForElement(loginPage.getUserName());
		Assert.assertNotNull(loginPage.getUserName());
		Assert.assertNotNull(loginPage.getPassword());
		Assert.assertNotNull(loginPage.getLoginButton());
	}

	@Test(description = "login Success for superadmin", dependsOnMethods = { "checkUrl" })
	public void loginWithSuperAdmin() throws Exception {
		HomePage homePage = null;
		for (String st[] : loginDatas.subList(1, 2))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		homePage.setWebDriverWait(webDriverWait);
		loginPage.loginErrorMsg();
		homePage.waitForElementId(HomePage.getLogoutId());
		Assert.assertNotNull(homePage.getLogOut());
		Assert.assertNotNull(homePage.getHomeTitle());
	}*/

	/*@Test(description = "login Success", dependsOnMethods = { "checkUrl" })
	public void loginSuccess() throws Exception {
		HomePage homePage = null;
		for (String st[] : loginDatas.subList(2, 3))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		homePage.setWebDriverWait(webDriverWait);
		loginPage.loginErrorMsg();
		homePage.waitForElementId(HomePage.getLogoutId());
		Assert.assertNotNull(homePage.getLogOut());
		Assert.assertNotNull(homePage.getHomeTitle());
	}*/
/*
	@Test(description = "login Success With Location", dependsOnMethods = { "checkUrl" })
	public void loginSuccessWithLocation() throws Exception {
		HomePage homePage = null;
		for (String st[] : loginDatas.subList(8, 9))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		homePage.setWebDriverWait(webDriverWait);
		homePage.waitForElementId(HomePage.getLogoutId());
		Assert.assertNotNull(homePage.getLogOut());
		Assert.assertNotNull(homePage.getHomeTitle());
	}*/
	
	/*@Test(description = "login Success With Position", dependsOnMethods = { "checkUrl" })
	public void loginSuccessWithPosition() throws Exception {
		HomePage homePage = null;
		for (String st[] : loginDatas.subList(2, 3))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
				homePage.setWebDriverWait(webDriverWait);
				homePage.waitForElementId(HomePage.getLogoutId());
				Assert.assertNotNull(homePage.getLogOut());
				Assert.assertNotNull(homePage.getHomeTitle());
	}*/
	
	@Test(description = "login Success With Location and position", dependsOnMethods = { "checkUrl" })
	public void loginSuccessWithLocAndPos() throws Exception {
		HomePage homePage = null;
		for (String st[] : loginDatas.subList(4,5))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
				homePage.setWebDriverWait(webDriverWait);
				homePage.waitForElementId(HomePage.getLogoutId());
				Assert.assertNotNull(homePage.getLogOut());
				Assert.assertNotNull(homePage.getHomeTitle());
	}
	/*@Test(description = "login Success With Location and position", groups={"checkPrivilegesGrp"}, dependsOnMethods = { "checkUrl" })
	public void loginSuccessWithUserpr() throws Exception {
		HomePage homePage = null;
		for (String st[] : loginDatas.subList(7,8))
			homePage = loginPage.doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
				homePage.setWebDriverWait(webDriverWait);
				homePage.waitForElementId(HomePage.getLogoutId());
				Assert.assertNotNull(homePage.getLogOut());
				Assert.assertNotNull(homePage.getHomeTitle());
	}*/
}
