package com.atk.himma.pageobjects.radiology.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.pharmacy.sections.DrugCompDetailsFirstSection;
import com.atk.himma.pageobjects.radiology.tabs.InstructionDetailsTab;
import com.atk.himma.pageobjects.radiology.tabs.InstructionListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class RadiologyInstructionPage extends DriverWaitClass {

	InstructionDetailsTab instructionDetailsTab;
	InstructionListTab instructionListTab;

	public final static String INSTRUCTIONLINK_LINKTEXT = "Instruction";
	public final static String INSTRUCTIONLISTTAB_LINKTEXT = "Instruction List";
	public final static String INSTRUCTIONDETAILSTAB_LINKTEXT = "Instruction Details";

	@FindBy(linkText = INSTRUCTIONLINK_LINKTEXT)
	private WebElement instructionLink;

	@FindBy(linkText = INSTRUCTIONLISTTAB_LINKTEXT)
	private WebElement instructionListTabLink;

	@FindBy(linkText = INSTRUCTIONDETAILSTAB_LINKTEXT)
	private WebElement instructionDetailsTabLink;

	@FindBy(linkText = INSTRUCTIONDETAILSTAB_LINKTEXT)
	private WebElement instructDetailsTabLink;

	public RadiologyInstructionPage setInstanceOfAllSection(
			WebDriver webDriver, WebDriverWait webDriverWait) {
		instructionListTab = PageFactory.initElements(webDriver,
				InstructionListTab.class);
		instructionListTab.setWebDriver(webDriver);
		instructionListTab.setWebDriverWait(webDriverWait);
		instructionDetailsTab = PageFactory.initElements(webDriver,
				InstructionDetailsTab.class);
		instructionDetailsTab.setWebDriver(webDriver);
		instructionDetailsTab.setWebDriverWait(webDriverWait);
		RadiologyInstructionPage radiologyInstructionPage = PageFactory
				.initElements(webDriver, RadiologyInstructionPage.class);
		radiologyInstructionPage.setWebDriver(webDriver);
		radiologyInstructionPage.setWebDriverWait(webDriverWait);
		return radiologyInstructionPage;
	}

	public RadiologyInstructionPage checkDrugComponentLink(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Radiology");
		menuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(menuList, "Instruction");
		RadiologyInstructionPage radiologyInstructionPage = PageFactory
				.initElements(webDriver, RadiologyInstructionPage.class);
		return radiologyInstructionPage;
	}

	public RadiologyInstructionPage clickOnDrugComponentMenu() throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Radiology");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Instruction");
		RadiologyInstructionPage radiologyInstructionPage = PageFactory
				.initElements(webDriver, RadiologyInstructionPage.class);
		radiologyInstructionPage.setWebDriver(webDriver);
		radiologyInstructionPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForElementId(InstructionListTab.GRID_ID);
		return radiologyInstructionPage;
	}

	public boolean clickOnAddNewInstrucBtn() throws Exception {
		waitForElementId(InstructionListTab.ADDNEWINSTRUBUTTON_ID);
		instructionDetailsTab.getAddNewButton().click();
		waitForElementId(InstructionDetailsTab.FORM_ID);
		return instructionDetailsTab.getSaveButton().isDisplayed();
	}

	public boolean isReadonlyInstructCode() {
		return isReadonlyField(instructionDetailsTab.getInstruCodeTxt());
	}

	public boolean isMandatoryInstrucShortNM() {
		return isMandatoryField(instructionDetailsTab
				.getInstruShortName());
	}

	public boolean isMandatoryInstrucType() {
		return isMandatoryField(instructionDetailsTab
				.getInstructionType());
	}

	public boolean isMandatoryInstrucDescrip() {
		return isMandatoryField(instructionDetailsTab.getInstruDescr());
	}

	public boolean fillRadiolInstructionDatas(String[] radiologyInstrucDatas) {
		if (!radiologyInstrucDatas[0].isEmpty()) {
			instructionDetailsTab.getInstruShortName().clear();
			instructionDetailsTab.getInstruShortName().sendKeys(
					radiologyInstrucDatas[0].trim());
		}
		if (!radiologyInstrucDatas[1].isEmpty()) {
			new Select(instructionDetailsTab.getInstructionType()).selectByVisibleText(radiologyInstrucDatas[1].trim());
		}
		if (!radiologyInstrucDatas[2].isEmpty()) {
			instructionDetailsTab.getInstruShortName().clear();
			instructionDetailsTab.getInstruShortName().sendKeys(
					radiologyInstrucDatas[2].trim());
		}
		if (!radiologyInstrucDatas[3].isEmpty()) {
			new Select(instructionDetailsTab.getInstruDescrAr())
					.selectByVisibleText(radiologyInstrucDatas[3].trim());
		}
		return instructionDetailsTab.getInstruShortName()
				.getAttribute("value").trim() == radiologyInstrucDatas[2].trim();
	}

	public boolean saveData() {
		waitForElementXpathExpression(InstructionDetailsTab.SAVEBUTTON_XPATH);
		instructionDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(InstructionDetailsTab.UPDATEBUTTON_XPATH);
		return instructionDetailsTab.getUpdateButton().isDisplayed();
	}

	public boolean updateData(String[] radiologyInstrucDatas) {

		waitForElementCssSelector(DrugCompDetailsFirstSection.UPDATEBUTTON_CSS);
		if (!radiologyInstrucDatas[0].isEmpty()) {
			instructionDetailsTab.getInstruShortName().clear();
			instructionDetailsTab.getInstruShortName().sendKeys(
					radiologyInstrucDatas[0].trim());
		}
		if (!radiologyInstrucDatas[1].isEmpty()) {
			new Select(instructionDetailsTab.getInstructionType()).selectByVisibleText(radiologyInstrucDatas[1].trim());
		}
		if (!radiologyInstrucDatas[2].isEmpty()) {
			instructionDetailsTab.getInstruShortName().clear();
			instructionDetailsTab.getInstruShortName().sendKeys(
					radiologyInstrucDatas[2].trim());
		}
		if (!radiologyInstrucDatas[3].isEmpty()) {
			new Select(instructionDetailsTab.getInstruDescrAr())
					.selectByVisibleText(radiologyInstrucDatas[3].trim());
		}
		instructionDetailsTab.getUpdateButton().click();
		waitForElementCssSelector(InstructionDetailsTab.UPDATEBUTTON_XPATH);
		return instructionDetailsTab.getInstruShortName()
				.getAttribute("value").trim() == radiologyInstrucDatas[2].trim();
	}
	
	/**
	 * @return the instructionDetailsTabLink
	 */
	public WebElement getInstructionDetailsTabLink() {
		return instructionDetailsTabLink;
	}

	/**
	 * @param instructionDetailsTabLink
	 *            the instructionDetailsTabLink to set
	 */
	public void setInstructionDetailsTabLink(
			WebElement instructionDetailsTabLink) {
		this.instructionDetailsTabLink = instructionDetailsTabLink;
	}

	/**
	 * @return the instructionDetailsTab
	 */
	public InstructionDetailsTab getInstructionDetailsTab() {
		return instructionDetailsTab;
	}

	/**
	 * @return the instructionListTab
	 */
	public InstructionListTab getInstructionListTab() {
		return instructionListTab;
	}

	/**
	 * @return the instructionLink
	 */
	public WebElement getInstructionLink() {
		return instructionLink;
	}

	/**
	 * @return the instructionListTabLink
	 */
	public WebElement getInstructionListTabLink() {
		return instructionListTabLink;
	}

	/**
	 * @return the instructDetailsTabLink
	 */
	public WebElement getInstructDetailsTabLink() {
		return instructDetailsTabLink;
	}

	/**
	 * @param instructionDetailsTab
	 *            the instructionDetailsTab to set
	 */
	public void setInstructionDetailsTab(
			InstructionDetailsTab instructionDetailsTab) {
		this.instructionDetailsTab = instructionDetailsTab;
	}

	/**
	 * @param instructionListTab
	 *            the instructionListTab to set
	 */
	public void setInstructionListTab(InstructionListTab instructionListTab) {
		this.instructionListTab = instructionListTab;
	}

	/**
	 * @param instructionLink
	 *            the instructionLink to set
	 */
	public void setInstructionLink(WebElement instructionLink) {
		this.instructionLink = instructionLink;
	}

	/**
	 * @param instructionListTabLink
	 *            the instructionListTabLink to set
	 */
	public void setInstructionListTabLink(WebElement instructionListTabLink) {
		this.instructionListTabLink = instructionListTabLink;
	}

	/**
	 * @param instructDetailsTabLink
	 *            the instructDetailsTabLink to set
	 */
	public void setInstructDetailsTabLink(WebElement instructDetailsTabLink) {
		this.instructDetailsTabLink = instructDetailsTabLink;
	}
}
