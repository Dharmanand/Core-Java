package com.atk.himma.pageobjects.sa.tabs;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.JsTreeSelector;

public class AppUserProfessionalDetailsSection extends DriverWaitClass {
	public final static String PROFDETAILSSECTION_LINKTXT = "Professional Details";
	@FindBy(linkText = PROFDETAILSSECTION_LINKTXT)
	private WebElement profDetailsSectionLinkTxt;

	public final static String PRIMARYPOSITIONLOOKUP_ID = "priPosSearchIcon";
	@FindBy(id = PRIMARYPOSITIONLOOKUP_ID)
	private WebElement primaryPositionLookup;

	public final static String SECONDARYPOSITIONLOOKUP_ID = "secPosSearchIcon";
	@FindBy(id = SECONDARYPOSITIONLOOKUP_ID)
	private WebElement secondaryPositionLookup;

	public final static String POSLOOKUPFORM_ID = "EMP_POS_LOOKUP_FRM";
	@FindBy(id = POSLOOKUPFORM_ID)
	private WebElement posLookupForm;

	public final static String POSTREEDIV_ID = "orgTree";
	@FindBy(id = POSTREEDIV_ID)
	private WebElement posTreeDiv;

	public final static String ASSIGNPOSITION_ID = "ASSIGN_POSITION_SELECT";
	@FindBy(id = ASSIGNPOSITION_ID)
	private WebElement assignPosition;

	public final static String ASSIGNBTN_ID = "assignPositionId";
	@FindBy(id = ASSIGNBTN_ID)
	private WebElement assignBtn;

	public final static String CLOSEBTN_XPATH = "//input[@value='Close']";
	@FindBy(xpath = CLOSEBTN_XPATH)
	private WebElement closeBtn;

	public final static String CLEARBTN_ID = "clearLink";
	@FindBy(id = CLEARBTN_ID)
	private WebElement clearBtn;

	public final static String MBU_ID = "RESOURCE_MBU_TEXT";
	@FindBy(id = MBU_ID)
	private WebElement MBU;

	public final static String RESOURCECATEGORY_ID = "RESOURCE_CATEGORY_TEXT";
	@FindBy(id = RESOURCECATEGORY_ID)
	private WebElement resourceCategory;

	public final static String RESOURCETYPE_ID = "RESOURCE_TYPE_TAB2";
	@FindBy(id = RESOURCETYPE_ID)
	private WebElement resourceType;

	public final static String DESIGNATION_ID = "EMPLOYEE_DESGN_TAB2";
	@FindBy(id = DESIGNATION_ID)
	private WebElement designation;

	public final static String RESOURCESTATUS_ID = "empStatus";
	@FindBy(id = RESOURCESTATUS_ID)
	private WebElement resourceStatus;

	public final static String SPECIALTY_ID = "SPECIALITY_LIST_TAB2";
	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;

	public final static String SUBSPECIALTY_ID = "SUB_SPECIALITY_LIST_TAB2";
	@FindBy(id = SUBSPECIALTY_ID)
	private WebElement subSpecialty;

	public final static String ASSIGNEDLOCGRID_ID = "gbox_ASSIGNED_LOCATION_GRID";
	@FindBy(id = ASSIGNEDLOCGRID_ID)
	private WebElement assignedLocGrid;

	public boolean checkPrimPos(String[] appUserData, List<String[]> posList)
			throws Exception {
		boolean selPos = false;
		if (!appUserData[19].isEmpty()) {
			primaryPositionLookup.click();
			sleepShort();
			waitForElementId(POSLOOKUPFORM_ID);
			selPos = selectPosition(POSTREEDIV_ID, appUserData[21],
					appUserData[20], appUserData[19], posList);
		}
		return selPos;
	}

	public void fillProfessionalDetails(String[] appUserData,
			List<String[]> posList) throws Exception {
		sleepShort();
		if (!appUserData[22].isEmpty()) {
			secondaryPositionLookup.click();
			sleepVeryShort();
			selectPosition(POSTREEDIV_ID, appUserData[24], appUserData[23],
					appUserData[22], posList);
		}

		if (!appUserData[26].isEmpty()) {
			new Select(resourceType).selectByVisibleText(appUserData[26]);
		}
		if (!appUserData[27].isEmpty()) {
			new Select(designation).selectByVisibleText(appUserData[27]);
		}
		if (!appUserData[28].isEmpty()) {
			new Select(resourceStatus).selectByVisibleText(appUserData[28]);
		}
		if (!appUserData[29].isEmpty()) {
			new Select(specialty).selectByVisibleText(appUserData[29]);
		}
		if (!appUserData[30].isEmpty()) {
			new Select(subSpecialty).selectByVisibleText(appUserData[30]);
		}
	}

	public boolean selectPosition(String postreedivId, String node,
			String parent, String posName, List<String[]> posList)
			throws Exception {
		new JsTreeSelector(webDriver, webDriverWait).expandTree(POSTREEDIV_ID);
		sleepVeryShort();
		new JsTreeSelector(webDriver, webDriverWait).selectTreeNode(
				postreedivId, node, parent);
		waitForElementId(ASSIGNPOSITION_ID);
		sleepShort();
		boolean res = false;
		List<WebElement> positions = new Select(assignPosition).getOptions();
		for (WebElement pos : positions) {
			for (String[] posData : posList) {
				if (pos.getText().contains(posData[0])) {
					res = true;
				}
			}
		}
		new Select(assignPosition).selectByVisibleText(posName);
		assignBtn.click();
		sleepShort();
		return res;
	}

	public WebElement getProfDetailsSectionLinkTxt() {
		return profDetailsSectionLinkTxt;
	}

	public WebElement getPrimaryPositionLookup() {
		return primaryPositionLookup;
	}

	public WebElement getSecondaryPositionLookup() {
		return secondaryPositionLookup;
	}

	public WebElement getPosLookupForm() {
		return posLookupForm;
	}

	public WebElement getPosTreeDiv() {
		return posTreeDiv;
	}

	public WebElement getAssignPosition() {
		return assignPosition;
	}

	public WebElement getAssignBtn() {
		return assignBtn;
	}

	public WebElement getCloseBtn() {
		return closeBtn;
	}

	public WebElement getClearBtn() {
		return clearBtn;
	}

	public WebElement getMBU() {
		return MBU;
	}

	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	public WebElement getResourceType() {
		return resourceType;
	}

	public WebElement getDesignation() {
		return designation;
	}

	public WebElement getResourceStatus() {
		return resourceStatus;
	}

	public WebElement getSpecialty() {
		return specialty;
	}

	public WebElement getSubSpecialty() {
		return subSpecialty;
	}

	public WebElement getAssignedLocGrid() {
		return assignedLocGrid;
	}

}
