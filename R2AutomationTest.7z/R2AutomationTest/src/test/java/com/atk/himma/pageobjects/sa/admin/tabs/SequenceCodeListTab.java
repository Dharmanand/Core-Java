package com.atk.himma.pageobjects.sa.admin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class SequenceCodeListTab extends DriverWaitClass {
	public final static String SEQUENCECODEFORM_ID = "CODE_SEQUENCE";
	@FindBy(id = SEQUENCECODEFORM_ID)
	private WebElement sequenceCodeForm;

	public final static String ADDNEWCODESEQBTN_ID = "NEW_CODE_SEQ";
	@FindBy(id = ADDNEWCODESEQBTN_ID)
	private WebElement addNewCodeSeqBtn;

	public final static String MBUNAME_ID = "S_MBU_NAME";
	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;

	public final static String APPLICABLETOALLMBUS_ID = "ALL_MBU";
	@FindBy(id = APPLICABLETOALLMBUS_ID)
	private WebElement applicableToAllMBUs;

	public final static String MODULENAME_ID = "S_Module_Name";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String CODENAME_ID = "S_SEQ_NAME";
	@FindBy(id = CODENAME_ID)
	private WebElement codeName;

	public final static String CODINGPATTERN_ALL_ID = "ALL_SEARCH";
	@FindBy(id = CODINGPATTERN_ALL_ID)
	private WebElement codingPattern_All;

	public final static String CODINGPATTERN_MANUAL_ID = "MANUAL_SEARCH";
	@FindBy(id = CODINGPATTERN_MANUAL_ID)
	private WebElement codingPattern_manual;

	public final static String CODINGPATTERN_SYSTEM_ID = "SYSTEM_GEN_SEARCH";
	@FindBy(id = CODINGPATTERN_SYSTEM_ID)
	private WebElement codingPattern_system;

	public final static String SEARCHBTN_XPATH = "//input[@value='Search']";
	@FindBy(xpath = SEARCHBTN_XPATH)
	private WebElement searchBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String SEQCODEGRID_ID = "CODE_GEN_GRID";
	@FindBy(id = SEQCODEGRID_ID)
	private WebElement seqCodeGrid;

	public final static String EDITLINK_XPATH = ".//table[@id='CODE_GEN_GRID']/..//a[text()='Edit']";
	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	public final static String DELETELINK_XPATH = ".//table[@id='CODE_GEN_GRID']/..//a[text()='Delete']";
	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public void addNewSequnceCode() throws Exception {
		addNewCodeSeqBtn.click();
		sleepShort();
	}

	public void searchSeqCodes(String[] scdata) throws Exception {
		if (!scdata[1].isEmpty()) {
			new Select(moduleName).selectByVisibleText(scdata[1]);
		}

		if (!scdata[2].isEmpty()) {
			new Select(codeName).selectByVisibleText(scdata[2]);
		}
		searchBtn.click();
		waitForElementId(SEQCODEGRID_ID);
		sleepShort();

	}

	public WebElement getSequenceCodeForm() {
		return sequenceCodeForm;
	}

	public WebElement getAddNewCodeSeqBtn() {
		return addNewCodeSeqBtn;
	}

	public WebElement getMbuName() {
		return mbuName;
	}

	public WebElement getApplicableToAllMBUs() {
		return applicableToAllMBUs;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getCodeName() {
		return codeName;
	}

	public WebElement getCodingPattern_All() {
		return codingPattern_All;
	}

	public WebElement getCodingPattern_manual() {
		return codingPattern_manual;
	}

	public WebElement getCodingPattern_system() {
		return codingPattern_system;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getSeqCodeGrid() {
		return seqCodeGrid;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
