package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AlternativeMedicinesSection {

	public final static String SECTIONNAME_LINKTEXT = "Alternative Medicines";
	public final static String ADDBUTTONGRID_XPATH = "//td[@id='ALTERNATIVE_MEDICINE_GRID_pager_left']//span[@class='ui-icon ui-icon-plus']";

	public final static String GRID_ID = "ALTERNATIVE_MEDICINE_GRID";
	public final static String GRID_DRUGCODE_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_alternativeDrug.brandedDrugCode";
	public final static String GRID_DRUGNAME_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_alternativeDrug.brandedDrugName";
	public final static String GRID_DOSAGEFORM_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_alternativeDrug.drugDosageFormText";
	public final static String GRID_ROUTEOFADMINTEXT_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_routeOfAdminText";
	public final static String GRID_QUANTITY_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_quantity";
	public final static String GRID_UNIT_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_unitText";
	public final static String GRID_FREQUENCY_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_frequencyText";
	public final static String GRID_DURATION_ARIA_DESCRIBEDBY = "ALTERNATIVE_MEDICINE_GRID_periodText";

//	(popup)---------------
	public final static String POPUPDIV_XPATH = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable' and @aria-labelledby='ui-dialog-title-ALTERNATE_MEDICINE_DIALOG']";
	public final static String QUICKSEARCHTXT_ID = "ALT_SEARCH_STRING";
	public final static String SEARCHBUTTON_ID = "ALT_MED_SEARCH";
	public final static String RESETBUTTON_CSS = "#ALT_MED_SEARCH + input";
	public final static String ADVSEARCHBUTTON_ID = "ALTERNATE_MEDICINE_DIALOG_ADV_SEARCH";

	// --------Search Result(s) - Generic Drugs(popup)---------------
	public final static String GRIDSEARCH_ID = "SEARCH_GENERIC_DRUG_GRID";
	public final static String GRIDSEADRUGCD_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_GRID_genericDrugCode";
	public final static String GRIDSEADRUGNM_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_GRID_drugName";
	public final static String GRIDSEATHERCHIER_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_GRID_therapeuticHierarchy";

	public final static String ADDTOSELECTBUTTON_ID = "ADD_TO_SELECTED";

	// --------Selected Generic Drugs(popup)---------------
	public final static String GRIDSELECT_ID = "GENERIC_DRUG_GRID";
	public final static String GRIDSELECT_DRUGCODE_ARIA_DESCRIBEDBY = "SELECTED_GENERIC_DRUG_GRID_genericDrugCode";
	public final static String GRIDSELECT_DRUGNAME_ARIA_DESCRIBEDBY = "SELECTED_GENERIC_DRUG_GRID_drugName";
	public final static String GRIDSELECTRCHIER_ARIA_DESCRIBEDBY = "SELECTED_GENERIC_DRUG_GRID_therapeuticHierarchy";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
		
	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButton;
	
	@FindBy(xpath = POPUPDIV_XPATH)
	private WebElement popupDiv;
	
	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;
	
	@FindBy(css = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(css = GRIDSEARCH_ID)
	private WebElement gridSearch;
	
	@FindBy(css = GRIDSELECT_ID)
	private WebElement gridSelect;

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the popupDiv
	 */
	public WebElement getPopupDiv() {
		return popupDiv;
	}

	/**
	 * @return the quickSearchTxt
	 */
	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the gridSearch
	 */
	public WebElement getGridSearch() {
		return gridSearch;
	}

	/**
	 * @return the gridSelect
	 */
	public WebElement getGridSelect() {
		return gridSelect;
	}
	
}
