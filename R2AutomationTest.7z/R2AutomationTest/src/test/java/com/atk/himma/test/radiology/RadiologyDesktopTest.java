package com.atk.himma.test.radiology;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.radiology.RadiologyDesktop;
import com.atk.himma.setup.SeleniumDriverSetup;

public class RadiologyDesktopTest extends SeleniumDriverSetup{
	
	List<String[]> radDatas;
	RadiologyDesktop radiologyDesktop;

	@Test(description = "Open Radiology Desktop Page")
	public void openRadDesktopPage() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("RADExcel"));
		radiologyDesktop = PageFactory.initElements(webDriver,
				RadiologyDesktop.class);
		radiologyDesktop = radiologyDesktop.clickOnRadDesktopMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(radiologyDesktop);
		radiologyDesktop.waitForElementId(RadiologyDesktop.QUECKSEARCHTXT_ID);
//		generalRegistrationPage.sleepShort();
//		Assert.assertEquals(generalRegistrationPage.getPageTitle().getText(),
//				"General Registration");
	}
}
