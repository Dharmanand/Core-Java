package com.atk.himma.pageobjects.sa.admin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RegionalSettingsInformationTab extends DriverWaitClass {
	public final static String EDITDEFSETTINGS = "DEF_SETTINGS";
	public final static String REGSETTINGSINFOFORM_ID = "regionalSettingsInfo";
	public final static String SAVEBTN_XPATH = "//input[@value='Save']";
	public final static String CANCELBTN_XPATH = "//input[@value='Cancel']";
	public final static String BUSINESSUNITNAME_ID = "regionalSettingsInfo_allBusinessUnit";
	public final static String SUPPORTINGLANG_NAME = "regionalSettings.langCode";
	public final static String DATEFORMAT_NAME = "regionalSettings.dateFormat";
	public final static String TIMEFORMAT_NAME = "regionalSettings.timeFormat";
	public final static String CURRENCYSETTING_NAME = "regionalSettings.currency";
	public final static String PERSONNAMEFORMAT_NAME = "regionalSettings.nameFormat";
	public final static String ADDRESSFORMAT_NAME = "regionalSettings.addressFormat";
	public final static String BUSINESSSTARTDAY_NAME = "regionalSettings.businessStartDay";
	public final static String BUSINESSENDDAY_NAME = "regionalSettings.businessEndDay";

	@FindBy(id = EDITDEFSETTINGS)
	private WebElement editDefaultSettings;

	@FindBy(id = REGSETTINGSINFOFORM_ID)
	private WebElement regSettingsInfoForm;

	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	@FindBy(id = BUSINESSUNITNAME_ID)
	private WebElement businessUnitName;

	@FindBy(name = SUPPORTINGLANG_NAME)
	private WebElement supportingLang;

	@FindBy(name = DATEFORMAT_NAME)
	private WebElement dateFormat;

	@FindBy(name = TIMEFORMAT_NAME)
	private WebElement timeFormat;

	@FindBy(name = CURRENCYSETTING_NAME)
	private WebElement currencySetting;

	@FindBy(name = PERSONNAMEFORMAT_NAME)
	private WebElement personNameFormat;

	@FindBy(name = ADDRESSFORMAT_NAME)
	private WebElement addressFormat;

	@FindBy(name = BUSINESSSTARTDAY_NAME)
	private WebElement businessStartDay;

	@FindBy(name = BUSINESSENDDAY_NAME)
	private WebElement businessEndDay;

	public WebElement getEditDefaultSettings() {
		return editDefaultSettings;
	}

	public WebElement getRegSettingsInfoForm() {
		return regSettingsInfoForm;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getBusinessUnitName() {
		return businessUnitName;
	}

	public WebElement getSupportingLang() {
		return supportingLang;
	}

	public WebElement getDateFormat() {
		return dateFormat;
	}

	public WebElement getTimeFormat() {
		return timeFormat;
	}

	public WebElement getCurrencySetting() {
		return currencySetting;
	}

	public WebElement getPersonNameFormat() {
		return personNameFormat;
	}

	public WebElement getAddressFormat() {
		return addressFormat;
	}

	public WebElement getBusinessStartDay() {
		return businessStartDay;
	}

	public WebElement getBusinessEndDay() {
		return businessEndDay;
	}

}
