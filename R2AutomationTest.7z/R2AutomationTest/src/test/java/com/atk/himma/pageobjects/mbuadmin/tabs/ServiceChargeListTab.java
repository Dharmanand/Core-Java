package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ServiceChargeListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "CHARGES_LIST_FORM";
	public final static String SERVICECHARGELIST_XPATH = "//a[@title='Charges List']";
	public final static String ADDNEWPRICELISTBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Add New Price List']";
	public final static String MBU_ID = "CHARGE_MBU";
	public final static String DEPARTMENT_ID = "SERVICE_DEPARTMENT";
	public final static String SERSUBSPECIALITY_ID = "SERVICE_SUB_SPECIALITY";
	public final static String SERVICETYPE_ID = "SERVICE_TYPE";
	public final static String SERVICENAME_ID = "SERVICE_NAME";
	public final static String SEARCHGLOBALSERVICE_ID = "SEARCH_GLOBAL_SERVICE";
	public final static String SERVICESPECIALITY_ID = "SERVICE_SPECIALITY";
	public final static String VISITCATEGORY_ID = "VISIT_CATEGORY";
	public final static String SERVICECODE_ID = "SERVICE_CODE";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "CHARGE_LIST_GRID";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCode";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceName";
	public final static String GRID_BASEPRICE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.basePrice";
	public final static String GRID_SELLINGPRICE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.stdChargeDetails.sellingPrice";
	public final static String GRID_DEPOSIT_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.stdChargeDetails.deposit";
	public final static String GRID_SECURITYDEPOSIT_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.stdChargeDetails.securityDeposit";
	public final static String GRID_DIFFFOREXTPATIENT_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.diffForExtPatient";
	public final static String GRID_EXTERNALPATIENTPRICE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.externalPatientPrice";
	public final static String GRID_NEGOTIABLE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.stdChargeDetails.negotiable";
	public final static String GRID_MINPRICE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.stdChargeDetails.minPrice";
	public final static String GRID_MAXPRICE_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_serviceCharge.stdChargeDetails.maxPrice";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "CHARGE_LIST_GRID_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_CHARGE_LIST_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_CHARGE_LIST_GRID_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = SERVICECHARGELIST_XPATH)
	private WebElement serCharListTab;
	
	@FindBy(xpath = ADDNEWPRICELISTBUTTON_XPATH)
	private WebElement addNewPLButton;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SERSUBSPECIALITY_ID)
	private WebElement serSubSpeciality;
	
	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;
	
	@FindBy(id = SERVICENAME_ID)
	private WebElement serviceName;
	
	@FindBy(id = SEARCHGLOBALSERVICE_ID)
	private WebElement searchGlobalService;
	
	@FindBy(id = SERVICESPECIALITY_ID)
	private WebElement serviceSpeciality;
	
	@FindBy(id = VISITCATEGORY_ID)
	private WebElement visitCategory;
	
	@FindBy(id = SERVICECODE_ID)
	private WebElement serviceCode;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the addNewPLButton
	 */
	public WebElement getAddNewPLButton() {
		return addNewPLButton;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the serSubSpeciality
	 */
	public WebElement getSerSubSpeciality() {
		return serSubSpeciality;
	}

	/**
	 * @return the serviceType
	 */
	public WebElement getServiceType() {
		return serviceType;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the searchGlobalService
	 */
	public WebElement getSearchGlobalService() {
		return searchGlobalService;
	}

	/**
	 * @return the serviceSpeciality
	 */
	public WebElement getServiceSpeciality() {
		return serviceSpeciality;
	}

	/**
	 * @return the visitCategory
	 */
	public WebElement getVisitCategory() {
		return visitCategory;
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	/**
	 * @return the serCharListTab
	 */
	public WebElement getSerCharListTab() {
		return serCharListTab;
	}
}
