package com.atk.himma.pageobjects.mrd;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mrd.tabs.LengthOfStayDetailsTab;
import com.atk.himma.pageobjects.mrd.tabs.MBUListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class MRLengthOfStayPage extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {
	
	private MBUListTab mbuListTab;
	private LengthOfStayDetailsTab lengthOfStayDetailsTab;
 	
	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		mbuListTab = PageFactory.initElements(webDriver,
				MBUListTab.class);
		mbuListTab.setWebDriver(webDriver);
		mbuListTab.setWebDriverWait(webDriverWait);

		lengthOfStayDetailsTab = PageFactory.initElements(webDriver,
				LengthOfStayDetailsTab.class);
		lengthOfStayDetailsTab.setWebDriver(webDriver);
		lengthOfStayDetailsTab.setWebDriverWait(webDriverWait);
	}

	public MRLengthOfStayPage clickOnMRLengthOfStayMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MRD");
		menuSelector.clickOnTargetMenu(menuList, "MR Length of Stay");
		MRLengthOfStayPage mrLengthOfStayPage = PageFactory.initElements(
				webDriver, MRLengthOfStayPage.class);
		mrLengthOfStayPage.setWebDriver(webDriver);
		mrLengthOfStayPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return mrLengthOfStayPage;
	}

	public boolean reset(String mbuName) throws InterruptedException
	{
		searchMBU(mbuName);
		return checkGridEmpty(MBUListTab.GRID_ID, MBUListTab.GRID_PAGERID);
	}
	
	public String searchMBU(String mbuName) throws InterruptedException
	{
		waitForElementId(MBUListTab.MBUNAME_ID);
		sleepVeryShort();
		mbuListTab.getMbuName().clear();
		mbuListTab.getMbuName().sendKeys(mbuName);
		mbuListTab.getSearchButton().click();
		return waitAndGetGridFirstCellText(MBUListTab.GRID_ID, MBUListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY, mbuName);
	}
	
	public boolean clickOnEditLink(String mbuName) throws InterruptedException
	{
		clickOnGridAction(mbuName, "Edit");
		waitForElementClassName(LengthOfStayDetailsTab.MBUNAME_CLASS);
		return lengthOfStayDetailsTab.getMbuName().getAttribute("Value").trim().equals(mbuName.trim());
	}
}
