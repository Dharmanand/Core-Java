package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class OtherDetailsSection extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Other Details";
	
	@FindBy(linkText=SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	private final static String SPONSORNAME_ID = "sponsorName";
	
	@FindBy(id=SPONSORNAME_ID)
	private WebElement sponsorName;
	
	private final static String PHONECODE_NAME = "otherDetails.sponsorPhone.countryCode";
	
	@FindBy(name=PHONECODE_NAME)
	private WebElement phoneCode;
	
	private final static String PHONENUMBER_ID = "sponsorPhone";
	
	@FindBy(id=PHONENUMBER_ID)
	private WebElement phoneNumber;
	
	private final static String ADDRESS_ID = "sponsorAddress";
	
	@FindBy(id=ADDRESS_ID)
	private WebElement address;

	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Other Details')]/..";
	
	@FindBy(xpath=SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	public void fillDatasOfOtherlDetailsSection(String[] excelData, WebDriverWait webDriverWait) throws InterruptedException
	{
//		getSectionName().click();
//		sleepVeryShort();
		if(!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute("class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getSponsorName()));
		getSponsorName().clear();
		getSponsorName().sendKeys(excelData[88].trim());
		getAddress().clear();
		getAddress().sendKeys(excelData[89].trim());
		new Select(getPhoneCode()).selectByVisibleText(excelData[90].trim());
		getPhoneNumber().clear();
		getPhoneNumber().sendKeys(excelData[91].trim());
	}
	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sponsorName
	 */
	public WebElement getSponsorName() {
		return sponsorName;
	}

	/**
	 * @return the phoneCode
	 */
	public WebElement getPhoneCode() {
		return phoneCode;
	}

	/**
	 * @return the phoneNumber
	 */
	public WebElement getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @return the address
	 */
	public WebElement getAddress() {
		return address;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the sponsornameId
	 */
	public static String getSponsornameId() {
		return SPONSORNAME_ID;
	}

	/**
	 * @return the phonecodeName
	 */
	public static String getPhonecodeName() {
		return PHONECODE_NAME;
	}

	/**
	 * @return the phonenumberId
	 */
	public static String getPhonenumberId() {
		return PHONENUMBER_ID;
	}

	/**
	 * @return the addressId
	 */
	public static String getAddressId() {
		return ADDRESS_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
