package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ItemListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "ITEM_LIST_PAGE";
	public final static String ITEMLISTTAB_XPATH = "//a[@title='Item List']";
	public final static String ADDNEWITEMBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Add New Item']";
	public final static String MBUNAME_ID = "MBU_ID_SEARCH";
	public final static String ITEMCATEGORY_ID = "ITEM_CATEGORY";
	public final static String ITEMSUBCATEGORY_ID = "ITEM_SUB_CATEGORY";
	public final static String ITEMNAME_ID = "ITEM_NAME";
	public final static String ITEMCODE_NAME = "searchCriteria.itemCode";
	public final static String ITEMREFERENCECODE_ID = "ITEM_REF_CODE";
	public final static String SHOWGLOBALITEM_ID = "SEARCH_GLOBAL_ITEM";
	public final static String ITEMTYPE_ID = "ITEM_TYPE";
	public final static String STATUS_ID = "ITEM_STATUS";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "SEARCH_ITEM_LIST_NEW";
	public final static String GRID_ITEMCODE_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_itemCode";
	public final static String GRID_ITEMNAME_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_itemName";
	public final static String GRID_SPECIALTY_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_itemReferenceCode";
	public final static String GRID_REFCODE_ARIA_DESCRIBEDBY = "clinicResults_departmentText";
	public final static String GRID_SUBCATEGORY_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_itemSubCategoryText";
	public final static String GRID_CATEGORY_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_itemCategoryText";
	public final static String GRID_ITEMTYPE_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_itemTypeText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "SEARCH_ITEM_LIST_NEW_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_SEARCH_ITEM_LIST_NEW_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_ITEM_LIST_NEW_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = ITEMLISTTAB_XPATH)
	private WebElement itemListTab;
	
	@FindBy(xpath = ADDNEWITEMBUTTON_XPATH)
	private WebElement addNewItemButton;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;
	
	@FindBy(id = ITEMCATEGORY_ID)
	private WebElement itemCategory;
	
	@FindBy(id = ITEMSUBCATEGORY_ID)
	private WebElement itemSubCategory;
	
	@FindBy(id = ITEMNAME_ID)
	private WebElement itemName;
	
	@FindBy(name = ITEMCODE_NAME)
	private WebElement itemCode;
	
	@FindBy(id = ITEMREFERENCECODE_ID)
	private WebElement itemReferenceCode;
	
	@FindBy(id = SHOWGLOBALITEM_ID)
	private WebElement showGlobalItem;
	
	@FindBy(id = ITEMTYPE_ID)
	private WebElement itemType;
	
	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	// pager
	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the itemListTab
	 */
	public WebElement getItemListTab() {
		return itemListTab;
	}

	/**
	 * @return the addNewItemButton
	 */
	public WebElement getAddNewItemButton() {
		return addNewItemButton;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the itemCategory
	 */
	public WebElement getItemCategory() {
		return itemCategory;
	}

	/**
	 * @return the itemSubCategory
	 */
	public WebElement getItemSubCategory() {
		return itemSubCategory;
	}

	/**
	 * @return the itemName
	 */
	public WebElement getItemName() {
		return itemName;
	}

	/**
	 * @return the itemCode
	 */
	public WebElement getItemCode() {
		return itemCode;
	}

	/**
	 * @return the itemReferenceCode
	 */
	public WebElement getItemReferenceCode() {
		return itemReferenceCode;
	}

	/**
	 * @return the showGlobalItem
	 */
	public WebElement getShowGlobalItem() {
		return showGlobalItem;
	}

	/**
	 * @return the itemType
	 */
	public WebElement getItemType() {
		return itemType;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

}
