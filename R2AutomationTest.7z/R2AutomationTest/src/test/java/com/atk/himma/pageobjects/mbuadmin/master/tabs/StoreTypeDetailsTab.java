package com.atk.himma.pageobjects.mbuadmin.master.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class StoreTypeDetailsTab extends DriverWaitClass {

	public final static String FORM_ID = "STORE_TYPE_FORM";
	public final static String MBUCODE_NAME = "mainBusinessUnit.unitCode";
	public final static String MBUNAME_NAME = "mainBusinessUnit.unitName";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String ADDRECORDGRIDBUTTON_XPATH = "//div[@class='ui-pg-div']//span[@class='ui-icon ui-icon-plus']";
	public final static String POPUPFORM_ID = "POPUP_DETAILS";
	public final static String POPUPTITLE_ID = "ui-dialog-title-openStoreTypeDialog";
	public final static String STORETYPE_ID = "STORE_TYPE";
	public final static String ITEMCATEGORIES_NAME = "multiselect_OM_ITEM_CATEGORY";
	public final static String SUBMITBUTTON_ID = "SUBMIT_BUTTON";
	public final static String CANCELBUTTON_ID = "CANCEL_BUTTON";
	public final static String UPDATEBUTTON_ID = "UPDATE_BUTTON";
	public final static String GRID_ID = "GET_STORE_TYPE_INFO"; 
	public final static String GRID_STORETYPE_ARIA_DESCRIBEDBY = "GET_STORE_TYPE_INFO_baseLV.longDesc";
	public final static String GRID_AVILITEMCATEGORY_ARIA_DESCRIBEDBY = "GET_STORE_TYPE_INFO_";

	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = POPUPTITLE_ID)
	private WebElement popUpTitle;

	@FindBy(name = MBUCODE_NAME)
	private WebElement mbuCode;

	@FindBy(name = MBUNAME_NAME)
	private WebElement mbuName;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(id = UPDATEBUTTON_ID)
	private WebElement updateButtonPopup;

	// ---------------------------------------------- Grid Start
	// -----------------------------------------

	@FindBy(xpath = ADDRECORDGRIDBUTTON_XPATH)
	private WebElement addRecordGridButton;

	@FindBy(id = POPUPFORM_ID)
	private WebElement popUpForm;

	@FindBy(id = STORETYPE_ID)
	private WebElement storeType;
	
	public void clickOnItemCategory(String itemCategory) {
		String visitTypeXpath = "//input[contains(@title, normalize-space('"
			+ itemCategory.trim() + "')) and @name='" + ITEMCATEGORIES_NAME + "']";
//		String visitTypeXpath = "//input[@title='" + itemCategory.trim()
//				+ "' and @name='" + ITEMCATEGORIES_NAME + "']";
		waitForElementXpathExpression(visitTypeXpath);
		if(!webDriver.findElement(By.xpath(visitTypeXpath)).isSelected())
		webDriver.findElement(By.xpath(visitTypeXpath)).click();
	}
	public void unSelectItemCategory(WebElement itemCategory) {
		if(itemCategory.isSelected())
			itemCategory.click();
	}

	@FindBy(id = SUBMITBUTTON_ID)
	private WebElement submitButtonPopup;

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButtonPopup;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the updateButtonPopup
	 */
	public WebElement getUpdateButtonPopup() {
		return updateButtonPopup;
	}

	/**
	 * @return the addRecordGridButton
	 */
	public WebElement getAddRecordGridButton() {
		return addRecordGridButton;
	}

	/**
	 * @return the storeType
	 */
	public WebElement getStoreType() {
		return storeType;
	}

	/**
	 * @return the submitButtonPopup
	 */
	public WebElement getSubmitButtonPopup() {
		return submitButtonPopup;
	}

	/**
	 * @return the cancelButtonPopup
	 */
	public WebElement getCancelButtonPopup() {
		return cancelButtonPopup;
	}

	/**
	 * @return the popUpForm
	 */
	public WebElement getPopUpForm() {
		return popUpForm;
	}

	/**
	 * @return the popUpTitle
	 */
	public WebElement getPopUpTitle() {
		return popUpTitle;
	}

}
