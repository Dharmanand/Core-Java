package com.atk.himma.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class DateTimeConverter {

	private static Date today = new Date();

	public static void main(String[] args) {
		/*
		 * // displaying this date on IST timezone DateFormat df = new
		 * SimpleDateFormat("dd-MM-yyyy HH:mm:SS z");
		 * df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); String IST =
		 * df.format(today);
		 * System.out.println("Date in Indian Timezone (IST) : " + IST);
		 * System.out.println("Date in Indian Timezone (IST)--> : " +
		 * currentISTDateFormat());
		 * 
		 * // dispalying date on PST timezone
		 * df.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles")); String
		 * PST = df.format(today); System.out.println("Date in PST Timezone : "
		 * + PST);
		 */

		/*System.out.println("First Date: " + getResCalDatesRange("").get(0)
				+ ", Second Date: " + getResCalDatesRange("").get(1));*/
		System.out.println("---------->>>>> "+yesturdayISTDateFormat());
	}

	public static String currentISTDateFormat() {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		String IST = df.format(today);
		return IST;
	}

	public static String tomorrowISTDateFormat() {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		calendar.add(Calendar.DATE, 1);
		date = calendar.getTime();
		return formatter.format(date);
	}
	public static String yesturdayISTDateFormat() {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		formatter.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
		calendar.add(Calendar.DATE, -1);
		date = calendar.getTime();
		return formatter.format(date);
	}

	public static boolean checkAfterDate(String givenDate, String compareWrtDate)
			throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date gDate = df.parse(givenDate);
		Date cWrtDate = df.parse(compareWrtDate);
		if (gDate.equals(cWrtDate) || (gDate.after(cWrtDate))) {
			System.out.println("After Date");
			return true;
		} else {
			System.out.println("Not After Date");
			return false;
		}
	}

	public static boolean checkBeforeDate(String givenDate,
			String compareWrtDate) throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date gDate = df.parse(givenDate);
		Date cWrtDate = df.parse(compareWrtDate);
		if (gDate.equals(cWrtDate) || (gDate.before(cWrtDate))) {
			System.out.println("Before Date");
			return true;
		} else {
			System.out.println("Not Before Date");
			return false;
		}
	}

	public static String[] datesOfAppointments(String displayTimeDates) {
		String[] sessionParts = displayTimeDates.split("-");
		String[] dates = new String[sessionParts.length];
		for (int i = 0; i < sessionParts.length; i++) {
			dates[i] = sessionParts[i].split("\\)")[1].trim();
		}
		return dates;
	}

	public static String[] datesOfAppointDairy(String displayTimeDates) {
		return displayTimeDates.split(" To ");
	}

	/**
	 * @author kumar
	 * @param givenDate
	 *            : Format is 'DD/MM/YYYY'
	 * @return String : Date Format is 'DD Mon YYYY'
	 */
	public static String getDateForAppointDairy(String givenDate) {
		String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
				"Aug", "Sep", "Oct", "Nov", "Dec" }, dateSplit = givenDate
				.split("\\/");
		return dateSplit[0].trim() + " "
				+ months[Integer.valueOf(dateSplit[1].trim()) - 1] + " "
				+ dateSplit[2].trim();
	}

	public static List<String> getResCalDatesRange(
			String displayDatesRangeInGrid) {
		List<String> dates = new ArrayList<String>();
		String[] strs = "(Fri)07/03/2014 - (Mon)17/03/2014".split("\\)");
		dates.add(strs[1].split(" -")[0].trim());
		dates.add(strs[2].trim());
		return dates;
	}

	public static boolean currentDateBetweenDates(String fromDate, String toDate)
			throws ParseException {
		return checkAfterDate(currentISTDateFormat(), fromDate)
				&& checkBeforeDate(currentISTDateFormat(), toDate);
	}

	public static int noOfSlotsPerSession(String availableSession,
			String slotInterval) {
		List<String> dates = new ArrayList<String>();
		String[] str = "Morning  ( 08:00 AM - 01:00 PM )".split("\\(");
		dates.add(str[1].split(" -")[0].trim());
		dates.add(str[1].split(" -")[1].split("\\)")[0].trim());
		return 0;
	}

	public static long noOfSlots(String fromTime, String toTime,
			long slotTimeInterval) throws ParseException {
		// String fromTime = "09:00 AM";
		// String toTime = "11:10 PM";
		SimpleDateFormat format = new SimpleDateFormat("HH:mm");
		Date frmTM = format.parse(fromTime.trim().split(" ")[0]);
		Date midTM = null;
		Date toTM = format.parse(toTime.trim().split(" ")[0]);
		long diffFrmTMWrtMidTM = 0, diffToTMWrtMidTM = 0;
		try {
			midTM = format.parse("12:00");
			diffFrmTMWrtMidTM = (midTM.getTime() - frmTM.getTime());
			diffToTMWrtMidTM = (midTM.getTime() - toTM.getTime());
			if (!fromTime.trim().split(" ")[1]
					.equals(toTime.trim().split(" ")[1])) {
				return (diffFrmTMWrtMidTM / (1000 * 60) - diffToTMWrtMidTM
						/ (1000 * 60) + 720)
						/ (slotTimeInterval);
			} else {
				if ((diffFrmTMWrtMidTM - diffToTMWrtMidTM) < 0) {
					System.out
							.println("Please enter correct session Time (From Date and To Date).");
					return 0;
				} else
					return (diffFrmTMWrtMidTM - diffToTMWrtMidTM) / (1000 * 60)
							/ (slotTimeInterval);
			}
		} catch (Exception e) {
			midTM = format.parse("24:00");
			diffFrmTMWrtMidTM = (midTM.getTime() - frmTM.getTime());
			diffToTMWrtMidTM = (midTM.getTime() - toTM.getTime());
			if ((diffFrmTMWrtMidTM - diffToTMWrtMidTM) < 0) {
				System.out
						.println("Please enter correct session Time (From Date and To Date).");
				return 0;
			} else
				return (diffFrmTMWrtMidTM - diffToTMWrtMidTM) / (1000 * 60)
						/ (slotTimeInterval);
		}
	}
}
