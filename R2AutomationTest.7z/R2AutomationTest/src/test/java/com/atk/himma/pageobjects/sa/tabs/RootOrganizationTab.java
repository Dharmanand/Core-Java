package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class RootOrganizationTab extends DriverWaitClass {
	public final static String ROOTORGFORM_ID = "ORGANIZATION_UNIT_FORM";
	public final static String EDITBTN_ID = "Edit_Id";
	public final static String UPDATEBTN_ID = "//input[@value='Update']";
	public final static String RESETBTN_ID = "//input[@value='Reset']";
	public final static String UNITNAME_NAME = "organizationUnit.unitName";
	public final static String UPDATEDUNITNAME_NAME = "organizationUnit.unitName1";
	public final static String UNITNAMEAR_NAME = "organizationUnit.unitNameNL";
	public final static String UNITSHORTNAME_ID = "ROOT_SHORT_NAME";
	public final static String UNITCODE_NAME = "organizationUnit.unitCode";
	public final static String MBU_NAME = "organizationUnit.mainBusinessUnit";
	public final static String CHECKED_XPATH = "//input[@checked='checked']";
	public final static String ORGHIERARCHYTAB_XPATH = "//li[@id='tab2']/a/span";
	public final static String ASSIGNORGHIERARCHYCONSTRAINTSBTN_ID = "orgHierarchyConstraints";
	public final static String CONSTRAINTSPOPUP_ID = "SAVE_ORG_HIERARCHY";
	public final static String SAVEBTN_ID = "BTN_SAVE";
	public final static String CANCELBTN_NAME = "cancel";
	public final static String SELECTEDORGUNIT_ID = "org_unit_id";
	public final static String SRC_ID = "src";
	public final static String DEST_ID = "dest";
	public final static String SRCTODEST_ID = "srctodest";
	public final static String DESTTOSRC_ID = "desttosrc";
	public final static String CONSTRAINTSGRID_ID = "orgHierarchyGrid";
	public final static String CLOSE_XPATH = "//span[@class='ui-icon ui-icon-closethick']";
	public final static String CONFIRMATIONMESSAGE_ID = "ConfirmationMessage";
	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";

	@FindBy(id = ROOTORGFORM_ID)
	private WebElement rootOrgForm;

	@FindBy(id = EDITBTN_ID)
	private WebElement editBtn;

	@FindBy(xpath = UPDATEBTN_ID)
	private WebElement updateBtn;

	@FindBy(xpath = RESETBTN_ID)
	private WebElement resetBtn;

	@FindBy(name = UNITNAME_NAME)
	private WebElement unitName;

	@FindBy(name = UPDATEDUNITNAME_NAME)
	private WebElement updatedUnitName;

	@FindBy(name = UNITNAMEAR_NAME)
	private WebElement unitNameAr;

	@FindBy(id = UNITSHORTNAME_ID)
	private WebElement unitShortName;

	@FindBy(name = UNITCODE_NAME)
	private WebElement unitCode;

	@FindBy(name = MBU_NAME)
	private WebElement mbu;

	@FindBy(xpath = CHECKED_XPATH)
	private WebElement checked;

	@FindBy(xpath = ORGHIERARCHYTAB_XPATH)
	private WebElement orgHierarchyTab;

	@FindBy(id = ASSIGNORGHIERARCHYCONSTRAINTSBTN_ID)
	private WebElement assignOrgHierarchyConstraintsBtn;

	@FindBy(id = CONSTRAINTSPOPUP_ID)
	private WebElement constraintsPopup;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(name = CANCELBTN_NAME)
	private WebElement cancelBtn;

	@FindBy(id = SELECTEDORGUNIT_ID)
	private WebElement selectedOrgUnit;

	@FindBy(id = SRC_ID)
	private WebElement src;

	@FindBy(id = DEST_ID)
	private WebElement dest;

	@FindBy(id = SRCTODEST_ID)
	private WebElement srctodest;

	@FindBy(id = DESTTOSRC_ID)
	private WebElement desttosrc;

	@FindBy(id = CONSTRAINTSGRID_ID)
	private WebElement constraintsGrid;

	@FindBy(xpath = CLOSE_XPATH)
	private WebElement close;

	@FindBy(id = CONFIRMATIONMESSAGE_ID)
	private WebElement confirmationMessage;

	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public void editRootName(String[] data) throws Exception {
		editBtn.click();
		sleepVeryShort();
		waitForElementName(UNITNAME_NAME);
		unitName.clear();
		unitName.sendKeys(data[0].trim());
		sleepVeryShort();
		unitNameAr.clear();
		unitNameAr.sendKeys(data[1].trim());
		unitShortName.clear();
		unitShortName.sendKeys(data[2].trim());
		if (!data[3].trim().isEmpty()) {
			unitCode.clear();
			unitCode.sendKeys(data[3].trim());
		}
		boolean isMBU = Boolean.valueOf(data[4].trim());
		if (isMBU) {
			mbu.click();
		}
		updateBtn.click();
		waitForElementId(EDITBTN_ID);
	}

	public void markAsMbu() throws Exception {
		editBtn.click();
		sleepVeryShort();
		mbu.click();
		updateBtn.click();
		sleepShort();
	}

	public void clickOnAssignConstraints() throws Exception {
		assignOrgHierarchyConstraintsBtn.click();
		sleepVeryShort();
	}

	public void assignConstraints(String[] orgUnits) throws Exception {

		new Select(selectedOrgUnit).selectByVisibleText(orgUnits[0]);
		String delimiter = "\\,";
		String[] childOrgUnitArray = orgUnits[1].split(delimiter);
		for (String childOrgUnit : childOrgUnitArray) {
			waitForElementId(SRC_ID);
			new Select(src).selectByVisibleText(childOrgUnit.trim());
			srctodest.click();
		}
		saveBtn.click();
		sleepShort();
	}

	public void editConstraints(String[] orgUnits) throws Exception {
		clickOnGridAction("HIERARCHY_GRID_parentOrgUnitText", orgUnits[0],
				"Edit");
		String delimiter = "\\,";
		String[] childOrgUnitArray = orgUnits[1].split(delimiter);
		for (String childOrgUnit : childOrgUnitArray) {
			waitForElementId(SRC_ID);
			new Select(src).selectByVisibleText(childOrgUnit.trim());
			srctodest.click();
		}
		saveBtn.click();
		sleepShort();
	}

	public void deleteConstraints(String[] orgUnits) throws Exception {
		clickOnGridAction("HIERARCHY_GRID_parentOrgUnitText", orgUnits[0],
				"Delete");
		waitForElementId(CONFIRMATIONMESSAGE_ID);
		confirmYes.click();
		sleepVeryShort();
	}

	public void closeConstraints() throws Exception {
		close.click();
		sleepShort();
	}

	public void navigateToOrgHierarchyTab() throws Exception {
		orgHierarchyTab.click();
		sleepShort();
	}

	public boolean searchGridData(String parentOrgUnit, String childOrgUnits) {
		boolean result = false;
		try {
			waitForElementXpathExpression("//td[@aria-describedby='HIERARCHY_GRID_parentOrgUnitText' and @title='"
					+ parentOrgUnit.trim() + "']");
			sleepVeryShort();
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='HIERARCHY_GRID_parentOrgUnitText' and @title='"
									+ parentOrgUnit.trim() + "']"))
					.isDisplayed()
					&& webDriver.findElement(
							By.xpath("//td[contains(@title, '"
									+ childOrgUnits.trim() + "')]"))
							.isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

	public WebElement getRootOrgForm() {
		return rootOrgForm;
	}

	public WebElement getEditBtn() {
		return editBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getUnitName() {
		return unitName;
	}

	public WebElement getUpdatedUnitName() {
		return updatedUnitName;
	}

	public WebElement getUnitNameAr() {
		return unitNameAr;
	}

	public WebElement getUnitShortName() {
		return unitShortName;
	}

	public WebElement getUnitCode() {
		return unitCode;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getChecked() {
		return checked;
	}

	public WebElement getOrgHierarchyTab() {
		return orgHierarchyTab;
	}

	public WebElement getAssignOrgHierarchyConstraintsBtn() {
		return assignOrgHierarchyConstraintsBtn;
	}

	public WebElement getConstraintsPopup() {
		return constraintsPopup;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getSelectedOrgUnit() {
		return selectedOrgUnit;
	}

	public WebElement getSrc() {
		return src;
	}

	public WebElement getDest() {
		return dest;
	}

	public WebElement getSrctodest() {
		return srctodest;
	}

	public WebElement getDesttosrc() {
		return desttosrc;
	}

	public WebElement getConstraintsGrid() {
		return constraintsGrid;
	}

	public WebElement getClose() {
		return close;
	}

	public WebElement getConfirmationMessage() {
		return confirmationMessage;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

}
