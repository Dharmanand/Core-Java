package com.atk.himma.pageobjects.radiology.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class InstructionDetailsTab extends DriverWaitClass {

	public final static String FORM_ID = "instructionForm";
	public final static String INSTRUCODETXT_ID = "instrCodeId";
	public final static String INSTRUSHORTNAME_ID = "instrShortNameId";
	public final static String INSTRUCTIONTYPE_ID = "instrTypeId";
	public final static String INSTRUDESCR_ID = "instrDescId";
	public final static String INSTRUDESCRAR_ID = "instrDescArId";
	public final static String ADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[contains(@value,'Add New')]";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Save']";
	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Update']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Cancel']";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(id = INSTRUCODETXT_ID)
	private WebElement instruCodeTxt;

	@FindBy(id = INSTRUSHORTNAME_ID)
	private WebElement instruShortName;

	@FindBy(id = INSTRUCTIONTYPE_ID)
	private WebElement instructionType;

	@FindBy(id = INSTRUDESCR_ID)
	private WebElement instruDescr;

	@FindBy(id = INSTRUDESCRAR_ID)
	private WebElement instruDescrAr;

	@FindBy(xpath = ADDNEWBUTTON_XPATH)
	private WebElement addNewButton;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;
	
	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;
	
	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	public WebElement getForm() {
		return form;
	}

	public WebElement getInstruCodeTxt() {
		return instruCodeTxt;
	}

	public WebElement getInstruShortName() {
		return instruShortName;
	}

	public WebElement getInstructionType() {
		return instructionType;
	}

	public WebElement getInstruDescr() {
		return instruDescr;
	}

	public WebElement getInstruDescrAr() {
		return instruDescrAr;
	}

	public WebElement getAddNewButton() {
		return addNewButton;
	}

	public WebElement getSaveButton() {
		return saveButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}
	
	public WebElement getUpdateButton() {
		return updateButton;
	}
}
