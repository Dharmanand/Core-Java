package com.atk.himma.pageobjects.sa.masters.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class MainBusinessUnitListTab extends DriverWaitClass {
	public final static String MBULISTFORM_ID = "RESOURCE_CATEGORY_LIST";
	@FindBy(id = MBULISTFORM_ID)
	private WebElement mbuListForm;

	public final static String EDITROOTBTN_XPATH = "//input[@value='Edit Root']";
	@FindBy(xpath = EDITROOTBTN_XPATH)
	private WebElement editRootBtn;

	public final static String MBUNAME_ID = "mbuName";
	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;

	public final static String MBUCODE_ID = "mbuCode";
	@FindBy(id = MBUCODE_ID)
	private WebElement mbuCode;

	public final static String SEARCHBTN_XPATH = "//input[@value='Search']";
	@FindBy(xpath = SEARCHBTN_XPATH)
	private WebElement searchBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String MBULISTGRID_ID = "resourceCategoryResults";
	@FindBy(id = MBULISTGRID_ID)
	private WebElement mbuListGrid;

	public void clickOnEditRoot() throws Exception {
		editRootBtn.click();
		sleepShort();
	}

	public void searchMbuList(String mbu) throws Exception {
		mbuName.sendKeys(mbu);
		searchBtn.click();
		sleepShort();
		waitForElementId(MBULISTGRID_ID);
		webDriver
				.findElement(
						By.xpath("//td[@aria-describedby = 'resourceCategoryResults_mainBusinessUnit.unitName' and @title='"
								+ mbu
								+ "']/..//a[@title='Add Resource Category']"))
				.click();
		sleepShort();
	}

	public WebElement getMbuListForm() {
		return mbuListForm;
	}

	public WebElement getEditRootBtn() {
		return editRootBtn;
	}

	public WebElement getMbuName() {
		return mbuName;
	}

	public WebElement getMbuCode() {
		return mbuCode;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getMbuListGrid() {
		return mbuListGrid;
	}

}
