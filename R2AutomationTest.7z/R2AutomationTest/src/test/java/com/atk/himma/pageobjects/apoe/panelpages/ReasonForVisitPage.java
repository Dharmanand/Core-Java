package com.atk.himma.pageobjects.apoe.panelpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ReasonForVisitPage extends DriverWaitClass {
	public final static String NEWVISITTAB_XPATH = ".//a[@href='#NEW_VISIT_DIV']";
	@FindBy(xpath = NEWVISITTAB_XPATH)
	private WebElement newVisitTab;

	public final static String FOLLOWUPDETTAB_XPATH = ".//a[@href='#FOLLOW_UP_DET_DIV']";
	@FindBy(xpath = FOLLOWUPDETTAB_XPATH)
	private WebElement followUpDetailsTab;

	public final static String NEWVISITSAVEBTN_XPATH = ".//form[@id='CONSULTATION_NEW_VISIT_FORM']/..//input[@value='Save']";
	@FindBy(xpath = NEWVISITSAVEBTN_XPATH)
	private WebElement newVisitSaveBtn;

	public final static String NEWVISITUPDATEBTN_XPATH = ".//form[@id='CONSULTATION_NEW_VISIT_FORM']/..//input[@value='Update']";
	@FindBy(xpath = NEWVISITUPDATEBTN_XPATH)
	private WebElement newVisitUpdateBtn;

	public final static String NEWVISITCANCELBTN_XPATH = ".//form[@id='CONSULTATION_NEW_VISIT_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = NEWVISITCANCELBTN_XPATH)
	private WebElement newVisitCancelBtn;

	public final static String NEWCHIEFCOMPLAINT_NAME = "consultationSummary.newReason.cheifComplaints[0].complaintContent";
	@FindBy(name = NEWCHIEFCOMPLAINT_NAME)
	private WebElement newChiefComplaint;

	public final static String HPI_NAME = "consultationSummary.newReason.cheifComplaints[0].hpiContent";
	@FindBy(name = HPI_NAME)
	private WebElement historyOfPresentIllness;

	public final static String FOLLOWUPDTLSAVEBTN_XPATH = ".//form[@id='CONSULTATION_FOLLOW_UP_DETAILS_FORM']/..//input[@value='Save']";
	@FindBy(xpath = FOLLOWUPDTLSAVEBTN_XPATH)
	private WebElement followUpDetailsSaveBtn;

	public final static String FOLLOWUPDTLUPDATEBTN_XPATH = ".//form[@id='CONSULTATION_FOLLOW_UP_DETAILS_FORM']/..//input[@value='Update']";
	@FindBy(xpath = FOLLOWUPDTLUPDATEBTN_XPATH)
	private WebElement followUpDetailsUpdateBtn;

	public final static String FOLLOWUPDTLCANCELBTN_XPATH = ".//form[@id='CONSULTATION_FOLLOW_UP_DETAILS_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = FOLLOWUPDTLCANCELBTN_XPATH)
	private WebElement followUpDetailsCancelBtn;

	public final static String FOLLOWUPDTLS_XPATH = "html/body/p";
	@FindBy(xpath = FOLLOWUPDTLS_XPATH)
	private WebElement followUpDetails;

	public void fillNewVisitDefaultSec(String[] outPatientListData) {
		newChiefComplaint.clear();
		newChiefComplaint.sendKeys(outPatientListData[23]);

		historyOfPresentIllness.clear();
		historyOfPresentIllness.sendKeys(outPatientListData[24]);

	}

	public void saveNewVisitReason() throws Exception {
		newVisitSaveBtn.click();
		sleepVeryShort();
		waitForElementXpathExpression(NEWVISITUPDATEBTN_XPATH);
	}

	public void clickFollowupDetailsTab() throws Exception {
		followUpDetailsTab.click();
		sleepVeryShort();
		waitForElementXpathExpression(FOLLOWUPDTLSAVEBTN_XPATH);

	}

	public void fillFollowupDetails(String[] outPatientListData) {
		followUpDetails.clear();
		followUpDetails.sendKeys(outPatientListData[36]);

	}

	public void clickSaveFllowupDetails() throws Exception {
		followUpDetailsSaveBtn.click();
		sleepVeryShort();
		waitForElementXpathExpression(FOLLOWUPDTLUPDATEBTN_XPATH);
	}

	public WebElement getNewVisitTab() {
		return newVisitTab;
	}

	public WebElement getFollowUpDetailsTab() {
		return followUpDetailsTab;
	}

	public WebElement getNewVisitSaveBtn() {
		return newVisitSaveBtn;
	}

	public WebElement getNewVisitUpdateBtn() {
		return newVisitUpdateBtn;
	}

	public WebElement getNewVisitCancelBtn() {
		return newVisitCancelBtn;
	}

	public WebElement getNewChiefComplaint() {
		return newChiefComplaint;
	}

	public WebElement getHistoryOfPresentIllness() {
		return historyOfPresentIllness;
	}

	public WebElement getFollowUpDetailsSaveBtn() {
		return followUpDetailsSaveBtn;
	}

	public WebElement getFollowUpDetailsUpdateBtn() {
		return followUpDetailsUpdateBtn;
	}

	public WebElement getFollowUpDetailsCancelBtn() {
		return followUpDetailsCancelBtn;
	}

	public WebElement getFollowUpDetails() {
		return followUpDetails;
	}

}
