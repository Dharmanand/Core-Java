package com.atk.himma.pageobjects.contracts.sections.debtordetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ContactPersonDetailsSection extends DriverWaitClass {
	public static final String CONTACTPERSONDETAILSSEC_LINKTEXT = "Contact Person(s) Details";
	public final static String PERSONNAME_NAME = "debtor.contactDetails[0].personName";
	public final static String PRIMCONTACTCHKBOX_NAME = "debtor.contactDetails[0].primaryFlg";
	public final static String EMAILID_NAME = "debtor.contactDetails[0].email";
	public final static String DESIGNATION_NAME = "debtor.contactDetails[0].designation";
	public final static String WORKPH1CC_NAME = "debtor.contactDetails[0].workPh1Cd";
	public final static String WORKPH1NUM_NAME = "debtor.contactDetails[0].workPh1Num";
	public final static String WORKPH2CC_NAME = "debtor.contactDetails[0].workPh2Cd";
	public final static String WORKPH2NUM_NAME = "debtor.contactDetails[0].workPh2Num";
	public final static String MOBPHCC_NAME = "debtor.contactDetails[0].mobPhCd";
	public final static String MOBPHNUM_NAME = "debtor.contactDetails[0].mobPhNum";
	public final static String PAGERCC_NAME = "debtor.contactDetails[0].pagerPhCd";
	public final static String PAGERNUM_NAME = "debtor.contactDetails[0].pagerPhNum";

	@FindBy(name = CONTACTPERSONDETAILSSEC_LINKTEXT)
	private WebElement contactPersonDetailsSec;

	@FindBy(name = PERSONNAME_NAME)
	private WebElement personName;

	@FindBy(name = PRIMCONTACTCHKBOX_NAME)
	private WebElement primaryContact;

	@FindBy(name = EMAILID_NAME)
	private WebElement emailId;

	@FindBy(name = DESIGNATION_NAME)
	private WebElement designation;

	@FindBy(name = WORKPH1CC_NAME)
	private WebElement workPh1CC;

	@FindBy(name = WORKPH1NUM_NAME)
	private WebElement workPh1Number;

	@FindBy(name = WORKPH2CC_NAME)
	private WebElement workPh2CC;

	@FindBy(name = WORKPH2NUM_NAME)
	private WebElement workPh2Number;

	@FindBy(name = MOBPHCC_NAME)
	private WebElement mobPhCC;

	@FindBy(name = MOBPHNUM_NAME)
	private WebElement mobPhNumber;

	@FindBy(name = PAGERCC_NAME)
	private WebElement pagerCC;

	@FindBy(name = PAGERNUM_NAME)
	private WebElement pagerNumber;

	public boolean isMandPersonName() {
		waitForElementName(PERSONNAME_NAME);
		return isMandatoryField(personName);
	}

	public boolean isMandMobPh() {
		waitForElementName(MOBPHCC_NAME);
		waitForElementName(MOBPHNUM_NAME);
		return isMandatoryField(mobPhCC) && isMandatoryField(mobPhNumber);
	}

	public void fillContactPersonDetailsData(String[] debtorListData)
			throws Exception {
		waitForElementName(PERSONNAME_NAME);
		sleepVeryShort();
		personName.clear();
		personName.sendKeys(debtorListData[25]);

		if (Boolean.valueOf(debtorListData[26])) {
			primaryContact.click();
		}
		emailId.clear();
		emailId.sendKeys(debtorListData[27]);

		if (!debtorListData[28].isEmpty()) {
			new Select(designation).selectByVisibleText(debtorListData[28]);
		}

		if (!debtorListData[29].isEmpty()) {
			new Select(workPh1CC).selectByVisibleText(debtorListData[29]);
		}
		workPh1Number.clear();
		workPh1Number.sendKeys(debtorListData[30]);

		if (!debtorListData[31].isEmpty()) {
			new Select(workPh2CC).selectByVisibleText(debtorListData[31]);
		}
		workPh2Number.clear();
		workPh2Number.sendKeys(debtorListData[32]);

		if (!debtorListData[33].isEmpty()) {
			new Select(mobPhCC).selectByVisibleText(debtorListData[33]);
		}
		mobPhNumber.clear();
		mobPhNumber.sendKeys(debtorListData[34]);

		if (!debtorListData[35].isEmpty()) {
			new Select(pagerCC).selectByVisibleText(debtorListData[35]);
		}
		pagerNumber.clear();
		pagerNumber.sendKeys(debtorListData[36]);

	}

	public String getSelectedMobCC() {
		return new Select(mobPhCC).getFirstSelectedOption().getText();
	}

	public WebElement getContactPersonDetailsSec() {
		return contactPersonDetailsSec;
	}

	public WebElement getPersonName() {
		return personName;
	}

	public WebElement getPrimaryContact() {
		return primaryContact;
	}

	public WebElement getEmailId() {
		return emailId;
	}

	public WebElement getDesignation() {
		return designation;
	}

	public WebElement getWorkPh1CC() {
		return workPh1CC;
	}

	public WebElement getWorkPh1Number() {
		return workPh1Number;
	}

	public WebElement getWorkPh2CC() {
		return workPh2CC;
	}

	public WebElement getWorkPh2Number() {
		return workPh2Number;
	}

	public WebElement getMobPhCC() {
		return mobPhCC;
	}

	public WebElement getMobPhNumber() {
		return mobPhNumber;
	}

	public WebElement getPagerCC() {
		return pagerCC;
	}

	public WebElement getPagerNumber() {
		return pagerNumber;
	}

}
