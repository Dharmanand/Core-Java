package com.atk.himma.pageobjects.preg.admin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PatientMergeTab extends DriverWaitClass{
	
	private final static String MERGEPATIENTTAB_XPATH = "//a[@title='Patient Merge']";
	
	@FindBy(id = MERGEPATIENTTAB_XPATH)
	private WebElement mergePatientTab;
	
	private final static String SEARCHTEXT_ID = "searchTextName";

	@FindBy(id = SEARCHTEXT_ID)
	private WebElement searchText;
	
	private final static String SEARCHBUTTON_ID = "searchBtn";
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	private final static String GRIDTABLE_ID= "multiSelVal";
	
	@FindBy(id = GRIDTABLE_ID)
	private WebElement gridTable;
	
	public final static String MEARGEBUTTON_ID= "mergeMRRecords";
	
	@FindBy(id = MEARGEBUTTON_ID)
	private WebElement meargeButton;

	private final static String MULTISELVAL_SELECT__ARIADESCRIBEDBY= "multiSelVal_cb";
	private final static String MULTISELVAL_RETAIN_ARIADESCRIBEDBY= "multiSelVal_sretain";
	private final static String MULTISELVAL_MRN_ARIADESCRIBEDBY= "multiSelVal_smrNumber";
	private final static String MULTISELVAL_PATIENTNAME_ARIADESCRIBEDBY= "multiSelVal_sgivenName";
	private final static String MULTISELVAL_GENDER_ARIADESCRIBEDBY= "multiSelVal_sgender";
	private final static String MULTISELVAL_AGE_ARIADESCRIBEDBY= "multiSelVal_formattedAge";
	private final static String MULTISELVAL_DATEOFBIRTH_ARIADESCRIBEDBY= "multiSelVal_dtdob";
	private final static String MULTISELVAL_STATUS_ARIADESCRIBEDBY= "multiSelVal_recordStatusText";
	private final static String MULTISELVAL_IDENTIFICATIONNUMBER_ARIADESCRIBEDBY= "multiSelVal_sidentityNo";
	
	private final static String GRIDPAGER_ID= "sp_1_multiSelVal_pager";
	
	@FindBy(id = GRIDPAGER_ID)
	private WebElement gridPager;
	
	private final static String GRIDPAGERNEXT_XPATH= "//td[@id='next_multiSelVal_pager']/span";
	
	@FindBy(xpath = GRIDPAGERNEXT_XPATH)
	private WebElement gridPagerNext;
	
	private final static String USERCONFIRMATIONYESBUTTON_ID= "MergeRecord_Id";
	
	@FindBy(id = USERCONFIRMATIONYESBUTTON_ID)
	private WebElement userConfirmationYesButton;
	
	private final static String USERCONFIRMATIONNOBUTTON_ID= "NotMerged_Id";
	
	@FindBy(id = USERCONFIRMATIONNOBUTTON_ID)
	private WebElement userConfirmationNoButton;
	
	
	
	
	/**
	 * @return the mergepatienttabXpath
	 */
	public static String getMergepatienttabXpath() {
		return MERGEPATIENTTAB_XPATH;
	}

	/**
	 * @return the mergePatientTab
	 */
	public WebElement getMergePatientTab() {
		return mergePatientTab;
	}

	/**
	 * @return the searchtextId
	 */
	public static String getSearchtextId() {
		return SEARCHTEXT_ID;
	}

	/**
	 * @return the searchText
	 */
	public WebElement getSearchText() {
		return searchText;
	}

	/**
	 * @return the searchbuttonId
	 */
	public static String getSearchbuttonId() {
		return SEARCHBUTTON_ID;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the meargebuttonId
	 */
	public static String getMeargebuttonId() {
		return MEARGEBUTTON_ID;
	}

	/**
	 * @return the meargeButton
	 */
	public WebElement getMeargeButton() {
		return meargeButton;
	}

	/**
	 * @return the multiselvalSelectAriadescribedby
	 */
	public static String getMultiselvalSelectAriadescribedby() {
		return MULTISELVAL_SELECT__ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalRetainAriadescribedby
	 */
	public static String getMultiselvalRetainAriadescribedby() {
		return MULTISELVAL_RETAIN_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalMrnAriadescribedby
	 */
	public static String getMultiselvalMrnAriadescribedby() {
		return MULTISELVAL_MRN_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalPatientnameAriadescribedby
	 */
	public static String getMultiselvalPatientnameAriadescribedby() {
		return MULTISELVAL_PATIENTNAME_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalGenderAriadescribedby
	 */
	public static String getMultiselvalGenderAriadescribedby() {
		return MULTISELVAL_GENDER_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalAgeAriadescribedby
	 */
	public static String getMultiselvalAgeAriadescribedby() {
		return MULTISELVAL_AGE_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalDateofbirthAriadescribedby
	 */
	public static String getMultiselvalDateofbirthAriadescribedby() {
		return MULTISELVAL_DATEOFBIRTH_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalStatusAriadescribedby
	 */
	public static String getMultiselvalStatusAriadescribedby() {
		return MULTISELVAL_STATUS_ARIADESCRIBEDBY;
	}

	/**
	 * @return the multiselvalIdentificationnumberAriadescribedby
	 */
	public static String getMultiselvalIdentificationnumberAriadescribedby() {
		return MULTISELVAL_IDENTIFICATIONNUMBER_ARIADESCRIBEDBY;
	}

	/**
	 * @return the gridpagerId
	 */
	public static String getGridpagerId() {
		return GRIDPAGER_ID;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the gridpagernextXpath
	 */
	public static String getGridpagernextXpath() {
		return GRIDPAGERNEXT_XPATH;
	}

	/**
	 * @return the gridPagerNext
	 */
	public WebElement getGridPagerNext() {
		return gridPagerNext;
	}

	/**
	 * @return the userconfirmationyesbuttonId
	 */
	public static String getUserconfirmationyesbuttonId() {
		return USERCONFIRMATIONYESBUTTON_ID;
	}

	/**
	 * @return the userConfirmationYesButton
	 */
	public WebElement getUserConfirmationYesButton() {
		return userConfirmationYesButton;
	}

	/**
	 * @return the userconfirmationnobuttonId
	 */
	public static String getUserconfirmationnobuttonId() {
		return USERCONFIRMATIONNOBUTTON_ID;
	}

	/**
	 * @return the userConfirmationNoButton
	 */
	public WebElement getUserConfirmationNoButton() {
		return userConfirmationNoButton;
	}

	/**
	 * @return the gridtableId
	 */
	public static String getGridtableId() {
		return GRIDTABLE_ID;
	}

	/**
	 * @return the gridTable
	 */
	public WebElement getGridTable() {
		return gridTable;
	}
	
}
