package com.atk.himma.pageobjects.mrd.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class SpecialRequestList extends DriverWaitClass implements
		StatusMessages, RecordStatus {

	public final static String QUICKSEARCHTXT_ID = "quickSearch_search";
	public final static String SEARCHBUTTON_ID = "QUICK_SEARCH_BTN";
	public final static String RESETBUTTON_XPATH = "//input[@id='QUICK_SEARCH_BTN']/..//input[@value='Reset']";
	public final static String ADVSEARCHBUTTON_ID = "ADVANCED_SEARCH_SPL";

	// ---------------------------Advance search fields-------------------------
	public final static String REQFROMDATE_ID = "datepicker_id1";
	public final static String REQTODATE_ID = "datepicker_id2";
	public final static String REQUNO_ID = "REQUEST_NUMBER_SEARCH";
	public final static String MRN_ID = "MRN_SEARCH";
	public final static String PATNAME_ID = "PATIENTNAME_SEARCH";
	public final static String REQUESEDBY_ID = "REQUESTING_PHYSICIAN_SEARCH";
	public final static String REQUESEDBYLOOKUP_XPATH = "//input[@id='REQUESTING_PHYSICIAN_SEARCH']/..//a[@class='lookup']";
	public final static String REQUIBYLOC_ID = "REQUIREDBY_LOCATION_SEARCH";
	public final static String REQUIBYLOCLOOKUP_XPATH = "//input[@id='REQUIREDBY_LOCATION_SEARCH']/..//a[@class='lookup']";
	public final static String REQREASONSEARCH_ID = "REQUIRED_REASON_SEARCH";
	public final static String STATUS_ID = "STATUS_SEARCH_NURSING_WORK_BENCH";
	public final static String STATUSADV_ID = "STATUS_ADV";
	public final static String ADVSEARCHSPLBUTTON_ID = "ADVANCED_SEARCH_BTN_SPL";
	public final static String ADVRESETBUTTON_XPATH = "//input[@id='ADVANCED_SEARCH_BTN_SPL']/..//input[@value='Reset']";
	public final static String ADDNEWREQUEST_ID = "ADD_NEW_REQUEST";

	// ----------------------------GRID-----------------------------
	public final static String REFRESHLINK_ID = "REFRESH_DATA_LINK_SPL";
	public final static String GRIDDUMMY_ID = "MR_RESULT_GRID_DUMMY";
	public final static String GRID_ID = "MR_RESULT_GRID";
	public final static String GRID_MRN_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_mrNumber";
	public final static String GRID_PATNAME_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_patientName";
	public final static String GRID_VOLUME_ARIA_DESCRIBEDBY = "jqgh_MR_RESULT_GRID_mrVolume.volume";
	public final static String GRID_REQUESTBY_ARIA_DESCRIBEDBY = "jqgh_MR_RESULT_GRID_mrRequestDetails.physician";
	public final static String GRID_REQDATANDTIME_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_mrRequestDetails.requestedDateText";
	public final static String GRID_SENTTOLOC_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_mrRequestDetails.sentToLoc";
	public final static String GRID_SENTDATEANDTIME_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_sentDateText";

	public final static String GRID_PAGER_ID = "sp_1_MR_RESULT_GRID_pager";

	@FindBy(id=QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;
	
	@FindBy(id=SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(xpath=RESETBUTTON_XPATH)
	private WebElement resetButton;
	
	@FindBy(id=ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(id=REQFROMDATE_ID)
	private WebElement reqFromDate;
	
	@FindBy(id=REQTODATE_ID)
	private WebElement reqToDate;
	
	@FindBy(id=REQUNO_ID)
	private WebElement requNo;
	
	@FindBy(id=MRN_ID)
	private WebElement mrn;
	
	@FindBy(id=PATNAME_ID)
	private WebElement patName;
	
	@FindBy(id=REQUESEDBY_ID)
	private WebElement requestingPhySearch;
	
	@FindBy(xpath=REQUESEDBYLOOKUP_XPATH)
	private WebElement requesedByLookup;
	
	@FindBy(id=REQUIBYLOC_ID)
	private WebElement requiByLoc;
	
	@FindBy(xpath=REQUIBYLOCLOOKUP_XPATH)
	private WebElement requiByLocLookup;
	
	@FindBy(id=REQREASONSEARCH_ID)
	private WebElement reqReasonSearch;
	
	@FindBy(id=STATUS_ID)
	private WebElement status;
	
	@FindBy(id=STATUSADV_ID)
	private WebElement statusAdv;
	
	@FindBy(id=ADVSEARCHSPLBUTTON_ID)
	private WebElement advSearchSplButton;
	
	@FindBy(xpath=ADVRESETBUTTON_XPATH)
	private WebElement advResetButton;
	
	@FindBy(id=ADDNEWREQUEST_ID)
	private WebElement addNewRequest;
	
	@FindBy(id=REFRESHLINK_ID)
	private WebElement refreshLink;

	/**
	 * @return the quickSearchTxt
	 */
	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the reqFromDate
	 */
	public WebElement getReqFromDate() {
		return reqFromDate;
	}

	/**
	 * @return the reqToDate
	 */
	public WebElement getReqToDate() {
		return reqToDate;
	}

	/**
	 * @return the requNo
	 */
	public WebElement getRequNo() {
		return requNo;
	}

	/**
	 * @return the mrn
	 */
	public WebElement getMrn() {
		return mrn;
	}

	/**
	 * @return the patName
	 */
	public WebElement getPatName() {
		return patName;
	}

	/**
	 * @return the requestingPhySearch
	 */
	public WebElement getRequestingPhySearch() {
		return requestingPhySearch;
	}

	/**
	 * @return the requesedByLookup
	 */
	public WebElement getRequesedByLookup() {
		return requesedByLookup;
	}

	/**
	 * @return the requiByLoc
	 */
	public WebElement getRequiByLoc() {
		return requiByLoc;
	}

	/**
	 * @return the requiByLocLookup
	 */
	public WebElement getRequiByLocLookup() {
		return requiByLocLookup;
	}

	/**
	 * @return the reqReasonSearch
	 */
	public WebElement getReqReasonSearch() {
		return reqReasonSearch;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the statusAdv
	 */
	public WebElement getStatusAdv() {
		return statusAdv;
	}

	/**
	 * @return the advSearchSplButton
	 */
	public WebElement getAdvSearchSplButton() {
		return advSearchSplButton;
	}

	/**
	 * @return the advResetButton
	 */
	public WebElement getAdvResetButton() {
		return advResetButton;
	}

	/**
	 * @return the addNewRequest
	 */
	public WebElement getAddNewRequest() {
		return addNewRequest;
	}

	/**
	 * @return the refreshLink
	 */
	public WebElement getRefreshLink() {
		return refreshLink;
	}
	
}
