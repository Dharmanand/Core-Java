package com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AssociatedPoliciesSection extends DriverWaitClass {
	public final static String ASSOCIATEDPOLSEC_LINKTEXT = "Associated Policies";
	public final static String ASSOPOLGRIDDIV = "gview_AGR_POLICY_GRID";

	@FindBy(linkText = ASSOCIATEDPOLSEC_LINKTEXT)
	private WebElement assoPolicySec;

	@FindBy(id = ASSOPOLGRIDDIV)
	private WebElement assoPolicyGridDiv;

	public WebElement getAssoPolicyGridDiv() {
		return assoPolicyGridDiv;
	}

	public WebElement getAssoPolicySec() {
		return assoPolicySec;
	}

	public boolean checkAssociatedPolData(String[] policyListData) {
		waitForElementId(ASSOPOLGRIDDIV);
		try {
			waitForElementXpathExpression(".//td[@aria-describedby='AGR_POLICY_GRID_policyName' and @title='"
					+ policyListData[2] + "']");
			return webDriver
					.findElement(
							By.xpath(".//td[@aria-describedby='AGR_POLICY_GRID_policyName' and @title='"
									+ policyListData[2] + "']")).isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}

}
