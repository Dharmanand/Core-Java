package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AppUserCredentialsSection extends DriverWaitClass {
	public final static String USERCREDENTIALSSECTION_LINKTXT = "Application User Credentials";
	@FindBy(linkText = USERCREDENTIALSSECTION_LINKTXT)
	private WebElement userCredentialsSectionLinkTxt;

	public final static String LOGINNAME_ID = "loginInfo";
	@FindBy(id = LOGINNAME_ID)
	private WebElement loginName;

	public final static String CHECKAVAILABILITYBTN_ID = "userNameAvailabilityLink";
	@FindBy(id = CHECKAVAILABILITYBTN_ID)
	private WebElement checkAvailabilityBtn;

	public final static String RESETPASSWD_XPATH = ".//input[@value='Reset Password']";
	@FindBy(xpath = RESETPASSWD_XPATH)
	private WebElement resetPasswordBtn;

	public final static String STATUSMSG_ID = "statusMsg";
	@FindBy(id = STATUSMSG_ID)
	private WebElement statusMsgLabel;

	public final static String DISPLAYNAME_NAME = "userInfo.displayName";
	@FindBy(name = DISPLAYNAME_NAME)
	private WebElement displayName;

	public final static String USERDESCRIPTION_NAME = "userInfo.userDesc";
	@FindBy(name = USERDESCRIPTION_NAME)
	private WebElement userDescription;

	public void fillCredentials(String[] appUserData) throws Exception {
		loginName.clear();
		loginName.sendKeys(appUserData[37]);
		checkAvailabilityBtn.click();
		sleepVeryShort();
		displayName.clear();
		displayName.sendKeys(appUserData[38]);
		userDescription.clear();
		userDescription.sendKeys(appUserData[39]);
	}

	public WebElement getUserCredentialsSectionLinkTxt() {
		return userCredentialsSectionLinkTxt;
	}

	public WebElement getLoginName() {
		return loginName;
	}

	public WebElement getCheckAvailabilityBtn() {
		return checkAvailabilityBtn;
	}

	public WebElement getResetPasswordBtn() {
		return resetPasswordBtn;
	}

	public WebElement getDisplayName() {
		return displayName;
	}

	public WebElement getUserDescription() {
		return userDescription;
	}

	public WebElement getStatusMsgLabel() {
		return statusMsgLabel;
	}

}
