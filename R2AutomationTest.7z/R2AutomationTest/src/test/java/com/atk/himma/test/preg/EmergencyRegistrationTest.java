package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.preg.EmergencyRegistrationPage;
import com.atk.himma.pageobjects.preg.GeneralRegistrationPage;
import com.atk.himma.pageobjects.preg.regsections.ContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.IdentificationDetailsSection;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class EmergencyRegistrationTest extends SeleniumDriverSetup {

	List<String[]> pregDatas;
	EmergencyRegistrationPage emergencyRegistrationPage;

	@Test(description = "Open Emergency Reg Page")
	public void openEmergencyRegPage() throws InterruptedException {
		emergencyRegistrationPage = PageFactory.initElements(webDriver,
				EmergencyRegistrationPage.class);
		emergencyRegistrationPage = emergencyRegistrationPage
				.clickOnEmerRegMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		emergencyRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		Assert.assertNotNull(emergencyRegistrationPage);
		emergencyRegistrationPage
				.waitForElementVisibilityOf(emergencyRegistrationPage
						.getFormName());
		emergencyRegistrationPage.sleepVeryShort();
		emergencyRegistrationPage
				.waitForElementId(EmergencyRegistrationPage.FORMNAME_ID);
		Assert.assertEquals(emergencyRegistrationPage.getPageTitle().getText(),
				"Emergency Registration");
	}

	// [Emergency Registration] Open Form
	@Test(description = "Open General Registration Page Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkEmerRegMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		emergencyRegistrationPage = PageFactory.initElements(webDriver,
				EmergencyRegistrationPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"Emergency Registration");
		emergencyRegistrationPage.setWebDriver(webDriver);
		emergencyRegistrationPage.setWebDriverWait(webDriverWait);
		emergencyRegistrationPage
				.waitForElementXpathExpression(GeneralRegistrationPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("Emergency Registration")
				.get("[Emergency Registration] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(GeneralRegistrationPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Emergency Registration] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			emergencyRegistrationPage = emergencyRegistrationPage
					.clickOnEmerRegMenu(webDriver, webDriverWait);
			emergencyRegistrationPage.setInstanceOfAllSection(webDriver,
					webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(emergencyRegistrationPage);
			emergencyRegistrationPage
					.waitForElementId(EmergencyRegistrationPage.FORMNAME_ID);
			emergencyRegistrationPage.sleepShort();
			Assert.assertEquals(emergencyRegistrationPage.getPageTitle()
					.getText(), "Emergency Registration");
		}
	}

	@Test(dependsOnMethods = { "openEmergencyRegPage" }, description = "Save Emergency Reg Record")
	public void test1SaveEmerRegPage() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("emergencyReg"));
		emergencyRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas) {
			emergencyRegistrationPage
					.waitForElementXpathExpression(EmergencyRegistrationPage.SAVEBUTTON_XPATH);
			emergencyRegistrationPage.sleepVeryShort();
			Assert.assertEquals(emergencyRegistrationPage.getRegType()
					.getText().trim(), "EMERGENCY");
			emergencyRegistrationPage.saveEmerRegPage(st, webDriver,
					webDriverWait);
			emergencyRegistrationPage
					.waitForElementXpathExpression(EmergencyRegistrationPage.UPDATEBUTTON_XPATH);
			Assert.assertNotNull(emergencyRegistrationPage.getUpdateButton(),
					"save successfully Emer. Reg. datas.");
		}
	}

	@Test(dependsOnMethods = { "test1SaveEmerRegPage" }, description = "Update Emergency Reg Record")
	public void test2UpdateEmerRegPage() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("updateEmergencyReg"));
		for (String[] st : pregDatas) {
			emergencyRegistrationPage
					.waitForElementXpathExpression(EmergencyRegistrationPage.UPDATEBUTTON_XPATH);
			emergencyRegistrationPage.updateEmerRegPage(st, webDriver,
					webDriverWait);
			emergencyRegistrationPage
					.waitForElementClickable(EmergencyRegistrationPage.UPDATEBUTTON_XPATH);
			emergencyRegistrationPage
					.waitForElementXpathExpression(EmergencyRegistrationPage.UPDATEBUTTON_XPATH);
			emergencyRegistrationPage.activateRecord(
					EmergencyRegistrationPage.ACTIVATE_ID,
					EmergencyRegistrationPage.MAINSTATUSLABEL_ID);
			emergencyRegistrationPage
					.waitForElementXpathExpression(EmergencyRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			Assert.assertNotNull(emergencyRegistrationPage.getUpdateButton(),
					"Update successfully Emer. Reg. datas.");
		}
	}

	// [Emergency Registration][Section: Identification Details] Manage
	@Test(dependsOnMethods = { "checkEmerRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Identification Details section privileges")
	public void checkIdentDetSecPrivileges() {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Emergency Registration")
				.get("[Emergency Registration][Section: Identification Details] Manage");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(IdentificationDetailsSection.SECTIONNAME_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Identification Details] Manage");
	}

	// [Emergency Registration][Section: Contact Details] Manage
	@Test(dependsOnMethods = { "checkEmerRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Contact Details section privileges")
	public void checkContactDetailsPrivileges() {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Emergency Registration")
				.get("[Emergency Registration][Section: Contact Details] Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(ContactDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Contact Details]  Manage");
	}

}
