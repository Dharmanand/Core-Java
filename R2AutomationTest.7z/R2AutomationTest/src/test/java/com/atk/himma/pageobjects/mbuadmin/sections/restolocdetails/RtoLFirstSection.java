package com.atk.himma.pageobjects.mbuadmin.sections.restolocdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RtoLFirstSection extends DriverWaitClass{
	
	public final static String RESOURCECODE_NAME = "resource.resourceCode";
	public final static String RESOURCENAME_NAME = "resource.resourceName.fullName";
	public final static String MBU_NAME = "resource.mbuName";
	public final static String DEPARTMENT_NAME = "resource.departmentId";
	public final static String RESOURCECATEGORY_NAME = "resource.resourceCategoryId";
	public final static String RESOURCETYPE_NAME = "resource.resourceTypeId";
	
	public final static String ADDBUTTONGRID_XPATH = "//td[@id='RES_WISE_ASSIGN_GRID_pager_left']//div[@class='ui-pg-div']/span";
	
//	Lookup Window
	public final static String LOOKUPFORM_ID = "LOCATION_ASSIGNMENT_FORM";
	public final static String LOOKUPTITLE_ID = "ui-dialog-title-LOCATION_ASSIGNMENT_POPUP";
	public final static String MBU_ID = "LOCATION_POPUP_MBU";
	public final static String DEPARTMENT_ID = "LOCATION_POPUP_DEPARTMENT";
	public final static String LOCCATEGORY_ID = "LOCATION_POPUP_LOCATION_CATEGORY";
	public final static String LOCATIONCODE_XPATH = "//form[@id='LOCATION_ASSIGNMENT_FORM']//input[@name='searchCriteria.locationCode']";
	public final static String LOCATIONNAME_XPATH = "//form[@id='LOCATION_ASSIGNMENT_FORM']//input[@name='searchCriteria.locationName']";
	public final static String SEARCHBUTTON_XPATH = "//form[@id='LOCATION_ASSIGNMENT_FORM']//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//form[@id='LOCATION_ASSIGNMENT_FORM']//sapn[@class='buttoncontainer_mid']//input[@value='Reset']";

//	PopUp Grid
	public final static String PUPGRIDID_ID = "LOCATION_ASSIGNMENT_GRID";
	public final static String PUPGRID_CKBOX_ARIA_DESCRIBEDBY = "LOCATION_ASSIGNMENT_GRID_cb";
	public final static String PUPGRID_LOCATIONCODE_ARIA_DESCRIBEDBY = "LOCATION_ASSIGNMENT_GRID_locationCode";
	public final static String PUPGRID_LOCATIONNAME_ARIA_DESCRIBEDBY = "LOCATION_ASSIGNMENT_GRID_locationName";
	public final static String PUPGRID_CATEGORYTEXT_ARIA_DESCRIBEDBY = "LOCATION_ASSIGNMENT_GRID_categoryText";
	public final static String PUPGRID_DEPARTMENT_ARIA_DESCRIBEDBY = "LOCATION_ASSIGNMENT_GRID_departmentText";
	public final static String PUPGRID_MBU_ARIA_DESCRIBEDBY = "LOCATION_ASSIGNMENT_GRID_mbuText";
	public final static String PUPGRID_PAGERID = "sp_1_LOCATION_ASSIGNMENT_GRID_pager";
	public final static String PUPGRID_NEXTPAGE_XPATH = "//td[@id='next_LOCATION_ASSIGNMENT_GRID_pager']";

//	public final static String ASSIGNBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Assign']";
//	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Cancel']";
	
	public final static String ASSIGNBUTTON_CSS = "html body div.ui-dialog div#LOCATION_ASSIGNMENT_POPUP.DialogWR div#contentBoxPopup div#form div.form_layout form#LOCATION_ASSIGNMENT_FORM span.buttoncontainer_vlrg_rgt input.input_button";
	public final static String CANCELBUTTON_CSS = "html body div.ui-dialog div#LOCATION_ASSIGNMENT_POPUP.DialogWR div#contentBoxPopup div#form div.form_layout form#LOCATION_ASSIGNMENT_FORM span.buttoncontainer_vlrg_rgt input.input_cancel";
	
	public final static String GRIDID_ID = "RES_WISE_ASSIGN_GRID";
	public final static String GRID_LOCATIONCODE_ID = "RES_WISE_ASSIGN_GRID_locationInfo.locationCode";
	public final static String GRID_LOCATIONNAME_ARIA_DESCRIBEDBY = "RES_WISE_ASSIGN_GRID_locationInfo.locationName";
	public final static String GRID_LOCATIONCATEGORY_ARIA_DESCRIBEDBY = "RES_WISE_ASSIGN_GRID_locationInfo.categoryText";
	public final static String GRID_department_ARIA_DESCRIBEDBY = "RES_WISE_ASSIGN_GRID_locationInfo.departmentText";
	public final static String GRID_mbu_ARIA_DESCRIBEDBY = "RES_WISE_ASSIGN_GRID_locationInfo.mbuText";
	public final static String GRID_PAGERID = "sp_1_RES_WISE_ASSIGN_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_RES_WISE_ASSIGN_GRID_pager']";
	public final static String GRID_ADDBUTTON_XPATH = "//span[@class='ui-icon ui-icon-plus']";

	@FindBy(name = RESOURCECODE_NAME)
	private WebElement resourceCode;
	
//	@FindBy(name = RESCAT_NAME)
//	private WebElement resourceCategory;
	
	@FindBy(xpath = GRID_ADDBUTTON_XPATH)
	private WebElement addButton;
	
	@FindBy(name = RESOURCENAME_NAME)
	private WebElement resourceName;
	
	@FindBy(name = MBU_NAME)
	private WebElement mbuName;
	
	@FindBy(name = DEPARTMENT_NAME)
	private WebElement department;
	
	@FindBy(name = RESOURCECATEGORY_NAME)
	private WebElement resourceCategory;
	
	@FindBy(name = RESOURCETYPE_NAME)
	private WebElement resourceType;
	
	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButtonGrid;
	
	@FindBy(id = LOOKUPFORM_ID)
	private WebElement lookUpForm;

	@FindBy(id = LOOKUPTITLE_ID)
	private WebElement lookUpTitle;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement departmentPopUp;
	
	@FindBy(id = LOCCATEGORY_ID)
	private WebElement locCategory;
	
	@FindBy(xpath = LOCATIONCODE_XPATH)
	private WebElement locationCodePopUp;
	
	@FindBy(xpath = LOCATIONNAME_XPATH)
	private WebElement locationNamePopUp;
	
	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;
	
	@FindBy(css = ASSIGNBUTTON_CSS)
	private WebElement assignButton;
	
	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;
	
	public boolean fillRtoLFirstSecDatas(String[] rToLDatas) throws InterruptedException
	{
		waitForElementXpathExpression(ADDBUTTONGRID_XPATH);
		sleepVeryShort();
		addButtonGrid.click();
		waitForElementId(LOOKUPTITLE_ID);
		waitForElementXpathExpression(LOCATIONNAME_XPATH);
		sleepShort();
		String[] locations = rToLDatas[8].split("\\,");
		for(int i=0; i<locations.length; i++)
		{
		locationNamePopUp.clear();
		locationNamePopUp.sendKeys(locations[i].trim());
		searchButton.click();
		sleepShort();
		clickOnCheckBoxGridItem(PUPGRIDID_ID, locations[i].trim());
		}
		waitForElementCssSelector(ASSIGNBUTTON_CSS);
		sleepVeryShort();
		assignButton.click();
		waitForElementId(GRIDID_ID);
		sleepShort();
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}
	
//	PopUp Grid
	
	@FindBy(id = PUPGRIDID_ID)
	private WebElement pupGridID;
	
	@FindBy(id = GRID_PAGERID)
	private WebElement gridPagerID;
	
	@FindBy(id = GRID_NEXTPAGE_XPATH)
	private WebElement gridNextPage;

	/**
	 * @return the resourceCode
	 */
	public WebElement getResourceCode() {
		return resourceCode;
	}

	/**
	 * @return the resourceName
	 */
	public WebElement getResourceName() {
		return resourceName;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the resourceCategory
	 */
	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	/**
	 * @return the resourceType
	 */
	public WebElement getResourceType() {
		return resourceType;
	}

	/**
	 * @return the addButtonGrid
	 */
	public WebElement getAddButtonGrid() {
		return addButtonGrid;
	}

	/**
	 * @return the lookUpForm
	 */
	public WebElement getLookUpForm() {
		return lookUpForm;
	}

	/**
	 * @return the lookUpTitle
	 */
	public WebElement getLookUpTitle() {
		return lookUpTitle;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the departmentPopUp
	 */
	public WebElement getDepartmentPopUp() {
		return departmentPopUp;
	}

	/**
	 * @return the locCategory
	 */
	public WebElement getLocCategory() {
		return locCategory;
	}

	/**
	 * @return the locationCodePopUp
	 */
	public WebElement getLocationCodePopUp() {
		return locationCodePopUp;
	}

	/**
	 * @return the locationNamePopUp
	 */
	public WebElement getLocationNamePopUp() {
		return locationNamePopUp;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the pupGridID
	 */
	public WebElement getPupGridID() {
		return pupGridID;
	}

	/**
	 * @return the gridPagerID
	 */
	public WebElement getGridPagerID() {
		return gridPagerID;
	}

	/**
	 * @return the gridNextPage
	 */
	public WebElement getGridNextPage() {
		return gridNextPage;
	}

	/**
	 * @return the assignButton
	 */
	public WebElement getAssignButton() {
		return assignButton;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}
	
}
