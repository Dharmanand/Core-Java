package com.atk.himma.pageobjects.appointsched.sections.appointSections;

import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DateTimeConverter;

public class ClinicsAvailability extends ResourceAvailability {

	public final static String FORM_ID = "searchClinicForm1";
	public static int noOfslotsForClinics;
	@FindBy(id = FORM_ID)
	private WebElement formId;

	public AppointmentDairy clickOnAvailableSession(String sessionName)
			throws InterruptedException {
		String elementXpath = "//table[@id='recourceAvailableGrid']//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/../../..//td[@aria-describedby='recourceAvailableGrid_sessionName']//a[contains(text(),'"
				+ sessionName.trim() + "')]";
		return clickAvailDateResSession(elementXpath);
	}

	public AppointmentDairy clickOnAvailDateSession(String sessionName,
			String date) throws InterruptedException {
		return clickAvailDateResSession("//table[@id='recourceAvailableGrid']//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/../../..//td[@aria-describedby='recourceAvailableGrid_sessionName']//a[contains(text(),'"
				+ sessionName.trim()
				+ "')]/../../..//td["
				+ dateColumnCount(date) + "]//a");
	}

//	count No of slot created at current date
	public int noOfSlotsAllSession(int slotTimeInterval) throws ParseException {
		String elementXpath = "//table[@id='recourceAvailableGrid']//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/../../..//td[@aria-describedby='recourceAvailableGrid_sessionName']//a";
		List<WebElement> elements = webDriver.findElements(By
				.xpath(elementXpath));
		noOfslotsForClinics = 0;
		for (WebElement we : elements) {
			String frmTM = we.getText().split("\\(")[1].split("-")[0].trim();
			String toTM = we.getText().split("\\(")[1].split("-")[1]
					.split("\\)")[0].trim();
			noOfslotsForClinics = noOfslotsForClinics
					+ (int) DateTimeConverter.noOfSlots(frmTM, toTM,
							slotTimeInterval);
		}
		return (int) noOfslotsForClinics;
	}

	/**
	 * @return the formId
	 */
	public WebElement getFormId() {
		return formId;
	}

}
