package com.atk.himma.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class LoginPage extends DriverWaitClass {

	public final static String USERLOCATION_ID = "locationId";
	public final static String USERPOSITION_ID = "positionId";

	@FindBy(id = USERLOCATION_ID)
	private WebElement userLocation;

	@FindBy(id = USERPOSITION_ID)
	private WebElement userPosition;

	public WebElement getUserPosition() {
		return userPosition;
	}

	public final static String LOGOUT_XPATH = "//input[@value='Log Out']";

	@FindBy(xpath = LOGOUT_XPATH)
	private WebElement logOut;

	public final static String FORMTITLE_ID = "loginform";

	@FindBy(id = FORMTITLE_ID)
	private WebElement formTitle;

	public final static String USERNAME_NAME = "userAuthInfo.loginName";

	@FindBy(name = USERNAME_NAME)
	private WebElement userName;

	public final static String PASSWORD_NAME = "userAuthInfo.password";

	@FindBy(name = PASSWORD_NAME)
	private WebElement password;

	public final static String LOGINBUTTON_XPATH = "//input[@value='Log In']";

	@FindBy(xpath = LOGINBUTTON_XPATH)
	private WebElement loginButton;

	public final static String GOBUTTON_XPATH = "//span[@class='buttoncontainer_sml']/input[@value='Go']";

	@FindBy(xpath = GOBUTTON_XPATH)
	private WebElement goButton;

	public final static String OKACTIVESESSIONBUTTON_XPATH = "//input[@value='OK']";

	@FindBy(xpath = OKACTIVESESSIONBUTTON_XPATH)
	private WebElement okActiveSessionButton;

	public void loginErrorMsg() {
		try {
			waitForElementXpathExpression(OKACTIVESESSIONBUTTON_XPATH);
			sleepVeryShort();
			getOkActiveSessionButton().click();
		} catch (Exception e) {

		}
	}

	public HomePage doLoginWithCorrectUserAndPassword(WebDriver webDriver,
			String userName, String password, String userLocValue,
			String positionName) throws InterruptedException {
		getUserName().sendKeys(userName);
		getPassword().sendKeys(password);
		getLoginButton().click();
		loginErrorMsg();
		if ((userLocValue != null) && !userLocValue.isEmpty()) {
			waitForElementId(USERLOCATION_ID);
			sleepVeryShort();
			new Select(userLocation).selectByVisibleText(userLocValue.trim());
		}
		if ((positionName != null) && !positionName.isEmpty()) {
			waitForElementId(USERPOSITION_ID);
			sleepVeryShort();
			new Select(userPosition).selectByVisibleText(positionName.trim());
		}
		if ((userLocValue != null) && !userLocValue.isEmpty()
				|| (positionName != null) && !positionName.isEmpty())
			goButton.click();
		waitForElementXpathExpression(HomePage.HOMETITLE_XPATH);
		return PageFactory.initElements(webDriver, HomePage.class);
	}

	public LoginPage doLoginWithIncorrectUserAndPassword(WebDriver webDriver,
			String userName, String password) {

		getUserName().sendKeys(userName);
		getPassword().sendKeys(password);
		getLoginButton().click();
		return PageFactory.initElements(webDriver, LoginPage.class);
	}

	public LoginPage logOut(WebDriver webDriver, String userName,
			String password) throws InterruptedException {
		logOut.click();
		LoginPage loginPage = PageFactory.initElements(webDriver,
				LoginPage.class);
		loginPage.setWebDriver(webDriver);
		loginPage.setWebDriverWait(webDriverWait);
		waitForElementId(LoginPage.FORMTITLE_ID);
		sleepShort();
		return loginPage;
	}

	public String login(int rowNO, List<String[]> loginDatas) throws Exception {
		HomePage homePage = null;
		sleepVeryShort();
		for (String st[] : loginDatas.subList(rowNO - 1, rowNO))
			homePage = doLoginWithCorrectUserAndPassword(webDriver,
					st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		loginErrorMsg();
		waitForElementXpathExpression(HomePage.HOMETITLE_XPATH);
		homePage.setWebDriverWait(webDriverWait);
		return homePage.getHomeTitle().getAttribute("title").trim();
	}

	/**
	 * @return the userLocation
	 */
	public WebElement getUserLocation() {
		return userLocation;
	}

	/**
	 * @return the logOut
	 */
	public WebElement getLogOut() {
		return logOut;
	}

	/**
	 * @return the formTitle
	 */
	public WebElement getFormTitle() {
		return formTitle;
	}

	/**
	 * @return the userName
	 */
	public WebElement getUserName() {
		return userName;
	}

	/**
	 * @return the password
	 */
	public WebElement getPassword() {
		return password;
	}

	/**
	 * @return the loginButton
	 */
	public WebElement getLoginButton() {
		return loginButton;
	}

	/**
	 * @return the okActiveSessionButton
	 */
	public WebElement getOkActiveSessionButton() {
		return okActiveSessionButton;
	}

	/**
	 * @return the goButton
	 */
	public WebElement getGoButton() {
		return goButton;
	}

}
