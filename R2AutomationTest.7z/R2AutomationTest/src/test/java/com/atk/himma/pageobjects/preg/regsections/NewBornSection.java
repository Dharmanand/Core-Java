package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.preg.PatientSearchPage;
import com.atk.himma.util.DriverWaitClass;

public class NewBornSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "New Born";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	private final static String NOTIFICATIONTYPE_NAME = "notificationType";

	@FindBy(name = NOTIFICATIONTYPE_NAME)
	private WebElement notificationType;

	private final static String MOTHERSMRN_ID = "motherMrnumber";

	@FindBy(id = MOTHERSMRN_ID)
	private WebElement mothersMRN;

	private final static String SEARCHMOTHERSMRNLOOKUP_ID = "searchmothersMRN";

	@FindBy(id = SEARCHMOTHERSMRNLOOKUP_ID)
	private WebElement searchMothersMRNLookUp;

	private final static String TIMEOFBIRTH_ID = "patientBirthTime";

	@FindBy(id = TIMEOFBIRTH_ID)
	private WebElement timeOfBirth;

	private final static String TIMEOFBIRTHDATEPICKER_XPATH = "//input[@id='patientBirthTime']/..//img[@class='ui-datepicker-trigger']";

	@FindBy(xpath = TIMEOFBIRTHDATEPICKER_XPATH)
	private WebElement timeOfBirthDatepicker;

	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//p[@title='Collapse / Expand']/a[contains(text(), 'New Born')]/..";

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public void fillDatasInNewbornSection(String[] excelData,
			WebDriverWait webDriverWait) throws InterruptedException {
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(getMothersmrnId());
		// waitForElementVisibilityOf(getMothersMRN());
		selectMotherMrnFrmLookUp(excelData[19]);
	}

	private PatientSearchPage selectMotherMrnFrmLookUp(String searchText)
			throws InterruptedException {
		PatientSearchPage patientSearchPage = PageFactory.initElements(
				webDriver, PatientSearchPage.class);
		patientSearchPage.setWebDriver(webDriver);
		patientSearchPage.setWebDriverWait(webDriverWait);
		getSearchMothersMRNLookUp().click();
		waitForElementVisibilityOf(patientSearchPage.getQuickSearchTextField());
		waitForElementVisibilityOf(patientSearchPage.getSearchButton());

		patientSearchPage.clickSelectLinkInGridOfNewBorn(searchText);
		return patientSearchPage;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the notificationtypeName
	 */
	public static String getNotificationtypeName() {
		return NOTIFICATIONTYPE_NAME;
	}

	/**
	 * @return the notificationType
	 */
	public WebElement getNotificationType() {
		return notificationType;
	}

	/**
	 * @return the mothersmrnId
	 */
	public static String getMothersmrnId() {
		return MOTHERSMRN_ID;
	}

	/**
	 * @return the mothersMRN
	 */
	public WebElement getMothersMRN() {
		return mothersMRN;
	}

	/**
	 * @return the searchmothersmrnlookupId
	 */
	public static String getSearchmothersmrnlookupId() {
		return SEARCHMOTHERSMRNLOOKUP_ID;
	}

	/**
	 * @return the searchMothersMRNLookUp
	 */
	public WebElement getSearchMothersMRNLookUp() {
		return searchMothersMRNLookUp;
	}

	/**
	 * @return the timeofbirthId
	 */
	public static String getTimeofbirthId() {
		return TIMEOFBIRTH_ID;
	}

	/**
	 * @return the timeOfBirth
	 */
	public WebElement getTimeOfBirth() {
		return timeOfBirth;
	}

	/**
	 * @return the timeofbirthdatepickerXpath
	 */
	public static String getTimeofbirthdatepickerXpath() {
		return TIMEOFBIRTHDATEPICKER_XPATH;
	}

	/**
	 * @return the timeOfBirthDatepicker
	 */
	public WebElement getTimeOfBirthDatepicker() {
		return timeOfBirthDatepicker;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
