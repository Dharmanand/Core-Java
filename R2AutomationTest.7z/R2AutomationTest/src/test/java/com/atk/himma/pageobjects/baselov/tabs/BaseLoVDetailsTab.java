package com.atk.himma.pageobjects.baselov.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class BaseLoVDetailsTab extends DriverWaitClass{
	
	public final static String FORM_ID = "baselvform";
	
	@FindBy(id=FORM_ID)
	private WebElement form;
	
	public final static String MODULENAME_ID = "moduleIdDetails";
	
	@FindBy(id=MODULENAME_ID)
	private WebElement moduleName;
	
	public final static String ENTITY_ID = "entityTypeIdDetails";
	
	@FindBy(id=ENTITY_ID)
	private WebElement entity;
	
	public final static String LANGUAGE_NAME = "baseLV.langCode";
	
	@FindBy(name=LANGUAGE_NAME)
	private WebElement language;

	public final static String STATUS_NAME = "baseLV.status";
	
	@FindBy(name=STATUS_NAME)
	private WebElement status;
	
	public final static String SHORTNAME_ID = "dispShortDesc";
	
	@FindBy(id=SHORTNAME_ID)
	private WebElement shortName;
	
	public final static String LONGNAME_ID = "longDesc";
	
	@FindBy(id=LONGNAME_ID)
	private WebElement longName;

	public final static String SAVEBUTTON_ID = "SAVE_BASELV_ID";
	
	@FindBy(id=SAVEBUTTON_ID)
	private WebElement saveButton;
	
	public final static String UPDATEBUTTON_ID = "UPDATE_BASELV_ID";
	
	@FindBy(id=UPDATEBUTTON_ID)
	private WebElement updateButton;
	
	public final static String ADDNEWBUTTON_ID = "ADDNEW_BASELV_ID_DET";
	
	@FindBy(id=SAVEBUTTON_ID)
	private WebElement addNewButton;
	
	public final static String CANCEBUTTON_ID = "CANCEL_BASELV_ID";
	
	@FindBy(id=CANCEBUTTON_ID)
	private WebElement canceButton;
	
//	----------------------------------------------  Grid Start -----------------------------------------
	
	public final static String GRID_ENTITYTYPEID_ARIA_DESCRIBEDBY = "BASELV_ALL_LANGS_entityTypeId"; 
	public final static String GRID_DISPSHORTDESC_ARIA_DESCRIBEDBY = "BASELV_ALL_LANGS_dispShortDesc"; 
	public final static String GRID_LONGDESC_ARIA_DESCRIBEDBY = "BASELV_ALL_LANGS_longDesc"; 
	public final static String GRID_LANGCODE_ARIA_DESCRIBEDBY = "BASELV_ALL_LANGS_langCode"; 
	public final static String GRID_status_ARIA_DESCRIBEDBY = "BASELV_ALL_LANGS_status"; 
	
//	----------------------------------------------  Grid End -----------------------------------------
	
	/**
	 * @return the moduleName
	 */
	public WebElement getModuleName() {
		return moduleName;
	}

	/**
	 * @return the entity
	 */
	public WebElement getEntity() {
		return entity;
	}

	/**
	 * @return the language
	 */
	public WebElement getLanguage() {
		return language;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the shortName
	 */
	public WebElement getShortName() {
		return shortName;
	}

	/**
	 * @return the longName
	 */
	public WebElement getLongName() {
		return longName;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the modulenameId
	 */
	public static String getModulenameId() {
		return MODULENAME_ID;
	}

	/**
	 * @return the entityId
	 */
	public static String getEntityId() {
		return ENTITY_ID;
	}

	/**
	 * @return the statusName
	 */
	public static String getStatusName() {
		return STATUS_NAME;
	}

	/**
	 * @return the shortnameId
	 */
	public static String getShortnameId() {
		return SHORTNAME_ID;
	}

	/**
	 * @return the longnameId
	 */
	public static String getLongnameId() {
		return LONGNAME_ID;
	}

	/**
	 * @return the savebuttonId
	 */
	public static String getSavebuttonId() {
		return SAVEBUTTON_ID;
	}

	/**
	 * @return the cancebuttonId
	 */
	public static String getCancebuttonId() {
		return CANCEBUTTON_ID;
	}

	/**
	 * @return the canceButton
	 */
	public WebElement getCanceButton() {
		return canceButton;
	}

	/**
	 * @return the formId
	 */
	public static String getFormId() {
		return FORM_ID;
	}

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the updatebuttonId
	 */
	public static String getUpdatebuttonId() {
		return UPDATEBUTTON_ID;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the addnewbuttonId
	 */
	public static String getAddnewbuttonId() {
		return ADDNEWBUTTON_ID;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	/**
	 * @return the languageName
	 */
	public static String getLanguageName() {
		return LANGUAGE_NAME;
	}

	/**
	 * @return the gridEntitytypeidAriaDescribedby
	 */
	public static String getGridEntitytypeidAriaDescribedby() {
		return GRID_ENTITYTYPEID_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridDispshortdescAriaDescribedby
	 */
	public static String getGridDispshortdescAriaDescribedby() {
		return GRID_DISPSHORTDESC_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridLongdescAriaDescribedby
	 */
	public static String getGridLongdescAriaDescribedby() {
		return GRID_LONGDESC_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridLangcodeAriaDescribedby
	 */
	public static String getGridLangcodeAriaDescribedby() {
		return GRID_LANGCODE_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridStatusAriaDescribedby
	 */
	public static String getGridStatusAriaDescribedby() {
		return GRID_status_ARIA_DESCRIBEDBY;
	}

}
