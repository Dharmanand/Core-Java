package com.atk.himma.pageobjects.sa.masters.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

import com.atk.himma.util.DriverWaitClass;

public class ResourceCategoryDetailsTab extends DriverWaitClass {
	public final static String RESCATDETAILSFORM_ID = "resourceCategoryForm";
	@FindBy(id = RESCATDETAILSFORM_ID)
	private WebElement resCatDetailsForm;

	public final static String SAVEBTN_ID = "SAVE_BUTTON";
	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	public final static String UPDATEBTN_XPATH = "//form[@id='resourceCategoryForm']//input[@value='Update']";
	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	public final static String CANCELBTN_XPATH = "//form[@id='resourceCategoryForm']//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String MBUCODE_NAME = "mainBusinessUnit.unitCode";
	@FindBy(name = MBUCODE_NAME)
	private WebElement mbuCode;

	public final static String MBUNAME_NAME = "mainBusinessUnit.unitName";
	@FindBy(name = MBUNAME_NAME)
	private WebElement mbuName;

	public final static String RESCATEGORYDETAILSGRID_ID = "gbox_RESOURCE_CATEGORY_MAP_GRID";
	@FindBy(id = RESCATEGORYDETAILSGRID_ID)
	private WebElement resCategoryDetailsGrid;

	public final static String ADDRECORDGRIDBTN_XPATH = "//span[@class='ui-icon ui-icon-plus']";
	@FindBy(xpath = ADDRECORDGRIDBTN_XPATH)
	private WebElement addRecordGridBtn;

	public final static String ADDRESCATPOPUP_ID = "POPUP_DETAILS";
	@FindBy(id = ADDRESCATPOPUP_ID)
	private WebElement addResCatPopup;

	public final static String RESOURCECATEGORY_ID = "RESOURCE_CATEGORY";
	@FindBy(id = RESOURCECATEGORY_ID)
	private WebElement resourceCategory;

	public final static String RESOURCETYPE_ID = "RESOURCE_TYPE";
	@FindBy(id = RESOURCETYPE_ID)
	private WebElement resourceType;

	public final static String ADDBTN_ID = "ADD_BUTTON";
	@FindBy(id = ADDBTN_ID)
	private WebElement addBtn;

	public final static String POPUPCANCELBTN_ID = "CANCEL_BUTTON";
	@FindBy(id = POPUPCANCELBTN_ID)
	private WebElement popupCancelBtn;

	public void addRootResCatRecord(String[] rootResCatData) throws Exception {
		sleepVeryShort();
		addRecordGridBtn.click();
		sleepVeryShort();
		waitForElementId(ADDRESCATPOPUP_ID);
		new Select(resourceCategory).selectByVisibleText(rootResCatData[1]);
		new Select(resourceType).selectByVisibleText(rootResCatData[2]);
		String[] appUserDesig;
		String delimiter = "\\,";
		appUserDesig = rootResCatData[3].split(delimiter);
		for (int i = 0; i < appUserDesig.length; i++) {
			webDriver.findElement(
					By.xpath("//input[@title='" + appUserDesig[i] + "']"))
					.click();
		}
		addBtn.click();
		sleepShort();
	}

	public void updateResCat() throws Exception {
		updateBtn.click();
		sleepShort();
	}

	public void addMbuResCatRecord(String[] mbuResCatData) throws Exception {
		addRecordGridBtn.click();
		sleepVeryShort();
		waitForElementId(ADDRESCATPOPUP_ID);
		new Select(resourceCategory).selectByVisibleText(mbuResCatData[1]);
		new Select(resourceType).selectByVisibleText(mbuResCatData[2]);
		String[] appUserDesig;
		String delimiter = "\\,";
		appUserDesig = mbuResCatData[3].split(delimiter);
		for (int i = 0; i < appUserDesig.length; i++) {
			webDriver.findElement(
					By.xpath("//input[@title='" + appUserDesig[i] + "']"))
					.click();
		}
		addBtn.click();
		sleepShort();
	}

	public void saveResCat() throws Exception {
		saveBtn.click();
		sleepShort();
	}

	public void clickOnCancel() throws Exception {
		cancelBtn.click();
		sleepVeryShort();
	}

	public boolean searchGridData(String[] rootResCatData) {
		boolean result = false;
		try {
			waitForElementXpathExpression("//td[@aria-describedby='RESOURCE_CATEGORY_MAP_GRID_employeeDesignation' and @title='"
					+ rootResCatData[3].trim() + "']");
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='RESOURCE_CATEGORY_MAP_GRID_employeeDesignation' and @title='"
									+ rootResCatData[3].trim() + "']"))
					.isDisplayed();
			return result;
		} catch (Exception e) {
			Reporter.log("Element not Found...");
			return result;
		}
	}

	public WebElement getResCatDetailsForm() {
		return resCatDetailsForm;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getMbuCode() {
		return mbuCode;
	}

	public WebElement getMbuName() {
		return mbuName;
	}

	public WebElement getResCategoryDetailsGrid() {
		return resCategoryDetailsGrid;
	}

	public WebElement getAddRecordGridBtn() {
		return addRecordGridBtn;
	}

	public WebElement getAddResCatPopup() {
		return addResCatPopup;
	}

	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	public WebElement getResourceType() {
		return resourceType;
	}

	public WebElement getAddBtn() {
		return addBtn;
	}

	public WebElement getPopupCancelBtn() {
		return popupCancelBtn;
	}

}
