package com.atk.himma.pageobjects.mrd;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mrd.tabs.SpecialRequestDetailsTab;
import com.atk.himma.pageobjects.mrd.tabs.SpecialRequestList;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class SpecialRequestPage extends DriverWaitClass {

	private SpecialRequestList specialRequestList;
	private SpecialRequestDetailsTab specialRequestDetailsTab;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String SPECIALREQUESTMENU_XPATH = "//a[text()='MRD']/..//a[text()='Special Request']";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = SPECIALREQUESTMENU_XPATH)
	private WebElement specialRequest;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		specialRequestList = PageFactory.initElements(webDriver,
				SpecialRequestList.class);
		specialRequestList.setWebDriver(webDriver);
		specialRequestList.setWebDriverWait(webDriverWait);

		specialRequestDetailsTab = PageFactory.initElements(webDriver,
				SpecialRequestDetailsTab.class);
		specialRequestDetailsTab.setWebDriver(webDriver);
		specialRequestDetailsTab.setWebDriverWait(webDriverWait);
	}

	public SpecialRequestPage checkSpecReqLink(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MRD");
		menuSelector.mouseOverOnTargetMenu(menuList, "Special Request");
		SpecialRequestPage specialRequestPage = PageFactory.initElements(
				webDriver, SpecialRequestPage.class);
		specialRequestPage.setWebDriver(webDriver);
		specialRequestPage.setWebDriverWait(webDriverWait);
		return specialRequestPage;
	}

	public SpecialRequestPage clickOnSpecReqMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MRD");
		menuSelector.clickOnTargetMenu(menuList, "Special Request");
		SpecialRequestPage specialRequestPage = PageFactory.initElements(
				webDriver, SpecialRequestPage.class);
		specialRequestPage.setWebDriver(webDriver);
		specialRequestPage.setWebDriverWait(webDriverWait);
		return specialRequestPage;
	}

	public boolean createMRRequest(String[] specialReqDatas)
			throws InterruptedException {
		waitForElementId(SpecialRequestList.ADDNEWREQUEST_ID);
		specialRequestList.getAddNewRequest().click();
		waitForElementId(SpecialRequestDetailsTab.GRID_ID);
		sleepVeryShort();
		return specialRequestDetailsTab.fillDatas(specialReqDatas);
	}

	public boolean saveSpeReqDetails(){
		waitForElementXpathExpression(SpecialRequestDetailsTab.SAVEBUTTON_XPATH);
		specialRequestDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(SpecialRequestDetailsTab.UPDATEBUTTON_XPATH);
		return specialRequestDetailsTab.getUpdateButton().getText().trim().equals("Update");
	}
	
	/**
	 * @return the specialRequestList
	 */
	public SpecialRequestList getSpecialRequestList() {
		return specialRequestList;
	}

	/**
	 * @return the specialRequestDetailsTab
	 */
	public SpecialRequestDetailsTab getSpecialRequestDetailsTab() {
		return specialRequestDetailsTab;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the specialRequest
	 */
	public WebElement getSpecialRequest() {
		return specialRequest;
	}

	/**
	 * @param pageTitle
	 *            the pageTitle to set
	 */
	public void setPageTitle(WebElement pageTitle) {
		this.pageTitle = pageTitle;
	}

}
