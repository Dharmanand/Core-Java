package com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;

public class DebtorAgrmntDetailsFirstSection extends DriverWaitClass {
	public final static String AGREEMENTCODE_ID = "AGMNT_CODE";
	public final static String AGREEMENTREFNO_ID = "AGMNT_REF_NUM";
	public final static String AGREEMENTBILLINGTYPE_ID = "AGMNT_BILLING_TYPE";
	public final static String AGREEMENTTYPE_ID = "AGREEMENT_TYPE";
	public final static String DEBTORNAMETXT_ID = "AGMNT_POP_NAME";
	public final static String DEBTORNAMELOOKUP_ID = "LOOK_UP_AGMNT_POP";
	public final static String DEBTORNAMELOOKUPFORM_ID = "debtoragmntNameformId";
	public final static String MBULIST_ID = "ARMNT_SERDEBT_MBU";
	public final static String GLOBALDEBTORCHKBOX_ID = "DEB_GLOBAL_CHBOX_POPUP";
	public final static String DEBTORTYPE_ID = "ARMNT_SERDEBT_DT";
	public final static String DEBTORCATEGORY_ID = "ARMNT_SERDEBT_DC";
	public final static String DEBTORNAME_ID = "ARMNT_SERDEBT_DN";
	public final static String DEBTORSEARCHBTN_ID = "searchDebatorNameId";
	public final static String DEBTORRESETBTN_ID = "ARMNT_SERDEBT_RESET";
	public final static String DEBTORGRIDDIV_ID = "ARMNT_SERDEBT_GRID_DIV";
	public final static String MBU_ID = "MBU_NAME";
	public final static String GLOBALAGRMNTCHKBOX_ID = "AGMNT_GLOBAL_CHBOX_MAIN";
	public final static String AGRMNTNAME_ID = "AGMNT_NAME";
	public final static String AGRMNTNAMEAR_ID = "AGMNT_NAME_AR";
	public final static String AGRMNTSIGNEDDATE_ID = "AGMNT_SIGN_DATE";
	public final static String AGRMNTSTARTDATE_ID = "AGMNT_START_DATE";
	public final static String AGRMNTENDDATE_ID = "AGMNT_END_DATE";
	public final static String EXPNOTIFVALUE_ID = "agmnt_exp_noti_value";
	public final static String EXPNOTIFTYPE_ID = "agmnt_exp_noti_Type";
	public final static String GRACEPERIODAPPL_ID = "AGMNT_GRACE_PERIOD_APP_CHBOX";
	public final static String GRACEPERIODVALUE_ID = "AGMNT_GRACE_PERIOD_VALUE";
	public final static String GRACEPERIODTYPE_ID = "AGMNT_GRACE_PERIOD_TYPE";
	public final static String AGRMNTCOVRG_NAME = "multiselect_AGMNT_CRAGE";

	@FindBy(id = AGREEMENTCODE_ID)
	private WebElement agrmntCode;

	@FindBy(id = AGREEMENTREFNO_ID)
	private WebElement agrmntRefNum;

	@FindBy(id = AGREEMENTBILLINGTYPE_ID)
	private WebElement agrmntBillingType;

	@FindBy(id = AGREEMENTTYPE_ID)
	private WebElement agrmntType;

	@FindBy(id = DEBTORNAMETXT_ID)
	private WebElement debtorNameText;

	@FindBy(id = DEBTORNAMELOOKUP_ID)
	private WebElement debtorNameLookup;

	@FindBy(id = DEBTORNAMELOOKUPFORM_ID)
	private WebElement debtorNameLookupForm;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALDEBTORCHKBOX_ID)
	private WebElement globalDebtorChkBox;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = DEBTORCATEGORY_ID)
	private WebElement debtorCategory;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = DEBTORSEARCHBTN_ID)
	private WebElement debtorSearchBtn;

	@FindBy(id = DEBTORRESETBTN_ID)
	private WebElement debtorResetBtn;

	@FindBy(id = DEBTORGRIDDIV_ID)
	private WebElement debtorGridDiv;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = GLOBALAGRMNTCHKBOX_ID)
	private WebElement globalAgrmntChkBox;

	@FindBy(id = AGRMNTNAME_ID)
	private WebElement agrmntName;

	@FindBy(id = AGRMNTNAMEAR_ID)
	private WebElement agrmntNameAr;

	@FindBy(id = AGRMNTSIGNEDDATE_ID)
	private WebElement agrmntSignedDate;

	@FindBy(id = AGRMNTSTARTDATE_ID)
	private WebElement agrmntStartDate;

	@FindBy(id = AGRMNTENDDATE_ID)
	private WebElement agrmntEndDate;

	@FindBy(id = EXPNOTIFVALUE_ID)
	private WebElement expNotifValue;

	@FindBy(id = EXPNOTIFTYPE_ID)
	private WebElement expNotifType;

	@FindBy(id = GRACEPERIODAPPL_ID)
	private WebElement gracePeriodApplChkBox;

	@FindBy(id = GRACEPERIODVALUE_ID)
	private WebElement gracePeriodValue;

	@FindBy(id = GRACEPERIODTYPE_ID)
	private WebElement gracePeriodType;

	public WebElement getAgrmntCode() {
		return agrmntCode;
	}

	public boolean isMandAgrmntRefNumber() {
		waitForElementId(AGREEMENTREFNO_ID);
		return isMandatoryField(agrmntRefNum);
	}

	public boolean isMandAgrmntBillingType() {
		waitForElementId(AGREEMENTBILLINGTYPE_ID);
		return isMandatoryField(agrmntBillingType);
	}

	public boolean isMandDebtorName() {
		waitForElementId(DEBTORNAMETXT_ID);
		return isMandatoryField(debtorNameText);
	}

	public boolean isMandMBUName() {
		waitForElementId(MBU_ID);
		return isMandatoryField(mbu);
	}

	public boolean isMandAgreementName() {
		waitForElementId(AGRMNTNAME_ID);
		return isMandatoryField(agrmntName);
	}

	public void fillData(String[] debtorAgrmntListData) throws Exception {
		waitForElementId(AGREEMENTREFNO_ID);
		sleepLong();
		agrmntRefNum.clear();
		agrmntRefNum.sendKeys(debtorAgrmntListData[0]);
		if (!debtorAgrmntListData[1].isEmpty()) {
			new Select(agrmntBillingType)
					.selectByVisibleText(debtorAgrmntListData[1]);
		}
		if (!debtorAgrmntListData[2].isEmpty()) {
			new Select(agrmntType).selectByVisibleText(debtorAgrmntListData[2]);
		}
		debtorNameLookup.click();
		sleepVeryShort();
		waitForElementId(DEBTORNAMELOOKUPFORM_ID);
		if (!debtorAgrmntListData[3].isEmpty()) {
			new Select(mbuList).selectByVisibleText(debtorAgrmntListData[3]);
		}
		if (Boolean.valueOf(debtorAgrmntListData[4])) {
			globalDebtorChkBox.click();
		}
		if (!debtorAgrmntListData[5].isEmpty()) {
			new Select(debtorType).selectByVisibleText(debtorAgrmntListData[5]);
		}
		if (!debtorAgrmntListData[6].isEmpty()) {
			new Select(debtorCategory)
					.selectByVisibleText(debtorAgrmntListData[6]);
		}
		debtorName.clear();
		debtorName.sendKeys(debtorAgrmntListData[7]);
		debtorSearchBtn.click();
		sleepShort();
		waitForElementId(DEBTORGRIDDIV_ID);
		clickOnGridAction("AGMNT_DEBT_DETAILS_GRID_debtorName",
				debtorAgrmntListData[7], "Select");
		sleepVeryShort();
		if (!debtorAgrmntListData[3].isEmpty()) {
			new Select(mbu).selectByVisibleText(debtorAgrmntListData[3]);
		}
		if (Boolean.valueOf(debtorAgrmntListData[8])) {
			globalAgrmntChkBox.click();
		}
		agrmntName.clear();
		agrmntName.sendKeys(debtorAgrmntListData[9]);
		agrmntNameAr.clear();
		agrmntNameAr.sendKeys(debtorAgrmntListData[10]);
		agrmntSignedDate.clear();
		agrmntSignedDate.sendKeys(DateTimeConverter.currentISTDateFormat());
		agrmntStartDate.clear();
		agrmntStartDate.sendKeys(DateTimeConverter.currentISTDateFormat());
		agrmntEndDate.clear();
		agrmntEndDate.sendKeys(debtorAgrmntListData[13]);
		expNotifValue.clear();
		expNotifValue.sendKeys(debtorAgrmntListData[14]);
		if (!debtorAgrmntListData[15].isEmpty()) {
			new Select(expNotifType)
					.selectByVisibleText(debtorAgrmntListData[15]);
		}
		if (Boolean.valueOf(debtorAgrmntListData[16])) {
			gracePeriodApplChkBox.click();
		}
		gracePeriodValue.clear();
		gracePeriodValue.sendKeys(debtorAgrmntListData[17]);
		if (!debtorAgrmntListData[18].isEmpty()) {
			new Select(gracePeriodType)
					.selectByVisibleText(debtorAgrmntListData[18]);
		}
		String[] temp;
		String delimiter = "\\,";
		temp = debtorAgrmntListData[19].split(delimiter);
		for (int i = 0; i < temp.length; i++) {
			webDriver
					.findElement(
							By.xpath("//input[@name='multiselect_AGMNT_CRAGE' and @title='"
									+ temp[i] + "']")).click();
		}

	}
	
	public String getSelectedMBU() {
		return new Select(mbu).getFirstSelectedOption().getText();
	}

	public WebElement getAgrmntRefNum() {
		return agrmntRefNum;
	}

	public WebElement getAgrmntBillingType() {
		return agrmntBillingType;
	}

	public WebElement getAgrmntType() {
		return agrmntType;
	}

	public WebElement getDebtorNameText() {
		return debtorNameText;
	}

	public WebElement getDebtorNameLookup() {
		return debtorNameLookup;
	}

	public WebElement getDebtorNameLookupForm() {
		return debtorNameLookupForm;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalDebtorChkBox() {
		return globalDebtorChkBox;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getDebtorCategory() {
		return debtorCategory;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorSearchBtn() {
		return debtorSearchBtn;
	}

	public WebElement getDebtorResetBtn() {
		return debtorResetBtn;
	}

	public WebElement getDebtorGridDiv() {
		return debtorGridDiv;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getGlobalAgrmntChkBox() {
		return globalAgrmntChkBox;
	}

	public WebElement getAgrmntName() {
		return agrmntName;
	}

	public WebElement getAgrmntNameAr() {
		return agrmntNameAr;
	}

	public WebElement getAgrmntSignedDate() {
		return agrmntSignedDate;
	}

	public WebElement getAgrmntStartDate() {
		return agrmntStartDate;
	}

	public WebElement getAgrmntEndDate() {
		return agrmntEndDate;
	}

	public WebElement getExpNotifValue() {
		return expNotifValue;
	}

	public WebElement getExpNotifType() {
		return expNotifType;
	}

	public WebElement getGracePeriodApplChkBox() {
		return gracePeriodApplChkBox;
	}

	public WebElement getGracePeriodValue() {
		return gracePeriodValue;
	}

	public WebElement getGracePeriodType() {
		return gracePeriodType;
	}

	

}
