package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.preg.admin.PatientMergePage;
import com.atk.himma.pageobjects.preg.admin.tabs.PatientMergeTab;
import com.atk.himma.pageobjects.preg.admin.tabs.ViewMergedPatientInformationTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class PatientMergeTest extends SeleniumDriverSetup {
	List<String[]> pregDatas;
	PatientMergePage patientMergePage;
	LoginPage loginPage;

	@Test(description = "Open Patient Merge Page")
	public void openPatientMergePage() {
		patientMergePage = PageFactory.initElements(webDriver,
				PatientMergePage.class);
		patientMergePage = patientMergePage.clickOnPatientMergeMenu(webDriver,
				webDriverWait);
		patientMergePage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		patientMergePage.waitForElementId(PatientMergeTab.getGridtableId());
		Assert.assertEquals(patientMergePage.getPageTitle().getText().trim(),
				"Patient Merge");
	}

	// [Patient Merge] Open Form
	@Test(description = "Open Patient Merge Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkPatMergeMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		patientMergePage = PageFactory.initElements(webDriver,
				PatientMergePage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		baseLVParentMenuList.add("Admin ");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"Patient Merge");
		patientMergePage.setWebDriver(webDriver);
		patientMergePage.setWebDriverWait(webDriverWait);
		patientMergePage
				.waitForElementXpathExpression(PatientMergePage.MENULINK_XPATH);
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("Patient Merge")
				.get("[Patient Merge] Open Form");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PatientMergePage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Merge] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			patientMergePage = patientMergePage.clickOnPatientMergeMenu(
					webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(patientMergePage);
			patientMergePage.waitForElementId(PatientMergePage.FORMNAME_ID);
			patientMergePage.sleepShort();
			Assert.assertEquals(patientMergePage.getPageTitle().getText(),
					"Patient Merge");
		}
	}

	@Test(dependsOnMethods = { "openPatientMergePage" }, description = "Search Patient")
	public void test1SearchPatient() throws IOException {

		patientMergePage.searchPatient(mergePatients[2].trim());
		Assert.assertEquals(
				patientMergePage
						.getPatientMergeTab()
						.waitForGridFirstDuplicateCellText(
								PatientMergeTab.getGridtableId(),
								PatientMergeTab
										.getMultiselvalPatientnameAriadescribedby())
						.contains(mergePatients[2].trim()), true);
	}

	@Test(dependsOnMethods = { "test1SearchPatient" }, description = "Merge Patients")
	public void test2MergePatients() {
		patientMergePage.mergePatients(mergePatients[0].trim(),
				mergePatients[1].trim(),
				PatientMergeTab.getMultiselvalMrnAriadescribedby());
		patientMergePage
				.waitForElementXpathExpression(PatientMergePage.MERGECONFMSG_XPATH);
		Assert.assertEquals(
				patientMergePage
						.getStatusMessage()
						.getText()
						.contains(
								"merged successfully. The new MRN is : ("
										+ mergePatients[0].trim() + ")"), true);
	}

	@Test(dependsOnMethods = { "test2MergePatients" }, description = "Search Merge Patients")
	public void test3SearchMergePatients() throws InterruptedException {
		Assert.assertEquals(patientMergePage.searchMergePatients(
				mergePatients[0].trim(), mergePatients[1].trim()), true);
	}

	@Test(description = "Sign Out", dependsOnMethods = "test3SearchMergePatients")
	public void test4SignOut() throws Exception {
		loginPage = patientMergePage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "test4SignOut")
	public void test5Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(10,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}
	
//	[Patient Merge Tab] Merge
	@Test(dependsOnMethods = { "checkPatMergeMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Merge Button privileges")
	public void checkMergeButtonPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Merge")
				.get("[Patient Merge Tab] Merge");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PatientMergeTab.MEARGEBUTTON_ID));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Patient Merge Tab] Merge");
	}
	
//	[View Merged Patient Information Tab] View
	@Test(dependsOnMethods = { "checkPatMergeMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking View Merged Patient Information Tab privileges")
	public void checkViewMergeTabPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Merge")
				.get("[View Merged Patient Information Tab] View");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ViewMergedPatientInformationTab.VIEWMERGEPATIENTINFOTAB_XPATH));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [View Merged Patient Information Tab] View");
	}
}
