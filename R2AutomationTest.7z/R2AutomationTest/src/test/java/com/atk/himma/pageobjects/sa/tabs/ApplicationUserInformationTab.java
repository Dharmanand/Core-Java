package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.RecordStatus;
import com.atk.himma.util.DriverWaitClass;

public class ApplicationUserInformationTab extends DriverWaitClass {
	private AppUserDefaultSection defaultSection;
	private RecordStatus status;
	private AppUserIdentifiersSection identifiersSection;
	private AppUserProfessionalDetailsSection professionalDetailsSection;
	private ContactDetailsSection contactDetailsSection;
	private AppUserCredentialsSection credentialsSection;

	public final static String AUDITTRAIL_ID = "auditViewId_title";

	@FindBy(id = AUDITTRAIL_ID)
	private WebElement auditTrail;

	public void initAllSections(WebDriver webDriver, WebDriverWait webDriverWait) {
		defaultSection = PageFactory.initElements(webDriver,
				AppUserDefaultSection.class);
		defaultSection.setWebDriver(webDriver);
		defaultSection.setWebDriverWait(webDriverWait);

		status = PageFactory.initElements(webDriver, RecordStatus.class);
		status.setWebDriver(webDriver);
		status.setWebDriverWait(webDriverWait);

		identifiersSection = PageFactory.initElements(webDriver,
				AppUserIdentifiersSection.class);
		identifiersSection.setWebDriver(webDriver);
		identifiersSection.setWebDriverWait(webDriverWait);

		professionalDetailsSection = PageFactory.initElements(webDriver,
				AppUserProfessionalDetailsSection.class);
		professionalDetailsSection.setWebDriver(webDriver);
		professionalDetailsSection.setWebDriverWait(webDriverWait);

		contactDetailsSection = PageFactory.initElements(webDriver,
				ContactDetailsSection.class);
		contactDetailsSection.setWebDriver(webDriver);
		contactDetailsSection.setWebDriverWait(webDriverWait);

		credentialsSection = PageFactory.initElements(webDriver,
				AppUserCredentialsSection.class);
		credentialsSection.setWebDriver(webDriver);
		credentialsSection.setWebDriverWait(webDriverWait);
	}

	public AppUserDefaultSection getDefaultSection() {
		return defaultSection;
	}

	public RecordStatus getStatus() {
		return status;
	}

	public AppUserIdentifiersSection getIdentifiersSection() {
		return identifiersSection;
	}

	public AppUserProfessionalDetailsSection getProfessionalDetailsSection() {
		return professionalDetailsSection;
	}

	public ContactDetailsSection getContactDetailsSection() {
		return contactDetailsSection;
	}

	public AppUserCredentialsSection getCredentialsSection() {
		return credentialsSection;
	}

	public WebElement getAuditTrail() {
		return auditTrail;
	}

}
