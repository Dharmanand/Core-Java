package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class JobInformationTab extends DriverWaitClass {
	public final static String CREATEJOBFORM_ID = "FORM_SAVE_ROLES";
	@FindBy(id = CREATEJOBFORM_ID)
	private WebElement createJobForm;

	public final static String ADDNEWJOBBTN_XPATH = "//form[@id='FORM_SAVE_ROLES']//input[@value='Add New Job']";
	@FindBy(xpath = ADDNEWJOBBTN_XPATH)
	private WebElement addNewJobBtn;

	public final static String SAVEBTN_XPATH = "//input[@value='Save']";
	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	public final static String CANCELBTN_XPATH = "//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String UPDATEBTN_XPATH = "//input[@value='Update']";
	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	public final static String JOBNAME_NAME = "roleInfo.roleName";
	@FindBy(name = JOBNAME_NAME)
	private WebElement jobName;

	public final static String ROOTORGUNIT_ID = "RADIO_BUTTON1";
	@FindBy(id = ROOTORGUNIT_ID)
	private WebElement rootOrgUnit;

	public final static String MAINBUSINESSUNIT_ID = "RADIO_BUTTON2";
	@FindBy(id = MAINBUSINESSUNIT_ID)
	private WebElement mainBusinessUnit;

	public final static String MAINBUSINESSUNITNAME_ID = "MAIN_BUSINESSUNIT_LIST";
	@FindBy(id = MAINBUSINESSUNITNAME_ID)
	private WebElement mainBusinessUnitName;

	public final static String MODULENAME_ID = "moduleCombo";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String SRC_ID = "src";
	@FindBy(id = SRC_ID)
	private WebElement src;

	public final static String DEST_ID = "dest";
	@FindBy(id = DEST_ID)
	private WebElement dest;

	public final static String SRCTODEST_ID = "srctodest";
	@FindBy(id = SRCTODEST_ID)
	private WebElement srctodest;

	public final static String DESTTOSRC_ID = "desttosrc";
	@FindBy(id = DESTTOSRC_ID)
	private WebElement desttosrc;

	public final static String JOBDESCRIPTION_NAME = "roleInfo.roleDesc";
	@FindBy(name = JOBDESCRIPTION_NAME)
	private WebElement jobDescription;

	public final static String AUDITTRAIL = "auditViewId_title";
	@FindBy(id = AUDITTRAIL)
	private WebElement auditTrail;

	public void addNewJob(String[] jobsData) throws Exception {
		waitForElementName(JOBNAME_NAME);
		if (!jobsData[0].isEmpty()) {
			jobName.clear();
			jobName.sendKeys(jobsData[0]);

			if (jobsData[1].isEmpty()) {
				rootOrgUnit.click();
			}
			selectModulePrivileges(jobsData);

		} else {
			if (!jobsData[1].isEmpty()) {
				mainBusinessUnit.click();
			}
			selectModulePrivileges(jobsData);
		}
		sleepShort();
	}

	public void saveJobs() throws InterruptedException {
		waitForElementXpathExpression(SAVEBTN_XPATH);
		saveBtn.click();
		waitForElementXpathExpression(UPDATEBTN_XPATH);
		sleepVeryShort();
	}

	private void selectModulePrivileges(String[] jobsData)
			throws InterruptedException {
		waitForElementId(MAINBUSINESSUNITNAME_ID);
		if (mainBusinessUnitName.isEnabled())
			new Select(mainBusinessUnitName).selectByVisibleText(jobsData[1]);
		waitForElementId(MODULENAME_ID);
		new Select(moduleName).selectByVisibleText(jobsData[2]);
		sleepShort();
		new Select(src).selectByVisibleText(jobsData[3].trim() + "("
				+ jobsData[2] + ")");
		sleepVeryShort();
		srctodest.click();
	}

	public void clickAddNewJob() throws Exception {
		addNewJobBtn.click();
		sleepShort();
	}

	public void clickOnCancel() throws Exception {
		cancelBtn.click();
		sleepShort();
	}

	public void updateJob(String[] editJobsData) throws Exception {
		waitForElementName(JOBNAME_NAME);
		/*
		 * new Select(moduleName).selectByVisibleText(editJobsData[2]);
		 * sleepVeryShort(); new
		 * Select(src).selectByVisibleText(editJobsData[3].trim() + "(" +
		 * editJobsData[2] + ")");
		 */
		selectModulePrivileges(editJobsData);
		sleepVeryShort();
		srctodest.click();
	}

	public void clickOnUpdateButton() throws InterruptedException {
		sleepVeryShort();
		updateBtn.click();
	}

	public WebElement getCreateJobForm() {
		return createJobForm;
	}

	public WebElement getAddNewJobBtn() {
		return addNewJobBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getJobName() {
		return jobName;
	}

	public WebElement getRootOrgUnit() {
		return rootOrgUnit;
	}

	public WebElement getMainBusinessUnit() {
		return mainBusinessUnit;
	}

	public WebElement getMainBusinessUnitName() {
		return mainBusinessUnitName;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getSrc() {
		return src;
	}

	public WebElement getDest() {
		return dest;
	}

	public WebElement getSrctodest() {
		return srctodest;
	}

	public WebElement getDesttosrc() {
		return desttosrc;
	}

	public WebElement getJobDescription() {
		return jobDescription;
	}

	public WebElement getAuditTrail() {
		return auditTrail;
	}

}
