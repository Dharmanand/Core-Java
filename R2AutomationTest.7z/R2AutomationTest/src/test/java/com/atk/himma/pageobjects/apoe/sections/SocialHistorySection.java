package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SocialHistorySection extends DriverWaitClass {
	public final static String SOCIALHISTORYSEC_XPATH = "//a[text()='Social History']";
	@FindBy(xpath = SOCIALHISTORYSEC_XPATH)
	private WebElement socialHistorySec;

	public final static String ALCOHOLCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.alcohol";
	@FindBy(name = ALCOHOLCHKBOX_NAME)
	private WebElement alcoholChkBox;

	public final static String ALCOHOLTEXT_NAME = "consultationSummary.histroy.socialHistroy.alcoholText";
	@FindBy(name = ALCOHOLTEXT_NAME)
	private WebElement alcoholTextBox;

	public final static String TOBACCOCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.tobacco";
	@FindBy(name = TOBACCOCHKBOX_NAME)
	private WebElement tobaccoChkBox;

	public final static String TOBACCOTEXT_NAME = "consultationSummary.histroy.socialHistroy.tobaccoText";
	@FindBy(name = TOBACCOTEXT_NAME)
	private WebElement tobaccoTextBox;

	public final static String TRAVELCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.travel";
	@FindBy(name = TRAVELCHKBOX_NAME)
	private WebElement travelChkBox;

	public final static String TRAVELTEXT_NAME = "consultationSummary.histroy.socialHistroy.travelText";
	@FindBy(name = TRAVELTEXT_NAME)
	private WebElement travelTextBox;

	public final static String LICITDRUGSCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.licitDrugs";
	@FindBy(name = LICITDRUGSCHKBOX_NAME)
	private WebElement licitDrugsChkBox;

	public final static String LICITDRUGSTEXT_NAME = "consultationSummary.histroy.socialHistroy.licitDrugsText";
	@FindBy(name = LICITDRUGSTEXT_NAME)
	private WebElement licitDrugsTextBox;

	public final static String LIVESWITHCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.livesWith";
	@FindBy(name = LIVESWITHCHKBOX_NAME)
	private WebElement livesWithChkBox;

	public final static String LIVESWITHTEXT_NAME = "consultationSummary.histroy.socialHistroy.livesWithText";
	@FindBy(name = LIVESWITHTEXT_NAME)
	private WebElement livesWithTextBox;

	public final static String OCCUPATION_NAME = "consultationSummary.histroy.socialHistroy.occupation";
	@FindBy(name = OCCUPATION_NAME)
	private WebElement occupation;

	public final static String HIVRISKFACTORSCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.hivRiskFactor";
	@FindBy(name = HIVRISKFACTORSCHKBOX_NAME)
	private WebElement hivRiskFactorsChkBox;

	public final static String HIVRISKFACTORSTEXT_NAME = "consultationSummary.histroy.socialHistroy.hivRiskFactorText";
	@FindBy(name = HIVRISKFACTORSTEXT_NAME)
	private WebElement hivRiskFactorsTextBox;

	public final static String COUNCELEDCESSCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.counseledCessation";
	@FindBy(name = COUNCELEDCESSCHKBOX_NAME)
	private WebElement counceledCessChkBox;

	public final static String PETSCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.pets";
	@FindBy(name = PETSCHKBOX_NAME)
	private WebElement petsChkBox;

	public final static String PETSTEXT_NAME = "consultationSummary.histroy.socialHistroy.petsText";
	@FindBy(name = PETSTEXT_NAME)
	private WebElement petsTextBox;

	public final static String HOBBIESCHKBOX_NAME = "consultationSummary.histroy.socialHistroy.hobbies";
	@FindBy(name = HOBBIESCHKBOX_NAME)
	private WebElement hobbiesChkBox;

	public final static String HOBBIESTEXT_NAME = "consultationSummary.histroy.socialHistroy.hobbiesText";
	@FindBy(name = HOBBIESTEXT_NAME)
	private WebElement hobbiesTextBox;

	public boolean checkSocialHistorySec() {
		return socialHistorySec.isDisplayed();
	}

	public void fillSocialHistoryInfo(String[] outPatientListData) {
		if (Boolean.valueOf(outPatientListData[51])) {
			alcoholChkBox.click();
			alcoholTextBox.clear();
			alcoholTextBox.sendKeys(outPatientListData[52]);
		}
		occupation.clear();
		occupation.sendKeys(outPatientListData[53]);
		if (Boolean.valueOf(outPatientListData[54])) {
			tobaccoChkBox.click();
			tobaccoTextBox.clear();
			tobaccoTextBox.sendKeys(outPatientListData[55]);
		}
		if (Boolean.valueOf(outPatientListData[56])) {
			hivRiskFactorsChkBox.click();
			hivRiskFactorsTextBox.clear();
			hivRiskFactorsTextBox.sendKeys(outPatientListData[57]);
		}
		if (Boolean.valueOf(outPatientListData[58])) {
			travelChkBox.click();
			travelTextBox.clear();
			travelTextBox.sendKeys(outPatientListData[59]);
		}
		if (Boolean.valueOf(outPatientListData[60])) {
			counceledCessChkBox.click();
		}
		if (Boolean.valueOf(outPatientListData[61])) {
			licitDrugsChkBox.click();
			licitDrugsTextBox.clear();
			licitDrugsTextBox.sendKeys(outPatientListData[62]);
		}
		if (Boolean.valueOf(outPatientListData[63])) {
			petsChkBox.click();
			petsTextBox.clear();
			petsTextBox.sendKeys(outPatientListData[64]);
		}
		if (Boolean.valueOf(outPatientListData[65])) {
			livesWithChkBox.click();
			livesWithTextBox.clear();
			livesWithTextBox.sendKeys(outPatientListData[66]);
		}
		if (Boolean.valueOf(outPatientListData[67])) {
			hobbiesChkBox.click();
			hobbiesTextBox.clear();
			hobbiesTextBox.sendKeys(outPatientListData[68]);
		}

	}

	public WebElement getSocialHistorySec() {
		return socialHistorySec;
	}

	public WebElement getAlcoholChkBox() {
		return alcoholChkBox;
	}

	public WebElement getAlcoholTextBox() {
		return alcoholTextBox;
	}

	public WebElement getTobaccoChkBox() {
		return tobaccoChkBox;
	}

	public WebElement getTobaccoTextBox() {
		return tobaccoTextBox;
	}

	public WebElement getTravelChkBox() {
		return travelChkBox;
	}

	public WebElement getTravelTextBox() {
		return travelTextBox;
	}

	public WebElement getLicitDrugsChkBox() {
		return licitDrugsChkBox;
	}

	public WebElement getLicitDrugsTextBox() {
		return licitDrugsTextBox;
	}

	public WebElement getLivesWithChkBox() {
		return livesWithChkBox;
	}

	public WebElement getLivesWithTextBox() {
		return livesWithTextBox;
	}

	public WebElement getOccupation() {
		return occupation;
	}

	public WebElement getHivRiskFactorsChkBox() {
		return hivRiskFactorsChkBox;
	}

	public WebElement getHivRiskFactorsTextBox() {
		return hivRiskFactorsTextBox;
	}

	public WebElement getCounceledCessChkBox() {
		return counceledCessChkBox;
	}

	public WebElement getPetsChkBox() {
		return petsChkBox;
	}

	public WebElement getPetsTextBox() {
		return petsTextBox;
	}

	public WebElement getHobbiesChkBox() {
		return hobbiesChkBox;
	}

	public WebElement getHobbiesTextBox() {
		return hobbiesTextBox;
	}

}
