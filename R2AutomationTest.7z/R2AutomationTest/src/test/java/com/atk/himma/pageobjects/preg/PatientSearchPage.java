package com.atk.himma.pageobjects.preg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mrd.ManageMRVolPage;
import com.atk.himma.util.DriverWaitClass;

public class PatientSearchPage extends DriverWaitClass {

	public final static String PAGESEARCHIMG_XPATH = "//img[@title='Patient Search']";

	@FindBy(xpath = PAGESEARCHIMG_XPATH)
	private WebElement pageSearchImg;

	public final static String FORMNAME_ID = "PATIENT_SEARCH_FID";

	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	public final static String QUICKSEARCHTEXTFIELD_ID = "searchTextName";

	@FindBy(id = QUICKSEARCHTEXTFIELD_ID)
	private WebElement quickSearchTextField;

	public final static String SEARCHBUTTON_ID = "quickSearch";

	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;

	public final static String RESETBUTTON_ID = "quickSearchReset";

	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	public final static String STANDARDSEARCHBUTTON_ID = "stdSearch_popup";

	@FindBy(id = STANDARDSEARCHBUTTON_ID)
	private WebElement standardSearchButton;

	public final static String VIEWFAMILYTREE_ID = "patSearchFamilyTreeId";

	@FindBy(id = VIEWFAMILYTREE_ID)
	private WebElement viewFamilyTree;

	public final static String NEWREGISTRATION_ID = "newReg";

	@FindBy(id = NEWREGISTRATION_ID)
	private WebElement newRegistration;

	public final static String MALEGROUP_XPATH = "//legend[contains(text(), 'Male Group')]/..";

	@FindBy(xpath = MALEGROUP_XPATH)
	private WebElement maleGroupLabel;

	public final static String FEMALEGROUP_XPATH = "//legend[contains(text(), 'Female Group')]/..";

	@FindBy(xpath = FEMALEGROUP_XPATH)
	private WebElement FemaleGroupLabel;

	public final static String STDSEARCHPOPUPENABLE_XPATH = "//input[@id='stdSearch_popup' and @class='FloatingContainerSH FloatingContainerSH_Active']";

	@FindBy(xpath = STDSEARCHPOPUPENABLE_XPATH)
	private WebElement stdSearchpopupEnable;

	public final static String STDSEARCHPOPUPDISABLE_XPATH = "//input[@id='stdSearch_popup' and @class='FloatingContainerSH']";

	@FindBy(xpath = STDSEARCHPOPUPENABLE_XPATH)
	private WebElement stdSearchpopupDisable;

	// ----------------------------------- Standard Search
	// Fields--------------------------------------

	public final static String REGISTRATIONTYPE_NAME = "patientStdSearch.iregType";

	@FindBy(name = REGISTRATIONTYPE_NAME)
	private WebElement registrationType;

	public final static String PATIENTTYPE_NAME = "patientStdSearch.ipatientType";

	@FindBy(name = PATIENTTYPE_NAME)
	private WebElement patientType;

	public final static String MRN_NAME = "patientStdSearch.smrNumber";

	@FindBy(name = MRN_NAME)
	private WebElement MRN;

	public final static String STAFFID_NAME = "patientStdSearch.sstaffId";

	@FindBy(name = STAFFID_NAME)
	private WebElement staffID;

	public final static String PATIENTNAME_NAME = "patientStdSearch.patientName";

	@FindBy(name = PATIENTNAME_NAME)
	private WebElement patientName;

	public final static String PATIENTNAMEARABIC_NAME = "patientStdSearch.patientNameAr";

	@FindBy(name = PATIENTNAMEARABIC_NAME)
	private WebElement patientNameArabic;

	public final static String DATEOFBIRTH_ID = "dobStdSrh";

	@FindBy(id = DATEOFBIRTH_ID)
	private WebElement DateOfBirth;

	public final static String DATEOFBIRTHHIJRI_ID = "dobHijStdSrh";

	@FindBy(id = DATEOFBIRTH_ID)
	private WebElement dateOfBirthHijri;

	public final static String GENDER_ID = "STANDARD_SEARCH_GENDER";

	@FindBy(id = GENDER_ID)
	private WebElement gender;

	public final static String MARITALSTATUS_NAME = "patientStdSearch.imaritalSatus";

	@FindBy(name = MARITALSTATUS_NAME)
	private WebElement maritalStatus;

	public final static String NATIONALITY_NAME = "patientStdSearch.inationality";

	@FindBy(name = NATIONALITY_NAME)
	private WebElement nationality;

	public final static String RELIGION_NAME = "patientStdSearch.ireligion";

	@FindBy(name = RELIGION_NAME)
	private WebElement religion;

	public final static String TELEPHONEORMOBILECODE_NAME = "patientStdSearch.smob";

	@FindBy(name = TELEPHONEORMOBILECODE_NAME)
	private WebElement telephoneOrMobileCode;

	public final static String TELEPHONEORMOBILENO_NAME = "patientStdSearch.smobileNo";

	@FindBy(name = TELEPHONEORMOBILENO_NAME)
	private WebElement telephoneOrMobileNo;

	public final static String FATHERORMOTHERMRN_NAME = "patientStdSearch.kinsMrn";

	@FindBy(name = FATHERORMOTHERMRN_NAME)
	private WebElement FatherOrMotherMRN;

	public final static String IDENTIFICATIONDOCUMENT_NAME = "patientStdSearch.iidentityType";

	@FindBy(name = IDENTIFICATIONDOCUMENT_NAME)
	private WebElement identificationDocument;

	public final static String IDENTIFICATIONNO_NAME = "patientStdSearch.sidentityNo";

	@FindBy(name = IDENTIFICATIONNO_NAME)
	private WebElement identificationNo;

	public final static String STDSEARCHBUTTON_ID = "searchButtonId";

	@FindBy(id = STDSEARCHBUTTON_ID)
	private WebElement stdSearchButton;

	public final static String STDRESETBUTTON_XPATH = "//span[@class='buttoncontainer_mid']/..//input[@value='Reset']";

	@FindBy(xpath = STDRESETBUTTON_XPATH)
	private WebElement stdResetButton;

	// Grid Start -----------------------------------------------

	public final static String PATIENTSEARCHGRID_ID = "quick_grid";
	public final static String GRIDTITLE_XPATH = "//span[@class='ui-jqgrid-title']";

	@FindBy(id = PATIENTSEARCHGRID_ID)
	private WebElement patientSearchGrid;

	// public final static String GRID_ID = "motherGridId";
	public final static String GRID_GENDERORINFO_ARIA_DESCRIBEDBY = "quick_grid_";
	public final static String GRID_SMRNUMBER_ARIA_DESCRIBEDBY = "quick_grid_smrNumber";
	public final static String GRID_PATIENTNAME_ARIA_DESCRIBEDBY = "quick_grid_patientName";
	public final static String GRID_PATIENTNAMEAR_ARIA_DESCRIBEDBY = "quick_grid_patientNameAr";
	public final static String GRID_FORMATTEDAGE_ARIA_DESCRIBEDBY = "quick_grid_formattedAge";
	public final static String GRID_SIDENTITYNO_ARIA_DESCRIBEDBY = "quick_grid_sidentityNo";
	public final static String GRID_SMOBILENO_ARIA_DESCRIBEDBY = "quick_grid_smobileNo";
	public final static String GRID_SREGDATETIMETEXT_ARIA_DESCRIBEDBY = "quick_grid_sregDateTimeText";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "quick_grid_action";

	public final static String GRID_PAGER_ID = "sp_1_quick_grid_pager";

	@FindBy(id = GRID_PAGER_ID)
	private WebElement gridPager;

	// Grid End ------------------------------------------------

	public PatientSearchPage clickOnPatientSearchLogo(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		PatientSearchPage patientSearchPage = PageFactory.initElements(
				webDriver, PatientSearchPage.class);
		patientSearchPage.setWebDriver(webDriver);
		patientSearchPage.setWebDriverWait(webDriverWait);
		patientSearchPage.getPageSearchImg().click();
		return patientSearchPage;
	}

	public boolean doQuickSearchPage(String searchText)
			throws InterruptedException {
		waitForElementId(QUICKSEARCHTEXTFIELD_ID);
		// waitForElementId(PATIENTSEARCHGRID_ID);
		sleepShort();
		getQuickSearchTextField().sendKeys(searchText);
		getSearchButton().click();
		waitForElementXpathExpression(GRIDTITLE_XPATH);
		sleepShort();
		return searchDataInGrid(searchText);
	}

	public boolean doReset(String searchText) throws InterruptedException {
		sleepShort();
		getResetButton().click();
		waitForElementId(PATIENTSEARCHGRID_ID);
		sleepShort();
		if (getQuickSearchTextField().getAttribute("value").isEmpty()
				&& checkGridEmpty(PATIENTSEARCHGRID_ID, GRID_PAGER_ID))
			return true;
		else
			return false;

	}

	public boolean searchDataInGrid(String searchText) {
		try {
			waitForGridSearchText(searchText.trim());
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public GeneralRegistrationPage clickEditLinkInGrid(String searchText)
			throws InterruptedException {
		if (doQuickSearchPage(searchText)) {
			clickOnGridAction(searchText.trim(), "Edit");
			GeneralRegistrationPage genReg = PageFactory.initElements(
					webDriver, GeneralRegistrationPage.class);
			genReg.setWebDriver(webDriver);
			genReg.setWebDriverWait(webDriverWait);
			waitForElementVisibilityOf(genReg.getUpdateButton());
			waitForElementVisibilityOf(genReg.getNewRegistrationButton());
			return genReg;
		}
		return null;
	}

	public ViewGeneralRegistrationPage clickViewLinkInGrid(String searchText)
			throws InterruptedException {
		if (doQuickSearchPage(searchText)) {
			String mrnNO = waitAndGetGridFirstCellText(PATIENTSEARCHGRID_ID,
					GRID_SMRNUMBER_ARIA_DESCRIBEDBY, searchText);
			clickOnGridAction(searchText, "View");
			ViewGeneralRegistrationPage viewGenReg = PageFactory.initElements(
					webDriver, ViewGeneralRegistrationPage.class);
			viewGenReg.setWebDriver(webDriver);
			viewGenReg.setWebDriverWait(webDriverWait);
			waitForElementXpathExpression(ViewGeneralRegistrationPage
					.getEditbuttonXpath());
			waitForElementXpathExpression(ViewGeneralRegistrationPage
					.getMrnnoXpath());
			if (mrnNO.equals(viewGenReg.getMrnNo().getText().trim()))
				return viewGenReg;
			else
				return null;
		}
		return null;
	}

	public void clickSelectLinkInGridOfNewBorn(String searchText)
			throws InterruptedException {
		doQuickSearchPage(searchText);
		if (searchDataInGrid(searchText)) {
			clickOnGridAction(searchText, "Select");
			sleepVeryShort();
		}
	}

	public boolean checkManageMRVolumeLink(String searchText)
			throws InterruptedException {
		doQuickSearchPage(searchText);
		clickOnGridAction(searchText.trim(), "More");
		return waitForGridAction(searchText.trim(), "Manage MR Volume");
	}

	public ManageMRVolPage clickOnManageMRVolLink(String searchText)
			throws InterruptedException {
		// return pageTitle.getText();
		clickOnGridAction(searchText, "Manage MR Volume");
		sleepMedium();
		parentWindowHandle = webDriver.getWindowHandle();
//		WebDriver childDriver = null;
		for (String winHandle : webDriver.getWindowHandles()) {
			
			webDriver.switchTo().window(winHandle);
//			childDriver = Utility.getHandleToWindow(webDriver, webDriver.switchTo().window(winHandle).getTitle());
			
		}
		waitForElementXpathExpression(ManageMRVolPage.FORM_XPATH);
		waitForElementId(ManageMRVolPage.GRID_ID);
//		childDriver.close();
		return PageFactory.initElements(webDriver, ManageMRVolPage.class);
	}

	/**
	 * @return the pagesearchimgXpath
	 */
	public static String getPagesearchimgXpath() {
		return PAGESEARCHIMG_XPATH;
	}

	/**
	 * @return the pageSearchImg
	 */
	public WebElement getPageSearchImg() {
		return pageSearchImg;
	}

	/**
	 * @return the formnameId
	 */
	public static String getFormnameId() {
		return FORMNAME_ID;
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the quicksearchtextfieldId
	 */
	public static String getQuicksearchtextfieldId() {
		return QUICKSEARCHTEXTFIELD_ID;
	}

	/**
	 * @return the quickSearchTextField
	 */
	public WebElement getQuickSearchTextField() {
		return quickSearchTextField;
	}

	/**
	 * @return the searchbuttonId
	 */
	public static String getSearchbuttonId() {
		return SEARCHBUTTON_ID;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetbuttonId
	 */
	public static String getResetbuttonId() {
		return RESETBUTTON_ID;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the standardsearchbuttonId
	 */
	public static String getStandardsearchbuttonId() {
		return STANDARDSEARCHBUTTON_ID;
	}

	/**
	 * @return the standardSearchButton
	 */
	public WebElement getStandardSearchButton() {
		return standardSearchButton;
	}

	/**
	 * @return the viewfamilytreeId
	 */
	public static String getViewfamilytreeId() {
		return VIEWFAMILYTREE_ID;
	}

	/**
	 * @return the viewFamilyTree
	 */
	public WebElement getViewFamilyTree() {
		return viewFamilyTree;
	}

	/**
	 * @return the newregistrationId
	 */
	public static String getNewregistrationId() {
		return NEWREGISTRATION_ID;
	}

	/**
	 * @return the newRegistration
	 */
	public WebElement getNewRegistration() {
		return newRegistration;
	}

	/**
	 * @return the patientsearchgridId
	 */
	public static String getPatientsearchgridId() {
		return PATIENTSEARCHGRID_ID;
	}

	/**
	 * @return the patientSearchGrid
	 */
	public WebElement getPatientSearchGrid() {
		return patientSearchGrid;
	}

	/**
	 * @return the malegroupXpath
	 */
	public static String getMalegroupXpath() {
		return MALEGROUP_XPATH;
	}

	/**
	 * @return the maleGroupLabel
	 */
	public WebElement getMaleGroupLabel() {
		return maleGroupLabel;
	}

	/**
	 * @return the femalegroupXpath
	 */
	public static String getFemalegroupXpath() {
		return FEMALEGROUP_XPATH;
	}

	/**
	 * @return the femaleGroupLabel
	 */
	public WebElement getFemaleGroupLabel() {
		return FemaleGroupLabel;
	}

	/**
	 * @return the stdsearchpopupenableXpath
	 */
	public static String getStdsearchpopupenableXpath() {
		return STDSEARCHPOPUPENABLE_XPATH;
	}

	/**
	 * @return the stdSearchpopupEnable
	 */
	public WebElement getStdSearchpopupEnable() {
		return stdSearchpopupEnable;
	}

	/**
	 * @return the stdsearchpopupdisableXpath
	 */
	public static String getStdsearchpopupdisableXpath() {
		return STDSEARCHPOPUPDISABLE_XPATH;
	}

	/**
	 * @return the stdSearchpopupDisable
	 */
	public WebElement getStdSearchpopupDisable() {
		return stdSearchpopupDisable;
	}

	/**
	 * @return the registrationtypeName
	 */
	public static String getRegistrationtypeName() {
		return REGISTRATIONTYPE_NAME;
	}

	/**
	 * @return the registrationType
	 */
	public WebElement getRegistrationType() {
		return registrationType;
	}

	/**
	 * @return the patienttypeName
	 */
	public static String getPatienttypeName() {
		return PATIENTTYPE_NAME;
	}

	/**
	 * @return the patientType
	 */
	public WebElement getPatientType() {
		return patientType;
	}

	/**
	 * @return the mrnName
	 */
	public static String getMrnName() {
		return MRN_NAME;
	}

	/**
	 * @return the mRN
	 */
	public WebElement getMRN() {
		return MRN;
	}

	/**
	 * @return the staffidName
	 */
	public static String getStaffidName() {
		return STAFFID_NAME;
	}

	/**
	 * @return the staffID
	 */
	public WebElement getStaffID() {
		return staffID;
	}

	/**
	 * @return the patientnameName
	 */
	public static String getPatientnameName() {
		return PATIENTNAME_NAME;
	}

	/**
	 * @return the patientName
	 */
	public WebElement getPatientName() {
		return patientName;
	}

	/**
	 * @return the patientnamearabicName
	 */
	public static String getPatientnamearabicName() {
		return PATIENTNAMEARABIC_NAME;
	}

	/**
	 * @return the patientNameArabic
	 */
	public WebElement getPatientNameArabic() {
		return patientNameArabic;
	}

	/**
	 * @return the dateofbirthId
	 */
	public static String getDateofbirthId() {
		return DATEOFBIRTH_ID;
	}

	/**
	 * @return the dateOfBirth
	 */
	public WebElement getDateOfBirth() {
		return DateOfBirth;
	}

	/**
	 * @return the dateofbirthhijriId
	 */
	public static String getDateofbirthhijriId() {
		return DATEOFBIRTHHIJRI_ID;
	}

	/**
	 * @return the dateOfBirthHijri
	 */
	public WebElement getDateOfBirthHijri() {
		return dateOfBirthHijri;
	}

	/**
	 * @return the genderId
	 */
	public static String getGenderId() {
		return GENDER_ID;
	}

	/**
	 * @return the gender
	 */
	public WebElement getGender() {
		return gender;
	}

	/**
	 * @return the maritalstatusName
	 */
	public static String getMaritalstatusName() {
		return MARITALSTATUS_NAME;
	}

	/**
	 * @return the maritalStatus
	 */
	public WebElement getMaritalStatus() {
		return maritalStatus;
	}

	/**
	 * @return the nationalityName
	 */
	public static String getNationalityName() {
		return NATIONALITY_NAME;
	}

	/**
	 * @return the nationality
	 */
	public WebElement getNationality() {
		return nationality;
	}

	/**
	 * @return the religionName
	 */
	public static String getReligionName() {
		return RELIGION_NAME;
	}

	/**
	 * @return the religion
	 */
	public WebElement getReligion() {
		return religion;
	}

	/**
	 * @return the telephoneormobilecodeName
	 */
	public static String getTelephoneormobilecodeName() {
		return TELEPHONEORMOBILECODE_NAME;
	}

	/**
	 * @return the telephoneOrMobileCode
	 */
	public WebElement getTelephoneOrMobileCode() {
		return telephoneOrMobileCode;
	}

	/**
	 * @return the telephoneormobilenoName
	 */
	public static String getTelephoneormobilenoName() {
		return TELEPHONEORMOBILENO_NAME;
	}

	/**
	 * @return the telephoneOrMobileNo
	 */
	public WebElement getTelephoneOrMobileNo() {
		return telephoneOrMobileNo;
	}

	/**
	 * @return the fatherormothermrnName
	 */
	public static String getFatherormothermrnName() {
		return FATHERORMOTHERMRN_NAME;
	}

	/**
	 * @return the fatherOrMotherMRN
	 */
	public WebElement getFatherOrMotherMRN() {
		return FatherOrMotherMRN;
	}

	/**
	 * @return the identificationdocumentName
	 */
	public static String getIdentificationdocumentName() {
		return IDENTIFICATIONDOCUMENT_NAME;
	}

	/**
	 * @return the identificationDocument
	 */
	public WebElement getIdentificationDocument() {
		return identificationDocument;
	}

	/**
	 * @return the identificationnoName
	 */
	public static String getIdentificationnoName() {
		return IDENTIFICATIONNO_NAME;
	}

	/**
	 * @return the identificationNo
	 */
	public WebElement getIdentificationNo() {
		return identificationNo;
	}

	/**
	 * @return the stdsearchbuttonId
	 */
	public static String getStdsearchbuttonId() {
		return STDSEARCHBUTTON_ID;
	}

	/**
	 * @return the stdSearchButton
	 */
	public WebElement getStdSearchButton() {
		return stdSearchButton;
	}

	/**
	 * @return the stdresetbuttonXpath
	 */
	public static String getStdresetbuttonXpath() {
		return STDRESETBUTTON_XPATH;
	}

	/**
	 * @return the stdResetButton
	 */
	public WebElement getStdResetButton() {
		return stdResetButton;
	}

	/**
	 * @return the gridGenderorinfoAriaDescribedby
	 */
	public static String getGridGenderorinfoAriaDescribedby() {
		return GRID_GENDERORINFO_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridSmrnumberAriaDescribedby
	 */
	public static String getGridSmrnumberAriaDescribedby() {
		return GRID_SMRNUMBER_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridPatientnameAriaDescribedby
	 */
	public static String getGridPatientnameAriaDescribedby() {
		return GRID_PATIENTNAME_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridPatientnamearAriaDescribedby
	 */
	public static String getGridPatientnamearAriaDescribedby() {
		return GRID_PATIENTNAMEAR_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridFormattedageAriaDescribedby
	 */
	public static String getGridFormattedageAriaDescribedby() {
		return GRID_FORMATTEDAGE_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridSidentitynoAriaDescribedby
	 */
	public static String getGridSidentitynoAriaDescribedby() {
		return GRID_SIDENTITYNO_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridSmobilenoAriaDescribedby
	 */
	public static String getGridSmobilenoAriaDescribedby() {
		return GRID_SMOBILENO_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridSregdatetimetextAriaDescribedby
	 */
	public static String getGridSregdatetimetextAriaDescribedby() {
		return GRID_SREGDATETIMETEXT_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridActionAriaDescribedby
	 */
	public static String getGridActionAriaDescribedby() {
		return GRID_ACTION_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridPagerId
	 */
	public static String getGridPagerId() {
		return GRID_PAGER_ID;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

}
