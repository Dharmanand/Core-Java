package com.atk.himma.pageobjects.mbuadmin.sections.servicedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ServiceFirstSection extends DriverWaitClass{
	
	public final static String SERVICECODE_ID = "SERVICE_CODE";
	public final static String SERVICESHORTNAME_ID = "SERVICE_SHORT_NAME";
	public final static String SERVICE_NAME_ID = "SERVICE_NAME";
	public final static String SERMBU_ID = "SER_MBU_ID";
	public final static String DEPARTMENT_ID = "DEPARTMENT";
	public final static String SPECIALITY_ID = "SPECIALITY";
	public final static String SUBSPECIALITY_ID = "SUB_SPECIALITY";
	public final static String SERVICETYPE_ID = "SERVICE_TYPE";
	public final static String ISGLOBALSERVICE_ID = "IS_GLOBAL_SERVICE";
	
	@FindBy(id = SERVICECODE_ID)
	private WebElement serviceCode;
	
	@FindBy(id = SERVICESHORTNAME_ID)
	private WebElement serviceshortName;
	
	@FindBy(id = SERVICE_NAME_ID)
	private WebElement serviceName;
	
	@FindBy(id = SERMBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SPECIALITY_ID)
	private WebElement speciality;
	
	@FindBy(id = SUBSPECIALITY_ID)
	private WebElement subSpeciality;
	
	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;
	
	@FindBy(id = ISGLOBALSERVICE_ID)
	private WebElement isGlobalService;

	
	public boolean isMandatorySerShortName()
	{
		return isMandatoryField(serviceshortName);
	}
	
	public boolean isMandatoryServiceName()
	{
		return isMandatoryField(serviceName);
	}
	
	public boolean isMandatoryMBU()
	{
		return isMandatoryField(mbu);
	}
	
	public boolean isMandatoryServiceType()
	{
		return isMandatoryField(serviceType);
	}
	
	public boolean fillServiceFirstSecDatas(String[] serviceDatas)
	{
		serviceshortName.clear();
		serviceshortName.sendKeys(serviceDatas[9].trim());
		serviceName.clear();
		serviceName.sendKeys(serviceDatas[10].trim());
		if(!serviceDatas[0].isEmpty())
		new Select(mbu).selectByVisibleText(serviceDatas[0].trim());
		if(!serviceDatas[11].isEmpty())
		new Select(department).selectByVisibleText(serviceDatas[11].trim());
		if(!serviceDatas[12].isEmpty())
		new Select(speciality).selectByVisibleText(serviceDatas[12].trim());
		if(!serviceDatas[13].isEmpty())
		new Select(subSpeciality).selectByVisibleText(serviceDatas[13].trim());
		if(!serviceDatas[14].isEmpty())
		new Select(serviceType).selectByVisibleText(serviceDatas[14].trim());
		selectOrUnSelectCheckBox(serviceDatas[15].trim(), isGlobalService);
		return isGlobalService.isSelected() == Boolean.getBoolean(serviceDatas[15].trim());
	}
	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the serviceshortName
	 */
	public WebElement getServiceshortName() {
		return serviceshortName;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the speciality
	 */
	public WebElement getSpeciality() {
		return speciality;
	}

	/**
	 * @return the subSpeciality
	 */
	public WebElement getSubSpeciality() {
		return subSpeciality;
	}

	/**
	 * @return the serviceType
	 */
	public WebElement getServiceType() {
		return serviceType;
	}

	/**
	 * @return the isGlobalService
	 */
	public WebElement getIsGlobalService() {
		return isGlobalService;
	}
	
}
