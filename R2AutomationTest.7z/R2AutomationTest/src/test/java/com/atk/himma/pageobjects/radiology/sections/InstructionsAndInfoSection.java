package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InstructionsAndInfoSection {

	public final static String ADDROWBUTTON_ID = "addNewInstInfo";
	
//	-----------GRID--------------
	public final static String GRID_ID = "rsis_GRID";
	public final static String GRID_GENDER_ARIA_DESCRIBEDBY = "rsis_GRID_gender";
	public final static String GRID_STAGEVAL_ARIA_DESCRIBEDBY = "rsis_GRID_startAge.ageInDays";
	public final static String GRID_STAGEUNIT_ARIA_DESCRIBEDBY = "rsis_GRID_startAge.ageType";
	public final static String GRID_EDAGEVAL_ARIA_DESCRIBEDBY = "rsis_GRID_endAge.ageInDays";
	public final static String GRID_EDAGEUNIT_ARIA_DESCRIBEDBY = "rsis_GRID_endAge.ageType";
	public final static String GRID_INSTRUCTYPE_ARIA_DESCRIBEDBY = "rsis_GRID_instructionTypeIdText";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "rsis_GRID_action";
	public final static String GRID_PAGERID = "sp_1_rsis_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rsis_GRID_pager']";

//	-----------GRID's Fields--------------
	public final static String GENDERDD_CSS = "td[aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"'] select[name=gender]";
	public final static String STAGEVALUETXT_CSS = "td[aria-describedby='"+GRID_STAGEVAL_ARIA_DESCRIBEDBY+"'] input[name='startAge.ageInDays']";
	public final static String STAGEUNITDD_CSS = "td[aria-describedby='"+GRID_STAGEVAL_ARIA_DESCRIBEDBY+"'] select[name='startAge.ageType']";
	public final static String EDAGEVALTXT_CSS = "td[aria-describedby='"+GRID_EDAGEVAL_ARIA_DESCRIBEDBY+"'] select[name='endAge.ageInDays']";
	public final static String EDAGEUNITDD_CSS = "td[aria-describedby='"+GRID_EDAGEUNIT_ARIA_DESCRIBEDBY+"'] select[name='endAge.ageType']";
	public final static String INSTRUCTYPETXT_CSS = "td[aria-describedby='"+GRID_INSTRUCTYPE_ARIA_DESCRIBEDBY+"'] select[name='instructionTypeIdText']";
	public final static String ADDINSTRUCTIONACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/select/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Add Instruction']";
	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/select/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";
	public final static String DELETEACTION_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";
	public final static String EDITINSTRUCTIONACTION_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Edit Instruction']";
	public final static String EXAMINFO_ID = "EXAM_INFO_ID";

	@FindBy(id = ADDROWBUTTON_ID)
	private WebElement addRowButton;
	
	@FindBy(css = GENDERDD_CSS)
	private WebElement genderDD;
	
	@FindBy(css = STAGEVALUETXT_CSS)
	private WebElement stageValueTxt;
	
	@FindBy(css = STAGEUNITDD_CSS)
	private WebElement stageUnitDD;
	
	@FindBy(css = EDAGEVALTXT_CSS)
	private WebElement endAgeValTxt;
	
	@FindBy(css = EDAGEUNITDD_CSS)
	private WebElement endAgeUnitDD;
	
	@FindBy(css = INSTRUCTYPETXT_CSS)
	private WebElement instrucTypeTxt;
	
	@FindBy(xpath = ADDINSTRUCTIONACTION_GE_XPATH)
	private WebElement addInstruActionGE;
	
	@FindBy(xpath = DELETEACTION_GE_XPATH)
	private WebElement deleteActionGE;
	
	@FindBy(xpath = DELETEACTION_XPATH)
	private WebElement deleteAction;
	
	@FindBy(xpath = EDITINSTRUCTIONACTION_XPATH)
	private WebElement editInstrucAction;
	
	@FindBy(id = EXAMINFO_ID)
	private WebElement examInfo;
	
	/**
	 * @return the examInfo
	 */
	public WebElement getExamInfo() {
		return examInfo;
	}

	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the genderDD
	 */
	public WebElement getGenderDD() {
		return genderDD;
	}

	/**
	 * @return the stageValueTxt
	 */
	public WebElement getStageValueTxt() {
		return stageValueTxt;
	}

	/**
	 * @return the stageUnitDD
	 */
	public WebElement getStageUnitDD() {
		return stageUnitDD;
	}

	/**
	 * @return the endAgeValTxt
	 */
	public WebElement getEndAgeValTxt() {
		return endAgeValTxt;
	}

	/**
	 * @return the endAgeUnitDD
	 */
	public WebElement getEndAgeUnitDD() {
		return endAgeUnitDD;
	}

	/**
	 * @return the instrucTypeTxt
	 */
	public WebElement getInstrucTypeTxt() {
		return instrucTypeTxt;
	}

	/**
	 * @return the addInstruActionGE
	 */
	public WebElement getAddInstruActionGE() {
		return addInstruActionGE;
	}

	/**
	 * @return the deleteActionGE
	 */
	public WebElement getDeleteActionGE() {
		return deleteActionGE;
	}

	/**
	 * @return the deleteAction
	 */
	public WebElement getDeleteAction() {
		return deleteAction;
	}

	/**
	 * @return the editInstrucAction
	 */
	public WebElement getEditInstrucAction() {
		return editInstrucAction;
	}
	
}
