package com.atk.himma.pageobjects.mrd.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class MBUListTab extends DriverWaitClass implements
StatusMessages, TopControls, RecordStatus {
	
	public static final String MBUNAME_ID = "UNIT_NAME";
	public static final String MBUCODE_ID = "UNIT_CODE";
	public static final String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']/input[@value='Reset']";
	public static final String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']/input[@value='Search']";
	public static final String GRID_ID = "MR_LENGTH_SEARCH_GRID";
	public static final String GRID_MBUNAME_ARIA_DESCRIBEDBY = "MR_LENGTH_SEARCH_GRID_mainBusinessUnit.unitName";
	public static final String GRID_MBUCODE_ARIA_DESCRIBEDBY = "MR_LENGTH_SEARCH_GRID_mainBusinessUnit.unitCode";
	public final static String GRID_PAGERID = "sp_1_MR_LENGTH_SEARCH_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_MR_LENGTH_SEARCH_GRID_pager']";
	
	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;
	
	@FindBy(id = MBUCODE_ID)
	private WebElement mbuCode;
	
	@FindBy(id = RESETBUTTON_XPATH)
	private WebElement resetButton;
	
	@FindBy(id = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}
	
}
