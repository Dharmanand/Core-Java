package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RadServiceFirstSection {
	
	public final static String SERVICECODETXT_ID = "serviceCode";
	public final static String SPECIALTYDD_ID = "specialtyList";
	public final static String SERVNAMETXT_ID = "serviceName";
	public final static String SUBSPECIALTYDD_ID = "subSpecialtyList";
	public final static String DEPARTMENTDD_ID = "departmentListId";
	public final static String STATUS_CSS = "#RAD_SERVICE_SUBSPECIALTY ~ label[class='label_3'] + input";
	public final static String APPLICABLEFREQUENCY_ID = "frequencyNeeded";

	@FindBy(id = SERVICECODETXT_ID)
	private WebElement serviceCodeTxt;
	
	@FindBy(id = SPECIALTYDD_ID)
	private WebElement specialtyDD;
	
	@FindBy(id = SERVNAMETXT_ID)
	private WebElement servNameTxt;
	
	@FindBy(id = SUBSPECIALTYDD_ID)
	private WebElement subSpecialtyDD;
	
	@FindBy(id = DEPARTMENTDD_ID)
	private WebElement departmentDD;
	
	@FindBy(css = STATUS_CSS)
	private WebElement status;
	
	/**
	 * @return the serviceCodeTxt
	 */
	public WebElement getServiceCodeTxt() {
		return serviceCodeTxt;
	}

	/**
	 * @return the specialtyDD
	 */
	public WebElement getSpecialtyDD() {
		return specialtyDD;
	}

	/**
	 * @return the servNameTxt
	 */
	public WebElement getServNameTxt() {
		return servNameTxt;
	}

	/**
	 * @return the subSpecialtyDD
	 */
	public WebElement getSubSpecialtyDD() {
		return subSpecialtyDD;
	}

	/**
	 * @return the departmentDD
	 */
	public WebElement getDepartmentDD() {
		return departmentDD;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the applicableFrequency
	 */
	public WebElement getApplicableFrequency() {
		return applicableFrequency;
	}

	@FindBy(id = APPLICABLEFREQUENCY_ID)
	private WebElement applicableFrequency;
	
}
