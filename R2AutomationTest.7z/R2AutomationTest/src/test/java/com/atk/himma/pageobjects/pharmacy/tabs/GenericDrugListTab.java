package com.atk.himma.pageobjects.pharmacy.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GenericDrugListTab {

	public final static String FORM_ID = "GENERIC_DRUG_LIST_PAGE";
	public final static String SEARCHTXT_CSS = "#GENERIC_DRUG_QUICK_SEARCH + input";
	public final static String SEARCHBUTTON_CSS = "#GENERIC_DRUG_QUICK_SEARCH + input";
	public final static String RESETBUTTON_CSS = "#GENERIC_DRUG_QUICK_SEARCH ~ input[value='Reset']";
	public final static String ADVSEARCHBUTTON_ID = "GENERIC_DRUG_ADV_SEARCH";
	public final static String EXEXCELBUTTON_ID = "SEARCH_GENERIC_DRUG_LIST_export_btn";
	public final static String ADDNEWGENDRUGBUTTON_ID = "ADD_NEW_GENERIC_DRUG_BTN";

	public final static String GRID_ID = "SEARCH_GENERIC_DRUG_LIST";
	public final static String GRID_DRUGCODE_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_genericDrugCode";
	public final static String GRID_DRUGSHORTNAME_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_shortName";
	public final static String GRID_DRUGNAME_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_drugName";
	public final static String GRID_ANATOMMAINGRP_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_anatomicalMainGroupIdText";
	public final static String GRID_THERAPEUTICGROUP_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_therapeuticGroupIdText";
	public final static String GRID_PHARMASUBGROUP_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_pharmacologicalSubGroupIdText";
	public final static String GRID_CHEMSUBGROUP_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_chemicalSubGroupIdText";
	public final static String GRID_PAGERID = "sp_1_SEARCH_GENERIC_DRUG_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_GENERIC_DRUG_LIST_pager']";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = SEARCHTXT_CSS)
	private WebElement searchTxt;

	@FindBy(css = SEARCHBUTTON_CSS)
	private WebElement searchButton;

	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;

	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;

	@FindBy(id = EXEXCELBUTTON_ID)
	private WebElement exexcelButton;

	@FindBy(id = ADDNEWGENDRUGBUTTON_ID)
	private WebElement addNewGenDrugButton;

	@FindBy(id = GRID_ID)
	private WebElement grid;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the searchTxt
	 */
	public WebElement getSearchTxt() {
		return searchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the exexcelButton
	 */
	public WebElement getExexcelButton() {
		return exexcelButton;
	}

	/**
	 * @return the addNewGenDrugButton
	 */
	public WebElement getAddNewGenDrugButton() {
		return addNewGenDrugButton;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

}
