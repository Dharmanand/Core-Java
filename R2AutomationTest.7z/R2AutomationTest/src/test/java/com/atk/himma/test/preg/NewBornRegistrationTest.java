package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.preg.NewBornRegistrationPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.ExcelReader;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class NewBornRegistrationTest extends SeleniumDriverSetup {

	List<String[]> pregDatas;
	NewBornRegistrationPage newBornRegistrationPage;

	@Test(description = "Open New Born Registration Page")
	public void openNewBornRegPage() throws InterruptedException {
		newBornRegistrationPage = PageFactory.initElements(webDriver,
				NewBornRegistrationPage.class);
		newBornRegistrationPage = newBornRegistrationPage
				.clickOnNewBornRegMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		newBornRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);

		newBornRegistrationPage
				.waitForElementId(NewBornRegistrationPage.FORMNAME_ID);
		newBornRegistrationPage.sleepVeryShort();
		Assert.assertEquals(newBornRegistrationPage.getPageTitle().getText(),
				"New Born Registration");
	}

	// [New Born Registration] Open Form
	@Test(description = "Open General Registration Page Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkNewBornRegMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		newBornRegistrationPage = PageFactory.initElements(webDriver,
				NewBornRegistrationPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"New Born Registration");
		newBornRegistrationPage.setWebDriver(webDriver);
		newBornRegistrationPage.setWebDriverWait(webDriverWait);
		newBornRegistrationPage
				.waitForElementXpathExpression(NewBornRegistrationPage.MENULINK_XPATH);
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("NewBorn Registration")
				.get("[New Born Registration] Open Form");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(NewBornRegistrationPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [New Born Registration] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			newBornRegistrationPage = newBornRegistrationPage
					.clickOnNewBornRegMenu(webDriver, webDriverWait);
			newBornRegistrationPage.setInstanceOfAllSection(webDriver,
					webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(newBornRegistrationPage);
			newBornRegistrationPage
					.waitForElementId(NewBornRegistrationPage.FORMNAME_ID);
			newBornRegistrationPage.sleepShort();
			Assert.assertEquals(newBornRegistrationPage.getPageTitle()
					.getText(), "New Born Registration");
		}
	}

	@Test(dependsOnMethods = { "openNewBornRegPage" }, description = "Save New Born Registration Record")
	public void test1SaveNewBornRegPage() throws IOException, InterruptedException {
		ExcelReader excelReader = new ExcelReader();
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("newBornReg"));
		newBornRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas) {

			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.SAVEBUTTON_XPATH);
			newBornRegistrationPage = newBornRegistrationPage
					.saveNewBornRegPage(st, webDriver, webDriverWait);
			Assert.assertNotNull(newBornRegistrationPage);
			// newBornRegistrationPage
			// .waitForElementXpathExpression(NewBornRegistrationPage
			// .getSuccessmsgenable1timeXpath());
			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.MSGENABLE_XPATH);
			newBornRegistrationPage.sleepVeryShort();
			newBornRegistrationPage.activateRecord(
					NewBornRegistrationPage.ACTIVATE_ID,
					NewBornRegistrationPage.MAINSTATUSLABEL_ID);

			Assert.assertEquals(newBornRegistrationPage.getRegType().getText()
					.trim(), "NEW BORN");
			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.UPDATEBUTTON_XPATH);
			Assert.assertNotNull(newBornRegistrationPage.getUpdateButton(),
					"save successfully New Born. Reg. datas.");
		}
	}

	@Test(dependsOnMethods = { "test1SaveNewBornRegPage" }, description = "Update New Born Registration Record")
	public void test2UpdateNewBornRegPage() throws IOException, InterruptedException {
		ExcelReader excelReader = new ExcelReader();
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("updateNewBornReg"));
		newBornRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas) {
			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.UPDATEBUTTON_XPATH);
			newBornRegistrationPage = newBornRegistrationPage
					.updateNewBornRegPage(st, webDriver, webDriverWait);
			Assert.assertNotNull(newBornRegistrationPage);
			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.INACTIVATE_XPATH);
			newBornRegistrationPage.sleepVeryShort();
			Assert.assertEquals(newBornRegistrationPage.getRegType().getText()
					.trim(), "NEW BORN");
			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.UPDATEBUTTON_XPATH);
			newBornRegistrationPage
					.waitForElementXpathExpression(NewBornRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			Assert.assertNotNull(newBornRegistrationPage.getUpdateButton(),
					"Update successfully New Born Reg. datas.");
		}
	}

}
