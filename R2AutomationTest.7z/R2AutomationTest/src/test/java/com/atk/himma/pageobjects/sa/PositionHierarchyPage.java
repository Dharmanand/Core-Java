package com.atk.himma.pageobjects.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.tabs.PositionInformationTab;
import com.atk.himma.pageobjects.sa.tabs.PositionListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class PositionHierarchyPage extends DriverWaitClass implements
		StatusMessages, TopControls {
	private PositionListTab positionListTab;
	private PositionInformationTab positionInformationTab;
	private RecordStatus status;

	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Position Hierarchy')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;
	
	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		positionListTab = PageFactory.initElements(webDriver,
				PositionListTab.class);
		positionListTab.setWebDriver(webDriver);
		positionListTab.setWebDriverWait(webDriverWait);

		positionInformationTab = PageFactory.initElements(webDriver,
				PositionInformationTab.class);
		positionInformationTab.setWebDriver(webDriver);
		positionInformationTab.setWebDriverWait(webDriverWait);

		status = PageFactory.initElements(webDriver, RecordStatus.class);
		status.setWebDriver(webDriver);
		status.setWebDriverWait(webDriverWait);

	}

	public PositionHierarchyPage clickOnPositionHierarchyMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("System Administration");
		menuSelector.clickOnTargetMenu(menuList, "Position Hierarchy");
		PositionHierarchyPage positionHierarchyPage = PageFactory.initElements(
				webDriver, PositionHierarchyPage.class);
		positionHierarchyPage.setWebDriver(webDriver);
		positionHierarchyPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return positionHierarchyPage;
	}

	public String searchPosition(String posName) throws InterruptedException
	{
		waitForElementId(PositionListTab.POSITIONNAMECODE_ID);
		sleepVeryShort();
		positionListTab.searchGridData(posName);
		return waitAndGetGridFirstCellText(PositionListTab.GRID_ID, PositionListTab.GRID_ROLENAME_ARIA_DESCRIBEDBY, posName);
	}
	
	public PositionListTab getPositionListTab() {
		return positionListTab;
	}

	public PositionInformationTab getPositionInformationTab() {
		return positionInformationTab;
	}

	public RecordStatus getStatus() {
		return status;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

}
