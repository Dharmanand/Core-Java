package com.atk.himma.pageobjects.appointsched.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class BookTab extends DriverWaitClass implements StatusMessages,
		RecordStatus {
	public final static String FORMNAME_ID = "PATIENT_SEARCH_FID";
	String parentWindowHandle;
	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	public final static String RESCHEDULE_BUTTON_ID = "RESCHEDULE_APP_UP";

	@FindBy(id = RESCHEDULE_BUTTON_ID)
	private WebElement rescheduleButton;

	public final static String QUICKSEARCHTEXTFIELD_ID = "searchTextName";

	@FindBy(id = QUICKSEARCHTEXTFIELD_ID)
	private WebElement quickSearchTextField;

	public final static String SEARCHBUTTON_ID = "quickSearch";

	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;

	public final static String RESETBUTTON_ID = "quickSearchReset";

	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	public final static String STANDARDSEARCHBUTTON_ID = "stdSearch_popup";

	@FindBy(id = STANDARDSEARCHBUTTON_ID)
	private WebElement standardSearchButton;

	public final static String CANCELAPPOINT_ID = "CANCEL_APPOINTMENT_POPUP_BUTTON";

	@FindBy(id = CANCELAPPOINT_ID)
	private WebElement cancelAppointButton;

	public final static String PRINTAPPOINTSLIP_ID = "PRINT_APPSLIP";

	@FindBy(id = PRINTAPPOINTSLIP_ID)
	private WebElement printAppointSlipButton;

	public final static String PRINTAPPOINTSLIP_XPATH = "//form[@id='appBookFormId']//span[@class='buttoncontainer_vlrg_top']//input[@value='Back to Appointment Diary']";

	@FindBy(xpath = PRINTAPPOINTSLIP_XPATH)
	private WebElement backToAppointDairyButton;

	public final static String PICKFRMWLBUTTON_ID = "PICK_FROM_WAITLIST_ID";
	public final static String BACKTOAPPOINTMENT_ID = "BACK_TO_DAIRY";
	public final static String QUICKFINDTXT_ID = "//div[@id='PATIENT_SEARCH']//input[@value='Register Reserved Patient']";

	public final static String GRID_ID = "generalSearchGridId";
	public final static String GRID_MRNUMBER_ARIA_DESCRIBEDBY = "generalSearchGridId_smrNumber";
	public final static String GRID_PATIENTNAME_ARIA_DESCRIBEDBY = "generalSearchGridId_patientName";
	public final static String GRID_PATIENTNAMEAR_ARIA_DESCRIBEDBY = "generalSearchGridId_patientNameAr";
	public final static String GRID_FORMATTEDAGE_ARIA_DESCRIBEDBY = "generalSearchGridId_formattedAge";
	public final static String GRID_IDENTITYNO_ARIA_DESCRIBEDBY = "generalSearchGridId_sidentityNo";
	public final static String GRID_MOBILENO_ARIA_DESCRIBEDBY = "generalSearchGridId_smobileNo";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "generalSearchGridId_action";

	public final static String GRID_PAGER_ID = "sp_1_generalSearchGridId_pager";

	public final static String REGRESPATIENT_XPATH = "//div[@id='PATIENT_SEARCH']//input[@value='Register Reserved Patient']";

	// Booking Details

	public final static String SAVE_ID = "SAVE_UP";
	public final static String CANCEL_ID = "CANCEL_UP";
	public final static String VISITTYPE_ID = "VISIT_TYPE_ID";
	public final static String APPOINTTYPE_ID = "APP_TYPE_ID";
	public final static String SERVICE_ID = "SERVICE";
	public final static String PRICE_ID = "PRICE";

	public final static String PREVIOUSBUTTON_XPATH = "//div[@id='BookingDetails']//span[@class='buttoncontainer_vlrg_top']//input[@value='Previous']";

	@FindBy(xpath = PREVIOUSBUTTON_XPATH)
	private WebElement previousButton;

	public final static String NEXTBUTTON_XPATH = "//div[@id='BookingDetails']//span[@class='buttoncontainer_vlrg_top']//input[@value='Next']";

	@FindBy(xpath = NEXTBUTTON_XPATH)
	private WebElement nextButton;

	@FindBy(id = SAVE_ID)
	private WebElement saveBooking;

	@FindBy(id = CANCEL_ID)
	private WebElement cancel;

	@FindBy(id = VISITTYPE_ID)
	private WebElement visitType;

	@FindBy(id = APPOINTTYPE_ID)
	private WebElement appointType;

	@FindBy(id = SERVICE_ID)
	private WebElement service;

	@FindBy(id = PRICE_ID)
	private WebElement price;

	// Financial Details
	public final static String CREDITRADIOBUTTON_ID = "Credit";
	public final static String CASHRADIOBUTTON_ID = "Cash";
	public final static String FUTUREAPPOBUTTON_ID = "FIN_NEXT_APPOINTMENTS_POPUP_BUTTON";
	public final static String NOSHOWHISTBUTTON_ID = "FIN_NO_SHOW_DETAILS_POPUP_BUTTON";

	@FindBy(id = CREDITRADIOBUTTON_ID)
	private WebElement creditRadioButton;

	@FindBy(id = CASHRADIOBUTTON_ID)
	private WebElement cashRadioButton;

	@FindBy(id = FUTUREAPPOBUTTON_ID)
	private WebElement futureAppoButton;

	@FindBy(id = NOSHOWHISTBUTTON_ID)
	private WebElement noShowHisButton;
	//

	@FindBy(xpath = REGRESPATIENT_XPATH)
	private WebElement registerResPatient;

	@FindBy(id = GRID_PAGER_ID)
	private WebElement gridPager;

	@FindBy(id = PICKFRMWLBUTTON_ID)
	private WebElement pickFromWaitList;

	@FindBy(id = BACKTOAPPOINTMENT_ID)
	private WebElement backToAppointDiary;

	// Cancel Appointment Pop Up
	public final static String FORMCANCELAPPOINT_ID = "cancelappPopup";
	public final static String CANCELAPPOINTBUTTON_ID = "CANCEL_APPOINTMENT";

	@FindBy(id = CANCELAPPOINTBUTTON_ID)
	private WebElement cancelAppPopUpButton;

	// Select Service Lookup

	public final static String SELECTSERVICEDIV_ID = "SERVICE_POPUP_CONTENT";
	public final static String SELSER_NAME_ARIA_DESCRIBEDBY = "CONSULTATION_SERVICES_GRID_serviceName";
	public final static String SELSER_ACTION_ARIA_DESCRIBEDBY = "CONSULTATION_SERVICES_GRID_serviceId";

	public final static String SELSER_PAGER_ID = "sp_1_CONSULTATION_SERVICES_GRID_pager";

	@FindBy(id = MSGDIALOG_YES_ID)
	public WebElement msgDialogYesButton;

	@FindBy(id = MSGDIALOG_NO_ID)
	public WebElement msgDialogNoButton;

	public boolean doQuickSearchPage(String searchPatient, String serviceName)
			throws InterruptedException {
		waitForElementId(QUICKSEARCHTEXTFIELD_ID);
		sleepShort();
		getQuickSearchTextField().sendKeys(searchPatient);
		getSearchButton().click();
		waitForElementId(GRID_ID);
		checkGridEmpty(GRID_ID, GRID_PATIENTNAME_ARIA_DESCRIBEDBY);
		return selectDataInGrid(searchPatient, serviceName.trim());
	}

	public void doQuickSearchPage(String searchPatient)
			throws InterruptedException {
		waitForElementId(QUICKSEARCHTEXTFIELD_ID);
		sleepShort();
		getQuickSearchTextField().sendKeys(searchPatient);
		getSearchButton().click();
		waitForElementId(GRID_ID);
		checkGridEmpty(GRID_ID, GRID_PATIENTNAME_ARIA_DESCRIBEDBY);
		clickOnGridAction(searchPatient, "Select");
	}

	public AppointmentDairy saveBookingDetails() throws InterruptedException {
		sleepShort();
		waitForElementId(SAVE_ID);
		saveBooking.click();
		waitForElementXpathExpression(AppointmentDairy.MSGDIALOGYES_XPATH);
		sleepShort();
		AppointmentDairy appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.setWebDriver(webDriver);
		appointmentDairy.setWebDriverWait(webDriverWait);
		parentWindowHandle = webDriver.getWindowHandle();
		appointmentDairy.getYesMsgButton().click();
		sleepShort();
		return appointmentDairy;
	}

	public boolean checkAppointmentSlip() throws InterruptedException {

		for (String winHandle : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(winHandle);
		}
		String url = webDriver.getCurrentUrl();
		System.out.println("----------->>>>>>>>> " + url);

		AppointmentDairy appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.setWebDriver(webDriver);
		appointmentDairy.setWebDriverWait(new WebDriverWait(webDriver, 3));
		appointmentDairy.waitForElementId(AppointmentDairy.APPSLIPPAGE_ID);
		appointmentDairy.sleepShort();
		appointmentDairy.sleepShort();
		webDriver.close();
		webDriver.switchTo().window(parentWindowHandle);
		if (url.contains("/himma-appsched/reports/printAppslip.action"))
			return true;
		else
			return false;
	}

	public boolean selectDataInGrid(String searchText, String serviceName) {
		try {
			clickOnGridAction(searchText.trim(), "Select");
			try {
				new WebDriverWait(webDriver, 3).until(ExpectedConditions
						.presenceOfElementLocated(By.id(SELECTSERVICEDIV_ID)));
				clickOnGridAction(SELSER_NAME_ARIA_DESCRIBEDBY,
						serviceName.trim(), "Select");
				sleepVeryShort();
			} catch (Exception e) {
			}
			sleepVeryShort();
			waitForElementId(SAVE_ID);
			sleepVeryShort();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public AppointmentDairy clickOnReschButton() throws InterruptedException {
		waitForElementId(FORMNAME_ID);
		waitForElementId(RESCHEDULE_BUTTON_ID);
		rescheduleButton.click();
		waitForElementId(MSGDIALOG_YES_ID);
		msgDialogYesButton.click();
		waitForPageLoaded(webDriver);
		waitForElementId(AppointmentDairy.DAIRY_ID);
		AppointmentDairy appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.setWebDriver(webDriver);
		appointmentDairy.setWebDriverWait(webDriverWait);
		return appointmentDairy;
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the quickSearchTextField
	 */
	public WebElement getQuickSearchTextField() {
		return quickSearchTextField;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the standardSearchButton
	 */
	public WebElement getStandardSearchButton() {
		return standardSearchButton;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the registerResPatient
	 */
	public WebElement getRegisterResPatient() {
		return registerResPatient;
	}

	/**
	 * @return the pickFromWaitList
	 */
	public WebElement getPickFromWaitList() {
		return pickFromWaitList;
	}

	/**
	 * @return the backToAppointDiary
	 */
	public WebElement getBackToAppointDiary() {
		return backToAppointDiary;
	}

	/**
	 * @return the previousButton
	 */
	public WebElement getPreviousButton() {
		return previousButton;
	}

	/**
	 * @return the nextButton
	 */
	public WebElement getNextButton() {
		return nextButton;
	}

	/**
	 * @return the saveBooking
	 */
	public WebElement getSaveBooking() {
		return saveBooking;
	}

	/**
	 * @return the cancel
	 */
	public WebElement getCancel() {
		return cancel;
	}

	/**
	 * @return the visitType
	 */
	public WebElement getVisitType() {
		return visitType;
	}

	/**
	 * @return the appointType
	 */
	public WebElement getAppointType() {
		return appointType;
	}

	/**
	 * @return the service
	 */
	public WebElement getService() {
		return service;
	}

	/**
	 * @return the price
	 */
	public WebElement getPrice() {
		return price;
	}

	/**
	 * @return the creditRadioButton
	 */
	public WebElement getCreditRadioButton() {
		return creditRadioButton;
	}

	/**
	 * @return the cashRadioButton
	 */
	public WebElement getCashRadioButton() {
		return cashRadioButton;
	}

	/**
	 * @return the futureAppoButton
	 */
	public WebElement getFutureAppoButton() {
		return futureAppoButton;
	}

	/**
	 * @return the noShowHisButton
	 */
	public WebElement getNoShowHisButton() {
		return noShowHisButton;
	}

	/**
	 * @return the cancelAppointButton
	 */
	public WebElement getCancelAppointButton() {
		return cancelAppointButton;
	}

	/**
	 * @return the printAppointSlipButton
	 */
	public WebElement getPrintAppointSlipButton() {
		return printAppointSlipButton;
	}

	/**
	 * @return the backToAppointDairyButton
	 */
	public WebElement getBackToAppointDairyButton() {
		return backToAppointDairyButton;
	}

	/**
	 * @return the rescheduleButton
	 */
	public WebElement getRescheduleButton() {
		return rescheduleButton;
	}

	/**
	 * @return the cancelAppPopUpButton
	 */
	public WebElement getCancelAppPopUpButton() {
		return cancelAppPopUpButton;
	}
	
	/**
	 * @return the msgDialogNoButton
	 */
	public WebElement getMsgDialogNoButton() {
		return msgDialogNoButton;
	}
	
	/**
	 * @return the msgDialogNoButton
	 */
	public WebElement getMsgDialogYesButton() {
		return msgDialogYesButton;
	}

	
}
