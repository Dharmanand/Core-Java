package com.atk.himma.pageobjects.mrd;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PharmacyDesktopPage {

	public static final String FORM_ID = "IP_PHARMACY_DESKTOP";
	public static final String QUICKSEARCHTX_ID = "IP_QUICK_SEARCH_FIELD";
	public static final String SEARCHBUTTON_ID = "IP_QUICK_SEARCH_BUTTON";
	public static final String RESETBUTTON_ID = "IP_QUICK_RESET";
	public static final String ADVSEARCHBUTTON_ID = "IP_FLOTING_CRITERIA_PHARM_DESK_BT";
	public static final String ROUTINEUDDISPENBUTTON_ID = "ROUTINE_UD_DISPENSING";
	public static final String UNITDOSEDISPENSBUTTON_ID = "IV_UNIT_DOSE_DISPENSING";

	public static final String CASSETTEPROCESSBUTTON_ID = "CAS	SETTE_PROCESSING";
	public static final String MEDRETURNSBUTTON_ID = "MED_RETURNS";
	public static final String PROCESSBUTTON_ID = "PROCESS";
	public static final String RETURNBUTTON_ID = "RETURN";
	public static final String IPORDERSRDBUTTON_ID = "IP_ORDERS";
	public static final String DISCHMEDICRDBUTTON_ID = "DISCHARGE_MEDICATIONS";
	public static final String ERORDERSRDBUTTON_ID = "ER_ORDERS";

	public static final String OUTPATIPORDERSRDBUTTON_ID = "OUTPATIENT_IP_ORDERS";
	public static final String NURSINGCOMMUNRDBUTTON_ID = "NURSING_COMMUNICATION";
	public static final String MEDICINTERVRDBUTTON_ID = "MEDICATION_INTERVENTION";
	public static final String ALLSTATUSLINK_ID = "IP_PCY_ORDER_ALL_ID";
	public static final String DISPENSEDSTATUSLINK_ID = "PCY_IP_DP_ID";
	public static final String ORDEREDSTATUSLINK_ID = "PCY_IP_OD_ID";
	public static final String PARDISPENSTATUSLINK_ID = "PCY_IP_PD_ID";
	public static final String PARRETURSTATUSLINK_ID = "PCY_IP_PR_ID";
	public static final String RETURNEDSTATUSLINK_ID = "PCY_IP_RT_ID";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(id = QUICKSEARCHTX_ID)
	private WebElement quickSearchTxt;

	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;

	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;

	@FindBy(id = ROUTINEUDDISPENBUTTON_ID)
	private WebElement routineUDDispenButton;

	@FindBy(id = UNITDOSEDISPENSBUTTON_ID)
	private WebElement unitDoseDispensButton;

	@FindBy(id = CASSETTEPROCESSBUTTON_ID)
	private WebElement cassetteProcessButton;

	@FindBy(id = MEDRETURNSBUTTON_ID)
	private WebElement medReturnsButton;

	@FindBy(id = PROCESSBUTTON_ID)
	private WebElement processButton;

	@FindBy(id = RETURNBUTTON_ID)
	private WebElement returnButton;

	@FindBy(id = IPORDERSRDBUTTON_ID)
	private WebElement ipOrdersRDButton;

	@FindBy(id = DISCHMEDICRDBUTTON_ID)
	private WebElement dischMedicRDButton;

	@FindBy(id = ERORDERSRDBUTTON_ID)
	private WebElement erOrdersRDButton;

	@FindBy(id = OUTPATIPORDERSRDBUTTON_ID)
	private WebElement outPatIPOrdersRDButton;

	@FindBy(id = NURSINGCOMMUNRDBUTTON_ID)
	private WebElement nursingCommunRDButton;

	@FindBy(id = MEDICINTERVRDBUTTON_ID)
	private WebElement medicIntervRDButton;

	@FindBy(id = ALLSTATUSLINK_ID)
	private WebElement allStatusLink;

	@FindBy(id = DISPENSEDSTATUSLINK_ID)
	private WebElement dispensedStatusLink;

	@FindBy(id = ORDEREDSTATUSLINK_ID)
	private WebElement orderedStatusLink;

	@FindBy(id = PARDISPENSTATUSLINK_ID)
	private WebElement parDispenStatusLink;

	@FindBy(id = PARRETURSTATUSLINK_ID)
	private WebElement parReturStatusLink;

	@FindBy(id = RETURNEDSTATUSLINK_ID)
	private WebElement returnedStatusLink;

	public WebElement getForm() {
		return form;
	}

	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getResetButton() {
		return resetButton;
	}

	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	public WebElement getRoutineUDDispenButton() {
		return routineUDDispenButton;
	}

	public WebElement getUnitDoseDispensButton() {
		return unitDoseDispensButton;
	}

	public WebElement getCassetteProcessButton() {
		return cassetteProcessButton;
	}

	public WebElement getMedReturnsButton() {
		return medReturnsButton;
	}

	public WebElement getProcessButton() {
		return processButton;
	}

	public WebElement getReturnButton() {
		return returnButton;
	}

	public WebElement getIpOrdersRDButton() {
		return ipOrdersRDButton;
	}

	public WebElement getDischMedicRDButton() {
		return dischMedicRDButton;
	}

	public WebElement getErOrdersRDButton() {
		return erOrdersRDButton;
	}

	public WebElement getOutPatIPOrdersRDButton() {
		return outPatIPOrdersRDButton;
	}

	public WebElement getNursingCommunRDButton() {
		return nursingCommunRDButton;
	}

	public WebElement getMedicIntervRDButton() {
		return medicIntervRDButton;
	}

	public WebElement getAllStatusLink() {
		return allStatusLink;
	}

	public WebElement getDispensedStatusLink() {
		return dispensedStatusLink;
	}

	public WebElement getOrderedStatusLink() {
		return orderedStatusLink;
	}

	public WebElement getParDispenStatusLink() {
		return parDispenStatusLink;
	}

	public WebElement getParReturStatusLink() {
		return parReturStatusLink;
	}

	public WebElement getReturnedStatusLink() {
		return returnedStatusLink;
	}

}
