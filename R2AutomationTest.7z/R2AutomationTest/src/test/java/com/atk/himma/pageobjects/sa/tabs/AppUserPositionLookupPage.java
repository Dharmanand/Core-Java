package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.JsTreeSelector;

public class AppUserPositionLookupPage extends DriverWaitClass {

	public final static String POSLOOKUPFORM_ID = "EMP_POS_LOOKUP_FRM";
	@FindBy(id = POSLOOKUPFORM_ID)
	private WebElement posLookupForm;

	public final static String POSTREEDIV_ID = "orgTree";
	@FindBy(id = POSTREEDIV_ID)
	private WebElement posTreeDiv;

	public final static String ASSIGNPOSITION_ID = "ASSIGN_POSITION_SELECT";
	@FindBy(id = ASSIGNPOSITION_ID)
	private WebElement assignPosition;

	public final static String ASSIGNBTN_ID = "assignPositionId";
	@FindBy(id = ASSIGNBTN_ID)
	private WebElement assignBtn;

	public final static String CLOSEBTN_XPATH = "//input[@value='Close']";
	@FindBy(xpath = CLOSEBTN_XPATH)
	private WebElement closeBtn;

	public void selectPrimaryPosition(String[] appUserData) throws Exception {
		new JsTreeSelector(webDriver, webDriverWait).expandTree(POSTREEDIV_ID);
		sleepVeryShort();
		new JsTreeSelector(webDriver, webDriverWait).selectTreeNode(
				POSTREEDIV_ID, appUserData[21], appUserData[20]);
		waitForElementId(ASSIGNPOSITION_ID);
		sleepShort();
		new Select(assignPosition).selectByVisibleText(appUserData[19]);
		assignBtn.click();
		sleepShort();
	}

	public void selectSecondaryPosition(String[] appUserData) throws Exception {
		new JsTreeSelector(webDriver, webDriverWait).expandTree(POSTREEDIV_ID);
		sleepVeryShort();
		new JsTreeSelector(webDriver, webDriverWait).selectTreeNode(
				POSTREEDIV_ID, appUserData[24], appUserData[23]);
		waitForElementId(ASSIGNPOSITION_ID);
		sleepShort();
		new Select(assignPosition).selectByVisibleText(appUserData[22]);
		assignBtn.click();
		sleepShort();
	}

	public WebElement getPosLookupForm() {
		return posLookupForm;
	}

	public WebElement getPosTreeDiv() {
		return posTreeDiv;
	}

	public WebElement getAssignPosition() {
		return assignPosition;
	}

	public WebElement getAssignBtn() {
		return assignBtn;
	}

	public WebElement getCloseBtn() {
		return closeBtn;
	}

}
