package com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PriceModificationParameters extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Price Modification Parameters";
	
	public final static String MODIFICATIONRADIO_ID = "MODIFICATION_PATTERN_DISCOUNT";
	public final static String ADDONRADIO_ID = "MODIFICATION_PATTERN_ADDON";
	public final static String FIXEDRADIO_ID = "MODIFICATION_PATTERN_FIXED";
	public final static String VALUEDD_ID = "PMP_VALUE_DROPDOWN";
	public final static String VALUETXT_ID = "PMP_VALUE_TEXT";
	public final static String DEPARTMENT_ID = "MODI_DEPARTMENT";
	public final static String SPECIALITY_ID = "MODI_SPECIALITY";
	public final static String SUBSPECIALITY_ID = "MODI_SUB_SPECIALITY";
	public final static String SERVICETYPE_ID = "MODI_SERVICE_TYPE";
	public final static String LOOKUP_CLASS = "lookup";
	public final static String SERVICECODE_ID = "MODIFICATION_SERVICE_CODE";
	public final static String UNDO_ID = "RESET_SERVICE_GRID";
	public final static String APPLYPRICEMODIFIER_ID = "APPLY_MODIFIER";
	public final static String RESET_ID = "RESET_MODIFIER";
	
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Price Modification Parameters')]/..";
	
//	POPUP
	public final static String PUSERFORM_ID = "MODIFICATION_LOOKUP_FORM";
	public final static String PUSERTITLE_ID = "ui-dialog-title-MODIFICATION_PARAMETER_LOOKUP_DIV";
	public final static String PUMBU_ID = "MODIFICATION_LOOKUP_MBU_NAME";
	public final static String PUDEPARTMENT_ID = "MLP_DEPARTMENT";
	public final static String PUSPECIALTY_ID = "MLP_SPECIALITY";
	public final static String PUSUBSPECIALITY_ID = "MLP_SUB_SPECIALITY";
	public final static String PUSERVICETYPE_ID = "MLP_SERVICE_TYPE";
	public final static String PUSERVICECODE_ID = "MLP_SERVICE_CODE";
	public final static String PUSERVICENAME_ID = "MLP_SERVICE_NAME";
	
	public final static String GRID_ID = "MODIFICATION_PARAMETER_GRID";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "MODIFICATION_PARAMETER_GRID_serviceInfo.serviceCode";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "MODIFICATION_PARAMETER_GRID_serviceInfo.serviceName";
	public final static String GRID_PAGERID = "sp_1_MODIFICATION_PARAMETER_GRID_pager";
	
	public final static String SEARCHBUTTON_XPATH = "//form[@id='MODIFICATION_LOOKUP_FORM']//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//form[@id='MODIFICATION_LOOKUP_FORM']//span[@class='buttoncontainer_mid']//input[@value='Reset']";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = VALUEDD_ID)
	private WebElement valueDD;
	
	@FindBy(id = VALUETXT_ID)
	private WebElement valueTxt;
	
	@FindBy(id = PUSERFORM_ID)
	private WebElement puSerForm;
	
	@FindBy(id = PUSERTITLE_ID)
	private WebElement puSerTitle;
	
	@FindBy(id = PUMBU_ID)
	private WebElement puMBU;
	
	@FindBy(id = PUDEPARTMENT_ID)
	private WebElement puDepartment;
	
	@FindBy(id = PUSPECIALTY_ID)
	private WebElement puSpecialty;
	
	@FindBy(id = PUSUBSPECIALITY_ID)
	private WebElement puSubSpeciality;
	
	@FindBy(id = PUSERVICETYPE_ID)
	private WebElement puServiceType;
	
	@FindBy(id = PUSERVICECODE_ID)
	private WebElement puServiceCode;
	
	@FindBy(id = PUSERVICENAME_ID)
	private WebElement puServiceName;
	
	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;
	
	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;
	
	@FindBy(id = MODIFICATIONRADIO_ID)
	private WebElement discountRadio;
	
	@FindBy(id = ADDONRADIO_ID)
	private WebElement addOnRadio;
	
	@FindBy(id = FIXEDRADIO_ID)
	private WebElement fixedRadio;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SPECIALITY_ID)
	private WebElement speciality;
	
	@FindBy(id = SUBSPECIALITY_ID)
	private WebElement subSpeciality;
	
	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;
	
	@FindBy(className = LOOKUP_CLASS)
	private WebElement lookup;
	
	@FindBy(id = SERVICECODE_ID)
	private WebElement serviceCode;
	
	@FindBy(id = UNDO_ID)
	private WebElement undo;
	
	@FindBy(id = APPLYPRICEMODIFIER_ID)
	private WebElement applyPriceModifier;
	
	@FindBy(id = RESET_ID)
	private WebElement reset;

	
	public boolean checkPriceModifParamSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatas(String[] pLDatas)
			throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
		getSectionName().click();
		waitForElementId(MODIFICATIONRADIO_ID);
		sleepVeryShort();
		selectRadioButtonAsLabelText(pLDatas[14].trim());
		if(!pLDatas[15].isEmpty())
		{
			new Select(valueDD).selectByVisibleText(pLDatas[15].trim());
			valueTxt.clear();
			valueTxt.sendKeys(pLDatas[16].trim());
		}
		if(!pLDatas[17].isEmpty())
			new Select(department).selectByVisibleText(pLDatas[17].trim());
		if(!pLDatas[18].isEmpty())
			new Select(speciality).selectByVisibleText(pLDatas[18].trim());
		if(!pLDatas[19].isEmpty())
			new Select(subSpeciality).selectByVisibleText(pLDatas[19].trim());
		if(!pLDatas[20].isEmpty())
			new Select(serviceType).selectByVisibleText(pLDatas[20].trim());
		lookup.click();
		waitForElementId(PUSERFORM_ID);
		waitForElementXpathExpression(SEARCHBUTTON_XPATH);
		sleepShort();
		puServiceName.clear();
		puServiceName.sendKeys(pLDatas[21].trim());	
		searchButton.click();
		clickOnGridAction(pLDatas[21].trim(), "Select");
		sleepShort();
		return puServiceName.getAttribute("value").trim().equals(pLDatas[21].trim());
	}
	
	/**
	 * @return the discountRadio
	 */
	public WebElement getDiscountRadio() {
		return discountRadio;
	}

	/**
	 * @return the addOnRadio
	 */
	public WebElement getAddOnRadio() {
		return addOnRadio;
	}

	/**
	 * @return the fixedRadio
	 */
	public WebElement getFixedRadio() {
		return fixedRadio;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the speciality
	 */
	public WebElement getSpeciality() {
		return speciality;
	}

	/**
	 * @return the subSpeciality
	 */
	public WebElement getSubSpeciality() {
		return subSpeciality;
	}

	/**
	 * @return the serviceType
	 */
	public WebElement getServiceType() {
		return serviceType;
	}

	/**
	 * @return the lookup
	 */
	public WebElement getLookup() {
		return lookup;
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the undo
	 */
	public WebElement getUndo() {
		return undo;
	}

	/**
	 * @return the applyPriceModifier
	 */
	public WebElement getApplyPriceModifier() {
		return applyPriceModifier;
	}

	/**
	 * @return the reset
	 */
	public WebElement getReset() {
		return reset;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the puSerForm
	 */
	public WebElement getPuSerForm() {
		return puSerForm;
	}

	/**
	 * @return the puSerTitle
	 */
	public WebElement getPuSerTitle() {
		return puSerTitle;
	}

	/**
	 * @return the puMBU
	 */
	public WebElement getPuMBU() {
		return puMBU;
	}

	/**
	 * @return the puDepartment
	 */
	public WebElement getPuDepartment() {
		return puDepartment;
	}

	/**
	 * @return the puSpecialty
	 */
	public WebElement getPuSpecialty() {
		return puSpecialty;
	}

	/**
	 * @return the puSubSpeciality
	 */
	public WebElement getPuSubSpeciality() {
		return puSubSpeciality;
	}

	/**
	 * @return the puServiceType
	 */
	public WebElement getPuServiceType() {
		return puServiceType;
	}

	/**
	 * @return the puServiceCode
	 */
	public WebElement getPuServiceCode() {
		return puServiceCode;
	}

	/**
	 * @return the puServiceName
	 */
	public WebElement getPuServiceName() {
		return puServiceName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the valueTxt
	 */
	public WebElement getValueTxt() {
		return valueTxt;
	}

	/**
	 * @return the valueDD
	 */
	public WebElement getValueDD() {
		return valueDD;
	}
	
}
