package com.atk.himma.pageobjects;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.baselov.BaseLovPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class HomePage extends DriverWaitClass{

	public final static String HOMETITLE_XPATH = "//li[@title='User Home']";
	
	@FindBy(xpath = HOMETITLE_XPATH)
	private WebElement homeTitle;

	public final static String HOMEBODYCONTENT_CLASSNAME = "DefaultHome";
	
	@FindBy(className = HOMEBODYCONTENT_CLASSNAME)
	private WebElement homeBodyContent;

	public final static String LOGOUT_ID = "LOG_OUT_URL";
	
	@FindBy(id = LOGOUT_ID)
	private WebElement logOut;

	public BaseLovPage clickOnBaseLovMenu(WebDriver webDriver,
			WebDriverWait webDriverWait, String moduleName) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add(moduleName);
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Base LV");
		BaseLovPage baseLov = PageFactory.initElements(webDriver,
				BaseLovPage.class);
		baseLov.setWebDriver(webDriver);
		baseLov.setWebDriverWait(webDriverWait);
		return baseLov;
	}

	/**
	 * @return the homeTitle
	 */
	public WebElement getHomeTitle() {
		return homeTitle;
	}

	/**
	 * @param homeTitle
	 *            the homeTitle to set
	 */
	public void setHomeTitle(WebElement homeTitle) {
		this.homeTitle = homeTitle;
	}

	/**
	 * @return the logOut
	 */
	public WebElement getLogOut() {
		return logOut;
	}

	/**
	 * @param logOut
	 *            the logOut to set
	 */
	public void setLogOut(WebElement logOut) {
		this.logOut = logOut;
	}

	/**
	 * @return the homeBodyContent
	 */
	public WebElement getHomeBodyContent() {
		return homeBodyContent;
	}

	/**
	 * @return the hometitleXpath
	 */
	public static String getHometitleXpath() {
		return HOMETITLE_XPATH;
	}

	/**
	 * @return the homebodycontentClassname
	 */
	public static String getHomebodycontentClassname() {
		return HOMEBODYCONTENT_CLASSNAME;
	}

	/**
	 * @return the logoutId
	 */
	public static String getLogoutId() {
		return LOGOUT_ID;
	}

}
