package com.atk.himma.test.sa;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.masters.EquipmentPage;
import com.atk.himma.pageobjects.sa.masters.tabs.EquipmentListTab;
import com.atk.himma.setup.SeleniumDriverSetup;

public class EquipmentTest extends SeleniumDriverSetup {
	EquipmentPage equipmentPage;
	List<String[]> equipmentList;

	@Test(description = "Open Equipment Page")
	public void clickOnEquipMenu() throws InterruptedException {
		equipmentPage = PageFactory
				.initElements(webDriver, EquipmentPage.class);
		equipmentPage = equipmentPage
				.clickOnEquipMenu(webDriver, webDriverWait);
		equipmentPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		equipmentPage
				.waitForElementXpathExpression(EquipmentListTab.EQUIPLISTTAB_XPATH);
		equipmentPage.sleepShort();
		Assert.assertEquals(equipmentPage.getEquipmentListTab()
				.getEquipListTab().getAttribute("title").trim(),
				"Equipment List", "Fail to open Equipment List.");
	}

	@Test(description = "click On Add New Equipment Button", dependsOnMethods = "clickOnEquipMenu")
	public void test001ClickOnAddNewEquipButt() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		equipmentList = excelReader.read(properties.getProperty("equipment"));
		for (String st[] : equipmentList)
			Assert.assertEquals(equipmentPage.clickOnAddNewEquipment(st), true,
					"Fail to click On Add New Equipment Button.");
	}

	@Test(description = "Check Mandatory Equipment Short Name", dependsOnMethods = "test1ClickOnAddNewEquipButt")
	public void test002IsMandEquipShotName() {
		Assert.assertEquals(equipmentPage.getEquipmentDetailsTab()
				.isMandEquipShotName(), true,
				"Fail to Mandatory Equipment Short Name.");
	}

	@Test(description = "Check Mandatory Equipment Name", dependsOnMethods = "test1ClickOnAddNewEquipButt")
	public void test003IsMandEquipName() {
		Assert.assertEquals(equipmentPage.getEquipmentDetailsTab()
				.isMandEquipName(), true,
				"Fail to Mandatory Equipment Name Check.");
	}

	@Test(description = "Check Mandatory MBU", dependsOnMethods = "test1ClickOnAddNewEquipButt")
	public void test004IsMandMBU() {
		Assert.assertEquals(equipmentPage.getEquipmentDetailsTab().isMandMBU(),
				true, "Fail to Mandatory MBU Check.");
	}

	@Test(description = "Check Mandatory Department", dependsOnMethods = "test1ClickOnAddNewEquipButt")
	public void test005IsMandDepartment() {
		Assert.assertEquals(equipmentPage.getEquipmentDetailsTab()
				.isMandDepartment(), true,
				"Fail to Mandatory Department Check.");
	}

	@Test(description = "Check Mandatory Equipment Resource Type ", dependsOnMethods = "test1ClickOnAddNewEquipButt")
	public void test006IsMandResTpye() {
		Assert.assertEquals(equipmentPage.getEquipmentDetailsTab()
				.isMandResTpye(), true, "Fail to Mandatory Resource Type.");
	}

	@Test(description = "Fill datas of Equipment", dependsOnMethods = { "test1ClickOnAddNewEquipButt" })
	public void test007FillEquipDatas() throws InterruptedException {
		for (String st[] : equipmentList)
			Assert.assertEquals(equipmentPage.getEquipmentDetailsTab()
					.fillDatas(st), true,
					"Fail to Fill datas of Equipment page");
	}

	@Test(description = "Save Equipment", dependsOnMethods = { "test007FillEquipDatas" })
	public void test008SaveEquipment() throws InterruptedException, IOException {
		Assert.assertEquals(equipmentPage.saveDetailsPage().contains("Update"),
				true, "Fail to Save Equipment.");
	}

	@Test(description = "Activate Equipment", dependsOnMethods = "test008SaveItem")
	public void test10ActivateEquipment() throws InterruptedException,
			IOException {
		Assert.assertEquals(
				equipmentPage.activateEquipDetails().contains("Active"), true,
				"Fail to Activate Item.");
	}
}
