package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LabEquipmentDetailsDefaultSec extends DriverWaitClass {
	public final static String LABEQUIPDTLSAVEBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	@FindBy(xpath = LABEQUIPDTLSAVEBTN_XPATH)
	private WebElement labEquipDtlSaveBtn;

	public final static String LABEQUIPDTLCANCELBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	@FindBy(xpath = LABEQUIPDTLCANCELBTN_XPATH)
	private WebElement labEquipDtlCancelBtn;

	public final static String EQUIPCODE_NAME = "labEquipment.equipmentCode";
	@FindBy(name = EQUIPCODE_NAME)
	private WebElement equipCode;

	public final static String EQUIPSHNAME_NAME = "labEquipment.equipmentShortName";
	@FindBy(name = EQUIPSHNAME_NAME)
	private WebElement equipShName;

	public final static String EQUIPNAME_NAME = "labEquipment.equipmentName";
	@FindBy(name = EQUIPNAME_NAME)
	private WebElement equipName;

	public final static String MBU_NAME = "labEquipment.mbuText";
	@FindBy(name = MBU_NAME)
	private WebElement mbu;

	public final static String DEPARTMENT_NAME = "labEquipment.departmentText";
	@FindBy(name = DEPARTMENT_NAME)
	private WebElement department;

	public final static String RESCAT_NAME = "labEquipment.resourceCategoryText";
	@FindBy(name = RESCAT_NAME)
	private WebElement resourceCategory;

	public final static String RESTYPE_NAME = "labEquipment.resourceTypeText";
	@FindBy(name = RESTYPE_NAME)
	private WebElement resourceType;

	public final static String RECORDSTATUS_NAME = "labEquipment.mainStatusText";
	@FindBy(name = RECORDSTATUS_NAME)
	private WebElement recordStatus;

	public WebElement getLabEquipDtlSaveBtn() {
		return labEquipDtlSaveBtn;
	}

	public WebElement getLabEquipDtlCancelBtn() {
		return labEquipDtlCancelBtn;
	}

	public WebElement getEquipCode() {
		return equipCode;
	}

	public WebElement getEquipShName() {
		return equipShName;
	}

	public WebElement getEquipName() {
		return equipName;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	public WebElement getResourceType() {
		return resourceType;
	}

	public WebElement getRecordStatus() {
		return recordStatus;
	}

}
