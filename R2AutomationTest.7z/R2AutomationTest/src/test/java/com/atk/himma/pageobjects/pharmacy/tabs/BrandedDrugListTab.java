package com.atk.himma.pageobjects.pharmacy.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BrandedDrugListTab {

	public final static String FORM_ID = "BRANDED_DRUG_LIST_PAGE";
	public final static String SEARCHTXT_ID = "TEXT_SEARCH_BRANDED_DRUG";
	public final static String SEARCHBUTTON_ID = "SEARCH_BRANDED_DRUG_BUTTON";
	public final static String RESETBUTTON_CSS = "#SEARCH_BRANDED_DRUG_BUTTON ~ input[value='Reset']";
	public final static String ADVSEARCHBUTTON_ID = "BRANDED_DRUG_ADV_SEARCH";
	public final static String EXEXCELBUTTON_ID = "SEARCH_BRANDED_DRUG_LIST_export_btn";

	public final static String GRID_ID = "SEARCH_BRANDED_DRUG_LIST";
	public final static String GRID_DRUGCODE_ARIA_DESCRIBEDBY = "SEARCH_BRANDED_DRUG_LIST_brandedDrugCode";
	public final static String GRID_DRUGSHORTNAME_ARIA_DESCRIBEDBY = "SEARCH_BRANDED_DRUG_LIST_brandedDrugShortName";
	public final static String GRID_DRUGNAME_ARIA_DESCRIBEDBY = "jqgh_SEARCH_BRANDED_DRUG_LIST_brandedDrugName";
	public final static String GRID_DRUGCATEGORY_ARIA_DESCRIBEDBY = "SEARCH_BRANDED_DRUG_LIST_brandedDrugCategoryText";
	public final static String GRID_DOSAGEFORM_ARIA_DESCRIBEDBY = "SEARCH_BRANDED_DRUG_LIST_drugDosageFormText";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "SEARCH_BRANDED_DRUG_LIST_brandedDrugMbuIdText";
	public final static String GRID_DRUGSTATUS_ARIA_DESCRIBEDBY = "SEARCH_BRANDED_DRUG_LIST_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_SEARCH_BRANDED_DRUG_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_BRANDED_DRUG_LIST_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = SEARCHTXT_ID)
	private WebElement searchTxt;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;
	
	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(id = EXEXCELBUTTON_ID)
	private WebElement exExcelButton;
	
	@FindBy(id = GRID_ID)
	private WebElement grid;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the searchTxt
	 */
	public WebElement getSearchTxt() {
		return searchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the exExcelButton
	 */
	public WebElement getExExcelButton() {
		return exExcelButton;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}
	
}
