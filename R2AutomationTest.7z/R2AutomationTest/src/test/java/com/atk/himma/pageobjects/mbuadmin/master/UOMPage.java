package com.atk.himma.pageobjects.mbuadmin.master;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.master.tabs.UOMDetailsTab;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.UOMListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class UOMPage extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	private UOMListTab uomListTab;
	private UOMDetailsTab uomDetailsTab;

	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Updated successfully')]";
	public final static String DELETECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'deleted successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Record activated successfully')]";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Unit of Measurement')]";
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;

	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;

	@FindBy(xpath = DELETECONFMSG_XPATH)
	private WebElement deleteConfMsg;

	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;

	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		uomListTab = PageFactory.initElements(webDriver, UOMListTab.class);
		uomListTab.setWebDriver(webDriver);
		uomListTab.setWebDriverWait(webDriverWait);

		uomDetailsTab = PageFactory
				.initElements(webDriver, UOMDetailsTab.class);
		uomDetailsTab.setWebDriver(webDriver);
		uomDetailsTab.setWebDriverWait(webDriverWait);
	}

	public UOMPage clickOnUOMPageMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Unit of Measurement");
		UOMPage uomPage = PageFactory.initElements(webDriver, UOMPage.class);
		uomPage.setWebDriver(webDriver);
		uomPage.setWebDriverWait(webDriverWait);
		return uomPage;
	}

	public void clickOnAddNewUOMButton() {
		waitForElementXpathExpression(UOMListTab.ADDNEWUOMBUTTON_XPATH);
		uomListTab.getAddNewUOMButton().click();
		waitForElementId(UOMDetailsTab.GRID_ID);
		waitForElementId(UOMDetailsTab.FORM_ID);
	}

	public String saveUOMData(String[] uomData) throws InterruptedException {
		waitForElementId(UOMDetailsTab.FORM_ID);
		uomDetailsTab.getUomName().sendKeys(uomData[0].trim());
		uomDetailsTab.getUomNameAr().sendKeys(uomData[1].trim());
		uomDetailsTab.getGridPopUpSubmitButton();
		waitForElementId(UOMDetailsTab.GRID_ID);
		uomDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(UOMDetailsTab.UPDATEBUTTON_XPATH);
		sleepVeryShort();
		return uomDetailsTab.getUpdateButton().getAttribute("value").trim();
	}

	public boolean saveDuplicateData(String[] uomData) throws InterruptedException, IOException {
		try{
			waitForElementId(UOMDetailsTab.FORM_ID);
			uomDetailsTab.getUomName().sendKeys(uomData[0].trim());
			uomDetailsTab.getUomNameAr().sendKeys(uomData[1].trim());
			uomDetailsTab.getGridPopUpSubmitButton();
			waitForElementId(UOMDetailsTab.GRID_ID);
			uomDetailsTab.getSaveButton().click();
		new WebDriverWait(webDriver, shortTimeInterval).until(ExpectedConditions.presenceOfElementLocated(By
				.xpath(UOMDetailsTab.UPDATEBUTTON_XPATH)));
		sleepVeryShort();
		return false;
		}
		catch (Exception e) {
			return searchData(uomData).equals(uomData[0].trim());
		}
	}
	
	public String searchData(String[] uomData) {
		waitForElementXpathExpression(UOMListTab.UOMLISTTAB_XPATH);
		uomListTab.getUomListTab().click();
		waitForElementId(UOMListTab.GRID_ID);
		uomListTab.getUomName().clear();
		uomListTab.getUomName().sendKeys(uomData[0].trim());
		uomListTab.getSearchButton().click();
		return waitForGridFirstDuplicateCellText(UOMListTab.GRID_ID, UOMListTab.GRID_UOMNAME_ARIA_DESCRIBEDBY);
	}
	
	public String activateUOM() throws InterruptedException, IOException {

		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);

	}

	public void clickOnCancelButton() throws InterruptedException {
		waitForElementId(UOMDetailsTab.FORM_ID);
		uomDetailsTab.getCancelButton().click();
		waitForElementId(UOMListTab.GRID_ID);
		sleepShort();
	}

	public String searchUOM(String[] uomData) throws InterruptedException {
		waitForElementId(UOMListTab.FORM_ID);
		uomListTab.getUomName().clear();
		uomListTab.getUomName().sendKeys(uomData[0].trim());
		uomListTab.getSearchButton().click();
		waitForElementId(UOMListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(UOMListTab.GRID_ID,
				UOMListTab.GRID_UOMNAME_ARIA_DESCRIBEDBY, uomData[0].trim());
	}

	public String clickOnEditLink(String[] uomData) throws InterruptedException {
		clickOnGridAction(uomData[0].trim(), "Edit");
		waitForElementId(UOMDetailsTab.GRID_ID);
		waitForElementXpathExpression(UOMDetailsTab.UPDATEBUTTON_XPATH);
		sleepShort();
		return uomDetailsTab.getUomName().getAttribute("value").trim();
	}

	public String updateUOMData(String[] uomData) throws InterruptedException {
		waitForElementId(UOMDetailsTab.FORM_ID);
		uomDetailsTab.getUomName().clear();
		uomDetailsTab.getUomName().sendKeys(uomData[0].trim());
		uomDetailsTab.getUomNameAr().clear();
		uomDetailsTab.getUomNameAr().sendKeys(uomData[1].trim());
		// if
		// ((webDriver.findElement(By.xpath(UOMDetailsTab.GRIDUOMNAMEPOPUP_ID))
		// .findElements(By.tagName("option")).size() > 1)
		// && (!uomData[2].isEmpty())) {
		// new Select(uomDetailsTab.getGridPopUpUomName())
		// .selectByVisibleText(uomData[2].trim());
		// uomDetailsTab.getGridPopUpConvertFactor().clear();
		// uomDetailsTab.getGridPopUpConvertFactor().sendKeys(
		// uomData[3].trim());
		// }
		uomDetailsTab.getGridPopUpSubmitButton();
		waitForElementId(UOMDetailsTab.GRID_ID);
		uomDetailsTab.getUpdateButton().click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		sleepShort();
		return uomDetailsTab.getUpdateButton().getAttribute("value").trim();
	}

	public String clickOnAddNewButton() throws InterruptedException {
		waitForElementId(UOMDetailsTab.FORM_ID);
		uomDetailsTab.getAddNewButton().click();
		waitForElementId(UOMDetailsTab.GRID_ID);
		sleepShort();
		return uomDetailsTab.getSaveButton().getAttribute("value").trim();
	}

	public String saveUOMWithConvFactor(String[] uomData)
			throws InterruptedException {
		waitForElementId(UOMDetailsTab.FORM_ID);
		uomDetailsTab.getUomName().sendKeys(uomData[0].trim());
		uomDetailsTab.getUomNameAr().sendKeys(uomData[1].trim());
		waitForElementId(UOMDetailsTab.GRIDPOPUPFORM_ID);
		uomDetailsTab.getGridAddButton().click();
		sleepShort();
		new Select(uomDetailsTab.getGridPopUpUomName())
				.selectByVisibleText(uomData[2].trim());
		uomDetailsTab.getGridPopUpConvertFactor().sendKeys(uomData[3].trim());
		uomDetailsTab.getGridPopUpSubmitButton().click();
		waitForElementId(UOMDetailsTab.GRID_ID);
		sleepShort();
		uomDetailsTab.getSaveButton().click();
		sleepShort();
		waitForElementXpathExpression(UOMDetailsTab.UPDATEBUTTON_XPATH);
		sleepShort();
		return uomDetailsTab.getUpdateButton().getAttribute("value").trim();
	}

	public String clickOnDeleteLink(String[] uomData)
			throws InterruptedException {
		uomListTab.getUomListTab().click();
		waitForElementId(UOMListTab.GRID_ID);
		searchUOM(uomData);
		clickOnGridAction(uomData[0].trim(), "Delete");
		waitForElementId(UOMListTab.CONFMESSAGE_ID);
		uomListTab.getConfMessYesButton().click();
		waitForElementXpathExpression(DELETECONFMSG_XPATH);
		return deleteConfMsg.getText().trim();
	}

	/**
	 * @return the uomListTab
	 */
	public UOMListTab getUomListTab() {
		return uomListTab;
	}

	/**
	 * @return the uomDetailsTab
	 */
	public UOMDetailsTab getUomDetailsTab() {
		return uomDetailsTab;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	/**
	 * @return the deleteConfMsg
	 */
	public WebElement getDeleteConfMsg() {
		return deleteConfMsg;
	}
}
