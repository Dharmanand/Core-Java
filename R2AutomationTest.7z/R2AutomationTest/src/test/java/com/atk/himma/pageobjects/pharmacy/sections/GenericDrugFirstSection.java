package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GenericDrugFirstSection {

	public final static String GENDRUGCODE_ID = "GENERIC_DRUG_CODE";
	public final static String GENDRUGSHORTNAME_ID = "GEN_DRUG_SHORT_NAME";
	public final static String GENDRUGNAME_ID = "GEN_DRUG_NAME";
	public final static String GENDRUGNAMEAR_ID = "GEN_DRUG_NAME_AR";
	public final static String ANATOMICALMAINGRP_ID = "ANATOMICAL_MAIN_GROUP";
	public final static String THERAPEUTICGROUP_ID = "THERAPEUTIC_GROUP";
	public final static String PHARMACOLSUBCLASS_ID = "PHARMACOLOGICAL_SUB_CLASS";
	public final static String CHEMICALSUBGROUP_ID = "CHEMICAL_SUB_GROUP";
	public final static String INDICATION_ID = "GEN_DRUG_INDICATION";
	public final static String NARCOTICDRUG_ID = "NARCOTIC";
	public final static String CONTROLLEDDRUG_ID = "CONTROLLED";
	public final static String CONTRAINDICATION_ID = "GEN_DRUG_CONTRA_INDICATION";
	public final static String MECHANISMOFACTION_ID = "GEN_DRUG_MECHANISM_OF_ACTION";
	
	public final static String GRID_ID = "RECOMMENDED_DOSAGE_GRID";
	public final static String GRID_GENDER_ARIA_DESCRIBEDBY = "RECOMMENDED_DOSAGE_GRID_genderText";
	public final static String GRID_DOSEPARAM_ARIA_DESCRIBEDBY = "RECOMMENDED_DOSAGE_GRID_doseParamDisplay";
	public final static String GRID_DOSEUOM_ARIA_DESCRIBEDBY = "RECOMMENDED_DOSAGE_GRID_quantityDisp";
	public final static String GRID_FREQUENCY_ARIA_DESCRIBEDBY = "RECOMMENDED_DOSAGE_GRID_frequencyText";
	public final static String GRID_DURATION_ARIA_DESCRIBEDBY = "RECOMMENDED_DOSAGE_GRID_periodDisp";
	
	public final static String GRID_ADDBUTTON_XPATH = "//td[@id='RECOMMENDED_DOSAGE_GRID_pager_left']//span";
	
//	-----------------------POPUP---------------------
	public final static String POPUPDIV_ID = "AddRecommendedDosageLookUp";
	public final static String POPUPGENDER_ID = "RECOMMENDED_DOSAGE_GENDER";
	public final static String BASEDONAGEGRP_CSS = "#DOSE_PARAM_TYPEA[value=A]";
	public final static String BASEDONBODYWT_CSS = "#DOSE_PARAM_TYPEA[value=B]";
	
//	------------Based on Age Group-------------------
	public final static String AGEFROM_ID = "AGE_FROM";
	public final static String AGEFROMTYPE_ID = "AGE_FROM_TYPE";
	public final static String AGETO_ID = "AGE_TO";
	public final static String AGETOTYPE_ID = "AGE_TO_TYPE";
	public final static String SIGINSTQUANTITY_ID = "SIG_INST_QUANTITY";
	public final static String SIGINSTTYPE_ID = "SIG_INST_TYPE";
	public final static String FREQUENCYAG_ID = "AGE_GROUP_FREQUENCY";
	public final static String DURATIONAG_ID = "AGE_GROUP_DURATION";
	public final static String DURATIONTYPEAG_ID = "AGE_GROUP_DURATION_TYPE";
	
//	------------Based on Body Weight-----------------
	public final static String DOSE_ID = "BODY_WEIGHT_DOSE";
	public final static String DOSETYPEBW_ID = "BODY_WEIGHT_DOSE_TYPE";
	public final static String FREQUENCYBW_ID = "BODY_WEIGHT_FREQUENCY";
	public final static String DURATIONBW_ID = "BODY_WEIGHT_DURATION";
	public final static String DURATIONTYPEBW_ID = "BODY_WEIGHT_DURATION_TYPE";
	
	public final static String SUBMITBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Submit']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Cancel']";
	
//	-------------------Safety Alerts-----------------
	public final static String PREGNANCY_ID = "PREGNANCY";
	public final static String BREASTFEEDING_ID = "BREASTFEEDING";
	public final static String INFANTANDCHILDREN_ID = "INFANTANDCHILDREN";
	public final static String ELDERLYAGE_ID = "ELDERLYAGE";
	public final static String DISCONTINUE_ID = "DISCONTINUE";
	public final static String HEART_ID = "HEART";
	public final static String PROLONGEDUSE_ID = "PROLONGEDUSE";
	public final static String SKINANDSUNLIGHT_ID = "SKINANDSUNLIGHT";
	public final static String DRIVING_ID = "DRIVING";
	public final static String HAZARDOUSWORK_ID = "HAZARDOUSWORK";
	public final static String KIDNEYORLIVER_ID = "KIDNEYORLIVER";
	public final static String DISCOLORATIONOFURINE_ID = "DISCOLORATIONOFURINE";
	public final static String LIVER_ID = "LIVER";
	
//	-----------------Risks---------------------------
	public final static String INFECTIONS_ID = "INFECTION";
	public final static String BIOHAZARD_ID = "BIOHAZARD";
	public final static String RADIOACTIVE_ID = "RADIOACTIVE";
	public final static String EXPLOSIVE_ID = "EXPLOSIVE";
	
	@FindBy(id = INFECTIONS_ID	)
	private WebElement infections;
	
	@FindBy(id = BIOHAZARD_ID	)
	private WebElement biohazard;
	
	@FindBy(id = RADIOACTIVE_ID	)
	private WebElement radioactive;
	
	@FindBy(id = EXPLOSIVE_ID	)
	private WebElement explosive;
	
	@FindBy(id = GENDRUGCODE_ID)
	private WebElement genDrugCode;
	
	@FindBy(id = GENDRUGSHORTNAME_ID)
	private WebElement genDrugShortName;
	
	@FindBy(id = GENDRUGNAME_ID)
	private WebElement genDrugName;
	
	@FindBy(id = GENDRUGNAMEAR_ID)
	private WebElement genDrugNameAr;
	
	@FindBy(id = ANATOMICALMAINGRP_ID)
	private WebElement anatomicalMainGrp;
	
	@FindBy(id = THERAPEUTICGROUP_ID)
	private WebElement therapeuticGroup;
	
	@FindBy(id = PHARMACOLSUBCLASS_ID)
	private WebElement pharmacolSubClass;
	
	@FindBy(id = CHEMICALSUBGROUP_ID)
	private WebElement chemicalSubGroup;
	
	@FindBy(id = INDICATION_ID)
	private WebElement indication;
	
	@FindBy(id = NARCOTICDRUG_ID)
	private WebElement narcoticDrug;
	
	@FindBy(id = CONTRAINDICATION_ID)
	private WebElement contraIndication;
	
	@FindBy(id = MECHANISMOFACTION_ID)
	private WebElement mechanismOfAction;
	
	@FindBy(xpath = GRID_ADDBUTTON_XPATH)
	private WebElement gridAddButton;
	
	@FindBy(id = POPUPDIV_ID)
	private WebElement popupDiv;
	
	@FindBy(id = POPUPGENDER_ID)
	private WebElement popupGender;
	
	@FindBy(css = BASEDONAGEGRP_CSS)
	private WebElement basedOnAgeGrp;
	
	@FindBy(css = BASEDONBODYWT_CSS)
	private WebElement basedOnBodyWt;
	
	@FindBy(id = AGEFROM_ID)
	private WebElement ageFrom;
	
	@FindBy(id = AGEFROMTYPE_ID)
	private WebElement ageFromType;
	
	@FindBy(id = AGETO_ID)
	private WebElement ageTo;
	
	@FindBy(id = AGETOTYPE_ID)
	private WebElement ageToType;
	
	@FindBy(id = SIGINSTQUANTITY_ID)
	private WebElement sigInstQuantity;
	
	@FindBy(id = SIGINSTTYPE_ID)
	private WebElement sigInstType;
	
	@FindBy(id = FREQUENCYAG_ID)
	private WebElement frequencyAG;
	
	@FindBy(id = DURATIONAG_ID)
	private WebElement durationAG;
	
	@FindBy(id = DURATIONTYPEAG_ID)
	private WebElement durationTypeAG;
	
	@FindBy(id = DOSE_ID)
	private WebElement dose;
	
	@FindBy(id = DOSETYPEBW_ID)
	private WebElement doseTypeBW;
	
	@FindBy(id = FREQUENCYBW_ID)
	private WebElement frequencyBW;
	
	@FindBy(id = DURATIONBW_ID)
	private WebElement durationBW;
	
	@FindBy(id = DURATIONTYPEBW_ID)
	private WebElement durationTypeBW;
	
	@FindBy(id = SUBMITBUTTON_XPATH)
	private WebElement submitButton;
	
	@FindBy(id = CANCELBUTTON_XPATH)
	private WebElement cancelButton;
	
	@FindBy(id = PREGNANCY_ID)
	private WebElement pregnancy;
	
	@FindBy(id = BREASTFEEDING_ID)
	private WebElement breastFeeding;
	
	@FindBy(id = INFANTANDCHILDREN_ID)
	private WebElement infantAndChildren;
	
	@FindBy(id = ELDERLYAGE_ID)
	private WebElement elderlyAge;
	
	@FindBy(id = DISCONTINUE_ID)
	private WebElement discontinue;
	
	@FindBy(id = HEART_ID)
	private WebElement heart;
	
	@FindBy(id = PROLONGEDUSE_ID)
	private WebElement prolongedUse;
	
	@FindBy(id = SKINANDSUNLIGHT_ID)
	private WebElement skinAndSunlight;
	
	@FindBy(id = DRIVING_ID)
	private WebElement driving;
	
	@FindBy(id = HAZARDOUSWORK_ID)
	private WebElement hazardousWork;
	
	@FindBy(id = KIDNEYORLIVER_ID)
	private WebElement kidneyOrLiver;
	
	@FindBy(id = DISCOLORATIONOFURINE_ID)
	private WebElement discolorationOfUrine;
	
	@FindBy(id = LIVER_ID)
	private WebElement liver;

	/**
	 * @return the infections
	 */
	public WebElement getInfections() {
		return infections;
	}

	/**
	 * @return the biohazard
	 */
	public WebElement getBiohazard() {
		return biohazard;
	}

	/**
	 * @return the radioactive
	 */
	public WebElement getRadioactive() {
		return radioactive;
	}

	/**
	 * @return the explosive
	 */
	public WebElement getExplosive() {
		return explosive;
	}

	/**
	 * @return the genDrugCode
	 */
	public WebElement getGenDrugCode() {
		return genDrugCode;
	}

	/**
	 * @return the genDrugShortName
	 */
	public WebElement getGenDrugShortName() {
		return genDrugShortName;
	}

	/**
	 * @return the genDrugName
	 */
	public WebElement getGenDrugName() {
		return genDrugName;
	}

	/**
	 * @return the genDrugNameAr
	 */
	public WebElement getGenDrugNameAr() {
		return genDrugNameAr;
	}

	/**
	 * @return the anatomicalMainGrp
	 */
	public WebElement getAnatomicalMainGrp() {
		return anatomicalMainGrp;
	}

	/**
	 * @return the therapeuticGroup
	 */
	public WebElement getTherapeuticGroup() {
		return therapeuticGroup;
	}

	/**
	 * @return the pharmacolSubClass
	 */
	public WebElement getPharmacolSubClass() {
		return pharmacolSubClass;
	}

	/**
	 * @return the chemicalSubGroup
	 */
	public WebElement getChemicalSubGroup() {
		return chemicalSubGroup;
	}

	/**
	 * @return the indication
	 */
	public WebElement getIndication() {
		return indication;
	}

	/**
	 * @return the narcoticDrug
	 */
	public WebElement getNarcoticDrug() {
		return narcoticDrug;
	}

	/**
	 * @return the contraIndication
	 */
	public WebElement getContraIndication() {
		return contraIndication;
	}

	/**
	 * @return the mechanismOfAction
	 */
	public WebElement getMechanismOfAction() {
		return mechanismOfAction;
	}

	/**
	 * @return the gridAddButton
	 */
	public WebElement getGridAddButton() {
		return gridAddButton;
	}

	/**
	 * @return the popupDiv
	 */
	public WebElement getPopupDiv() {
		return popupDiv;
	}

	/**
	 * @return the popupGender
	 */
	public WebElement getPopupGender() {
		return popupGender;
	}

	/**
	 * @return the basedOnAgeGrp
	 */
	public WebElement getBasedOnAgeGrp() {
		return basedOnAgeGrp;
	}

	/**
	 * @return the basedOnBodyWt
	 */
	public WebElement getBasedOnBodyWt() {
		return basedOnBodyWt;
	}

	/**
	 * @return the ageFrom
	 */
	public WebElement getAgeFrom() {
		return ageFrom;
	}

	/**
	 * @return the ageFromType
	 */
	public WebElement getAgeFromType() {
		return ageFromType;
	}

	/**
	 * @return the ageTo
	 */
	public WebElement getAgeTo() {
		return ageTo;
	}

	/**
	 * @return the ageToType
	 */
	public WebElement getAgeToType() {
		return ageToType;
	}

	/**
	 * @return the sigInstQuantity
	 */
	public WebElement getSigInstQuantity() {
		return sigInstQuantity;
	}

	/**
	 * @return the sigInstType
	 */
	public WebElement getSigInstType() {
		return sigInstType;
	}

	/**
	 * @return the frequencyAG
	 */
	public WebElement getFrequencyAG() {
		return frequencyAG;
	}

	/**
	 * @return the durationAG
	 */
	public WebElement getDurationAG() {
		return durationAG;
	}

	/**
	 * @return the durationTypeAG
	 */
	public WebElement getDurationTypeAG() {
		return durationTypeAG;
	}

	/**
	 * @return the dose
	 */
	public WebElement getDose() {
		return dose;
	}

	/**
	 * @return the doseTypeBW
	 */
	public WebElement getDoseTypeBW() {
		return doseTypeBW;
	}

	/**
	 * @return the frequencyBW
	 */
	public WebElement getFrequencyBW() {
		return frequencyBW;
	}

	/**
	 * @return the durationBW
	 */
	public WebElement getDurationBW() {
		return durationBW;
	}

	/**
	 * @return the durationTypeBW
	 */
	public WebElement getDurationTypeBW() {
		return durationTypeBW;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the pregnancy
	 */
	public WebElement getPregnancy() {
		return pregnancy;
	}

	/**
	 * @return the breastFeeding
	 */
	public WebElement getBreastFeeding() {
		return breastFeeding;
	}

	/**
	 * @return the infantAndChildren
	 */
	public WebElement getInfantAndChildren() {
		return infantAndChildren;
	}

	/**
	 * @return the elderlyAge
	 */
	public WebElement getElderlyAge() {
		return elderlyAge;
	}

	/**
	 * @return the discontinue
	 */
	public WebElement getDiscontinue() {
		return discontinue;
	}

	/**
	 * @return the heart
	 */
	public WebElement getHeart() {
		return heart;
	}

	/**
	 * @return the prolongedUse
	 */
	public WebElement getProlongedUse() {
		return prolongedUse;
	}

	/**
	 * @return the skinAndSunlight
	 */
	public WebElement getSkinAndSunlight() {
		return skinAndSunlight;
	}

	/**
	 * @return the driving
	 */
	public WebElement getDriving() {
		return driving;
	}

	/**
	 * @return the hazardousWork
	 */
	public WebElement getHazardousWork() {
		return hazardousWork;
	}

	/**
	 * @return the kidneyOrLiver
	 */
	public WebElement getKidneyOrLiver() {
		return kidneyOrLiver;
	}

	/**
	 * @return the discolorationOfUrine
	 */
	public WebElement getDiscolorationOfUrine() {
		return discolorationOfUrine;
	}

	/**
	 * @return the liver
	 */
	public WebElement getLiver() {
		return liver;
	}
}
