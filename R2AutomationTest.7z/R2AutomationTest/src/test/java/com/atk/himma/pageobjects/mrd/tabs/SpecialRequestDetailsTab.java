package com.atk.himma.pageobjects.mrd.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class SpecialRequestDetailsTab extends DriverWaitClass implements
		StatusMessages, TopControls, RecordStatus {

	public final static String ADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Add New']";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Save']";
	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Update']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Cancel']";
	public final static String REQUESTNO_NAME = "mrRequestDetails.requestNo";
	public final static String REQUESTEDBY_ID = "PHYSICIAN_NAME";
	public final static String LOOKUPREQUESTEDBY_CSS = "input#PHYSICIAN_NAME ~ a.lookup";
	public final static String REQDURATION_ID = "REQUIRED_DURATION";
	public final static String REQDURATIONTYPE_ID = "REQUIRED_DURATION_TYPE";
	public final static String REQBYLOCATION_ID = "LOCATION_NAME";
	public final static String REQREASON_ID = "REASON_ID";
	public final static String TOTALNOOFFILES_ID = "TOTAL_NO_OF_FILES_SELECTED";
	public final static String NOTES_ID = "REQUEST_COMMENT";

	// ----GRID(Requester Search)----
	public final static String PHYSEARFORMPOPUP_ID = "PHYSICIAN_SEARCH_FORM_POPUP_MRD";
	public final static String GRID_REQUSEARCH_ID = "physicianSearchGridList";
	public final static String GRID_RESCODE_ARIA_DESCRIBEDBY = "physicianSearchGridList_resourceCode";
	public final static String GRID_FULLNAME_ARIA_DESCRIBEDBY = "physicianSearchGridList_resourceName.fullName";
	public final static String RESOURCENAME_ID = "physicianId";
	public final static String RESOURCECODE_ID = "physicianCodeId";
	public final static String SEARCHBUTTON_ID = "SEARCH_PHYSICIAN_MRD";
	public final static String CANCELBUTTON_CSS = "#SEARCH_PHYSICIAN_MRD ~ input[value=Reset]";

	// ----GRID(List of Medical Records Required)----
	public final static String ADDROWSBUTTON_ID = "ADD_ROW_SPCL_REQ";
	public final static String GRID_ID = "SPCL_REQ_GRID";
	public final static String GRID_MRN_ARIA_DESCRIBEDBY = "SPCL_REQ_GRID_mrNumber";
	public final static String GRIDSEARCHLOOKUP_ID = "gridSearchLookup";
	public final static String GRID_VOLUMETXT_ARIA_DESCRIBEDBY = "SPCL_REQ_GRID_volumeText";
	public final static String GRIDVOLUME_CLASS = "ui-multiselect ui-state-default";
	public final static String GRIDVOLUMESELECTBUTTON_XPATH = "//table[@id='SPCL_REQ_GRID']//button[@type='button']";
	public final static String GRIDVOLUMESELECT_XPATH = "//ul[@class='ui-multiselect-checkboxes ui-helper-reset']//input[@class='required' and @type='checkbox']";
	public final static String GRID_NOOFFILES_ARIA_DESCRIBEDBY = "SPCL_REQ_GRID_numberOfFiles";
	public final static String GRIDNOOFFILES_NAME = "numberOfFiles";
	public final static String GRID_PATNAME_ARIA_DESCRIBEDBY = "SPCL_REQ_GRID_patientName";
	public final static String GRIDPATNAME_NAME = "patientName";
	public final static String GRID_CURRLOC_ARIA_DESCRIBEDBY = "SPCL_REQ_GRID_currentLocation";
	public final static String GRIDCURRENTLOCATION_NAME = "currentLocation";

	public final static String GRID_PAGER_ID = "sp_1_SPCL_REQ_GRID_pager";

	// ---------------Grid POPUP-Grid()-----------------------------------
	public final static String QUICKSEARCHTXT_ID = "searchTextName";
	public final static String PATSEARCHBUTTON_ID = "quickSearch";
	public final static String RESETBUTTON_ID = "quickSearchReset";
	public final static String GRID_PATSEARCH_ID = "generalSearchGridId";
	public final static String GRID_PATIENTNAME_ARIA_DESCRIBEDBY = "generalSearchGridId_patientName";

	public boolean fillDatas(String[] speReqDetDatas)
			throws InterruptedException {
		waitForElementCssSelector(LOOKUPREQUESTEDBY_CSS);
		lookupRequesteBy.click();
		waitForElementId(PHYSEARFORMPOPUP_ID);
		waitForElementId(GRID_REQUSEARCH_ID);
		resourceNameReSear.clear();
		resourceNameReSear.sendKeys(speReqDetDatas[0].trim());
		searchButtonReSear.click();
		clickOnGridAction(speReqDetDatas[1].trim(), "Select");
		sleepVeryShort();
		requestDuration.clear();
		requestDuration.sendKeys(speReqDetDatas[2].trim());
		new Select(requestDurType)
				.selectByVisibleText(speReqDetDatas[3].trim());
		new Select(reqReason).selectByVisibleText(speReqDetDatas[4].trim());
		addRow(speReqDetDatas[5].trim(), speReqDetDatas[6].trim());
		return checkGridEmpty(GRID_ID, GRID_PAGER_ID);
	}

	public void addRow(String patName, String volumeName)
			throws InterruptedException {
		waitForElementId(ADDROWSBUTTON_ID);
		addRowButton.click();
		waitForElementId(GRIDSEARCHLOOKUP_ID);
		gridLookup.click();
		waitForElementId(GRID_PATSEARCH_ID);
		sleepVeryShort();
		searchTxt.clear();
		searchTxt.sendKeys(patName.trim());
		patSearchButton.click();
		clickOnGridAction(patName.trim(), "Select");
		selectVolume(volumeName);
	}

	public void selectVolume(String volumeName) {
		webDriver.findElement(
				By.xpath(GRIDVOLUMESELECT_XPATH + "[@value='"
						+ volumeName.trim() + "']")).click();
	}

	@FindBy(className = UPDATEBUTTON_XPATH)
	private WebElement updateButton;
	
	@FindBy(className = GRIDVOLUMESELECTBUTTON_XPATH)
	private WebElement volSelectButton;

	@FindBy(id = GRIDVOLUMESELECT_XPATH)
	private WebElement volSelect;

	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement searchTxt;

	@FindBy(id = PATSEARCHBUTTON_ID)
	private WebElement patSearchButton;

	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	@FindBy(id = RESOURCENAME_ID)
	private WebElement resourceNameReSear;

	@FindBy(id = GRIDSEARCHLOOKUP_ID)
	private WebElement gridLookup;

	@FindBy(id = RESOURCECODE_ID)
	private WebElement resourceCodeReSear;

	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButtonReSear;

	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButtonReSear;

	@FindBy(xpath = ADDNEWBUTTON_XPATH)
	private WebElement addNewButton;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(name = REQUESTNO_NAME)
	private WebElement requestNo;

	@FindBy(id = REQUESTEDBY_ID)
	private WebElement requestedBy;

	@FindBy(id = REQDURATION_ID)
	private WebElement requestDuration;

	@FindBy(css = LOOKUPREQUESTEDBY_CSS)
	private WebElement lookupRequesteBy;

	@FindBy(id = REQDURATIONTYPE_ID)
	private WebElement requestDurType;

	@FindBy(id = REQBYLOCATION_ID)
	private WebElement reqByLocation;

	@FindBy(xpath = REQREASON_ID)
	private WebElement reqReason;

	@FindBy(id = TOTALNOOFFILES_ID)
	private WebElement totalNoOfFiles;

	@FindBy(xpath = NOTES_ID)
	private WebElement notes;

	@FindBy(xpath = ADDROWSBUTTON_ID)
	private WebElement addRowButton;

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the requestNo
	 */
	public WebElement getRequestNo() {
		return requestNo;
	}

	/**
	 * @return the requestedBy
	 */
	public WebElement getRequestedBy() {
		return requestedBy;
	}

	/**
	 * @return the requestDuration
	 */
	public WebElement getRequestDuration() {
		return requestDuration;
	}

	/**
	 * @return the lookupRequesteBy
	 */
	public WebElement getLookupRequesteBy() {
		return lookupRequesteBy;
	}

	/**
	 * @return the requestDurType
	 */
	public WebElement getRequestDurType() {
		return requestDurType;
	}

	/**
	 * @return the reqByLocation
	 */
	public WebElement getReqByLocation() {
		return reqByLocation;
	}

	/**
	 * @return the reqReason
	 */
	public WebElement getReqReason() {
		return reqReason;
	}

	/**
	 * @return the totalNoOfFiles
	 */
	public WebElement getTotalNoOfFiles() {
		return totalNoOfFiles;
	}

	/**
	 * @return the notes
	 */
	public WebElement getNotes() {
		return notes;
	}

	/**
	 * @return the arrowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the resourceNameReSear
	 */
	public WebElement getResourceNameReSear() {
		return resourceNameReSear;
	}

	/**
	 * @return the resourceCodeReSear
	 */
	public WebElement getResourceCodeReSear() {
		return resourceCodeReSear;
	}

	/**
	 * @return the searchButtonReSear
	 */
	public WebElement getSearchButtonReSear() {
		return searchButtonReSear;
	}

	/**
	 * @return the cancelButtonReSear
	 */
	public WebElement getCancelButtonReSear() {
		return cancelButtonReSear;
	}

	/**
	 * @return the gridLookup
	 */
	public WebElement getGridLookup() {
		return gridLookup;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the patSearchButton
	 */
	public WebElement getPatSearchButton() {
		return patSearchButton;
	}

	/**
	 * @return the searchTxt
	 */
	public WebElement getSearchTxt() {
		return searchTxt;
	}

	/**
	 * @return the volSelect
	 */
	public WebElement getVolSelect() {
		return volSelect;
	}

	/**
	 * @return the volSelectButton
	 */
	public WebElement getVolSelectButton() {
		return volSelectButton;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}
}
