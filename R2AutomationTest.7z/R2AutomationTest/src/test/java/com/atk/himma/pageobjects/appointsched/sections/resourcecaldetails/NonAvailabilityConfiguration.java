package com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class NonAvailabilityConfiguration extends DriverWaitClass{

	public final static String SECTIONNAME_LINKTEXT = "Non-Availability Configuration";
	public final static String ADDNONAVAILBUTTON_ID = "addNonAvailConfigToGridButton";
	public final static String VIEWCALBUTTON_ID = "VIEW_CALENDAR_LINK4";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Non-Availability Configuration')]/..";
	
//	
	public final static String FROMDATE_ID = "calNonAvailConfFromDateDP";
	public final static String TODATE_ID = "calNonAvailConfToDateDP";
	public final static String SELALLWORKDAYS_ID = "nonAvailselectAllCheckbox";
	public final static String APPLICABLEDAYS_ID = "multiselect_calNonAvailConfDayDD";
	public final static String SESSION_ID = "calNonAvailConfSessionDD";
	public final static String STTIME_ID = "calNonAvailConfStartTimeTP";
	public final static String ENDTIME_ID = "calNonAvailConfEndTimeTP";
	public final static String RECURRENCE_ID = "nonAvailCalConfRecurDD";

	public final static String ADDBUTTON_ID = "CAL_NON_AVAIL_CONFIG_SAVE_BUTTON";
	public final static String CANCELBUTTON_ID = "CAL_NON_AVAIL_CONFIG_CANCEL_BUTTON";
	
//	Grid
	public final static String GRIDID_ID = "calendarNonAvailConfigGrid";
	public final static String GRID_CONFIGTYPE_ID = "calendarNonAvailConfigGrid_configType";
	public final static String GRID_FROMDATE_ID = "calendarNonAvailConfigGrid_fromDate";
	public final static String GRID_TODATE_ID = "calendarNonAvailConfigGrid_toDate";
	public final static String GRID_SESSION_ARIA_DESCRIBEDBY = "calendarNonAvailConfigGrid_calendarSession.sessionName";
	public final static String GRID_STARTTIME_ARIA_DESCRIBEDBY = "calendarNonAvailConfigGrid_sessionStartTime";
	public final static String GRID_ENDTIME_ARIA_DESCRIBEDBY = "calendarNonAvailConfigGrid_sessionEndTime";
	public final static String GRID_APPLICDAYS_ARIA_DESCRIBEDBY = "calendarNonAvailConfigGrid_dayNames";
	public final static String GRID_RECURRENCE_ARIA_DESCRIBEDBY = "calendarNonAvailConfigGrid_recurrence";
	public final static String GRID_RELEASEBEFORE_ARIA_DESCRIBEDBY = "calendarNonAvailConfigGrid_releaseBefore";
	public final static String GRID_PAGERID = "sp_1_calendarNonAvailConfigGrid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_calendarNonAvailConfigGrid_pager']";
	
//	Pop Up End

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = ADDNONAVAILBUTTON_ID)
	private WebElement addNonAvailButton;
	
	@FindBy(id = VIEWCALBUTTON_ID)
	private WebElement viewCalButton;
	
	@FindBy(id = FROMDATE_ID)
	private WebElement fromDate;
	
	@FindBy(id = TODATE_ID)
	private WebElement toDate;
	
	@FindBy(id = SELALLWORKDAYS_ID)
	private WebElement selAllWorkDays;
	
	@FindBy(id = APPLICABLEDAYS_ID)
	private WebElement applicableDays;
	
	@FindBy(id = SESSION_ID)
	private WebElement session;
	
	@FindBy(id = STTIME_ID)
	private WebElement stTime;
	
	@FindBy(id = ENDTIME_ID)
	private WebElement endTime;
	
	@FindBy(id = RECURRENCE_ID)
	private WebElement recurrence;
	
	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;
	
	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	public boolean checkNonAvailRegSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean clickOnAddNonAvailButton() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(ADDNONAVAILBUTTON_ID);
		sleepVeryShort();
		addNonAvailButton.click();
		waitForElementId(FROMDATE_ID);
		waitForElementId(ADDBUTTON_ID);
		sleepVeryShort();
		return addButton.isDisplayed();
	}

	public boolean isMandFromDate() {
		waitForElementId(FROMDATE_ID);
		return isMandatoryField(fromDate);
	}
	
	public boolean isMandToDate() {
		waitForElementId(TODATE_ID);
		return isMandatoryField(toDate);
	}
	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the addAvailButton
	 */
	public WebElement getNonAddAvailButton() {
		return addNonAvailButton;
	}

	/**
	 * @return the viewCalButton
	 */
	public WebElement getViewCalButton() {
		return viewCalButton;
	}

	/**
	 * @return the fromDate
	 */
	public WebElement getFromDate() {
		return fromDate;
	}

	/**
	 * @return the toDate
	 */
	public WebElement getToDate() {
		return toDate;
	}

	/**
	 * @return the selAllWorkDays
	 */
	public WebElement getSelAllWorkDays() {
		return selAllWorkDays;
	}

	/**
	 * @return the applicableDays
	 */
	public WebElement getApplicableDays() {
		return applicableDays;
	}

	/**
	 * @return the session
	 */
	public WebElement getSession() {
		return session;
	}

	/**
	 * @return the stTime
	 */
	public WebElement getStTime() {
		return stTime;
	}

	/**
	 * @return the endTime
	 */
	public WebElement getEndTime() {
		return endTime;
	}

	/**
	 * @return the recurrence
	 */
	public WebElement getRecurrence() {
		return recurrence;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}
	
}
