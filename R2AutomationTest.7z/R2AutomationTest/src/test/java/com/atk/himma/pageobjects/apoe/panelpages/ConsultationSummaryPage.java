package com.atk.himma.pageobjects.apoe.panelpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ConsultationSummaryPage extends DriverWaitClass {
	public final static String CONSSMRYSAVEBTN_XPATH = ".//form[@id='CONSULTATION_SUMMARY_FORM']/..//input[@value='Save']";
	@FindBy(xpath = CONSSMRYSAVEBTN_XPATH)
	private WebElement conSummmarySaveBtn;

	public final static String CONSSMRYUPDATEBTN_ID = "UPDATE_CONSUMMARY_BT";
	@FindBy(id = CONSSMRYUPDATEBTN_ID)
	private WebElement conSummmaryUpdateBtn;

	public final static String CONSSMRYCANCELBTN_XPATH = ".//form[@id='CONSULTATION_SUMMARY_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = CONSSMRYCANCELBTN_XPATH)
	private WebElement conSummmaryCancelBtn;

	public final static String CONSRADIOBTN_ID = "CONSULTATION_RADIO";
	@FindBy(id = CONSRADIOBTN_ID)
	private WebElement consRadioBtn;

	public final static String PATREPORT_ID = "PATIENT_REPORT_RADIO";
	@FindBy(id = PATREPORT_ID)
	private WebElement patReportRadioBtn;

	public final static String EDITCONSBTN_ID = "EDIT_CONSULTATION_SUMMARY";
	@FindBy(id = EDITCONSBTN_ID)
	private WebElement editConsBtn;

	public final static String SAVEREPORTBTN_ID = "SAVE_REPORT_CON_SUMMARY_BT";
	@FindBy(id = SAVEREPORTBTN_ID)
	private WebElement saveReportBtn;

	public final static String SIGNREPORTBTN_ID = "SIGN_REPORT_CON_SUMMARY_BT";
	@FindBy(id = SIGNREPORTBTN_ID)
	private WebElement signReportBtn;

	public final static String PRINTREPORTBTN_ID = "PRINT_REPORT_CON_SUMMARY_BT";
	@FindBy(id = PRINTREPORTBTN_ID)
	private WebElement printReportBtn;

	public final static String PRINTSMRYBTN_ID = "SUMMARY_REPORT_CON_SUMMARY_BT";
	@FindBy(id = PRINTSMRYBTN_ID)
	private WebElement printSummaryBtn;
	
	public void saveConsSummaryDetails() throws Exception {
		conSummmarySaveBtn.click();
		sleepVeryShort();
		waitForElementId(CONSSMRYUPDATEBTN_ID);
	}

	public WebElement getConSummmarySaveBtn() {
		return conSummmarySaveBtn;
	}

	public WebElement getConSummmaryUpdateBtn() {
		return conSummmaryUpdateBtn;
	}

	public WebElement getConSummmaryCancelBtn() {
		return conSummmaryCancelBtn;
	}

	public WebElement getConsRadioBtn() {
		return consRadioBtn;
	}

	public WebElement getPatReportRadioBtn() {
		return patReportRadioBtn;
	}

	public WebElement getEditConsBtn() {
		return editConsBtn;
	}

	public WebElement getSaveReportBtn() {
		return saveReportBtn;
	}

	public WebElement getSignReportBtn() {
		return signReportBtn;
	}

	public WebElement getPrintReportBtn() {
		return printReportBtn;
	}

	public WebElement getPrintSummaryBtn() {
		return printSummaryBtn;
	}

}
