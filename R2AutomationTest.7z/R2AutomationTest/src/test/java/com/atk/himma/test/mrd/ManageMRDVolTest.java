package com.atk.himma.test.mrd;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mrd.ManageMRVolPage;
import com.atk.himma.pageobjects.preg.PatientSearchPage;
import com.atk.himma.setup.SeleniumDriverSetup;

@Test(groups = { "functionalTestGrp" })
public class ManageMRDVolTest extends SeleniumDriverSetup {

	PatientSearchPage patientSearchPage;
	ManageMRVolPage manageMRVolPage;
	List<String[]> mrdVolDatas, editMrdVolDatas;
	String addNewVolumeNo;

	// static String searchText = "PatMRNum-000198";
	// static String name = "Kd1 Kd1";

	@Test(description = "Open Patient Search Page")
	public void test001OpenPatSearchPage() {
		patientSearchPage = PageFactory.initElements(webDriver,
				PatientSearchPage.class);
		patientSearchPage = patientSearchPage.clickOnPatientSearchLogo(
				webDriver, webDriverWait);
		doDirtyFormCheck();
		patientSearchPage.waitForElementId(PatientSearchPage.getFormnameId());
		patientSearchPage.waitForElementVisibilityOf(patientSearchPage
				.getSearchButton());
		Assert.assertNotNull(patientSearchPage.getFormName(),
				"Fail: Patient Search page loaded.");
	}

	@Test(description = "Check privilege of MRVolumeLink", dependsOnMethods = { "test001OpenPatSearchPage" })
	public void test002CheckManageMRVolLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("mrdExcel"));
		mrdVolDatas = excelReader.read(properties.getProperty("manageMRDVol"));
		for (String[] st : mrdVolDatas.subList(0, 1)) {
			Assert.assertEquals(
					patientSearchPage.checkManageMRVolumeLink(st[0].trim()),
					true,
					"Fail to appearance of 'Manage MR Volume' action link");
		}
	}

	@Test(description = "Check Accessibility to 'Manage MR Volume' screen", dependsOnMethods = { "test002CheckManageMRVolLink" })
	public void test003ClickOnManageMRVolLink() throws InterruptedException {
		for (String[] st : mrdVolDatas.subList(0, 1)) {
			manageMRVolPage = patientSearchPage.clickOnManageMRVolLink(st[0]);
			manageMRVolPage.setWebDriver(webDriver);
			manageMRVolPage.setWebDriverWait(webDriverWait);

			Assert.assertEquals(manageMRVolPage.getPatAddNewButton()
					.getAttribute("value").trim().equals("Add New"), true,
					"Fail to Access 'Manage MR Volume' screen");
		}
	}

	@Test(description = "Verify MR Volume Creation", dependsOnMethods = { "test003ClickOnManageMRVolLink" })
	public void test004VerifyVolCreation() throws InterruptedException {
		Assert.assertEquals(manageMRVolPage.verifyVolCreation(), false,
				"Fail to Verify MR Volume Creation");
	}

	@Test(description = "Verify Patient search Name with Patient Banner", dependsOnMethods = { "test003ClickOnManageMRVolLink" })
	public void test005VerifyPatBanner() throws InterruptedException {
		for (String[] st : mrdVolDatas.subList(0, 1)) {
			Assert.assertEquals(manageMRVolPage.verifyPatBanner(st[0].trim()),
					true,
					"Fail to Verify Patient search Name with Patient Banner");
		}
	}

	@Test(description = "Verify 'Add New' Button Appearance.", dependsOnMethods = { "test003ClickOnManageMRVolLink" })
	public void test006VerifyAddNewButton() throws InterruptedException {
		Assert.assertEquals(
				manageMRVolPage.verifyAddNewButton().equals("Add New"), true,
				"Fail to Verify 'Add New' Button Appearance.");
	}

	@Test(description = "Verify Click on 'Add New' Button.", dependsOnMethods = { "test006VerifyAddNewButton" })
	public void test007ClickOnAddNewButton() throws InterruptedException {
		Assert.assertEquals(manageMRVolPage.clickOnAddNewButton(), true,
				"Fail to Verify Click on 'Add New' Button.");
	}

	@Test(description = "Verify Delete Link", dependsOnMethods = { "test007ClickOnAddNewButton" })
	public void test008VerifyDeleteLink() throws InterruptedException {
		addNewVolumeNo = Integer.toString(manageMRVolPage.countGridAllRows(
				ManageMRVolPage.GRID_ID,
				ManageMRVolPage.GRID_VOLUME_ARIA_DESCRIBEDBY));
		Assert.assertEquals(manageMRVolPage.verifyDeleteLink(addNewVolumeNo),
				true, "Fail to Verify Delete Link");
	}

	@Test(description = "Verify Edit Link", dependsOnMethods = { "test007ClickOnAddNewButton" })
	public void test009VerifyEditSlotLink() throws InterruptedException {
		Assert.assertEquals(manageMRVolPage.verifyEditSlotLink(addNewVolumeNo),
				true, "Fail to Verify Edit Link");
	}

	@Test(description = "Verify Print Label Link", dependsOnMethods = { "test007ClickOnAddNewButton" })
	public void test010VerifyPrintLabelLink() throws InterruptedException {
		Assert.assertEquals(
				manageMRVolPage.verifyPrintLabelLink(addNewVolumeNo), true,
				"Fail to Verify Print Label Link");
	}

	@Test(description = "Edit Slot at selected volume No", dependsOnMethods = { "test009VerifyEditSlotLink" })
	public void test011EditSlot() throws InterruptedException, IOException {
		editMrdVolDatas = excelReader.read(properties
				.getProperty("editManageMRDVol"));
		for (String[] st : editMrdVolDatas.subList(0, 1)) {
			Assert.assertEquals(
					manageMRVolPage.editSlot(addNewVolumeNo, st[2]), true,
					"Fail to Edit Slot at selected volume No");
		}
	}
	
	@Test(description = "Print MR volume Label", dependsOnMethods = { "test010VerifyPrintLabelLink" })
	public void test012ClickonPrintLabelLink() throws InterruptedException {
		Assert.assertEquals(manageMRVolPage.clickonPrintLabelLink("1"), true,
				"Fail to Print MR volume Label");
	}
	
}
