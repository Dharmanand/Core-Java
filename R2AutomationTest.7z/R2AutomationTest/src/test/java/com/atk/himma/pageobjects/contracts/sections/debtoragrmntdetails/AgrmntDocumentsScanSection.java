package com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AgrmntDocumentsScanSection extends DriverWaitClass {
	public final static String AGRMNTDOCSCANSEC_LINKTEXT = "Agreement Documents Scan";
	public final static String ADDROWAGRMNTDOCBTN = "AddRow_AgrDocForm_Action";
	public final static String ADDAGRMNTDOCDIV = "AddRow_AgrDocForm";
	public final static String AGRMNTDOCNAME = "AGMNT_DOC_NAME";
	public final static String UPLOADDOCBTN = "agrmntfileupload";
	public final static String ADDBTN = "Add_AgrDocForm_Btn";
	public final static String CANCELROW = "CancelRow_AgrDocForm_Action";
	public final static String AGRMNTDOCGRIDDIV = "AGMNT_DOCUMENT_GRID_DIV";
	public final static String VIEWLINK_XPATH = ".//table[@id='AGR_DOC_SCAN_GRID']/..//a[text()=' View ']";
	public final static String DELETELINK_XPATH = ".//table[@id='AGR_DOC_SCAN_GRID']/..//a[text()=' Delete ']";

	@FindBy(linkText = AGRMNTDOCSCANSEC_LINKTEXT)
	private WebElement agrmntDocScanSec;

	@FindBy(id = ADDROWAGRMNTDOCBTN)
	private WebElement addRowBtn;

	@FindBy(id = ADDAGRMNTDOCDIV)
	private WebElement addAgrmntDocDiv;

	@FindBy(id = AGRMNTDOCNAME)
	private WebElement agrmntDocName;

	@FindBy(id = UPLOADDOCBTN)
	private WebElement uploadDocBtn;

	@FindBy(id = ADDBTN)
	private WebElement addBtn;

	@FindBy(id = CANCELROW)
	private WebElement cancelBtn;

	@FindBy(id = AGRMNTDOCGRIDDIV)
	private WebElement agrmntDocGridDiv;

	public void addAgrmntDocsData(String[] debtorAgrmntListData)
			throws Exception {
		addRowBtn.click();
		waitForElementId(ADDAGRMNTDOCDIV);
		agrmntDocName.clear();
		agrmntDocName.sendKeys(debtorAgrmntListData[20]);
		uploadDocBtn.sendKeys(debtorAgrmntListData[21]);
		sleepVeryShort();
		addBtn.click();
		waitForElementId(AGRMNTDOCGRIDDIV);

	}

	public boolean checkAgrmntDocGrid(String[] debtorAgrmntListData) {
		try {
			waitForElementXpathExpression(".//td[@aria-describedby='AGR_DOC_SCAN_GRID_docName' and @title='"
					+ debtorAgrmntListData[20] + "']");
			return webDriver
					.findElement(
							By.xpath(".//td[@aria-describedby='AGR_DOC_SCAN_GRID_docName' and @title='"
									+ debtorAgrmntListData[20] + "']"))
					.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public WebElement getAgrmntDocScanSec() {
		return agrmntDocScanSec;
	}

	public WebElement getAddRowBtn() {
		return addRowBtn;
	}

	public WebElement getAddAgrmntDocDiv() {
		return addAgrmntDocDiv;
	}

	public WebElement getAgrmntDocName() {
		return agrmntDocName;
	}

	public WebElement getUploadDocBtn() {
		return uploadDocBtn;
	}

	public WebElement getAddBtn() {
		return addBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getAgrmntDocGridDiv() {
		return agrmntDocGridDiv;
	}

}
