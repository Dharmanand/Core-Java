package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AllergyPopupPage extends DriverWaitClass {
	public final static String ALRGYPOPUPFORM_ID = "ALLERGY_POP_UP_FORM";
	@FindBy(id = ALRGYPOPUPFORM_ID)
	private WebElement allergyPopupForm;

	public final static String ALRGYNAME_ID = "ALLERGY_POP_UP_NAME_TXT";
	@FindBy(id = ALRGYNAME_ID)
	private WebElement allergyName;

	public final static String ALLERGEN_ID = "ALLERGN_POP_UP_DN";
	@FindBy(id = ALLERGEN_ID)
	private WebElement allergen;

	public final static String ALRGYTYPE_NAME = "allergyTypeText";
	@FindBy(name = ALRGYTYPE_NAME)
	private WebElement allergyType;

	public final static String SEVERITY_NAME = "severityText";
	@FindBy(name = SEVERITY_NAME)
	private WebElement severity;

	public final static String ONSETDATE_ID = "START_DATE_COMP";
	@FindBy(id = ONSETDATE_ID)
	private WebElement onSetDate;

	public final static String STOPDATE_ID = "END_DATE_COMP";
	@FindBy(id = STOPDATE_ID)
	private WebElement stopDate;

	public final static String CONFIDENCELVL_NAME = "confidentLevelText";
	@FindBy(name = CONFIDENCELVL_NAME)
	private WebElement confidenceLevel;

	public final static String SOURCEINFO_NAME = "sourceInfoText";
	@FindBy(name = SOURCEINFO_NAME)
	private WebElement sourceInfo;

	public final static String CAPTON_ID = "CAPUTERED_ON_POP_UP_ID";
	@FindBy(id = CAPTON_ID)
	private WebElement capturedOn;

	public final static String SIGNIFCHKBOX_ID = "ALLERGY_POP_UP_FORM_significant";
	@FindBy(id = SIGNIFCHKBOX_ID)
	private WebElement significantChkBox;

	public final static String REACTIONSMULTISELECT_NAME = "multiselect_ALLERGY_REACTIONS_POP_UP";
	@FindBy(name = REACTIONSMULTISELECT_NAME)
	private WebElement reactionsMultiselctChkBox;

	public final static String COMMENTS_NAME = "comments";
	@FindBy(name = COMMENTS_NAME)
	private WebElement comments;

	public final static String ADDALRGYBTN_ID = "ADD_POPUP_ALLERGIES_BUT";
	@FindBy(id = ADDALRGYBTN_ID)
	private WebElement addAllergyBtn;

	public final static String UPDATEALRGYBTN_ID = "EDIT_POPUP_ALLERGIES_BUT";
	@FindBy(id = UPDATEALRGYBTN_ID)
	private WebElement updateAllergyBtn;

	public final static String RESETALRGYBTN_ID = "CANCEL_POP_UP_ALLERGIES_BUT";
	@FindBy(id = RESETALRGYBTN_ID)
	private WebElement resetAllergyBtn;

	public final static String ALRGYPOPUPTBL_ID = "ALLERGIES_POPUP_GRID_ID";
	@FindBy(id = ALRGYPOPUPTBL_ID)
	private WebElement allergyPopupGridTbl;

	public final static String CANCELALRGYPOPUP_XPATH = "//form[@id='ALLERGY_FORM']//input[@value='Cancel']";
	@FindBy(xpath = CANCELALRGYPOPUP_XPATH)
	private WebElement cancelAllergyPopup;

	public final static String SAVEALRGYPOPUP_XPATH = "//form[@id='ALLERGY_FORM']//input[@value='Save']";
	@FindBy(xpath = SAVEALRGYPOPUP_XPATH)
	private WebElement saveAllergyPopup;

	public boolean isMandAllergyName() {
		waitForElementId(ALRGYNAME_ID);
		return isMandatoryField(allergyName);
	}

	public void addAllergyDetails(String[] orderEntryListData) {
		waitForElementId(ALRGYPOPUPFORM_ID);
		waitForElementId(ALRGYNAME_ID);
		allergyName.clear();
		allergyName.sendKeys(orderEntryListData[0]);
		if (!orderEntryListData[1].isEmpty()) {
			new Select(allergen).selectByVisibleText(orderEntryListData[1]);
		}
		if (!orderEntryListData[2].isEmpty()) {
			new Select(allergyType).selectByVisibleText(orderEntryListData[2]);
		}
		if (!orderEntryListData[3].isEmpty()) {
			new Select(severity).selectByVisibleText(orderEntryListData[3]);
		}
		onSetDate.clear();
		onSetDate.sendKeys(orderEntryListData[4]);
		stopDate.clear();
		stopDate.sendKeys(orderEntryListData[5]);
		if (!orderEntryListData[6].isEmpty()) {
			new Select(confidenceLevel)
					.selectByVisibleText(orderEntryListData[6]);
		}
		if (!orderEntryListData[7].isEmpty()) {
			new Select(sourceInfo).selectByVisibleText(orderEntryListData[7]);
		}
		if (Boolean.valueOf(orderEntryListData[8])) {
			significantChkBox.click();
		}
		String[] temp;
		String delimiter = "\\,";
		temp = orderEntryListData[9].split(delimiter);
		for (int i = 0; i < temp.length; i++) {
			webDriver.findElement(
					By.xpath("//input[@name='" + REACTIONSMULTISELECT_NAME
							+ "' and @title='" + temp[i] + "']")).click();
		}
		comments.clear();
		comments.sendKeys(orderEntryListData[10]);
	}

	public void clickAddAlrgyBtn() {
		addAllergyBtn.click();
		waitForElementId(ALRGYPOPUPTBL_ID);
	}

	public void clickResetAlrgyBtn() {
		resetAllergyBtn.click();
	}

	public String chkAlrgyDataGrid(String[] orderEntryListData) {
		return waitAndGetGridFirstCellText(ALRGYPOPUPTBL_ID,
				"ALLERGIES_POPUP_GRID_ID_allergyName", orderEntryListData[79]);
	}

	public void saveAlrgyDetails() throws Exception {
		saveAllergyPopup.click();
		sleepShort();
	}

	public boolean chkEditLink(String[] orderEntryListData) {
		waitForElementXpathExpression("//td[@aria-describedby='ALLERGIES_POPUP_GRID_ID_allergyName' and @title='"
				+ orderEntryListData[0] + "']/..//a[@title='Edit']");
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='ALLERGIES_POPUP_GRID_ID_allergyName' and @title='"
								+ orderEntryListData[0]
								+ "']/..//a[@title='Edit']")).isDisplayed();
	}

	public boolean chkDeleteLink(String[] orderEntryListData) {
		waitForElementXpathExpression("//td[@aria-describedby='ALLERGIES_POPUP_GRID_ID_allergyName' and @title='"
				+ orderEntryListData[0] + "']/..//a[@title='Delete']");
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='ALLERGIES_POPUP_GRID_ID_allergyName' and @title='"
								+ orderEntryListData[0]
								+ "']/..//a[@title='Delete']")).isDisplayed();
	}

	public void editAllergyDetails(String[] orderEntryListData) {
		clickOnGridAction("ALLERGIES_POPUP_GRID_ID_allergyName",
				orderEntryListData[0], "Edit");
		waitForElementId(UPDATEALRGYBTN_ID);
		if (!orderEntryListData[1].isEmpty()) {
			new Select(allergen).selectByVisibleText(orderEntryListData[1]);
		}
		if (!orderEntryListData[2].isEmpty()) {
			new Select(allergyType).selectByVisibleText(orderEntryListData[2]);
		}
		if (!orderEntryListData[3].isEmpty()) {
			new Select(severity).selectByVisibleText(orderEntryListData[3]);
		}

	}

	public void clickUpdateAlrgyBtn() throws Exception {
		updateAllergyBtn.click();
		sleepVeryShort();
	}

	public String chkUpdatedAlrgyDtl(String[] orderEntryListData) {
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='ALLERGIES_POPUP_GRID_ID_allergyName' and @title='"
								+ orderEntryListData[1] + "'")).getText();
	}

	public boolean deleteAllergyDetails(String[] orderEntryListData) {
		clickOnGridAction("ALLERGIES_POPUP_GRID_ID_allergyName",
				orderEntryListData[0], "Delete");
		boolean result = false;
		try {
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='ALLERGIES_POPUP_GRID_ID_allergyName' and @title='"
									+ orderEntryListData[0] + "'"))
					.isDisplayed();
		} catch (Exception e) {

		}
		return result;
	}

	public void clickCancelBtn() throws Exception {
		cancelAllergyPopup.click();

	}

	public boolean isAlrgyPopupDisplayed() throws Exception {
		waitForElementId(ALRGYPOPUPFORM_ID);
		return allergyPopupForm.isDisplayed();
	}

	public WebElement getAllergyPopupForm() {
		return allergyPopupForm;
	}

	public WebElement getAllergyName() {
		return allergyName;
	}

	public WebElement getAllergen() {
		return allergen;
	}

	public WebElement getAllergyType() {
		return allergyType;
	}

	public WebElement getSeverity() {
		return severity;
	}

	public WebElement getOnSetDate() {
		return onSetDate;
	}

	public WebElement getStopDate() {
		return stopDate;
	}

	public WebElement getConfidenceLevel() {
		return confidenceLevel;
	}

	public WebElement getSourceInfo() {
		return sourceInfo;
	}

	public WebElement getCapturedOn() {
		return capturedOn;
	}

	public WebElement getSignificantChkBox() {
		return significantChkBox;
	}

	public WebElement getReactionsMultiselctChkBox() {
		return reactionsMultiselctChkBox;
	}

	public WebElement getComments() {
		return comments;
	}

	public WebElement getAddAllergyBtn() {
		return addAllergyBtn;
	}

	public WebElement getUpdateAllergyBtn() {
		return updateAllergyBtn;
	}

	public WebElement getResetAllergyBtn() {
		return resetAllergyBtn;
	}

	public WebElement getAllergyPopupGridTbl() {
		return allergyPopupGridTbl;
	}

	public WebElement getCancelAllergyPopup() {
		return cancelAllergyPopup;
	}

	public WebElement getSaveAllergyPopup() {
		return saveAllergyPopup;
	}

}
