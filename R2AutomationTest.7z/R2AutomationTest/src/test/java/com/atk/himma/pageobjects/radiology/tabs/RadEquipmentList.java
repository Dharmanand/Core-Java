package com.atk.himma.pageobjects.radiology.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RadEquipmentList extends DriverWaitClass{
	
	public final static String QUICKSEARCH_ID = "SEARCH_TEXT_FIELD";
	public final static String SEARCHBUTTON_ID = "QSEARCH_BT_ID";
	public final static String ADVSEARBUTTON_ID = "FLOTING_CRITERIA_BT_ID";
	public final static String EXPORTTOEXCELBUTTON_ID = "equipment_detail_grid_export_btn";

//	-----------GRID--------------
	public final static String GRID_ID = "equipment_detail_grid";
	public final static String GRID_EQUIPCODE_ARIA_DESCRIBEDBY = "equipment_detail_grid_equipmentCode";
	public final static String GRID_EQUIPSHORTNAME_ARIA_DESCRIBEDBY = "equipment_detail_grid_equipmentCode";
	public final static String GRID_EQUIPNAME_ARIA_DESCRIBEDBY = "equipment_detail_grid_equipmentName";
	public final static String GRID_RESOURCETYPE_ARIA_DESCRIBEDBY = "equipment_detail_grid_resourceType";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "equipment_detail_grid_department";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "equipment_detail_grid_mainBusinessUnit";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "equipment_detail_grid_status";
	public final static String GRID_PAGERID = "sp_1_equipment_detail_grid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_equipment_detail_grid_pager']";
	
	@FindBy(id = QUICKSEARCH_ID)
	private WebElement quickSearch;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(id = ADVSEARBUTTON_ID)
	private WebElement advSearchButton;
	
	/**
	 * @return the quickSearch
	 */
	public WebElement getQuickSearch() {
		return quickSearch;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the exportToExcelButton
	 */
	public WebElement getExportToExcelButton() {
		return exportToExcelButton;
	}

	@FindBy(id = EXPORTTOEXCELBUTTON_ID)
	private WebElement exportToExcelButton;
	
}
