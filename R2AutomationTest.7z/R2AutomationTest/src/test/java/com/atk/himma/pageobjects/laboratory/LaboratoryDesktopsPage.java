package com.atk.himma.pageobjects.laboratory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LaboratoryDesktopsPage extends DriverWaitClass {
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String DTQSEARCHTXT_ID = "SEARCH_STRING";
	@FindBy(id = DTQSEARCHTXT_ID)
	private WebElement DTQSearchTxt;

	public final static String DTQSEARCHBTN_ID = "DESKTOP_SEARCH";
	@FindBy(id = DTQSEARCHBTN_ID)
	private WebElement DTQSearchBtn;

	public final static String DTRESETBTN_ID = "DESKTOP_RESET";
	@FindBy(id = DTRESETBTN_ID)
	private WebElement DTResetBtn;

	public final static String DTADVSEARCHBTN_ID = "RECDESK_ADVANCED_SEARCH";
	@FindBy(id = DTADVSEARCHBTN_ID)
	private WebElement DTAdvsearchBtn;

	public final static String DTADVSEARCHDIV_ID = "RD_ADV_SEARCH_DIV";
	@FindBy(id = DTADVSEARCHDIV_ID)
	private WebElement DTAdvSearchDiv;

	public final static String MBU_ID = "MAIN_BUSINESS_UNIT_ID";
	@FindBy(id = MBU_ID)
	private WebElement mbu;

	public final static String SEARCHPERIOD_ID = "LAB_SEARCH_PERIOD";
	@FindBy(id = SEARCHPERIOD_ID)
	private WebElement searchPeriod;

	public final static String NOFILTER_ID = "BY_NO_FILTER";
	@FindBy(id = NOFILTER_ID)
	private WebElement noFilter;

	public final static String FILTERBYPAT_ID = "BY_PATIENT";
	@FindBy(id = FILTERBYPAT_ID)
	private WebElement filterByPat;

	public final static String FILTERBYREFPHYS_ID = "BY_REFFERED_PHYSICIAN";
	@FindBy(id = FILTERBYREFPHYS_ID)
	private WebElement filterByRefPhys;

	public final static String FILTERBYENC_ID = "BY_ENCOUNTER";
	@FindBy(id = FILTERBYENC_ID)
	private WebElement filterByEnc;

	public final static String FILTERBYLOC_ID = "BY_LOCATION";
	@FindBy(id = FILTERBYLOC_ID)
	private WebElement filterByLoc;

	public final static String FILTERBYSERV_ID = "BY_SERVICE";
	@FindBy(id = FILTERBYSERV_ID)
	private WebElement filterByServ;

	public final static String ADVSEARCHBTN_XPATH = "//form[@id='RECEPTIONIST_DESKTOP']//span[@class='buttoncontainer_mid']//input[@value='Search']";
	@FindBy(xpath = ADVSEARCHBTN_XPATH)
	private WebElement advSearchBtn;

	public final static String ADVRESETBTN_XPATH = "//form[@id='RECEPTIONIST_DESKTOP']//span[@class='buttoncontainer_mid']//input[@value='Reset']";
	@FindBy(xpath = ADVRESETBTN_XPATH)
	private WebElement advResetBtn;

	public final static String INVOICEBTN_ID = "RD_INVOICE_BUT_ID";
	@FindBy(id = INVOICEBTN_ID)
	private WebElement invoiceBtn;

	public final static String CREATEINVOICEBTN_ID = "CREATE_INVOICE";
	@FindBy(id = CREATEINVOICEBTN_ID)
	private WebElement createInvoiceBtn;

	public final static String INVRECEIPTFORM_ID = "invoiceReceiptForm";
	@FindBy(id = INVRECEIPTFORM_ID)
	private WebElement invReceiptForm;

	public final static String PAYMENTTYPE_ID = "PAYMENT_TYPE";
	@FindBy(id = PAYMENTTYPE_ID)
	private WebElement paymentType;

	public final static String PAYMENTCURRENCY_ID = "PAYMENT_CURRENCY";
	@FindBy(id = PAYMENTCURRENCY_ID)
	private WebElement paymentCurrency;

	public final static String AMOUNT_ID = "AMOUNT";
	@FindBy(id = AMOUNT_ID)
	private WebElement amount;

	public final static String SUBMIT_XPATH = "//form[@id='invoiceReceiptForm']//input[@value='Submit']";
	@FindBy(xpath = SUBMIT_XPATH)
	private WebElement submit;

	public final static String RESET_XPATH = "//form[@id='invoiceReceiptForm']//input[@value='Reset']";
	@FindBy(xpath = RESET_XPATH)
	private WebElement reset;

	public final static String INVRECPTPAYMENTGRIDTBL_ID = "INVOICE_RECEIPT_PAYMENT_GRID";
	@FindBy(id = INVRECPTPAYMENTGRIDTBL_ID)
	private WebElement invRecptPaymentGridTbl;

	public final static String SAVEDEPORECPT_ID = "saveDepositReceipt";
	@FindBy(id = SAVEDEPORECPT_ID)
	private WebElement saveDepoRecpt;

	public final static String CANCELDEPORECPT_XPATH = "//form[@id='invoiceReceiptForm']//input[@value='Cancel']";
	@FindBy(xpath = CANCELDEPORECPT_XPATH)
	private WebElement cancelDepoRecpt;

	public final static String VISITCAT_ID = "RECEIPTIONIST_VISIT_CATEGORY";
	@FindBy(id = VISITCAT_ID)
	private WebElement visitCat;

	public final static String PRINTREPORTSBTN_ID = "PRINT_REPORTS";
	@FindBy(id = PRINTREPORTSBTN_ID)
	private WebElement printReportsBtn;

	public final static String REPRINTLABELSBTN_ID = "PRINT_LABEL";
	@FindBy(id = REPRINTLABELSBTN_ID)
	private WebElement reprintLabelsBtn;

	public final static String SEDTOEXTERNALLABBTN_ID = "MSC_SEND_TO_EXT_LAB_BUTTON";
	@FindBy(id = SEDTOEXTERNALLABBTN_ID)
	private WebElement sedToExternalLabBtn;

	public final static String ARRIVEBTN_ID = "DESKTOP_ARRIVE_BUTTON";
	@FindBy(id = ARRIVEBTN_ID)
	private WebElement arriveBtn;

	public final static String SPECCOLLGRIDTBL_ID = "DESKTOP_SPECIMEN_COLLECTION_GRID";
	@FindBy(id = SPECCOLLGRIDTBL_ID)
	private WebElement specCollGridTbl;

	public final static String COLLECTEDVOL_NAME = "collectedVol";
	@FindBy(name = COLLECTEDVOL_NAME)
	private WebElement collectedVol;

	public final static String UOM_NAME = "uomId";
	@FindBy(name = UOM_NAME)
	private WebElement uom;

	public final static String FIXATIVE_NAME = "fixativeId";
	@FindBy(name = FIXATIVE_NAME)
	private WebElement fixative;

	public final static String ANATOMICSITE_NAME = "anatomicSiteId";
	@FindBy(name = ANATOMICSITE_NAME)
	private WebElement anatomicSite;

	public final static String REMARKS_NAME = "remarks";
	@FindBy(name = REMARKS_NAME)
	private WebElement remarks;

	public final static String COLLECTBTN_XPATH = "//form[@id='DESKTOP_SPECIMEN_COLLECTION']//input[@value='Collect']";
	@FindBy(xpath = COLLECTBTN_XPATH)
	private WebElement collectBtn;

	public final static String SPECCOLLNSENDBTN_ID = "SEND_BUTTON";
	@FindBy(id = SPECCOLLNSENDBTN_ID)
	private WebElement specCollnSendBtn;

	public final static String SPECCOLLNDTTIMEFORM_ID = "SPECIMEN_COLLECTION_DATE_TIME_SEND";
	@FindBy(id = SPECCOLLNDTTIMEFORM_ID)
	private WebElement specCollnDtTimeForm;

	public final static String COLLNDTTIMESUBMIT_XPATH = "//form[@id='SPECIMEN_COLLECTION_DATE_TIME_SEND']//input[@value='Submit']";
	@FindBy(xpath = COLLNDTTIMESUBMIT_XPATH)
	private WebElement collnDtTimeSubmit;

	public final static String COLLNDTTIMECANCEL_XPATH = "//form[@id='SPECIMEN_COLLECTION_DATE_TIME_SEND']//input[@value='Cancel']";
	@FindBy(xpath = COLLNDTTIMECANCEL_XPATH)
	private WebElement collnDtTimeCancel;

	public final static String REVERTTOCOLLFORM_ID = "REVERT_TO_COLLECTED";
	@FindBy(id = REVERTTOCOLLFORM_ID)
	private WebElement revertToCollForm;

	public final static String REVERTTOCOLLGRIDTBL_ID = "REVERT_TO_COLLECTED_GRID";
	@FindBy(id = REVERTTOCOLLGRIDTBL_ID)
	private WebElement revertToCollGridTbl;

	public final static String REVERTTOCOLLBTN_XPATH = "//form[@id='REVERT_TO_COLLECTED']//input[@value='Revert to Collected']";
	@FindBy(xpath = REVERTTOCOLLBTN_XPATH)
	private WebElement revertToCollBtn;

	public final static String REVERTTOCOLLCANCELBTN_XPATH = "//form[@id='REVERT_TO_COLLECTED']//input[@value='Cancel']";
	@FindBy(xpath = REVERTTOCOLLCANCELBTN_XPATH)
	private WebElement revertToCollCancelBtn;

	public final static String SENDBTN_ID = "MSC_SEND_BUTTON";
	@FindBy(id = SENDBTN_ID)
	private WebElement sendBtn;

	public final static String REJECTSPECFORM_ID = "REJECT_SPECIMEN_ID";
	@FindBy(id = REJECTSPECFORM_ID)
	private WebElement rejectSpecForm;

	public final static String REJECTSPECGRIDTBL_ID = "REJECT_SPECIMEN_GRID";
	@FindBy(id = REJECTSPECGRIDTBL_ID)
	private WebElement rejectSpecGridTbl;

	public final static String REJECTSPECBTN_ID = "REJECT_SPECIMEN_DATA";
	@FindBy(id = REJECTSPECBTN_ID)
	private WebElement rejectSpecBtn;

	public final static String REJECTCANCELBTN_ID = "REJECT_CANCEL";
	@FindBy(id = REJECTCANCELBTN_ID)
	private WebElement rejectCancelBtn;

	public final static String RECEIVEBTN_ID = "MSC_RECIEVE_BUTTON";
	@FindBy(id = RECEIVEBTN_ID)
	private WebElement receiveBtn;

	public final static String REVERTTOSENTFORM_ID = "REVERT_TO_SENT";
	@FindBy(id = REVERTTOSENTFORM_ID)
	private WebElement revertToSentForm;

	public final static String REVERTTOSENTGRIDTBL_ID = "REVERT_TO_SENT_GRID";
	@FindBy(id = REVERTTOSENTGRIDTBL_ID)
	private WebElement revertToSentGridTbl;

	public final static String REVERTTOSENTBTN_XPATH = "//form[@id='REVERT_TO_SENT']//input[@value='Revert to Sent']";
	@FindBy(xpath = REVERTTOSENTBTN_XPATH)
	private WebElement revertToSentBtn;

	public final static String REVERTTOSENTCANCELBTN_XPATH = "//form[@id='REVERT_TO_SENT']//input[@value='Cancel']";
	@FindBy(xpath = REVERTTOSENTCANCELBTN_XPATH)
	private WebElement revertToSentCancelBtn;

	public final static String DISPATCHBTN_ID = "MSC_DISPATCH_BUTTON";
	@FindBy(id = DISPATCHBTN_ID)
	private WebElement dispatchBtn;

	public final static String REVERTTORECVFORM_ID = "REVERT_TO_RECEIVED";
	@FindBy(id = REVERTTORECVFORM_ID)
	private WebElement revertToRecvForm;

	public final static String REVERTTORECVGRIDTBL_ID = "REVERT_TO_RECEIVED_GRID";
	@FindBy(id = REVERTTORECVGRIDTBL_ID)
	private WebElement revertToRecvGridTbl;

	public final static String REVERTTORECVBTN_XPATH = "//form[@id='REVERT_TO_RECEIVED']//input[@value='Revert to Received']";
	@FindBy(xpath = REVERTTORECVBTN_XPATH)
	private WebElement revertToRecvBtn;

	public final static String REVERTTORECVCANCELBTN_ID = "REVERT_TO_RECEIVD_CANCEL";
	@FindBy(id = REVERTTORECVCANCELBTN_ID)
	private WebElement revertToRecvCancelBtn;

	public final static String REJECTDISPATCHSPEC_XPATH = "//form[@id='REJECT_SPECIMEN_ID']";
	@FindBy(xpath = REJECTDISPATCHSPEC_XPATH)
	private WebElement rejectDispatchSpec;

	public final static String ACKBTN_ID = "CLD_ACKNOWLEDGE_BUTTON";
	@FindBy(id = ACKBTN_ID)
	private WebElement acknowledgeBtn;

	public final static String REVERTTODISPFORM_ID = "REVERT_TO_DISPATCHED";
	@FindBy(id = REVERTTODISPFORM_ID)
	private WebElement revertToDispForm;

	public final static String REVERTTODISPGRIDTBL_ID = "REVERT_TO_DISPATCHED_GRID";
	@FindBy(id = REVERTTODISPGRIDTBL_ID)
	private WebElement revertToDispGridTbl;

	public final static String REVERTTODISPBTN_XPATH = "//form[@id='REVERT_TO_DISPATCHED']//input[@value='Revert to Dispatched']";
	@FindBy(xpath = REVERTTODISPBTN_XPATH)
	private WebElement revertToDispBtn;

	public final static String REVERTTODISPCANCELBTN_ID = "REVERT_TO_DISPATHED_CANCEL";
	@FindBy(id = REVERTTODISPCANCELBTN_ID)
	private WebElement revertToDispCancelBtn;

	public final static String PRELIMINARYREPORTBTN_ID = "PRI_REPORT";
	@FindBy(id = PRELIMINARYREPORTBTN_ID)
	private WebElement preliminaryReportBtn;

	public final static String PRELIMREPORTPREVRESBTN_CSS = "input#PRI_REPORT~input";
	@FindBy(css = PRELIMREPORTPREVRESBTN_CSS)
	private WebElement prelimReportPrevResBtn;

	public final static String UPLOADREPORTBTN_ID = "RESULT_ENTRY_CULTURE_FILEUPLOAD";
	@FindBy(id = UPLOADREPORTBTN_ID)
	private WebElement uploadReportBtn;

	public final static String PRELIMINARYRADIOBTN_ID = "RADIO_BUTTON1";
	@FindBy(id = PRELIMINARYRADIOBTN_ID)
	private WebElement preliminaryRadioBtn;

	public final static String FINALRADIOBTN_ID = "RADIO_BUTTON2";
	@FindBy(id = FINALRADIOBTN_ID)
	private WebElement finalRadioBtn;

	public final static String PRELIMRESULTDESC_ID = "ADD_PRELIM_DESC_ID";
	@FindBy(id = PRELIMRESULTDESC_ID)
	private WebElement prelimResultDesc;

	public final static String PRELIMRESINCUBATIONPERIOD_NAME = "labResult.labResultCulture.incubationPeriodId";
	@FindBy(name = PRELIMRESINCUBATIONPERIOD_NAME)
	private WebElement prelimResIncubationPeriod;

	public final static String ADDPRELIMRESDESCBTN_CSS = "textarea#ADD_PRELIM_DESC_ID ~ input";
	@FindBy(css = ADDPRELIMRESDESCBTN_CSS)
	private WebElement addPrelimResDescBtn;

	public final static String PRELIMRESDESCPOPUP_ID = "PRELIM_RESULT_DESC_POPUP";
	@FindBy(id = PRELIMRESDESCPOPUP_ID)
	private WebElement prelimResDescPopUp;

	public final static String PRELIMRESDESCGRIDTBL_ID = "PRELIM_DESCRIPTION_GRID";
	@FindBy(id = PRELIMRESDESCGRIDTBL_ID)
	private WebElement prelimResDecGridTbl;

	public final static String PRELIMRESDESCSUBMITBTN_XPATH = "//div[@id='PRELIM_RESULT_DESC_POPUP']//input[@id='ADD_DEFAULT_DESC']";
	@FindBy(xpath = PRELIMRESDESCSUBMITBTN_XPATH)
	private WebElement prelimResDescSubmitBtn;

	public final static String PRELIMRESDESCCANCELBTN_XPATH = "//div[@id='PRELIM_RESULT_DESC_POPUP']//input[@id='CANCEL_DEFAULT_DESC']";
	@FindBy(xpath = PRELIMRESDESCCANCELBTN_XPATH)
	private WebElement prelimResDescCancelBtn;

	public final static String PRELIMRESULTREMARKS_NAME = "labResult.labResultCulture.prelimRemarks";
	@FindBy(name = PRELIMRESULTREMARKS_NAME)
	private WebElement prelimResultRemarks;

	public final static String COMPLETEBTN_ID = "COMPLETE_BTN_ID";
	@FindBy(id = COMPLETEBTN_ID)
	private WebElement completeBtn;

	public final static String VERIFYBTN_ID = "VERIFY_BTN_ID";
	@FindBy(id = VERIFYBTN_ID)
	private WebElement verifyBtn;

	public final static String AUTHORIZEBTN_ID = "AUTHORIZE_BTN_ID";
	@FindBy(id = AUTHORIZEBTN_ID)
	private WebElement authorizeBtn;

	public final static String AMENDBTN_ID = "AMEND_BTN_POPUP_ID";
	@FindBy(id = AMENDBTN_ID)
	private WebElement amendBtn;

	public final static String FINALREPORTPREVRESBTN_CSS = "input#AMEND_BTN_POPUP_ID~input";
	@FindBy(css = FINALREPORTPREVRESBTN_CSS)
	private WebElement finalReportPrevResBtn;

	public final static String FINALRESDESC_ID = "ADD_FINAL_DESC_ID";
	@FindBy(id = FINALRESDESC_ID)
	private WebElement finalResDesc;

	public final static String FINALRESINCUBATIONPERIOD_NAME = "labResult.labResultCulture.finalIncubationPeriodId";
	@FindBy(name = FINALRESINCUBATIONPERIOD_NAME)
	private WebElement finalResIncubationPeriod;

	public final static String ISORGANISMISOLATED_ID = "IS_ORG_ISOLATED";
	@FindBy(id = ISORGANISMISOLATED_ID)
	private WebElement isOrganismIsolated;

	public final static String ADDFINALRESDESCBTN_CSS = "textarea#ADD_FINAL_DESC_ID ~ input";
	@FindBy(css = ADDFINALRESDESCBTN_CSS)
	private WebElement addFinalResDescBtn;

	public final static String FINALRESDESCPOPUP_ID = "FINAL_RESULT_DESC_POPUP";
	@FindBy(id = FINALRESDESCPOPUP_ID)
	private WebElement finalResDescPopUp;

	public final static String FINALRESDESCGRIDTBL_ID = "FINAL_DESCRIPTION_GRID";
	@FindBy(id = FINALRESDESCGRIDTBL_ID)
	private WebElement finalResDecGridTbl;

	public final static String FINALRESDESCSUBMITBTN_XPATH = "//div[@id='FINAL_RESULT_DESC_POPUP']//input[@id='ADD_DEFAULT_DESC']";
	@FindBy(xpath = FINALRESDESCSUBMITBTN_XPATH)
	private WebElement finalResDescSubmitBtn;

	public final static String FINALRESDESCCANCELBTN_XPATH = "//div[@id='FINAL_RESULT_DESC_POPUP']//input[@id='CANCEL_DEFAULT_DESC']";
	@FindBy(xpath = FINALRESDESCCANCELBTN_XPATH)
	private WebElement finalResDescCancelBtn;

	public final static String FINALRESULTREMARKS_NAME = "labResult.labResultCulture.remarks";
	@FindBy(name = FINALRESULTREMARKS_NAME)
	private WebElement finalResultRemarks;

	public final static String DESKTOPGRIDTBL_ID = "LAB_DESKTOP_FILTER_GRID";
	@FindBy(id = DESKTOPGRIDTBL_ID)
	private WebElement desktopGridTbl;

	public final static String STATUS_ALL_ID = "RD_ORDER_ALL_ID";
	@FindBy(id = STATUS_ALL_ID)
	private WebElement statusAll;

	public final static String STATUS_ORDERED_ID = "RD_ORDER_ORDERED_ID";
	@FindBy(id = STATUS_ORDERED_ID)
	private WebElement statusOrdered;

	public final static String STATUS_BOOKED_ID = "RD_ORDER_BOOKED_ID";
	@FindBy(id = STATUS_BOOKED_ID)
	private WebElement statusBooked;

	public final static String STATUS_ARRIVED_ID = "RD_ORDER_ARRIVED_ID";
	@FindBy(id = STATUS_ARRIVED_ID)
	private WebElement statusArrived;

	public final static String STATUS_CANCELLED_ID = "RD_ORDER_CANCELLED_ID";
	@FindBy(id = STATUS_CANCELLED_ID)
	private WebElement statusCancelled;

	public final static String STATUS_SPECIMEN_COLLECTED_ID = "RD_ORDER_SPECIMEN_COLLECTED_ID";
	@FindBy(id = STATUS_SPECIMEN_COLLECTED_ID)
	private WebElement statusSpecimenCollected;

	public final static String STATUS_SPECIMEN_REJECTED_ID = "RD_ORDER_SPECIMEN_REJECTED_ID";
	@FindBy(id = STATUS_SPECIMEN_REJECTED_ID)
	private WebElement statusSpecimenRejected;

	public final static String STATUS_SENT_ID = "RD_ORDER_SENT_ID";
	@FindBy(id = STATUS_SENT_ID)
	private WebElement statusSent;

	public final static String STATUS_RECIEVED_ID = "RD_ORDER_RECIEVED_ID";
	@FindBy(id = STATUS_RECIEVED_ID)
	private WebElement statusReceived;

	public final static String STATUS_DISPATCHED_ID = "RD_ORDER_DISPATCHED_ID";
	@FindBy(id = STATUS_DISPATCHED_ID)
	private WebElement statusDispatched;

	public final static String STATUS_ACKNOWLEDGED_ID = "RD_ORDER_ACKNOWLEDGED_ID";
	@FindBy(id = STATUS_ACKNOWLEDGED_ID)
	private WebElement statusAcknowledged;

	public final static String STATUS_RESULT_COMPLETED_ID = "RD_ORDER_RESULT_COMPLETED_ID";
	@FindBy(id = STATUS_RESULT_COMPLETED_ID)
	private WebElement statusResultCompleted;

	public final static String STATUS_RESULT_VERIFIED_ID = "RD_ORDER_RESULT_VERIFIED_ID";
	@FindBy(id = STATUS_RESULT_VERIFIED_ID)
	private WebElement statusResultVerified;

	public final static String STATUS_RESULT_AUTHORIZED_ID = "RD_ORDER_RESULT_AUTHORIZED_ID";
	@FindBy(id = STATUS_RESULT_AUTHORIZED_ID)
	private WebElement statusResultAuthorized;

	public final static String STATUS_SENTTOEXTLAB_ID = "RD_ORDER_SENT_TO_EXT_LAB_ID";
	@FindBy(id = STATUS_SENTTOEXTLAB_ID)
	private WebElement statusSentToExtLab;

	public final static String STATUS_RESULT_AMENDED_ID = "RD_ORDER_RESULT_AMENDED_ID";
	@FindBy(id = STATUS_RESULT_AMENDED_ID)
	private WebElement statusResultAmended;

	public final static String STATUS_PRELIM_REPORT_ID = "RD_ORDER_PRELIM_REPORT_ID";
	@FindBy(id = STATUS_PRELIM_REPORT_ID)
	private WebElement statusPrelimReport;

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getDTQSearchTxt() {
		return DTQSearchTxt;
	}

	public WebElement getDTQSearchBtn() {
		return DTQSearchBtn;
	}

	public WebElement getDTResetBtn() {
		return DTResetBtn;
	}

	public WebElement getDTAdvsearchBtn() {
		return DTAdvsearchBtn;
	}

	public WebElement getDTAdvSearchDiv() {
		return DTAdvSearchDiv;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getSearchPeriod() {
		return searchPeriod;
	}

	public WebElement getNoFilter() {
		return noFilter;
	}

	public WebElement getFilterByPat() {
		return filterByPat;
	}

	public WebElement getFilterByRefPhys() {
		return filterByRefPhys;
	}

	public WebElement getFilterByEnc() {
		return filterByEnc;
	}

	public WebElement getFilterByLoc() {
		return filterByLoc;
	}

	public WebElement getFilterByServ() {
		return filterByServ;
	}

	public WebElement getAdvSearchBtn() {
		return advSearchBtn;
	}

	public WebElement getAdvResetBtn() {
		return advResetBtn;
	}

	public WebElement getInvoiceBtn() {
		return invoiceBtn;
	}

	public WebElement getVisitCat() {
		return visitCat;
	}

	public WebElement getPrintReportsBtn() {
		return printReportsBtn;
	}

	public WebElement getReprintLabelsBtn() {
		return reprintLabelsBtn;
	}

	public WebElement getSedToExternalLabBtn() {
		return sedToExternalLabBtn;
	}

	public WebElement getArriveBtn() {
		return arriveBtn;
	}

	public WebElement getCreateInvoiceBtn() {
		return createInvoiceBtn;
	}

	public WebElement getInvReceiptForm() {
		return invReceiptForm;
	}

	public WebElement getPaymentType() {
		return paymentType;
	}

	public WebElement getPaymentCurrency() {
		return paymentCurrency;
	}

	public WebElement getAmount() {
		return amount;
	}

	public WebElement getSubmit() {
		return submit;
	}

	public WebElement getReset() {
		return reset;
	}

	public WebElement getInvRecptPaymentGridTbl() {
		return invRecptPaymentGridTbl;
	}

	public WebElement getSaveDepoRecpt() {
		return saveDepoRecpt;
	}

	public WebElement getCancelDepoRecpt() {
		return cancelDepoRecpt;
	}

	public WebElement getCollectBtn() {
		return collectBtn;
	}

	public WebElement getSpecCollnSendBtn() {
		return specCollnSendBtn;
	}

	public WebElement getSpecCollnDtTimeForm() {
		return specCollnDtTimeForm;
	}

	public WebElement getCollnDtTimeSubmit() {
		return collnDtTimeSubmit;
	}

	public WebElement getCollnDtTimeCancel() {
		return collnDtTimeCancel;
	}

	public WebElement getRevertToCollForm() {
		return revertToCollForm;
	}

	public WebElement getRevertToCollGridTbl() {
		return revertToCollGridTbl;
	}

	public WebElement getRevertToCollBtn() {
		return revertToCollBtn;
	}

	public WebElement getRevertToCollCancelBtn() {
		return revertToCollCancelBtn;
	}

	public WebElement getRejectSpecForm() {
		return rejectSpecForm;
	}

	public WebElement getRejectSpecGridTbl() {
		return rejectSpecGridTbl;
	}

	public WebElement getRejectSpecBtn() {
		return rejectSpecBtn;
	}

	public WebElement getRejectCancelBtn() {
		return rejectCancelBtn;
	}

	public WebElement getRevertToSentForm() {
		return revertToSentForm;
	}

	public WebElement getRevertToSentGridTbl() {
		return revertToSentGridTbl;
	}

	public WebElement getRevertToSentBtn() {
		return revertToSentBtn;
	}

	public WebElement getRevertToSentCancelBtn() {
		return revertToSentCancelBtn;
	}

	public WebElement getRevertToRecvForm() {
		return revertToRecvForm;
	}

	public WebElement getRevertToRecvGridTbl() {
		return revertToRecvGridTbl;
	}

	public WebElement getRevertToRecvBtn() {
		return revertToRecvBtn;
	}

	public WebElement getRevertToRecvCancelBtn() {
		return revertToRecvCancelBtn;
	}

	public WebElement getRejectDispatchSpec() {
		return rejectDispatchSpec;
	}

	public WebElement getRevertToDispForm() {
		return revertToDispForm;
	}

	public WebElement getRevertToDispGridTbl() {
		return revertToDispGridTbl;
	}

	public WebElement getRevertToDispBtn() {
		return revertToDispBtn;
	}

	public WebElement getRevertToDispCancelBtn() {
		return revertToDispCancelBtn;
	}

	public WebElement getPreliminaryReportBtn() {
		return preliminaryReportBtn;
	}

	public WebElement getPrelimReportPrevResBtn() {
		return prelimReportPrevResBtn;
	}

	public WebElement getUploadReportBtn() {
		return uploadReportBtn;
	}

	public WebElement getPreliminaryRadioBtn() {
		return preliminaryRadioBtn;
	}

	public WebElement getFinalRadioBtn() {
		return finalRadioBtn;
	}

	public WebElement getPrelimResultDesc() {
		return prelimResultDesc;
	}

	public WebElement getPrelimResIncubationPeriod() {
		return prelimResIncubationPeriod;
	}

	public WebElement getAddPrelimResDescBtn() {
		return addPrelimResDescBtn;
	}

	public WebElement getPrelimResDescPopUp() {
		return prelimResDescPopUp;
	}

	public WebElement getPrelimResDecGridTbl() {
		return prelimResDecGridTbl;
	}

	public WebElement getPrelimResDescSubmitBtn() {
		return prelimResDescSubmitBtn;
	}

	public WebElement getPrelimResDescCancelBtn() {
		return prelimResDescCancelBtn;
	}

	public WebElement getPrelimResultRemarks() {
		return prelimResultRemarks;
	}

	public WebElement getCompleteBtn() {
		return completeBtn;
	}

	public WebElement getVerifyBtn() {
		return verifyBtn;
	}

	public WebElement getAuthorizeBtn() {
		return authorizeBtn;
	}

	public WebElement getAmendBtn() {
		return amendBtn;
	}

	public WebElement getFinalReportPrevResBtn() {
		return finalReportPrevResBtn;
	}

	public WebElement getFinalResDesc() {
		return finalResDesc;
	}

	public WebElement getFinalResIncubationPeriod() {
		return finalResIncubationPeriod;
	}

	public WebElement getIsOrganismIsolated() {
		return isOrganismIsolated;
	}

	public WebElement getAddFinalResDescBtn() {
		return addFinalResDescBtn;
	}

	public WebElement getFinalResDescPopUp() {
		return finalResDescPopUp;
	}

	public WebElement getFinalResDecGridTbl() {
		return finalResDecGridTbl;
	}

	public WebElement getFinalResDescSubmitBtn() {
		return finalResDescSubmitBtn;
	}

	public WebElement getFinalResDescCancelBtn() {
		return finalResDescCancelBtn;
	}

	public WebElement getFinalResultRemarks() {
		return finalResultRemarks;
	}

	public WebElement getSpecCollGridTbl() {
		return specCollGridTbl;
	}

	public WebElement getCollectedVol() {
		return collectedVol;
	}

	public WebElement getUom() {
		return uom;
	}

	public WebElement getFixative() {
		return fixative;
	}

	public WebElement getAnatomicSite() {
		return anatomicSite;
	}

	public WebElement getRemarks() {
		return remarks;
	}

	public WebElement getSendBtn() {
		return sendBtn;
	}

	public WebElement getReceiveBtn() {
		return receiveBtn;
	}

	public WebElement getDispatchBtn() {
		return dispatchBtn;
	}

	public WebElement getAcknowledgeBtn() {
		return acknowledgeBtn;
	}

	public WebElement getDesktopGridTbl() {
		return desktopGridTbl;
	}

	public WebElement getStatusAll() {
		return statusAll;
	}

	public WebElement getStatusOrdered() {
		return statusOrdered;
	}

	public WebElement getStatusBooked() {
		return statusBooked;
	}

	public WebElement getStatusArrived() {
		return statusArrived;
	}

	public WebElement getStatusCancelled() {
		return statusCancelled;
	}

	public WebElement getStatusSpecimenCollected() {
		return statusSpecimenCollected;
	}

	public WebElement getStatusSpecimenRejected() {
		return statusSpecimenRejected;
	}

	public WebElement getStatusSent() {
		return statusSent;
	}

	public WebElement getStatusReceived() {
		return statusReceived;
	}

	public WebElement getStatusDispatched() {
		return statusDispatched;
	}

	public WebElement getStatusAcknowledged() {
		return statusAcknowledged;
	}

	public WebElement getStatusResultCompleted() {
		return statusResultCompleted;
	}

	public WebElement getStatusResultVerified() {
		return statusResultVerified;
	}

	public WebElement getStatusResultAuthorized() {
		return statusResultAuthorized;
	}

	public WebElement getStatusSentToExtLab() {
		return statusSentToExtLab;
	}

	public WebElement getStatusResultAmended() {
		return statusResultAmended;
	}

	public WebElement getStatusPrelimReport() {
		return statusPrelimReport;
	}

}
