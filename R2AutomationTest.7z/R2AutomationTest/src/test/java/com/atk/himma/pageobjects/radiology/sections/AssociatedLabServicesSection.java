package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AssociatedLabServicesSection extends DriverWaitClass{
	
	public final static String ADDROWBUTTON_ID = "addNewLabService";
	
//	-----------GRID--------------
	public final static String GRID_ID = "rsals_GRID";
	public final static String GRID_MANDATORY_ARIA_DESCRIBEDBY = "rsals_GRID_mandatory";
	public final static String GRID_SERVICE_ARIA_DESCRIBEDBY = "rsals_GRID_serviceName";
	public final static String GRID_DURATION_ARIA_DESCRIBEDBY = "rsals_GRID_duration";
	public final static String GRID_DURATIONUNIT_ARIA_DESCRIBEDBY = "rsals_GRID_durationUnit";
	public final static String GRID_EXECUSTAGE_ARIA_DESCRIBEDBY = "rsals_GRID_exeStage";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "rsals_GRID_action";
	public final static String GRID_PAGERID = "sp_1_rsals_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rsals_GRID_pager']";

//	-----------GRID's Fields--------------
	public final static String MANDATORYCHKBX_CSS = "td[aria-describedby='"+GRID_MANDATORY_ARIA_DESCRIBEDBY+"'] input[name=mandatory]";
	public final static String SERVICETXT_CSS = "td[aria-describedby='"+GRID_SERVICE_ARIA_DESCRIBEDBY+"'] span input[name='serviceName']";
	public final static String SERVICELOOKUP_CSS = "td[aria-describedby='"+GRID_SERVICE_ARIA_DESCRIBEDBY+"'] span a[name='serviceName']";
	public final static String DURATIONTXT_CSS = "td[aria-describedby='"+GRID_DURATION_ARIA_DESCRIBEDBY+"'] input[name='duration']";
	public final static String DURATIONUNIT_CSS = "td[aria-describedby='"+GRID_DURATIONUNIT_ARIA_DESCRIBEDBY+"'] select[name='durationUnit']";
	public final static String EXECUSTAGEDD_CSS = "td[aria-describedby='"+GRID_EXECUSTAGE_ARIA_DESCRIBEDBY+"'] select[name='exeStage']";
	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_SERVICE_ARIA_DESCRIBEDBY+"']/span/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";

	@FindBy(id = ADDROWBUTTON_ID)
	private WebElement addRowButton;

	@FindBy(xpath = MANDATORYCHKBX_CSS)
	private WebElement visitCategoryBtn;

	@FindBy(xpath = SERVICETXT_CSS)
	private WebElement serviceTxt;
	
	@FindBy(xpath = SERVICELOOKUP_CSS)
	private WebElement serviceLookup;
	
	@FindBy(xpath = DURATIONTXT_CSS)
	private WebElement durationTxt;
	
	@FindBy(xpath = DURATIONUNIT_CSS)
	private WebElement durationUnit;
	
	@FindBy(xpath = EXECUSTAGEDD_CSS)
	private WebElement execuStageDD;
	
	@FindBy(xpath = DELETEACTION_GE_XPATH)
	private WebElement deleteActionGE;
	
	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the visitCategoryBtn
	 */
	public WebElement getVisitCategoryBtn() {
		return visitCategoryBtn;
	}

	/**
	 * @return the serviceTxt
	 */
	public WebElement getServiceTxt() {
		return serviceTxt;
	}

	/**
	 * @return the serviceLookup
	 */
	public WebElement getServiceLookup() {
		return serviceLookup;
	}

	/**
	 * @return the durationTxt
	 */
	public WebElement getDurationTxt() {
		return durationTxt;
	}

	/**
	 * @return the durationUnit
	 */
	public WebElement getDurationUnit() {
		return durationUnit;
	}

	/**
	 * @return the execuStageDD
	 */
	public WebElement getExecuStageDD() {
		return execuStageDD;
	}

	/**
	 * @return the deleteActionGE
	 */
	public WebElement getDeleteActionGE() {
		return deleteActionGE;
	}
}
