package com.atk.himma.pageobjects.radiology;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.RadCommonDesk;

public class ReceptionistDesktopPage extends RadCommonDesk{
	
	public final static String ALLSTATUSLIST_XPATH = "//span[@id='RAD_ALL_STATUS_LP']/..";
	
	@FindBy(id = ALLSTATUSLIST_XPATH)
	private WebElement allStatusList;

	/**
	 * @return the allStatusList
	 */
	public WebElement getAllStatusList() {
		return allStatusList;
	}

}