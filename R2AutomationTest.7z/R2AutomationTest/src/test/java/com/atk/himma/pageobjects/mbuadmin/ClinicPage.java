package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.AppointmentParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.ClinicFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.TimeDuraConsulServices;
import com.atk.himma.pageobjects.mbuadmin.tabs.ClinicListTab;
import com.atk.himma.pageobjects.mbuadmin.tabs.ServiceListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ClinicPage extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	private ClinicListTab clinicListTab;
	private ClinicFirstSection clinicFirstSection;
	private TimeDuraConsulServices timeDuraConsulServices;
	private AppointmentParameters appointmentParameters;

	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'updated successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Record activated successfully')]";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Clinic']";

	@FindBy(xpath = DETAILSADDNEWBUTTON_XPATH)
	private WebElement addNewButton;
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement detailsPageTitle;

	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;

	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;

	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;

	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		clinicListTab = PageFactory
				.initElements(webDriver, ClinicListTab.class);
		clinicListTab.setWebDriver(webDriver);
		clinicListTab.setWebDriverWait(webDriverWait);

		clinicFirstSection = PageFactory.initElements(webDriver,
				ClinicFirstSection.class);
		clinicFirstSection.setWebDriver(webDriver);
		clinicFirstSection.setWebDriverWait(webDriverWait);

		timeDuraConsulServices = PageFactory.initElements(webDriver,
				TimeDuraConsulServices.class);
		timeDuraConsulServices.setWebDriver(webDriver);
		timeDuraConsulServices.setWebDriverWait(webDriverWait);

		appointmentParameters = PageFactory.initElements(webDriver,
				AppointmentParameters.class);
		appointmentParameters.setWebDriver(webDriver);
		appointmentParameters.setWebDriverWait(webDriverWait);

	}

	public ClinicPage clickOnClinicMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Clinic");
		ClinicPage clinicPage = PageFactory.initElements(webDriver,
				ClinicPage.class);
		clinicPage.setWebDriver(webDriver);
		clinicPage.setWebDriverWait(webDriverWait);
		return clinicPage;
	}

	public String searchClinic(String[] clinicDatas)
			throws InterruptedException {
		waitForElementId(ClinicListTab.MBUNAME_ID);
		new Select(clinicListTab.getMbuName())
				.selectByVisibleText(clinicDatas[0]);
		if (!clinicDatas[1].isEmpty())
			new Select(clinicListTab.getDepartment())
					.selectByVisibleText(clinicDatas[1]);
		if (!clinicDatas[2].isEmpty())
			new Select(clinicListTab.getSpecialty())
					.selectByVisibleText(clinicDatas[2]);
		clinicListTab.getClinicName().clear();
		clinicListTab.getClinicName().sendKeys(clinicDatas[3]);
		if (!clinicDatas[4].isEmpty())
			new Select(clinicListTab.getStatus())
					.selectByVisibleText(clinicDatas[4]);
		clinicListTab.getClinicCode().clear();
		clinicListTab.getClinicCode().sendKeys(clinicDatas[5]);
		clinicListTab.getSearchButton().click();
		waitForElementId(ServiceListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(ClinicListTab.GRID_ID,
				ClinicListTab.GRID_CLINICNAME_ARIA_DESCRIBEDBY, clinicDatas[3]);
	}

	public boolean clickOnAddNewButton(String[] clinicDatas)
			throws InterruptedException {
		waitForElementId(ClinicListTab.ADDNEWCLINICBUTTON_ID);
		sleepVeryShort();
		clinicListTab.getAddNewClinicButton().click();
		waitForElementId(ClinicFirstSection.MBU_ID);
		waitForElementId(ClinicFirstSection.CLINICSHORTNAME_ID);
		sleepShort();
		return new Select(clinicFirstSection.getMbu()).getFirstSelectedOption()
				.getText().trim().equals(clinicDatas[0].trim());
	}

	public String updateClinicDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		detailsUpdateButton.click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		sleepVeryShort();
		return updateConfMsg.getText().trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		waitForElementXpathExpression(SAVECONFMSG_XPATH);
		sleepShort();
		return detailsUpdateButton.getAttribute("value").trim();

	}

	public boolean saveDuplicateData(String[] clinicDatas)
			throws InterruptedException, IOException {
		try {
			waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
			detailsSaveButton.click();
			new WebDriverWait(webDriver, shortTimeInterval)
					.until(ExpectedConditions.presenceOfElementLocated(By
							.xpath(DETAILSUPDATEBUTTON_XPATH)));
			sleepVeryShort();
			return false;
		} catch (Exception e) {
			return searchData(clinicDatas).equals(clinicDatas[9].trim());
		}
	}

	public String searchData(String[] clinicDatas) {
		waitForElementXpathExpression(ClinicListTab.CLINICLISTTAB_XPATH);
		clinicListTab.getClinicListTab().click();
		waitForElementId(ClinicListTab.GRID_ID);
		clinicListTab.getClinicName().clear();
		clinicListTab.getClinicName().sendKeys(clinicDatas[7].trim());
		clinicListTab.getSearchButton().click();
		return waitAndGetGridFirstCellText(ClinicListTab.GRID_ID,
				ClinicListTab.GRID_CLINICNAME_ARIA_DESCRIBEDBY,clinicDatas[7].trim());
	}

	public String activateClinic() throws InterruptedException, IOException {

		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);

	}

	public void clickClinicListTab() throws InterruptedException {
		waitForElementXpathExpression(ClinicPage.SAVECONFMSG_XPATH);
		clinicListTab.getClinicListTab().click();
		waitForElementXpathExpression(ClinicListTab.SEARCHBUTTON_XPATH);
		sleepVeryShort();
	}

	/**
	 * @return the clinicListTab
	 */
	public ClinicListTab getClinicListTab() {
		return clinicListTab;
	}

	/**
	 * @return the clinicFirstSection
	 */
	public ClinicFirstSection getClinicFirstSection() {
		return clinicFirstSection;
	}

	/**
	 * @return the timeDuraConsulServices
	 */
	public TimeDuraConsulServices getTimeDuraConsulServices() {
		return timeDuraConsulServices;
	}

	/**
	 * @return the appointmentParameters
	 */
	public AppointmentParameters getAppointmentParameters() {
		return appointmentParameters;
	}

	/**
	 * @return the detailsPageTitle
	 */
	public WebElement getDetailsPageTitle() {
		return detailsPageTitle;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

}
