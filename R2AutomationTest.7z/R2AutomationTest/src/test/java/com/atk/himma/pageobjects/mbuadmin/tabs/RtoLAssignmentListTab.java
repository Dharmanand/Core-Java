package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RtoLAssignmentListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "resLocAssignment";
	public final static String RTOLLIST_XPATH = "//a[@title='Assignment List']";
	public final static String LOCWISEASSIGN_ID = "ASSIGNMENT_TYPEL";
	
	public final static String MBU_ID = "RES_LOC_RES_MBU_DD";
	public final static String DEPARTMENT_ID = "RES_LOC_RES_DEPARTMENT";
	public final static String RESOURCETYPE_ID = "RES_LOC_RESOURCE_TYPE_DD";
	public final static String DESIGNATION_ID = "RES_LOC_RESOURCE_DESIGNATION_DD";
	public final static String RESOURCENAME_ID = "RES_NAME";
	public final static String RESOURCECODE_ID = "RES_CODE";
	public final static String RESOURCECATEGORY_ID = "RES_LOC_RESOURCE_CATEGORY_DD";
	public final static String STATUS_ID = "RES_STATUS_DD";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "RES_SEARCH_GRID";
	public final static String GRID_RESCODE_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.resourceCode";
	public final static String GRID_RESOURCENAME_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.resourceName.fullName";
	public final static String GRID_RESOURCECATEGORY_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.resourceCategoryText";
	public final static String GRID_RESOURCETYPE_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.resourceTypeText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.departmentText";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.mbuName.mbuName";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resLocAssignment.recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_RES_SEARCH_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_RES_SEARCH_GRID_pager']";
	
	public final static String RESSEARCHGRID_ID = "gview_RES_SEARCH_GRID";
	public final static String GRID_LOCATION_ARIA_DESCRIBEDBY = "RES_SEARCH_GRID_resource.resourceName.fullName";
	
	
	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = RESSEARCHGRID_ID)
	private WebElement resSearchGrid;
	
	@FindBy(id = LOCWISEASSIGN_ID)
	private WebElement locWiseAssignRadio;

	@FindBy(xpath = RTOLLIST_XPATH)
	private WebElement resToLocListTab;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = RESOURCETYPE_ID)
	private WebElement resourceType;
	
	@FindBy(id = RESOURCENAME_ID)
	private WebElement resourceName;
	
	@FindBy(id = RESOURCECODE_ID)
	private WebElement resourceCode;
	
	@FindBy(id = RESOURCECATEGORY_ID)
	private WebElement resourceCategory;
	
	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the resToLocListTab
	 */
	public WebElement getResToLocListTab() {
		return resToLocListTab;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the resourceType
	 */
	public WebElement getResourceType() {
		return resourceType;
	}

	/**
	 * @return the resourceName
	 */
	public WebElement getResourceName() {
		return resourceName;
	}

	/**
	 * @return the resourceCode
	 */
	public WebElement getResourceCode() {
		return resourceCode;
	}

	/**
	 * @return the resourceCategory
	 */
	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	/**
	 * @return the locWiseAssignRadio
	 */
	public WebElement getLocWiseAssignRadio() {
		return locWiseAssignRadio;
	}

	/**
	 * @return the resSearchGrid
	 */
	public WebElement getResSearchGrid() {
		return resSearchGrid;
	}

}
