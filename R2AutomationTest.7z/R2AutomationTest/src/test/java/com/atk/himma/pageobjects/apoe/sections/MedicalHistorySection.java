package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class MedicalHistorySection extends DriverWaitClass {
	public final static String MEDHISTORYSEC_XPATH = "//a[text()='Medical History']";
	@FindBy(xpath = MEDHISTORYSEC_XPATH)
	private WebElement medHistorySec;

	public final static String LASTINFLVACCINEMONTH_ID = "LAST_INFLUENZA_M_SELECT";
	@FindBy(id = LASTINFLVACCINEMONTH_ID)
	private WebElement lastInfluenzaVaccineMonth;

	public final static String LASTINFLVACCINEYEAR_ID = "LAST_INFLUENZA_Y_SELECT";
	@FindBy(id = LASTINFLVACCINEYEAR_ID)
	private WebElement lastInfluenzaVaccineYear;

	public final static String PNEUMOCOCCALVACCINEMONTH_ID = "LAST_VACINE_M_SELECT";
	@FindBy(id = PNEUMOCOCCALVACCINEMONTH_ID)
	private WebElement pneumococcalVaccineMonth;

	public final static String PNEUMOCOCCALVACCINEYEAR_ID = "LAST_VACINE_Y_SELECT";
	@FindBy(id = PNEUMOCOCCALVACCINEYEAR_ID)
	private WebElement pneumococcalVaccineYear;

	public final static String MEDICALHISTORYNOTES_NAME = "consultationSummary.histroy.medicalHistroy.notes";
	@FindBy(name = MEDICALHISTORYNOTES_NAME)
	private WebElement medicalHistoryNotes;

	public void fillMedHistoryInfo(String[] outPatientListData) {
		if (!outPatientListData[36].isEmpty()) {
			new Select(lastInfluenzaVaccineMonth)
					.selectByVisibleText(outPatientListData[36]);
		}
		if (!outPatientListData[37].isEmpty()) {
			new Select(lastInfluenzaVaccineYear)
					.selectByVisibleText(outPatientListData[37]);
		}
		if (!outPatientListData[38].isEmpty()) {
			new Select(pneumococcalVaccineMonth)
					.selectByVisibleText(outPatientListData[38]);
		}
		if (!outPatientListData[39].isEmpty()) {
			new Select(pneumococcalVaccineYear)
					.selectByVisibleText(outPatientListData[39]);
		}
		medicalHistoryNotes.clear();
		medicalHistoryNotes.sendKeys(outPatientListData[40]);

	}
	
	public boolean checkMedHistorySec() {
		return medHistorySec.isDisplayed();
	}

	public WebElement getMedHistorySec() {
		return medHistorySec;
	}

	public WebElement getLastInfluenzaVaccineMonth() {
		return lastInfluenzaVaccineMonth;
	}

	public WebElement getLastInfluenzaVaccineYear() {
		return lastInfluenzaVaccineYear;
	}

	public WebElement getPneumococcalVaccineMonth() {
		return pneumococcalVaccineMonth;
	}

	public WebElement getPneumococcalVaccineYear() {
		return pneumococcalVaccineYear;
	}

	public WebElement getMedicalHistoryNotes() {
		return medicalHistoryNotes;
	}

}
