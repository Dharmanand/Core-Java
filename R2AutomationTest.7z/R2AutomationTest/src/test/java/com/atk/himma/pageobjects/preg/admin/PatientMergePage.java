package com.atk.himma.pageobjects.preg.admin;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.preg.admin.tabs.PatientMergeTab;
import com.atk.himma.pageobjects.preg.admin.tabs.ViewMergedPatientInformationTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class PatientMergePage extends DriverWaitClass implements StatusMessages{

	private final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String MENULINK_XPATH = "//a[contains(text(),'Patient Registration')]/..//a[contains(text(),'Patient Merge')]";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String FORMNAME_ID = "mergePatient";

	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;
	
	public final static String MERGECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'merged successfully')]";
	
	@FindBy(xpath = MERGECONFMSG_XPATH)
	private WebElement mergeConfMsg;
	
	private PatientMergeTab patientMergeTab;

	private ViewMergedPatientInformationTab viewMergedPatientInformationTab;

	public PatientMergePage clickOnPatientMergeMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Patient Registration");
		menuList.add("Admin ");
		menuSelector.clickOnTargetMenu(menuList, "Patient Merge");
		PatientMergePage patientMergePage = PageFactory.initElements(webDriver,
				PatientMergePage.class);
		patientMergePage.setWebDriver(webDriver);
		patientMergePage.setWebDriverWait(webDriverWait);
		return patientMergePage;
	}

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		patientMergeTab = PageFactory.initElements(webDriver,
				PatientMergeTab.class);
		patientMergeTab.setWebDriver(webDriver);
		patientMergeTab.setWebDriverWait(webDriverWait);

		viewMergedPatientInformationTab = PageFactory.initElements(webDriver,
				ViewMergedPatientInformationTab.class);
		viewMergedPatientInformationTab.setWebDriver(webDriver);
		viewMergedPatientInformationTab.setWebDriverWait(webDriverWait);
	}

	public void searchPatient(String searchText) {
		patientMergeTab.getSearchText().clear();
		patientMergeTab.getSearchText().sendKeys(searchText.trim());
		patientMergeTab.getSearchButton().click();
		waitForElementId(PatientMergeTab.getGridtableId());
	}

	public void mergePatients(String primaryMrn, String mrns,
			String tdAriaDescribedby) {
		String[] mrn = mrns.split("\\,");
		int pageCount = Integer.parseInt(patientMergeTab.getGridPager()
				.getText().trim());

		List<WebElement> rows = null;

		for (int j = 0; j < pageCount; j++) {
			rows = webDriver.findElements(By.xpath("//td[@aria-describedby='"
					+ tdAriaDescribedby + "']"));
			for (int i = 0; i < mrn.length; i++) {
				for (WebElement element : rows) {
					if (mrn[i].trim().equals(element.getText().trim())) {
						webDriver
								.findElement(
										By.xpath("//td[@aria-describedby='"
												+ tdAriaDescribedby
												+ "' and @title='"
												+ mrn[i]
												+ "']/..//td[@aria-describedby='multiSelVal_cb']//input"))
								.click();
						if (mrn[i].trim().equals(primaryMrn.trim()))
							webDriver
									.findElement(
											By.xpath("//td[@aria-describedby='"
													+ tdAriaDescribedby
													+ "' and @title='"
													+ mrn[i]
													+ "']/..//td[@aria-describedby='multiSelVal_sretain']//input"))
									.click();
					}
				}
			}
			if (pageCount > 1 && j < pageCount - 1)
				patientMergeTab.getGridPagerNext().click();
		}
		patientMergeTab.getMeargeButton().click();
		waitForElementId(PatientMergeTab.getUserconfirmationyesbuttonId());
		patientMergeTab.getUserConfirmationYesButton().click();
	}

	public boolean searchMergePatients(String primaryMrn, String mrns)
			throws InterruptedException {

		boolean flag = false;
		waitForElementXpathExpression(ViewMergedPatientInformationTab
				.getViewmergepatientinfotabXpath());
		viewMergedPatientInformationTab.getViewMergePatientInfoTab().click();
		waitForElementId(ViewMergedPatientInformationTab.getSearchbuttonId());
		waitForElementId(ViewMergedPatientInformationTab.getEntermergedmrnId());
		viewMergedPatientInformationTab.getEnterMergedMRN().clear();
		viewMergedPatientInformationTab.getEnterMergedMRN().sendKeys(
				primaryMrn.trim());
		viewMergedPatientInformationTab.getSearchButton().click();
		waitForElementXpathExpression(ViewMergedPatientInformationTab
				.getGridtableXpath());
		waitForElementId(ViewMergedPatientInformationTab.getGridpagerId());
		String[] mrn = mrns.split("\\,");

		int pageCount = Integer.parseInt(viewMergedPatientInformationTab
				.getGridPager().getText().trim());

		List<WebElement> rows = null;

		int count = 0;

		for (int j = 0; j < pageCount; j++) {
			rows = webDriver.findElements(By.xpath("//td[@aria-describedby='"
					+ ViewMergedPatientInformationTab
							.getViewmergemrnoMrnoAriadescribedby() + "']"));
			for (int i = 0; i < mrn.length; i++) {
				for (WebElement element : rows) {
					String str = element.getText().trim();
					if (mrn[i].trim().equals(str)) {
						waitForElementXpathExpression("//td[@aria-describedby='"
								+ ViewMergedPatientInformationTab
										.getViewmergemrnoPrimarymrnoAriadescribedby()
								+ "' and @title='"
								+ primaryMrn.trim()
								+ "']/..//td[@aria-describedby='"
								+ ViewMergedPatientInformationTab
										.getViewmergemrnoMrnoAriadescribedby()
								+ "' and @title='" + mrn[i].trim() + "']");
						count++;
					}
				}
			}
			if (pageCount > 1 && j < pageCount - 1) {
				viewMergedPatientInformationTab.getGridPagerNext().click();
				waitForElementXpathExpression(ViewMergedPatientInformationTab
						.getGridtableXpath());
				sleepVeryShort();
			}
		}
		if (count == mrn.length)
			flag = true;
		return flag;
	}

	/**
	 * @return the formnameId
	 */
	public static String getFormnameId() {
		return FORMNAME_ID;
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the patientMergeTab
	 */
	public PatientMergeTab getPatientMergeTab() {
		return patientMergeTab;
	}

	/**
	 * @return the viewMergedPatientInformationTab
	 */
	public ViewMergedPatientInformationTab getViewMergedPatientInformationTab() {
		return viewMergedPatientInformationTab;
	}

	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the mergeConfMsg
	 */
	public WebElement getMergeConfMsg() {
		return mergeConfMsg;
	}

}
