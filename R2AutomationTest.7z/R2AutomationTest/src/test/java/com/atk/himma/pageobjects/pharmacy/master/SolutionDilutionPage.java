package com.atk.himma.pageobjects.pharmacy.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.pharmacy.tabs.SolnDiluentListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class SolutionDilutionPage extends DriverWaitClass {

	private SolnDiluentListTab solnDiluentListTab;

	public final static String FORM_ID = "SOL_DILUENT_DETAILS";
	public final static String SOLDILMENULINK_XPATH = "//a[text()='Pharmacy']/..//a[contains(text(),'Masters')]/..//a[contains(text(),'Solution / Diluent')]";
	public final static String SAVEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Save']";
	public final static String UPDATEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Update']";
	public final static String ADDNEWBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Add New']";
	public final static String SEARCEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Cancel']";
	public final static String SOLDILUENT_NAME = "drugCompSolDiluent.code";
	public final static String SHORTDESCRIPTXT_NAME = "SHORT_DESC";
	public final static String SOLNDILDESC_ID = "DESCRIPTION";
	public final static String DEFAULTUOM_ID = "UOM";
	public final static String ROUTE_ID = "ROUTE";
	public final static String ITEMCATEGORY_CSS = "#SOL_DILUENT_DETAILS_drugCompSolDiluent_itemCategory + input";

	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = SOLDILMENULINK_XPATH)
	private WebElement solDilMenuLink;

	@FindBy(css = SAVEBUTTON_CSS)
	private WebElement saveButton;

	@FindBy(css = UPDATEBUTTON_CSS)
	private WebElement updateButton;

	@FindBy(css = ADDNEWBUTTON_CSS)
	private WebElement addNewButton;

	@FindBy(css = SEARCEBUTTON_CSS)
	private WebElement searceButton;

	@FindBy(name = SOLDILUENT_NAME)
	private WebElement solDiluentTxt;

	@FindBy(name = SHORTDESCRIPTXT_NAME)
	private WebElement shortDescripTxt;

	@FindBy(id = SOLNDILDESC_ID)
	private WebElement solnDilDescription;

	@FindBy(id = DEFAULTUOM_ID)
	private WebElement defaultUOM;

	@FindBy(id = ROUTE_ID)
	private WebElement route;

	@FindBy(css = ITEMCATEGORY_CSS)
	private WebElement itemCategory;

	public SolnDiluentListTab setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		solnDiluentListTab = PageFactory.initElements(webDriver,
				SolnDiluentListTab.class);
		solnDiluentListTab.setWebDriver(webDriver);
		solnDiluentListTab.setWebDriverWait(webDriverWait);
		return solnDiluentListTab;
	}

	public SolutionDilutionPage checkSolnDiluentLink(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(menuList, "Solution / Diluent");
		SolutionDilutionPage solutionDilutionPage = PageFactory.initElements(
				webDriver, SolutionDilutionPage.class);
		return solutionDilutionPage;
	}

	public SolutionDilutionPage clickOnSolnDiluentMenu() throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Solution / Diluent");
		SolutionDilutionPage solutionDilutionPage = PageFactory.initElements(
				webDriver, SolutionDilutionPage.class);
		solutionDilutionPage.setWebDriver(webDriver);
		solutionDilutionPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForElementId(SolnDiluentListTab.GRID_ID);
		return solutionDilutionPage;
	}

	public boolean clickOnAddNewSolnBtn() throws Exception {
		waitForElementCssSelector(SolnDiluentListTab.ADDNEWLEBELBUTTON_CSS);
		solnDiluentListTab.getAddNewLebelButton().click();
		waitForElementId(FORM_ID);
		waitForElementId(SOLNDILDESC_ID);
		return solnDilDescription.isDisplayed();
	}

	public boolean isReadonlySolnDiluentCode() {
		return isReadonlyField(solDiluentTxt);
	}

	public boolean isMandatoryShortDescr() {
		return isMandatoryField(shortDescripTxt);
	}

	public boolean isMandatoryDefaultUOM() {
		return isMandatoryField(defaultUOM);
	}

	public boolean isMandatoryRoute() {
		return isMandatoryField(route);
	}

	public boolean isReadonlyItemCategory() {
		return isReadonlyField(itemCategory);
	}

	public boolean fillSolutionDilutionDatas(String[] solDilutionDatas) {
		shortDescripTxt.clear();
		shortDescripTxt.sendKeys(solDilutionDatas[0].trim());
		if (!solDilutionDatas[1].isEmpty()) {
			shortDescripTxt.clear();
			shortDescripTxt.sendKeys(solDilutionDatas[0].trim());
		}
		if (!solDilutionDatas[2].isEmpty()) {
			solnDilDescription.clear();
			solnDilDescription.sendKeys(solDilutionDatas[2].trim());
		}
		if (!solDilutionDatas[3].isEmpty()) {
			new Select(defaultUOM).selectByVisibleText(solDilutionDatas[3]
					.trim());
		}
		if (!solDilutionDatas[4].isEmpty()) {
			new Select(route).selectByVisibleText(solDilutionDatas[4].trim());
		}
		return solnDilDescription.getAttribute("value").trim() == solDilutionDatas[2]
				.trim();
	}

	public boolean saveData() {
		waitForElementCssSelector(SAVEBUTTON_CSS);
		saveButton.click();
		waitForElementCssSelector(UPDATEBUTTON_CSS);
		return updateButton.isDisplayed();
	}

	public boolean updateData(String[] solDilutionDatas) {

		waitForElementCssSelector(UPDATEBUTTON_CSS);
		if (!solDilutionDatas[1].isEmpty()) {
			shortDescripTxt.clear();
			shortDescripTxt.sendKeys(solDilutionDatas[0].trim());
		}
		if (!solDilutionDatas[1].isEmpty()) {
			shortDescripTxt.clear();
			shortDescripTxt.sendKeys(solDilutionDatas[0].trim());
		}
		if (!solDilutionDatas[2].isEmpty()) {
			solnDilDescription.clear();
			solnDilDescription.sendKeys(solDilutionDatas[2].trim());
		}
		if (!solDilutionDatas[3].isEmpty()) {
			new Select(defaultUOM).selectByVisibleText(solDilutionDatas[3]
					.trim());
		}
		if (!solDilutionDatas[4].isEmpty()) {
			new Select(route).selectByVisibleText(solDilutionDatas[4].trim());
		}
		updateButton.click();
		waitForElementCssSelector(UPDATEBUTTON_CSS);
		return solnDilDescription.getAttribute("value").trim() == solDilutionDatas[2]
				.trim();
	}

	/**
	 * @return the diluentListTab
	 */
	public SolnDiluentListTab getDiluentListTab() {
		return solnDiluentListTab;
	}

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the searceButton
	 */
	public WebElement getSearceButton() {
		return searceButton;
	}

	/**
	 * @return the solDiluent
	 */
	public WebElement getSolDiluentTxt() {
		return solDiluentTxt;
	}

	/**
	 * @return the shortDescripTxt
	 */
	public WebElement getShortDescripTxt() {
		return shortDescripTxt;
	}

	/**
	 * @return the solnDilDescription
	 */
	public WebElement getSolnDilDescription() {
		return solnDilDescription;
	}

	/**
	 * @return the defaultUOM
	 */
	public WebElement getDefaultUOM() {
		return defaultUOM;
	}

	/**
	 * @return the route
	 */
	public WebElement getRoute() {
		return route;
	}

	/**
	 * @return the itemCategory
	 */
	public WebElement getItemCategory() {
		return itemCategory;
	}

	/**
	 * @return the solnDiluentListTab
	 */
	public SolnDiluentListTab getSolnDiluentListTab() {
		return solnDiluentListTab;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}
	
	/**
	 * @return the solDilMenuLink
	 */
	public WebElement getSolDilMenuLink() {
		return solDilMenuLink;
	}

}
