package com.atk.himma.pageobjects.radiology.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RadiologyServiceList {

	public final static String FORM_ID = "serviceList";
	public final static String QUICKSEARCHTXT_ID = "serviceList";
	public final static String SEARCHBUTTON_ID = "quickSearch";
	public final static String ADVSEARCHBUTTON_ID = "advancedSearch";
	public final static String EXPORTTOEXCELBUTTON_ID = "serviceSearch_grid_export_btn";
	
//	-----------GRID--------------
	public final static String GRID_ID = "serviceSearch_grid";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.serviceCode";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.serviceName";
	public final static String GRID_SPECIALTY_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.specialtyText";
	public final static String GRID_SUBSPECIALITY_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.subSpecialityText";
	public final static String GRID_status_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_serviceSearch_grid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_serviceSearch_grid_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(id = EXPORTTOEXCELBUTTON_ID)
	private WebElement exportToExcelButton;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the quickSearchTxt
	 */
	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the exportToExcelButton
	 */
	public WebElement getExportToExcelButton() {
		return exportToExcelButton;
	}
	
	
}
