package com.atk.himma.pageobjects.sa.masters;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.masters.tabs.MainBusinessUnitListTab;
import com.atk.himma.pageobjects.sa.masters.tabs.ResourceCategoryDetailsTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class ResourceCategoryPage extends DriverWaitClass implements
		StatusMessages {
	private MainBusinessUnitListTab mainBusinessUnitListTab;
	private ResourceCategoryDetailsTab resourceCategoryDetailsTab;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Resource Category')]";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void initPage(WebDriver webDriver, WebDriverWait webDriverWait) {
		mainBusinessUnitListTab = PageFactory.initElements(webDriver,
				MainBusinessUnitListTab.class);
		mainBusinessUnitListTab.setWebDriver(webDriver);
		mainBusinessUnitListTab.setWebDriverWait(webDriverWait);

		resourceCategoryDetailsTab = PageFactory.initElements(webDriver,
				ResourceCategoryDetailsTab.class);
		resourceCategoryDetailsTab.setWebDriver(webDriver);
		resourceCategoryDetailsTab.setWebDriverWait(webDriverWait);

	}

	public ResourceCategoryPage clickOnResourceCategoryMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> resCatParentMenuList = new LinkedList<String>();
		resCatParentMenuList.add("System Administration");
		resCatParentMenuList.add("Masters ");
		menuSelector.clickOnTargetMenu(resCatParentMenuList, "Resource Category");
		ResourceCategoryPage resourceCategoryPage = PageFactory.initElements(
				webDriver, ResourceCategoryPage.class);
		resourceCategoryPage.setWebDriver(webDriver);
		resourceCategoryPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return resourceCategoryPage;

	}

	public MainBusinessUnitListTab getMainBusinessUnitListTab() {
		return mainBusinessUnitListTab;
	}

	public ResourceCategoryDetailsTab getResourceCategoryDetailsTab() {
		return resourceCategoryDetailsTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
