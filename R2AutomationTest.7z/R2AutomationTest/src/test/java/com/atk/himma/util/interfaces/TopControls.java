package com.atk.himma.util.interfaces;

public interface TopControls {
	
	public final static String SETTINGS_XPATH = "//div[@id='topcontrols']//img[@title='Settings']";
	public final static String HELP_XPATH = "//div[@id='topcontrols']//img[@title='Help']";
	public final static String SIGNOUT_XPATH = "//div[@id='topcontrols']//img[@title='Sign Out']";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	
}
