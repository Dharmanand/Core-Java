package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.masters.ResourceCategoryPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ResourceCategoryTest extends SeleniumDriverSetup {
	ResourceCategoryPage resourceCategoryPage;
	List<String[]> rootResCatList;
	List<String[]> mbuResCatList;

	@Test(description = "Open Resource Category Page")
	public void openResourceCategory() throws Exception {
		resourceCategoryPage = PageFactory.initElements(webDriver,
				ResourceCategoryPage.class);
		resourceCategoryPage = resourceCategoryPage
				.clickOnResourceCategoryMenu(webDriver, webDriverWait);
		resourceCategoryPage.initPage(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		Assert.assertNotNull(resourceCategoryPage);
		resourceCategoryPage.waitForElementVisibilityOf(resourceCategoryPage
				.getMainBusinessUnitListTab().getMbuListForm());
		Assert.assertTrue(resourceCategoryPage.getMainBusinessUnitListTab()
				.getMbuName().isDisplayed());
	}

	@Test(description = "Add Resource Category For Root", dependsOnMethods = { "openResourceCategory" })
	public void addResourceCatTest1ForRoot() throws Exception {
		rootResCatList = excelReader.read(properties.getProperty("rootResourceCategory").trim());
		if (rootResCatList != null && !rootResCatList.isEmpty()) {
			resourceCategoryPage.getMainBusinessUnitListTab().clickOnEditRoot();
			for (String[] rootResCatData : rootResCatList) {
				resourceCategoryPage.getResourceCategoryDetailsTab()
						.addRootResCatRecord(rootResCatData);
				Assert.assertTrue(resourceCategoryPage
						.getResourceCategoryDetailsTab().searchGridData(
								rootResCatData));
				resourceCategoryPage.getResourceCategoryDetailsTab()
						.updateResCat();
			}
			resourceCategoryPage.getResourceCategoryDetailsTab()
					.clickOnCancel();
		}
	}

	@Test(description = "Add Resource Category For MBU", dependsOnMethods = { "openResourceCategory" })
	public void addResourceCatTest2ForMBU() throws Exception {
		mbuResCatList = excelReader.read(properties.getProperty("resourceCategory").trim());
		if (mbuResCatList != null && !mbuResCatList.isEmpty()) {
			for (String[] mbuResCatData : mbuResCatList) {
				if (mbuResCatData[0].trim().length() != 0) {
					resourceCategoryPage.getMainBusinessUnitListTab()
							.searchMbuList(mbuResCatData[0].trim());
				}
				resourceCategoryPage.getResourceCategoryDetailsTab()
						.addMbuResCatRecord(mbuResCatData);
			}
			resourceCategoryPage.getResourceCategoryDetailsTab().saveResCat();
		}

	}

	//[Resource Category] Open Form
	@Test(description = "Check Resource Category Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkResourceCategoryMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		resourceCategoryPage = PageFactory.initElements(webDriver,
				ResourceCategoryPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> resCatParentMenuList = new LinkedList<String>();
		resCatParentMenuList.add("System Administration");
		resCatParentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(resCatParentMenuList,
				"Resource Category");
		resourceCategoryPage.setWebDriver(webDriver);
		resourceCategoryPage.setWebDriverWait(webDriverWait);
		resourceCategoryPage
				.waitForElementXpathExpression(ResourceCategoryPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Resource Category")
				.get("[Resource Category] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ResourceCategoryPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Resource Category] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			resourceCategoryPage = resourceCategoryPage
					.clickOnResourceCategoryMenu(webDriver, webDriverWait);
			resourceCategoryPage.initPage(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(resourceCategoryPage);
			resourceCategoryPage
					.waitForElementVisibilityOf(resourceCategoryPage
							.getMainBusinessUnitListTab().getMbuListForm());
			resourceCategoryPage.sleepShort();
			Assert.assertEquals(resourceCategoryPage.getPageTitle().getText(),
					"Resource Category");
		}
	}
}
