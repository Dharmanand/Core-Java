package com.atk.himma.pageobjects.cpoe;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.cpoe.sections.ConsultationFirstSection;
import com.atk.himma.pageobjects.cpoe.sections.DiagnosisDetailsSection;
import com.atk.himma.pageobjects.cpoe.sections.ExternalOrderSummarySection;
import com.atk.himma.pageobjects.cpoe.sections.OrderSummarySection;
import com.atk.himma.pageobjects.cpoe.sections.VitalSignsSection;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;

public class ConsultationPage extends DriverWaitClass implements StatusMessages {
	private ConsultationFirstSection consultationFirstSection;
	private VitalSignsSection vitalSignsSection;
	private DiagnosisDetailsSection diagnosisDetailsSection;
	private OrderSummarySection orderSummarySection;
	private ExternalOrderSummarySection externalOrderSummarySection;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String CONSULTATIONFORM_ID = "CPOE_FORM";
	public final static String CALCPRICEBTN_ID = "CALCULATE_PRICE";
	public final static String SAVEBTN_ID = "SAVE_BUTTON";
	public final static String NEWORDBTN_XPATH = "//form[@id='CPOE_FORM']////input[@value='New Order']";
	public final static String UPDATEBTN_XPATH = "//form[@id='CPOE_FORM']//input[@value='Update']";
	public final static String PRINTORDBTN_ID = "PRINT_BTN_ORDER_ID";
	public final static String PRINTEXTORDBTN_ID = "PRINT_BTN_EXT_ORDER_ID";
	public final static String CANCELBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String INVOICEBTN_ID = "INVOICE_BT_ID";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(id = CONSULTATIONFORM_ID)
	private WebElement consultationForm;

	@FindBy(id = CALCPRICEBTN_ID)
	private WebElement calculatePriceBtn;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(id = PRINTORDBTN_ID)
	private WebElement printOrderBtn;

	@FindBy(id = PRINTEXTORDBTN_ID)
	private WebElement printExtOrderBtn;

	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	@FindBy(xpath = NEWORDBTN_XPATH)
	private WebElement newOrderBtn;

	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	@FindBy(id = INVOICEBTN_ID)
	private WebElement invoiceBtn;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		consultationFirstSection = PageFactory.initElements(webDriver,
				ConsultationFirstSection.class);
		consultationFirstSection.setWebDriver(webDriver);
		consultationFirstSection.setWebDriverWait(webDriverWait);

		vitalSignsSection = PageFactory.initElements(webDriver,
				VitalSignsSection.class);
		vitalSignsSection.setWebDriver(webDriver);
		vitalSignsSection.setWebDriverWait(webDriverWait);

		diagnosisDetailsSection = PageFactory.initElements(webDriver,
				DiagnosisDetailsSection.class);
		diagnosisDetailsSection.setWebDriver(webDriver);
		diagnosisDetailsSection.setWebDriverWait(webDriverWait);

		orderSummarySection = PageFactory.initElements(webDriver,
				OrderSummarySection.class);
		orderSummarySection.setWebDriver(webDriver);
		orderSummarySection.setWebDriverWait(webDriverWait);

		externalOrderSummarySection = PageFactory.initElements(webDriver,
				ExternalOrderSummarySection.class);
		externalOrderSummarySection.setWebDriver(webDriver);
		externalOrderSummarySection.setWebDriverWait(webDriverWait);
	}

	public String calcPrice() throws Exception {
		waitForElementId(CALCPRICEBTN_ID);
		calculatePriceBtn.click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		sleepVeryShort();
		String msg = webDriver.findElement(By.xpath(MSGENABLE_XPATH)).getText();
		webDriver.findElement(By.id(MSGHIDELNK_ID)).click();
		return msg;
	}

	public String saveConsultationDetails() throws Exception {
		waitForElementId(SAVEBTN_ID);
		saveBtn.click();
		sleepShort();
		waitForElementId(PRINTEXTORDBTN_ID);
//		waitForElementXpathExpression(UPDATEBTN_XPATH);
		String text = printExtOrderBtn.getAttribute("value").trim();
		sleepShort();
		webDriver.close();
		webDriver.switchTo().window(parentWindowHandle);
		return text;

	}

	public ConsultationFirstSection getConsultationFirstSection() {
		return consultationFirstSection;
	}

	public VitalSignsSection getVitalSignsSection() {
		return vitalSignsSection;
	}

	public DiagnosisDetailsSection getDiagnosisDetailsSection() {
		return diagnosisDetailsSection;
	}

	public OrderSummarySection getOrderSummarySection() {
		return orderSummarySection;
	}

	public ExternalOrderSummarySection getExternalOrderSummarySection() {
		return externalOrderSummarySection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getConsultationForm() {
		return consultationForm;
	}

	public WebElement getCalculatePriceBtn() {
		return calculatePriceBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getInvoiceBtn() {
		return invoiceBtn;
	}

	public WebElement getPrintOrderBtn() {
		return printOrderBtn;
	}

	public WebElement getPrintExtOrderBtn() {
		return printExtOrderBtn;
	}

	public WebElement getNewOrderBtn() {
		return newOrderBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

}
