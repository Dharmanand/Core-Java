package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AppUserIdentifiersSection extends DriverWaitClass {
	public final static String USERIDSECTION_LINKTXT = "Application User Identifiers";
	@FindBy(linkText = USERIDSECTION_LINKTXT)
	private WebElement userIdSectionLinkTxt;

	public final static String PREFIX_ID = "prefix";
	@FindBy(id = PREFIX_ID)
	private WebElement prefix;

	public final static String PREFIXAR_ID = "prefixNL";
	@FindBy(id = PREFIXAR_ID)
	private WebElement prefixAr;

	public final static String GIVENNAME_ID = "givenName";
	@FindBy(id = GIVENNAME_ID)
	private WebElement givenName;

	public final static String GIVENNAMEAR_ID = "givenNameNL";
	@FindBy(id = GIVENNAMEAR_ID)
	private WebElement givenNameAr;

	public final static String FATHERNAME_ID = "fatherName";
	@FindBy(id = FATHERNAME_ID)
	private WebElement fatherName;

	public final static String FATHERNAMEAR_ID = "fatherNameNL";
	@FindBy(id = FATHERNAMEAR_ID)
	private WebElement fatherNameAr;

	public final static String GRANDFATHERNAME_ID = "grandFatherName";
	@FindBy(id = GRANDFATHERNAME_ID)
	private WebElement grandFatherName;

	public final static String GRANDFATHERNAMEAR_ID = "grandFatherNameNL";
	@FindBy(id = GRANDFATHERNAMEAR_ID)
	private WebElement grandFatherNameAr;

	public final static String FAMILYNAME_ID = "familyName";
	@FindBy(id = FAMILYNAME_ID)
	private WebElement familyName;

	public final static String FAMILYNAMEAR_ID = "familyNameNL";
	@FindBy(id = FAMILYNAMEAR_ID)
	private WebElement familyNameAr;

	public final static String PROFESSIONALSUFFIX_ID = "professional_Suffix";
	@FindBy(id = PROFESSIONALSUFFIX_ID)
	private WebElement professionalSuffix;

	public final static String PROFESSIONALSUFFIXAR_ID = "professionalSuffixNL";
	@FindBy(id = PROFESSIONALSUFFIXAR_ID)
	private WebElement professionalSuffixAr;

	public final static String GENDER_ID = "gender";
	@FindBy(id = GENDER_ID)
	private WebElement gender;

	public final static String DOB_ID = "emDobDatPickr";
	@FindBy(id = DOB_ID)
	private WebElement dob;

	public final static String NATIONALITY_ID = "nationality";
	@FindBy(id = NATIONALITY_ID)
	private WebElement nationality;

	public final static String RELIGION_ID = "religion";
	@FindBy(id = RELIGION_ID)
	private WebElement religion;

	public final static String LANGUAGE_ID = "languageText";
	@FindBy(id = LANGUAGE_ID)
	private WebElement language;

	public final static String MARITALSTATUS_ID = "maritalStatus";
	@FindBy(id = MARITALSTATUS_ID)
	private WebElement maritalStatus;

	public void fillUserIdentifiers(String[] appUserData) {
		if (!appUserData[1].isEmpty()) {
			new Select(prefix).selectByVisibleText(appUserData[1]);
		}
		if (!appUserData[2].isEmpty()) {
			new Select(prefixAr).selectByVisibleText(appUserData[2]);
		}
		givenName.clear();
		givenName.sendKeys(appUserData[3]);

		givenNameAr.clear();
		givenNameAr.sendKeys(appUserData[4]);

		fatherName.clear();
		fatherName.sendKeys(appUserData[5]);

		fatherNameAr.clear();
		fatherNameAr.sendKeys(appUserData[6]);

		grandFatherName.clear();
		grandFatherName.sendKeys(appUserData[7]);

		grandFatherNameAr.clear();
		grandFatherNameAr.sendKeys(appUserData[8]);

		familyName.clear();
		familyName.sendKeys(appUserData[9]);

		familyNameAr.clear();
		familyNameAr.sendKeys(appUserData[10]);

		professionalSuffix.clear();
		professionalSuffix.sendKeys(appUserData[11]);

		professionalSuffixAr.clear();
		professionalSuffixAr.sendKeys(appUserData[12]);

		if (!appUserData[13].isEmpty()) {
			new Select(gender).selectByVisibleText(appUserData[13]);
		}
		dob.clear();
		dob.sendKeys(appUserData[14]);

		if (!appUserData[15].isEmpty()) {
			new Select(nationality).selectByVisibleText(appUserData[15]);
		}

		if (!appUserData[16].isEmpty()) {
			new Select(religion).selectByVisibleText(appUserData[16]);
		}

		if (!appUserData[17].isEmpty()) {
			new Select(language).selectByVisibleText(appUserData[17]);
		}

		if (!appUserData[18].isEmpty()) {
			new Select(maritalStatus).selectByVisibleText(appUserData[18]);
		}
	}

	public WebElement getUserIdSectionLinkTxt() {
		return userIdSectionLinkTxt;
	}

	public WebElement getPrefix() {
		return prefix;
	}

	public WebElement getPrefixAr() {
		return prefixAr;
	}

	public WebElement getGivenName() {
		return givenName;
	}

	public WebElement getGivenNameAr() {
		return givenNameAr;
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public WebElement getFatherNameAr() {
		return fatherNameAr;
	}

	public WebElement getGrandFatherName() {
		return grandFatherName;
	}

	public WebElement getGrandFatherNameAr() {
		return grandFatherNameAr;
	}

	public WebElement getFamilyName() {
		return familyName;
	}

	public WebElement getFamilyNameAr() {
		return familyNameAr;
	}

	public WebElement getProfessionalSuffix() {
		return professionalSuffix;
	}

	public WebElement getProfessionalSuffixAr() {
		return professionalSuffixAr;
	}

	public WebElement getGender() {
		return gender;
	}

	public WebElement getDob() {
		return dob;
	}

	public WebElement getNationality() {
		return nationality;
	}

	public WebElement getReligion() {
		return religion;
	}

	public WebElement getLanguage() {
		return language;
	}

	public WebElement getMaritalStatus() {
		return maritalStatus;
	}

}
