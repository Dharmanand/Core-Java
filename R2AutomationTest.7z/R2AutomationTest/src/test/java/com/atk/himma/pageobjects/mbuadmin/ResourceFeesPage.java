package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.resfeesdetails.ApplicableMainBusinessUnits;
import com.atk.himma.pageobjects.mbuadmin.sections.resfeesdetails.ResFeesFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.resfeesdetails.ServiceTariffModifier;
import com.atk.himma.pageobjects.mbuadmin.tabs.ResourceFeesListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ResourceFeesPage extends DriverWaitClass implements
		StatusMessages, TopControls, RecordStatus {

	private ResourceFeesListTab resourceFeesListTab;
	private ResFeesFirstSection resFeesFirstSection;
	private ServiceTariffModifier serviceTariffModifier;
	private ApplicableMainBusinessUnits applicableMainBusinessUnits;

	public final static String EXPORTTOEXCEL_ID = "RESOURCE_NAME_LIST_export_btn";
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";

	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'created successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Updated successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Record activated successfully')]";
	
	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Resource Fees']";	
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement resFeeDetailsPageTitle;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;

	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		resourceFeesListTab = PageFactory.initElements(webDriver,
				ResourceFeesListTab.class);
		resourceFeesListTab.setWebDriver(webDriver);
		resourceFeesListTab.setWebDriverWait(webDriverWait);

		resFeesFirstSection = PageFactory.initElements(webDriver,
				ResFeesFirstSection.class);
		resFeesFirstSection.setWebDriver(webDriver);
		resFeesFirstSection.setWebDriverWait(webDriverWait);

		serviceTariffModifier = PageFactory.initElements(webDriver,
				ServiceTariffModifier.class);
		serviceTariffModifier.setWebDriver(webDriver);
		serviceTariffModifier.setWebDriverWait(webDriverWait);

		applicableMainBusinessUnits = PageFactory.initElements(webDriver,
				ApplicableMainBusinessUnits.class);
		applicableMainBusinessUnits.setWebDriver(webDriver);
		applicableMainBusinessUnits.setWebDriverWait(webDriverWait);

	}

	public ResourceFeesPage clickOnResFeesMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Resource Fees");
		ResourceFeesPage resourceFeesPage = PageFactory.initElements(webDriver,
				ResourceFeesPage.class);
		resourceFeesPage.setWebDriver(webDriver);
		resourceFeesPage.setWebDriverWait(webDriverWait);
		return resourceFeesPage;
	}

	public String searchResourceFees(String[] resourceFeeDatas) throws InterruptedException {
		waitForElementId(ResourceFeesListTab.MBU_ID);
		resourceFeesListTab.getResourceName().clear();
		resourceFeesListTab.getResourceName().sendKeys(resourceFeeDatas[5].trim());
		resourceFeesListTab.getSearchButton().click();
		waitForElementId(ResourceFeesListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(ResourceFeesListTab.GRID_ID,
				ResourceFeesListTab.GRID_FULLNAME_ARIA_DESCRIBEDBY, resourceFeeDatas[5].trim());
	}
	
	public boolean defineFees(String[] resourceFeeDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(ResourceFeesListTab.GRID_ID,
				ResourceFeesListTab.GRID_FULLNAME_ARIA_DESCRIBEDBY, resourceFeeDatas[5]);
		sleepShort();
		clickOnGridAction(resourceFeeDatas[5], "Define Fees");
		waitForElementId(ResFeesFirstSection.RESNAME_ID);
		sleepVeryShort();
		return resFeesFirstSection.getResName().getAttribute("value").trim().equals(resourceFeeDatas[5].trim());
	}
	
	public boolean editServiceCharge(String[] resourceFeeDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(ResourceFeesListTab.GRID_ID,
				ResourceFeesListTab.GRID_FULLNAME_ARIA_DESCRIBEDBY, resourceFeeDatas[5]);
		sleepShort();
		clickOnGridAction(resourceFeeDatas[5], "Edit");
		waitForElementId(ResFeesFirstSection.RESNAME_ID);
		sleepVeryShort();
		return resFeesFirstSection.getResName().getAttribute("value").trim().equals(resourceFeeDatas[5].trim());
	}
	
	public String updateResFeeDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		detailsUpdateButton.click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		return updateConfMsg.getText().trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		waitForElementXpathExpression(SAVECONFMSG_XPATH);
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		return detailsUpdateButton.getAttribute("value").trim();

	}
	
	public String activateResFees() throws InterruptedException, IOException {
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
		
	}
	
	/**
	 * @return the resFeeDetailsPageTitle
	 */
	public WebElement getResFeeDetailsPageTitle() {
		return resFeeDetailsPageTitle;
	}

	/**
	 * @return the resourceFeesListTab
	 */
	public ResourceFeesListTab getResourceFeesListTab() {
		return resourceFeesListTab;
	}

	/**
	 * @return the resFeesFirstSection
	 */
	public ResFeesFirstSection getResFeesFirstSection() {
		return resFeesFirstSection;
	}

	/**
	 * @return the serviceTariffModifier
	 */
	public ServiceTariffModifier getServiceTariffModifier() {
		return serviceTariffModifier;
	}

	/**
	 * @return the applicableMainBusinessUnits
	 */
	public ApplicableMainBusinessUnits getApplicableMainBusinessUnits() {
		return applicableMainBusinessUnits;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	// public String searchService(String[] serviceDatas) throws
	// InterruptedException {
	// waitForElementId(ServiceListTab.MBU_ID);
	// new Select(serviceListTab.getMbu()).selectByVisibleText(serviceDatas[0]);
	// serviceListTab.getServiceName().clear();
	// serviceListTab.getServiceName().sendKeys(serviceDatas[4]);
	// new
	// Select(serviceListTab.getStatus()).selectByVisibleText(serviceDatas[8]);
	// serviceListTab.getSearchButton().click();
	// waitForElementId(ServiceListTab.GRID_ID);
	// sleepShort();
	// return waitAndGetGridFirstCellText(ServiceListTab.GRID_ID,
	// ServiceListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serviceDatas[4]);
	// }

}
