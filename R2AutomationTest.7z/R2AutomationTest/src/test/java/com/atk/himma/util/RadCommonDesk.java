package com.atk.himma.util;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RadCommonDesk extends DriverWaitClass{
	
	public final static String FORM_ID = "SEARCH_RCEP_DESKTOP_FORM";
	public final static String QUECKSEARCHTXT_ID = "QUICK_SEARCH_TEXT";
	public final static String SEARCHBUTTON_ID = "QUICK_SEARCH";
	public final static String RESETBUTTON_ID = "RESET_QUICK_SEARCH";
	public final static String VISITCATEGORY_ID = "VISIT_CATEGORY_ID";
	public final static String PRINTREPORT_ID = "DEKTOP_PRINT_REPORT_BT";
	public final static String ADVSEARCHBUTTON_ID = "FLOTING_CRITERIA_RECEP_DESK_BT";
	
	public final static String ARRIVEARSTATUSLIST_XPATH = "//span[@id='RAD_ARRIVED_STATUS	']/..";
	public final static String BOOKBKSTATUSLIST_XPATH = "//span[@id='RAD_BOOKED_STATUS']/..";
	public final static String CANCELCNSTATUSLIST_XPATH = "//span[@id='RAD_CANCELED_STATUS']/..";
	public final static String ORDEREDODSTATUSLIST_XPATH = "//span[@id='RAD_ORDERED_STATUS']/..";
	public final static String PROCEDABORTPASTATUSLIST_XPATH = "//span[@id='RAD_PROCEDURE_ABORTED_STATUS']/..";
	public final static String PROCEDCOMPLPCSTATUSLIST_XPATH = "//span[@id='RAD_PROCEDURE_COMPLETED_STATUS']/..";
	public final static String PROCESTARTEDSTATUSLIST_XPATH = "//span[@id='RAD_PROCEDURE_STARTED_STATUS']/..";
	public final static String PROCEDUREONHOLDSTATUSLIST_XPATH = "//span[@id='RAD_PROCEDURE_ONHOLD_STATUS']/..";
	public final static String RESULTAMENDRMSTATUSLIST_XPATH = "//span[@id='RAD_RESULT_AMENDED_STATUS']/..";
	public final static String RESULTAUTHORASTATUSLIST_XPATH = "//span[@id='RAD_RESULT_AUTHORIZED_STATUS']/..";
	public final static String RESULTCOMPLRCSTATUSLIST_XPATH = "//span[@id='RAD_RESULT_COMPLETED_STATUS']/..";
	public final static String RESULTVERIFIEDSTATUSLIST_XPATH = "//span[@id='RAD_RESULT_VERIFIED_STATUS']/..";
	
	@FindBy(id = FORM_ID)
	protected WebElement form;
	
	@FindBy(id = QUECKSEARCHTXT_ID)
	protected WebElement queckSearchTxt;
	
	@FindBy(id = SEARCHBUTTON_ID)
	protected WebElement searchButton;
	
	@FindBy(id = RESETBUTTON_ID)
	protected WebElement resetButton;
	
	@FindBy(id = VISITCATEGORY_ID)
	protected WebElement visitCategory;
	
	@FindBy(id = PRINTREPORT_ID)
	protected WebElement printReport;
	
	@FindBy(id = ADVSEARCHBUTTON_ID)
	protected WebElement advSearchButton;
	
	@FindBy(id = ARRIVEARSTATUSLIST_XPATH)
	protected WebElement arriveARStatusList;
	
	@FindBy(id = BOOKBKSTATUSLIST_XPATH)
	protected WebElement bookBKStatusList;
	
	@FindBy(id = CANCELCNSTATUSLIST_XPATH)
	protected WebElement cancelCNStatusList;
	
	@FindBy(id = ORDEREDODSTATUSLIST_XPATH)
	protected WebElement orderedODStatusList;
	
	@FindBy(id = PROCEDABORTPASTATUSLIST_XPATH)
	protected WebElement procedAbortPAStatusList;
	
	@FindBy(id = PROCEDCOMPLPCSTATUSLIST_XPATH)
	protected WebElement procedComplPCStatusList;
	
	@FindBy(id = PROCESTARTEDSTATUSLIST_XPATH)
	protected WebElement proceStartedStatusList;
	
	@FindBy(id = PROCEDUREONHOLDSTATUSLIST_XPATH)
	protected WebElement procedureOnHoldStatusList;
	
	@FindBy(id = RESULTAMENDRMSTATUSLIST_XPATH)
	protected WebElement resultAmendRMStatusList;
	
	@FindBy(id = RESULTAUTHORASTATUSLIST_XPATH)
	protected WebElement resultAuthoRAStatusList;
	
	/**
	 * @return the arriveARStatusList
	 */
	public WebElement getArriveARStatusList() {
		return arriveARStatusList;
	}

	/**
	 * @return the bookBKStatusList
	 */
	public WebElement getBookBKStatusList() {
		return bookBKStatusList;
	}

	/**
	 * @return the cancelCNStatusList
	 */
	public WebElement getCancelCNStatusList() {
		return cancelCNStatusList;
	}

	/**
	 * @return the orderedODStatusList
	 */
	public WebElement getOrderedODStatusList() {
		return orderedODStatusList;
	}

	/**
	 * @return the procedAbortPAStatusList
	 */
	public WebElement getProcedAbortPAStatusList() {
		return procedAbortPAStatusList;
	}

	/**
	 * @return the procedComplPCStatusList
	 */
	public WebElement getProcedComplPCStatusList() {
		return procedComplPCStatusList;
	}

	/**
	 * @return the proceStartedStatusList
	 */
	public WebElement getProceStartedStatusList() {
		return proceStartedStatusList;
	}

	/**
	 * @return the resultAmendRMStatusList
	 */
	public WebElement getResultAmendRMStatusList() {
		return resultAmendRMStatusList;
	}

	/**
	 * @return the resultAuthoRAStatusList
	 */
	public WebElement getResultAuthoRAStatusList() {
		return resultAuthoRAStatusList;
	}

	/**
	 * @return the resultComplRCStatusList
	 */
	public WebElement getResultComplRCStatusList() {
		return resultComplRCStatusList;
	}

	/**
	 * @return the resultVerifiedStatusList
	 */
	public WebElement getResultVerifiedStatusList() {
		return resultVerifiedStatusList;
	}

	@FindBy(id = RESULTCOMPLRCSTATUSLIST_XPATH)
	protected WebElement resultComplRCStatusList;
	
	@FindBy(id = RESULTVERIFIEDSTATUSLIST_XPATH)
	protected WebElement resultVerifiedStatusList;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the queckSearchTxt
	 */
	public WebElement getQueckSearchTxt() {
		return queckSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the visitCategory
	 */
	public WebElement getVisitCategory() {
		return visitCategory;
	}

	/**
	 * @return the printReport
	 */
	public WebElement getPrintReport() {
		return printReport;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}
	
	/**
	 * @return the procedureOnHoldStatusList
	 */
	public WebElement getProcedureOnHoldStatusList() {
		return procedureOnHoldStatusList;
	}

}
