package com.atk.himma.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MenuSelector {
	private WebDriver webDriver;
	private WebDriverWait webDriverWait;

	public MenuSelector(WebDriver webDriver, WebDriverWait webDriverWait) {
		this.webDriver = webDriver;
		this.webDriverWait = webDriverWait;
	}

	public void clickOnTargetMenu(List<String> parentMenuList, String targetMenu) {
		webDriverWait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.className("navigationdd")));
		List<WebElement> menus = webDriver.findElement(
				By.className("navigationdd")).findElements(By.tagName("a"));
		WebElement we;
		for (int i = 0; i < menus.size(); i++) {
			we = menus.get(i);
			String menu = we.getText();
			if (menu.equals(targetMenu)) {
				((JavascriptExecutor) webDriver)
						.executeScript("$('#navigation a:eq(" + i
								+ ")').mouseover();");
				we.click();
				break;
			} else {
				for (String parentMenu : parentMenuList) {
					if (menu.startsWith(parentMenu)) {
						((JavascriptExecutor) webDriver)
								.executeScript("$('#navigation a:eq(" + i
										+ ")').mouseover();");
						break;
					}
				}
			}
		}
	}

	public void mouseOverOnTargetMenu(List<String> parentMenuList,
			String targetMenu) {
		webDriverWait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.className("navigationdd")));
		List<WebElement> menus = webDriver.findElement(
				By.className("navigationdd")).findElements(By.tagName("a"));
		WebElement we;
		for (int i = 0; i < menus.size(); i++) {
			we = menus.get(i);
			String menu = we.getText();
			if (menu.equals(targetMenu)) {
				((JavascriptExecutor) webDriver)
						.executeScript("$('#navigation a:eq(" + i
								+ ")').mouseover();");

				break;
			} else {
				for (String parentMenu : parentMenuList) {
					if (menu.startsWith(parentMenu)) {
						((JavascriptExecutor) webDriver)
								.executeScript("$('#navigation a:eq(" + i
										+ ")').mouseover();");
						break;
					}
				}
			}
		}
	}

}
