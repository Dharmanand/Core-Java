package com.atk.himma.pageobjects.sa.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.pageobjects.sa.masters.tabs.sections.InterfaceDetailsSection;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class EquipmentDetailsTab extends DriverWaitClass implements
		StatusMessages, TopControls, RecordStatus {

	private InterfaceDetailsSection interfaceDetailsSection;

	public final static String ADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Add New']";
	@FindBy(xpath = ADDNEWBUTTON_XPATH)
	private WebElement addNewButton;

	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Save']";
	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Update']";
	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;

	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Cancel']";
	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	public final static String EQUIPCODE_ID = "EQ_CODE";
	@FindBy(id = EQUIPCODE_ID)
	private WebElement equipmentCode;

	public final static String EQUIPSHNAME_ID = "EQ_SHORT_NAME";
	@FindBy(id = EQUIPSHNAME_ID)
	private WebElement equipShortName;

	public final static String EQUIPNAME_ID = "EQ_NAME";
	@FindBy(id = EQUIPNAME_ID)
	private WebElement equipName;

	public final static String MBU_ID = "MBU_EQUIP";
	@FindBy(id = MBU_ID)
	private WebElement mbu;

	public final static String DEPARTMENT_ID = "EQUIP_DEPT";
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	public final static String RESTYPE_ID = "EQUIP_RES_TYPE";
	@FindBy(id = RESTYPE_ID)
	private WebElement resourceType;

	public final static String REFITEMNAME_ID = "REF_ITEM_NAME";
	@FindBy(id = REFITEMNAME_ID)
	private WebElement refItemName;

	// --------------------------lookup------------------------------------

	public final static String LOOKUP_ID = "EQUIP_RES_TYPE";
	@FindBy(id = LOOKUP_ID)
	private WebElement lookUpLogo;

	public final static String itemCategory_ID = "ITEM_CAT";
	@FindBy(id = itemCategory_ID)
	private WebElement itemCategory;

	public final static String ITEMCODE_ID = "ITEM_CODE";
	@FindBy(id = ITEMCODE_ID)
	private WebElement itemCode;

	public final static String ITEMNAME_ID = "ITEM_NAME";
	@FindBy(id = ITEMNAME_ID)
	private WebElement itemName;

	public final static String SEARCHBUTTON_XPATH = "(//span[@class='buttoncontainer_mid'])[2]//input[@value='Search']";
	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	public final static String RESETBUTTON_XPATH = "(//span[@class='buttoncontainer_mid'])[2]//input[@value='Reset']";
	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	public final static String GRIDLOOKUP_ID = "ITEM_POPUP_GRID";

	public final static String GRIDLOOKUP_ITEMCODE_ARIA_DESCRIBEDBY = "ITEM_POPUP_GRID_itemCode";
	public final static String GRIDLOOKUP_ITEMNAME_ARIA_DESCRIBEDBY = "ITEM_POPUP_GRID_itemName";

	// ---------------------Material Management
	// Details---------------------------

	public boolean isMandEquipShotName() {
		waitForElementId(EQUIPSHNAME_ID);
		return isMandatoryField(equipShortName);
	}

	public boolean isMandEquipName() {
		waitForElementId(EQUIPNAME_ID);
		return isMandatoryField(equipName);
	}

	public boolean isMandMBU() {
		waitForElementId(MBU_ID);
		return isMandatoryField(mbu);
	}

	public boolean isMandDepartment() {
		waitForElementId(DEPARTMENT_ID);
		return isMandatoryField(department);
	}

	public boolean isMandResTpye() {
		waitForElementId(RESTYPE_ID);
		return isMandatoryField(resourceType);
	}

	public boolean fillDatas(String[] equipDatas) throws InterruptedException {
		waitForElementXpathExpression(SAVEBUTTON_XPATH);
		sleepVeryShort();
		equipShortName.clear();
		equipShortName.sendKeys(equipDatas[1].trim());
		equipName.clear();
		equipName.sendKeys(equipDatas[2].trim());

		if (!equipDatas[3].trim().isEmpty())
			new Select(mbu).selectByVisibleText(equipDatas[3].trim());
		if (!equipDatas[4].trim().isEmpty())
			new Select(department).selectByVisibleText(equipDatas[4].trim());
		if (!equipDatas[5].trim().isEmpty())
			new Select(resourceType).selectByVisibleText(equipDatas[5].trim());
		clickOnlookUp();
		fillLookUpData(equipDatas);
		return equipName.getAttribute("value").trim()
				.equals(equipDatas[2].trim());
	}

	public boolean clickOnlookUp() {
		waitForElementId(LOOKUP_ID);
		lookUpLogo.click();
		waitForElementId(GRIDLOOKUP_ID);
		waitForElementId(ITEMNAME_ID);
		return itemName.isDisplayed();
	}

	public boolean fillLookUpData(String[] equipDatas) {
		waitForElementId(ITEMNAME_ID);
		itemName.clear();
		itemName.sendKeys(equipDatas[9].trim());
		searchButton.click();
		clickOnGridAction(equipDatas[9].trim(), "Select");
		waitForElementId(REFITEMNAME_ID);
		return refItemName.getAttribute("value").trim()
				.equals(equipDatas[9].trim());
	}

	/**
	 * @return the interfaceDetailsSection
	 */
	public InterfaceDetailsSection getInterfaceDetailsSection() {
		return interfaceDetailsSection;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the equipmentCode
	 */
	public WebElement getEquipmentCode() {
		return equipmentCode;
	}

	/**
	 * @return the equipShortName
	 */
	public WebElement getEquipShortName() {
		return equipShortName;
	}

	/**
	 * @return the equipName
	 */
	public WebElement getEquipName() {
		return equipName;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the resourceType
	 */
	public WebElement getResourceType() {
		return resourceType;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the lookUpLogo
	 */
	public WebElement getLookUpLogo() {
		return lookUpLogo;
	}

	/**
	 * @return the itemCategory
	 */
	public WebElement getItemCategory() {
		return itemCategory;
	}

	/**
	 * @return the itemCode
	 */
	public WebElement getItemCode() {
		return itemCode;
	}

	/**
	 * @return the itemName
	 */
	public WebElement getItemName() {
		return itemName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the refItemName
	 */
	public WebElement getRefItemName() {
		return refItemName;
	}

}
