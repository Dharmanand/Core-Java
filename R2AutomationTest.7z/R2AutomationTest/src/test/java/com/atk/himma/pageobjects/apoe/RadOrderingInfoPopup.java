package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RadOrderingInfoPopup extends DriverWaitClass {
	public final static String RADORDERINFOPOPUPFORM_ID = "RAD_ORDER_POPUP";
	@FindBy(id = RADORDERINFOPOPUPFORM_ID)
	private WebElement radOrderInfoPopupForm;

	public final static String RADORDERURGENCY_ID = "ORDERING_URGENCY";
	@FindBy(id = RADORDERURGENCY_ID)
	private WebElement radOrderUrgency;

	public final static String RADORDERSTARTDATETIMETEXT_ID = "RAD_START_DATE_TIME_DATEP";
	@FindBy(id = RADORDERSTARTDATETIMETEXT_ID)
	private WebElement radOrderStartDateTimeText;

	public final static String RADORDERSTARTDATETIMEIMG_XPATH = "//input[@id='RAD_START_DATE_TIME_DATEP']/../img";
	@FindBy(id = RADORDERSTARTDATETIMEIMG_XPATH)
	private WebElement radOrderStartDateTimeImg;

	public final static String RADPERFLOC_ID = "prefloc";
	@FindBy(id = RADPERFLOC_ID)
	private WebElement radPerformingLoc;

	public final static String RADEXAMREASON_ID = "RAD_REASON_FOR_EXAM";
	@FindBy(id = RADEXAMREASON_ID)
	private WebElement radExamReason;

	public final static String RADADDITIONALPROTOCOL_ID = "additionalPatProtocols";
	@FindBy(id = RADADDITIONALPROTOCOL_ID)
	private WebElement radAdditionalProtocol;

	public final static String RADADDITIONALPATINSTR_ID = "additionalPatientInstr";
	@FindBy(id = RADADDITIONALPATINSTR_ID)
	private WebElement radAdditionalPatInstr;

	public final static String RADORDERADDTOSEL_ID = "RAD_ORDER_INFO_SUBMIT";
	@FindBy(id = RADORDERADDTOSEL_ID)
	private WebElement radOrderAddToSelList;

	public final static String RADORDERRESET_ID = "RAD_ORDER_INFO_RESET";
	@FindBy(id = RADORDERRESET_ID)
	private WebElement radOrderReset;
	
	public void addRadOrderInfo(String[] orderEntryListData) {
		waitForElementId(RADORDERINFOPOPUPFORM_ID);
		
	}

	public WebElement getRadOrderInfoPopupForm() {
		return radOrderInfoPopupForm;
	}

	public WebElement getRadOrderUrgency() {
		return radOrderUrgency;
	}

	public WebElement getRadOrderStartDateTimeText() {
		return radOrderStartDateTimeText;
	}

	public WebElement getRadOrderStartDateTimeImg() {
		return radOrderStartDateTimeImg;
	}

	public WebElement getRadPerformingLoc() {
		return radPerformingLoc;
	}

	public WebElement getRadExamReason() {
		return radExamReason;
	}

	public WebElement getRadAdditionalProtocol() {
		return radAdditionalProtocol;
	}

	public WebElement getRadAdditionalPatInstr() {
		return radAdditionalPatInstr;
	}

	public WebElement getRadOrderAddToSelList() {
		return radOrderAddToSelList;
	}

	public WebElement getRadOrderReset() {
		return radOrderReset;
	}
}
