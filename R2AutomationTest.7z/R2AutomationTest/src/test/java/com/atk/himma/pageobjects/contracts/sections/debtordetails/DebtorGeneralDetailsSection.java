package com.atk.himma.pageobjects.contracts.sections.debtordetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class DebtorGeneralDetailsSection extends DriverWaitClass {
	public final static String DEBTORGENLDETAILSSEC_LINKTEXT = "Debtor General Details";
	private final static String ADDRESSLINE1_NAME = "debtor.generalDetails.addLine1";
	private final static String ADDRESSLINE2_NAME = "debtor.generalDetails.addLine2";
	private final static String COUNTRY_ID = "COUNTRY_ID";
	private final static String DISTRICT_ID = "DISTRICT_ID";
	private final static String CITYLOCALITY_ID = "CITY_ID";
	private final static String POSTCODE_ID = "POST_CD";
	private final static String POSTEXT_ID = "POST_EXT";
	private final static String POSTBOXNUM_NAME = "debtor.generalDetails.poBox";
	private final static String LANDPH1CC_NAME = "debtor.generalDetails.landPh1Cd";
	private final static String LANDPH1NUM_NAME = "debtor.generalDetails.landPh1Num";
	private final static String LANDPH2CC_NAME = "debtor.generalDetails.landPh2Cd";
	private final static String LANDPH2NUM_NAME = "debtor.generalDetails.landPh2Num";
	private final static String FAXCC_NAME = "debtor.generalDetails.faxCd";
	private final static String FAXNUM_NAME = "debtor.generalDetails.faxNum";

	@FindBy(linkText = DEBTORGENLDETAILSSEC_LINKTEXT)
	private WebElement dbtrGenlDetailsSec;

	@FindBy(name = ADDRESSLINE1_NAME)
	private WebElement addressLine1;

	@FindBy(name = ADDRESSLINE2_NAME)
	private WebElement addressLine2;

	@FindBy(id = COUNTRY_ID)
	private WebElement country;

	@FindBy(id = DISTRICT_ID)
	private WebElement district;

	@FindBy(id = CITYLOCALITY_ID)
	private WebElement cityLocality;

	@FindBy(id = POSTCODE_ID)
	private WebElement postCode;

	@FindBy(id = POSTEXT_ID)
	private WebElement postExt;

	@FindBy(name = POSTBOXNUM_NAME)
	private WebElement postBoxNum;

	@FindBy(name = LANDPH1CC_NAME)
	private WebElement landPh1CC;

	@FindBy(name = LANDPH1NUM_NAME)
	private WebElement landPh1Num;

	@FindBy(name = LANDPH2CC_NAME)
	private WebElement landPh2CC;

	@FindBy(name = LANDPH2NUM_NAME)
	private WebElement landPh2Num;

	@FindBy(name = FAXCC_NAME)
	private WebElement faxCC;

	@FindBy(name = FAXNUM_NAME)
	private WebElement faxNum;

	/*
	 * public boolean isMandAddress1() { waitForElementName(ADDRESSLINE1_NAME);
	 * return isMandatoryField(addressLine1); }
	 */

	public boolean isMandCountry() {
		waitForElementId(COUNTRY_ID);
		return isMandatoryField(country);
	}

	public boolean isMandDistrict() {
		waitForElementId(DISTRICT_ID);
		return isMandatoryField(district);
	}

	public boolean isMandCityLocal() {
		waitForElementId(CITYLOCALITY_ID);
		return isMandatoryField(cityLocality);
	}

	public boolean isMandLandPh1() {
		waitForElementName(LANDPH1CC_NAME);
		waitForElementName(LANDPH1NUM_NAME);
		return isMandatoryField(landPh1CC) && isMandatoryField(landPh1Num);
	}

	public void fillDebtorGeneralDetailsData(String[] debtorListData)
			throws Exception {
		addressLine1.clear();
		addressLine1.sendKeys(debtorListData[7]);

		addressLine2.clear();
		addressLine2.sendKeys(debtorListData[8]);

		if (!debtorListData[9].isEmpty()) {
			new Select(country).selectByVisibleText(debtorListData[9]);
		}
		sleepVeryShort();
		if (!debtorListData[10].isEmpty()) {
			new Select(district).selectByVisibleText(debtorListData[10]);
		}
		sleepVeryShort();
		if (!debtorListData[11].isEmpty()) {
			new Select(cityLocality).selectByVisibleText(debtorListData[11]);
		}

		postCode.clear();
		postCode.sendKeys(debtorListData[12]);

		postExt.clear();
		postExt.sendKeys(debtorListData[13]);

		postBoxNum.clear();
		postBoxNum.sendKeys(debtorListData[14]);

		if (!debtorListData[15].isEmpty()) {
			new Select(landPh1CC).selectByVisibleText(debtorListData[15]);
		}
		landPh1Num.clear();
		landPh1Num.sendKeys(debtorListData[16]);

		if (!debtorListData[17].isEmpty()) {
			new Select(landPh2CC).selectByVisibleText(debtorListData[17]);
		}
		landPh2Num.clear();
		landPh2Num.sendKeys(debtorListData[18]);

		if (!debtorListData[19].isEmpty()) {
			new Select(faxCC).selectByVisibleText(debtorListData[19]);
		}
		faxNum.clear();
		faxNum.sendKeys(debtorListData[20]);

	}

	public String getSelectedCountry() {
		return new Select(country).getFirstSelectedOption().getText();

	}

	public WebElement getDbtrGenlDetailsSec() {
		return dbtrGenlDetailsSec;
	}

	public WebElement getAddressLine1() {
		return addressLine1;
	}

	public WebElement getAddressLine2() {
		return addressLine2;
	}

	public WebElement getCountry() {
		return country;
	}

	public WebElement getDistrict() {
		return district;
	}

	public WebElement getCityLocality() {
		return cityLocality;
	}

	public WebElement getPostCode() {
		return postCode;
	}

	public WebElement getPostExt() {
		return postExt;
	}

	public WebElement getPostBoxNum() {
		return postBoxNum;
	}

	public WebElement getLandPh1CC() {
		return landPh1CC;
	}

	public WebElement getLandPh1Num() {
		return landPh1Num;
	}

	public WebElement getLandPh2CC() {
		return landPh2CC;
	}

	public WebElement getLandPh2Num() {
		return landPh2Num;
	}

	public WebElement getFaxCC() {
		return faxCC;
	}

	public WebElement getFaxNum() {
		return faxNum;
	}

}
