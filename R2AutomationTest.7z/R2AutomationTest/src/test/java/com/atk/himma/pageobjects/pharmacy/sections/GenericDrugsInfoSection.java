package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class GenericDrugsInfoSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Generic Drugs Composition";
	public final static String ADDROW_XPATH = "//div[@id='GEN_DRUG_INFORMATION_SECTION']//input[@VALUE='Add Row']";

	// Grid Elements(Drug Interactions )
	public final String GRID_ID = "DRUG_INTERACTION_GRID";
	public final static String GRID_DRUGCODE_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_interactionLevel";
	public final static String GRID_DRUGINTERACTSWITH_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_interactionLevelName";
	public final static String GRID_SEVERITY_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_interactionLevel";
	public final static String GRID_ONSETREACTION_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_onsetReaction";
	public final static String GRID_INTERMECH_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_interactionMechanism";
	public final static String GRID_CLINICALMECH_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_clinicalMechanism";
	public final static String GRID_ADVERSEEFFECT_ARIA_DESCRIBEDBY = "DRUG_INTERACTION_GRID_adverseEffect";

	// Grid Data Elements(Drug Interactions )
	public final static String INTERACTIONTYPE_XPATH = "//table[@id='DRUG_INTERACTION_GRID']//select[@name='interactionLevel']";
	public final static String DRAGINTERACTPOPUP_ID = "gridSearchLookup";
	public final static String SEVERITY_XPATH = "//table[@id='DRUG_INTERACTION_GRID']//select[@name='severity']";
	public final static String ONSETREACTION_XPATH = "//table[@id='DRUG_INTERACTION_GRID']//select[@name='onsetReaction']";
	public final static String PROBABLEINTERMECH_XPATH = "//table[@id='DRUG_INTERACTION_GRID']//select[@name='interactionMechanism']";
	public final static String CLINICALMECHANISM_XPATH = "//table[@id='DRUG_INTERACTION_GRID']//select[@name='clinicalMechanism']";
	public final static String ADVERSEEFFECTS_XPATH = "//table[@id='DRUG_INTERACTION_GRID']//select[@name='adverseEffect']";

	// Pop up(For Drug to Drug)
	public final static String POPUPDIV_ID = "DrugtoDrug";
	public final static String QUICKSEARCHTXT_ID = "GENERIC_DRUG_QUICK_SEARCH_LOOKUP";
	public final static String SEARCHBUTTON_CSS = "#GENERIC_DRUG_QUICK_SEARCH_LOOKUP ~ input[value=Search]";
	public final static String RESETBUTTON_CSS = "#GENERIC_DRUG_QUICK_SEARCH_LOOKUP ~ input[value=Reset]";
	public final static String ADVSEARCHBUTTON_ID = "GENERIC_DRUG_ADV_SEARCH_LOOKUP";
	public final static String SUBMITBUTTON_ID = "GENERIC_DRUG_ADV_SEARCH_LOOKUP";
	public final static String CANCELBUTTON_CSS = "#GENERIC_DRUG_ADV_SEARCH_LOOKUP ~ input[value=Cancel]";

	// Grid(For Drug to Drug)
	public final static String POPUPGRID_ID = "SEARCH_GENERIC_DRUG_LIST_LOOKUP";
	public final static String POPUPGRID_GENERDRUGCODE_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_LOOKUP_genericDrugCode";
	public final static String POPUPGRID_DRUGNAME_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_LOOKUP_drugName";
	public final static String POPUPGRID_GENDRUGSHORTNM_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_LOOKUP_shortName";
	public final static String POPUPGRID_ANATOMMAINGRPIDTXT_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_LOOKUP_anatomicalMainGroupIdText";
	public final static String POPUPGRID_PHARMSUBGRPIDTXT_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_LOOKUP_pharmacologicalSubGroupIdText";
	public final static String POPUPGRID_CHECKBOX_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_LIST_LOOKUP_cb";

	// Grid Elements(Adverse Drug Reactions)
	public final String GRIDADR_ID = "ADVERSE_DRUG_REACTION_GRID";
	public final static String GRIDADR_ADRREPORTTYPE_ARIA_DESCRIBEDBY = "ADVERSE_DRUG_REACTION_GRID_adrReportTypeText";
	public final static String GRIDADR_ADRDESCRIPTION_ARIA_DESCRIBEDBY = "ADVERSE_DRUG_REACTION_GRID_adrDescription";
	public final static String GRIDADR_QUICKREF_ARIA_DESCRIBEDBY = "ADVERSE_DRUG_REACTION_GRID_quickReferences";
	
	public final static String GRIDADR_ADDBUTTON_XPATH = "//td[@id='ADVERSE_DRUG_REACTION_GRID_pager_left']//span";

//	Pop Up(Add Record - Adverse Drug Reaction (ADR))
	public final String KNOWNADR_ID = "ADR_REPORT_TYPEK";
	public final String HOSREPORTADR_ID = "ADR_REPORT_TYPEH";
	public final String ADRDESCRIPTION_ID = "ADR_DESCRIPTION";
	public final String QUICKREFERENCE_ID = "QUICK_REFERENCE";
	public final String SUBMITBUTTONADR_XPATH = "//form[@id='ADVERSE_DRUG_REACTION_LOOKUP']//input[@value='Submit']";
	public final String CANCELBUTTONADR_XPATH = "//form[@id='ADVERSE_DRUG_REACTION_LOOKUP']//input[@value='Cancel']";
	
	@FindBy(xpath = GRIDADR_ADDBUTTON_XPATH	)
	private WebElement addButtonADR;
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT	)
	private WebElement sectionName;
	
	@FindBy(xpath = ADDROW_XPATH)
	private WebElement addRow;
	
	@FindBy(xpath = INTERACTIONTYPE_XPATH)
	private WebElement interactionType;
	
	@FindBy(id = DRAGINTERACTPOPUP_ID)
	private WebElement dragInteracts;
	
	@FindBy(xpath = SEVERITY_XPATH)
	private WebElement severity;
	
	@FindBy(xpath = ONSETREACTION_XPATH)
	private WebElement onSetReaction;
	
	@FindBy(xpath = PROBABLEINTERMECH_XPATH)
	private WebElement probableInterMech;
	
	@FindBy(xpath = CLINICALMECHANISM_XPATH)
	private WebElement clinicalMechanism;
	
	@FindBy(xpath = ADVERSEEFFECTS_XPATH)
	private WebElement adverseEffects;
	
	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;
	
	@FindBy(css = SEARCHBUTTON_CSS)
	private WebElement searchButton;
	
	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;
	
	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(id = SUBMITBUTTON_ID)
	private WebElement submitButton;
	
	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButton;
	
	@FindBy(id = KNOWNADR_ID)
	private WebElement knownADRRadButton;
	
	@FindBy(id = HOSREPORTADR_ID)
	private WebElement hosReportADRRadButton;
	
	@FindBy(id = ADRDESCRIPTION_ID)
	private WebElement adrDescription;
	
	@FindBy(id = QUICKREFERENCE_ID)
	private WebElement quickReference;
	
	@FindBy(id = SUBMITBUTTONADR_XPATH)
	private WebElement submitButtonADR;
	
	@FindBy(id = CANCELBUTTONADR_XPATH)
	private WebElement cancelButtonADR;
	
	public void selectGenericDrug() {
		waitForElementId(POPUPGRID_ID);
		webDriver.findElement(
				By.xpath("table[@id='" + POPUPGRID_ID
						+ "']//td[@aria-describedby='"
						+ POPUPGRID_DRUGNAME_ARIA_DESCRIBEDBY
						+ "']/..//td[@aria-describedby='"
						+ POPUPGRID_CHECKBOX_ARIA_DESCRIBEDBY + "']/input"))
				.click();
	}

	/**
	 * @return the addButtonADR
	 */
	public WebElement getAddButtonADR() {
		return addButtonADR;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addRow
	 */
	public WebElement getAddRow() {
		return addRow;
	}

	/**
	 * @return the interactionType
	 */
	public WebElement getInteractionType() {
		return interactionType;
	}

	/**
	 * @return the dragInteracts
	 */
	public WebElement getDragInteracts() {
		return dragInteracts;
	}

	/**
	 * @return the severity
	 */
	public WebElement getSeverity() {
		return severity;
	}

	/**
	 * @return the onSetReaction
	 */
	public WebElement getOnSetReaction() {
		return onSetReaction;
	}

	/**
	 * @return the probableInterMech
	 */
	public WebElement getProbableInterMech() {
		return probableInterMech;
	}

	/**
	 * @return the clinicalMechanism
	 */
	public WebElement getClinicalMechanism() {
		return clinicalMechanism;
	}

	/**
	 * @return the adverseEffects
	 */
	public WebElement getAdverseEffects() {
		return adverseEffects;
	}

	/**
	 * @return the quickSearchTxt
	 */
	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the knownADRRadButton
	 */
	public WebElement getKnownADRRadButton() {
		return knownADRRadButton;
	}

	/**
	 * @return the hosReportADRRadButton
	 */
	public WebElement getHosReportADRRadButton() {
		return hosReportADRRadButton;
	}

	/**
	 * @return the adrDescription
	 */
	public WebElement getAdrDescription() {
		return adrDescription;
	}

	/**
	 * @return the quickReference
	 */
	public WebElement getQuickReference() {
		return quickReference;
	}

	/**
	 * @return the submitButtonADR
	 */
	public WebElement getSubmitButtonADR() {
		return submitButtonADR;
	}

	/**
	 * @return the cancelButtonADR
	 */
	public WebElement getCancelButtonADR() {
		return cancelButtonADR;
	}

}
