package com.atk.himma.pageobjects.mbuadmin.sections.servicedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AdministrativeParameters extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Administrative Parameters";
	public final static String LIMITEDPERSER_ID = "LIMITED_PERIOD_SERVICE";
	public final static String STARTDATE_ID = "START_DATE";
	public final static String ENDDATE_ID = "END_DATE";
	public final static String ALLOWMULTIPLE_ID = "ALLOW_MULTIPLE";
	public final static String FOREXTPAT_ID = "FOR_EXTERNAL_PATIENT";
	public final static String REQDOCORDER_ID = "REQ_DOCTOR_ORDER";
	public final static String APPOINTABLESER_ID= "APPOINTABLE_SERVICE";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Administrative Parameters')]/..";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = LIMITEDPERSER_ID)
	private WebElement limitedPeriodService;
	
	@FindBy(id = STARTDATE_ID)
	private WebElement startDate;
	
	@FindBy(id = ENDDATE_ID)
	private WebElement endDate;
	
	@FindBy(id = ALLOWMULTIPLE_ID)
	private WebElement allowMultiple;
	
	@FindBy(id = FOREXTPAT_ID)
	private WebElement forExternalPatient;
	
	@FindBy(id = REQDOCORDER_ID)
	private WebElement reqDocOrder;
	
	@FindBy(id = APPOINTABLESER_ID)
	private WebElement appointableService;

	public boolean checkAdminisParamSection() throws InterruptedException {
		waitForElementLinkText(AdministrativeParameters.SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatas(String[] sectionDatas)
			throws InterruptedException {
		waitForElementLinkText(AdministrativeParameters.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
		getSectionName().click();
		waitForElementId(LIMITEDPERSER_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(sectionDatas[32].trim(), limitedPeriodService);
		if(limitedPeriodService.isSelected())
		{
			startDate.clear();
			startDate.sendKeys(sectionDatas[33].trim());
			endDate.clear();
			endDate.sendKeys(sectionDatas[34].trim());
		}
		selectOrUnSelectCheckBox(sectionDatas[35].trim(), allowMultiple);
		selectOrUnSelectCheckBox(sectionDatas[36].trim(), forExternalPatient);
		selectOrUnSelectCheckBox(sectionDatas[37].trim(), reqDocOrder);
//		selectOrUnSelectCheckBox(sectionDatas[38].trim(), appointableService);
		return reqDocOrder.isSelected() == Boolean.valueOf(sectionDatas[37].trim());
	}
	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the limitedPeriodService
	 */
	public WebElement getLimitedPeriodService() {
		return limitedPeriodService;
	}

	/**
	 * @return the startDate
	 */
	public WebElement getStartDate() {
		return startDate;
	}

	/**
	 * @return the endDate
	 */
	public WebElement getEndDate() {
		return endDate;
	}

	/**
	 * @return the allowMultiple
	 */
	public WebElement getAllowMultiple() {
		return allowMultiple;
	}

	/**
	 * @return the forExternalPatient
	 */
	public WebElement getForExternalPatient() {
		return forExternalPatient;
	}

	/**
	 * @return the reqDocOrder
	 */
	public WebElement getReqDocOrder() {
		return reqDocOrder;
	}

	/**
	 * @return the appointableService
	 */
	public WebElement getAppointableService() {
		return appointableService;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}
	
}
