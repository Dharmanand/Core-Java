package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ExclusionListTab extends DriverWaitClass {
	public final static String EXCLUSIONLISTFORM_ID = "SEARCH_EXCLUSION_LIST";
	public final static String ADDNEWEXCLLISTBTN_ID = "ADD_NEW_EXCLUSION_BTN";
	public final static String MBULIST_ID = "S_MBU_NAME";
	public final static String GLOBALEXCLCHKBOX_ID = "EXCLN_GLOBAL_CHBOX";
	public final static String STATUS_ID = "STATUS";
	public final static String SEARCHEXCLLISTBTN_ID = "SEARCH";
	public final static String RESETEXCLLISTBTN_ID = "EXC_RESET";
	public final static String EXCLUSIONLISTGRIDDIV_ID = "SEARCH_EXCLUSION_LIST_GRID";
	public final static String VIEWLINK_XPATH = ".//table[@id='GRID_PAT']/..//a[text()='View']";
	public final static String EDITLINK_XPATH = ".//table[@id='GRID_PAT']/..//a[text()='Edit']";
	public final static String DELETELINK_XPATH = ".//table[@id='GRID_PAT']/..//a[text()='Delete']";

	@FindBy(id = EXCLUSIONLISTFORM_ID)
	private WebElement exclListForm;

	@FindBy(id = ADDNEWEXCLLISTBTN_ID)
	private WebElement addNewExclBtn;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALEXCLCHKBOX_ID)
	private WebElement globalExclChkBox;

	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(id = SEARCHEXCLLISTBTN_ID)
	private WebElement searchExclBtn;

	@FindBy(id = RESETEXCLLISTBTN_ID)
	private WebElement resetExclBtn;

	@FindBy(id = EXCLUSIONLISTGRIDDIV_ID)
	private WebElement exclListGridDiv;

	@FindBy(xpath = VIEWLINK_XPATH)
	private WebElement viewLink;

	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public void clickAddNewExcList() throws Exception {
		addNewExclBtn.click();
		sleepShort();

	}

	public void searchExcList(String[] mbuExclusionData) throws Exception {
		if (!mbuExclusionData[2].isEmpty()) {
			new Select(mbuList).selectByVisibleText(mbuExclusionData[2]);
		}

		if (!mbuExclusionData[4].isEmpty()) {
			new Select(status).selectByVisibleText(mbuExclusionData[4]);
		}
		searchExclBtn.click();
		sleepShort();
		waitForElementId(EXCLUSIONLISTGRIDDIV_ID);
	}
	
	public void clickEditLink(String[] excListData) throws Exception {
		clickOnGridAction("GRID_PAT_listName", excListData[1], "Edit");
		sleepShort();
		
	}

	public WebElement getExclListForm() {
		return exclListForm;
	}

	public WebElement getAddNewExclBtn() {
		return addNewExclBtn;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalExclChkBox() {
		return globalExclChkBox;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getSearchExclBtn() {
		return searchExclBtn;
	}

	public WebElement getResetExclBtn() {
		return resetExclBtn;
	}

	public WebElement getExclListGridDiv() {
		return exclListGridDiv;
	}

	public WebElement getViewLink() {
		return viewLink;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
