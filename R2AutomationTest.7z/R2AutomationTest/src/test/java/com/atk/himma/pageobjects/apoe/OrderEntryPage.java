package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;

public class OrderEntryPage extends DriverWaitClass implements StatusMessages {
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String NEWORDERTAB_XPATH = ".//a[@href='#new_order_div']";
	@FindBy(xpath = NEWORDERTAB_XPATH)
	private WebElement newOrderTab;

	public final static String EXISTINGORDERTAB_XPATH = ".//a[@href='#Existing_Order']";
	@FindBy(xpath = EXISTINGORDERTAB_XPATH)
	private WebElement existingOrderTab;

	public boolean checkNewOrderTab() {
		return newOrderTab.isDisplayed();
	}

	public boolean checkExistingOrderTab() {
		return existingOrderTab.isDisplayed();
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getNewOrderTab() {
		return newOrderTab;
	}

	public WebElement getExistingOrderTab() {
		return existingOrderTab;
	}

}
