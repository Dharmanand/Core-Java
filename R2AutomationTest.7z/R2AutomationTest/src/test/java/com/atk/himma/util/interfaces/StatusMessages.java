package com.atk.himma.util.interfaces;

public interface StatusMessages {
	static final String MSGHIDELNK_ID = "hidemessage";
	static final String MSGENABLE_XPATH = "//div[@id='StatusMessage']//label";
	static final String ACTIVATEMSG_XPATH = "//label[text()='Record activated successfully.']";
	static final String MSGDIALOG_YES_ID = "MSG_DIALOG_YES";
	static final String MSGDIALOG_NO_ID = "MSG_DIALOG_NO";
//	static String STATUSMSGENABLE_1XPATH = "//div[@id='StatusMessage' and @style='']";
//	static String STATUSMSGENABLE_XPATH = "//div[@id='StatusMessage' and @style='display: block;']";
}
	