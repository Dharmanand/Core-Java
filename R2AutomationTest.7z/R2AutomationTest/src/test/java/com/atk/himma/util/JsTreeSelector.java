package com.atk.himma.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JsTreeSelector {

	private WebDriver webDriver;
	private WebDriverWait webDriverWait;

	public JsTreeSelector(WebDriver webDriver, WebDriverWait webDriverWait) {
		this.webDriver = webDriver;
		this.webDriverWait = webDriverWait;
	}

	public void expandTree(String treeId) throws Exception {
		if (treeId == null || treeId.isEmpty()) {
			throw new Exception(
					"Provide value for mandatory param. Provided value is : treeId->"
							+ treeId);
		}
		// threadHelper.sleepShort();
		List<WebElement> closedOus = webDriver
				.findElement(By.id(treeId))
				.findElements(
						By.xpath(".//li[contains(@class,'jstree-closed')]/ins[@class='jstree-icon']"));
		for (WebElement closedOu : closedOus) {
			// threadHelper.sleepVeryShort();
			closedOu.click();
		}
	}

	public void selectTreeNode(String treeId, String node, String parent)
			throws Exception {
		if (treeId == null || treeId.isEmpty() || node == null
				|| node.isEmpty()) {
			throw new Exception(
					"Provide values for mandatory params. Provided values are : treeId->"
							+ treeId + ";node->" + node);
		}
		if (parent.isEmpty()) {
			webDriver
					.findElement(By.id(treeId))
					.findElement(
							By.xpath(".//a[starts-with(text(),'" + node + "')]"))
					.click();
		} else {
			webDriver
					.findElement(By.id(treeId))
					.findElement(
							By.xpath(".//a[starts-with(text(),'" + parent
									+ "')]/..//a[starts-with(text(), '" + node
									+ "')]")).click();
		}
	}

}
