package com.atk.himma.pageobjects.apoe.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class NewOrderTab extends DriverWaitClass {
	public final static String SAVEDRAFTBTNTOP_ID = "SAVE_BUTTON";
	@FindBy(id = SAVEDRAFTBTNTOP_ID)
	private WebElement saveDraftBtnTop;

	public final static String SUBMITORDERBTNTOP_ID = "SUBMIT_BUTTON_TOP";
	@FindBy(id = SUBMITORDERBTNTOP_ID)
	private WebElement submitOrderBtnTop;

	public final static String DISCARDBTNTOP_ID = "DISCARD_BUTTON";
	@FindBy(id = DISCARDBTNTOP_ID)
	private WebElement discardBtnTop;

	public final static String SAVEDRAFTBTNBTM_ID = "BOTTOM_SAVE_BUTTON";
	@FindBy(id = SAVEDRAFTBTNBTM_ID)
	private WebElement saveDraftBtnBottom;

	public final static String SUBMITORDERBTNBTM_ID = "SUBMIT_BUTTON_LOWER";
	@FindBy(id = SUBMITORDERBTNBTM_ID)
	private WebElement submitOrderBtnBottom;

	public final static String DISCARDBTNBTM_ID = "DISCARD_BUTTON_BOTTOM";
	@FindBy(id = DISCARDBTNBTM_ID)
	private WebElement discardBtnBottom;

	public WebElement getSaveDraftBtnTop() {
		return saveDraftBtnTop;
	}

	public WebElement getSubmitOrderBtnTop() {
		return submitOrderBtnTop;
	}

	public WebElement getDiscardBtnTop() {
		return discardBtnTop;
	}

	public WebElement getSaveDraftBtnBottom() {
		return saveDraftBtnBottom;
	}

	public WebElement getSubmitOrderBtnBottom() {
		return submitOrderBtnBottom;
	}

	public WebElement getDiscardBtnBottom() {
		return discardBtnBottom;
	}

}
