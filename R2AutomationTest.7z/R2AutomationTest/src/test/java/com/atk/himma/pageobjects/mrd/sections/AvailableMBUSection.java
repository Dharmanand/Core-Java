package com.atk.himma.pageobjects.mrd.sections;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class AvailableMBUSection extends DriverWaitClass implements
		StatusMessages, RecordStatus {
	public static final String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Update']";
}
