package com.atk.himma.pageobjects.contracts.sections.policydetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PolicyGeneralParametersSection extends DriverWaitClass {
	public static final String POLGENPARAMSEC_LINKTEXT = "Policy General Parameters";
	public final static String VISITCOVERAGECHKBOX_ID = "Visit_Coverage";
	public final static String VISITCOV_ADDRECORDPLUSBTN_XPATH = "//div[@id='POLICY_VISIT_COVERAGE_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String VISITCOVPOPUPFORM_ID = "VISIT_COVERAGE_ADD_NEW_POPUP";
	public final static String VISITCATEGORY_ID = "VISIT_CAT_ID";
	public final static String PREAUTHCHKBOX_ID = "PRE_AUTHORIZATION_REQUIRED";
	public final static String NOTES_NAME = "notes";
	public final static String SUBMITBTN_XPATH = "//form[@id='VISIT_COVERAGE_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String CANCELBTN_XPATH = "//form[@id='VISIT_COVERAGE_ADD_NEW_POPUP']//input[@value='Cancel']";
	public final static String VISITCOVGRIDDIV_ID = "VISIT_COVERAGE_GRID_DIV";

	public final static String AGECOVLIMITCHKBOX_ID = "AGE_COVERAGE_LIMIT";
	public final static String AGECOVFROMVAL_ID = "AGE_COV_FROM";
	public final static String AGECOVFROMLIMIT_ID = "AGE_COV_LIMIT_DROPDOWN_FROM";
	public final static String AGECOVTOVAL_ID = "AGE_COV_TO";
	public final static String AGECOVTOLIMIT_ID = "AGE_COV_LIMIT_DROPDOWN_TO";

	public final static String POLICYCDTLIMITCHKBOX_ID = "POLICY_CREDIT_LIMIT";
	public final static String GENERAL_ID = "RADIO_BUTTONG";
	public final static String VISITSPECIFIC_ID = "RADIO_BUTTONV";
	public final static String GAMOUNTVAL_ID = "GEN_AMOUNT";
	public final static String GAMOUNTTYPE_ID = "TOTAL_AMOUNT_DROPDOWN";
	public final static String SERVLIMITINCLCHKBOX_NAME = "multiselect_LIMIT_INCLUSION_GENERAL";
	public final static String ITEMLIMITINCLCHKBOX_NAME = "multiselect_LIMIT_INCLUSION_GENERAL_ITEM";
	public final static String VISITSPEC_ADDRECORDPLUSBTN_XPATH = "//div[@id='VISIT_SPECIFIC_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String VISITSPECPOPUPFORM_ID = "VISIT_SPECIFIC_ADD_NEW_POPUP";
	public final static String VISITCATEGORY_VISITSPEC_ID = "VISIT_CAT_ID_SPECIFIC";
	public final static String AMOUNT_VISITSPEC_ID = "AMOUNT_VISIT_SPC";
	public final static String AMOUNTTYPE_VISITSPEC_ID = "TOTAL_AMOUNT_DROPDOWN_VISIT_SPC";
	public final static String SERVLIMITINCL_VISITSPEC_NAME = "multiselect_LIMITINCLUSION_VISIT_SPC";
	public final static String ITEMLIMITINCL_VISITSPEC_NAME = "multiselect_LIMITINCLUSION_VISIT_SPC_ITEM";
	public final static String SUBMITBTN_VISITSPEC_XPATH = "//form[@id='VISIT_SPECIFIC_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String CANCELBTN_VISITSPEC_XPATH = "//form[@id='VISIT_SPECIFIC_ADD_NEW_POPUP']//input[@value='Cancel']";

	public final static String VISITSPECGRIDDIV_ID = "VISIT_SPECIFIC_GRID_DIV";
	public final static String CDTLIMITDURCHKBOX_ID = "CREDIT_LIMIT_DURATION";
	public final static String CDTLIMITDURAGRMNT_ID = "RADIO_BUTTON_CREDIT_LIMIT_DURagreement";
	public final static String CDTLIMITDURPOL_ID = "RADIO_BUTTON_CREDIT_LIMIT_DURpolicy";
	public final static String CDTLIMITDUROTHERS_ID = "RADIO_BUTTON_CREDIT_LIMIT_DURothers";
	public final static String CDTSTARTDATE_ID = "datepicker_credit_start_dur";
	public final static String CDTENDDATE_ID = "datepicker_credit_end_dur";
	public final static String APPLYPARAMTOCHKBOX_ID = "APPLY_THE_ABOVE_POLICY_GENERAL_PARAMETERS_TO";
	public final static String ALLCLASSES_ID = "FIRST_RADIO";
	public final static String SELCLASSES_ID = "SECOND_RADIO";
	public final static String SELCLASSESVAL_NAME = "multiselect_POLICY_APPL_TO_SEL_CLASS";

	public final static String APPLYEXCLISTTOCHKBOX_ID = "Apply_the_Above_Exclusion_List_To";
	public final static String EXASSOCTCLASSES_ID = "EX_POLICY_MODE1";
	public final static String EXSELECTEDCLASSES_ID = "EX_POLICY_MODE2";
	public final static String EXSELCLASSESVAL_NAME = "multiselect_POLICY_APPL_TO_CLASSES_EX";
	public final static String APPLYAPPLLISTTOCHKBOX_ID = "Apply_the_Above_Approval_List_To";
	public final static String APPASSOCTCLASSES_ID = "APP_POLICY_MODE1";
	public final static String APPSELECTEDCLASSES_ID = "APP_POLICY_MODE2";
	public final static String APPSELCLASSESVAL_NAME = "multiselect_POLICY_APPL_TO_CLASSES_APP";

	private final static String GENERAL = "General",
			VISIT_SPEC = "Visit Specific", OTH = "Others";

	@FindBy(linkText = POLGENPARAMSEC_LINKTEXT)
	private WebElement polGenParamSec;

	@FindBy(id = VISITCOVERAGECHKBOX_ID)
	private WebElement visitCovChkBox;

	@FindBy(xpath = VISITCOV_ADDRECORDPLUSBTN_XPATH)
	private WebElement visitCov_addRecPlusBtn;

	@FindBy(id = VISITCOVPOPUPFORM_ID)
	private WebElement visitCovPopupForm;

	@FindBy(id = VISITCATEGORY_ID)
	private WebElement visitCategory;

	@FindBy(id = PREAUTHCHKBOX_ID)
	private WebElement preAuthRequiredChkBox;

	@FindBy(name = NOTES_NAME)
	private WebElement notes;

	@FindBy(xpath = SUBMITBTN_XPATH)
	private WebElement submitVisitCovPopup;

	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancleVisitCovPopup;

	@FindBy(id = VISITCOVGRIDDIV_ID)
	private WebElement visitCovGridDiv;

	@FindBy(id = AGECOVLIMITCHKBOX_ID)
	private WebElement ageCovLimitChkBox;

	@FindBy(id = AGECOVFROMVAL_ID)
	private WebElement ageCovFromVal;

	@FindBy(id = AGECOVFROMLIMIT_ID)
	private WebElement ageCovFromLimit;

	@FindBy(id = AGECOVTOVAL_ID)
	private WebElement ageCovToVal;

	@FindBy(id = AGECOVTOLIMIT_ID)
	private WebElement ageCovToLimit;

	@FindBy(id = POLICYCDTLIMITCHKBOX_ID)
	private WebElement policyCdtLimitChkBox;

	@FindBy(id = GENERAL_ID)
	private WebElement general;

	@FindBy(id = VISITSPECIFIC_ID)
	private WebElement visitSpec;

	@FindBy(id = GAMOUNTVAL_ID)
	private WebElement generalAmountVal;

	@FindBy(id = GAMOUNTTYPE_ID)
	private WebElement generalAmountType;

	@FindBy(name = SERVLIMITINCLCHKBOX_NAME)
	private WebElement servLimitInclChkBox;

	@FindBy(name = ITEMLIMITINCLCHKBOX_NAME)
	private WebElement itemLimitInclChkBox;

	@FindBy(xpath = VISITSPEC_ADDRECORDPLUSBTN_XPATH)
	private WebElement visitSpec_addRecPlusBtn;

	@FindBy(id = VISITSPECPOPUPFORM_ID)
	private WebElement visitSpecPopupForm;

	@FindBy(id = VISITCATEGORY_VISITSPEC_ID)
	private WebElement visitSpecVisitCateg;

	@FindBy(id = AMOUNT_VISITSPEC_ID)
	private WebElement visitSpecAmount;

	@FindBy(id = AMOUNTTYPE_VISITSPEC_ID)
	private WebElement visitSpecAmountType;

	@FindBy(name = SERVLIMITINCL_VISITSPEC_NAME)
	private WebElement visitSpecServLimitIncl;

	@FindBy(name = ITEMLIMITINCL_VISITSPEC_NAME)
	private WebElement visitSpecItemLimitIncl;

	@FindBy(xpath = SUBMITBTN_VISITSPEC_XPATH)
	private WebElement submitVisitSpecPopup;

	@FindBy(xpath = CANCELBTN_VISITSPEC_XPATH)
	private WebElement cancelVisitSpecPopup;

	@FindBy(id = VISITSPECGRIDDIV_ID)
	private WebElement visitSpecGridDiv;

	@FindBy(id = CDTLIMITDURCHKBOX_ID)
	private WebElement cdtLimitDurChkBox;

	@FindBy(id = CDTLIMITDURAGRMNT_ID)
	private WebElement cdtLimitDurAgrmnt;

	@FindBy(id = CDTLIMITDURPOL_ID)
	private WebElement cdtLimitDurPolicy;

	@FindBy(id = CDTLIMITDUROTHERS_ID)
	private WebElement cdtLimitDurOthers;

	@FindBy(id = CDTSTARTDATE_ID)
	private WebElement cdtStartDate;

	@FindBy(id = CDTENDDATE_ID)
	private WebElement cdtEndDate;

	@FindBy(id = APPLYPARAMTOCHKBOX_ID)
	private WebElement applyPolParametersToChkBox;

	@FindBy(id = ALLCLASSES_ID)
	private WebElement allAssociatedClasses;

	@FindBy(id = SELCLASSES_ID)
	private WebElement selectedClasses;

	@FindBy(name = SELCLASSESVAL_NAME)
	private WebElement selectedClassesVal;

	@FindBy(id = APPLYEXCLISTTOCHKBOX_ID)
	private WebElement applyExListToChkBox;

	@FindBy(id = EXASSOCTCLASSES_ID)
	private WebElement exAssoctAllClasses;

	@FindBy(id = EXSELECTEDCLASSES_ID)
	private WebElement exSelectedClasses;

	@FindBy(name = EXSELCLASSESVAL_NAME)
	private WebElement exSelectedClassesVal;

	@FindBy(id = APPLYAPPLLISTTOCHKBOX_ID)
	private WebElement applyAppListToChkBox;

	@FindBy(id = APPASSOCTCLASSES_ID)
	private WebElement appAssoctAllClasses;

	@FindBy(id = APPSELECTEDCLASSES_ID)
	private WebElement appSelectedClasses;

	@FindBy(id = APPSELCLASSESVAL_NAME)
	private WebElement appSelectedClassesVal;

	public void addPolicyGeneralParamData(String[] policyListData)
			throws Exception {
		if (Boolean.valueOf(policyListData[15])) {
			visitCovChkBox.click();
			sleepVeryShort();
			waitForElementId(VISITCOVGRIDDIV_ID);
			visitCov_addRecPlusBtn.click();
			waitForElementId(VISITCOVPOPUPFORM_ID);
			if (!policyListData[16].isEmpty()) {
				new Select(visitCategory)
						.selectByVisibleText(policyListData[16]);
			}
			if (Boolean.valueOf(policyListData[17])) {
				preAuthRequiredChkBox.click();
			}
			notes.clear();
			notes.sendKeys(policyListData[18]);
			submitVisitCovPopup.click();

		}
		if (Boolean.valueOf(policyListData[19])) {
			ageCovLimitChkBox.click();
			ageCovFromVal.clear();
			ageCovFromVal.sendKeys(policyListData[20]);
			if (!policyListData[21].isEmpty()) {
				new Select(ageCovFromLimit)
						.selectByVisibleText(policyListData[21]);
			}
			ageCovToVal.clear();
			ageCovToVal.sendKeys(policyListData[22]);

			if (!policyListData[23].isEmpty()) {
				new Select(ageCovToLimit)
						.selectByVisibleText(policyListData[23]);
			}

		}
		if (Boolean.valueOf(policyListData[24])) {
			policyCdtLimitChkBox.click();
			selectRadioButtonAsLabelText(policyListData[25]);
			if (GENERAL.equals(policyListData[25])) {
				generalAmountVal.clear();
				generalAmountVal.sendKeys(policyListData[26]);
				if (!policyListData[27].isEmpty()) {
					new Select(generalAmountType)
							.selectByVisibleText(policyListData[27]);
				}
				String[] temp;
				String delimiter = "\\,";
				temp = policyListData[28].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMIT_INCLUSION_GENERAL", temp[i]);
				}

				temp = policyListData[29].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMIT_INCLUSION_GENERAL_ITEM", temp[i]);
				}

			} else if (VISIT_SPEC.equals(policyListData[25])) {
				waitForElementId(VISITSPECGRIDDIV_ID);
				visitSpec_addRecPlusBtn.click();
				sleepVeryShort();
				waitForElementId(VISITSPECPOPUPFORM_ID);
				if (!policyListData[30].isEmpty()) {
					new Select(visitSpecVisitCateg)
							.selectByVisibleText(policyListData[30]);
				}
				visitSpecAmount.clear();
				visitSpecAmount.sendKeys(policyListData[31]);
				if (!policyListData[32].isEmpty()) {
					new Select(visitSpecAmountType)
							.selectByVisibleText(policyListData[32]);
				}
				String[] temp;
				String delimiter = "\\,";
				temp = policyListData[33].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMITINCLUSION_VISIT_SPC", temp[i]);
				}

				temp = policyListData[34].split(delimiter);
				for (int i = 0; i < temp.length; i++) {
					selectValueOfMultiselect(
							"multiselect_LIMITINCLUSION_VISIT_SPC_ITEM",
							temp[i]);
				}
				submitVisitSpecPopup.click();

			}

		}
		if (Boolean.valueOf(policyListData[35])) {
			cdtLimitDurChkBox.click();
			selectRadioButtonAsLabelText(policyListData[36]);
			if (OTH.equals(policyListData[36])) {
				cdtStartDate.clear();
				cdtStartDate.sendKeys(policyListData[37]);
				cdtEndDate.clear();
				cdtEndDate.sendKeys(policyListData[38]);
			}

		}
		if (!policyListData[39].isEmpty()) {
			applyPolParametersToChkBox.click();
			selectRadioButtonAsLabelText(policyListData[39]);
		}

	}

	public WebElement getPolGenParamSec() {
		return polGenParamSec;
	}

	public WebElement getVisitCovChkBox() {
		return visitCovChkBox;
	}

	public WebElement getVisitCov_addRecPlusBtn() {
		return visitCov_addRecPlusBtn;
	}

	public WebElement getVisitCovPopupForm() {
		return visitCovPopupForm;
	}

	public WebElement getVisitCategory() {
		return visitCategory;
	}

	public WebElement getPreAuthRequiredChkBox() {
		return preAuthRequiredChkBox;
	}

	public WebElement getNotes() {
		return notes;
	}

	public WebElement getSubmitVisitCovPopup() {
		return submitVisitCovPopup;
	}

	public WebElement getCancleVisitCovPopup() {
		return cancleVisitCovPopup;
	}

	public WebElement getVisitCovGridDiv() {
		return visitCovGridDiv;
	}

	public WebElement getAgeCovLimitChkBox() {
		return ageCovLimitChkBox;
	}

	public WebElement getAgeCovFromVal() {
		return ageCovFromVal;
	}

	public WebElement getAgeCovFromLimit() {
		return ageCovFromLimit;
	}

	public WebElement getAgeCovToVal() {
		return ageCovToVal;
	}

	public WebElement getAgeCovToLimit() {
		return ageCovToLimit;
	}

	public WebElement getPolicyCdtLimitChkBox() {
		return policyCdtLimitChkBox;
	}

	public WebElement getGeneral() {
		return general;
	}

	public WebElement getVisitSpec() {
		return visitSpec;
	}

	public WebElement getGeneralAmountVal() {
		return generalAmountVal;
	}

	public WebElement getGeneralAmountType() {
		return generalAmountType;
	}

	public WebElement getServLimitInclChkBox() {
		return servLimitInclChkBox;
	}

	public WebElement getItemLimitInclChkBox() {
		return itemLimitInclChkBox;
	}

	public WebElement getVisitSpec_addRecPlusBtn() {
		return visitSpec_addRecPlusBtn;
	}

	public WebElement getVisitSpecPopupForm() {
		return visitSpecPopupForm;
	}

	public WebElement getVisitSpecVisitCateg() {
		return visitSpecVisitCateg;
	}

	public WebElement getVisitSpecAmount() {
		return visitSpecAmount;
	}

	public WebElement getVisitSpecAmountType() {
		return visitSpecAmountType;
	}

	public WebElement getVisitSpecServLimitIncl() {
		return visitSpecServLimitIncl;
	}

	public WebElement getVisitSpecItemLimitIncl() {
		return visitSpecItemLimitIncl;
	}

	public WebElement getSubmitVisitSpecPopup() {
		return submitVisitSpecPopup;
	}

	public WebElement getCancelVisitSpecPopup() {
		return cancelVisitSpecPopup;
	}

	public WebElement getVisitSpecGridDiv() {
		return visitSpecGridDiv;
	}

	public WebElement getCdtLimitDurChkBox() {
		return cdtLimitDurChkBox;
	}

	public WebElement getCdtLimitDurAgrmnt() {
		return cdtLimitDurAgrmnt;
	}

	public WebElement getCdtLimitDurPolicy() {
		return cdtLimitDurPolicy;
	}

	public WebElement getCdtLimitDurOthers() {
		return cdtLimitDurOthers;
	}

	public WebElement getCdtStartDate() {
		return cdtStartDate;
	}

	public WebElement getCdtEndDate() {
		return cdtEndDate;
	}

	public WebElement getApplyPolParametersToChkBox() {
		return applyPolParametersToChkBox;
	}

	public WebElement getAllAssociatedClasses() {
		return allAssociatedClasses;
	}

	public WebElement getSelectedClasses() {
		return selectedClasses;
	}

	public WebElement getSelectedClassesVal() {
		return selectedClassesVal;
	}

	public WebElement getApplyExListToChkBox() {
		return applyExListToChkBox;
	}

	public WebElement getExAssoctAllClasses() {
		return exAssoctAllClasses;
	}

	public WebElement getExSelectedClasses() {
		return exSelectedClasses;
	}

	public WebElement getExSelectedClassesVal() {
		return exSelectedClassesVal;
	}

	public WebElement getApplyAppListToChkBox() {
		return applyAppListToChkBox;
	}

	public WebElement getAppAssoctAllClasses() {
		return appAssoctAllClasses;
	}

	public WebElement getAppSelectedClasses() {
		return appSelectedClasses;
	}

	public WebElement getAppSelectedClassesVal() {
		return appSelectedClassesVal;
	}

}
