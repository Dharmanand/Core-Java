package com.atk.himma.pageobjects.mbuadmin.sections.packagedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PackageInclusionDetails extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Appointment Parameters";
	
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Appointment Parameters')]/..";
	
	public final static String SERVICERADIO_ID = "PKG_DEF_PATTERN_RADIO2";
	public final static String RESOURCERADIO_ID = "PKG_DEF_PATTERN_RADIO1";
	public final static String ITEMRADIO_ID = "PKG_DEF_PATTERN_RADIO3";
	public final static String ADDBUTTON_ID = "AddRow_Excl_ItemForm_Action";
	
//	Common Grid
	
	public final static String GRIDSEARCHLOOKUP_ID = "gridSearchLookup";
	public final static String GRIDEXCLUDE_ID = "exclude";
	public final static String GRIDVISITCATEGORY_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div/div[2]/div[11]/div/form/div/div[4]/fieldset/div[3]/div/div/div[3]/div[3]/div/table/tbody/tr[2]/td[6]/button";
	public final static String TYPE_NAME = "type";
	public final static String VALUE_NAME = "value";
	
//	service
	
	public final static String GRIDIDSER_ID = "SERV_GRID";
	public final static String GRIDSERVICELEVEL_NAME = "serviceLevel";
	public final static String GRID_PAGERIDSER_ID = "sp_1_SERV_GRID_pager";
	public final static String GRID_NEXTPAGESER_XPATH = "//td[@id='next_SERV_GRID_pager']";
	
//	Resource
	
	public final static String GRIDIDRES_ID = "RESOURCE_GRID";
	public final static String GRIDRESOURCELEVEL_NAME = "resourceLevel";
	public final static String UNIT_NAME = "unit";
	public final static String GRID_PAGERIDRES_ID = "sp_1_RESOURCE_GRID_pager";
	public final static String GRID_NEXTPAGERES_XPATH = "//td[@id='next_RESOURCE_GRID_pager']";
	
//	Item

	public final static String GRIDIDITEM_ID = "ITEM_GRID";
	public final static String GRIDITEMLEVEL_NAME = "itemLevel";
	public final static String GRID_PAGERIDITEM_ID = "sp_1_ITEM_GRID_pager";
	public final static String GRID_NEXTPAGEITEM_XPATH = "//td[@id='next_ITEM_GRID_pager']";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = SERVICERADIO_ID)
	private WebElement serviceRadio;
	
	@FindBy(id = RESOURCERADIO_ID)
	private WebElement resourceRadio;
	
	@FindBy(id = ITEMRADIO_ID)
	private WebElement itemRadio;
	
	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;
	
//	Common Grid
	
	@FindBy(id = GRIDSEARCHLOOKUP_ID)
	private WebElement searchLookup;
	
	@FindBy(id = GRIDEXCLUDE_ID)
	private WebElement exclude;
	
	@FindBy(xpath = GRIDVISITCATEGORY_XPATH)
	private WebElement visitCategory;
	
	@FindBy(name = TYPE_NAME)
	private WebElement type;
	
	@FindBy(name = VALUE_NAME)
	private WebElement value;
	
//	service
	
	@FindBy(id = GRIDIDSER_ID)
	private WebElement gridIDService;
	
	@FindBy(name = GRIDSERVICELEVEL_NAME)
	private WebElement serviceLevel;
	
	@FindBy(id = GRID_PAGERIDSER_ID)
	private WebElement gridPagerIDService;
	
	@FindBy(name = GRID_NEXTPAGESER_XPATH)
	private WebElement gridNextPageService;
	
//	Resource
	
	@FindBy(id = GRIDIDRES_ID)
	private WebElement gridIDResource;
	
	@FindBy(id = GRIDRESOURCELEVEL_NAME)
	private WebElement gridResourceLevel;
	
	@FindBy(id = UNIT_NAME)
	private WebElement unit;
	
	@FindBy(id = GRID_PAGERIDRES_ID)
	private WebElement gridPagerIDResource;
	
	@FindBy(xpath = GRID_NEXTPAGERES_XPATH)
	private WebElement gridNextPageResource;
	
//	Item
	
	@FindBy(id = GRIDIDITEM_ID)
	private WebElement gridIDItem;
	
	@FindBy(id = GRIDITEMLEVEL_NAME)
	private WebElement gridItemLevel;
	
	@FindBy(id = GRID_PAGERIDITEM_ID)
	private WebElement gridPagerIDItem;
	
	@FindBy(xpath = GRID_NEXTPAGEITEM_XPATH)
	private WebElement gridNextPageItem;

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the serviceRadio
	 */
	public WebElement getServiceRadio() {
		return serviceRadio;
	}

	/**
	 * @return the resourceRadio
	 */
	public WebElement getResourceRadio() {
		return resourceRadio;
	}

	/**
	 * @return the itemRadio
	 */
	public WebElement getItemRadio() {
		return itemRadio;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the searchLookup
	 */
	public WebElement getSearchLookup() {
		return searchLookup;
	}

	/**
	 * @return the exclude
	 */
	public WebElement getExclude() {
		return exclude;
	}

	/**
	 * @return the visitCategory
	 */
	public WebElement getVisitCategory() {
		return visitCategory;
	}

	/**
	 * @return the type
	 */
	public WebElement getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	public WebElement getValue() {
		return value;
	}

	/**
	 * @return the gridIDService
	 */
	public WebElement getGridIDService() {
		return gridIDService;
	}

	/**
	 * @return the serviceLevel
	 */
	public WebElement getServiceLevel() {
		return serviceLevel;
	}

	/**
	 * @return the gridPagerIDService
	 */
	public WebElement getGridPagerIDService() {
		return gridPagerIDService;
	}

	/**
	 * @return the gridNextPageService
	 */
	public WebElement getGridNextPageService() {
		return gridNextPageService;
	}

	/**
	 * @return the gridIDResource
	 */
	public WebElement getGridIDResource() {
		return gridIDResource;
	}

	/**
	 * @return the gridResourceLevel
	 */
	public WebElement getGridResourceLevel() {
		return gridResourceLevel;
	}

	/**
	 * @return the unit
	 */
	public WebElement getUnit() {
		return unit;
	}

	/**
	 * @return the gridPagerIDResource
	 */
	public WebElement getGridPagerIDResource() {
		return gridPagerIDResource;
	}

	/**
	 * @return the gridNextPageResource
	 */
	public WebElement getGridNextPageResource() {
		return gridNextPageResource;
	}

	/**
	 * @return the gridIDItem
	 */
	public WebElement getGridIDItem() {
		return gridIDItem;
	}

	/**
	 * @return the gridItemLevel
	 */
	public WebElement getGridItemLevel() {
		return gridItemLevel;
	}

	/**
	 * @return the gridPagerIDItem
	 */
	public WebElement getGridPagerIDItem() {
		return gridPagerIDItem;
	}

	/**
	 * @return the gridNextPageItem
	 */
	public WebElement getGridNextPageItem() {
		return gridNextPageItem;
	}
	
}
