package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.AppDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.ApprovalListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class MBUApprovalListPage extends DriverWaitClass implements
		StatusMessages, RecordStatus {
	private ApprovalListTab approvalListTab;
	private AppDetailsFirstSection appDetailsFirstSection;
	private ApprovalListDetailsSection approvalListDetailsSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[contains(text(),'MBU Approval List')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String APPLISTDETAILSFORM_ID = "mbuapprovallistform";
	public final static String ADDNEWBTN_ID = "ADD_NEW_APP_UPPER_BTN";
	public final static String COPYBTN_ID = "COPY_APP_UPPER_BTN";
	public final static String SAVEBTN_ID = "SAVE_UPPER_BTN";
	public final static String CANCELBTN_ID = "APP_CANCEL_UPPER_BTN";
	public final static String UPDATEBTN_ID = "UPDATE_UPPER_BTN";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = APPLISTDETAILSFORM_ID)
	private WebElement appListDetailsForm;

	@FindBy(id = ADDNEWBTN_ID)
	private WebElement addNewBtn;

	@FindBy(id = COPYBTN_ID)
	private WebElement copyBtn;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(id = CANCELBTN_ID)
	private WebElement cancelBtn;

	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		approvalListTab = PageFactory.initElements(webDriver,
				ApprovalListTab.class);
		approvalListTab.setWebDriver(webDriver);
		approvalListTab.setWebDriverWait(webDriverWait);

		appDetailsFirstSection = PageFactory.initElements(webDriver,
				AppDetailsFirstSection.class);
		appDetailsFirstSection.setWebDriver(webDriver);
		appDetailsFirstSection.setWebDriverWait(webDriverWait);

		approvalListDetailsSection = PageFactory.initElements(webDriver,
				ApprovalListDetailsSection.class);
		approvalListDetailsSection.setWebDriver(webDriver);
		approvalListDetailsSection.setWebDriverWait(webDriverWait);
	}

	public MBUApprovalListPage clickOnMBUApprovalListMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws InterruptedException {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "MBU Approval List");
		MBUApprovalListPage mbuApprovalListPage = PageFactory.initElements(
				webDriver, MBUApprovalListPage.class);
		mbuApprovalListPage.setWebDriver(webDriver);
		mbuApprovalListPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return mbuApprovalListPage;

	}

	public void saveApprvlListDetails() throws Exception {
		saveBtn.click();
		waitForElementId(UPDATEBTN_ID);
		sleepShort();

	}

	public String activateRecord() throws Exception {
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickCopy() throws Exception {
		copyBtn.click();
		waitForElementId(UPDATEBTN_ID);
		sleepVeryShort();

	}

	public void clickAddMoreNewApprvlList() throws Exception {
		addNewBtn.click();
		doDirtyPopUpCheck();
		waitForElementId(SAVEBTN_ID);

	}

	public void clickCancel() throws Exception {
		cancelBtn.click();
		doDirtyPopUpCheck();
		waitForElementId(ApprovalListTab.APPLISTGRIDDIV_ID);
		sleepVeryShort();
	}

	public ApprovalListTab getApprovalListTab() {
		return approvalListTab;
	}

	public AppDetailsFirstSection getAppDetailsFirstSection() {
		return appDetailsFirstSection;
	}

	public ApprovalListDetailsSection getApprovalListDetailsSection() {
		return approvalListDetailsSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getAppListDetailsForm() {
		return appListDetailsForm;
	}

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getActivateRecord() {
		return activateRecord;
	}

}
