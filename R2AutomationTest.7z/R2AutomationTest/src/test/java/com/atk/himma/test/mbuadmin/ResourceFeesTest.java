package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.ResourceFeesPage;
import com.atk.himma.pageobjects.mbuadmin.tabs.ResourceFeesListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ResourceFeesTest extends SeleniumDriverSetup{
	
	List<String[]> resourceFeesDatas;
	ResourceFeesPage resourceFeesPage;

	@Test(description="Open Resource Fees")
	public void clickOnResourceFeesMenu() throws InterruptedException {
		resourceFeesPage = PageFactory.initElements(webDriver, ResourceFeesPage.class);
		resourceFeesPage = resourceFeesPage.clickOnResFeesMenu(webDriver, webDriverWait);
		resourceFeesPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		resourceFeesPage
				.waitForElementXpathExpression(ResourceFeesListTab.SEARCHBUTTON_XPATH);
		Assert.assertEquals(resourceFeesPage.getResourceFeesListTab().getResourceFeesListTab().getAttribute("title").trim(),
				"Resource Fees List", "Fail to Open Resource Fees");
	}
	
	// [Resource Fees] Open Form
	@Test(description = "Open Resource Fees Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkResourceFeesLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		resourceFeesPage = PageFactory.initElements(webDriver,
				ResourceFeesPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Resource Fees");
		resourceFeesPage.setWebDriver(webDriver);
		resourceFeesPage.setWebDriverWait(webDriverWait);
		resourceFeesPage
				.waitForElementXpathExpression(ResourceFeesPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Resource Fees")
				.get("[Resource Fees] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ResourceFeesPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Resource Fees] Open Form privilege");
		if (actualPrivilage) {
			resourceFeesPage = resourceFeesPage.clickOnResFeesMenu(webDriver,
					webDriverWait);
			resourceFeesPage.setInstanceOfAllSection(webDriver, webDriverWait);
			Assert.assertNotNull(resourceFeesPage);
			resourceFeesPage.waitForPageLoaded(webDriver);
			resourceFeesPage.waitForElementId(ResourceFeesListTab.GRID_ID);
			resourceFeesPage.sleepVeryShort();
			Assert.assertEquals(resourceFeesPage.getResourceFeesListTab()
					.getResourceFeesListTab().getAttribute("title").trim(),
					"Resource Fees List", "Fail to Open Resource Fees");
		}
	}

	@Test(description="search Resource Fees", dependsOnMethods="clickOnResourceFeesMenu")
	public void test1SearchResourceFees() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		resourceFeesDatas = excelReader.read(properties.getProperty("resourceFees"));
		for (String st[] : resourceFeesDatas.subList(0, 1))
		Assert.assertEquals(resourceFeesPage.searchResourceFees(st).trim(),
				st[5].trim(), "Fail to search Resource Fees");
	}
	
	@Test(description="Define Resource Fees", dependsOnMethods="test1SearchResourceFees")
	public void test2DefineResourceFees() throws InterruptedException, IOException {
		for (String st[] : resourceFeesDatas.subList(0, 1))
		Assert.assertEquals(resourceFeesPage.defineFees(st),
				true, "Fail to Define Resource Fees");
	}
	
	@Test(description="check Registration Configuration Section", dependsOnMethods={"test2DefineResourceFees"})
	public void test3CheckSerTariffModSec() throws InterruptedException {
		Assert.assertEquals(resourceFeesPage.getServiceTariffModifier().checkRegConfigSection(),
				true, "Fail to check Registration Configuration Section");
	}
	
	@Test(description="check Applicable MBU Section", dependsOnMethods={"test2DefineResourceFees"})
	public void test4CheckApplMBUSection() throws InterruptedException {
		Assert.assertEquals(resourceFeesPage.getApplicableMainBusinessUnits().checkApplMBUSection(),
				true, "Fail to check Applicable MBU Section");
	}
	
	@Test(description="fill Resource Fee Datas", dependsOnMethods={"test3CheckSerTariffModSec"})
	public void test5FillResFeeDatas() throws InterruptedException {
		for (String st[] : resourceFeesDatas.subList(0, 1))
			Assert.assertEquals(resourceFeesPage.getServiceTariffModifier().fillResourceFeeDatas(st),
					true, "Fail to fill Resource Fee Datas");
	}
	
	@Test(description="fill datas of Applicable MBU Section", dependsOnMethods="test4CheckApplMBUSection")
	public void test6FillAppMBUDatas() throws InterruptedException {
		for (String st[] : resourceFeesDatas.subList(0, 1))
			Assert.assertEquals(resourceFeesPage.getApplicableMainBusinessUnits().fillDatas(st),
					true, "Fail to fill datas of Applicable MBU Section");
	}
	
	@Test(description="Save Resource Fees Datas", dependsOnMethods="test6FillAppMBUDatas")
	public void  test7SaveDatas() throws InterruptedException, IOException {
			Assert.assertEquals(resourceFeesPage.saveDetailsPage().contains("Update"),
					true, "Failed to Save Resource Fees Datas");
	}
	
	@Test(description="Activate Record", dependsOnMethods="test7SaveDatas")
	public void  test8ActivateRecord() throws InterruptedException, IOException {
		Assert.assertEquals(resourceFeesPage.activateResFees().contains("Active"),
				true, "Failed Activate Record");
	}
	
	@Test(description="Fill Resource Fees Datas", dependsOnMethods="test7SaveDatas")
	public void test9EditResourceFees() throws InterruptedException, IOException {
		for (String st[] : resourceFeesDatas.subList(0, 1))
			Assert.assertEquals(resourceFeesPage.editServiceCharge(st),
					true, "Fail to Fill Resource Fees Datas");
	}
	
	@Test(dependsOnMethods = { "checkResourceFeesLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Resource Fees for Privilege")
	public void searchResFeesPrivilege() throws Exception {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		resourceFeesDatas = excelReader.read(properties.getProperty("resourceFees"));
		for (String st[] : resourceFeesDatas.subList(1, 2))
			Assert.assertEquals(
					resourceFeesPage.searchResourceFees(st),
					st[5].trim(), "Fail to Search Resource Fee");
	}
	
//	[List Tab] Define Resource fee Name (Link in the search result grid)
	@Test(dependsOnMethods = { "searchResFeesPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Define Resource fee Name (Link in the search result grid) privilage")
	public void checkDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Resource Fees")
				.get("[List Tab] Define Resource fee Name (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ resourceFeesDatas.subList(0, 1).get(0)[5].trim()
						+ "']/..//a[text()='Define Fees']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Define Resource fee Name (Link in the search result grid) privilege");
	}
	
////	@Test(dependsOnMethods = { "searchPLPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Define Resource fee Name (Link in the search result grid) privilage")
//	public void checkDeleteLinkPrivilege() {
//		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
//				.get("MBU Administration").get("Resource Fees")
//				.get("[List Tab] Define Resource fee Name (Link in the search result grid)");
//		System.out.println("privFilter----------> " + expectedPrivilage);
//		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
//				webDriver,
//				By.xpath(".//td[@title='"
//						+ resourceFeesDatas.subList(0, 1).get(0)[5].trim()
//						+ "']/..//a[text()='Define Fees']"));
//		System.out
//				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
//		Assert.assertEquals(actualPrivilage, expectedPrivilage,
//				"Fail to check [List Tab] Define Resource fee Name (Link in the search result grid) privilege");
//	}
	
//	[Details Tab] [Section: Service Tariff Modifier] Add (Button)
	
//	[Details Tab] [Section: Service Tariff Modifier] Edit (Link in the grid)
	
//	[Details Tab] [Section: Service Tariff Modifier] Delete (Link in the grid)
	
	
//	[List Tab] Modify Resource fee Name (Link in the search result grid)
	
//	[List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchResFeesPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "[List Tab] View (Link in the search result grid)")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Resource Fees")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ resourceFeesDatas.subList(1, 2).get(0)[5].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");
	}
	
////	[List Tab] Define Resource fee Designation (Link in the search result grid)
//	
////	[List Tab] Modify Resource fee Designation (Link in the search result grid)
	
//	[Details Tab] [Section: Audit Trail] View
	
}
