package com.atk.himma.pageobjects.cpoe.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class OrderSummarySection extends DriverWaitClass {
	public final static String ORDERSERVTYPE_ID = "ORD_SVC_TYPE";
	public final static String STATUSFILTERBTN_NAME = "statusFilter";
	public final static String STATUSFILTERDIALOG_ID = "StatusFilter";
	public final static String FILTERCRIT_PENDING_ID = "Pending";
	public final static String FILTERCRIT_INVOICED_ID = "Invoiced";
	public final static String FILTERCRIT_CANCELLED_ID = "Cancelled";
	public final static String SUBMITFILTERBTN_ID = "SUBMIT_FILTER";
	public final static String CANCELFILTERBTN_ID = "CANCEL_FILTER";
	public final static String ADDSERVICESBTN_ID = "ADD_SERVICES";
	public final static String ADDSERVICESFORM_ID = "ADD_SERVICES_FORM";
	public final static String SERVPOPUPMBU_ID = "SERVICE_MBU_POPUP";
	public final static String SERVPOPUPDEPT_ID = "DEPT_ADD";
	public final static String SERVPOPUPSPLTY_ID = "SPEC_ADD";
	public final static String SERVPOPUPSUBSPLTY_ID = "SUB_S_ADD";
	public final static String SERVTYPE_ID = "SVC_TYPE_ADD";
	public final static String SERVCODE_ID = "CODE_ADD";
	public final static String SERVNAME_ID = "NAME_ADD";
	public final static String SERVSEARCHBTN_ID = "SERVICES_FOR_ADD_SERVICES";
	public final static String SERVRESETBTN_XPATH = "//form[@id='ADD_SERVICES_FORM']//input[@value='Reset']";
	public final static String SERVSEARCHGRIDDIV_ID = "ADD_SERV_U_DIV";
	public final static String ADDTOSELECTEDSERVBTN_ID = "ADD_TO_SELECTED";
	public final static String REMOVEFROMSELECTEDSERVBTN_ID = "REMOVE_FROM_SELECTED";
	public final static String SELECTEDSERVGRIDDIV_ID = "ADD_SERV_L_DIV";
	public final static String SELSERVSUBMITBTN_ID = "ADD_SELECTED_SERVICES_TO_ORDER";
	public final static String SELSERVCANCELBTN_ID = "CANCEL_ADD_SERVICES";
	public final static String ADDITEMSBTN_ID = "ADD_ITEMS";
	public final static String ADDITEMSFORM_ID = "ADD_ITEMS_FORM_ID";
	public final static String ITEMTYPE_ID = "ITEM_TYPE_ID";
	public final static String ITEMCATEGORY_ID = "ITEM_CATEGORY_ID";
	public final static String ITEMSUBCATEGORY_ID = "ITEM_SUBCATEGORY_ID";
	public final static String ITEMCODE_ID = "ITEM_CODE_ID";
	public final static String ITEMNAME_ID = "ITEM_NAME_ID";
	public final static String ITEMSEARCHBTN_ID = "ITEMS_FOR_ADD";
	public final static String ITEMRESETBTN_XPATH = "//form[@id='ADD_ITEMS_FORM_ID']//input[@value='Reset']";
	public final static String ITEMSEARCHGRIDDIV_ID = "ADD_ITEM_UPPER_GRID__DIV";
	public final static String ADDTOSELECTEDITMBTN_ID = "ADD_TO_SELECTED_ID";
	public final static String REMOVEFROMSELECTEDITMBTN_ID = "REMOVE_FROM_SELECTED_ID";
	public final static String SELECTEDITMGRIDDIV_ID = "ADD_ITEM_LOWER_GRID_DIV";
	public final static String SELITMSUBMITBTN_ID = "ADD_SELECTED_ITEMS_TO_ORDER";
	public final static String SELITMCANCELBTN_ID = "CANCEL_ADD_ITEMS";
	public final static String ORDSUMMGRIDDIV_ID = "INVOICE_GRID_DIV";
	public final static String QUANTITY_NAME = "quantity";
	public final static String INSTRUCTIONS_NAME = "instructions";

	@FindBy(id = ORDERSERVTYPE_ID)
	private WebElement orderServiceType;

	@FindBy(id = STATUSFILTERBTN_NAME)
	private WebElement statusFilterBtn;

	@FindBy(id = STATUSFILTERDIALOG_ID)
	private WebElement statusFilterDialog;

	@FindBy(id = FILTERCRIT_PENDING_ID)
	private WebElement pending;

	@FindBy(id = FILTERCRIT_INVOICED_ID)
	private WebElement invoiced;

	@FindBy(id = FILTERCRIT_CANCELLED_ID)
	private WebElement cancelled;

	@FindBy(id = SUBMITFILTERBTN_ID)
	private WebElement submitStatusFilterBtn;

	@FindBy(id = CANCELFILTERBTN_ID)
	private WebElement cancelStatusFilterBtn;

	@FindBy(id = ADDSERVICESBTN_ID)
	private WebElement addServicesBtn;

	@FindBy(id = ADDSERVICESFORM_ID)
	private WebElement addServicesForm;

	@FindBy(id = SERVPOPUPMBU_ID)
	private WebElement mbu;

	@FindBy(id = SERVPOPUPDEPT_ID)
	private WebElement servDepartment;

	@FindBy(id = SERVPOPUPSPLTY_ID)
	private WebElement servSpecialty;

	@FindBy(id = SERVPOPUPSUBSPLTY_ID)
	private WebElement servSubSpecialty;

	@FindBy(id = SERVTYPE_ID)
	private WebElement servType;

	@FindBy(id = SERVCODE_ID)
	private WebElement servCode;

	@FindBy(id = SERVNAME_ID)
	private WebElement servName;

	@FindBy(id = SERVSEARCHBTN_ID)
	private WebElement servSearchBtn;

	@FindBy(xpath = SERVRESETBTN_XPATH)
	private WebElement servResetBtn;

	@FindBy(id = SERVSEARCHGRIDDIV_ID)
	private WebElement servSearchGridDiv;

	@FindBy(id = ADDTOSELECTEDSERVBTN_ID)
	private WebElement addToSelectedServBtn;

	@FindBy(id = REMOVEFROMSELECTEDSERVBTN_ID)
	private WebElement removeSelectedServBtn;

	@FindBy(id = SELECTEDSERVGRIDDIV_ID)
	private WebElement selectedServGridDiv;

	@FindBy(id = SELSERVSUBMITBTN_ID)
	private WebElement selectedServSubmitBtn;

	@FindBy(id = SELSERVCANCELBTN_ID)
	private WebElement selectedServCancelBtn;

	@FindBy(id = ADDITEMSBTN_ID)
	private WebElement addItemsBtn;

	@FindBy(id = ADDITEMSFORM_ID)
	private WebElement addItemsForm;

	@FindBy(id = ITEMTYPE_ID)
	private WebElement itemType;

	@FindBy(id = ITEMCATEGORY_ID)
	private WebElement itemCategory;

	@FindBy(id = ITEMSUBCATEGORY_ID)
	private WebElement itemSubCategory;

	@FindBy(id = ITEMCODE_ID)
	private WebElement itemCode;

	@FindBy(id = ITEMNAME_ID)
	private WebElement itemName;

	@FindBy(id = ITEMSEARCHBTN_ID)
	private WebElement itemSearchBtn;

	@FindBy(xpath = ITEMRESETBTN_XPATH)
	private WebElement itemResetBtn;

	@FindBy(id = ITEMSEARCHGRIDDIV_ID)
	private WebElement itemSearchGridDiv;

	@FindBy(id = ADDTOSELECTEDITMBTN_ID)
	private WebElement addToSelectedItemBtn;

	@FindBy(id = REMOVEFROMSELECTEDITMBTN_ID)
	private WebElement removeFromSelectedItemBtn;

	@FindBy(id = SELECTEDITMGRIDDIV_ID)
	private WebElement selectedItmGridDiv;

	@FindBy(id = SELITMSUBMITBTN_ID)
	private WebElement selectedItmSubmitBtn;

	@FindBy(id = SELITMCANCELBTN_ID)
	private WebElement selectedItmCancelBtn;

	@FindBy(id = ORDSUMMGRIDDIV_ID)
	private WebElement ordSummaryGridDiv;

	@FindBy(id = QUANTITY_NAME)
	private WebElement quantity;

	@FindBy(id = INSTRUCTIONS_NAME)
	private WebElement instructions;

	public void addOrder(String[] outPatientListData) throws Exception {
		waitForElementId(ORDERSERVTYPE_ID);
		sleepVeryShort();
		if (!outPatientListData[28].isEmpty()) {
			new Select(orderServiceType)
					.selectByVisibleText(outPatientListData[28]);
		}
		waitForElementId(ADDSERVICESBTN_ID);
		sleepVeryShort();
		addServicesBtn.click();
		waitForElementId(ADDSERVICESFORM_ID);
		sleepVeryShort();
		if (!outPatientListData[29].isEmpty()) {
			new Select(servDepartment)
					.selectByVisibleText(outPatientListData[29]);
		}
		waitForElementId(SERVPOPUPSPLTY_ID);
		sleepVeryShort();
		if (!outPatientListData[30].isEmpty()) {
			new Select(servSpecialty)
					.selectByVisibleText(outPatientListData[30]);
		}
		waitForElementId(SERVPOPUPSUBSPLTY_ID);
		sleepVeryShort();
		if (!outPatientListData[31].isEmpty()) {
			new Select(servSubSpecialty)
					.selectByVisibleText(outPatientListData[31]);
		}
		waitForElementId(SERVTYPE_ID);
		sleepVeryShort();
		if (!outPatientListData[32].isEmpty()) {
			new Select(servType).selectByVisibleText(outPatientListData[32]);
		}
		servCode.clear();
		servCode.sendKeys(outPatientListData[33]);
		servName.clear();
		servName.sendKeys(outPatientListData[34]);
		servSearchBtn.click();
		waitForElementId(SERVSEARCHGRIDDIV_ID);
		sleepShort();
		webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='ADD_SERVICES_UPPER_GRID_serviceInfo.serviceName' and @title='"
								+ outPatientListData[34]
								+ "']/..//td[@aria-describedby='ADD_SERVICES_UPPER_GRID_cb']/input"))
				.click();
		addToSelectedServBtn.click();
		waitForElementId(SELECTEDSERVGRIDDIV_ID);
		sleepVeryShort();
		selectedServSubmitBtn.click();
		waitForElementId(ORDSUMMGRIDDIV_ID);
		sleepVeryShort();
		addItemsBtn.click();
		waitForElementId(ADDITEMSFORM_ID);
		sleepVeryShort();
		if (!outPatientListData[35].isEmpty()) {
			new Select(itemType).selectByVisibleText(outPatientListData[35]);
		}
		if (!outPatientListData[36].isEmpty()) {
			new Select(itemCategory)
					.selectByVisibleText(outPatientListData[36]);
		}
		waitForElementId(ITEMSUBCATEGORY_ID);
		sleepVeryShort();
		if (!outPatientListData[37].isEmpty()) {
			new Select(itemSubCategory)
					.selectByVisibleText(outPatientListData[37]);
		}
		itemCode.clear();
		itemCode.sendKeys(outPatientListData[38]);
		itemName.clear();
		itemName.sendKeys(outPatientListData[39]);
		itemSearchBtn.click();
		waitForElementId(ITEMSEARCHGRIDDIV_ID);
		sleepShort();
		webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='ADD_ITEMS_UPPER_GRID_itemName' and @title='"
								+ outPatientListData[39]
								+ "']/..//td[@aria-describedby='ADD_ITEMS_UPPER_GRID_cb']/input"))
				.click();
		sleepVeryShort();
		addToSelectedItemBtn.click();
		waitForElementId(SELECTEDITMGRIDDIV_ID);
		sleepShort();
		selectedItmSubmitBtn.click();
		waitForElementId(ORDSUMMGRIDDIV_ID);
		sleepShort();

	}

	public boolean checkOrderGridData(String[] outPatientListData)
			throws Exception {
		try {
			waitForElementXpathExpression("//td[@aria-describedby='ORDER_SUMMARY_GRID_name' and @title='"
					+ outPatientListData[34] + "']");
			return webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='ORDER_SUMMARY_GRID_name' and @title='"
									+ outPatientListData[34] + "']"))
					.isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}

	public WebElement getOrderServiceType() {
		return orderServiceType;
	}

	public WebElement getStatusFilterBtn() {
		return statusFilterBtn;
	}

	public WebElement getStatusFilterDialog() {
		return statusFilterDialog;
	}

	public WebElement getPending() {
		return pending;
	}

	public WebElement getInvoiced() {
		return invoiced;
	}

	public WebElement getCancelled() {
		return cancelled;
	}

	public WebElement getSubmitStatusFilterBtn() {
		return submitStatusFilterBtn;
	}

	public WebElement getCancelStatusFilterBtn() {
		return cancelStatusFilterBtn;
	}

	public WebElement getAddServicesBtn() {
		return addServicesBtn;
	}

	public WebElement getAddServicesForm() {
		return addServicesForm;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getServDepartment() {
		return servDepartment;
	}

	public WebElement getServSpecialty() {
		return servSpecialty;
	}

	public WebElement getServSubSpecialty() {
		return servSubSpecialty;
	}

	public WebElement getServType() {
		return servType;
	}

	public WebElement getServCode() {
		return servCode;
	}

	public WebElement getServName() {
		return servName;
	}

	public WebElement getServSearchBtn() {
		return servSearchBtn;
	}

	public WebElement getServResetBtn() {
		return servResetBtn;
	}

	public WebElement getServSearchGridDiv() {
		return servSearchGridDiv;
	}

	public WebElement getAddToSelectedServBtn() {
		return addToSelectedServBtn;
	}

	public WebElement getRemoveSelectedServBtn() {
		return removeSelectedServBtn;
	}

	public WebElement getSelectedServGridDiv() {
		return selectedServGridDiv;
	}

	public WebElement getSelectedServSubmitBtn() {
		return selectedServSubmitBtn;
	}

	public WebElement getSelectedServCancelBtn() {
		return selectedServCancelBtn;
	}

	public WebElement getAddItemsBtn() {
		return addItemsBtn;
	}

	public WebElement getAddItemsForm() {
		return addItemsForm;
	}

	public WebElement getItemType() {
		return itemType;
	}

	public WebElement getItemCategory() {
		return itemCategory;
	}

	public WebElement getItemSubCategory() {
		return itemSubCategory;
	}

	public WebElement getItemCode() {
		return itemCode;
	}

	public WebElement getItemName() {
		return itemName;
	}

	public WebElement getItemSearchBtn() {
		return itemSearchBtn;
	}

	public WebElement getItemResetBtn() {
		return itemResetBtn;
	}

	public WebElement getItemSearchGridDiv() {
		return itemSearchGridDiv;
	}

	public WebElement getAddToSelectedItemBtn() {
		return addToSelectedItemBtn;
	}

	public WebElement getRemoveFromSelectedItemBtn() {
		return removeFromSelectedItemBtn;
	}

	public WebElement getSelectedItmGridDiv() {
		return selectedItmGridDiv;
	}

	public WebElement getSelectedItmSubmitBtn() {
		return selectedItmSubmitBtn;
	}

	public WebElement getSelectedItmCancelBtn() {
		return selectedItmCancelBtn;
	}

	public WebElement getOrdSummaryGridDiv() {
		return ordSummaryGridDiv;
	}

	public WebElement getQuantity() {
		return quantity;
	}

	public WebElement getInstructions() {
		return instructions;
	}

}