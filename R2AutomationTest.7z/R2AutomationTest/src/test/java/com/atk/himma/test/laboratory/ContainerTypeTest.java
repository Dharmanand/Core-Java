package com.atk.himma.test.laboratory;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.laboratory.masters.ContainerTypePage;
import com.atk.himma.setup.SeleniumDriverSetup;

public class ContainerTypeTest extends SeleniumDriverSetup {
	ContainerTypePage containerTypePage;
	List<String[]> containerTypeList;

	@Test(description = "Open Container Type Page")
	public void testOpenContainerTypePage() throws Exception {
		containerTypePage = PageFactory.initElements(webDriver,
				ContainerTypePage.class);
		containerTypePage = containerTypePage.clickOnContainerTypeMenu(
				webDriver, webDriverWait);
		containerTypePage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("laboratoryExcel"));
		containerTypeList = excelReader.read(properties
				.getProperty("containerType"));
		Assert.assertNotNull(containerTypePage);
		containerTypePage.waitForElementVisibilityOf(containerTypePage
				.getContainerTypeListTabPage().getQuickSearchTxt());
		Assert.assertTrue(containerTypePage.getContainerTypeListTabPage()
				.getQuickSearchTxt().isDisplayed());

	}

	@Test(description = "Check 'Add New Container Type' button", dependsOnMethods = { "testOpenContainerTypePage" })
	public void testCheckAddNewContainerTypeBtn() throws Exception {
		Assert.assertEquals(containerTypePage.getContainerTypeListTabPage()
				.checkAddNewContTypeBtn(), "Add New Container Type");

	}

	@Test(description = "Click 'Add New Container Type' button", dependsOnMethods = { "testCheckAddNewContainerTypeBtn" })
	public void testClickAddNewContainerTypeBtn() throws Exception {
		containerTypePage.getContainerTypeListTabPage()
				.clickAddNewContTypeBtn();
		Assert.assertTrue(containerTypePage.getContainerTypeDetailsTabPage()
				.getContTypeShName().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Container Type Short Name", dependsOnMethods = { "testClickAddNewContainerTypeBtn" })
	public void testValidateContTypeShNameMandatoryField() throws Exception {
		Assert.assertTrue(containerTypePage.getContainerTypeDetailsTabPage()
				.isMandContTypeShName());
	}

	@Test(description = "Validate Mandatory for Container Type Desc", dependsOnMethods = { "testClickAddNewContainerTypeBtn" })
	public void testValidateContTypeDescMandatoryField() throws Exception {
		Assert.assertTrue(containerTypePage.getContainerTypeDetailsTabPage()
				.isMandContTypeDesc());
	}

	@Test(description = "Fill Container Type Details", dependsOnMethods = { "testClickAddNewContainerTypeBtn" })
	public void testFillContainerTypeDetails() throws Exception {
		if (containerTypeList != null && !containerTypeList.isEmpty()) {
			for (String[] containerTypeData : containerTypeList.subList(0, 1)) {
				containerTypePage.getContainerTypeDetailsTabPage()
						.fillContainerTypeDetails(containerTypeData);
				Assert.assertEquals(containerTypePage
						.getContainerTypeDetailsTabPage().getSelectedUOM(),
						containerTypeData[4]);
			}
		}
	}

	@Test(description = "Save Container Type Details", dependsOnMethods = { "testFillContainerTypeDetails" })
	public void testSaveContainerTypeDetails() throws Exception {
		containerTypePage.getContainerTypeDetailsTabPage()
				.saveContainerDetails();
		Assert.assertTrue(containerTypePage.getContainerTypeDetailsTabPage()
				.getAddNewUpBtn().isEnabled()
				&& containerTypePage.getContainerTypeDetailsTabPage()
						.getUpdateUpBtn().isEnabled());

	}

	@Test(description = "Activate Record", dependsOnMethods = { "testSaveContainerTypeDetails" })
	public void testActivateRecord() throws Exception {
		Assert.assertEquals(containerTypePage.getContainerTypeDetailsTabPage()
				.activateRecord().contains("Active"), true,
				"Failed Activate Record");

	}

	@Test(description = "Add More Container Type Data", dependsOnMethods = { "testActivateRecord" })
	public void testAddMoreContainerTypeData() throws Exception {
		if (containerTypeList != null && !containerTypeList.isEmpty()) {
			for (String[] containerTypeData : containerTypeList.subList(1,
					containerTypeList.size())) {
				containerTypePage.getContainerTypeDetailsTabPage()
						.clickAddMoreContainerType();
				containerTypePage.getContainerTypeDetailsTabPage()
						.fillContainerTypeDetails(containerTypeData);
				containerTypePage.getContainerTypeDetailsTabPage()
						.saveContainerDetails();
				Assert.assertEquals(containerTypePage
						.getContainerTypeDetailsTabPage().activateRecord()
						.contains("Active"), true, "Failed Activate Record");

			}
		}

	}

	@Test(description = "Navigate to Container Type List tab", dependsOnMethods = { "testAddMoreContainerTypeData" })
	public void testNavigateToContainerTypeList() throws Exception {
		containerTypePage.navigateToContTypeListPage();
		Assert.assertTrue(containerTypePage.getContainerTypeListTabPage()
				.getQuickSearchTxt().isDisplayed());

	}

	@Test(description = "Search Container Type List", dependsOnMethods = { "testNavigateToContainerTypeList" })
	public void testSearchContainerTypeList() throws Exception {
		if (containerTypeList != null && !containerTypeList.isEmpty()) {
			for (String[] containerTypeData : containerTypeList.subList(0, 1)) {
				Assert.assertEquals(
						containerTypePage.getContainerTypeListTabPage()
								.searchContainerTypeList(containerTypeData),
						containerTypeData[1]);
			}
		}
	}

	@Test(description = "Delete Container Type List Data", dependsOnMethods = { "testSearchContainerTypeList" })
	public void testDeleteContainerTypeData() throws Exception {
		if (containerTypeList != null && !containerTypeList.isEmpty()) {
			for (String[] containerTypeData : containerTypeList.subList(0, 1)) {
				containerTypePage.getContainerTypeListTabPage()
						.deleteContainerTypeData(containerTypeData);
				Assert.assertFalse(containerTypePage
						.getContainerTypeListTabPage().searchGridData(
								containerTypeData[1]));
			}
		}
	}

	@Test(description = "Edit Container Type List Data", dependsOnMethods = { "testSearchContainerTypeList" })
	public void testEditContainerTypeData() throws Exception {
		if (containerTypeList != null && !containerTypeList.isEmpty()) {
			for (String[] containerTypeData : containerTypeList.subList(1, 2)) {
				Assert.assertEquals(
						containerTypePage.getContainerTypeListTabPage()
								.searchContainerTypeList(containerTypeData),
						containerTypeData[1]);
				containerTypePage.getContainerTypeListTabPage()
						.clickEditContainerData(containerTypeData);
				Assert.assertEquals(
						containerTypePage.getContainerTypeDetailsTabPage()
								.verifyContTypeDesc(containerTypeData),
						containerTypeData[2]);

			}
		}
	}

	@Test(description = "Update Container Type List Data", dependsOnMethods = { "testSearchContainerTypeList" })
	public void testUpdateContainerTypeData() throws Exception {
		// add containerTypeList for update
		if (containerTypeList != null && !containerTypeList.isEmpty()) {
			for (String[] containerTypeData : containerTypeList.subList(1, 2)) {
				Assert.assertEquals(containerTypePage
						.getContainerTypeDetailsTabPage()
						.updateContainerTypeData(containerTypeData),
						containerTypeData[2]);

			}
		}
	}

}
