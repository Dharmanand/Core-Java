package com.atk.himma.pageobjects.apoe.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ExistingOrderTab extends DriverWaitClass {
	public final static String MBU_ID = "OTC_MAIN_BS_UNIT";
	@FindBy(id = MBU_ID)
	private WebElement mbu;

	public final static String SERVTYPE_ID = "ROUT_SERVICE_TYPE";
	@FindBy(id = SERVTYPE_ID)
	private WebElement servType;

	public final static String TIMERANGE_ID = "ROUT_TIME_RANGE";
	@FindBy(id = TIMERANGE_ID)
	private WebElement timeRange;

	public final static String CURRENTVISIT_ID = "ROUT_VISIT_RANGE1";
	@FindBy(id = CURRENTVISIT_ID)
	private WebElement currentVisit;

	public final static String ALLMYVISITS_ID = "ROUT_VISIT_RANGE2";
	@FindBy(id = ALLMYVISITS_ID)
	private WebElement allMyVisits;

	public final static String VISITINSELECTEDMBU_ID = "ROUT_VISIT_RANGE3";
	@FindBy(id = VISITINSELECTEDMBU_ID)
	private WebElement visitInSelectedMBU;

	public final static String VISITINALLMBUS_ID = "ROUT_VISIT_RANGE4";
	@FindBy(id = VISITINALLMBUS_ID)
	private WebElement visitInAllMBUs;

	public final static String QUICKSEARCHBOX_XPATH = ".//input[@id='EXISTING_ORDER_SEARCH']";
	@FindBy(xpath = QUICKSEARCHBOX_XPATH)
	private WebElement quickSearchBox;

	public final static String EXISTORDERSEARCHBTN_ID = "EXORDER_SEARCH_BUTTON";
	@FindBy(id = EXISTORDERSEARCHBTN_ID)
	private WebElement existOrderSearchBtn;

	public final static String EXISTORDERRESETBTN_ID = "EXORDER_RESET_BUTTON";
	@FindBy(id = EXISTORDERRESETBTN_ID)
	private WebElement existOrderResetBtn;

	public final static String EXISTORDERGRIDTBL_ID = "EXISTING_ORDER_GRID";
	@FindBy(id = EXISTORDERGRIDTBL_ID)
	private WebElement existOrderGridTbl;
	
	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getServType() {
		return servType;
	}

	public WebElement getTimeRange() {
		return timeRange;
	}

	public WebElement getCurrentVisit() {
		return currentVisit;
	}

	public WebElement getAllMyVisits() {
		return allMyVisits;
	}

	public WebElement getVisitInSelectedMBU() {
		return visitInSelectedMBU;
	}

	public WebElement getVisitInAllMBUs() {
		return visitInAllMBUs;
	}

	public WebElement getQuickSearchBox() {
		return quickSearchBox;
	}

	public WebElement getExistOrderSearchBtn() {
		return existOrderSearchBtn;
	}

	public WebElement getExistOrderResetBtn() {
		return existOrderResetBtn;
	}

	public WebElement getExistOrderGridTbl() {
		return existOrderGridTbl;
	}

}
