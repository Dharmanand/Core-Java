package com.atk.himma.pageobjects.contracts.sections.rateplandetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PriceModifParametersSection extends DriverWaitClass {
	public static final String PRICEMODIFPARAMSEC_LINKTEXT = "Price Modification Parameters";
	public final static String MODIFPATTERNDISC_ID = "MODIFICATION_PATTERN1";
	public final static String MODIFPATTERNADDON_ID = "MODIFICATION_PATTERN2";
	public final static String MODIFPATTERNFIXED_ID = "MODIFICATION_PATTERN3";
	public final static String MODIFPATTERNTYPE_ID = "PMP_VALUE_DROPDOWN";
	public final static String MODIFPATTERNVAL_ID = "PMP_VALUE_TEXT";
	public final static String DEPARTMENT_ID = "department";
	public final static String SPECIALTY_ID = "speciality_id";
	public final static String SUBSPECIALTY_ID = "Sub_speciality_id";
	public final static String SERVICETYPE_ID = "service_type";
	public final static String SERVLOOKUP_ID = "MODIFI_PARAMETER";
	public final static String SERVLOOKUPFORM_ID = "MODIFICATION_LOOKUP_FORM";
	public final static String SERVLOOKUPDEPT_ID = "MOD_DEPT";
	public final static String SERVLOOKUPSPLTY_ID = "MOD_SPEC";
	public final static String SERVLOOKUPSUBSPLTY_ID = "MOD_SUB";
	public final static String SERVLOOKUPSERVTYPE_ID = "MOD_TYPE";
	public final static String SERVLOOKUPSERVCODE_ID = "MOD_CODE";
	public final static String SERVLOOKUPSERVNAME_ID = "MOD_NAME";
	public final static String SERVLOOKUPSEARCHBTN_XPATH = "//form[@id='MODIFICATION_LOOKUP_FORM']//input[@value='Search']";
	public final static String SERVLOOKUPRESETBTN_XPATH = "//form[@id='MODIFICATION_LOOKUP_FORM']//input[@value='Reset']";
	public final static String SERVGRIDDIV_ID = "MODIFICATION_PARAMETER_LOOKUP_GRID";
	public final static String APPLYPRICEMODIFBTN_XPATH = "//input[@value='Apply Price Modifier']";
	public final static String UNDOBTN_ID = "CANCEL_MODIFICATION";
	public final static String CLEARBTN_XPATH = "//input[@value='Clear']";
	public final static String NONRPSERVDISC_ID = "NON_RATE_PLAN_SERVICE_DISCOUNT";
	public final static String NONRPDISCMODIFPATTERN_XPATH = "//input[@name='ratePlanWorkingArea.nonRateplanServiceDiscountPattern' and @value='1']";
	public final static String NONRPADDONMODIFPATTERN_XPATH = "//input[@name='ratePlanWorkingArea.nonRateplanServiceDiscountPattern' and @value='2']";
	public final static String NONRPMODIFVAL_ID = "SER_STND_MOD_VALUE_NON_RATE_PLAN";
	public final static String NONRPMODIFTYPE_ID = "SER_STND_MOD_TYPE_NON_RATE_PLAN";

	private final static String DISC = "Discount", ADDON = "Add On",
			FIXED = "Fixed";
	

	@FindBy(linkText = PRICEMODIFPARAMSEC_LINKTEXT)
	private WebElement priceModifParamSec;
	
	@FindBy(id = MODIFPATTERNDISC_ID)
	private WebElement discModifPattern;

	@FindBy(id = MODIFPATTERNADDON_ID)
	private WebElement addOnModifPattern;

	@FindBy(id = MODIFPATTERNFIXED_ID)
	private WebElement fixedModifPattern;

	@FindBy(id = MODIFPATTERNTYPE_ID)
	private WebElement modifPatternType;

	@FindBy(id = MODIFPATTERNVAL_ID)
	private WebElement modifPatternValue;

	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;

	@FindBy(id = SUBSPECIALTY_ID)
	private WebElement subSpecialty;

	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;

	@FindBy(id = SERVLOOKUP_ID)
	private WebElement serviceLookup;

	@FindBy(id = SERVLOOKUPFORM_ID)
	private WebElement serviceLookupForm;

	@FindBy(id = SERVLOOKUPDEPT_ID)
	private WebElement serviceLookupDept;

	@FindBy(id = SERVLOOKUPSPLTY_ID)
	private WebElement serviceLookupSplty;

	@FindBy(id = SERVLOOKUPSUBSPLTY_ID)
	private WebElement serviceLookupSubSplty;

	@FindBy(id = SERVLOOKUPSERVTYPE_ID)
	private WebElement serviceLookupServType;

	@FindBy(id = SERVLOOKUPSERVCODE_ID)
	private WebElement serviceLookupServCode;

	@FindBy(id = SERVLOOKUPSERVNAME_ID)
	private WebElement serviceLookupServName;

	@FindBy(xpath = SERVLOOKUPSEARCHBTN_XPATH)
	private WebElement serviceLookupSearchBtn;

	@FindBy(xpath = SERVLOOKUPRESETBTN_XPATH)
	private WebElement serviceLookupResetBtn;

	@FindBy(id = SERVGRIDDIV_ID)
	private WebElement searchGridDiv;

	@FindBy(xpath = APPLYPRICEMODIFBTN_XPATH)
	private WebElement applyPriceModifBtn;

	@FindBy(id = UNDOBTN_ID)
	private WebElement undoBtn;

	@FindBy(xpath = CLEARBTN_XPATH)
	private WebElement clearBtn;

	@FindBy(id = NONRPSERVDISC_ID)
	private WebElement nonRPServDisc;;

	@FindBy(xpath = NONRPDISCMODIFPATTERN_XPATH)
	private WebElement nonRPDiscModifPattern;;

	@FindBy(xpath = NONRPADDONMODIFPATTERN_XPATH)
	private WebElement nonRPAddonModifPattern;

	@FindBy(id = NONRPMODIFVAL_ID)
	private WebElement nonRPModifValue;

	@FindBy(id = NONRPMODIFTYPE_ID)
	private WebElement nonRPModifType;

	public void addPriceModifParamData(String[] ratePlanListData)
			throws Exception {
		if (DISC.equals(ratePlanListData[12])) {
			discModifPattern.click();
		} else if (ADDON.equals(ratePlanListData[12])) {
			addOnModifPattern.click();
		} else if (FIXED.equals(ratePlanListData[12])) {
			fixedModifPattern.click();
		}

		if (DISC.equals(ratePlanListData[12])
				|| ADDON.equals(ratePlanListData[12])) {
			if (!ratePlanListData[13].isEmpty()) {
				new Select(modifPatternType)
						.selectByVisibleText(ratePlanListData[13]);
			}
		}
		modifPatternValue.clear();
		modifPatternValue.sendKeys(ratePlanListData[14]);

		if (!ratePlanListData[19].isEmpty()) {
			if (!ratePlanListData[15].isEmpty()) {
				new Select(department)
						.selectByVisibleText(ratePlanListData[15]);
			}
			sleepVeryShort();
			if (!ratePlanListData[16].isEmpty()) {
				new Select(specialty).selectByVisibleText(ratePlanListData[16]);
			}
			sleepVeryShort();
			if (!ratePlanListData[17].isEmpty()) {
				new Select(subSpecialty)
						.selectByVisibleText(ratePlanListData[17]);
			}
			sleepVeryShort();
			if (!ratePlanListData[18].isEmpty()) {
				new Select(serviceType)
						.selectByVisibleText(ratePlanListData[18]);
			}

			serviceLookup.click();
			waitForElementId(SERVLOOKUPFORM_ID);
			serviceLookupServName.clear();
			serviceLookupServName.sendKeys(ratePlanListData[19]);
			serviceLookupSearchBtn.click();
			sleepShort();
			waitForElementId(SERVGRIDDIV_ID);
			clickOnGridAction("MODIFICATION_PARAMETER_GRID_serviceName",
					ratePlanListData[19], "Select");
			sleepVeryShort();
		}
		applyPriceModifBtn.click();
		sleepShort();
		if (Boolean.valueOf(ratePlanListData[20])) {
			nonRPServDisc.click();
			if (DISC.equals(ratePlanListData[21])) {
				nonRPDiscModifPattern.click();
			} else if (ADDON.equals(ratePlanListData[21])) {
				nonRPAddonModifPattern.click();
			}

			nonRPModifValue.clear();
			nonRPModifValue.sendKeys(ratePlanListData[22]);

			if (!ratePlanListData[23].isEmpty()) {
				new Select(nonRPModifType)
						.selectByVisibleText(ratePlanListData[23]);
			}

		}

	}

	public WebElement getPriceModifParamSec() {
		return priceModifParamSec;
	}

	public WebElement getDiscModifPattern() {
		return discModifPattern;
	}

	public WebElement getAddOnModifPattern() {
		return addOnModifPattern;
	}

	public WebElement getFixedModifPattern() {
		return fixedModifPattern;
	}

	public WebElement getModifPatternType() {
		return modifPatternType;
	}

	public WebElement getModifPatternValue() {
		return modifPatternValue;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getSpecialty() {
		return specialty;
	}

	public WebElement getSubSpecialty() {
		return subSpecialty;
	}

	public WebElement getServiceType() {
		return serviceType;
	}

	public WebElement getServiceLookup() {
		return serviceLookup;
	}

	public WebElement getServiceLookupForm() {
		return serviceLookupForm;
	}

	public WebElement getServiceLookupDept() {
		return serviceLookupDept;
	}

	public WebElement getServiceLookupSplty() {
		return serviceLookupSplty;
	}

	public WebElement getServiceLookupSubSplty() {
		return serviceLookupSubSplty;
	}

	public WebElement getServiceLookupServType() {
		return serviceLookupServType;
	}

	public WebElement getServiceLookupServCode() {
		return serviceLookupServCode;
	}

	public WebElement getServiceLookupServName() {
		return serviceLookupServName;
	}

	public WebElement getServiceLookupSearchBtn() {
		return serviceLookupSearchBtn;
	}

	public WebElement getServiceLookupResetBtn() {
		return serviceLookupResetBtn;
	}

	public WebElement getSearchGridDiv() {
		return searchGridDiv;
	}

	public WebElement getApplyPriceModifBtn() {
		return applyPriceModifBtn;
	}

	public WebElement getUndoBtn() {
		return undoBtn;
	}

	public WebElement getClearBtn() {
		return clearBtn;
	}

	public WebElement getNonRPServDisc() {
		return nonRPServDisc;
	}

	public WebElement getNonRPDiscModifPattern() {
		return nonRPDiscModifPattern;
	}

	public WebElement getNonRPAddonModifPattern() {
		return nonRPAddonModifPattern;
	}

	public WebElement getNonRPModifValue() {
		return nonRPModifValue;
	}

	public WebElement getNonRPModifType() {
		return nonRPModifType;
	}

}
