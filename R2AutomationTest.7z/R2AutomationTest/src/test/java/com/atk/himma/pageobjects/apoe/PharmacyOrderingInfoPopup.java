package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PharmacyOrderingInfoPopup extends DriverWaitClass {
	public final static String PHARMACYINFOPOPUPFROM_ID = "DRUG_INFO_POPUP";
	@FindBy(id = PHARMACYINFOPOPUPFROM_ID)
	private WebElement pharmacyInfoPopupForm;

	public final static String PRIORITY_ID = "DOSE_TYPE";
	@FindBy(id = PRIORITY_ID)
	private WebElement priority;

	public final static String ROUTE_ID = "ROUTE";
	@FindBy(id = ROUTE_ID)
	private WebElement route;

	public final static String PHARMACY_ID = "NORMAL_PHARM_DEPT";
	@FindBy(id = PHARMACY_ID)
	private WebElement pharmacy;

	public final static String REFILLCHKBOX_ID = "NUMBER_OF_REFILLS_APPLY";
	@FindBy(id = REFILLCHKBOX_ID)
	private WebElement refillChkBox;

	public final static String NOOFREFILLS_ID = "NO_OF_REFILLS";
	@FindBy(id = NOOFREFILLS_ID)
	private WebElement noOfRefills;

	public final static String NORMALDOSE_ID = "RADIO_BUTTON1";
	@FindBy(id = NORMALDOSE_ID)
	private WebElement normalDose;

	public final static String SLIDEDOSE_ID = "RADIO_BUTTON2";
	@FindBy(id = SLIDEDOSE_ID)
	private WebElement slideDose;

	public final static String MULTIDOSAGE_ID = "RADIO_BUTTON3";
	@FindBy(id = MULTIDOSAGE_ID)
	private WebElement multiDosage;

	public final static String ADDMOREPCYINSTR_ID = "ADD_MORE_PCY_INSTR";
	@FindBy(id = ADDMOREPCYINSTR_ID)
	private WebElement addMorePharmacyInstr;

	public final static String DOSEINSTRGRIDTBL_ID = "DOSE_INSTRUCTION_GRID";
	@FindBy(id = DOSEINSTRGRIDTBL_ID)
	private WebElement doseInstrGridTbl;

	public final static String DOSEINSTR_NAME = "instruction";
	@FindBy(name = DOSEINSTR_NAME)
	private WebElement doseInstr;

	public final static String ACTION_NAME = "instrVerb";
	@FindBy(name = ACTION_NAME)
	private WebElement action;

	public final static String DOSE_NAME = "dose";
	@FindBy(name = DOSE_NAME)
	private WebElement dose;

	public final static String STRENGTH_NAME = "strength";
	@FindBy(name = STRENGTH_NAME)
	private WebElement strength;

	public final static String UOM_NAME = "uomName";
	@FindBy(name = UOM_NAME)
	private WebElement uom;

	public final static String FREQUENCY_NAME = "frequency";
	@FindBy(name = FREQUENCY_NAME)
	private WebElement frequency;

	public final static String DURVALUE_NAME = "durationValue";
	@FindBy(name = DURVALUE_NAME)
	private WebElement durValue;

	public final static String DURUNIT_NAME = "durationUnit";
	@FindBy(name = DURUNIT_NAME)
	private WebElement durUnit;

	public final static String DOSSTARTDATE_NAME = "startDate";
	@FindBy(name = DOSSTARTDATE_NAME)
	private WebElement doseStartDate;

	public final static String DOSSTOPDATE_NAME = "stopDate";
	@FindBy(name = DOSSTOPDATE_NAME)
	private WebElement doseStopDate;

	public final static String QUANTITY_NAME = "quantity";
	@FindBy(name = QUANTITY_NAME)
	private WebElement quantity;

	public final static String DOSEREASON_ID = "DOSE_REASON";
	@FindBy(id = DOSEREASON_ID)
	private WebElement doseReason;

	public final static String PHARMACISTINSTR_ID = "PHARMACIST_INSTRUCTIONS";
	@FindBy(id = PHARMACISTINSTR_ID)
	private WebElement pharmacistInstr;

	public final static String PATINSTR_ID = "PATIENT_INSTRUCTIONS";
	@FindBy(id = PATINSTR_ID)
	private WebElement patInstr;

	public final static String ADDDRUGTOLIST_XPATH = ".//input[@value='Add to Selection List']";
	@FindBy(id = ADDDRUGTOLIST_XPATH)
	private WebElement addDrugToList;

	public final static String RESETPHARMACYPOPUP_ID = "RESET_PHARMACY_POPUP";
	@FindBy(id = RESETPHARMACYPOPUP_ID)
	private WebElement resetPharmacyPopup;

	public void addPcyOrderInfo(String[] orderEntryListData) {
		waitForElementId(PHARMACYINFOPOPUPFROM_ID);
		if (!orderEntryListData[43].isEmpty()) {
			new Select(priority).selectByVisibleText(orderEntryListData[43]);
		}
		if (!orderEntryListData[44].isEmpty()) {
			new Select(route).selectByVisibleText(orderEntryListData[44]);
		}
		if (!orderEntryListData[45].isEmpty()) {
			new Select(pharmacy).selectByVisibleText(orderEntryListData[45]);
		}
		if (Boolean.valueOf(orderEntryListData[46])) {
			refillChkBox.click();
			noOfRefills.clear();
			noOfRefills.sendKeys(orderEntryListData[47]);
		}
		selectRadioButtonAsLabelText(orderEntryListData[48]);
		waitForElementId(DOSEINSTRGRIDTBL_ID);
		doseInstr.clear();
		doseInstr.sendKeys(orderEntryListData[49]);
		if (!orderEntryListData[50].isEmpty()) {
			new Select(action).selectByVisibleText(orderEntryListData[50]);
		}
		dose.clear();
		dose.sendKeys(orderEntryListData[51]);
		if (!orderEntryListData[52].isEmpty()) {
			new Select(frequency).selectByVisibleText(orderEntryListData[52]);
		}
		durValue.clear();
		durValue.sendKeys(orderEntryListData[53]);
		if (!orderEntryListData[54].isEmpty()) {
			new Select(durUnit).selectByVisibleText(orderEntryListData[54]);
		}
		quantity.clear();
		quantity.sendKeys(orderEntryListData[55]);
		doseReason.clear();
		doseReason.sendKeys(orderEntryListData[56]);
		pharmacistInstr.clear();
		pharmacistInstr.sendKeys(orderEntryListData[57]);
		patInstr.clear();
		patInstr.sendKeys(orderEntryListData[58]);
		addDrugToList.click();
	}

	public WebElement getPharmacyInfoPopupForm() {
		return pharmacyInfoPopupForm;
	}

	public WebElement getPriority() {
		return priority;
	}

	public WebElement getRoute() {
		return route;
	}

	public WebElement getPharmacy() {
		return pharmacy;
	}

	public WebElement getRefillChkBox() {
		return refillChkBox;
	}

	public WebElement getNoOfRefills() {
		return noOfRefills;
	}

	public WebElement getNormalDose() {
		return normalDose;
	}

	public WebElement getSlideDose() {
		return slideDose;
	}

	public WebElement getMultiDosage() {
		return multiDosage;
	}

	public WebElement getAddMorePharmacyInstr() {
		return addMorePharmacyInstr;
	}

	public WebElement getDoseInstrGridTbl() {
		return doseInstrGridTbl;
	}

	public WebElement getDoseInstr() {
		return doseInstr;
	}

	public WebElement getAction() {
		return action;
	}

	public WebElement getDose() {
		return dose;
	}

	public WebElement getStrength() {
		return strength;
	}

	public WebElement getUom() {
		return uom;
	}

	public WebElement getFrequency() {
		return frequency;
	}

	public WebElement getDurValue() {
		return durValue;
	}

	public WebElement getDurUnit() {
		return durUnit;
	}

	public WebElement getDoseStartDate() {
		return doseStartDate;
	}

	public WebElement getDoseStopDate() {
		return doseStopDate;
	}

	public WebElement getQuantity() {
		return quantity;
	}

	public WebElement getDoseReason() {
		return doseReason;
	}

	public WebElement getPharmacistInstr() {
		return pharmacistInstr;
	}

	public WebElement getPatInstr() {
		return patInstr;
	}

	public WebElement getAddDrugToList() {
		return addDrugToList;
	}

	public WebElement getResetPharmacyPopup() {
		return resetPharmacyPopup;
	}

}
