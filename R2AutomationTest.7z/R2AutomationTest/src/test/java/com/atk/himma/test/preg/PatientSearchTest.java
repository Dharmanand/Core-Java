package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.preg.GeneralRegistrationPage;
import com.atk.himma.pageobjects.preg.PatientSearchPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class PatientSearchTest extends SeleniumDriverSetup {
	PatientSearchPage patientSearchPage;
	List<String[]> pregDatas;
	GeneralRegistrationPage generalRegistrationPage;
	LoginPage loginPage;

	@Test(description = "Open Patient Search Page")
	public void openPatientSearchPage() {
		patientSearchPage = PageFactory.initElements(webDriver,
				PatientSearchPage.class);
		patientSearchPage = patientSearchPage.clickOnPatientSearchLogo(
				webDriver, webDriverWait);
		doDirtyFormCheck();
		patientSearchPage.waitForElementId(PatientSearchPage.getFormnameId());
		patientSearchPage.waitForElementVisibilityOf(patientSearchPage
				.getSearchButton());
		Assert.assertNotNull(patientSearchPage.getFormName(),
				"Fail: Patient Search page loaded.");
	}

// 	[Patient Search Page] Open Form
	@Test(description = "Open Patient Merge Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkPatSearchMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		patientSearchPage = PageFactory.initElements(webDriver,
				PatientSearchPage.class);
		patientSearchPage.setWebDriver(webDriver);
		patientSearchPage.setWebDriverWait(webDriverWait);
		patientSearchPage
				.waitForElementXpathExpression(PatientSearchPage.PAGESEARCHIMG_XPATH);
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("Patient Search")
				.get("[Patient Search] Open Form");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PatientSearchPage.PAGESEARCHIMG_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Search] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			patientSearchPage = patientSearchPage.clickOnPatientSearchLogo(
					webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(patientSearchPage);
			patientSearchPage.waitForElementVisibilityOf(patientSearchPage
					.getSearchButton());
			patientSearchPage.sleepShort();
			Assert.assertNotNull(patientSearchPage.getFormName(),
					"Fail: Patient Search page loaded.");
		}
	}

	@Test(dependsOnMethods = { "openPatientSearchPage" }, description = "Quick Search")
	public void test1DoQuickSearch() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		for (String[] st : pregDatas.subList(6, 7))
			Assert.assertEquals(
					true,
					patientSearchPage.doQuickSearchPage(st[5].trim() + " "
							+ st[8].trim()));
	}

	@Test(dependsOnMethods = { "openPatientSearchPage" }, description = "do Reset")
	public void test2DoReset() throws InterruptedException {
		for (String[] st : pregDatas.subList(6, 7))
			Assert.assertEquals(patientSearchPage.doReset(st[5].trim() + " "
					+ st[8].trim()), true);
	}

	@Test(dependsOnMethods = { "openPatientSearchPage" }, description = "Check View")
	public void test3CheckView() throws InterruptedException {
		for (String[] st : pregDatas.subList(6, 7))
			Assert.assertEquals(
					patientSearchPage
							.clickViewLinkInGrid(
									st[5].trim() + " " + st[8].trim())
							.getPageTitle().getText().trim(),
					"General Registration");
	}

	@Test(dependsOnMethods = { "test3CheckView" }, description = "Check Edit")
	public void test4CheckEdit() throws InterruptedException {
		patientSearchPage.clickOnPatientSearchLogo(webDriver, webDriverWait);
		// doDirtyFormCheck();
		patientSearchPage.waitForElementId(PatientSearchPage.getFormnameId());
		patientSearchPage.waitForElementVisibilityOf(patientSearchPage
				.getSearchButton());
		for (String[] st : pregDatas.subList(6, 7))
			Assert.assertEquals(
					patientSearchPage
							.clickEditLinkInGrid(
									st[5].trim() + " " + st[8].trim())
							.getNewRegistrationButton().getAttribute("value"),
					"New Registration");
	}

	@Test(dependsOnMethods = { "test4CheckEdit" }, description = "Update General Registration Record")
	public void test5UpdateGenRegPage() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("updateGeneralRegistration"));
		generalRegistrationPage = PageFactory.initElements(webDriver,
				GeneralRegistrationPage.class);
		generalRegistrationPage.setWebDriver(webDriver);
		generalRegistrationPage.setWebDriverWait(webDriverWait);
		generalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas.subList(1, 2)) {
			waitForElement(generalRegistrationPage.getUpdateButton());
			generalRegistrationPage = generalRegistrationPage.updateGenRegPage(
					st, webDriver, webDriverWait);
			Assert.assertNotNull(generalRegistrationPage);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.MSGENABLE_XPATH);
			generalRegistrationPage
					.waitForElementVisibilityOf(generalRegistrationPage
							.getStatusMessage());
			Assert.assertEquals(generalRegistrationPage.getRegType().getText()
					.trim(), "GENERAL");
			generalRegistrationPage
					.waitForElementVisibilityOf(generalRegistrationPage
							.getNewRegistrationButton());
			Assert.assertNotNull(generalRegistrationPage.getUpdateButton(),
					"Update successfully Gen. Reg. datas.");
		}
	}

	@Test(dependsOnMethods = { "test5UpdateGenRegPage" }, description = "Save General Registration Record")
	public void test6SaveGenRegPage() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		generalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas.subList(6, 7)) {
			generalRegistrationPage.getNewRegistrationButton().click();
			generalRegistrationPage
					.waitForElementVisibilityOf(generalRegistrationPage
							.getSaveButton());
			generalRegistrationPage = generalRegistrationPage.saveGenRegPage(
					st, webDriver, webDriverWait);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.MSGENABLE_XPATH);
			generalRegistrationPage
					.waitForElementVisibilityOf(generalRegistrationPage
							.getStatusMessage());
			String regTypeMsg = generalRegistrationPage.getRegType().getText()
					.trim();
			Assert.assertEquals(regTypeMsg, "GENERAL");
			generalRegistrationPage
					.waitForElementVisibilityOf(generalRegistrationPage
							.getUpdateButton());
			Assert.assertNotNull(generalRegistrationPage.getUpdateButton(),
					"save successfully Gen. Reg. datas.");
		}
	}
	
	@Test(description = "Sign Out", dependsOnMethods = "test6SaveGenRegPage", alwaysRun = true)
	public void test7SignOut() throws Exception {
		loginPage = generalRegistrationPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = { "test7SignOut" })
	public void test8Login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(9,
				excelReader.read(properties.getProperty("loginSheetName"))),
				"User Home", "Failed Login");
	}
	

	
	
	@Test(description = "Quick Search", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "checkPatSearchMenuLink")
	public void doQuickSearchForPrivilege() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		for (String[] st : pregDatas.subList(0,1))
			Assert.assertEquals(
					true,
					patientSearchPage.doQuickSearchPage(st[5].trim() + " "
							+ st[8].trim()), "Fail to Quick Search");
	}
	
//	[Patient Search] View patient record (Link in the search result list)
	@Test(description = "check View Patient Link in Grid", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "doQuickSearchForPrivilege")
	public void checkViewLinkPrivilege()
	{
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Search")
				.get("[Patient Search] View patient record (Link in the search result list)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(".//td[@title='" + pregDatas.subList(0,1).get(0)[5].trim() +" "+pregDatas.subList(0,1).get(0)[8].trim()
						+ "']/..//a[text()='View']"));
		System.out
		.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Search] View patient record (Link in the search result list) privilege");
	}
	
//	[Patient Search] Edit  patient record (Link in the search result list)
	@Test(description = "check Edit Patient Link in Grid", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "doQuickSearchForPrivilege")
	public void checkEditLinkPrivilege()
	{
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Patient Search")
				.get("[Patient Search] Edit  patient record (Link in the search result list)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(".//td[@title='" + pregDatas.subList(0,1).get(0)[5].trim() +" "+pregDatas.subList(0,1).get(0)[8].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
		.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Patient Search] Edit  patient record (Link in the search result list) privilege");
	}
}
