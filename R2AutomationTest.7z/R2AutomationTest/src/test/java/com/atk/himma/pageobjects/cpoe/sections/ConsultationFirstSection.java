package com.atk.himma.pageobjects.cpoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;

public class ConsultationFirstSection extends DriverWaitClass {
	public final static String ENCNUMTXT_ID = "ENCOUNTER_ID";
	public final static String ENCSEARCHLOOKUP_ID = "ENC_SEARCH_LOOKUP";
	public final static String ENCSEARCHFORM_ID = "ENCOUNTER_SEARCH_FORM_ID";
	public final static String ENCNUM_NAME = "encounterSearchCriteria.encounterNumber";
	public final static String ENCLOOKUP_PHYSICIAN_NAME = "encounterSearchCriteria.physician";
	public final static String FROMDATE_ID = "FROM_DATE_ID";
	public final static String TODATE_ID = "TO_DATE_ID";
	public final static String LOCATION_NAME = "encounterSearchCriteria.location";
	public final static String ENCTYPE_NAME = "encounterSearchCriteria.encounterType";
	public final static String ENCSTATUS_NAME = "encounterSearchCriteria.encounterStatus";
	public final static String SEARCHENCBTN_XPATH = "//form[@id='ENCOUNTER_SEARCH_FORM_ID']//input[@value='Search']";
	public final static String CANCELENCBTN_XPATH = "//form[@id='ENCOUNTER_SEARCH_FORM_ID']//input[@value='Cancel']";
	public final static String ENCSEARCHGRIDDIV_ID = "ENCOUNTER_SEARCH_RESULT";

	public final static String ENCDATE_ID = "ENCOUNTER_DATE_TXT";
	public final static String ENCSPECIALTY_NAME = "encounterSpeciality";
	public final static String ORDERNUM_NAME = "order.orderCode";
	public final static String ENCDETAILSBTN_ID = "diagnosis_popup_but";
	public final static String ENCDETAILSPOPUP_ID = "diagnosis_popup";
	public final static String ENCPACKAGE_NAME = "packageName";
	public final static String PHYSICIAN_NAME = "physician";
	public final static String CLASS_NAME = "className";

	@FindBy(id = ENCNUMTXT_ID)
	private WebElement encounterNumTextBox;

	@FindBy(id = ENCSEARCHLOOKUP_ID)
	private WebElement encounterSearchLookup;

	@FindBy(id = ENCSEARCHFORM_ID)
	private WebElement encounterSearchForm;

	@FindBy(name = ENCNUM_NAME)
	private WebElement encounterNum;

	@FindBy(name = ENCLOOKUP_PHYSICIAN_NAME)
	private WebElement encounterPhysName;

	@FindBy(id = FROMDATE_ID)
	private WebElement encounterFromDate;

	@FindBy(id = TODATE_ID)
	private WebElement encounterToDate;

	@FindBy(name = LOCATION_NAME)
	private WebElement encounterLocName;

	@FindBy(name = ENCTYPE_NAME)
	private WebElement encounterType;

	@FindBy(name = ENCSTATUS_NAME)
	private WebElement encounterStatus;

	@FindBy(xpath = SEARCHENCBTN_XPATH)
	private WebElement encounterSearchBtn;

	@FindBy(xpath = CANCELENCBTN_XPATH)
	private WebElement encounterCancelBtn;

	@FindBy(id = ENCSEARCHGRIDDIV_ID)
	private WebElement encounterSearchGridDiv;

	@FindBy(id = ENCDATE_ID)
	private WebElement encounterDate;

	@FindBy(name = ENCSPECIALTY_NAME)
	private WebElement encounterSpecialtyName;

	@FindBy(name = ORDERNUM_NAME)
	private WebElement orderNumber;

	@FindBy(id = ENCDETAILSBTN_ID)
	private WebElement encounterDetailsBtn;

	@FindBy(id = ENCDETAILSPOPUP_ID)
	private WebElement encounterDetailsPopup;

	@FindBy(name = ENCPACKAGE_NAME)
	private WebElement encounterPackage;

	@FindBy(name = PHYSICIAN_NAME)
	private WebElement physician;

	@FindBy(name = CLASS_NAME)
	private WebElement className;

	public void selectEncounterNumber(String encounterNo, String[] outPatientListData)
			throws Exception {
		encounterSearchLookup.click();
		waitForElementId(ENCSEARCHFORM_ID);
		sleepVeryShort();
		encounterNum.clear();
		encounterNum.sendKeys(encounterNo.trim());
		waitForElementName(ENCLOOKUP_PHYSICIAN_NAME);
		if (!outPatientListData[12].isEmpty()) {
			new Select(encounterPhysName)
					.selectByVisibleText(outPatientListData[12]);
		}
		encounterFromDate.clear();
		encounterFromDate.sendKeys(DateTimeConverter.currentISTDateFormat());
		encounterToDate.clear();
		encounterToDate.sendKeys(outPatientListData[2]);
		if (!outPatientListData[6].isEmpty()) {
			new Select(encounterLocName)
					.selectByVisibleText(outPatientListData[6]);
		}
		if (!outPatientListData[24].isEmpty()) {
			new Select(encounterType)
					.selectByVisibleText(outPatientListData[24]);
		}
		if (!outPatientListData[25].isEmpty()) {
			new Select(encounterStatus)
					.selectByVisibleText(outPatientListData[25]);
		}
		encounterSearchBtn.click();
		waitForElementId(ENCSEARCHGRIDDIV_ID);
		sleepVeryShort();
		clickOnGridAction("ENCOUTER_SEARCH_GRID_ID_encounterNumber",
				outPatientListData[23], "Select");

	}

	public WebElement getEncounterNumTextBox() {
		return encounterNumTextBox;
	}

	public WebElement getEncounterSearchLookup() {
		return encounterSearchLookup;
	}

	public WebElement getEncounterSearchForm() {
		return encounterSearchForm;
	}

	public WebElement getEncounterNum() {
		return encounterNum;
	}

	public WebElement getEncounterPhysName() {
		return encounterPhysName;
	}

	public WebElement getEncounterFromDate() {
		return encounterFromDate;
	}

	public WebElement getEncounterToDate() {
		return encounterToDate;
	}

	public WebElement getEncounterLocName() {
		return encounterLocName;
	}

	public WebElement getEncounterType() {
		return encounterType;
	}

	public WebElement getEncounterStatus() {
		return encounterStatus;
	}

	public WebElement getEncounterSearchBtn() {
		return encounterSearchBtn;
	}

	public WebElement getEncounterCancelBtn() {
		return encounterCancelBtn;
	}

	public WebElement getEncounterSearchGridDiv() {
		return encounterSearchGridDiv;
	}

	public WebElement getEncounterDate() {
		return encounterDate;
	}

	public WebElement getEncounterSpecialtyName() {
		return encounterSpecialtyName;
	}

	public WebElement getOrderNumber() {
		return orderNumber;
	}

	public WebElement getEncounterDetailsBtn() {
		return encounterDetailsBtn;
	}

	public WebElement getEncounterDetailsPopup() {
		return encounterDetailsPopup;
	}

	public WebElement getEncounterPackage() {
		return encounterPackage;
	}

	public WebElement getPhysician() {
		return physician;
	}

	public WebElement getClassName() {
		return className;
	}

}
