package com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ExclDetailsFirstSection extends DriverWaitClass {

	public final static String EXCLISTCODE_ID = "EXC_LIST_CODE";
	public final static String EXCLISTNAME_ID = "EXC_LIST_NAME";
	public final static String MBULIST_ID = "MBU_NAME";
	public final static String GLOBALEXC_ID = "EXCLN_GLOBAL_CHBOX_MAIN";
	public final static String GLOBALEXCMBU_ID = "GLOBAL_EXMAIN_MBU";

	@FindBy(id = EXCLISTCODE_ID)
	private WebElement excListCode;

	@FindBy(id = EXCLISTNAME_ID)
	private WebElement excListName;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALEXC_ID)
	private WebElement globalExc;

	@FindBy(id = GLOBALEXCMBU_ID)
	private WebElement globalExcMBU;

	public boolean isMandExcListName() {
		waitForElementId(EXCLISTNAME_ID);
		return isMandatoryField(excListName);
	}

	public boolean isMandMBU() {
		waitForElementId(MBULIST_ID);
		return isMandatoryField(mbuList);
	}

	public void fillData(String[] excListFirstSectionData) throws Exception {
		waitForElementId(EXCLISTNAME_ID);
		sleepVeryShort();
		excListName.clear();
		excListName.sendKeys(excListFirstSectionData[1]);
		if (!excListFirstSectionData[2].isEmpty()) {
			new Select(mbuList).selectByVisibleText(excListFirstSectionData[2]);
		}
		if (Boolean.valueOf(excListFirstSectionData[3])) {
			globalExc.click();
		}
	}

	public String checkFieldValue() {
		return excListName.getAttribute("value");
	}

	public String checkGlobalExc() throws Exception {
		globalExc.click();
		confirmOkDialogBox();
		sleepVeryShort();
		return globalExcMBU.getAttribute("value");

	}

	public WebElement getExcListCode() {
		return excListCode;
	}

	public WebElement getExcListName() {
		return excListName;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalExc() {
		return globalExc;
	}

	public WebElement getGlobalExcMBU() {
		return globalExcMBU;
	}

}
