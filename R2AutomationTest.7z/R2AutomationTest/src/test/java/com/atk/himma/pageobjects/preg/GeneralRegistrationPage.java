package com.atk.himma.pageobjects.preg;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.preg.regsections.BiometricDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.ContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.EmergencyContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.IdentificationDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.NextOfKinSection;
import com.atk.himma.pageobjects.preg.regsections.OtherDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.PatientIdentifierSection;
import com.atk.himma.pageobjects.preg.regsections.PersonalDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.PolicyDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.PregFirstSection;
import com.atk.himma.pageobjects.preg.regsections.ReferralDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.RegistrationDetailsSection;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class GeneralRegistrationPage extends DriverWaitClass implements StatusMessages, TopControls, RecordStatus{

	private PregFirstSection firstSection;

	private PatientIdentifierSection patientIdentifierSection;

	private IdentificationDetailsSection identificationDetailsSection;

	private ContactDetailsSection contactDetailsSection;

	private PolicyDetailsSection policyDetailsSection;

	private PersonalDetailsSection personalDetailsSection;

	private EmergencyContactDetailsSection emergencyContactDetailsSection;

	private NextOfKinSection nextOfKinSection;

	private BiometricDetailsSection biometricDetailsSection;

	private ReferralDetailsSection referralDetailsSection;

	private OtherDetailsSection otherDetailsSection;

	private RegistrationDetailsSection registrationDetailsSection;

	public final static String MENULINK_XPATH = "//a[contains(text(),'Patient Registration')]/..//a[contains(text(),'General Registration')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	
	public final static String UPDATEMSG_XPATH = MSGENABLE_XPATH+"[contains(text(),'updated successfully.')]";
	
	@FindBy(id=PAGETITLE_ID)
	private WebElement pageTitle;
	
	public final static String regType_xpath = "//label[@id='GEN_REG_FRM_patiInfoDetails_registrationType' and @class='label_highlight capsletter']";
	
	@FindBy(xpath=regType_xpath)
	private WebElement regType;
	
	public final static String FORMNAME_ID = "GEN_REG_FRM";
	
	@FindBy(id=FORMNAME_ID)
	private WebElement formName;
	
	public final static String NEWREGISTRATIONBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='New Registration']";
	
	@FindBy(xpath=NEWREGISTRATIONBUTTON_XPATH)
	private WebElement newRegistrationButton;
	
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']//input[@value='Save']";
	
	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;
	
	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']//input[@value='Update']";
	
	@FindBy(xpath=UPDATEBUTTON_XPATH)
	private WebElement updateButton;
	
	public final static String DELETEBUTTON_ID = "DELETE_PATIENT_RECORD";
	
	@FindBy(id=DELETEBUTTON_ID)
	private WebElement deleteButton;
	
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']//input[@value='Cancel']";
	
	@FindBy(xpath=CANCELBUTTON_XPATH)
	private WebElement cancelButton;
	
	public final static String PRINTLABELSBUTTON_ID = "printPatientLabels";
	
	@FindBy(id=PRINTLABELSBUTTON_ID)
	private WebElement printLabelsButton;
	
	public final static String PRINTREGISTRATIONFORMBUTTON_ID = "printRegistrationForm";
	
	@FindBy(id=PRINTREGISTRATIONFORMBUTTON_ID)
	private WebElement printRegistrationFormButton;
	
	public final static String PRINTMRCARDBUTTON_XPATH = "Print MR Card...";
	
	@FindBy(xpath=PRINTMRCARDBUTTON_XPATH)
	private WebElement printMRCardButton;
	
	public final static String VIEWFAMILYTREEBUTTON_XPATH = "View Family Tree...";
	
	@FindBy(xpath=VIEWFAMILYTREEBUTTON_XPATH)
	private WebElement viewFamilyTreeButton;
	
	public final static String VIEWUPLOADEDDOCUMENTSBUTTON_ID = "viewUploadedFiles";
	
	@FindBy(id=VIEWUPLOADEDDOCUMENTSBUTTON_ID)
	private WebElement viewUploadedDocumentsButton;

	public final static String SUCCESSMSG_CLASSNAME = "successMsg";
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;
	
	/**
	 * @param firstSection the firstSection to set
	 */
	public void setInstanceOfAllSection(WebDriver webDriver, WebDriverWait webDriverWait) 
	{
		this.firstSection = PageFactory.initElements(webDriver, PregFirstSection.class);
		this.firstSection.setWebDriver(webDriver);
		this.firstSection.setWebDriverWait(webDriverWait);
		
		this.patientIdentifierSection = PageFactory.initElements(webDriver, PatientIdentifierSection.class);
		this.patientIdentifierSection.setWebDriver(webDriver);
		this.patientIdentifierSection.setWebDriverWait(webDriverWait);
		
		this.identificationDetailsSection = PageFactory.initElements(webDriver, IdentificationDetailsSection.class);
		this.identificationDetailsSection.setWebDriver(webDriver);
		this.identificationDetailsSection.setWebDriverWait(webDriverWait);
		
		this.contactDetailsSection = PageFactory.initElements(webDriver, ContactDetailsSection.class);
		this.contactDetailsSection.setWebDriver(webDriver);
		this.contactDetailsSection.setWebDriverWait(webDriverWait);
		
		this.policyDetailsSection = PageFactory.initElements(webDriver, PolicyDetailsSection.class);
		this.policyDetailsSection.setWebDriver(webDriver);
		this.policyDetailsSection.setWebDriverWait(webDriverWait);
		
		this.personalDetailsSection = PageFactory.initElements(webDriver, PersonalDetailsSection.class);
		this.personalDetailsSection.setWebDriver(webDriver);
		this.personalDetailsSection.setWebDriverWait(webDriverWait);
		
		this.emergencyContactDetailsSection = PageFactory.initElements(webDriver, EmergencyContactDetailsSection.class);
		this.emergencyContactDetailsSection.setWebDriver(webDriver);
		this.emergencyContactDetailsSection.setWebDriverWait(webDriverWait);
		
		this.nextOfKinSection = PageFactory.initElements(webDriver, NextOfKinSection.class);
		this.nextOfKinSection.setWebDriver(webDriver);
		this.nextOfKinSection.setWebDriverWait(webDriverWait);
		
		this.biometricDetailsSection = PageFactory.initElements(webDriver, BiometricDetailsSection.class);
		this.biometricDetailsSection.setWebDriver(webDriver);
		this.biometricDetailsSection.setWebDriverWait(webDriverWait);
		
		this.referralDetailsSection = PageFactory.initElements(webDriver, ReferralDetailsSection.class);
		this.referralDetailsSection.setWebDriver(webDriver);
		this.referralDetailsSection.setWebDriverWait(webDriverWait);
		
		this.otherDetailsSection = PageFactory.initElements(webDriver, OtherDetailsSection.class);
		this.otherDetailsSection.setWebDriver(webDriver);
		this.otherDetailsSection.setWebDriverWait(webDriverWait);
		
		this.registrationDetailsSection = PageFactory.initElements(webDriver, RegistrationDetailsSection.class);
		this.registrationDetailsSection.setWebDriver(webDriver);
		this.registrationDetailsSection.setWebDriverWait(webDriverWait);
		
	}
	
	public GeneralRegistrationPage clickOnGenRegMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		menuSelector.clickOnTargetMenu(baseLVParentMenuList,
				"General Registration");
		GeneralRegistrationPage genRegObj = PageFactory.initElements(webDriver, GeneralRegistrationPage.class);
		genRegObj.setWebDriver(webDriver);
		genRegObj.setWebDriverWait(webDriverWait);
		return genRegObj;
	}
	
	public GeneralRegistrationPage saveGenRegPage(String[] st, WebDriver webDriver, WebDriverWait webDriverWait) throws InterruptedException
	{
		fillGenRegData(st, webDriverWait);
		waitForElementXpathExpression(SAVEBUTTON_XPATH);
		saveButton.click();
		return createPageFactoryObject(webDriver, webDriverWait);
	}
	
	public GeneralRegistrationPage updateGenRegPage(String[] st, WebDriver webDriver, WebDriverWait webDriverWait) throws InterruptedException
	{
		fillGenRegData(st, webDriverWait);
		getUpdateButton().click();
		return createPageFactoryObject(webDriver, webDriverWait);
	}
	
	public GeneralRegistrationPage createPageFactoryObject(WebDriver webDriver, WebDriverWait webDriverWait)
	{
		GeneralRegistrationPage genRegObj = PageFactory.initElements(webDriver, GeneralRegistrationPage.class);
		genRegObj.setWebDriver(webDriver);
		genRegObj.setWebDriverWait(webDriverWait);
		return genRegObj;
	}
	
	public void fillGenRegData(String[] st, WebDriverWait webDriverWait) throws InterruptedException
	{
		getFirstSection().fillDatasOfPregFirstSection(st, webDriverWait);
		getPatientIdentifierSection().fillDatasOfPatientIdentifier(st, webDriverWait);
		getIdentificationDetailsSection().fillDatasIdentificationDetails(st, webDriverWait);
		getContactDetailsSection().fillDatasContactDetails(st, webDriverWait);
		getPersonalDetailsSection().fillDatasOfPersonalDetailsSection(st, webDriverWait);
		getEmergencyContactDetailsSection().fillDatasOfEmergencyContactDetailsSection(st, webDriverWait);
//		getBiometricDetailsSection().fillDatasOfBiometricDetailsSection(st, webDriverWait);
		getReferralDetailsSection().fillDatasOfReferralDetailsSection(st, webDriverWait);
		getOtherDetailsSection().fillDatasOfOtherlDetailsSection(st, webDriverWait);
	}
	
	/**
	 * @return the firstSection
	 */
	public PregFirstSection getFirstSection() {
		return firstSection;
	}

	/**
	 * @return the patientIdentifierSection
	 */
	public PatientIdentifierSection getPatientIdentifierSection() {
		return patientIdentifierSection;
	}

	/**
	 * @return the identificationDetailsSection
	 */
	public IdentificationDetailsSection getIdentificationDetailsSection() {
		return identificationDetailsSection;
	}

	/**
	 * @return the contactDetailsSection
	 */
	public ContactDetailsSection getContactDetailsSection() {
		return contactDetailsSection;
	}

	/**
	 * @return the policyDetailsSection
	 */
	public PolicyDetailsSection getPolicyDetailsSection() {
		return policyDetailsSection;
	}

	/**
	 * @return the personalDetailsSection
	 */
	public PersonalDetailsSection getPersonalDetailsSection() {
		return personalDetailsSection;
	}

	/**
	 * @return the emergencyContactDetailsSection
	 */
	public EmergencyContactDetailsSection getEmergencyContactDetailsSection() {
		return emergencyContactDetailsSection;
	}

	/**
	 * @return the nextOfKinSection
	 */
	public NextOfKinSection getNextOfKinSection() {
		return nextOfKinSection;
	}

	/**
	 * @return the biometricDetailsSection
	 */
	public BiometricDetailsSection getBiometricDetailsSection() {
		return biometricDetailsSection;
	}

	/**
	 * @return the referralDetailsSection
	 */
	public ReferralDetailsSection getReferralDetailsSection() {
		return referralDetailsSection;
	}

	/**
	 * @return the otherDetailsSection
	 */
	public OtherDetailsSection getOtherDetailsSection() {
		return otherDetailsSection;
	}

	/**
	 * @return the registrationDetailsSection
	 */
	public RegistrationDetailsSection getRegistrationDetailsSection() {
		return registrationDetailsSection;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the newRegistrationButton
	 */
	public WebElement getNewRegistrationButton() {
		return newRegistrationButton;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the deleteButton
	 */
	public WebElement getDeleteButton() {
		return deleteButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the printLabelsButton
	 */
	public WebElement getPrintLabelsButton() {
		return printLabelsButton;
	}

	/**
	 * @return the printRegistrationFormButton
	 */
	public WebElement getPrintRegistrationFormButton() {
		return printRegistrationFormButton;
	}

	/**
	 * @return the printMRCardButton
	 */
	public WebElement getPrintMRCardButton() {
		return printMRCardButton;
	}

	/**
	 * @return the viewFamilyTreeButton
	 */
	public WebElement getViewFamilyTreeButton() {
		return viewFamilyTreeButton;
	}

	/**
	 * @return the viewUploadedDocumentsButton
	 */
	public WebElement getViewUploadedDocumentsButton() {
		return viewUploadedDocumentsButton;
	}

	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the formnameId
	 */
	public static String getFormnameId() {
		return FORMNAME_ID;
	}

	/**
	 * @return the newregistrationbuttonXpath
	 */
	public static String getNewregistrationbuttonXpath() {
		return NEWREGISTRATIONBUTTON_XPATH;
	}

	/**
	 * @return the updatebuttonXpath
	 */
	public static String getUpdatebuttonXpath() {
		return UPDATEBUTTON_XPATH;
	}

	/**
	 * @return the deletebuttonId
	 */
	public static String getDeletebuttonId() {
		return DELETEBUTTON_ID;
	}

	/**
	 * @return the cancelbuttonXpath
	 */
	public static String getCancelbuttonXpath() {
		return CANCELBUTTON_XPATH;
	}

	/**
	 * @return the printlabelsbuttonId
	 */
	public static String getPrintlabelsbuttonId() {
		return PRINTLABELSBUTTON_ID;
	}

	/**
	 * @return the printregistrationformbuttonId
	 */
	public static String getPrintregistrationformbuttonId() {
		return PRINTREGISTRATIONFORMBUTTON_ID;
	}

	/**
	 * @return the printmrcardbuttonXpath
	 */
	public static String getPrintmrcardbuttonXpath() {
		return PRINTMRCARDBUTTON_XPATH;
	}

	/**
	 * @return the viewfamilytreebuttonXpath
	 */
	public static String getViewfamilytreebuttonXpath() {
		return VIEWFAMILYTREEBUTTON_XPATH;
	}

	/**
	 * @return the viewuploadeddocumentsbuttonId
	 */
	public static String getViewuploadeddocumentsbuttonId() {
		return VIEWUPLOADEDDOCUMENTSBUTTON_ID;
	}

	/**
	 * @return the successmsgClassname
	 */
	public static String getSuccessmsgClassname() {
		return SUCCESSMSG_CLASSNAME;
	}

	/**
	 * @return the regType
	 */
	public WebElement getRegType() {
		return regType;
	}

	/**
	 * @return the regtypeXpath
	 */
	public static String getRegtypeXpath() {
		return regType_xpath;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
