package com.atk.himma.pageobjects.laboratory.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SensitivityPanelListTabPage extends DriverWaitClass {
	public final static String ADDNEWSENSPANELBTN_XPATH = "//input[@value='Add New Sensitivity Panel']";
	@FindBy(xpath = ADDNEWSENSPANELBTN_XPATH)
	private WebElement addNewSensPanelBtn;

	public final static String SENSPANELQSEARCHTXT_NAME = "searchString";
	@FindBy(name = SENSPANELQSEARCHTXT_NAME)
	private WebElement sensPanelQSearchTxt;

	public final static String SENSPANELQSEARCHBTN_CSS = "span.input_holder_auto > input[value='Search']";
	@FindBy(css = SENSPANELQSEARCHBTN_CSS)
	private WebElement sensPanelQSearchBtn;

	public final static String SENSPANELADVSEARCHBTN_ID = "SENSITIVITY_PANEL_ADVANCED_SEARCH";
	@FindBy(id = SENSPANELADVSEARCHBTN_ID)
	private WebElement sensPanelAdvSearchBtn;

	public final static String SENSPANELADVSEARCHDIV_ID = "SENSITIVITY_PANEL_ADV_SEARCH_DIV";
	@FindBy(id = SENSPANELADVSEARCHDIV_ID)
	private WebElement sensPanelAdvSearchDiv;

	public final static String SENSPANELCODE_ID = "PANEL_CODE";
	@FindBy(id = SENSPANELCODE_ID)
	private WebElement sensPanelCode;

	public final static String SENSPANELSHNAME_ID = "SENSITIVITY_PANEL_SHORT_NAME";
	@FindBy(id = SENSPANELSHNAME_ID)
	private WebElement sensPanelShName;

	public final static String SENSPANELDESC_ID = "SENSITIVITY_PANEL_DESC";
	@FindBy(id = SENSPANELDESC_ID)
	private WebElement sensPanelDesc;

	public final static String STATUS_ID = "MAINSTATUS_ID";
	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String ADVSENSPANELSEARCHBTN_CSS = "span.buttoncontainer_mid > input[value='Search']";
	@FindBy(css = ADVSENSPANELSEARCHBTN_CSS)
	private WebElement advSensPanelSearchBtn;

	public final static String ADVSENSPANELRESETBTN_CSS = "span.buttoncontainer_mid > input[value='Reset']";
	@FindBy(css = ADVSENSPANELRESETBTN_CSS)
	private WebElement advSensPanelResetBtn;

	public final static String EXPORTSENSPANELBTN_ID = "SEARCH_SENSITIVITY_LIST_export_btn";
	@FindBy(id = EXPORTSENSPANELBTN_ID)
	private WebElement exportSensPanelBtn;

	public final static String SENSLISTGRIDTBL_ID = "SEARCH_SENSITIVITY_LIST";
	@FindBy(id = SENSLISTGRIDTBL_ID)
	private WebElement sensListGridTbl;

	public WebElement getAddNewSensPanelBtn() {
		return addNewSensPanelBtn;
	}

	public WebElement getSensPanelQSearchTxt() {
		return sensPanelQSearchTxt;
	}

	public WebElement getSensPanelQSearchBtn() {
		return sensPanelQSearchBtn;
	}

	public WebElement getSensPanelAdvSearchBtn() {
		return sensPanelAdvSearchBtn;
	}

	public WebElement getSensPanelAdvSearchDiv() {
		return sensPanelAdvSearchDiv;
	}

	public WebElement getSensPanelCode() {
		return sensPanelCode;
	}

	public WebElement getSensPanelShName() {
		return sensPanelShName;
	}

	public WebElement getSensPanelDesc() {
		return sensPanelDesc;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getAdvSensPanelSearchBtn() {
		return advSensPanelSearchBtn;
	}

	public WebElement getAdvSensPanelResetBtn() {
		return advSensPanelResetBtn;
	}

	public WebElement getExportSensPanelBtn() {
		return exportSensPanelBtn;
	}

	public WebElement getSensListGridTbl() {
		return sensListGridTbl;
	}

}
