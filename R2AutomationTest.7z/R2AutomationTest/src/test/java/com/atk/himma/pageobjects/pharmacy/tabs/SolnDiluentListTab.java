package com.atk.himma.pageobjects.pharmacy.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SolnDiluentListTab extends DriverWaitClass{

	public final static String FORM_ID = "SOL_DILUENT_LIST_PAGE";
	public final static String SEARCHTXT_ID = "SOL_DILUENT_QUICK_SEARCH";
	public final static String SEARCHBUTTON_CSS = "#SOL_DILUENT_QUICK_SEARCH + input";
	public final static String RESETBUTTON_CSS = "#SOL_DILUENT_QUICK_SEARCH ~ input[value='Reset']";
	public final static String ADDNEWLEBELBUTTON_CSS = "#SOL_DILUENT_QUICK_SEARCH ~ input[value='Advanced Search']";
	public final static String ADDNEWSOLDILBUTTON_ID = "ADD_NEW_SOL_DILUENT_BTN";
	public final static String EXEXCELBUTTON_ID = "SEARCH_SOL_DILUENT_LIST_export_btn";

	public final static String GRID_ID = "SEARCH_SOL_DILUENT_LIST";
	public final static String GRID_SOLNDILCODE_ARIA_DESCRIBEDBY = "SEARCH_SOL_DILUENT_LIST_code";
	public final static String GRID_SHORTDESC_ARIA_DESCRIBEDBY = "SEARCH_SOL_DILUENT_LIST_shortDesc";
	public final static String GRID_DESCRIPTION_ARIA_DESCRIBEDBY = "SEARCH_SOL_DILUENT_LIST_description";
	public final static String GRID_UOMTEXT_ARIA_DESCRIBEDBY = "SEARCH_SOL_DILUENT_LIST_uomText";
	public final static String GRID_ROUTETEXT_ARIA_DESCRIBEDBY = "SEARCH_SOL_DILUENT_LIST_routeText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "SEARCH_SOL_DILUENT_LIST_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_SEARCH_SOL_DILUENT_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_SOL_DILUENT_LIST_pager']";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(id = SEARCHTXT_ID)
	private WebElement searchTxt;

	@FindBy(id = SEARCHBUTTON_CSS)
	private WebElement searchButton;

	@FindBy(id = RESETBUTTON_CSS)
	private WebElement resetButton;

	@FindBy(id = ADDNEWLEBELBUTTON_CSS)
	private WebElement addNewLebelButton;

	@FindBy(id = ADDNEWSOLDILBUTTON_ID)
	private WebElement addNewSolDilButton;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the searchTxt
	 */
	public WebElement getSearchTxt() {
		return searchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the addNewLebelButton
	 */
	public WebElement getAddNewLebelButton() {
		return addNewLebelButton;
	}

	/**
	 * @return the addNewSolDilButton
	 */
	public WebElement getAddNewSolDilButton() {
		return addNewSolDilButton;
	}

	/**
	 * @return the exExcelButton
	 */
	public WebElement getExExcelButton() {
		return exExcelButton;
	}
	
	@FindBy(id = EXEXCELBUTTON_ID)
	private WebElement exExcelButton;
	
}
