package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ServiceListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "CHARGES_LIST_FORM";
	public final static String SERVICELIST_XPATH = "//a[@title='Service List']";
	public final static String ADDNEWSERVICEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Add New Service']";
	public final static String MBU_ID = "MBU_ID_SEARCH";
	public final static String DEPARTMENT_ID = "SERVICE_DEPARTMENT";
	public final static String SERSUBSPECIALITY_ID = "SERVICE_SUB_SPECIALITY";
	public final static String SERVICETYPE_ID = "SEARCH_SERVICE_TYPE";
	public final static String SERVICENAME_NAME = "searchCriteria.serviceName";
	public final static String SHOWGLOBALSERVICE_ID = "SEARCH_GLOBAL_SERVICE";
	public final static String SERVICESPECIALITY_ID = "SERVICE_SPECIALITY";
	public final static String SERVICECODE_NAME = "searchCriteria.serviceCode";
	public final static String VISITCATEGORY_ID = "VISIT_CATEGORY";
	public final static String STATUS_ID = "STATUS";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "SEARCH_SERVICE_LIST";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "SEARCH_SERVICE_LIST_serviceCode";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "SEARCH_SERVICE_LIST_serviceName";
	public final static String GRID_SERSPECIALTY_ARIA_DESCRIBEDBY = "SEARCH_SERVICE_LIST_specialtyText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "SEARCH_SERVICE_LIST_departmentText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "SEARCH_SERVICE_LIST_recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_SEARCH_SERVICE_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_SERVICE_LIST_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = SERVICELIST_XPATH)
	private WebElement serviceListTab;
	
	@FindBy(xpath = ADDNEWSERVICEBUTTON_XPATH)
	private WebElement addNewService;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SERSUBSPECIALITY_ID)
	private WebElement serSubSpeciality;
	
	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;
	
	@FindBy(name = SERVICENAME_NAME)
	private WebElement serviceName;
	
	@FindBy(id = SHOWGLOBALSERVICE_ID)
	private WebElement showGlobalService;
	
	@FindBy(id = SERVICESPECIALITY_ID)
	private WebElement serviceSpeciality;
	
	@FindBy(id = VISITCATEGORY_ID)
	private WebElement visitCategory;
	
	@FindBy(name = SERVICECODE_NAME)
	private WebElement serviceCode;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;
	
	@FindBy(id = STATUS_ID)
	private WebElement status;
	
	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the serviceListTab
	 */
	public WebElement getServiceListTab() {
		return serviceListTab;
	}

	/**
	 * @return the addNewService
	 */
	public WebElement getAddNewService() {
		return addNewService;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the serSubSpeciality
	 */
	public WebElement getSerSubSpeciality() {
		return serSubSpeciality;
	}

	/**
	 * @return the serviceType
	 */
	public WebElement getServiceType() {
		return serviceType;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the showGlobalService
	 */
	public WebElement getShowGlobalService() {
		return showGlobalService;
	}

	/**
	 * @return the serviceSpeciality
	 */
	public WebElement getServiceSpeciality() {
		return serviceSpeciality;
	}

	/**
	 * @return the visitCategory
	 */
	public WebElement getVisitCategory() {
		return visitCategory;
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

}
