package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PolicyListTab extends DriverWaitClass {
	public final static String POLICYLISTFORM_ID = "POLICY_LIST_FORM";
	public final static String ADDNEWPOLICYBTN_ID = "ADD_NEW_POLICY";
	public final static String MBULIST_ID = "mainBusinessUnit_search";
	public final static String GLOBALPOLICYCHKBOX_ID = "POL_GLOBAL_CHBOX";
	public final static String DEBTORNAME_ID = "debtor_search";
	public final static String DEBTORTYPE_ID = "debtorType_search";
	public final static String AGRMNTNAME_ID = "agreementName_search";
	public final static String POLICYSTATUS_ID = "status_search";
	public final static String POLICYNAME_ID = "policyName_search";
	public final static String POLICYREFNUM_ID = "referenceNumber_search";
	public final static String POLSEARCHBTN_XPATH = "//form[@id='POLICY_LIST_FORM']//input[@value='Search']";
	public final static String POLRESETBTN_XPATH = "//form[@id='POLICY_LIST_FORM']//input[@value='Reset']";
	public final static String POLGRIDDIV_ID = "POLICY_GRID_DIV";
	public static final String VIEWPOLLINK_XPATH = ".//table[@id='POLICY_GRID']/..//a[text()='View']";
	public static final String DELPOLLINK_XPATH = ".//table[@id='POLICY_GRID']/..//a[text()='Delete']";
	public static final String EDITPOLLINK_XPATH = ".//table[@id='POLICY_GRID']/..//a[text()='Edit']";

	@FindBy(id = POLICYLISTFORM_ID)
	private WebElement policyListForm;

	@FindBy(id = ADDNEWPOLICYBTN_ID)
	private WebElement addNewPolicyBtn;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALPOLICYCHKBOX_ID)
	private WebElement globalPolicyChkBox;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = AGRMNTNAME_ID)
	private WebElement agrmntName;

	@FindBy(id = POLICYSTATUS_ID)
	private WebElement policyStatus;

	@FindBy(id = POLICYNAME_ID)
	private WebElement policyName;

	@FindBy(id = POLICYREFNUM_ID)
	private WebElement policyRefNum;

	@FindBy(xpath = POLSEARCHBTN_XPATH)
	private WebElement policySearchBtn;

	@FindBy(xpath = POLRESETBTN_XPATH)
	private WebElement policyResetBtn;

	@FindBy(id = POLGRIDDIV_ID)
	private WebElement policyGridDiv;

	@FindBy(xpath = VIEWPOLLINK_XPATH)
	private WebElement viewPolLink;

	@FindBy(xpath = DELPOLLINK_XPATH)
	private WebElement delPolLink;

	@FindBy(xpath = EDITPOLLINK_XPATH)
	private WebElement editPolLink;

	public void clickAddNewPolicy() throws Exception {
		addNewPolicyBtn.click();
		sleepShort();

	}

	public void searchPolicy(String[] policyListData) throws Exception {
		waitForPageLoaded(webDriver);
		sleepShort();
		if (!policyListData[9].isEmpty()) {
			new Select(mbuList).selectByVisibleText(policyListData[9]);
		}
		waitForElementId(DEBTORNAME_ID);
		sleepVeryShort();
		if (!policyListData[7].isEmpty()) {
			new Select(debtorName).selectByVisibleText(policyListData[7]);
		}
		waitForElementId(AGRMNTNAME_ID);
		sleepVeryShort();
		if (!policyListData[8].isEmpty()) {
			new Select(agrmntName).selectByVisibleText(policyListData[8]);
		}
		policyName.clear();
		policyName.sendKeys(policyListData[2]);
		policySearchBtn.click();
		waitForElementId(POLGRIDDIV_ID);
		clickOnGridAction("POLICY_GRID_policyName", policyListData[2], "Edit");
		waitForPageLoaded(webDriver);

	}

	public void searchPolicyList(String[] policyData) throws Exception {
		waitForPageLoaded(webDriver);
		sleepShort();
		if (!policyData[9].isEmpty()) {
			new Select(mbuList).selectByVisibleText(policyData[9]);
		}
		waitForElementId(DEBTORNAME_ID);
		sleepVeryShort();
		if (!policyData[7].isEmpty()) {
			new Select(debtorName).selectByVisibleText(policyData[7]);
		}
		waitForElementId(AGRMNTNAME_ID);
		sleepVeryShort();
		if (!policyData[8].isEmpty()) {
			new Select(agrmntName).selectByVisibleText(policyData[8]);
		}
		policyName.clear();
		policyName.sendKeys(policyData[2]);
		policySearchBtn.click();
		waitForElementId(POLGRIDDIV_ID);
		sleepShort();

	}

	public void clickEditPolLink(String[] policyData) throws Exception {
		clickOnGridAction("POLICY_GRID_policyName", policyData[2], "Edit");
		sleepShort();
	}

	public WebElement getPolicyListForm() {
		return policyListForm;
	}

	public WebElement getAddNewPolicyBtn() {
		return addNewPolicyBtn;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalPolicyChkBox() {
		return globalPolicyChkBox;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getAgrmntName() {
		return agrmntName;
	}

	public WebElement getPolicyStatus() {
		return policyStatus;
	}

	public WebElement getPolicyName() {
		return policyName;
	}

	public WebElement getPolicyRefNum() {
		return policyRefNum;
	}

	public WebElement getPolicySearchBtn() {
		return policySearchBtn;
	}

	public WebElement getPolicyResetBtn() {
		return policyResetBtn;
	}

	public WebElement getPolicyGridDiv() {
		return policyGridDiv;
	}

	public WebElement getViewPolLink() {
		return viewPolLink;
	}

	public WebElement getDelPolLink() {
		return delPolLink;
	}

	public WebElement getEditPolLink() {
		return editPolLink;
	}

}
