package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.JobsPage;
import com.atk.himma.pageobjects.sa.tabs.JobListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class JobsTest extends SeleniumDriverSetup {
	JobsPage jobsPage;
	List<String[]> jobsList;

	@Test(description = "Open Jobs Page")
	public void openJobs() throws Exception {
		jobsPage = PageFactory.initElements(webDriver, JobsPage.class);
		jobsPage = jobsPage.clickOnJobsMenu(webDriver, webDriverWait);
		jobsPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		Assert.assertNotNull(jobsPage);
		jobsPage.waitForElementId(JobListTab.SEARCHJOBFORM_ID);
		jobsPage.sleepVeryShort();
		Assert.assertTrue(jobsPage.getJobListTab().getMainBusinessUnitName()
				.isDisplayed());
	}

	@Test(description = "Add New Jobs for Admin", dependsOnMethods = { "openJobs" }, groups={"superAdminTestsGrp"})
	public void addNewJob() throws Exception {
		jobsList = excelReader.read(properties.getProperty("jobs"));
		if (jobsList != null && !jobsList.isEmpty()) {
			jobsPage.getJobListTab().clickOnAddNewJob();
			jobsPage.waitForElementName(jobsPage.getJobInformationTab().JOBNAME_NAME);
			int i = 0;
			for (String[] jobsData : jobsList) {
				if (i > 0 && !jobsData[0].isEmpty()) {
					jobsPage.getJobInformationTab().saveJobs();
					Assert.assertTrue(jobsPage.getJobInformationTab()
							.getAddNewJobBtn().isEnabled()
							&& jobsPage.getJobInformationTab().getUpdateBtn()
									.isEnabled());
					jobsPage.getJobInformationTab().clickAddNewJob();
				}
				jobsPage.getJobInformationTab().addNewJob(jobsData);
				i++;
			}
			jobsPage.getJobInformationTab().saveJobs();
			jobsPage.getJobInformationTab().clickOnCancel();
		}
	}

	@Test(description = "Add New Jobs for Other Users", dependsOnMethods = { "openJobs" }, groups={"adminTestsGrp"})
	public void addNewJobsOtherUsers() throws Exception {
		jobsList = excelReader.read(properties.getProperty("otherUsersJobs"));
		if (jobsList != null && !jobsList.isEmpty()) {
			jobsPage.getJobListTab().clickOnAddNewJob();
			jobsPage.waitForElementName(jobsPage.getJobInformationTab().JOBNAME_NAME);
			int i = 0;
			for (String[] jobsData : jobsList) {
				if (i > 0 && !jobsData[0].isEmpty()) {
					jobsPage.getJobInformationTab().saveJobs();
					Assert.assertTrue(jobsPage.getJobInformationTab()
							.getAddNewJobBtn().isEnabled()
							&& jobsPage.getJobInformationTab().getUpdateBtn()
									.isEnabled());
					jobsPage.getJobInformationTab().clickAddNewJob();
				}
				jobsPage.getJobInformationTab().addNewJob(jobsData);
				i++;
			}
			jobsPage.getJobInformationTab().saveJobs();
			jobsPage.getJobInformationTab().clickOnCancel();
		}
	}

	@Test(description = "Edit Job", dependsOnMethods = { "addNewJobsOtherUsers" }, groups={"adminTestsGrp"})
	public void editJob() throws Exception {
		jobsList = excelReader.read(properties.getProperty("editJobs"));

		if (jobsList != null && !jobsList.isEmpty()) {
			int i = 0;
			for (String[] editJobsData : jobsList.subList(0, 2)) {
				if (i > 0 && !editJobsData[0].isEmpty()) {
					jobsPage.getJobInformationTab().clickOnUpdateButton();
					jobsPage.sleepVeryShort();
					jobsPage.waitForElementXpathExpression(JobsPage.MSGENABLE_XPATH);
					WebElement we = jobsPage.getStatusMessage();
					boolean flag = we.isEnabled();
					Assert.assertTrue(flag);
					jobsPage.getMsgHideLink().click();
					jobsPage.getJobInformationTab().clickOnCancel();
				}
				if (!editJobsData[0].isEmpty()) {
					jobsPage.getJobListTab().searchJobs(editJobsData);
					Assert.assertTrue(jobsPage.getJobListTab().searchGridData(
							editJobsData[0]));
					jobsPage.getJobListTab().clickOnEdit(editJobsData);
				}
				jobsPage.getJobInformationTab().updateJob(editJobsData);
				i++;
			}
			jobsPage.getJobInformationTab().clickOnUpdateButton();
			jobsPage.sleepVeryShort();
			jobsPage.getJobInformationTab().clickOnCancel();
		}
	}

	@Test(description = "Delete Job", dependsOnMethods = { "addNewJobsOtherUsers" }, groups={"adminTestsGrp"})
	public void deleteJob() throws Exception {
		jobsList = excelReader.read(properties.getProperty("deleteJobs"));
		if (jobsList != null && !jobsList.isEmpty()) {
			for (String[] delJobsData : jobsList) {
				jobsPage.getJobListTab().searchJobs(delJobsData);
				Assert.assertTrue(jobsPage.getJobListTab().searchGridData(
						delJobsData[0]));
				jobsPage.getJobListTab().clickOnDelete(delJobsData);
				try {
					Assert.assertFalse(jobsPage.getJobListTab().searchGridData(
							delJobsData[0]));
				} catch (Exception e) {
					Reporter.log("Element not Found....");
				}
			}
		}
	}

	/*
	 * @Test(description = "search Privileges Groups name at Job",
	 * dependsOnMethods = { "openJobs" }, groups="") public void
	 * searchPosGrpAtJob() throws Exception { String privGrpsName =
	 * jobsPage.searchPrivilegeGroups(fullPrivUserDatas .get("jobName").get(0));
	 * String modulesName = jobsPage.searchPrivilegeGroups(fullPrivUserDatas
	 * .get("jobName").get(0)); List<String> privGrpsNmList = new
	 * ArrayList<String>(); Assert.assertNotNull(modulesName);
	 * Assert.assertNotNull(privGrpsName); privGrpsNmList.add(modulesName);
	 * privGrpsNmList.add(privGrpsName);
	 * fullPrivUserDatas.put("privModuleGrpsNm", privGrpsNmList); }
	 */

	// [Jobs] Open Form
	@Test(description = "Open Jobs Page", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkJobsMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		jobsPage = PageFactory.initElements(webDriver, JobsPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> jobsParentMenuList = new LinkedList<String>();
		jobsParentMenuList.add("System Administration");
		menuSelector.mouseOverOnTargetMenu(jobsParentMenuList, "Jobs");
		jobsPage.setWebDriver(webDriver);
		jobsPage.setWebDriverWait(webDriverWait);
		jobsPage.waitForElementXpathExpression(JobsPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Jobs").get("[Jobs] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(JobsPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Jobs] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			jobsPage = jobsPage.clickOnJobsMenu(webDriver, webDriverWait);
			jobsPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(jobsPage);
			jobsPage.waitForElementVisibilityOf(jobsPage.getJobListTab()
					.getSearchJobForm());
			jobsPage.sleepShort();
			Assert.assertEquals(jobsPage.getPageTitle().getText(), "Jobs");
		}
	}

	// [List Tab] Add New (Button)
	@Test(description = "Check Add New Job Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkJobsMenuLink")
	public void checkAddNewJobBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Privilege Groups")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(JobListTab.ADDNEWJOBBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(description = "Check Edit Job Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkJobsMenuLink")
	public void checkEditJobLink() throws Exception {
		jobsList = excelReader.read(properties.getProperty("jobs"));
		for (String[] jobsData : jobsList.subList(3, 4)) {
			jobsPage.getJobListTab().privSearchJobs(jobsData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Jobs")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(JobListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
	}

	// [List Tab] Delete (Link in the search result grid)
	@Test(description = "Check Delete Job Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkJobsMenuLink")
	public void checkDeleteJobLink() throws Exception {
		jobsList = excelReader.read(properties.getProperty("jobs"));
		for (String[] jobsData : jobsList.subList(3, 4)) {
			jobsPage.getJobListTab().privSearchJobs(jobsData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Jobs")
				.get("[List Tab] Delete (Link in the search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(JobListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete (Link in the search result grid) privilege");
	}

	// [Details Tab][Section: Audit Trail] View

}
