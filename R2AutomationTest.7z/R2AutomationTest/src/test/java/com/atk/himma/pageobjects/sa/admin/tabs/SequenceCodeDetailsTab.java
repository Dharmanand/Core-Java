package com.atk.himma.pageobjects.sa.admin.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class SequenceCodeDetailsTab extends DriverWaitClass {
	public final static String SEQCODEDETAILSFORM_ID = "NEW_CODE_SEQUENCE";
	@FindBy(id = SEQCODEDETAILSFORM_ID)
	private WebElement seqCodeDetailsForm;

	public final static String ADDNEWSEQCODEBTN_XPATH = "//form[@id='NEW_CODE_SEQUENCE']//input[@value='Add New Sequence Code']";
	@FindBy(xpath = ADDNEWSEQCODEBTN_XPATH)
	private WebElement addNewSeqCodeBtn;

	public final static String SAVEBTN_ID = "SAVE_ID";
	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	public final static String CANCELBTN_XPATH = "//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String COPYBTN_XPATH = "//input[@value='Copy']";
	@FindBy(xpath = COPYBTN_XPATH)
	private WebElement copyBtn;

	public final static String UPDATEBTN_ID = "UPDATE_ID";
	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	public final static String MBU_ID = "MBU_NAME";
	@FindBy(id = MBU_ID)
	private WebElement mbu;

	public final static String APPLTOALLMBU_ID = "APPL_TO_ALL_MBU";
	@FindBy(id = APPLTOALLMBU_ID)
	private WebElement applToAllMbu;

	public final static String MODULENAME_ID = "MODULE_ID";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String CODENAME_ID = "SEQ_NAME";
	@FindBy(id = CODENAME_ID)
	private WebElement codeName;

	public final static String CODINGPATTERN_MANUAL_ID = "MANUAL_GEN";
	@FindBy(id = CODINGPATTERN_MANUAL_ID)
	private WebElement codingPattern_manual;

	public final static String CODINGPATTERN_SYSTEM_ID = "SYSTEM_GEN";
	@FindBy(id = CODINGPATTERN_SYSTEM_ID)
	private WebElement codingPattern_system;

	public final static String SEQUENCESEPARATOR_ID = "SEQ_SEPARATOR";
	@FindBy(id = SEQUENCESEPARATOR_ID)
	private WebElement sequenceSeparator;

	public final static String SEQCODECOMPONENTGRID_ID = "gbox_CODE_SEQ_GRID";
	@FindBy(id = SEQCODECOMPONENTGRID_ID)
	private WebElement seqCodeComponentGrid;

	public final static String ADDCOMPONENTBTN_XPATH = "//input[@value='Add Component']";
	@FindBy(xpath = ADDCOMPONENTBTN_XPATH)
	private WebElement addComponentBtn;

	public final static String UPBTN_ID = "UP_BUTTON";
	@FindBy(id = UPBTN_ID)
	private WebElement upBtn;

	public final static String DOWNBTN_ID = "DOWN_BUTTON";
	@FindBy(id = DOWNBTN_ID)
	private WebElement downBtn;

	public final static String COMPONENTPOPUP_ID = "COMPONENT_POPUP";
	@FindBy(id = COMPONENTPOPUP_ID)
	private WebElement componentPopup;

	public final static String COMPONENTTYPE_ID = "COMPONENT_TYPE";
	@FindBy(id = COMPONENTTYPE_ID)
	private WebElement componentType;

	public final static String STATICTEXT_ID = "STATIC_TEXT";
	@FindBy(id = STATICTEXT_ID)
	private WebElement staticText;

	public final static String NOOFDIGITS_ID = "NO_OF_DIGITS";
	@FindBy(id = NOOFDIGITS_ID)
	private WebElement noOfDigits;

	public final static String INITIALVALUE_ID = "INITIAL_VALUE";
	@FindBy(id = INITIALVALUE_ID)
	private WebElement initialValue;

	public final static String TWODIGITYRFORMAT_XPATH = "//input[@value='YY']";
	@FindBy(xpath = TWODIGITYRFORMAT_XPATH)
	private WebElement twoDigitYrFormat;

	public final static String FOURDIGITYRFORMAT_XPATH = "//input[@value='YYYY']";
	@FindBy(xpath = FOURDIGITYRFORMAT_XPATH)
	private WebElement fourDigitYrFormat;

	public final static String TWODIGITMONTHFORMAT_XPATH = "//input[@value='MM']";
	@FindBy(xpath = TWODIGITMONTHFORMAT_XPATH)
	private WebElement twoDigitMonthFormat;

	public final static String THREEDIGITMONTHFORMAT_XPATH = "//input[@value='MMM']";
	@FindBy(xpath = THREEDIGITMONTHFORMAT_XPATH)
	private WebElement threeDigitMonthFormat;

	public final static String OBJFIELDNAME_ID = "SCG_FORM_FIELD";
	@FindBy(id = OBJFIELDNAME_ID)
	private WebElement objFieldName;

	private final static String USEROBJFIELDNAME_ID = "SCG_USER_OBJ_FIELD";
	@FindBy(id = USEROBJFIELDNAME_ID)
	private WebElement userObjFieldName;

	public final static String OKBTN_ID = "ADD_COMPONENT_TO_GRID_BTN";
	@FindBy(id = OKBTN_ID)
	private WebElement okBtn;

	public final static String POPUPCANCELBTN_ID = "CANCEL_POPUP";
	@FindBy(id = POPUPCANCELBTN_ID)
	private WebElement popupCancelBtn;

	public void addSeqCode(String[] scdata) throws Exception {
		waitForElementId(MBU_ID);
		sleepVeryShort();
		if (Boolean.valueOf(scdata[8])) {
			sleepVeryShort();
			applToAllMbu.click();

		} else {
			new Select(mbu).selectByVisibleText(scdata[0]);
		}
		waitForElementId(MODULENAME_ID);
		sleepVeryShort();
		new Select(moduleName).selectByVisibleText(scdata[1]);
		waitForElementId(CODENAME_ID);
		sleepVeryShort();
		new Select(codeName).selectByVisibleText(scdata[2]);
		codingPattern_system.click();
		new Select(sequenceSeparator).selectByVisibleText(scdata[3]);
		addComponentBtn.click();
		sleepVeryShort();
		waitForElementId(COMPONENTPOPUP_ID);
		sleepVeryShort();
		new Select(componentType).selectByVisibleText(scdata[4]);
		staticText.sendKeys(scdata[5]);
		okBtn.click();
		sleepVeryShort();
		addComponentBtn.click();
		sleepVeryShort();
		waitForElementId(COMPONENTPOPUP_ID);
		new Select(componentType).selectByVisibleText(scdata[6]);
		noOfDigits.sendKeys(scdata[7]);
		waitForElementId(INITIALVALUE_ID);
		if (!scdata[9].isEmpty()) {
			initialValue.clear();
			initialValue.sendKeys(scdata[9]);
		}
		okBtn.click();
		sleepVeryShort();
		saveBtn.click();
		sleepShort();
	}

	public void addNewSequenceCode() throws Exception {
		addNewSeqCodeBtn.click();
		sleepVeryShort();
	}

	public WebElement getSeqCodeDetailsForm() {
		return seqCodeDetailsForm;
	}

	public WebElement getAddNewSeqCodeBtn() {
		return addNewSeqCodeBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getApplToAllMbu() {
		return applToAllMbu;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getCodeName() {
		return codeName;
	}

	public WebElement getCodingPattern_manual() {
		return codingPattern_manual;
	}

	public WebElement getCodingPattern_system() {
		return codingPattern_system;
	}

	public WebElement getSequenceSeparator() {
		return sequenceSeparator;
	}

	public WebElement getSeqCodeComponentGrid() {
		return seqCodeComponentGrid;
	}

	public WebElement getAddComponentBtn() {
		return addComponentBtn;
	}

	public WebElement getUpBtn() {
		return upBtn;
	}

	public WebElement getDownBtn() {
		return downBtn;
	}

	public WebElement getComponentPopup() {
		return componentPopup;
	}

	public WebElement getComponentType() {
		return componentType;
	}

	public WebElement getStaticText() {
		return staticText;
	}

	public WebElement getNoOfDigits() {
		return noOfDigits;
	}

	public WebElement getInitialValue() {
		return initialValue;
	}

	public WebElement getTwoDigitYrFormat() {
		return twoDigitYrFormat;
	}

	public WebElement getFourDigitYrFormat() {
		return fourDigitYrFormat;
	}

	public WebElement getTwoDigitMonthFormat() {
		return twoDigitMonthFormat;
	}

	public WebElement getThreeDigitMonthFormat() {
		return threeDigitMonthFormat;
	}

	public WebElement getObjFieldName() {
		return objFieldName;
	}

	public WebElement getUserObjFieldName() {
		return userObjFieldName;
	}

	public WebElement getOkBtn() {
		return okBtn;
	}

	public WebElement getPopupCancelBtn() {
		return popupCancelBtn;
	}

	public boolean searchGridData(String seqCode) {
		boolean result = false;
		try {
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='CODE_SEQ_GRID_displayFormat' and @title='"
									+ seqCode.trim() + "']")).isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

}
