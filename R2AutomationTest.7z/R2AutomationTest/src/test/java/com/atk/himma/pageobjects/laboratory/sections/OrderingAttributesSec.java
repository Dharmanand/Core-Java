package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class OrderingAttributesSec extends DriverWaitClass {
	public final static String ORDATTRIBUTESSEC_XPATH = "//a[text()='Ordering Attributes']";
	@FindBy(xpath = ORDATTRIBUTESSEC_XPATH)
	private WebElement ordAttributesSec;

	public final static String CLINICALINFOCHKBOX_ID = "CLINIC_INFO";
	@FindBy(id = CLINICALINFOCHKBOX_ID)
	private WebElement clinicalInfoChkBox;

	public final static String FREQAVAILCHKBOX_ID = "FREQ_AVAILABLE";
	@FindBy(id = FREQAVAILCHKBOX_ID)
	private WebElement freqAvailChkBox;

	public final static String URGENCYMULTISELBOX_NAME = "multiselect_ORDERING_ATTR_URGENCY_ID";
	@FindBy(name = URGENCYMULTISELBOX_NAME)
	private WebElement urgencyMultiSelBox;

	public final static String SERVDEFPATTRADIO_XPATH = "//input[@name='LAB_LINKED_TASK_DEFIITION_TYPE' and @value='1']";
	@FindBy(xpath = SERVDEFPATTRADIO_XPATH)
	private WebElement servDefPattRadio;

	public final static String ITEMDEFPATTRADIO_XPATH = "//input[@name='LAB_LINKED_TASK_DEFIITION_TYPE' and @value='2']";
	@FindBy(xpath = ITEMDEFPATTRADIO_XPATH)
	private WebElement itemDefPattRadio;

	public final static String SERVITEMADDROWBTN_ID = "LAB_TEST_SERVICE_ITEM_ADD";
	@FindBy(id = SERVITEMADDROWBTN_ID)
	private WebElement servItemAddRowBtn;

	public final static String GRIDLOOKUP_XPATH = "//a[@class='lookup gridServiceItemSearchLookup customelement']";
	@FindBy(xpath = GRIDLOOKUP_XPATH)
	private WebElement gridLookUp;

	public final static String ADDSERVPOPUPFORM_ID = "LAB_TEST_ODR_ATR_ADD_SERVICE_FORM";
	@FindBy(id = ADDSERVPOPUPFORM_ID)
	private WebElement addServPopUpForm;

	public final static String ADDSERVPOPUPMBU_ID = "mbusId";
	@FindBy(id = ADDSERVPOPUPMBU_ID)
	private WebElement addServPopUpMbu;

	public final static String ADDSERVPOPUPGLOBALSERV_ID = "LAB_TEST_DETAILS_GLOBAL_SERVICE_SEARCH";
	@FindBy(id = ADDSERVPOPUPGLOBALSERV_ID)
	private WebElement addServPopUpGlobalServ;

	public final static String ADDSERVPOPUPDEPT_ID = "deptId";
	@FindBy(id = ADDSERVPOPUPDEPT_ID)
	private WebElement addServPopUpDept;

	public final static String ADDSERVPOPUPSPLTY_ID = "specId";
	@FindBy(id = ADDSERVPOPUPSPLTY_ID)
	private WebElement addServPopUpSplty;

	public final static String ADDSERVPOPUPSUBSPLTY_ID = "subSpecId";
	@FindBy(id = ADDSERVPOPUPSUBSPLTY_ID)
	private WebElement addServPopUpSubSplty;

	public final static String ADDSERVPOPUPSERVTYPE_ID = "ORDER_SERVICE_TYPE_ID";
	@FindBy(id = ADDSERVPOPUPSERVTYPE_ID)
	private WebElement addServPopUpServType_;

	public final static String ADDSERVPOPUPSERVCODE_NAME = "serviceSearchCriteria.serviceCode";
	@FindBy(name = ADDSERVPOPUPSERVCODE_NAME)
	private WebElement addServPopUpServCode;

	public final static String ADDSERVPOPUPSERVNAME_NAME = "serviceSearchCriteria.serviceName";
	@FindBy(name = ADDSERVPOPUPSERVNAME_NAME)
	private WebElement addServPopUpServName;

	public final static String ADDSERVPOPUPSEARCHBTN_ID = "LAB_TEST_ORDER_ATTR_SERVICE_SRCG_BUT";
	@FindBy(id = ADDSERVPOPUPSEARCHBTN_ID)
	private WebElement addServPopUpSearchBtn;

	public final static String ADDSERVPOPUPRESETBTN_XPATH = "//form[@id='LAB_TEST_ODR_ATR_ADD_SERVICE_FORM']//input[@value='Reset']";
	@FindBy(xpath = ADDSERVPOPUPRESETBTN_XPATH)
	private WebElement addServPopUpResetBtn;

	public final static String ADDSERVPOPUPSERVGRIDTBL_ID = "LAB_TEST_SERVICE_RESULT_GRID";
	@FindBy(id = ADDSERVPOPUPSERVGRIDTBL_ID)
	private WebElement addServPopUpServGridTbl;

	public final static String DURATION_NAME = "duration";
	@FindBy(name = DURATION_NAME)
	private WebElement duration;

	public final static String TIMEUNIT_NAME = "timeUnitId";
	@FindBy(name = TIMEUNIT_NAME)
	private WebElement timeUnit;

	public final static String EXECSTAGE_NAME = "executionStageId";
	@FindBy(name = EXECSTAGE_NAME)
	private WebElement execStage;

	public final static String QUANTITY_NAME = "quantity";
	@FindBy(name = QUANTITY_NAME)
	private WebElement quantity;

	public final static String ADDITEMPOPUPFORM_ID = "LAB_TEST_ODR_ATR_ADD_ITEM_FORM";
	@FindBy(id = ADDITEMPOPUPFORM_ID)
	private WebElement addItemPopUpForm;

	public final static String ADDITEMPOPUPFORM_MBU_NAME = "itemSearchCriteria.mbuId";
	@FindBy(name = ADDITEMPOPUPFORM_MBU_NAME)
	private WebElement addItemPopUpFormMbu;

	public final static String ADDITEMPOPUPFORM_ITEMTYPE_NAME = "itemSearchCriteria.itemTypeId";
	@FindBy(name = ADDITEMPOPUPFORM_ITEMTYPE_NAME)
	private WebElement addItemPopUpFormItemType;

	public final static String ADDITEMPOPUPFORM_ITEMCATEGORY_NAME = "itemSearchCriteria.itemCategoryId";
	@FindBy(name = ADDITEMPOPUPFORM_ITEMCATEGORY_NAME)
	private WebElement addItemPopUpFormItemCategory;

	public final static String ADDITEMPOPUPFORM_ITEMSUBCATEGORY_NAME = "itemSearchCriteria.itemSubCategoryId";
	@FindBy(name = ADDITEMPOPUPFORM_ITEMSUBCATEGORY_NAME)
	private WebElement addItemPopUpFormItemSubCategory;

	public final static String ADDITEMPOPUPFORM_ITEMCODE_NAME = "itemSearchCriteria.itemCode";
	@FindBy(name = ADDITEMPOPUPFORM_ITEMCODE_NAME)
	private WebElement addItemPopUpFormItemCode;

	public final static String ADDITEMPOPUPFORM_ITEMNAME_NAME = "itemSearchCriteria.itemName";
	@FindBy(name = ADDITEMPOPUPFORM_ITEMNAME_NAME)
	private WebElement addItemPopUpFormItemName;

	public final static String ADDITEMPOPUPFORM_ITEMSEARCHBTN_ID = "LAB_TEST_ORDER_ATTR_ITEM_SRCG_BUT";
	@FindBy(id = ADDITEMPOPUPFORM_ITEMSEARCHBTN_ID)
	private WebElement addItemPopUpFormItemSearchBtn;

	public final static String ADDITEMPOPUPFORM_ITEMRESETBTN_XPATH = "//form[@id='LAB_TEST_ODR_ATR_ADD_ITEM_FORM']//input[@value='Reset']";
	@FindBy(xpath = ADDITEMPOPUPFORM_ITEMRESETBTN_XPATH)
	private WebElement addItemPopUpFormItemResetBtn;

	public final static String ADDITEMPOPUPFORM_ITEMGRIDTBL_ID = "LAB_TEST_ITEM_RESULT_GRID";
	@FindBy(id = ADDITEMPOPUPFORM_ITEMGRIDTBL_ID)
	private WebElement addItemPopUpFormItemGridTbl;

	public final static String LABTESTSERVITEMGRIDTBL_ID = "LAB_TEST_SERVICE_ITEM_GRID";
	@FindBy(id = LABTESTSERVITEMGRIDTBL_ID)
	private WebElement labTestServItemGridTbl;

	public WebElement getOrdAttributesSec() {
		return ordAttributesSec;
	}

	public WebElement getClinicalInfoChkBox() {
		return clinicalInfoChkBox;
	}

	public WebElement getFreqAvailChkBox() {
		return freqAvailChkBox;
	}

	public WebElement getUrgencyMultiSelBox() {
		return urgencyMultiSelBox;
	}

	public WebElement getServDefPattRadio() {
		return servDefPattRadio;
	}

	public WebElement getItemDefPattRadio() {
		return itemDefPattRadio;
	}

	public WebElement getServItemAddRowBtn() {
		return servItemAddRowBtn;
	}

	public WebElement getGridLookUp() {
		return gridLookUp;
	}

	public WebElement getAddServPopUpForm() {
		return addServPopUpForm;
	}

	public WebElement getAddServPopUpMbu() {
		return addServPopUpMbu;
	}

	public WebElement getAddServPopUpGlobalServ() {
		return addServPopUpGlobalServ;
	}

	public WebElement getAddServPopUpDept() {
		return addServPopUpDept;
	}

	public WebElement getAddServPopUpSplty() {
		return addServPopUpSplty;
	}

	public WebElement getAddServPopUpSubSplty() {
		return addServPopUpSubSplty;
	}

	public WebElement getAddServPopUpServType_() {
		return addServPopUpServType_;
	}

	public WebElement getAddServPopUpServCode() {
		return addServPopUpServCode;
	}

	public WebElement getAddServPopUpServName() {
		return addServPopUpServName;
	}

	public WebElement getAddServPopUpSearchBtn() {
		return addServPopUpSearchBtn;
	}

	public WebElement getAddServPopUpResetBtn() {
		return addServPopUpResetBtn;
	}

	public WebElement getAddServPopUpServGridTbl() {
		return addServPopUpServGridTbl;
	}

	public WebElement getDuration() {
		return duration;
	}

	public WebElement getTimeUnit() {
		return timeUnit;
	}

	public WebElement getExecStage() {
		return execStage;
	}

	public WebElement getQuantity() {
		return quantity;
	}

	public WebElement getAddItemPopUpForm() {
		return addItemPopUpForm;
	}

	public WebElement getAddItemPopUpFormMbu() {
		return addItemPopUpFormMbu;
	}

	public WebElement getAddItemPopUpFormItemType() {
		return addItemPopUpFormItemType;
	}

	public WebElement getAddItemPopUpFormItemCategory() {
		return addItemPopUpFormItemCategory;
	}

	public WebElement getAddItemPopUpFormItemSubCategory() {
		return addItemPopUpFormItemSubCategory;
	}

	public WebElement getAddItemPopUpFormItemCode() {
		return addItemPopUpFormItemCode;
	}

	public WebElement getAddItemPopUpFormItemName() {
		return addItemPopUpFormItemName;
	}

	public WebElement getAddItemPopUpFormItemSearchBtn() {
		return addItemPopUpFormItemSearchBtn;
	}

	public WebElement getAddItemPopUpFormItemResetBtn() {
		return addItemPopUpFormItemResetBtn;
	}

	public WebElement getAddItemPopUpFormItemGridTbl() {
		return addItemPopUpFormItemGridTbl;
	}

	public WebElement getLabTestServItemGridTbl() {
		return labTestServItemGridTbl;
	}

}
