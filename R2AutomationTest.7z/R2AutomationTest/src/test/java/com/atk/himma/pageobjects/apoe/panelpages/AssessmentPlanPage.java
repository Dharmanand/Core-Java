package com.atk.himma.pageobjects.apoe.panelpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AssessmentPlanPage extends DriverWaitClass {
	public final static String DIAGASSESSTAB_XPATH = ".//a[@href='#DIAGNOSIS_DIV']";
	@FindBy(xpath = DIAGASSESSTAB_XPATH)
	private WebElement diagAssessTab;

	public final static String PLANTAB_XPATH = ".//a[@href='#Plan']";
	@FindBy(xpath = PLANTAB_XPATH)
	private WebElement planTab;

	public final static String DIAGSAVEBTN_XPATH = ".//form[@id='CONSULTATION_DIAGNOSIS_FORM']/..//input[@value='Save']";
	@FindBy(xpath = DIAGSAVEBTN_XPATH)
	private WebElement diagSaveBtn;

	public final static String DIAGUPDATEBTN_XPATH = ".//form[@id='CONSULTATION_DIAGNOSIS_FORM']/..//input[@value='Update']";
	@FindBy(xpath = DIAGUPDATEBTN_XPATH)
	private WebElement diagUpdateBtn;

	public final static String DIAGCANCELBTN_XPATH = ".//form[@id='CONSULTATION_DIAGNOSIS_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = DIAGCANCELBTN_XPATH)
	private WebElement diagCancelBtn;

	public final static String PLANSAVEBTN_XPATH = ".//form[@id='CONSULTATION_PLAN_FORM']/..//input[@value='Save']";
	@FindBy(xpath = PLANSAVEBTN_XPATH)
	private WebElement planSaveBtn;

	public final static String PLANUPDATEBTN_XPATH = ".//form[@id='CONSULTATION_PLAN_FORM']/..//input[@value='Update']";
	@FindBy(xpath = PLANUPDATEBTN_XPATH)
	private WebElement planUpdateBtn;

	public final static String PLANCANCELBTN_XPATH = ".//form[@id='CONSULTATION_PLAN_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = PLANCANCELBTN_XPATH)
	private WebElement planCancelBtn;

	public final static String SEARCHICDTAB_XPATH = ".//a[@href='#SEARCH_ICD_MATRIX_DIV']";
	@FindBy(xpath = SEARCHICDTAB_XPATH)
	private WebElement searchICDTab;

	public final static String MYICDICDTAB_XPATH = ".//a[@href='#MY_ICD']";
	@FindBy(xpath = MYICDICDTAB_XPATH)
	private WebElement myICDTab;

	public final static String MANUALICDICDTAB_XPATH = ".//a[@href='#MANUAL_ICD_MATRIX_DIV']";
	@FindBy(xpath = MANUALICDICDTAB_XPATH)
	private WebElement manualICDTab;

	public final static String SEARCHICDTEXTBOX_ID = "SEARCH_ICD_TEXT_FIELD";
	@FindBy(id = SEARCHICDTEXTBOX_ID)
	private WebElement searchICDTextBox;

	public final static String SEARCHICDBTN_ID = "SEARCH_ICD_BUTTON";
	@FindBy(id = SEARCHICDBTN_ID)
	private WebElement searchICDBtn;

	public final static String ICDCHILDGRIDTBL_ID = "SEARCH_ICD_CHILD_GRID";
	@FindBy(id = ICDCHILDGRIDTBL_ID)
	private WebElement icdChildGridTbl;

	public final static String ADDTOMYICDSCHKBOX_ID = "ADD_TO_FAVORITE_CK";
	@FindBy(id = ADDTOMYICDSCHKBOX_ID)
	private WebElement addToMyICDsChkBox;

	public final static String ADDSICDDIAGNOSISBTN_ID = "ADD_DIAGNOSIS_FROM_SEARCH_ICD_BUT";
	@FindBy(id = ADDSICDDIAGNOSISBTN_ID)
	private WebElement addSearchICDDiagBtn;

	public final static String DIAGNOSISGRIDTBL_ID = "DIAGNOSIS_LOG_GRID";
	@FindBy(id = DIAGNOSISGRIDTBL_ID)
	private WebElement diagGridTbl;

	public final static String ADDMYICDDIAGBTN_ID = "ADD_DIAGNOSIS_FROM_MY_ICD";
	@FindBy(id = ADDMYICDDIAGBTN_ID)
	private WebElement addMyICDDiagBtn;

	public final static String MANUALICDTEXT_ID = "MANUAL_ICD_TEXT_ID";
	@FindBy(id = MANUALICDTEXT_ID)
	private WebElement manualICDText;

	public final static String ADDMANUALICDDIAGBTN_ID = "ADD_DIAGNOSIS_FROM_MANUAL_ICD";
	@FindBy(id = ADDMANUALICDDIAGBTN_ID)
	private WebElement addManualICDDiagBtn;

	public final static String ASSESSMENT_NAME = "consultationSummary.assessmentDiagnosis.assessment";
	@FindBy(name = ASSESSMENT_NAME)
	private WebElement assessment;
	
	public void clickPlanTab() throws Exception {
		planTab.click();
		sleepVeryShort();
		waitForElementXpathExpression(PLANSAVEBTN_XPATH);

	}
	
	public void savePlanDetails() throws Exception {
		planSaveBtn.click();
		sleepVeryShort();
		waitForElementXpathExpression(PLANUPDATEBTN_XPATH);
	}

	public WebElement getDiagAssessTab() {
		return diagAssessTab;
	}

	public WebElement getPlanTab() {
		return planTab;
	}

	public WebElement getDiagSaveBtn() {
		return diagSaveBtn;
	}

	public WebElement getDiagUpdateBtn() {
		return diagUpdateBtn;
	}

	public WebElement getDiagCancelBtn() {
		return diagCancelBtn;
	}

	public WebElement getPlanSaveBtn() {
		return planSaveBtn;
	}

	public WebElement getPlanUpdateBtn() {
		return planUpdateBtn;
	}

	public WebElement getPlanCancelBtn() {
		return planCancelBtn;
	}

	public WebElement getSearchICDTab() {
		return searchICDTab;
	}

	public WebElement getMyICDTab() {
		return myICDTab;
	}

	public WebElement getManualICDTab() {
		return manualICDTab;
	}

	public WebElement getSearchICDTextBox() {
		return searchICDTextBox;
	}

	public WebElement getSearchICDBtn() {
		return searchICDBtn;
	}

	public WebElement getIcdChildGridTbl() {
		return icdChildGridTbl;
	}

	public WebElement getAddToMyICDsChkBox() {
		return addToMyICDsChkBox;
	}

	public WebElement getAddSearchICDDiagBtn() {
		return addSearchICDDiagBtn;
	}

	public WebElement getDiagGridTbl() {
		return diagGridTbl;
	}

	public WebElement getAddMyICDDiagBtn() {
		return addMyICDDiagBtn;
	}

	public WebElement getManualICDText() {
		return manualICDText;
	}

	public WebElement getAddManualICDDiagBtn() {
		return addManualICDDiagBtn;
	}

	public WebElement getAssessment() {
		return assessment;
	}

}
