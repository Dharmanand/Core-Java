package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ApplicationUserListTab extends DriverWaitClass {

	public final static String APPUSERLISTFORM_ID = "empList";
	
	@FindBy(id = APPUSERLISTFORM_ID)
	private WebElement appUserListForm;
	
	public final static String APPUSERLIST_XPATH = "//a[@title='Application User List']";
	@FindBy(xpath = APPUSERLIST_XPATH)
	private WebElement appUserListTab;

	public final static String ADDNEWAPPUSERBTN_ID = "newEmpAddButton";
	@FindBy(id = ADDNEWAPPUSERBTN_ID)
	private WebElement addNewAppUserBtn;

	public final static String ORGUNITLOOKUP_XPATH = "//input[@id='orgUnitText']/../a[@title='Organization Unit Search']";
	@FindBy(xpath = ORGUNITLOOKUP_XPATH)
	private WebElement orgUnitLookup;

	public final static String DEPARTMENT_ID = "DEPARTMENT_LIST_TAB1";
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	public final static String RESOURCECATEGORY_ID = "RESOURCE_CATEGORY_TAB1";
	@FindBy(id = RESOURCECATEGORY_ID)
	private WebElement resourceCategory;

	public final static String RESOURCETYPE_ID = "RESOURCE_TYPE_TAB1";
	@FindBy(id = RESOURCETYPE_ID)
	private WebElement resourceType;

	public final static String APPUSERCODE_ID = "EMPLOYEE_ID";
	@FindBy(id = APPUSERCODE_ID)
	private WebElement appUserCode;

	public final static String LOGINNAME_ID = "LOGIN_NAME_ID";
	@FindBy(id = LOGINNAME_ID)
	private WebElement loginName;

	public final static String APPUSERNAME_ID = "EMPLOYEE_NAME";
	@FindBy(id = APPUSERNAME_ID)
	private WebElement appUserName;

	public final static String STATUS_ID = "EMPLOYEE_STATUS";
	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String SEARCHBTN_XPATH = "//form[@id='empList']//input[@value='Search']";
	@FindBy(xpath = SEARCHBTN_XPATH)
	private WebElement searchBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String APPUSERGRID_ID = "gbox_EMP_SEARCH_GRID";
	@FindBy(id = APPUSERGRID_ID)
	private WebElement appUserGrid;

	public final static String CONFIRMATIONMSG_ID = "ConfirmationMessage";
	@FindBy(id = CONFIRMATIONMSG_ID)
	private WebElement confirmMsg;

	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";
	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public final static String VIEWLINK_XPATH = ".//table[@id='EMP_SEARCH_GRID']/..//a[text()='View']";
	@FindBy(xpath = VIEWLINK_XPATH)
	private WebElement viewLink;

	public final static String EDITLINK_XPATH = ".//table[@id='EMP_SEARCH_GRID']/..//a[text()='Edit']";
	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	public final static String DELETELINK_XPATH = ".//table[@id='EMP_SEARCH_GRID']/..//a[text()='Delete']";
	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public void clickAddNewAppUser() throws Exception {
		addNewAppUserBtn.click();
		sleepShort();
	}

	public void searchAppUser(String[] userData) throws Exception {
		OrgUnitSearchPopupPage popupPage = PageFactory.initElements(webDriver,
				OrgUnitSearchPopupPage.class);
		popupPage.setWebDriver(webDriver);
		popupPage.setWebDriverWait(webDriverWait);
		waitForElementXpathExpression(ORGUNITLOOKUP_XPATH);
		orgUnitLookup.click();
		sleepShort();
		popupPage.searchUnit(userData[21], userData[20], null);
		sleepShort();
		if (!userData[25].isEmpty()) {
			new Select(resourceCategory).selectByVisibleText(userData[25]);
		}
		waitForElementId(RESOURCETYPE_ID);
		sleepVeryShort();
		if (!userData[26].isEmpty()) {
			new Select(resourceType).selectByVisibleText(userData[26]);
		}
		loginName.clear();
		loginName.sendKeys(userData[37]);

		appUserName.clear();
		appUserName.sendKeys(userData[3] + " " + userData[9]);

		searchBtn.click();
		sleepShort();
	}
	
	public void privSearchAppUser(String[] userData) throws Exception {
		loginName.clear();
		loginName.sendKeys(userData[37]);
		
		appUserName.clear();
		appUserName.sendKeys(userData[3] + " " + userData[9]);
		
		searchBtn.click();
		sleepShort();
	}

	public void clickOnEdit(String[] editUserData) throws Exception {
		clickOnGridAction("EMP_SEARCH_GRID_resourceName.fullName",
				editUserData[3] + " " + editUserData[9], "Edit");
		sleepShort();
	}

	public void clickOnDelete(String[] appUserData) throws Exception {
		clickOnGridAction("EMP_SEARCH_GRID_resourceName.fullName",
				appUserData[3] + " " + appUserData[9], "Delete");
		waitForElementId(CONFIRMATIONMSG_ID);
		confirmYes.click();
		sleepShort();
	}

	public boolean searchGridData(String[] appUserName) {
		boolean result = false;
		try {
			waitForElementXpathExpression("//td[@aria-describedby='EMP_SEARCH_GRID_resourceName.fullName' and @title='"
					+ appUserName[3].trim()
					+ " "
					+ appUserName[9].trim()
					+ "']");
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='EMP_SEARCH_GRID_resourceName.fullName' and @title='"
									+ appUserName[3].trim()
									+ " "
									+ appUserName[9].trim() + "']"))
					.isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

	public WebElement getAppUserListForm() {
		return appUserListForm;
	}

	public WebElement getAddNewAppUserBtn() {
		return addNewAppUserBtn;
	}

	public WebElement getOrgUnitLookup() {
		return orgUnitLookup;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	public WebElement getResourceType() {
		return resourceType;
	}

	public WebElement getAppUserCode() {
		return appUserCode;
	}

	public WebElement getLoginName() {
		return loginName;
	}

	public WebElement getAppUserName() {
		return appUserName;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getAppUserGrid() {
		return appUserGrid;
	}

	public WebElement getConfirmMsg() {
		return confirmMsg;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

	public WebElement getViewLink() {
		return viewLink;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

	/**
	 * @return the appUserListTab
	 */
	public WebElement getAppUserListTab() {
		return appUserListTab;
	}

}
