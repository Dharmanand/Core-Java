package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LabTestDetailsDefaultSec extends DriverWaitClass {
	public final static String LABTESTDTLSAVEBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	@FindBy(xpath = LABTESTDTLSAVEBTN_XPATH)
	private WebElement labTestDtlSaveBtn;

	public final static String LABTESTDTLUPDATEBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	@FindBy(xpath = LABTESTDTLUPDATEBTN_XPATH)
	private WebElement labTestDtlUpdateBtn;

	public final static String LABTESTDTLCANCELBTN_ID = "LAB_TEST_DET_CANCEL_BUT_UP";
	@FindBy(id = LABTESTDTLCANCELBTN_ID)
	private WebElement labTestDtlCancelBtn;

	public final static String SERVICECODE_NAME = "labTest.serviceCode";
	@FindBy(name = SERVICECODE_NAME)
	private WebElement serviceCode;

	public final static String SERVICECODESHNAME_NAME = "labTest.serviceShortName";
	@FindBy(name = SERVICECODESHNAME_NAME)
	private WebElement serviceCodeShName;

	public final static String SERVICENAME_NAME = "labTest.serviceName";
	@FindBy(name = SERVICENAME_NAME)
	private WebElement serviceName;

	public final static String SERVICEDESC_NAME = "labTest.serviceDesc";
	@FindBy(name = SERVICEDESC_NAME)
	private WebElement serviceDesc;

	public final static String SERVICECLASS_ID = "LAB_TEST_SERVICE_CLASS_ID";
	@FindBy(id = SERVICECLASS_ID)
	private WebElement serviceClass;

	public final static String SPECIALTY_ID = "LAB_TEST_DETAILS_SPEC_ID";
	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;

	public final static String SUBSPECIALTY_ID = "LAB_TEST_DETAILS_SUB_SPEC_ID";
	@FindBy(id = SUBSPECIALTY_ID)
	private WebElement subSpecialty;

	public final static String STATUS_NAME = "labTest.status";
	@FindBy(name = STATUS_NAME)
	private WebElement status;

	public final static String DEPARTMENT_ID = "LABTEST_DETAILS_DEPTID";
	@FindBy(name = DEPARTMENT_ID)
	private WebElement department;

	public WebElement getLabTestDtlSaveBtn() {
		return labTestDtlSaveBtn;
	}

	public WebElement getLabTestDtlUpdateBtn() {
		return labTestDtlUpdateBtn;
	}

	public WebElement getLabTestDtlCancelBtn() {
		return labTestDtlCancelBtn;
	}

	public WebElement getServiceCode() {
		return serviceCode;
	}

	public WebElement getServiceCodeShName() {
		return serviceCodeShName;
	}

	public WebElement getServiceName() {
		return serviceName;
	}

	public WebElement getServiceDesc() {
		return serviceDesc;
	}

	public WebElement getServiceClass() {
		return serviceClass;
	}

	public WebElement getSpecialty() {
		return specialty;
	}

	public WebElement getSubSpecialty() {
		return subSpecialty;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getDepartment() {
		return department;
	}

}
