package com.atk.himma.pageobjects.sa;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class RecordStatus extends DriverWaitClass {
	private final static String MAINSTATUS_ID = "UPDATE_MAIN_STATUS";
	@FindBy(id = MAINSTATUS_ID)
	private WebElement mainStatus;

	private final static String MAINSTATUSTEXT_ID = "MAIN_STATUS_TEXT";
	@FindBy(id = MAINSTATUSTEXT_ID)
	private WebElement mainStatusText;

	private final static String EXPANDCOLLAPSE_XPATH = "//span[@title='Expand / Collapse']";
	@FindBy(xpath = EXPANDCOLLAPSE_XPATH)
	private WebElement expandCollapse;

	private final static String INACTIVEREASON_ID = "inactiveReason";
	@FindBy(id = INACTIVEREASON_ID)
	private WebElement inactiveReason;

	private final static String WORKINGSTATUS_ID = "WORKING_STATUS";
	@FindBy(id = WORKINGSTATUS_ID)
	private WebElement workingStatus;

	private final static String REASON_ID = "WORKSTATUS_REASON";
	@FindBy(id = REASON_ID)
	private WebElement reason;

	private final static String DESCRIPTION_ID = "RECORD_STATUS_DESC";
	@FindBy(id = DESCRIPTION_ID)
	private WebElement description;

	private final static String APPLYBTN_ID = "APPLY_RECORD";
	@FindBy(id = APPLYBTN_ID)
	private WebElement applyBtn;

	public void activateRecord() throws Exception {
		mainStatus.click();
		sleepShort();
	}

	public void InactivateRecord() throws Exception {
		expandCollapse.click();
		sleepVeryShort();
		new Select(inactiveReason).selectByVisibleText("Discontinued");
		mainStatus.click();
		sleepShort();
	}

	public static String getMainstatusId() {
		return MAINSTATUS_ID;
	}

	public static String getMainstatustextId() {
		return MAINSTATUSTEXT_ID;
	}

	public static String getExpandcollapseXpath() {
		return EXPANDCOLLAPSE_XPATH;
	}

	public static String getInactivereasonId() {
		return INACTIVEREASON_ID;
	}

	public static String getWorkingstatusId() {
		return WORKINGSTATUS_ID;
	}

	public static String getReasonId() {
		return REASON_ID;
	}

	public static String getDescriptionId() {
		return DESCRIPTION_ID;
	}

	public static String getApplybtnId() {
		return APPLYBTN_ID;
	}

	public WebElement getMainStatus() {
		return mainStatus;
	}

	public WebElement getMainStatusText() {
		return mainStatusText;
	}

	public WebElement getExpandCollapse() {
		return expandCollapse;
	}

	public WebElement getInactiveReason() {
		return inactiveReason;
	}

	public WebElement getWorkingStatus() {
		return workingStatus;
	}

	public WebElement getReason() {
		return reason;
	}

	public WebElement getDescription() {
		return description;
	}

	public WebElement getApplyBtn() {
		return applyBtn;
	}

}
