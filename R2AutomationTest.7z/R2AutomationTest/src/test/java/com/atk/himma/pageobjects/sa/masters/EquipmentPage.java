package com.atk.himma.pageobjects.sa.masters;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.masters.tabs.EquipmentDetailsTab;
import com.atk.himma.pageobjects.sa.masters.tabs.EquipmentListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class EquipmentPage extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	private EquipmentListTab equipmentListTab;
	private EquipmentDetailsTab equipmentDetailsTab;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		equipmentListTab = PageFactory.initElements(webDriver,
				EquipmentListTab.class);
		equipmentListTab.setWebDriver(webDriver);
		equipmentListTab.setWebDriverWait(webDriverWait);

		equipmentDetailsTab = PageFactory.initElements(webDriver,
				EquipmentDetailsTab.class);
		equipmentDetailsTab.setWebDriver(webDriver);
		equipmentDetailsTab.setWebDriverWait(webDriverWait);

	}

	public EquipmentPage clickOnEquipMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuList.add("Resource ");
		menuSelector.clickOnTargetMenu(menuList, "Equipment");
		EquipmentPage equipment = PageFactory.initElements(webDriver,
				EquipmentPage.class);
		equipment.setWebDriver(webDriver);
		equipment.setWebDriverWait(webDriverWait);
		return equipment;
	}

	public boolean clickOnAddNewEquipment(String[] equipDatas)
			throws InterruptedException {
		waitForElementXpathExpression(EquipmentListTab.ADDNEWBUTTON_XPATH);
		sleepVeryShort();
		equipmentListTab.getAddNewEquipButton().click();
		waitForElementId(EquipmentListTab.MBU_ID);
		sleepVeryShort();
		return new Select(equipmentDetailsTab.getMbu())
				.getFirstSelectedOption().getText().trim()
				.equals(equipDatas[0].trim());
	}

	public String saveDetailsPage() throws InterruptedException, IOException {
		waitForElementXpathExpression(EquipmentDetailsTab.SAVEBUTTON_XPATH);
		equipmentDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(EquipmentDetailsTab.UPDATEBUTTON_XPATH);
		sleepVeryShort();
		return equipmentDetailsTab.getSaveButton().getAttribute("value").trim();
	}

	public String updateDetailsPage() throws InterruptedException, IOException {
		waitForElementXpathExpression(EquipmentDetailsTab.UPDATEBUTTON_XPATH);
		equipmentDetailsTab.getUpdateButton().click();
		waitForPageLoaded(webDriver);
		waitForElementXpathExpression(EquipmentDetailsTab.UPDATEBUTTON_XPATH);
		sleepVeryShort();
		return equipmentDetailsTab.getSaveButton().getAttribute("value").trim();
	}

	public String activateEquipDetails() throws InterruptedException, IOException {

		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);

	}

	/**
	 * @return the equipmentList
	 */
	public EquipmentListTab getEquipmentListTab() {
		return equipmentListTab;
	}

	/**
	 * @return the equipmentDetails
	 */
	public EquipmentDetailsTab getEquipmentDetailsTab() {
		return equipmentDetailsTab;
	}

}
