package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.sa.OrganizationHierarchyPage;
import com.atk.himma.pageobjects.sa.tabs.OrganizationHierarchyTab;
import com.atk.himma.pageobjects.sa.tabs.RootOrganizationTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class OrgHierarchyTest extends SeleniumDriverSetup {
	OrganizationHierarchyPage organizationHierarchyPage;
	LoginPage loginPage;
	List<String[]> saOrgStructList;
	List<String[]> saEditConstraintsList;
	List<String[]> editOrgStructList;

	@Test(description = "Open Org Hierarchy Page")
	public void openOrgHierarchy() throws Exception {
		organizationHierarchyPage = PageFactory.initElements(webDriver,
				OrganizationHierarchyPage.class);
		organizationHierarchyPage = organizationHierarchyPage
				.clickOnOrganizationHierarchyMenu(webDriver, webDriverWait);
		organizationHierarchyPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		Assert.assertNotNull(organizationHierarchyPage);
		organizationHierarchyPage
				.waitForElementVisibilityOf(organizationHierarchyPage
						.getRootOrganizationTab().getRootOrgForm());
	}

	@Test(description = "Edit Root Organization", dependsOnMethods = { "openOrgHierarchy" })
	public void editRootOrg() throws Exception {
		saOrgStructList = excelReader.read(properties.getProperty("rootOrgInfos").trim());
		for (String[] st : saOrgStructList) {
			organizationHierarchyPage.getRootOrganizationTab().editRootName(st);
			Assert.assertNotNull(organizationHierarchyPage
					.getRootOrganizationTab().getUpdatedUnitName());
			String actual = organizationHierarchyPage.getRootOrganizationTab()
					.getUpdatedUnitName().getAttribute("value");
			Assert.assertEquals(actual, st[0].trim());
		}
	}

	/*@Test(description = "Mark Root As MBU", dependsOnMethods = { "openOrgHierarchy" })
	public void markRootAsMBU() throws Exception {
		Assert.assertNotNull(organizationHierarchyPage.getRootOrganizationTab()
				.getMbu());
		organizationHierarchyPage.getRootOrganizationTab().markAsMbu();
		Assert.assertNotNull(organizationHierarchyPage.getRootOrganizationTab()
				.getChecked());
	}*/

	@Test(description = "Assign Org Hierarchy Constraints", dependsOnMethods = { "openOrgHierarchy" })
	public void assignOrgHierarchyConstraints() throws Exception {
		List<String[]> saAddConstraintsList = excelReader
				.read(properties.getProperty("addConstraints").trim());
		if (saAddConstraintsList != null && !saAddConstraintsList.isEmpty()) {
			Assert.assertNotNull(organizationHierarchyPage
					.getRootOrganizationTab()
					.getAssignOrgHierarchyConstraintsBtn());
			organizationHierarchyPage.getRootOrganizationTab()
					.clickOnAssignConstraints();
			organizationHierarchyPage
					.waitForElementVisibilityOf(organizationHierarchyPage
							.getRootOrganizationTab().getConstraintsPopup());

			for (String[] orgUnits : saAddConstraintsList) {
				organizationHierarchyPage.getRootOrganizationTab()
						.assignConstraints(orgUnits);
				/*
				 * organizationHierarchyPage.getRootOrganizationTab()
				 * .waitForElementVisibilityOf( organizationHierarchyPage
				 * .getRootOrganizationTab() .getConstraintsGrid());
				 */
				Assert.assertTrue(organizationHierarchyPage
						.getRootOrganizationTab().searchGridData(orgUnits[0],
								orgUnits[1]));
			}
			organizationHierarchyPage.getRootOrganizationTab()
					.closeConstraints();
		}
	}

	@Test(description = "Edit Org Hierarchy Constraints", dependsOnMethods = { "assignOrgHierarchyConstraints" })
	public void editOrgHierarchyConstraints() throws Exception {
		saEditConstraintsList = excelReader.read(properties.getProperty("editConstraints").trim());
		if (saEditConstraintsList != null && !saEditConstraintsList.isEmpty()) {
			organizationHierarchyPage.getRootOrganizationTab()
					.clickOnAssignConstraints();
			organizationHierarchyPage.getRootOrganizationTab()
					.waitForElementVisibilityOf(
							organizationHierarchyPage.getRootOrganizationTab()
									.getConstraintsPopup());
			for (String[] orgUnits : saEditConstraintsList.subList(0, 3)) {
				organizationHierarchyPage.getRootOrganizationTab()
						.editConstraints(orgUnits);
				organizationHierarchyPage.getRootOrganizationTab()
						.waitForElementVisibilityOf(
								organizationHierarchyPage
										.getRootOrganizationTab()
										.getConstraintsGrid());
				Assert.assertTrue(organizationHierarchyPage
						.getRootOrganizationTab().searchGridData(orgUnits[0],
								orgUnits[1]));
			}
			organizationHierarchyPage.getRootOrganizationTab()
					.closeConstraints();
		}
	}

	@Test(description = "Delete Org Hierarchy Constraints", dependsOnMethods = { "assignOrgHierarchyConstraints" })
	public void deleteOrgHierarchyConstraints() throws Exception {
		saEditConstraintsList = excelReader.read(properties.getProperty("editConstraints").trim());
		if (saEditConstraintsList != null && !saEditConstraintsList.isEmpty()) {
			organizationHierarchyPage.getRootOrganizationTab()
					.clickOnAssignConstraints();
			organizationHierarchyPage.getRootOrganizationTab()
					.waitForElementId(RootOrganizationTab.CONSTRAINTSPOPUP_ID);
			organizationHierarchyPage.sleepVeryShort();
			for (String[] orgUnits : saEditConstraintsList.subList(3, 4)) {
				Assert.assertTrue(organizationHierarchyPage
						.getRootOrganizationTab().searchGridData(orgUnits[0],
								orgUnits[1]));
				organizationHierarchyPage.getRootOrganizationTab()
						.deleteConstraints(orgUnits);
				Assert.assertFalse(organizationHierarchyPage
						.getRootOrganizationTab().searchGridData(orgUnits[0],
								orgUnits[1]));
			}
			organizationHierarchyPage.getRootOrganizationTab()
					.closeConstraints();
		}
	}

	@Test(description = "Add Organization Unit", dependsOnMethods = {
			"editRootOrg", "assignOrgHierarchyConstraints" })
	public void addOrganizationUnit() throws Exception {
		saOrgStructList = excelReader.read(properties.getProperty("orgStruct").trim());
		if (saOrgStructList != null && !saOrgStructList.isEmpty()) {
			organizationHierarchyPage.getRootOrganizationTab()
					.navigateToOrgHierarchyTab();
			Assert.assertNotNull(organizationHierarchyPage
					.getOrganizationHierarchyTab().getRootOrganization());
			for (String[] orgStructData : saOrgStructList) {
				organizationHierarchyPage.getOrganizationHierarchyTab()
						.addOrgStructure(orgStructData);
				try {
					String expected = "Update";
					String actual = organizationHierarchyPage
							.getOrganizationHierarchyTab().getUpdateBtn()
							.getAttribute("value");
					Assert.assertEquals(actual, expected);
				} catch (Exception e) {
					Reporter.log("Element not Found......");
				}
			}
		}
	}

	@Test(description = "Modify Organization Unit", dependsOnMethods = { "addOrganizationUnit" })
	public void modifyOrganizationUnit() throws Exception {
		editOrgStructList = excelReader.read(properties.getProperty("editOrgStruct").trim());
		if (editOrgStructList != null && !editOrgStructList.isEmpty()) {
			for (String[] editOrgStructData : editOrgStructList.subList(1, 2)) {
				organizationHierarchyPage.getOrganizationHierarchyTab()
						.editOrgStructure(editOrgStructData);
				Assert.assertTrue(organizationHierarchyPage
						.getOrganizationHierarchyTab().getModifyUnitBtn()
						.isEnabled());
			}
		}
	}

	@Test(description = "Delete Organization Unit", dependsOnMethods = { "addOrganizationUnit" })
	public void deleteOrganizationUnit() throws Exception {
		editOrgStructList = excelReader.read(properties.getProperty("editOrgStruct").trim());
		if (editOrgStructList != null && !editOrgStructList.isEmpty()) {
			for (String[] deleteOrgStructData : editOrgStructList.subList(2, 3)) {
				organizationHierarchyPage.getOrganizationHierarchyTab()
						.deleteUnit(deleteOrgStructData);
				Assert.assertFalse(organizationHierarchyPage
						.getOrganizationHierarchyTab().getDeleteUnitBtn()
						.isEnabled());
			}
		}
	}

	@Test(description = "Sign Out", dependsOnMethods = "addOrganizationUnit")
	public void signOut() throws Exception {
		loginPage = organizationHierarchyPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "signOut")
	public void login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(2,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}

	// [Organization Hierarchy] Open Form
	@Test(description = "Check Org Hierarchy Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkOrgHierarchyMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		organizationHierarchyPage = PageFactory.initElements(webDriver,
				OrganizationHierarchyPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> orgParentMenuList = new LinkedList<String>();
		orgParentMenuList.add("System Administration");
		menuSelector.mouseOverOnTargetMenu(orgParentMenuList,
				"Organization Hierarchy");
		organizationHierarchyPage.setWebDriver(webDriver);
		organizationHierarchyPage.setWebDriverWait(webDriverWait);
		organizationHierarchyPage
				.waitForElementXpathExpression(OrganizationHierarchyPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Organization Unit")
				.get("[Organization Hierarchy] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(OrganizationHierarchyPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Organization Hierarchy] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			organizationHierarchyPage = organizationHierarchyPage
					.clickOnOrganizationHierarchyMenu(webDriver, webDriverWait);
			organizationHierarchyPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(organizationHierarchyPage);
			organizationHierarchyPage
					.waitForElementVisibilityOf(organizationHierarchyPage
							.getRootOrganizationTab().getRootOrgForm());
			organizationHierarchyPage.sleepShort();
			Assert.assertEquals(organizationHierarchyPage.getPageTitle()
					.getText(), "Organization Hierarchy");
		}
	}

	// [Root Organization Tab] Edit Root (Button)
	@Test(description = "Check Edit Root Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkOrgHierarchyMenuLink")
	public void checkEditRootButton() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Organization Unit")
				.get("[Root Organization Tab] Edit Root (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(RootOrganizationTab.EDITBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Root Organization Tab] Edit Root (Button) privilege");
	}

	// [Root Organization Tab] Manage (assign, edit, delete) Organization
	// Hierarchy Constraints (Button)
	@Test(description = "Check Organization Hierarchy Constraints Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkOrgHierarchyMenuLink")
	public void checkOrgHierarchyConstraintsBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Organization Unit")
				.get("[Root Organization Tab] Manage (assign, edit, delete) Organization Hierarchy Constraints (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(RootOrganizationTab.ASSIGNORGHIERARCHYCONSTRAINTSBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Root Organization Tab] Manage (assign, edit, delete) Organization Hierarchy Constraints (Button) privilege");
	}

	// [Organization Hierarchy Tab] View Organization Hierarchy
	@Test(description = "Check View Organization Hierarchy Tab", groups = "checkPrivilegesGrp", dependsOnMethods = "checkOrgHierarchyMenuLink")
	public void checkViewOrgHierarchyTab() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Organization Unit")
				.get("[Organization Hierarchy Tab] View Organization Hierarchy");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RootOrganizationTab.ORGHIERARCHYTAB_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Organization Hierarchy Tab] View Organization Hierarchy privilege");
		organizationHierarchyPage.getRootOrganizationTab()
				.navigateToOrgHierarchyTab();
	}

	// [Organization Hierarchy Tab] Add Organization Units (Button)
	@Test(description = "Check Add Organization Units Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkViewOrgHierarchyTab")
	public void checkAddOrgUnitsBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Organization Unit")
				.get("[Organization Hierarchy Tab] Add Organization Units (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(OrganizationHierarchyTab.ADDUNITBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Organization Hierarchy Tab] Add Organization Units (Button) privilege");
	}

	// [Organization Hierarchy Tab] Modify Organization Units (Button)
	@Test(description = "Check Modify Organization Units Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkViewOrgHierarchyTab")
	public void checkModifyOrgUnitsBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Organization Unit")
				.get("[Organization Hierarchy Tab] Modify Organization Units (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(OrganizationHierarchyTab.MODIFYUNITBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Organization Hierarchy Tab] Modify Organization Units (Button) privilege");
	}

	// [Organization Hierarchy Tab] Delete Organization Units (Button)
	@Test(description = "Check Delete Organization Units Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkViewOrgHierarchyTab")
	public void checkDeleteOrgUnitsBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Organization Unit")
				.get("[Organization Hierarchy Tab] Delete Organization Units (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(OrganizationHierarchyTab.DELETEUNITBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Organization Hierarchy Tab] Delete Organization Units (Button) privilege");
	}

	// [Organization Hierarchy Tab] Manage Main Business Unit (Button)
	@Test(description = "Check Manage Main Business Units Button", groups = "checkPrivilegesGrp", dependsOnMethods = "checkViewOrgHierarchyTab")
	public void checkManageMBUBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Organization Unit")
				.get("[Organization Hierarchy Tab] Manage Main Business Unit (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(OrganizationHierarchyTab.MANAGEMBUBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Organization Hierarchy Tab] Manage Main Business Unit (Button) privilege");
	}

}
