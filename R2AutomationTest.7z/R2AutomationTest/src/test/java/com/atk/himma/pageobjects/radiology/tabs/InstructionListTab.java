package com.atk.himma.pageobjects.radiology.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class InstructionListTab extends DriverWaitClass {

	public final static String FORM_ID = "instrSearchId";
	public final static String QUICKSEARCHTXT_ID = "instrSearchField";
	public final static String SEARCHBUTTON_ID = "instrSearchBtn";
	public final static String ADVSEARCHBUTTON_ID = "INSTR_ADV_SEARCH";
	public final static String ADDNEWINSTRUBUTTON_ID = "addNew";
	public final static String EXPORTTOEXCELBUTTON_ID = "instrucionlist_grid_export_btn";
	public final static String GRID_ID = "instrucionlist_grid";
	public final static String GRID_INSTRCODE_ARIA_DESCRIBEDBY = "instrucionlist_grid_instrCode";
	public final static String GRID_INSTRUSHORTNAME_ARIA_DESCRIBEDBY = "instrucionlist_grid_instrShortName";
	public final static String GRID_INSTRUDESCRIPTION_ARIA_DESCRIBEDBY = "instrucionlist_grid_instrDesc";
	public final static String GRID_INSTRUTYPE_ARIA_DESCRIBEDBY = "instrucionlist_grid_instrTypeText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "instrucionlist_grid_mainStatusText";
	public final static String GRID_PAGERID = "sp_1_instrucionlist_grid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_instrucionlist_grid_pager']";	
	
	@FindBy(id=FORM_ID)
	private WebElement form;
	
	@FindBy(id=QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;
	
	@FindBy(id=SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(id=ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(id=ADDNEWINSTRUBUTTON_ID)
	private WebElement addNewInstruButton;
	
	@FindBy(id=EXPORTTOEXCELBUTTON_ID)
	private WebElement exportToExcelButton;
	
	public WebElement getForm() {
		return form;
	}

	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	public WebElement getAddNewInstruButton() {
		return addNewInstruButton;
	}

	public WebElement getExportToExcelButton() {
		return exportToExcelButton;
	}

}
