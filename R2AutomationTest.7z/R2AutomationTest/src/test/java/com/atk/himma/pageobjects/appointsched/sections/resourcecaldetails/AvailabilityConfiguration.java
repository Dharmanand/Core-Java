package com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AvailabilityConfiguration extends DriverWaitClass{

	public final static String SECTIONNAME_LINKTEXT = "Availability Configuration";
	public final static String ADDAVAILBUTTON_ID = "addConfigToGridButton";
	public final static String VIEWCALBUTTON_ID = "VIEW_CALENDAR_LINK3";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Availability Configuration')]/..";
	
//	
	public final static String FROMDATE_ID = "calConfFromDateDP";
	public final static String TODATE_ID = "calConfToDateDP";
	public final static String SELALLWORKDAYS_ID = "selectAllCheckbox";
	public final static String APPLICABLEDAYS_ID = "multiselect_calConfDayDD";
	public final static String SESSION_ID = "calConfSessionDD";
	public final static String STTIME_ID = "calConfStartTimeTP";
	public final static String ENDTIME_ID = "calConfEndTimeTP";
	public final static String RECURRENCE_ID = "calConfRecurDD";

	public final static String ADDBUTTON_ID = "CAL_CONFIG_SAVE_BUTTON";
	public final static String CANCELBUTTON_ID = "CAL_CONFIG_CANCEL_BUTTON";
	
//	Grid
	public final static String GRIDID_ID = "calendarConfigGrid";
	public final static String GRID_FROMDATE_ID = "calendarConfigGrid_fromDate";
	public final static String GRID_TODATE_ID = "calendarConfigGrid_toDate";
	public final static String GRID_SESSION_ARIA_DESCRIBEDBY = "calendarConfigGrid_calendarSession.sessionName";
	public final static String GRID_STARTTIME_ARIA_DESCRIBEDBY = "calendarConfigGrid_sessionStartTime";
	public final static String GRID_ENDTIME_ARIA_DESCRIBEDBY = "calendarConfigGrid_sessionEndTime";
	public final static String GRID_APPLICDAYS_ARIA_DESCRIBEDBY = "calendarConfigGrid_dayNames";
	public final static String GRID_RECURRENCE_ARIA_DESCRIBEDBY = "calendarConfigGrid_recurrence";
	public final static String GRID_PAGERID = "sp_1_calendarConfigGrid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_calendarConfigGrid_pager']";
	
//	Pop Up End

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = ADDAVAILBUTTON_ID)
	private WebElement addAvailButton;
	
	@FindBy(id = VIEWCALBUTTON_ID)
	private WebElement viewCalButton;
	
	@FindBy(id = FROMDATE_ID)
	private WebElement fromDate;
	
	@FindBy(id = TODATE_ID)
	private WebElement toDate;
	
	@FindBy(id = SELALLWORKDAYS_ID)
	private WebElement selAllWorkDays;
	
	@FindBy(id = APPLICABLEDAYS_ID)
	private WebElement applicableDays;
	
	@FindBy(id = SESSION_ID)
	private WebElement session;
	
	@FindBy(id = STTIME_ID)
	private WebElement stTime;
	
	@FindBy(id = ENDTIME_ID)
	private WebElement endTime;
	
	@FindBy(id = RECURRENCE_ID)
	private WebElement recurrence;
	
	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;
	
	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;
	
	public boolean checkAvilConfiSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean clickOnAddAvailButton() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(ADDAVAILBUTTON_ID);
		sleepVeryShort();
		addAvailButton.click();
		waitForElementId(FROMDATE_ID);
		waitForElementId(ADDBUTTON_ID);
		sleepVeryShort();
		return addButton.isDisplayed();
	}

	public boolean isMandFromDate() {
		waitForElementId(FROMDATE_ID);
		return isMandatoryField(fromDate);
	}
	
	public boolean isMandToDate() {
		waitForElementId(TODATE_ID);
		return isMandatoryField(toDate);
	}
	
//	public boolean fillDatas(String[] mbuDatas)
//			throws InterruptedException {
//		waitForElementLinkText(OPDParameters.SECTIONNAME_LINKTEXT);
//		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
//				"class").trim()))
//			getSectionName().click();
//		waitForElementId(SLOTINTERVAL_ID);
//		sleepVeryShort();
//		slotInterval.clear();
//		slotInterval.sendKeys(mbuDatas[41].trim());
//		slotBlockDuration.clear();
//		slotBlockDuration.sendKeys(mbuDatas[42].trim());
//		permisibleNo.clear();
//		permisibleNo.sendKeys(mbuDatas[43].trim());
//		revokeBlockAfter.clear();
//		revokeBlockAfter.sendKeys(mbuDatas[44].trim());
//		selectOrUnSelectCheckBox(mbuDatas[45].trim(), onApptStatusModific);
//		selectOrUnSelectCheckBox(mbuDatas[46].trim(), onAppointReminder);
//		return (onAppointReminder.isSelected() == Boolean.valueOf(mbuDatas[46]));
//	}
//
//	
//	public boolean submitFollowUpDatas() throws InterruptedException {
//		waitForElementId(SUBMITBUTTON_ID);
//		submitButton.click();
//		waitForElementId(GRIDID_ID);
//		sleepVeryShort();
//		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
//	}
//	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the addAvailButton
	 */
	public WebElement getAddAvailButton() {
		return addAvailButton;
	}

	/**
	 * @return the viewCalButton
	 */
	public WebElement getViewCalButton() {
		return viewCalButton;
	}

	/**
	 * @return the fromDate
	 */
	public WebElement getFromDate() {
		return fromDate;
	}

	/**
	 * @return the toDate
	 */
	public WebElement getToDate() {
		return toDate;
	}

	/**
	 * @return the selAllWorkDays
	 */
	public WebElement getSelAllWorkDays() {
		return selAllWorkDays;
	}

	/**
	 * @return the applicableDays
	 */
	public WebElement getApplicableDays() {
		return applicableDays;
	}

	/**
	 * @return the session
	 */
	public WebElement getSession() {
		return session;
	}

	/**
	 * @return the stTime
	 */
	public WebElement getStTime() {
		return stTime;
	}

	/**
	 * @return the endTime
	 */
	public WebElement getEndTime() {
		return endTime;
	}

	/**
	 * @return the recurrence
	 */
	public WebElement getRecurrence() {
		return recurrence;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}
	
}
