package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class DiagnosisPopupPage extends DriverWaitClass {
	public final static String CONSDIAGCOMPFORM_ID = "CONSULTATION_DIAGNOSIS_COMP_FORM";
	@FindBy(id = CONSDIAGCOMPFORM_ID)
	private WebElement diagnosisForm;

	public final static String SEARCHICDTAB_XPATH = ".//a[@href='#SEARCH_ICD_MATRIX_COMP_DIV']";
	@FindBy(xpath = SEARCHICDTAB_XPATH)
	private WebElement searchICDTab;

	public final static String MYICDICDTAB_XPATH = ".//a[@href='#MY_ICD']";
	@FindBy(xpath = MYICDICDTAB_XPATH)
	private WebElement myICDTab;

	public final static String MANUALICDICDTAB_XPATH = ".//a[@href='#MANUAL_ICD_MATRIX_COMP_DIV']";
	@FindBy(xpath = MANUALICDICDTAB_XPATH)
	private WebElement manualICDTab;

	public final static String SEARCHICDTEXTBOX_ID = "SEARCH_ICD_TEXT_COMP_FIELD";
	@FindBy(id = SEARCHICDTEXTBOX_ID)
	private WebElement searchICDTextBox;

	public final static String SEARCHICDBTN_ID = "SEARCH_ICD_COMP_BUTTON";
	@FindBy(id = SEARCHICDBTN_ID)
	private WebElement searchICDBtn;

	public final static String ICDCHILDGRIDTBL_ID = "SEARCH_ICD_CHILD_COMP_GRID";
	@FindBy(id = ICDCHILDGRIDTBL_ID)
	private WebElement icdChildGridTbl;

	public final static String ADDTOMYICDSCHKBOX_ID = "ADD_TO_FAVORITE_COMP_CK";
	@FindBy(id = ADDTOMYICDSCHKBOX_ID)
	private WebElement addToMyICDsChkBox;

	public final static String ADDSICDDIAGNOSISBTN_ID = "ADD_DIAGNOSIS_FROM_SEARCH_ICD_COMP_BUT";
	@FindBy(id = ADDSICDDIAGNOSISBTN_ID)
	private WebElement addSearchICDDiagBtn;

	public final static String DIAGNOSISGRIDTBL_ID = "DIAGNOSIS_LOG_COMP_GRID";
	@FindBy(id = DIAGNOSISGRIDTBL_ID)
	private WebElement diagGridTbl;

	public final static String ADDMYICDDIAGBTN_ID = "ADD_DIAGNOSIS_FROM_MY_ICD_COMP";
	@FindBy(id = ADDMYICDDIAGBTN_ID)
	private WebElement addMyICDDiagBtn;

	public final static String CANCELDIAGPOPUPBTN_XPATH = "//form[@id='CONSULTATION_DIAGNOSIS_COMP_FORM']/input[@value='Cancel']";
	@FindBy(xpath = CANCELDIAGPOPUPBTN_XPATH)
	private WebElement cancelDiagPopupBtn;

	public final static String SAVEDIAGPOPUPBTN_XPATH = "//form[@id='CONSULTATION_DIAGNOSIS_COMP_FORM']/input[@value='Save']";
	@FindBy(xpath = SAVEDIAGPOPUPBTN_XPATH)
	private WebElement saveDiagPopupBtn;

	public final static String MANUALICDTEXT_ID = "MANUAL_ICD_TEXT_COMP_ID";
	@FindBy(id = MANUALICDTEXT_ID)
	private WebElement manualICDText;

	public final static String ADDMANUALICDDIAGBTN_ID = "ADD_DIAGNOSIS_FROM_MANUAL_COMP_ICD";
	@FindBy(id = ADDMANUALICDDIAGBTN_ID)
	private WebElement addManualICDDiagBtn;

	public WebElement getDiagnosisForm() {
		return diagnosisForm;
	}

	public WebElement getSearchICDTab() {
		return searchICDTab;
	}

	public WebElement getMyICDTab() {
		return myICDTab;
	}

	public WebElement getManualICDTab() {
		return manualICDTab;
	}

	public WebElement getSearchICDTextBox() {
		return searchICDTextBox;
	}

	public WebElement getSearchICDBtn() {
		return searchICDBtn;
	}

	public WebElement getIcdChildGridTbl() {
		return icdChildGridTbl;
	}

	public WebElement getAddToMyICDsChkBox() {
		return addToMyICDsChkBox;
	}

	public WebElement getAddSearchICDDiagBtn() {
		return addSearchICDDiagBtn;
	}

	public WebElement getDiagGridTbl() {
		return diagGridTbl;
	}

	public WebElement getAddMyICDDiagBtn() {
		return addMyICDDiagBtn;
	}

	public WebElement getCancelDiagPopupBtn() {
		return cancelDiagPopupBtn;
	}

	public WebElement getSaveDiagPopupBtn() {
		return saveDiagPopupBtn;
	}

	public WebElement getManualICDText() {
		return manualICDText;
	}

	public WebElement getAddManualICDDiagBtn() {
		return addManualICDDiagBtn;
	}

}
