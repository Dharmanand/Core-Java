package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.preg.GeneralRegistrationPage;
import com.atk.himma.pageobjects.preg.regsections.BiometricDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.ContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.EmergencyContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.IdentificationDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.NextOfKinSection;
import com.atk.himma.pageobjects.preg.regsections.OtherDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.PersonalDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.ReferralDetailsSection;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class GeneralRegistrationTest extends SeleniumDriverSetup {

	List<String[]> pregDatas;
	GeneralRegistrationPage generalRegistrationPage;

	@Test(description = "Open General Registration Page")
	public void openGeneralRegPage() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		generalRegistrationPage = PageFactory.initElements(webDriver,
				GeneralRegistrationPage.class);
		generalRegistrationPage = generalRegistrationPage.clickOnGenRegMenu(
				webDriver, webDriverWait);
		generalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(generalRegistrationPage);
		generalRegistrationPage
				.waitForElementId(GeneralRegistrationPage.FORMNAME_ID);
		generalRegistrationPage.sleepShort();
		Assert.assertEquals(generalRegistrationPage.getPageTitle().getText(),
				"General Registration");
	}
	
//	[General Registration] Open Form
	@Test(description = "Open General Registration Page Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkGenRegMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		generalRegistrationPage = PageFactory.initElements(webDriver,
				GeneralRegistrationPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList, "General Registration");
		generalRegistrationPage.setWebDriver(webDriver);
		generalRegistrationPage.setWebDriverWait(webDriverWait);
		generalRegistrationPage.waitForElementXpathExpression(GeneralRegistrationPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(GeneralRegistrationPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage,expectedPrivilage,
				"Fail to check [General Registration] Open Form privilege");
		if(actualPrivilage && expectedPrivilage)
		{
		generalRegistrationPage = generalRegistrationPage.clickOnGenRegMenu(
				webDriver, webDriverWait);
		generalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(generalRegistrationPage);
		generalRegistrationPage
		.waitForElementId(GeneralRegistrationPage.FORMNAME_ID);
		generalRegistrationPage.sleepShort();
		Assert.assertEquals(generalRegistrationPage.getPageTitle().getText(),
				"General Registration");
		}
	}
	
	@Test(dependsOnMethods = { "openGeneralRegPage" }, description = "Check Persional Details Lov Data")
	public void tset1CheckPerDetailsLovData() {
		Assert.assertEquals(generalRegistrationPage.getPersonalDetailsSection()
				.compareBaseLovData(masterDatas), true);
	}

	@Test(dependsOnMethods = { "openGeneralRegPage" }, description = "Save Gen Reg Page")
	public void test2SaveGenRegPage() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		for (String[] st : pregDatas.subList(0, 1)) {
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage.sleepVeryShort();
			generalRegistrationPage
					.saveGenRegPage(st, webDriver, webDriverWait);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.MSGENABLE_XPATH);
			String regTypeMsg = generalRegistrationPage.getRegType().getText()
					.trim();
			Assert.assertEquals(regTypeMsg, "GENERAL");
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage.sleepVeryShort();
			Assert.assertNotNull(generalRegistrationPage.getUpdateButton(),
					"Reg Data didn't save successfully.");
		}
	}

	@Test(dependsOnMethods = { "test2SaveGenRegPage" }, description = "Update Gen Reg Page")
	public void test3UpdateGenRegPage() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("updateGeneralRegistration"));
		for (String[] st : pregDatas.subList(0, 1)) {
			generalRegistrationPage.updateGenRegPage(st, webDriver,
					webDriverWait);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.UPDATEMSG_XPATH);
			// generalRegistrationPage.sleepMedium();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			Assert.assertNotNull(generalRegistrationPage.getUpdateButton(),
					"Update successfully Gen. Reg. datas.");
			generalRegistrationPage.getNewRegistrationButton().click();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage.sleepShort();
		}
	}

	@Test(dependsOnMethods = { "test2SaveGenRegPage" }, description = "Save Gen Reg Page")
	public void test4SaveGenRegAllDatas() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		boolean flag = false;
		mergePatients = new String[pregDatas.size()];
		for (String[] st : pregDatas.subList(1, pregDatas.size())) {
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage.sleepVeryShort();
			generalRegistrationPage
					.saveGenRegPage(st, webDriver, webDriverWait);
			generalRegistrationPage.sleepShort();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.MSGENABLE_XPATH);
			Assert.assertEquals(generalRegistrationPage.getStatusMessage()
					.getText().contains("registered successfully."), true,
					"Reg Data didn't save successfully.");
			generalRegistrationPage.sleepVeryShort();
			String mrn = generalRegistrationPage.getFirstSection().getMrn()
					.getAttribute("value").trim();
			if (Boolean.valueOf(st[93].trim())) {
				if (Boolean.valueOf(st[94].trim())) {
					mergePatients[0] = mrn;
					mergePatients[2] = st[5].trim();
				}
				if (!flag) {
					mergePatients[1] = mrn;
					flag = true;
				} else
					mergePatients[1] = mergePatients[1] + "," + mrn;
			}
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.ACTIVATE_XPATH);
			generalRegistrationPage.activateRecord(
					GeneralRegistrationPage.ACTIVATE_ID,
					GeneralRegistrationPage.MAINSTATUSLABEL_ID);
			generalRegistrationPage.sleepVeryShort();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			generalRegistrationPage.getNewRegistrationButton().click();
			generalRegistrationPage.sleepVeryShort();
		}
	}

	// [General Registration][Section: Identification Details] Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Identification Details section privileges")
	public void checkIdentDetSecPrivileges() {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Identification Details] Manage");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(IdentificationDetailsSection.SECTIONNAME_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Identification Details] Manage");
	}
	
//	[General Registration][Section: Contact Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Contact Details section privileges")
	public void checkContactDetailsPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Contact Details]  Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(ContactDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Contact Details]  Manage");
	}
	
	/*//	[General Registration][Section: New Born] Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking New Born section privileges")
	public void checkNewBornSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: New Born] Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(NewBornSection.SECTIONNAME_LINKTEXT),
				actualPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: New Born] Manage");
	}*/
	
/*//	[General Registration][Section: Policy Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Policy Details section privileges")
	public void checkPolicyDetailsSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Policy Details]  Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(PolicyDetailsSection.SECTIONNAME_LINKTEXT),
				actualPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Policy Details] Manage");
	}*/
		
//	[General Registration][Section: Personal Details] Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Personal Details section privileges")
	public void checkPersonalDetailsSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Personal Details] Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(PersonalDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Personal Details] Manage");
	}
		
/*//	[General Registration][Section: Package Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Package Details section privileges")
	public void checkPackageDetailsSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Personal Details] Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(Package.SECTIONNAME_LINKTEXT),
				actualPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Personal Details] Manage");
	}*/
	
//	[General Registration][Section: Emergency Contact Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Emergency Contact Details section privileges")
	public void checkEmerContDetSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Emergency Contact Details]  Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(EmergencyContactDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Emergency Contact Details] Manage");
	}
	
//	[General Registration][Section: Next of kin]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Next of kin section privileges")
	public void checkNextOfKinSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Next of kin]  Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(NextOfKinSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Next of kin] Manage");
	}
	
//	[General Registration][Section: Biometric Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Biometric Details section privileges")
	public void checkBiometricDetailsSecPrivileges()
	{
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Biometric Details]  Manage");
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(BiometricDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Biometric Details] Manage");
	}
	
//	[General Registration][Section: Referral Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Referral Details section privileges")
	public void checkReferralDetailsSecPrivileges()
	{
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Referral Details]  Manage");
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(ReferralDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Referral Details] Manage");
	}
	
//	[General Registration][Section: Other Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Other Details section privileges")
	public void checkOtherDetailsSecPrivileges()
	{
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Other Details]  Manage");
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(OtherDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Other Details] Manage");
	}
	
	@Test(dependsOnMethods = { "openGeneralRegPage", "test3UpdateGenRegPage" }, description = "Save Gen Reg Page")
	public void saveGRegDatasForPrivilege() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		boolean flag = false;
		mergePatients = new String[pregDatas.size()];
		for (String[] st : pregDatas.subList(1, pregDatas.size())) {
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage.sleepVeryShort();
			generalRegistrationPage
					.saveGenRegPage(st, webDriver, webDriverWait);
			generalRegistrationPage.sleepShort();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.MSGENABLE_XPATH);
			Assert.assertEquals(generalRegistrationPage.getStatusMessage()
					.getText().contains("registered successfully."), true,
					"Reg Data didn't save successfully.");
			generalRegistrationPage.sleepVeryShort();
			String mrn = generalRegistrationPage.getFirstSection().getMrn()
					.getAttribute("value").trim();
			if (Boolean.valueOf(st[93].trim())) {
				if (Boolean.valueOf(st[94].trim())) {
					mergePatients[0] = mrn;
					mergePatients[2] = st[5].trim();
				}
				if (!flag) {
					mergePatients[1] = mrn;
					flag = true;
				} else
					mergePatients[1] = mergePatients[1] + "," + mrn;
			}
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.ACTIVATE_XPATH);
			generalRegistrationPage.activateRecord(
					GeneralRegistrationPage.ACTIVATE_ID,
					GeneralRegistrationPage.MAINSTATUSLABEL_ID);
			generalRegistrationPage.sleepVeryShort();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			generalRegistrationPage.getNewRegistrationButton().click();
			generalRegistrationPage.sleepVeryShort();
		}
	}
	
/*//	[General Registration][Section: Death Details]  Manage
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Death Details")
	public void checkDeathDetailsSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Death Details]  Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(IdentificationDetailsSection.SECTIONNAME_LINKTEXT),
				actualPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Death Details] Manage");
	}*/
	
/*//	[General Registration][Section: Audit Trail] View
	public void checkAuditTrailSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Audit Trail] View");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(IdentificationDetailsSection.SECTIONNAME_LINKTEXT),
				actualPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Audit Trail] Manage");
	}*/
	
	
	//	[General Registration][Section: Audit Trail] View
	@Test(dependsOnMethods = { "checkGenRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Saving Data for Privileges check")
	public void saveDataForPrivileges() throws IOException, InterruptedException
	{
		pregDatas = excelReader.read(properties.getProperty("generalRegistration"));
		for (String[] st : pregDatas.subList(0, 1)) {
		generalRegistrationPage.getFirstSection().fillDatasOfPregFirstSection(st, webDriverWait);
		generalRegistrationPage.getPatientIdentifierSection().fillDatasOfPatientIdentifier(st, webDriverWait);
		if(PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Identification Details] Manage"))
		generalRegistrationPage.getIdentificationDetailsSection().fillDatasIdentificationDetails(st, webDriverWait);
		if(PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Contact Details]  Manage"))
		generalRegistrationPage.getContactDetailsSection().fillDatasContactDetails(st, webDriverWait);
		if(PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Personal Details] Manage"))
		generalRegistrationPage.getPersonalDetailsSection().fillDatasOfPersonalDetailsSection(st, webDriverWait);
		if(PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Emergency Contact Details]  Manage"))
		generalRegistrationPage.getEmergencyContactDetailsSection().fillDatasOfEmergencyContactDetailsSection(st, webDriverWait);
//		generalRegistrationPage.getBiometricDetailsSection().fillDatasOfBiometricDetailsSection(st, webDriverWait);
		if(PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Referral Details]  Manage"))
		generalRegistrationPage.getReferralDetailsSection().fillDatasOfReferralDetailsSection(st, webDriverWait);
		if(PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration][Section: Other Details]  Manage"))
		generalRegistrationPage.getOtherDetailsSection().fillDatasOfOtherlDetailsSection(st, webDriverWait);
		generalRegistrationPage.waitForElementXpathExpression(GeneralRegistrationPage.SAVEBUTTON_XPATH);
			generalRegistrationPage.getSaveButton().click();
			generalRegistrationPage
					.waitForElementClickable(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.UPDATEBUTTON_XPATH);
			generalRegistrationPage
					.waitForElementXpathExpression(GeneralRegistrationPage.MSGENABLE_XPATH);
			Assert.assertEquals(generalRegistrationPage.getStatusMessage()
					.getText().contains("registered successfully."), true,
					"Reg Data didn't save successfully.");
	}
	}
	
//	[General Registration] Delete
	@Test(dependsOnMethods = { "checkGenRegMenuLink", "saveDataForPrivileges" }, groups = { "checkPrivilegesGrp" }, description = "Check Delete button privilege")
	public void checkDeletePrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration] Delete");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(GeneralRegistrationPage.DELETEBUTTON_ID));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [General Registration] Delete");
	}
	
	
//	[General Registration] Print Labels
	@Test(dependsOnMethods = { "checkGenRegMenuLink", "saveDataForPrivileges" }, groups = { "checkPrivilegesGrp" }, description = "Check Print Labels button privilege")
	public void checkPrintLabelsSecPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration] Print Labels");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(GeneralRegistrationPage.PRINTLABELSBUTTON_ID));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [General Registration] Print Labels");
	}
	
//	[General Registration] Print Registration Form
	public void checkPrintRegFormPrivileges() {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration] Print Registration Form");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(GeneralRegistrationPage.PRINTREGISTRATIONFORMBUTTON_ID));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [General Registration] Print Registration Form");
	}
	
//	[General Registration] Print MR Card
	@Test(dependsOnMethods = { "checkGenRegMenuLink", "saveDataForPrivileges" }, groups = { "checkPrivilegesGrp" }, description = "Check Print MR Card button privilege")
	public void checkPrintMRCardPrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration] Print MR Card");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(GeneralRegistrationPage.PRINTMRCARDBUTTON_XPATH));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [General Registration] Print MR Card");
	}
	
//	[General Registration] View Family Tree
	@Test(dependsOnMethods = { "checkGenRegMenuLink", "saveDataForPrivileges" }, groups = { "checkPrivilegesGrp" }, description = "Check View Family Tree button privilege")
	public void checkViewFamilyTreePrivileges()
	{
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("General Registration")
				.get("[General Registration] View Family Tree");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(GeneralRegistrationPage.VIEWFAMILYTREEBUTTON_XPATH));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [General Registration] View Family Tree");
	}
	
}
