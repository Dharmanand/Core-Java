package com.atk.himma.pageobjects.nursing.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class TriageFirstSection extends DriverWaitClass {
	public final static String ENCNUM_ID = "ENCOUNTER_NUMBER_TXT";
	public final static String ENCDATE_ID = "ENCOUNTER_DATE_TXT";
	public final static String ENCSPECIALTY_NAME = "patEncounterDetails.speciality";

	@FindBy(id = ENCNUM_ID)
	private WebElement encounterNumber;

	@FindBy(id = ENCDATE_ID)
	private WebElement encounterDate;

	@FindBy(id = ENCSPECIALTY_NAME)
	private WebElement encounterSpecialty;

	public WebElement getEncounterNumber() {
		return encounterNumber;
	}

	public WebElement getEncounterDate() {
		return encounterDate;
	}

	public WebElement getEncounterSpecialty() {
		return encounterSpecialty;
	}

}
