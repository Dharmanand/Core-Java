package com.atk.himma.pageobjects.mrd;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.pageobjects.appointsched.Appointments;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class MRDDesktopPage extends DriverWaitClass implements StatusMessages,
		RecordStatus, TopControls {

	// ---------------------------Filter By-------------------------
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String MRDDESKTOPMENULINK_XPATH = "//a[text()='MRD']/..//a[text()='MRD Desktop']";
	public final static String ALLSTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='ALL_URL']";
	public final static String REQUESTEDSTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='OP_PENDING_URL']";
	public final static String DISPATCHEDSTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='OP_SENT_URL']";
	public final static String REQURECEIVESTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='TARGET_RECEIVE_URL']";
	public final static String REQURETURNEDSTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='OP_RECEIVE_URL']";
	public final static String MRDRECEIVESTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='OP_RECEIVED_MRD_URL']";
	public final static String DISPCANCELSTATUS_XPATH = "//div[@id='lftpnlitm']//a[@id='CANCEL_DISPATCH_URL']";

	public final static String HIDEPANEL_ID = "hidePanel";
	public final static String QUICKSEARCHTXT_ID = "QUICK_SEARCH";
	public final static String SEARCHBUTTON_ID = "QUICK_SEARCH_BTN_MRD";
	public final static String RESETBUTTON_ID = "RESET_MRN_LOOKUP";
	public final static String ADVSEARCHBUTTON_ID = "MR_ADV_SEARCH_LOOKUP";

	// ---------------------------Advance search fields-------------------------
	public final static String ADVSEARCHPOPUP_ID = "MR_ADV_SEARCH_LOOKUP_FLOAT";
	public final static String MBUADVSEARCH_ID = "MBU_ADVANCE_SEARCH";
	public final static String SEARCHPERIOD_ID = "SEARCH_PERIOD_ADV_SRCH";
	public final static String REQNUMBER_ID = "REQUEST_NUMBER_ADV";
	public final static String REQTYPE_ID = "REQUEST_TYPE_ADV";
	public final static String NOFILTERADV_ID = "NO_FILTER_ADV";
	public final static String PATIENTADV_ID = "PATIENT_ADV";
	public final static String PHYSICIANADV_ID = "PHYSICIAN_ADV";
	public final static String LOCATIONADV_ID = "LOCATION_ADV";
	public final static String STATUSADV_ID = "STATUS_ADV";
	public final static String ADVSEARCHMRDBUTTON_ID = "ADVANCE_SEARCH_MRD";
	public final static String ADVRESETBUTTON_ID = "RESET_ADV_SEARCH_LOOKUP";

	// ----------------------------GRID-----------------------------
	public final static String REFRESHLINK_ID = "REFRESH_DATA_LINK_DUMMY";
	public final static String GRIDDUMMY_ID = "MR_RESULT_GRID_DUMMY";
	public final static String GRID_ID = "MR_RESULT_GRID";
	public final static String GRID_MRN_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_mrNumber";
	public final static String GRID_PATNAME_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_patientName";
	public final static String GRID_VOLUME_ARIA_DESCRIBEDBY = "jqgh_MR_RESULT_GRID_mrVolume.volume";
	public final static String GRID_REQUESTBY_ARIA_DESCRIBEDBY = "jqgh_MR_RESULT_GRID_mrRequestDetails.physician";
	public final static String GRID_REQDATANDTIME_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_mrRequestDetails.requestedDateText";
	public final static String GRID_SENTTOLOC_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_mrRequestDetails.sentToLoc";
	public final static String GRID_SENTDATEANDTIME_ARIA_DESCRIBEDBY = "MR_RESULT_GRID_sentDateText";

	public final static String GRID_PAGER_ID = "sp_1_MR_RESULT_GRID_pager";

	// --------------------------------------------------------------
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MRDDESKTOPMENULINK_XPATH)
	private WebElement mrdDesktopMenuLink;

	@FindBy(xpath = ALLSTATUS_XPATH)
	private WebElement allStatus;

	@FindBy(xpath = REQUESTEDSTATUS_XPATH)
	private WebElement requestedStatus;

	@FindBy(xpath = DISPATCHEDSTATUS_XPATH)
	private WebElement dispatchedStatus;

	@FindBy(xpath = REQURECEIVESTATUS_XPATH)
	private WebElement requReceiveStatus;

	@FindBy(xpath = REQURETURNEDSTATUS_XPATH)
	private WebElement requReturnedStatus;

	@FindBy(xpath = MRDRECEIVESTATUS_XPATH)
	private WebElement mrdReceiveStatus;

	@FindBy(xpath = DISPCANCELSTATUS_XPATH)
	private WebElement dispCancelStatus;

	@FindBy(id = HIDEPANEL_ID)
	private WebElement hidePanel;

	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;

	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;

	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;

	@FindBy(id = ADVSEARCHPOPUP_ID)
	private WebElement advSearchPopup;

	@FindBy(id = MBUADVSEARCH_ID)
	private WebElement mbuAdvSearch;

	@FindBy(id = SEARCHPERIOD_ID)
	private WebElement searchPeriod;

	@FindBy(id = REQNUMBER_ID)
	private WebElement reqNumber;

	@FindBy(id = REQTYPE_ID)
	private WebElement reqType;

	@FindBy(xpath = NOFILTERADV_ID)
	private WebElement noFilterAdv;

	@FindBy(xpath = PATIENTADV_ID)
	private WebElement patientAdv;

	@FindBy(xpath = PHYSICIANADV_ID)
	private WebElement physicianAdv;

	@FindBy(xpath = LOCATIONADV_ID)
	private WebElement locationAdv;

	@FindBy(xpath = STATUSADV_ID)
	private WebElement statusAdv;

	@FindBy(xpath = ADVSEARCHMRDBUTTON_ID)
	private WebElement advSearchMRDButton;

	@FindBy(xpath = ADVRESETBUTTON_ID)
	private WebElement advResetButton;

	public MRDDesktopPage checkMRDDesktopLink(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MRD");
		menuSelector.mouseOverOnTargetMenu(menuList, "MRD Desktop");
		MRDDesktopPage mrdDesktopPage = PageFactory.initElements(webDriver,
				MRDDesktopPage.class);
		return mrdDesktopPage;
	}

	public MRDDesktopPage clickOnMRDDesktopMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MRD");
		menuSelector.clickOnTargetMenu(menuList, "MRD Desktop");
		MRDDesktopPage mrdDesktopPage = PageFactory.initElements(webDriver,
				MRDDesktopPage.class);
		mrdDesktopPage.setWebDriver(webDriver);
		mrdDesktopPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForElementId(GRIDDUMMY_ID);
		return mrdDesktopPage;
	}

	public boolean verifyAutoReqestMRDVolume(String patientName, String MRStatus) {

		waitForElementId(SEARCHBUTTON_ID);
		quickSearchTxt.clear();
		quickSearchTxt.sendKeys(patientName);
		searchButton.click();
		waitForElementId(GRID_ID);
		return waitForPatMRStatus(patientName, MRStatus);

	}

	public boolean verifySendLinkMRDVolume(String patientName, String MRStatus) {

		waitForElementId(SEARCHBUTTON_ID);
		quickSearchTxt.clear();
		quickSearchTxt.sendKeys(patientName);
		searchButton.click();
		waitForElementId(GRID_ID);
		return waitForSendLink(patientName, MRStatus);

	}

	public boolean waitForPatMRStatus(String patientName, String MRStatus) {

		String xpath = "//td[@aria-describedby='MR_RESULT_GRID_patientName'][text()='"
				+ patientName.trim()
				+ "']/..//td[@aria-describedby='MR_RESULT_GRID_statusText'][text()='"
				+ MRStatus.trim() + "']";
		try {
			waitForPageLoaded(webDriver);
			new WebDriverWait(webDriver, shortTimeInterval)
					.until(ExpectedConditions.presenceOfElementLocated(By
							.xpath(xpath)));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean waitForSendLink(String patientName, String actionLink) {

		String xpath = "//td[@aria-describedby='MR_RESULT_GRID_patientName'][text()='"
				+ patientName.trim()
				+ "']/..//a[text()='"
				+ actionLink.trim()
				+ "']";
		try {
			waitForPageLoaded(webDriver);
			new WebDriverWait(webDriver, shortTimeInterval)
					.until(ExpectedConditions.presenceOfElementLocated(By
							.xpath(xpath)));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public AppointmentDairy bookAppoint(Appointments appointmentsPage,
			String[] st) throws InterruptedException {
		appointmentsPage = appointmentsPage.clickOnAppointmentsMenu(webDriver,
				webDriverWait);
		appointmentsPage.setInstance(webDriver, webDriverWait);
		doDirtyPopUpCheck();
		appointmentsPage.getPhysicianAvailability().quickSearchPhysician(
				st[0].trim());
		appointmentsPage.getPhysicianAvailability().clickOnAvailDateSession(
				st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		appointmentsPage.getAppointmentDairy().clickOnAppSlotForBook(
				st[3].trim(), st[4].trim());
		appointmentsPage.getManageBooking().getBookTab()
				.doQuickSearchPage(st[5].trim(), st[18]);
		return appointmentsPage.getManageBooking().getBookTab()
				.saveBookingDetails();
	}

	public boolean cancelAppointment(Appointments appointmentsPage, String[] st)
			throws InterruptedException {
		appointmentsPage = appointmentsPage.clickOnAppointmentsMenu(webDriver,
				webDriverWait);
		appointmentsPage.setInstance(webDriver, webDriverWait);
		doDirtyPopUpCheck();
		appointmentsPage.getPhysicianAvailability().quickSearchPhysician(
				st[0].trim());
		appointmentsPage.getPhysicianAvailability().clickOnAvailDateSession(
				st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		return appointmentsPage.getAppointmentDairy().cancelBookedSlot(
				st[4].trim(), st[5].trim());
	}

	public void reschAppointment(Appointments appointmentsPage,
			AppointmentDairy appointmentDairy, String[] st)
			throws InterruptedException {
		appointmentsPage = appointmentsPage.clickOnAppointmentsMenu(webDriver,
				webDriverWait);
		appointmentsPage.setInstance(webDriver, webDriverWait);
		doDirtyPopUpCheck();
		appointmentsPage.getPhysicianAvailability().quickSearchPhysician(
				st[0].trim());
		appointmentsPage.getPhysicianAvailability().clickOnAvailDateSession(
				st[0].trim(), st[1].trim(), st[2].trim(), st[3].trim());
		appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.rescheduleAppointment(st[2], st[3], st[5], st[6],
				st[4]);
	}

	/**
	 * @return the allStatus
	 */
	public WebElement getAllStatus() {
		return allStatus;
	}

	/**
	 * @return the requestedStatus
	 */
	public WebElement getRequestedStatus() {
		return requestedStatus;
	}

	/**
	 * @return the dispatchedStatus
	 */
	public WebElement getDispatchedStatus() {
		return dispatchedStatus;
	}

	/**
	 * @return the requReceiveStatus
	 */
	public WebElement getRequReceiveStatus() {
		return requReceiveStatus;
	}

	/**
	 * @return the requReturnedStatus
	 */
	public WebElement getRequReturnedStatus() {
		return requReturnedStatus;
	}

	/**
	 * @return the mrdReceiveStatus
	 */
	public WebElement getMrdReceiveStatus() {
		return mrdReceiveStatus;
	}

	/**
	 * @return the dispCancelStatus
	 */
	public WebElement getDispCancelStatus() {
		return dispCancelStatus;
	}

	/**
	 * @return the hidePanel
	 */
	public WebElement getHidePanel() {
		return hidePanel;
	}

	/**
	 * @return the quickSearch
	 */
	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the advSearchPopup
	 */
	public WebElement getAdvSearchPopup() {
		return advSearchPopup;
	}

	/**
	 * @return the mbuAdvSearch
	 */
	public WebElement getMbuAdvSearch() {
		return mbuAdvSearch;
	}

	/**
	 * @return the searchPeriod
	 */
	public WebElement getSearchPeriod() {
		return searchPeriod;
	}

	/**
	 * @return the reqNumber
	 */
	public WebElement getReqNumber() {
		return reqNumber;
	}

	/**
	 * @return the reqType
	 */
	public WebElement getReqType() {
		return reqType;
	}

	/**
	 * @return the noFilterAdv
	 */
	public WebElement getNoFilterAdv() {
		return noFilterAdv;
	}

	/**
	 * @return the patientAdv
	 */
	public WebElement getPatientAdv() {
		return patientAdv;
	}

	/**
	 * @return the physicianAdv
	 */
	public WebElement getPhysicianAdv() {
		return physicianAdv;
	}

	/**
	 * @return the locationAdv
	 */
	public WebElement getLocationAdv() {
		return locationAdv;
	}

	/**
	 * @return the statusAdv
	 */
	public WebElement getStatusAdv() {
		return statusAdv;
	}

	/**
	 * @return the advSearchMRDButton
	 */
	public WebElement getAdvSearchMRDButton() {
		return advSearchMRDButton;
	}

	/**
	 * @return the advResetButton
	 */
	public WebElement getAdvResetButton() {
		return advResetButton;
	}

	/**
	 * @return the mrdDesktopMenuLink
	 */
	public WebElement getMrdDesktopMenuLink() {
		return mrdDesktopMenuLink;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}
}
