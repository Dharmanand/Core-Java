package com.atk.himma.pageobjects.baselov.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class BaseLoVListTab extends DriverWaitClass {

	public final static String FORM_ID = "baselvformSearch";

	@FindBy(id = FORM_ID)
	private WebElement form;

	public final static String BASELOVLISTTAB_XPATH = "//a[@title='Base LoV List']";

	@FindBy(xpath = BASELOVLISTTAB_XPATH)
	private WebElement baseLoVListTab;

	// private final static String BASELOVDETAILS_XPATH =
	// "//a[@title='Base LoV Details']";
	//
	// @FindBy(xpath=BASELOVDETAILS_XPATH)
	// private WebElement baseLoVDetails;

	public final static String ADDNEWBASELOVBUTTON_ID = "ADDNEW_BASELV_ID";

	@FindBy(id = ADDNEWBASELOVBUTTON_ID)
	private WebElement addNewBaseLoVButton;

	public final static String MODULENAME_ID = "moduleId";

	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String ENTITY_ID = "entityTypeId";

	@FindBy(id = ENTITY_ID)
	private WebElement entity;

	public final static String LANGUAGE_ID = "langCode";

	@FindBy(id = LANGUAGE_ID)
	private WebElement language;

	public final static String STATUS_NAME = "searchBaseLV.status";

	@FindBy(name = STATUS_NAME)
	private WebElement status;

	public final static String SHORTNAME_NAME = "searchBaseLV.dispShortDesc";

	@FindBy(name = SHORTNAME_NAME)
	private WebElement shortName;

	public final static String LONGNAME_NAME = "searchBaseLV.longDesc";

	@FindBy(name = LONGNAME_NAME)
	private WebElement longName;

	public final static String SEARCHBUTTON_id = "SEARCH_BASELV_ID";

	@FindBy(id = SEARCHBUTTON_id)
	private WebElement searchButton;

	public final static String RESETBUTTON_ID = "RESET_BASELV_ID";

	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	// ---------------------------------------------- Grid Start
	// -----------------------------------------
	public final static String GRID_ID = "CODE_GEN_GRID";

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	public final static String GRID_ENTITYTYPEID_ARIA_DESCRIBEDBY = "CODE_GEN_GRID_entityTypeId";
	public final static String GRID_DISPSHORTDESC_ARIA_DESCRIBEDBY = "CODE_GEN_GRID_dispShortDesc";
	public final static String GRID_LONGDESC_ARIA_DESCRIBEDBY = "CODE_GEN_GRID_longDesc";
	public final static String GRID_LANGCODE_ARIA_DESCRIBEDBY = "CODE_GEN_GRID_langCode";
	public final static String GRID_status_ARIA_DESCRIBEDBY = "CODE_GEN_GRID_status";
	public final static String GEN_GRID_ACTION_ARIA_DESCRIBEDBY = "CODE_GEN_GRID_id";

	// pager
	public final static String GRID_PAGERID = "sp_1_CODE_GEN_GRID_pager";

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_CODE_GEN_GRID_pager']/span";
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	// ---------------------------------------------- Grid End
	// -----------------------------------------

	/**
	 * @return the baseLoVListTab
	 */
	public WebElement getBaseLoVListTab() {
		return baseLoVListTab;
	}

	/**
	 * @return the addNewBaseLoVButton
	 */
	public WebElement getAddNewBaseLoVButton() {
		return addNewBaseLoVButton;
	}

	/**
	 * @return the moduleName
	 */
	public WebElement getModuleName() {
		return moduleName;
	}

	/**
	 * @return the language
	 */
	public WebElement getLanguage() {
		return language;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the shortName
	 */
	public WebElement getShortName() {
		return shortName;
	}

	/**
	 * @return the longName
	 */
	public WebElement getLongName() {
		return longName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the formId
	 */
	public static String getFormId() {
		return FORM_ID;
	}

	/**
	 * @return the baselovlisttabXpath
	 */
	public static String getBaselovlisttabXpath() {
		return BASELOVLISTTAB_XPATH;
	}

	/**
	 * @return the addnewbaselovbuttonId
	 */
	public static String getAddnewbaselovbuttonId() {
		return ADDNEWBASELOVBUTTON_ID;
	}

	/**
	 * @return the modulenameId
	 */
	public static String getModulenameId() {
		return MODULENAME_ID;
	}

	/**
	 * @return the languageId
	 */
	public static String getLanguageId() {
		return LANGUAGE_ID;
	}

	/**
	 * @return the statusName
	 */
	public static String getStatusName() {
		return STATUS_NAME;
	}

	/**
	 * @return the shortnameName
	 */
	public static String getShortnameName() {
		return SHORTNAME_NAME;
	}

	/**
	 * @return the longnameName
	 */
	public static String getLongnameName() {
		return LONGNAME_NAME;
	}

	/**
	 * @return the searchbuttonId
	 */
	public static String getSearchbuttonId() {
		return SEARCHBUTTON_id;
	}

	/**
	 * @return the resetbuttonId
	 */
	public static String getResetbuttonId() {
		return RESETBUTTON_ID;
	}

	/**
	 * @return the gridEntitytypeidAriaDescribedby
	 */
	public static String getGridEntitytypeidAriaDescribedby() {
		return GRID_ENTITYTYPEID_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridDispshortdescAriaDescribedby
	 */
	public static String getGridDispshortdescAriaDescribedby() {
		return GRID_DISPSHORTDESC_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridLongdescAriaDescribedby
	 */
	public static String getGridLongdescAriaDescribedby() {
		return GRID_LONGDESC_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridLangcodeAriaDescribedby
	 */
	public static String getGridLangcodeAriaDescribedby() {
		return GRID_LANGCODE_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridStatusAriaDescribedby
	 */
	public static String getGridStatusAriaDescribedby() {
		return GRID_status_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the genGridActionAriaDescribedby
	 */
	public static String getGenGridActionAriaDescribedby() {
		return GEN_GRID_ACTION_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridId
	 */
	public static String getGridId() {
		return GRID_ID;
	}

	/**
	 * @return the gridPagerid
	 */
	public static String getGridPagerid() {
		return GRID_PAGERID;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the entityId
	 */
	public static String getEntityId() {
		return ENTITY_ID;
	}

	/**
	 * @return the entity
	 */
	public WebElement getEntity() {
		return entity;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

}
