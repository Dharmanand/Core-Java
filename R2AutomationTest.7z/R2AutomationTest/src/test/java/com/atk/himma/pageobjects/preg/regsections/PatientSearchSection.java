package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PatientSearchSection extends DriverWaitClass{
	
	private final static String QUICKSEARCH_ID = "searchTextName";
	
	@FindBy(id=QUICKSEARCH_ID)
	private WebElement quickSearch;
	
	private final static String QUICKSEARCHBUTTON_ID = "quickSearch";
	
	@FindBy(id=QUICKSEARCHBUTTON_ID)
	private WebElement quickSearchButton;
	
	private final static String QUICKSEARCHRESETBUTTON_ID = "quickSearchReset";
	
	@FindBy(id = QUICKSEARCHRESETBUTTON_ID)
	private WebElement quickSearchResetButton;
	
	private final static String STANDARDSEARCHEXPANDORCOLLAPSEBUTTON_ID = "quickSearchReset";
	
	@FindBy(id=STANDARDSEARCHEXPANDORCOLLAPSEBUTTON_ID)
	private WebElement standardSearchExpandOrCollapseButton;
	
//	Standard Popup Elements
	
	private final static String REGISTRATIONTYPE_NAME = "patientStdSearch.iregType";
	
	@FindBy(name=REGISTRATIONTYPE_NAME)
	private WebElement registrationType;
	
	private final static String PATIENTTYPE_NAME = "patientStdSearch.ipatientType";
	
	@FindBy(name=PATIENTTYPE_NAME)
	private WebElement patientType;
	
	private final static String MRNSTANDSEARCH_NAME = "patientStdSearch.ipatientType";
	
	@FindBy(name= MRNSTANDSEARCH_NAME)
	private WebElement mrnStandSearch;
	
	private final static String STAFFID_NAME = "patientStdSearch.sstaffId";
	
	@FindBy(name=STAFFID_NAME)
	private WebElement staffID;
	
	private final static String PATIENTNAME_NAME = "patientStdSearch.patientName";
	
	@FindBy(name=PATIENTNAME_NAME)
	private WebElement patientName;
	
	private final static String PATIENTNAMEAR_NAME = "patientStdSearch.patientNameAr";
	
	@FindBy(name=PATIENTNAMEAR_NAME)
	private WebElement patientNameAr;
	
	private final static String DATEOFBIRTH_ID = "dobStdSrh";
	
	@FindBy(id=DATEOFBIRTH_ID)
	private WebElement dateOfBirth;
	
	private final static String DATEOFBIRTHHIJRI_ID = "dobHijStdSrh";
	
	@FindBy(id=DATEOFBIRTHHIJRI_ID)
	private WebElement dateOfBirthHijri;
	
	private final static String GENDER_ID = "STANDARD_SEARCH_GENDER";
	
	@FindBy(id=GENDER_ID)
	private WebElement gender;
	
	private final static String MARITALSTATUS_NAME = "patientStdSearch.imaritalSatus";
	
	@FindBy(name=MARITALSTATUS_NAME)
	private WebElement maritalStatus;
	
	private final static String NATIONALITY_NAME = "patientStdSearch.inationality";
	
	@FindBy(name=NATIONALITY_NAME)
	private WebElement nationality;
	
	private final static String RELIGION_NAME = "patientStdSearch.ireligion";
	
	@FindBy(name=RELIGION_NAME)
	private WebElement religion;
	
	private final static String TELEPHONEORMOBILECODE_NAME = "patientStdSearch.smob";
	
	@FindBy(name=TELEPHONEORMOBILECODE_NAME)
	private WebElement TelephoneOrMobileCode;
	
	private final static String TELEPHONEORMOBILENUMBER_NAME = "patientStdSearch.smobileNo";
	
	@FindBy(name=TELEPHONEORMOBILENUMBER_NAME)
	private WebElement TelephoneOrMobileNumber;
	
	private final static String FATHERORMOTHERMRN_NAME = "patientStdSearch.kinsMrn";
	
	@FindBy(name=FATHERORMOTHERMRN_NAME)
	private WebElement FatherOrMotherMRN;
	
	private final static String IDENTIFICATIONDOCUMENT_NAME = "patientStdSearch.iidentityType";
	
	@FindBy(name=IDENTIFICATIONDOCUMENT_NAME)
	private WebElement identificationDocument;
	
	private final static String IDENTIFICATIONNO_NAME = "patientStdSearch.sidentityNo";
	
	@FindBy(name=IDENTIFICATIONNO_NAME)
	private WebElement identificationNo;
	
	private final static String STANDARDSEARCHBUTTON_ID = "searchButtonId";
	
	@FindBy(id=STANDARDSEARCHBUTTON_ID)
	private WebElement standardSearchButton;
	
	private final static String STANDARDSEARCHRESETBUTTON_XPATH = "//input[@id='searchButtonId']/..//input[@value='Reset']";
	
	@FindBy(xpath=STANDARDSEARCHRESETBUTTON_XPATH)
	private WebElement standardSearchResetButton;

	/**
	 * @return the quickSearch
	 */
	public WebElement getQuickSearch() {
		return quickSearch;
	}

	/**
	 * @return the quickSearchButton
	 */
	public WebElement getQuickSearchButton() {
		return quickSearchButton;
	}

	/**
	 * @return the quickSearchResetButton
	 */
	public WebElement getQuickSearchResetButton() {
		return quickSearchResetButton;
	}

	/**
	 * @return the standardSearchExpandOrCollapseButton
	 */
	public WebElement getStandardSearchExpandOrCollapseButton() {
		return standardSearchExpandOrCollapseButton;
	}

	/**
	 * @return the registrationType
	 */
	public WebElement getRegistrationType() {
		return registrationType;
	}

	/**
	 * @return the patientType
	 */
	public WebElement getPatientType() {
		return patientType;
	}

	/**
	 * @return the mrnStandSearch
	 */
	public WebElement getMrnStandSearch() {
		return mrnStandSearch;
	}

	/**
	 * @return the staffID
	 */
	public WebElement getStaffID() {
		return staffID;
	}

	/**
	 * @return the patientName
	 */
	public WebElement getPatientName() {
		return patientName;
	}

	/**
	 * @return the patientNameAr
	 */
	public WebElement getPatientNameAr() {
		return patientNameAr;
	}

	/**
	 * @return the dateOfBirth
	 */
	public WebElement getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @return the dateOfBirthHijri
	 */
	public WebElement getDateOfBirthHijri() {
		return dateOfBirthHijri;
	}

	/**
	 * @return the gender
	 */
	public WebElement getGender() {
		return gender;
	}

	/**
	 * @return the maritalStatus
	 */
	public WebElement getMaritalStatus() {
		return maritalStatus;
	}

	/**
	 * @return the nationality
	 */
	public WebElement getNationality() {
		return nationality;
	}

	/**
	 * @return the religion
	 */
	public WebElement getReligion() {
		return religion;
	}

	/**
	 * @return the telephoneOrMobileCode
	 */
	public WebElement getTelephoneOrMobileCode() {
		return TelephoneOrMobileCode;
	}

	/**
	 * @return the telephoneOrMobileNumber
	 */
	public WebElement getTelephoneOrMobileNumber() {
		return TelephoneOrMobileNumber;
	}

	/**
	 * @return the fatherOrMotherMRN
	 */
	public WebElement getFatherOrMotherMRN() {
		return FatherOrMotherMRN;
	}

	/**
	 * @return the identificationDocument
	 */
	public WebElement getIdentificationDocument() {
		return identificationDocument;
	}

	/**
	 * @return the identificationNo
	 */
	public WebElement getIdentificationNo() {
		return identificationNo;
	}

	/**
	 * @return the standardSearchButton
	 */
	public WebElement getStandardSearchButton() {
		return standardSearchButton;
	}

	/**
	 * @return the standardSearchRestButton
	 */
	public WebElement getStandardSearchResetButton() {
		return standardSearchResetButton;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the quicksearchId
	 */
	public static String getQuicksearchId() {
		return QUICKSEARCH_ID;
	}

	/**
	 * @return the quicksearchbuttonId
	 */
	public static String getQuicksearchbuttonId() {
		return QUICKSEARCHBUTTON_ID;
	}

	/**
	 * @return the quicksearchresetbuttonId
	 */
	public static String getQuicksearchresetbuttonId() {
		return QUICKSEARCHRESETBUTTON_ID;
	}

	/**
	 * @return the standardsearchexpandorcollapsebuttonId
	 */
	public static String getStandardsearchexpandorcollapsebuttonId() {
		return STANDARDSEARCHEXPANDORCOLLAPSEBUTTON_ID;
	}

	/**
	 * @return the registrationtypeName
	 */
	public static String getRegistrationtypeName() {
		return REGISTRATIONTYPE_NAME;
	}

	/**
	 * @return the patienttypeName
	 */
	public static String getPatienttypeName() {
		return PATIENTTYPE_NAME;
	}

	/**
	 * @return the mrnstandsearchName
	 */
	public static String getMrnstandsearchName() {
		return MRNSTANDSEARCH_NAME;
	}

	/**
	 * @return the staffidName
	 */
	public static String getStaffidName() {
		return STAFFID_NAME;
	}

	/**
	 * @return the patientnameName
	 */
	public static String getPatientnameName() {
		return PATIENTNAME_NAME;
	}

	/**
	 * @return the patientnamearName
	 */
	public static String getPatientnamearName() {
		return PATIENTNAMEAR_NAME;
	}

	/**
	 * @return the dateofbirthId
	 */
	public static String getDateofbirthId() {
		return DATEOFBIRTH_ID;
	}

	/**
	 * @return the dateofbirthhijriId
	 */
	public static String getDateofbirthhijriId() {
		return DATEOFBIRTHHIJRI_ID;
	}

	/**
	 * @return the genderId
	 */
	public static String getGenderId() {
		return GENDER_ID;
	}

	/**
	 * @return the maritalstatusName
	 */
	public static String getMaritalstatusName() {
		return MARITALSTATUS_NAME;
	}

	/**
	 * @return the nationalityName
	 */
	public static String getNationalityName() {
		return NATIONALITY_NAME;
	}

	/**
	 * @return the religionName
	 */
	public static String getReligionName() {
		return RELIGION_NAME;
	}

	/**
	 * @return the telephoneormobilecodeName
	 */
	public static String getTelephoneormobilecodeName() {
		return TELEPHONEORMOBILECODE_NAME;
	}

	/**
	 * @return the telephoneormobilenumberName
	 */
	public static String getTelephoneormobilenumberName() {
		return TELEPHONEORMOBILENUMBER_NAME;
	}

	/**
	 * @return the fatherormothermrnName
	 */
	public static String getFatherormothermrnName() {
		return FATHERORMOTHERMRN_NAME;
	}

	/**
	 * @return the identificationdocumentName
	 */
	public static String getIdentificationdocumentName() {
		return IDENTIFICATIONDOCUMENT_NAME;
	}

	/**
	 * @return the identificationnoName
	 */
	public static String getIdentificationnoName() {
		return IDENTIFICATIONNO_NAME;
	}

	/**
	 * @return the standardsearchbuttonId
	 */
	public static String getStandardsearchbuttonId() {
		return STANDARDSEARCHBUTTON_ID;
	}

	/**
	 * @return the standardsearchresetbuttonXpath
	 */
	public static String getStandardsearchresetbuttonXpath() {
		return STANDARDSEARCHRESETBUTTON_XPATH;
	}

}
