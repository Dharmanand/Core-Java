package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PatientEducationSection extends DriverWaitClass {
	public final static String PATEDUSEC_XPATH = "//a[text()='Patient Education']";
	@FindBy(xpath = PATEDUSEC_XPATH)
	private WebElement patEducationSec;

	public final static String PATEDUNOTES_NAME = "consultationSummary.plan.patientEducationNotes";
	@FindBy(name = PATEDUNOTES_NAME)
	private WebElement patientEducationNotes;

	public void addPatientEducationSecData(String[] outPatientListData) {
		patientEducationNotes.clear();
		patientEducationNotes.sendKeys(outPatientListData[76]);
	}

	public WebElement getPatEducationSec() {
		return patEducationSec;
	}

	public WebElement getPatientEducationNotes() {
		return patientEducationNotes;
	}

	public boolean checkPatEducationSec() {
		return patEducationSec.isDisplayed();
	}

}
