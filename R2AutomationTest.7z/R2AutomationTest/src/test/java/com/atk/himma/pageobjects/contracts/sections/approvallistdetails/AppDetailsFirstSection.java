package com.atk.himma.pageobjects.contracts.sections.approvallistdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AppDetailsFirstSection extends DriverWaitClass {

	public final static String APPLISTCODE_ID = "APP_LIST_CODE";
	public final static String APPLISTNAME_ID = "APP_LIST_NAME";
	public final static String MBULISTNAME_ID = "MBU_NAME";
	public final static String GLOBALAPP_ID = "APPRVL_GLOBAL_CHBOX_MAIN";
	public final static String GLOBALAPPMBU_ID = "GLOBAL_APPMAIN_MBU";

	@FindBy(id = APPLISTCODE_ID)
	private WebElement appListCode;

	@FindBy(id = APPLISTNAME_ID)
	private WebElement appListName;

	@FindBy(id = MBULISTNAME_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALAPP_ID)
	private WebElement globalApp;

	@FindBy(id = GLOBALAPPMBU_ID)
	private WebElement globalAppMBU;

	public boolean isMandApprvlListName() {
		waitForElementId(APPLISTNAME_ID);
		return isMandatoryField(appListName);
	}

	public boolean isMandMBU() {
		waitForElementId(MBULISTNAME_ID);
		return isMandatoryField(mbuList);
	}

	public void fillData(String[] apprvlListFirstSectionData) throws Exception {
		waitForElementId(APPLISTNAME_ID);
		sleepVeryShort();
		appListName.clear();
		appListName.sendKeys(apprvlListFirstSectionData[1]);
		if (!apprvlListFirstSectionData[2].isEmpty()) {
			new Select(mbuList)
					.selectByVisibleText(apprvlListFirstSectionData[2]);
		}
		if (Boolean.valueOf(apprvlListFirstSectionData[3])) {
			globalApp.click();
		}

	}

	public String checkFieldValue() {
		return appListName.getAttribute("value");
	}

	public String checkGlobalApprvl() throws Exception {
		globalApp.click();
		confirmOkDialogBox();
		sleepVeryShort();
		return globalAppMBU.getAttribute("value");

	}

	public WebElement getAppListCode() {
		return appListCode;
	}

	public WebElement getAppListName() {
		return appListName;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalApp() {
		return globalApp;
	}

	public WebElement getGlobalAppMBU() {
		return globalAppMBU;
	}

}
