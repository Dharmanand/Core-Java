package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class PregFirstSection extends DriverWaitClass {

	private final static String MRN_ID = "mrNumberId";

	@FindBy(id = MRN_ID)
	private WebElement mrn;

	private final static String PATIENTTYPE_ID = "PATIENT_TYPE";

	@FindBy(id = PATIENTTYPE_ID)
	private WebElement patientType;

	private final static String STAFFID_ID = "STAFFID";

	@FindBy(id = STAFFID_ID)
	private WebElement staffID;

	private final static String UPLOADDOCUMENT_ID = "fileupload";

	@FindBy(id = UPLOADDOCUMENT_ID)
	private WebElement uploadDocument;
	
	private final static String RECORDSTATUSBUTTON_ID = "RECORDSTATUSBUTTON_ID";

	@FindBy(id = RECORDSTATUSBUTTON_ID)
	private WebElement recordstatusButton;

	private final static String STATUSBUTTON_ID = "UPDATE_MAIN_STATUS";

	@FindBy(id = STATUSBUTTON_ID)
	private WebElement statusButton;

	private final static String MAINRECORDINFORMATION_ID = "fieldinfo";

	@FindBy(id = MAINRECORDINFORMATION_ID)
	private WebElement mainRecordInformation;

	private final static String EXPANDANDCOLLAPSEBUTTON_XPATH = "//span[@title='Expand / Collapse']";

	@FindBy(xpath = EXPANDANDCOLLAPSEBUTTON_XPATH)
	private WebElement expandAndCollapseButton;

	private final static String INACTIVEREASON_ID = "inactiveReason";

	@FindBy(id = INACTIVEREASON_ID)
	private WebElement inactiveReason;

	private final static String WORKINGSTATUS_ID = "WORKING_STATUS";

	@FindBy(id = WORKINGSTATUS_ID)
	private WebElement workingStatus;

	private final static String REASON_ID = "WORKSTATUS_REASON";

	@FindBy(id = REASON_ID)
	private WebElement reason;

	private final static String DESCRIPTION_ID = "RECORD_STATUS_DESC";

	@FindBy(id = DESCRIPTION_ID)
	private WebElement description;

	private final static String APPLYBUTTON_ID = "APPLY_RECORD";

	@FindBy(id = APPLYBUTTON_ID)
	private WebElement applyButton;

	private final static String INACTIVE_XPATH = "//input[@value='Inactivate']";

	@FindBy(xpath = INACTIVE_XPATH)
	private WebElement inactive;

	private final static String ACTIVATE_ID = "//input[@value='Activate']";

	@FindBy(xpath = ACTIVATE_ID)
	private WebElement activate;

	public void fillDatasOfPregFirstSection(String[] excelData,
			WebDriverWait webDriverWait) throws InterruptedException {
		new Select(getPatientType()).selectByVisibleText(excelData[0].trim());
		if (excelData[0].trim().equals("Staff")) {
			// webDriverWait.until(ExpectedConditions.visibilityOf(firstSection.getStaffID()));
			// webDriverWait.until(ExpectedConditions.visibilityOf(firstSection.getUploadDocument()));
			waitForElementId(STAFFID_ID);
			sleepVeryShort();
			getStaffID().clear();
			getStaffID().sendKeys(excelData[1].trim());
			getUploadDocument().sendKeys(excelData[2]);
		}
	}

	/**
	 * @return the mrn
	 */
	public WebElement getMrn() {
		return mrn;
	}

	/**
	 * @return the patientType
	 */
	public WebElement getPatientType() {
		return patientType;
	}

	/**
	 * @return the statusButton
	 */
	public WebElement getStatusButton() {
		return statusButton;
	}

	/**
	 * @return the mainRecordInformation
	 */
	public WebElement getMainRecordInformation() {
		return mainRecordInformation;
	}

	/**
	 * @return the expandAndCollapseButton
	 */
	public WebElement getExpandAndCollapseButton() {
		return expandAndCollapseButton;
	}

	/**
	 * @return the inactiveReason
	 */
	public WebElement getInactiveReason() {
		return inactiveReason;
	}

	/**
	 * @return the workingStatus
	 */
	public WebElement getWorkingStatus() {
		return workingStatus;
	}

	/**
	 * @return the reason
	 */
	public WebElement getReason() {
		return reason;
	}

	/**
	 * @return the description
	 */
	public WebElement getDescription() {
		return description;
	}

	/**
	 * @return the applyButton
	 */
	public WebElement getApplyButton() {
		return applyButton;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the staffID
	 */
	public WebElement getStaffID() {
		return staffID;
	}

	/**
	 * @return the uploadDocument
	 */
	public WebElement getUploadDocument() {
		return uploadDocument;
	}

	/**
	 * @return the mrnId
	 */
	public static String getMrnId() {
		return MRN_ID;
	}

	/**
	 * @return the patienttypeId
	 */
	public static String getPatienttypeId() {
		return PATIENTTYPE_ID;
	}

	/**
	 * @return the staffidId
	 */
	public static String getStaffidId() {
		return STAFFID_ID;
	}

	/**
	 * @return the uploaddocumentId
	 */
	public static String getUploaddocumentId() {
		return UPLOADDOCUMENT_ID;
	}

	/**
	 * @return the statusbuttonId
	 */
	public static String getStatusbuttonId() {
		return STATUSBUTTON_ID;
	}

	/**
	 * @return the mainrecordinformationId
	 */
	public static String getMainrecordinformationId() {
		return MAINRECORDINFORMATION_ID;
	}

	/**
	 * @return the expandandcollapsebuttonXpath
	 */
	public static String getExpandandcollapsebuttonXpath() {
		return EXPANDANDCOLLAPSEBUTTON_XPATH;
	}

	/**
	 * @return the inactivereasonId
	 */
	public static String getInactivereasonId() {
		return INACTIVEREASON_ID;
	}

	/**
	 * @return the workingstatusId
	 */
	public static String getWorkingstatusId() {
		return WORKINGSTATUS_ID;
	}

	/**
	 * @return the reasonId
	 */
	public static String getReasonId() {
		return REASON_ID;
	}

	/**
	 * @return the descriptionId
	 */
	public static String getDescriptionId() {
		return DESCRIPTION_ID;
	}

	/**
	 * @return the applybuttonId
	 */
	public static String getApplybuttonId() {
		return APPLYBUTTON_ID;
	}

	/**
	 * @return the inactiveXpath
	 */
	public static String getInactiveXpath() {
		return INACTIVE_XPATH;
	}

	/**
	 * @return the inactive
	 */
	public WebElement getInactive() {
		return inactive;
	}

	/**
	 * @return the activateId
	 */
	public static String getActivateId() {
		return ACTIVATE_ID;
	}

	/**
	 * @return the activate
	 */
	public WebElement getActivate() {
		return activate;
	}

	/**
	 * @return the recordstatusbuttonId
	 */
	public static String getRecordstatusbuttonId() {
		return RECORDSTATUSBUTTON_ID;
	}

	/**
	 * @return the recordstatusButton
	 */
	public WebElement getRecordstatusButton() {
		return recordstatusButton;
	}

}
