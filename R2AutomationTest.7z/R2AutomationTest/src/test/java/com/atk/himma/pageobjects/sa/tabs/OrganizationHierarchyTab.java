package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.JsTreeSelector;

public class OrganizationHierarchyTab extends DriverWaitClass {
	public final static String ORGHIERARCHYTAB_XPATH = "//a[@title='Organization Hierarchy']";
	@FindBy(xpath = ORGHIERARCHYTAB_XPATH)
	private WebElement orgHierarchyTab;

	public final static String ORGHIERARCHYFORM_NAME = "organizationhierarchy";
	@FindBy(name = ORGHIERARCHYFORM_NAME)
	private WebElement orgHierarchyForm;

	public final static String ROOTORGANIZATION_ID = "rootName";
	@FindBy(id = ROOTORGANIZATION_ID)
	private WebElement rootOrganization;

	public final static String MANAGEROOTHIERARCHYBTN_ID = "MANAGE_ROOT_HIERARCHY_BTN";
	@FindBy(id = MANAGEROOTHIERARCHYBTN_ID)
	private WebElement manageRootHierarchyBtn;

	public final static String ORGINFOGRID_ID = "gbox_gridtable_orgInfo";
	@FindBy(id = ORGINFOGRID_ID)
	private WebElement orgInfoGrid;

	public final static String ORGTREEID_ID = "orgTreeId";
	@FindBy(id = ORGTREEID_ID)
	private WebElement orgTreeId;

	public final static String ADDUNITBTN_ID = "create";
	@FindBy(id = ADDUNITBTN_ID)
	private WebElement addUnitBtn;

	public final static String MODIFYUNITBTN_ID = "modify";
	@FindBy(id = MODIFYUNITBTN_ID)
	private WebElement modifyUnitBtn;

	public final static String DELETEUNITBTN_ID = "delete";
	@FindBy(id = DELETEUNITBTN_ID)
	private WebElement deleteUnitBtn;

	public final static String MANAGEMBUBTN_ID = "manageOprnButton";
	@FindBy(id = MANAGEMBUBTN_ID)
	private WebElement manageMbuBtn;

	public final static String SELECTEDPARENTORGUNIT_ID = "parentName";
	@FindBy(id = SELECTEDPARENTORGUNIT_ID)
	private WebElement selectedParentOrgUnit;

	public final static String ORGUNITTYPE_ID = "ORG_UNIT_TYPE_ADD";
	@FindBy(id = ORGUNITTYPE_ID)
	private WebElement orgUnitType;

	public final static String DEPARTMENT = "Department";
	public final static String SPECIALTY = "Specialty";
	public final static String SUBSPECIALTY = "Sub Specialty";

	public final static String DEPARTMENT_ID = "DEPARTMENT_ID";
	@FindBy(id = DEPARTMENT_ID)
	private WebElement deptTypeOrgUnit;

	public final static String SPECIALTY_ID = "SPECIALTY_ID";
	@FindBy(id = SPECIALTY_ID)
	private WebElement spltyTypeOrgUnit;

	public final static String SUBSPECIALTY_ID = "SUBSPECIALTY_ID";
	@FindBy(id = SUBSPECIALTY_ID)
	private WebElement subSpltyTypeOrgUnit;

	public final static String ORGUNITSHORTNAME_ID = "ORG_SHORT_NAME";
	@FindBy(id = ORGUNITSHORTNAME_ID)
	private WebElement orgUnitShortName;

	public final static String ORGUNITNAME_ID = "ORG_UNIT_NAME_ADD";
	@FindBy(id = ORGUNITNAME_ID)
	private WebElement orgUnitName;

	public final static String ORGUNITNAMEAR_ID = "ORG_UNIT_NAMENL_ADD";
	@FindBy(id = ORGUNITNAMEAR_ID)
	private WebElement orgUnitNameAr;

	public final static String ORGUNITCODE_ID = "ORG_UNIT_CODE_ADD";
	@FindBy(id = ORGUNITCODE_ID)
	private WebElement orgUnitCode;

	public final static String MBU_ID = "MAIN_BUSINESS_UNIT";
	@FindBy(id = MBU_ID)
	private WebElement mbu;

	public final static String SAVEBTN_XPATH = "//input[@value='Save']";
	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	public final static String SUCCESSMSG_XPATH = "//span[@id='statusMsgContainer']/label[@class='successMsg']";
	@FindBy(xpath = SUCCESSMSG_XPATH)
	private WebElement successMessage;

	public final static String ERRORMSG_XPATH = "//span[@id='statusMsgContainer']/label[@class='errorMsg']";
	@FindBy(xpath = ERRORMSG_XPATH)
	private WebElement errorMessage;

	public final static String CANCELBTN_XPATH = "//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String MODSELECTEDPARENTORGUNIT_ID = "parentOrgName";
	@FindBy(id = MODSELECTEDPARENTORGUNIT_ID)
	private WebElement modSelectedParentOrgUnit;

	public final static String MODORGUNITTYPE_ID = "ORG_UNIT_TYPE_MOD";
	@FindBy(id = MODORGUNITTYPE_ID)
	private WebElement modOrgUnitType;

	public final static String MODORGUNITSHORTNAME_ID = "ORG_SHORT_NAME_MOD";
	@FindBy(id = MODORGUNITSHORTNAME_ID)
	private WebElement modOrgUnitShortName;

	public final static String MODDEPTORGUNIT_ID = "MOD_DEPARTMENT_ID";
	@FindBy(id = MODDEPTORGUNIT_ID)
	private WebElement modDeptOrgUnit;

	public final static String MODORGUNITNAME_ID = "modName";
	@FindBy(id = MODORGUNITNAME_ID)
	private WebElement modOrgUnitName;

	public final static String MODORGUNITNAMEAR_ID = "modNameNL";
	@FindBy(id = MODORGUNITNAMEAR_ID)
	private WebElement modOrgUnitNameAr;

	public final static String MODORGUNITCODE_ID = "modCode";
	@FindBy(id = MODORGUNITCODE_ID)
	private WebElement modOrgUnitCode;

	public final static String MODMBU_ID = "modMainBusinessUnit";
	@FindBy(id = MODMBU_ID)
	private WebElement modMbu;

	public final static String UPDATEBTN_XPATH = "//form[@id = 'FORM_MOD_ORG']/..//input[@value='Update']";
	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	public void addOrgStructure(String[] orgStructData) throws Exception {
		if (orgStructData.length == 0) {
			waitForElementId(ORGINFOGRID_ID);
			waitForElementId(MANAGEROOTHIERARCHYBTN_ID);
			manageRootHierarchyBtn.click();
			sleepVeryShort();
			new JsTreeSelector(webDriver, webDriverWait)
					.expandTree(ORGTREEID_ID);
		} else {
			waitForElementPartialLinkText(orgStructData[0].trim());
			sleepVeryShort();
			getOrgTreeId().findElement(By.partialLinkText(orgStructData[0]))
					.click();
			sleepVeryShort();
			String manageMBUButton = getManageMbuBtn().getAttribute("class");
			if (manageMBUButton.equals("input_button")) {
				manageMainBusinessUnit(orgStructData);
			} else {
				addUnit(orgStructData);
			}
		}
	}

	private void manageMainBusinessUnit(String[] orgStructData)
			throws Exception {
		// waitForElementLinkText(orgStructData[0]);
		webDriver.findElement(By.partialLinkText(orgStructData[0])).click();
		sleepVeryShort();
		if (getManageMbuBtn().isEnabled()) {
			manageMbuBtn.click();
			sleepVeryShort();
			webDriver.findElement(By.partialLinkText(orgStructData[0])).click();
			addUnit(orgStructData);
		}
	}

	private void addUnit(String[] orgStructData) throws Exception {
		boolean isMbu = Boolean.parseBoolean(orgStructData[2]);
		waitForElementId(ORGINFOGRID_ID);
		waitForElementId(ADDUNITBTN_ID);
		addUnitBtn.click();
		waitForElementId(ORGUNITTYPE_ID);
		new Select(orgUnitType).selectByVisibleText(orgStructData[3]);
		if (DEPARTMENT.equals(orgStructData[3])) {
			waitForElementId(DEPARTMENT_ID);
			new Select(deptTypeOrgUnit).selectByVisibleText(orgStructData[1]);
		} else if (SPECIALTY.equals(orgStructData[3])) {
			waitForElementId(SPECIALTY_ID);
			new Select(spltyTypeOrgUnit).selectByVisibleText(orgStructData[1]);
		} else if (SUBSPECIALTY.equals(orgStructData[3])) {
			waitForElementId(SUBSPECIALTY_ID);
			new Select(subSpltyTypeOrgUnit)
					.selectByVisibleText(orgStructData[1]);
		} else {
			waitForElementId(ORGUNITNAME_ID);
			orgUnitName.sendKeys(orgStructData[1]);
		}

		if (isMbu) {
			waitForElementId(MBU_ID);
			mbu.click();
		}
		saveBtn.click();
		sleepShort();
	}

	public void editOrgStructure(String[] editOrgStructData) throws Exception {
		getOrgTreeId().findElement(By.partialLinkText(editOrgStructData[1]))
				.click();
		modifyUnitBtn.click();
		sleepShort();
		new Select(modDeptOrgUnit).selectByVisibleText(editOrgStructData[2]);
		updateBtn.click();
		sleepShort();
	}

	public void deleteUnit(String[] deleteOrgStructData) throws Exception {
		getOrgTreeId().findElement(By.partialLinkText(deleteOrgStructData[1]))
				.click();
		deleteUnitBtn.click();
		sleepShort();
		waitForElementId(CONFIRMYES_ID);
		confirmYes.click();
		sleepShort();
	}

	public WebElement getOrgHierarchyTab() {
		return orgHierarchyTab;
	}

	public WebElement getOrgHierarchyForm() {
		return orgHierarchyForm;
	}

	public WebElement getRootOrganization() {
		return rootOrganization;
	}

	public WebElement getManageRootHierarchyBtn() {
		return manageRootHierarchyBtn;
	}

	public WebElement getOrgInfoGrid() {
		return orgInfoGrid;
	}

	public WebElement getOrgTreeId() {
		return orgTreeId;
	}

	public WebElement getAddUnitBtn() {
		return addUnitBtn;
	}

	public WebElement getModifyUnitBtn() {
		return modifyUnitBtn;
	}

	public WebElement getDeleteUnitBtn() {
		return deleteUnitBtn;
	}

	public WebElement getManageMbuBtn() {
		return manageMbuBtn;
	}

	public WebElement getSelectedParentOrgUnit() {
		return selectedParentOrgUnit;
	}

	public WebElement getOrgUnitType() {
		return orgUnitType;
	}

	public WebElement getDeptTypeOrgUnit() {
		return deptTypeOrgUnit;
	}

	public WebElement getSpltyTypeOrgUnit() {
		return spltyTypeOrgUnit;
	}

	public WebElement getSubSpltyTypeOrgUnit() {
		return subSpltyTypeOrgUnit;
	}

	public WebElement getOrgUnitShortName() {
		return orgUnitShortName;
	}

	public WebElement getOrgUnitName() {
		return orgUnitName;
	}

	public WebElement getOrgUnitNameAr() {
		return orgUnitNameAr;
	}

	public WebElement getOrgUnitCode() {
		return orgUnitCode;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getSuccessMessage() {
		return successMessage;
	}

	public WebElement getErrorMessage() {
		return errorMessage;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getModSelectedParentOrgUnit() {
		return modSelectedParentOrgUnit;
	}

	public WebElement getModOrgUnitType() {
		return modOrgUnitType;
	}

	public WebElement getModOrgUnitShortName() {
		return modOrgUnitShortName;
	}

	public WebElement getModDeptOrgUnit() {
		return modDeptOrgUnit;
	}

	public WebElement getModOrgUnitName() {
		return modOrgUnitName;
	}

	public WebElement getModOrgUnitNameAr() {
		return modOrgUnitNameAr;
	}

	public WebElement getModOrgUnitCode() {
		return modOrgUnitCode;
	}

	public WebElement getModMbu() {
		return modMbu;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

}
