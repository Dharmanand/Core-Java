package com.atk.himma.pageobjects.sa.admin;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.admin.tabs.MainBusinessUnitsTab;
import com.atk.himma.pageobjects.sa.admin.tabs.RegionalSettingsInformationTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class RegionalSettingsPage extends DriverWaitClass implements
		StatusMessages {
	private MainBusinessUnitsTab mainBusinessUnitsTab;
	private RegionalSettingsInformationTab regionalSettingsInformationTab;

	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		mainBusinessUnitsTab = PageFactory.initElements(webDriver,
				MainBusinessUnitsTab.class);
		mainBusinessUnitsTab.setWebDriver(webDriver);
		mainBusinessUnitsTab.setWebDriverWait(webDriverWait);

		regionalSettingsInformationTab = PageFactory.initElements(webDriver,
				RegionalSettingsInformationTab.class);
		regionalSettingsInformationTab.setWebDriver(webDriver);
		regionalSettingsInformationTab.setWebDriverWait(webDriverWait);

	}

	public RegionalSettingsPage clickOnRegionalSettingsMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> regSettingsParentMenuList = new LinkedList<String>();
		regSettingsParentMenuList.add("System Administration");
		regSettingsParentMenuList.add("Admin ");
		menuSelector.clickOnTargetMenu(regSettingsParentMenuList,
				"Regional Settings");
		RegionalSettingsPage regionalSettingsPage = PageFactory.initElements(
				webDriver, RegionalSettingsPage.class);
		regionalSettingsPage.setWebDriver(webDriver);
		regionalSettingsPage.setWebDriverWait(webDriverWait);
		return regionalSettingsPage;

	}

	public MainBusinessUnitsTab getMainBusinessUnitsTab() {
		return mainBusinessUnitsTab;
	}

	public RegionalSettingsInformationTab getRegionalSettingsInformationTab() {
		return regionalSettingsInformationTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
