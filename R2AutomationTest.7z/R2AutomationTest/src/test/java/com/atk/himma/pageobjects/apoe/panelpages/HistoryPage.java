package com.atk.himma.pageobjects.apoe.panelpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class HistoryPage extends DriverWaitClass {
	public final static String HPITAB_XPATH = ".//a[@href='#HISTROY_DIV']";
	@FindBy(xpath = HPITAB_XPATH)
	private WebElement hpiTab;

	public final static String MEDICATIONSTAB_XPATH = ".//a[@href='#Medications']";
	@FindBy(xpath = MEDICATIONSTAB_XPATH)
	private WebElement medicationsTab;

	public final static String HPISAVEBTN_XPATH = ".//form[@id='CONSULTATION_HISTROY_FORM']/..//input[@value='Save']";
	@FindBy(xpath = HPISAVEBTN_XPATH)
	private WebElement hpiSaveBtn;

	public final static String HPIUPDATEBTN_XPATH = ".//form[@id='CONSULTATION_HISTROY_FORM']/..//input[@value='Update']";
	@FindBy(xpath = HPIUPDATEBTN_XPATH)
	private WebElement hpiUpdateBtn;

	public final static String HPICANCELBTN_XPATH = ".//form[@id='CONSULTATION_HISTROY_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = HPICANCELBTN_XPATH)
	private WebElement hpiCancelBtn;

	public final static String MEDICATIONSSAVEBTN_XPATH = ".//form[@id='CONSULTATION_MEDICATION_FORM']/..//input[@value='Save']";
	@FindBy(xpath = MEDICATIONSSAVEBTN_XPATH)
	private WebElement medicationsSaveBtn;

	public final static String MEDICATIONSCANCELBTN_XPATH = ".//form[@id='CONSULTATION_MEDICATION_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = MEDICATIONSCANCELBTN_XPATH)
	private WebElement medicationsCancelBtn;
	
	public String checkMedicationTab() {
		return medicationsTab.getText();
		
	}
	
	public void clickSaveHPI() throws Exception {
		hpiSaveBtn.click();
		sleepVeryShort();
		waitForElementXpathExpression(HPIUPDATEBTN_XPATH);
		
	}
	
	public void clickMedicationsTab() throws Exception {
		medicationsTab.click();
		sleepVeryShort();
		waitForElementXpathExpression(MEDICATIONSSAVEBTN_XPATH);
		
	}
	
	public void saveMedicationsDetails() throws Exception {
		medicationsSaveBtn.click();
		sleepVeryShort();
		waitForElementXpathExpression(MEDICATIONSSAVEBTN_XPATH);
		
	}

	public WebElement getHpiTab() {
		return hpiTab;
	}

	public WebElement getMedicationsTab() {
		return medicationsTab;
	}

	public WebElement getHpiSaveBtn() {
		return hpiSaveBtn;
	}

	public WebElement getHpiUpdateBtn() {
		return hpiUpdateBtn;
	}

	public WebElement getHpiCancelBtn() {
		return hpiCancelBtn;
	}

	public WebElement getMedicationsSaveBtn() {
		return medicationsSaveBtn;
	}

	public WebElement getMedicationsCancelBtn() {
		return medicationsCancelBtn;
	}

}
