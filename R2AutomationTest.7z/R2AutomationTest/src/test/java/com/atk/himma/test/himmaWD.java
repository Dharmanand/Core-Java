package com.atk.himma.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

public class himmaWD {
	private Selenium selenium;

	@BeforeTest
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://abkqar1:8080/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@Test
	public void testHimmaWD() throws Exception {
		selenium.open("/himma-core/qarthree/qarthree/Home.action");
		selenium.type("id=userName", "k");
		selenium.click("id=submit_901865398");
		selenium.waitForPageToLoad("30000");
		selenium.click("id=submit_482171870");
		selenium.waitForPageToLoad("30000");
		selenium.select("id=locationId", "label=clinic1");
		selenium.click("id=submit_1223667945");
		selenium.waitForPageToLoad("30000");
		selenium.click("id=anchor_1155350483");
		selenium.click("id=SEARCH_BRANDED_DRUG_BUTTON");
		selenium.click("id=SEARCH_BRANDED_DRUG_LIST_Edit_1");
		selenium.click("css=td[title=\"Edit &nbspDelete\"] > a[title=\"Edit\"]");
		selenium.click("id=submit_383308893");
		selenium.click("css=span.ui-icon.ui-icon-plus");
		selenium.click("id=submit_1040986786");
		selenium.click("id=submit_965407729");
		selenium.click("id=submit_1566357395");
		selenium.click("css=img[alt=\"Sign Out\"]");
		selenium.waitForPageToLoad("30000");
	}

	@AfterTest
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
