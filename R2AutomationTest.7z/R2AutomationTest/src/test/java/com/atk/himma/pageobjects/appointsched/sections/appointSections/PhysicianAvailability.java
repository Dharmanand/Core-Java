package com.atk.himma.pageobjects.appointsched.sections.appointSections;

import java.text.ParseException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DateTimeConverter;

public class PhysicianAvailability extends ResourceAvailability {

	public final static String FORM_ID = "searchPhysicianForm";

	public final static String PHYSICIAN_ID = "physicianId";
	public static int noOfslotsForPhysician;
	@FindBy(id = FORM_ID)
	private WebElement formId;

	@FindBy(id = PHYSICIAN_ID)
	private WebElement physician;

	public AppointmentDairy clickOnAvailableSession(String physicianName,
			String sessionName) throws InterruptedException {

		String elementXpath = "//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),'"
				+ physicianName.trim()
				+ "')]/../..//a[text()='"
				+ sessionName.trim() + "']";
		return clickAvailDateResSession(elementXpath);
	}

	public AppointmentDairy clickOnAvailDateSession(String physicianName,
			String sessionName, String locationName, String date)
			throws InterruptedException {

		String elementXpath = clickOnAvailSession(physicianName, sessionName,
				locationName, date);
		return clickAvailDateResSession(elementXpath);
	}

	private String clickOnAvailSession(String physicianName,
			String sessionName, String locationName, String date)
			throws InterruptedException {
		int i = dateColumnCount(date);
		// Avail Link Location Session under Location and Physician
		String availLocLinkXpath = null;

		if (sessionName.contains("Morning")) {
			availLocLinkXpath = "(//table[@id='recourceAvailableGrid']//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),'"
					+ physicianName.trim()
					+ "')]/../..//td[@title='"
					+ locationName.trim() + "'])[1]/../td[" + i + "]//a";
		} else if (sessionName.contains("Evening")) {
			availLocLinkXpath = "(//table[@id='recourceAvailableGrid']//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),'"
					+ physicianName.trim()
					+ "')]/../..//td[@title='"
					+ locationName.trim() + "'])[2]/../td[" + i + "]//a";
		} else if (sessionName.contains("Night")) {
			availLocLinkXpath = "(//table[@id='recourceAvailableGrid']//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),'"
					+ physicianName.trim()
					+ "')]/../..//td[@title='"
					+ locationName.trim() + "'])[3]/../td[" + i + "]//a";
		}
		return availLocLinkXpath;
	}

	public int noOfSlotsAllSession(String physicianName, int slotTimeInterval)
			throws ParseException {
		String elementXpath = "//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),'"
				+ physicianName.trim()
				+ "')]/../..//td[@aria-describedby='recourceAvailableGrid_sessionName']//a]";
		List<WebElement> elements = webDriver.findElements(By
				.xpath(elementXpath));
		noOfslotsForPhysician = 0;
		for (WebElement we : elements) {
			String frmTM = we.getText().split("\\(")[1].split("-")[0].trim();
			String toTM = we.getText().split("\\(")[1].split("-")[1]
					.split("\\)")[0].trim();
			noOfslotsForPhysician = noOfslotsForPhysician
					+ (int) DateTimeConverter.noOfSlots(frmTM, toTM,
							slotTimeInterval);
		}
		return (int) noOfslotsForPhysician;
	}

	/**
	 * @return the physician
	 */
	public WebElement getPhysician() {
		return physician;
	}

	/**
	 * @return the formId
	 */
	public WebElement getFormId() {
		return formId;
	}

}
