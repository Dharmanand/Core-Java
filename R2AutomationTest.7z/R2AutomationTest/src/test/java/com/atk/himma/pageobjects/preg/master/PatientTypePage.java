package com.atk.himma.pageobjects.preg.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class PatientTypePage extends DriverWaitClass implements StatusMessages {

	public final static String MENULINK_XPATH = "//a[contains(text(),'Patient Registration')]/..//a[contains(text(),'Patient Type')]";
	private final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	private final static String CODE_ID = "codeId";

	@FindBy(id = CODE_ID)
	private WebElement code;

	private final static String PATIENTTYPENAME_ID = "nameId";

	@FindBy(id = PATIENTTYPENAME_ID)
	private WebElement patientTypeName;

	private final static String STATUS_ID = "PATTYPE_STATUS";

	@FindBy(id = STATUS_ID)
	private WebElement status;

	private final static String HASFIXEDPOLICY_ID = "HasFixedContract";

	@FindBy(id = HASFIXEDPOLICY_ID)
	private WebElement hasfixedPolicy;

	private final static String POLICYNAME_ID = "contrctName";

	@FindBy(id = POLICYNAME_ID)
	private WebElement policyName;

	private final static String DEBTORNAME_ID = "dbtrId";

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	private final static String POLICYSTARTDATE_ID = "datepicker1";

	@FindBy(id = POLICYSTARTDATE_ID)
	private WebElement policyStartDate;

	private final static String POLICYENDDATE_ID = "datepicker2";

	@FindBy(id = POLICYENDDATE_ID)
	private WebElement policyEndDate;

	private final static String PATIENTGRID_ID = "gview_sample_grid";

	@FindBy(id = PATIENTGRID_ID)
	private WebElement patientGrid;

	private final static String ADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";

	@FindBy(xpath = ADDNEWBUTTON_XPATH)
	private WebElement addNewButton;

	private final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	private final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";

	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;
	
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'created successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'modified successfully')]";
	public final static String DELETECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'deleted successfully')]";
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = DELETECONFMSG_XPATH)
	private WebElement deleteConfMsg;
	
	public final static String ADDNEW_XPATH = "//input[@value='Add New']";

	@FindBy(xpath = ADDNEW_XPATH)
	private WebElement addNew;
	
	// ---------------------------------------------- Grid Start
	// -----------------------------------------

	public final static String GRID_ID= "sample_grid";
	public final static String GRID_CODE_ARIA_DESCRIBEDBY = "sample_grid_code";
	public final static String GRID_PATIENTNAME_ARIA_DESCRIBEDBY = "sample_grid_name";
	public final static String GRID_CONTRACTNAME_ARIA_DESCRIBEDBY = "sample_grid_contractName";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "sample_grid_id";

	// ---------------------------------------------- Grid End
	// -----------------------------------------

	private final static String DELETECONFBUTTON_ID = "MSG_DIALOG_YES";
	
	@FindBy(id = DELETECONFBUTTON_ID)
	private WebElement deleteYesButton;
	
	public PatientTypePage clickOnpatientTypeMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws InterruptedException {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Patient Registration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Patient Type");
		PatientTypePage patientTypePage = PageFactory.initElements(webDriver,
				PatientTypePage.class);
		patientTypePage.setWebDriver(webDriver);
		patientTypePage.setWebDriverWait(webDriverWait);
		sleepShort();
		return patientTypePage;
	}

	public boolean savePatientTypePage(String[] patientTypeDatas,
			WebDriver webDriver, WebDriverWait webDriverWait) throws InterruptedException {
		code.sendKeys(patientTypeDatas[0].trim());
		patientTypeName.sendKeys(patientTypeDatas[1].trim());
		new Select(status).selectByVisibleText(patientTypeDatas[2].trim());
		if (!(Boolean.getBoolean(patientTypeDatas[3].trim()) == hasfixedPolicy
				.isSelected()))
			hasfixedPolicy.click();
		if (hasfixedPolicy.isSelected()) {
			policyName.sendKeys(patientTypeDatas[4].trim());
			debtorName.sendKeys(patientTypeDatas[5].trim());
			policyStartDate.sendKeys(patientTypeDatas[6].trim());
			policyEndDate.sendKeys(patientTypeDatas[7].trim());
		}
		saveButton.click();
		waitForElementId(GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(GRID_ID, GRID_PATIENTNAME_ARIA_DESCRIBEDBY, patientTypeDatas[1].trim()).equals(patientTypeDatas[1].trim());
	}

	public boolean cancelEntry(String[] patientTypeDatas) {
		code.sendKeys(patientTypeDatas[0].trim());
		patientTypeName.sendKeys(patientTypeDatas[1].trim());
		new Select(status).selectByVisibleText(patientTypeDatas[2].trim());
		if (!(Boolean.getBoolean(patientTypeDatas[3].trim()) == hasfixedPolicy
				.isSelected()))
			hasfixedPolicy.click();
		if (hasfixedPolicy.isSelected()) {
			policyName.sendKeys(patientTypeDatas[4].trim());
			debtorName.sendKeys(patientTypeDatas[5].trim());
			policyStartDate.sendKeys(patientTypeDatas[6].trim());
			policyEndDate.sendKeys(patientTypeDatas[7].trim());
		}
		cancelButton.click();
		waitForElementId(PATIENTGRID_ID);
		if (patientTypeName.getAttribute("value").trim().isEmpty())
			return true;
		else
			return false;
	}

	public String editRow(String[] patientTypeDatas, String ptyCode) throws InterruptedException {
		clickOnGridAction(GRID_CODE_ARIA_DESCRIBEDBY,
				ptyCode, "Edit");
		waitForElementXpathExpression(UPDATEBUTTON_XPATH);
		waitForElementVisibilityOf(updateButton);
		patientTypeName.clear();
		patientTypeName.sendKeys(patientTypeDatas[1].trim());
		new Select(status).selectByVisibleText(patientTypeDatas[2].trim());
		if (!(Boolean.getBoolean(patientTypeDatas[3].trim()) == hasfixedPolicy
				.isSelected()))
			hasfixedPolicy.click();
		if (hasfixedPolicy.isSelected()) {
			policyName.clear();
			policyName.sendKeys(patientTypeDatas[4].trim());
			debtorName.clear();
			debtorName.sendKeys(patientTypeDatas[5].trim());
			policyStartDate.clear();
			policyStartDate.sendKeys(patientTypeDatas[6].trim());
			policyEndDate.clear();
			policyEndDate.sendKeys(patientTypeDatas[7].trim());
		}
		updateButton.click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		sleepShort();
		return updateConfMsg.getText().trim();
	}

	public boolean searchRecord(String patTypeName,
			String patCode) throws InterruptedException {
		waitForElementId(GRID_ID);
		sleepShort();
		WebDriverWait driverWait = webDriverWait;
		try {
			webDriverWait = new WebDriverWait(webDriver, 1);
			waitForGridSearchText(patCode.trim());
			waitForGridSearchText(patTypeName.trim());
			sleepShort();
			webDriverWait = driverWait;
			return true;
		} catch (Exception e) {
			webDriverWait = driverWait;
			return false;
		}
	}
	
	public boolean viewRow(String[] patientTypeDatas, String ptyCode) throws InterruptedException {
		clickOnGridAction(GRID_CODE_ARIA_DESCRIBEDBY, ptyCode, "View");
		waitForElementXpathExpression(ADDNEWBUTTON_XPATH);
		waitForElementXpathExpression(ADDNEW_XPATH);
		sleepShort();
		if(patientTypeDatas[0].trim().equals(code.getAttribute("value").trim()))
			return true;
		else
			return false;
	}

	public String deleteRow(String[] patientTypeDatas, String ptyCode) throws InterruptedException {
		sleepVeryShort();
		clickOnGridAction(GRID_CODE_ARIA_DESCRIBEDBY, ptyCode, "Delete");
		waitForElementId(DELETECONFBUTTON_ID);
		sleepVeryShort();
		getDeleteYesButton().click();
		waitForElementXpathExpression(DELETECONFMSG_XPATH);
		return deleteConfMsg.getText().trim();
	}
	/**
	 * @return the code
	 */
	public WebElement getCode() {
		return code;
	}

	/**
	 * @return the patientTypeName
	 */
	public WebElement getPatientTypeName() {
		return patientTypeName;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the hasfixedPolicy
	 */
	public WebElement getHasfixedPolicy() {
		return hasfixedPolicy;
	}

	/**
	 * @return the policyName
	 */
	public WebElement getPolicyName() {
		return policyName;
	}

	/**
	 * @return the debtorName
	 */
	public WebElement getDebtorName() {
		return debtorName;
	}

	/**
	 * @return the policyStartDate
	 */
	public WebElement getPolicyStartDate() {
		return policyStartDate;
	}

	/**
	 * @return the policyEndDate
	 */
	public WebElement getPolicyEndDate() {
		return policyEndDate;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the codeId
	 */
	public static String getCodeId() {
		return CODE_ID;
	}

	/**
	 * @return the patienttypenameId
	 */
	public static String getPatienttypenameId() {
		return PATIENTTYPENAME_ID;
	}

	/**
	 * @return the statusId
	 */
	public static String getStatusId() {
		return STATUS_ID;
	}

	/**
	 * @return the hasfixedpolicyId
	 */
	public static String getHasfixedpolicyId() {
		return HASFIXEDPOLICY_ID;
	}

	/**
	 * @return the policynameId
	 */
	public static String getPolicynameId() {
		return POLICYNAME_ID;
	}

	/**
	 * @return the debtornameId
	 */
	public static String getDebtornameId() {
		return DEBTORNAME_ID;
	}

	/**
	 * @return the policystartdateId
	 */
	public static String getPolicystartdateId() {
		return POLICYSTARTDATE_ID;
	}

	/**
	 * @return the policyenddateId
	 */
	public static String getPolicyenddateId() {
		return POLICYENDDATE_ID;
	}

	/**
	 * @return the addnewbuttonXpath
	 */
	public static String getAddnewbuttonXpath() {
		return ADDNEWBUTTON_XPATH;
	}

	/**
	 * @return the savebuttonXpath
	 */
	public static String getSavebuttonXpath() {
		return SAVEBUTTON_XPATH;
	}

	/**
	 * @return the cancelbuttonXpath
	 */
	public static String getCancelbuttonXpath() {
		return CANCELBUTTON_XPATH;
	}

	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the gridCodeAriaDescribedby
	 */
	public static String getGridCodeAriaDescribedby() {
		return GRID_CODE_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridPatientnameAriaDescribedby
	 */
	public static String getGridPatientnameAriaDescribedby() {
		return GRID_PATIENTNAME_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridContractnameAriaDescribedby
	 */
	public static String getGridContractnameAriaDescribedby() {
		return GRID_CONTRACTNAME_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the gridActionAriaDescribedby
	 */
	public static String getGridActionAriaDescribedby() {
		return GRID_ACTION_ARIA_DESCRIBEDBY;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the patientgridId
	 */
	public static String getPatientgridId() {
		return PATIENTGRID_ID;
	}

	/**
	 * @return the patientGrid
	 */
	public WebElement getPatientGrid() {
		return patientGrid;
	}

	/**
	 * @return the updatebuttonXpath
	 */
	public static String getUpdatebuttonXpath() {
		return UPDATEBUTTON_XPATH;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the deleteconfbuttonId
	 */
	public static String getDeleteconfbuttonId() {
		return DELETECONFBUTTON_ID;
	}

	/**
	 * @return the deleteYesButton
	 */
	public WebElement getDeleteYesButton() {
		return deleteYesButton;
	}

	/**
	 * @return the addnewXpath
	 */
	public static String getAddnewXpath() {
		return ADDNEW_XPATH;
	}

	/**
	 * @return the addNew
	 */
	public WebElement getAddNew() {
		return addNew;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the deleteConfMsg
	 */
	public WebElement getDeleteConfMsg() {
		return deleteConfMsg;
	}

}
