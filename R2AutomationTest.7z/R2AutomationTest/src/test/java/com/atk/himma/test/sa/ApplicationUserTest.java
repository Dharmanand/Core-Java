package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.sa.ApplicationUserPage;
import com.atk.himma.pageobjects.sa.tabs.AppUserCredentialsSection;
import com.atk.himma.pageobjects.sa.tabs.AppUserIdentifiersSection;
import com.atk.himma.pageobjects.sa.tabs.AppUserProfessionalDetailsSection;
import com.atk.himma.pageobjects.sa.tabs.ApplicationUserListTab;
import com.atk.himma.pageobjects.sa.tabs.ContactDetailsSection;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ApplicationUserTest extends SeleniumDriverSetup {
	ApplicationUserPage applicationUserPage;
	LoginPage loginPage;
	List<String[]> userList;
	List<String[]> posList;

	@Test(description = "Open Application User Page")
	public void openApplicationUserPage() throws Exception {
		applicationUserPage = PageFactory.initElements(webDriver,
				ApplicationUserPage.class);
		applicationUserPage = applicationUserPage.clickOnApplicationUserMenu(
				webDriver, webDriverWait);
		applicationUserPage.initPages(webDriver, webDriverWait);
		applicationUserPage.getUserInformationTab().initAllSections(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		Assert.assertNotNull(applicationUserPage);
		applicationUserPage.waitForElementVisibilityOf(applicationUserPage
				.getUserListTab().getAppUserListForm());
		Assert.assertTrue(applicationUserPage.getUserListTab()
				.getOrgUnitLookup().isDisplayed());
	}

	@Test(description = "Fill Default Section Data", dependsOnMethods = { "openApplicationUserPage" }, groups={"superAdminTestsGrp"})
	public void test1FillDefaultSectionData() throws Exception {
		userList = excelReader.read(properties.getProperty("applicationUser"));
		if (userList != null && !userList.isEmpty()) {
			applicationUserPage.getUserListTab().clickAddNewAppUser();
			applicationUserPage.getUserInformationTab().getDefaultSection()
					.addDefaultSectionData(userList.get(0));
		}
	}

	@Test(description = "Fill User Identifiers Section Data", dependsOnMethods = { "openApplicationUserPage" }, groups={"superAdminTestsGrp"})
	public void test2FillUserIdentifiersSectionData() throws Exception {
		if (userList != null && !userList.isEmpty()) {
			applicationUserPage.getUserInformationTab().getIdentifiersSection()
					.fillUserIdentifiers(userList.get(0));
		}
	}

	@Test(description = "Check Primary Position Data", dependsOnMethods = { "openApplicationUserPage" }, groups={"superAdminTestsGrp"})
	public void test3CheckPrimPosData() throws Exception {
		posList = excelReader.read(properties.getProperty("positionHierarchy"));
		if (userList != null && !userList.isEmpty()) {
			Assert.assertEquals(
					applicationUserPage.getUserInformationTab()
							.getProfessionalDetailsSection()
							.checkPrimPos(userList.get(0), posList), true);
		}
	}

	@Test(description = "Fill Professional Details Section Data", dependsOnMethods = { "test3CheckPrimPosData" }, groups={"superAdminTestsGrp"})
	public void test10FillProfDetailsSecData() throws Exception {
		if (userList != null && !userList.isEmpty()) {
			applicationUserPage.getUserInformationTab()
					.getProfessionalDetailsSection()
					.fillProfessionalDetails(userList.get(0), posList);

		}
	}

	@Test(description = "Fill Contact Details Section Data", dependsOnMethods = { "openApplicationUserPage" }, groups={"superAdminTestsGrp"})
	public void test4FillContactDetailsSectionData() throws Exception {
		if (userList != null && !userList.isEmpty()) {
			applicationUserPage.getUserInformationTab()
					.getContactDetailsSection()
					.fillContactDetails(userList.get(0));
		}
	}

	@Test(description = "Fill User Credentials Section Data", dependsOnMethods = { "openApplicationUserPage" }, groups={"superAdminTestsGrp"})
	public void test5FillUserCredSecData() throws Exception {
		if (userList != null && !userList.isEmpty()) {
			applicationUserPage.getUserInformationTab().getCredentialsSection()
					.fillCredentials(userList.get(0));
			Assert.assertEquals(applicationUserPage.getUserInformationTab()
					.getCredentialsSection().getStatusMsgLabel().getText(),
					"Available !!");
		}
	}

	@Test(description = "Save Application User Info", dependsOnMethods = {
			"test5FillUserCredSecData", "test2FillUserIdentifiersSectionData",
			"test3CheckPrimPosData" }, groups={"superAdminTestsGrp"})
	public void saveUserInfo() throws Exception {
		applicationUserPage.getUserInformationTab().getDefaultSection()
				.clickSave();
		applicationUserPage.waitForElementVisibilityOf(applicationUserPage
				.getUserInformationTab().getDefaultSection()
				.getAppUserIdNumber());
		Assert.assertNotNull(applicationUserPage.getUserInformationTab()
				.getDefaultSection().getUpdateBtnTop().isDisplayed(),
				"Add User Success");

	}

	@Test(description = "Activate A New User", dependsOnMethods = { "saveUserInfo" }, groups={"superAdminTestsGrp"})
	public void activateNewUser() throws Exception {
		Assert.assertEquals(applicationUserPage.getUserInformationTab()
				.getStatus().getMainStatusText().getText(), "New",
				"New User Record");
		applicationUserPage.getUserInformationTab().getStatus()
				.activateRecord();
		Assert.assertEquals(applicationUserPage.getUserInformationTab()
				.getStatus().getMainStatusText().getText(), "Active",
				"Activated User Record");
	}

	@Test(description = "Sign Out", dependsOnMethods = "activateNewUser", groups={"superAdminTestsGrp"})
	public void signOut() throws Exception {
		loginPage = applicationUserPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "signOut", groups={"superAdminTestsGrp"})
	public void login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(3,excelReader.read(properties.getProperty("loginSheetName"))), "User Home", "Failed Login");
	}

	@Test(description = "Add more Users", dependsOnMethods = { "openApplicationUserPage" }, groups={"adminTestsGrp"})
	public void test6AddMoreUsers() throws Exception {
		userList = excelReader.read(properties.getProperty("applicationUser"));
		posList = excelReader.read(properties.getProperty("positionHierarchy"));
		applicationUserPage.getUserListTab().clickAddNewAppUser();
		applicationUserPage.getUserInformationTab().initAllSections(webDriver,
				webDriverWait);
		for (String[] userData : userList.subList(1, userList.size())) {
			applicationUserPage.getUserInformationTab().getDefaultSection()
					.addDefaultSectionData(userData);
			applicationUserPage.getUserInformationTab().getIdentifiersSection()
					.fillUserIdentifiers(userData);
			applicationUserPage.getUserInformationTab()
					.getProfessionalDetailsSection()
					.checkPrimPos(userData, posList);
			applicationUserPage.getUserInformationTab()
					.getProfessionalDetailsSection()
					.fillProfessionalDetails(userData, posList);
			applicationUserPage.getUserInformationTab()
					.getContactDetailsSection().fillContactDetails(userData);
			applicationUserPage.getUserInformationTab().getCredentialsSection()
					.fillCredentials(userData);
			applicationUserPage.getUserInformationTab().getDefaultSection()
					.clickSave();
			applicationUserPage.getUserInformationTab().getStatus()
					.activateRecord();
			applicationUserPage.getUserInformationTab().getDefaultSection()
					.clickAddNewAppUser();
		}
		applicationUserPage.getUserInformationTab().getDefaultSection()
				.clickCancel();
	}

	@Test(description = "Search An Existing User", dependsOnMethods = { "test6AddMoreUsers" }, groups={"adminTestsGrp"})
	public void test7SearchExistingUser() throws Exception {
		if (userList != null && !userList.isEmpty()) {
			applicationUserPage.getUserListTab().searchAppUser(userList.get(1));
			Assert.assertTrue(applicationUserPage.getUserListTab()
					.searchGridData(userList.get(1)));
			applicationUserPage.getUserListTab().clickOnEdit(userList.get(1));
		}
	}

	@Test(description = "Edit An Existing User", dependsOnMethods = { "test7SearchExistingUser" }, groups={"adminTestsGrp"})
	public void test8EditExistingUser() throws Exception {
		userList = excelReader.read(properties.getProperty("editApplicationUser"));
		applicationUserPage.getUserInformationTab().getDefaultSection()
				.addDefaultSectionData(userList.get(0));
		applicationUserPage.getUserInformationTab().getIdentifiersSection()
				.fillUserIdentifiers(userList.get(0));
		applicationUserPage.getUserInformationTab().getCredentialsSection()
				.fillCredentials(userList.get(0));
		applicationUserPage.getUserInformationTab().getDefaultSection()
				.clickUpdate();
		Assert.assertEquals(
				applicationUserPage.getUserInformationTab().getDefaultSection()
						.getAppUserIdNumber().getAttribute("value"),
				userList.get(0)[0]);
	}

	@Test(description = "Delete An Existing User", dependsOnMethods = {
			"test7SearchExistingUser" }, alwaysRun = true, groups={"adminTestsGrp"})
	public void test9DeleteExistingUser() throws Exception {
		userList = excelReader.read(properties.getProperty("deleteAppUser"));
		applicationUserPage.getUserListTab().getAppUserListTab().click();
		if (userList != null && !userList.isEmpty()) {
			for (String[] userData : userList) {
				applicationUserPage.getUserListTab().searchAppUser(userData);
				Assert.assertTrue(applicationUserPage.getUserListTab()
						.searchGridData(userData));
				applicationUserPage.getUserListTab().clickOnDelete(userData);
				Assert.assertFalse(applicationUserPage.getUserListTab()
						.searchGridData(userData));
			}
		}
	}

	/*
	 * @Test(description = "Search primary Position for User Privilege",
	 * dependsOnMethods = { "openApplicationUserPage" }, groups="") public void
	 * getPrPosOfPrivCheck() throws Exception { if (userList != null &&
	 * !userList.isEmpty()) {
	 * applicationUserPage.getUserListTab().searchAppUser(userList.get(7));
	 * Assert.assertTrue(applicationUserPage.getUserListTab()
	 * .searchGridData(userList.get(7)));
	 * applicationUserPage.getUserListTab().clickOnEdit(userList.get(7)); }
	 * applicationUserPage.waitForElementId(ApplicationUserPage.PRIPOS_ID);
	 * applicationUserPage.sleepVeryShort(); List<String> poslist = new
	 * ArrayList<String>();
	 * poslist.add(applicationUserPage.getPrimaryPos().getAttribute("value")
	 * .trim()); fullPrivUserDatas.put("primaryPosition", poslist); }
	 */

	// [Application User] Open Form
	@Test(description = "Check Application User Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckApplicationUserPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel"));
		applicationUserPage = PageFactory.initElements(webDriver,
				ApplicationUserPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> userParentMenuList = new LinkedList<String>();
		userParentMenuList.add("System Administration");
		menuSelector.mouseOverOnTargetMenu(userParentMenuList,
				"Application User");
		applicationUserPage.setWebDriver(webDriver);
		applicationUserPage.setWebDriverWait(webDriverWait);
		applicationUserPage
				.waitForElementXpathExpression(ApplicationUserPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[Application User] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApplicationUserPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Application User] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			applicationUserPage = applicationUserPage
					.clickOnApplicationUserMenu(webDriver, webDriverWait);
			applicationUserPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(applicationUserPage);
			applicationUserPage.waitForElementVisibilityOf(applicationUserPage
					.getUserListTab().getAppUserListForm());
			applicationUserPage.sleepShort();
			Assert.assertEquals(applicationUserPage.getPageTitle().getText(),
					"Application User");
		}

	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckApplicationUserPageMenuLink")
	public void test03CheckViewLink() throws Exception {
		userList = excelReader.read(properties.getProperty("applicationUser"));
		for (String[] userData : userList.subList(2, 3)) {
			applicationUserPage.getUserListTab().privSearchAppUser(userData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApplicationUserListTab.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckApplicationUserPageMenuLink")
	public void test05CheckEditLink() throws Exception {
		userList = excelReader.read(properties.getProperty("applicationUser"));
		for (String[] userData : userList.subList(2, 3)) {
			applicationUserPage.getUserListTab().privSearchAppUser(userData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[List Tab] Edit  (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApplicationUserListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit  (Link in search result grid) privilege");
		if (actualPrivilage) 
			applicationUserPage.getUserListTab().clickOnEdit(
					userList.get(2));
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckApplicationUserPageMenuLink")
	public void test04CheckDeleteLink() throws Exception {
		userList = excelReader.read(properties.getProperty("applicationUser"));
		for (String[] userData : userList.subList(2, 3)) {
			applicationUserPage.getUserListTab().privSearchAppUser(userData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApplicationUserListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [Details Tab][Section: Audit Trail] View

	// [List Tab] Add New (Button)
	@Test(description = "Check Add New Application User Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckApplicationUserPageMenuLink")
	public void test02CheckAddNewUserBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(ApplicationUserListTab.ADDNEWAPPUSERBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");
	}

	// [Details Tab][Section: Application User Identifiers] View
	@Test(description = "Check Application User Identifiers Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckEditLink")
	public void test06CheckAppUserIdSection() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Application User")
				.get("[Details Tab][Section: Application User Identifiers] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(AppUserIdentifiersSection.USERIDSECTION_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Details Tab][Section: Application User Identifiers] View privilege");
	}

	// [Details Tab][Section: Professional Details] View
	@Test(description = "Check Professional Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckEditLink")
	public void test07CheckProfDetailsSection() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[Details Tab][Section: Professional Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(AppUserProfessionalDetailsSection.PROFDETAILSSECTION_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Details Tab][Section: Professional Details] View privilege");
	}

	// [Details Tab][Section: Contact Details] View
	@Test(description = "Check Contact Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckEditLink")
	public void test08CheckContactDetailsSection() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Application User")
				.get("[Details Tab][Section: Contact Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ContactDetailsSection.CONTACTDETAILSSECTION_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Details Tab][Section: Contact Details] View privilege");
	}

	// [Details Tab][Section: Application User Credentials] View
	@Test(description = "Check Application User Credentials Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckEditLink")
	public void test09CheckUserCredentialsSection() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Application User")
				.get("[Details Tab][Section: Application User Credentials] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(AppUserCredentialsSection.USERCREDENTIALSSECTION_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Details Tab][Section: Application User Credentials] View privilege");
	}

	// [Details Tab][Section: Application User Credentials] Reset Password
	// (Button)

}
