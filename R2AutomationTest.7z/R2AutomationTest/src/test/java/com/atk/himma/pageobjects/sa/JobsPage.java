package com.atk.himma.pageobjects.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.tabs.JobInformationTab;
import com.atk.himma.pageobjects.sa.tabs.JobListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class JobsPage extends DriverWaitClass implements StatusMessages {
	private JobListTab jobListTab;
	private JobInformationTab jobInformationTab;

	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Jobs')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(id = MSGHIDELNK_ID)
	private WebElement msgHideLink;

	public WebElement getMsgHideLink() {
		return msgHideLink;
	}

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		jobListTab = PageFactory.initElements(webDriver, JobListTab.class);
		jobListTab.setWebDriver(webDriver);
		jobListTab.setWebDriverWait(webDriverWait);

		jobInformationTab = PageFactory.initElements(webDriver,
				JobInformationTab.class);
		jobInformationTab.setWebDriver(webDriver);
		jobInformationTab.setWebDriverWait(webDriverWait);

	}

	public JobsPage clickOnJobsMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("System Administration");
		menuSelector.clickOnTargetMenu(menuList, "Jobs");
		JobsPage jobsPage = PageFactory.initElements(webDriver, JobsPage.class);
		jobsPage.setWebDriver(webDriver);
		jobsPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return jobsPage;
	}

	public String searchPrivilegeGroups(String jobName) throws InterruptedException
	{
		waitForElementId(JobListTab.JOBNAME_ID);
		sleepVeryShort();
		jobListTab.searchGridData(jobName);
		return waitAndGetGridFirstCellText(JobListTab.GRID_ID, JobListTab.GRID_PRIVGRPNAMES_ARIA_DESCRIBEDBY, jobName);
	}
	public String searchModuleName(String jobName) throws InterruptedException
	{
		waitForElementId(JobListTab.JOBNAME_ID);
		sleepVeryShort();
		jobListTab.searchGridData(jobName);
		return waitAndGetGridFirstCellText(JobListTab.GRID_ID, JobListTab.GRID_PRIVMODNAMES_ARIA_DESCRIBEDBY, jobName);
	}
	
	public JobListTab getJobListTab() {
		return jobListTab;
	}

	public JobInformationTab getJobInformationTab() {
		return jobInformationTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
