package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.AgrmntDocumentsScanSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.AgrmntSpecificRatePlanSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.AssociatedPoliciesSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.DebtorAgrmntDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.FinancialParametersSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.StandardDiscountPatternSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.DebtorAgreementListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class DebtorAgreementPage extends DriverWaitClass implements
		StatusMessages, RecordStatus {
	private DebtorAgreementListTab debtorAgreementListTab;
	private DebtorAgrmntDetailsFirstSection debtorAgrmntDetailsFirstSection;
	private AgrmntDocumentsScanSection agrmntDocumentsScanSection;
	private AssociatedPoliciesSection associatedPoliciesSection;
	private FinancialParametersSection financialParametersSection;
	private StandardDiscountPatternSection standardDiscountPatternSection;
	private AgrmntSpecificRatePlanSection agrmntSpecificRatePlanSection;
	private ExclusionListDetailsSection exclusionListDetailsSection;
	private ApprovalListDetailsSection approvalListDetailsSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[text()= 'Debtor Agreement']";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String DEBTORDETAILSFORM_ID = "debtorListDetailsformId";
	public final static String ADDNEWBTN_ID = "DEBT_AGRMNT_ADD_UPPER";
	public final static String COPYBTN_ID = "DEBT_AGRMNT_COPY_UPPER";
	public final static String SAVEBTN_ID = "DEBT_AGRMNT_SAVE_UPPER";
	public final static String UPDATEBTN_ID = "DEBT_AGRMNT_UPDATE_UPPER";
	public final static String CANCELBTN_ID = "DEBT_AGRMNT_CANCEL_UPPER";
	public final static String GOTODEBTORBTN_ID = "GO_TO_DEBTOR";
	public final static String ADDNEWPOLICYBTN_ID = "ADD_NEW_POLICY";

	public final static String EXCLISTDETAILSSECTION_ID = "AGR_EX_SECTION_title";
	public final static String EXCSECTIONDIV_ID = "AGR_EX_SECTION";
	public final static String APPRVLLISTDETAILSSECTION_ID = "AGR_APP_SECTION_title";
	public final static String APPRVLSECTIONDIV_ID = "AGR_APP_SECTION";
	

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = DEBTORDETAILSFORM_ID)
	private WebElement agrmntDetailsForm;

	@FindBy(id = ADDNEWBTN_ID)
	private WebElement addNewBtn;

	@FindBy(id = COPYBTN_ID)
	private WebElement copyBtn;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	@FindBy(id = CANCELBTN_ID)
	private WebElement cancelBtn;

	@FindBy(id = GOTODEBTORBTN_ID)
	private WebElement goToDebtorBtn;

	@FindBy(id = ADDNEWPOLICYBTN_ID)
	private WebElement addNewPolicyBtn;

	@FindBy(id = EXCLISTDETAILSSECTION_ID)
	private WebElement excListDetailsSection;

	@FindBy(id = EXCSECTIONDIV_ID)
	private WebElement excSectionDiv;

	@FindBy(id = APPRVLLISTDETAILSSECTION_ID)
	private WebElement apprvlListDetailsSection;

	@FindBy(id = APPRVLSECTIONDIV_ID)
	private WebElement apprvlSectionDiv;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		debtorAgreementListTab = PageFactory.initElements(webDriver,
				DebtorAgreementListTab.class);
		debtorAgreementListTab.setWebDriver(webDriver);
		debtorAgreementListTab.setWebDriverWait(webDriverWait);

		debtorAgrmntDetailsFirstSection = PageFactory.initElements(webDriver,
				DebtorAgrmntDetailsFirstSection.class);
		debtorAgrmntDetailsFirstSection.setWebDriver(webDriver);
		debtorAgrmntDetailsFirstSection.setWebDriverWait(webDriverWait);

		agrmntDocumentsScanSection = PageFactory.initElements(webDriver,
				AgrmntDocumentsScanSection.class);
		agrmntDocumentsScanSection.setWebDriver(webDriver);
		agrmntDocumentsScanSection.setWebDriverWait(webDriverWait);

		associatedPoliciesSection = PageFactory.initElements(webDriver,
				AssociatedPoliciesSection.class);
		associatedPoliciesSection.setWebDriver(webDriver);
		associatedPoliciesSection.setWebDriverWait(webDriverWait);

		financialParametersSection = PageFactory.initElements(webDriver,
				FinancialParametersSection.class);
		financialParametersSection.setWebDriver(webDriver);
		financialParametersSection.setWebDriverWait(webDriverWait);

		standardDiscountPatternSection = PageFactory.initElements(webDriver,
				StandardDiscountPatternSection.class);
		standardDiscountPatternSection.setWebDriver(webDriver);
		standardDiscountPatternSection.setWebDriverWait(webDriverWait);

		agrmntSpecificRatePlanSection = PageFactory.initElements(webDriver,
				AgrmntSpecificRatePlanSection.class);
		agrmntSpecificRatePlanSection.setWebDriver(webDriver);
		agrmntSpecificRatePlanSection.setWebDriverWait(webDriverWait);

		exclusionListDetailsSection = PageFactory.initElements(webDriver,
				ExclusionListDetailsSection.class);
		exclusionListDetailsSection.setWebDriver(webDriver);
		exclusionListDetailsSection.setWebDriverWait(webDriverWait);

		approvalListDetailsSection = PageFactory.initElements(webDriver,
				ApprovalListDetailsSection.class);
		approvalListDetailsSection.setWebDriver(webDriver);
		approvalListDetailsSection.setWebDriverWait(webDriverWait);

	}

	public DebtorAgreementPage clickOnDebtorAgreementMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "Debtor Agreement");
		DebtorAgreementPage debtorAgreementPage = PageFactory.initElements(
				webDriver, DebtorAgreementPage.class);
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return debtorAgreementPage;
	}

	public void collapseExpandExcSection() throws Exception {
		waitForElementId(EXCLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getExcListDetailsSection().getAttribute(
				"class"))) {
			excListDetailsSection.click();
			sleepMedium();
		}

	}

	public void collapseExpandApprvlSection() throws Exception {
		waitForElementId(APPRVLLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getApprvlListDetailsSection().getAttribute(
				"class"))) {
			apprvlListDetailsSection.click();
			sleepMedium();
		}

	}

	public void saveDebtorAgreementDetails() throws Exception {
		saveBtn.click();
		sleepVeryShort();
		waitForElementId(UPDATEBTN_ID);
		sleepShort();

	}

	public String activateRecord() throws Exception {
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickCreateNewPolicyBtn() throws Exception {
		addNewPolicyBtn.click();
		doDirtyPopUpCheck();
		sleepShort();
		waitForPageLoaded(webDriver);

	}

	public Object verifyDebtorAgrmnt(String[] debtorAgrmntListData) {
		PolicyPage policyPage = PageFactory.initElements(webDriver,
				PolicyPage.class);
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		policyPage.initPages(webDriver, webDriverWait);
		String debtorAgrmntName = policyPage.getPolicyDetailsFirstSection()
				.getSelectedAgrment();
		return debtorAgrmntName;
	}

	public void clickOnGoToDebtorBtn() throws Exception {
		waitForElementId(GOTODEBTORBTN_ID);
		sleepVeryShort();
		goToDebtorBtn.click();
		doDirtyPopUpCheck();
		waitForPageLoaded(webDriver);

	}

	public boolean verifyDebtorAssociatedAgreements(
			String[] debtorAgrmntListData) {
		DebtorPage debtorPage = PageFactory.initElements(webDriver,
				DebtorPage.class);
		debtorPage.setWebDriver(webDriver);
		debtorPage.setWebDriverWait(webDriverWait);
		debtorPage.initPages(webDriver, webDriverWait);
		return debtorPage.getAssociatedAgreementsSection()
				.checkAssociatedAgrmntData(debtorAgrmntListData);
	}

	public void collapseExpandDebtorExcSection() throws Exception {
		DebtorPage debtorPage = PageFactory.initElements(webDriver,
				DebtorPage.class);
		debtorPage.setWebDriver(webDriver);
		debtorPage.setWebDriverWait(webDriverWait);
		debtorPage.initPages(webDriver, webDriverWait);
		debtorPage.collapseExpandExcSection();
		sleepMedium();
	}

	public void collapseExpandDebtorApprvlSection() throws Exception {
		DebtorPage debtorPage = PageFactory.initElements(webDriver,
				DebtorPage.class);
		debtorPage.setWebDriver(webDriver);
		debtorPage.setWebDriverWait(webDriverWait);
		debtorPage.initPages(webDriver, webDriverWait);
		debtorPage.collapseExpandApprvlSection();
		sleepMedium();
	}

	public void updateDebtorDetails() throws Exception {
		DebtorPage debtorPage = PageFactory.initElements(webDriver,
				DebtorPage.class);
		debtorPage.setWebDriver(webDriver);
		debtorPage.setWebDriverWait(webDriverWait);
		debtorPage.getUpdateBtn().click();
		sleepMedium();
	}

	public DebtorAgreementListTab getDebtorAgreementListTab() {
		return debtorAgreementListTab;
	}

	public DebtorAgrmntDetailsFirstSection getDebtorAgrmntDetailsFirstSection() {
		return debtorAgrmntDetailsFirstSection;
	}

	public AgrmntDocumentsScanSection getAgrmntDocumentsScanSection() {
		return agrmntDocumentsScanSection;
	}

	public AssociatedPoliciesSection getAssociatedPoliciesSection() {
		return associatedPoliciesSection;
	}

	public FinancialParametersSection getFinancialParametersSection() {
		return financialParametersSection;
	}

	public StandardDiscountPatternSection getStandardDiscountPatternSection() {
		return standardDiscountPatternSection;
	}

	public AgrmntSpecificRatePlanSection getAgrmntSpecificRatePlanSection() {
		return agrmntSpecificRatePlanSection;
	}

	public ExclusionListDetailsSection getExclusionListDetailsSection() {
		return exclusionListDetailsSection;
	}

	public ApprovalListDetailsSection getApprovalListDetailsSection() {
		return approvalListDetailsSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getAgrmntDetailsForm() {
		return agrmntDetailsForm;
	}

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getGoToDebtorBtn() {
		return goToDebtorBtn;
	}

	public WebElement getAddNewPolicyBtn() {
		return addNewPolicyBtn;
	}

	public WebElement getExcListDetailsSection() {
		return excListDetailsSection;
	}

	public WebElement getExcSectionDiv() {
		return excSectionDiv;
	}

	public WebElement getApprvlListDetailsSection() {
		return apprvlListDetailsSection;
	}

	public WebElement getApprvlSectionDiv() {
		return apprvlSectionDiv;
	}

	public WebElement getActivateRecord() {
		return activateRecord;
	}

}
