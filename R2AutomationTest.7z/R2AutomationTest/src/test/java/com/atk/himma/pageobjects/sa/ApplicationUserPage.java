package com.atk.himma.pageobjects.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.tabs.ApplicationUserInformationTab;
import com.atk.himma.pageobjects.sa.tabs.ApplicationUserListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ApplicationUserPage extends DriverWaitClass implements
		StatusMessages, TopControls {
	private ApplicationUserListTab userListTab;
	private ApplicationUserInformationTab userInformationTab;

	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Application User')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String PRIPOS_ID = "primaryPositionText";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;
	
	@FindBy(id = PRIPOS_ID)
	private WebElement primaryPos;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		userListTab = PageFactory.initElements(webDriver,
				ApplicationUserListTab.class);
		userListTab.setWebDriver(webDriver);
		userListTab.setWebDriverWait(webDriverWait);

		userInformationTab = PageFactory.initElements(webDriver,
				ApplicationUserInformationTab.class);
		userInformationTab.setWebDriver(webDriver);
		userInformationTab.setWebDriverWait(webDriverWait);
	}

	public ApplicationUserPage clickOnApplicationUserMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("System Administration");
		menuList.add("Resource ");
		menuSelector.clickOnTargetMenu(menuList, "Application User");
		ApplicationUserPage applicationUserPage = PageFactory.initElements(
				webDriver, ApplicationUserPage.class);
		applicationUserPage.setWebDriver(webDriver);
		applicationUserPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return applicationUserPage;
	}

	public ApplicationUserListTab getUserListTab() {
		return userListTab;
	}

	public ApplicationUserInformationTab getUserInformationTab() {
		return userInformationTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the primaryPos
	 */
	public WebElement getPrimaryPos() {
		return primaryPos;
	}

}
