package com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;

public class PriceListFirstSection extends DriverWaitClass{
	
	public final static String PLCODE_ID = "PL_CODE";
	public final static String PLSHORTNAME_ID = "PL_SHORT_NAME";
	public final static String PLNAME_ID = "PL_NAME";
	public final static String PLNAMEAR_ID = "PL_ARABIC_NAME";
	public final static String STARTDATE_ID = "START_DATE";
	public final static String ENDDATE_ID = "END_DATE";
	public final static String VERSION_ID = "version_details";
	public final static String GLOBALPRICELIST_ID = "GLOBAL_PL";
	public final static String MBU_ID = "MBU_PRICE_LIST";
	public final static String RETRIEVEBUTTON_ID = "RETRIEVE_BUTTON";
	
	public final static String GRID_ID = "SERVICES_LIST_GRID";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_serviceInfo.serviceCode";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_serviceInfo.serviceName";
	public final static String GRID_SUBSPECIALITY_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_serviceInfo.subSpecialityText";
	public final static String GRID_SPECIALTY_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_serviceInfo.specialtyText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_serviceInfo.departmentText";
	public final static String GRID_BASEPRICE_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_basePrice";
	public final static String GRID_MODIFIEDPRICE_ARIA_DESCRIBEDBY = "SERVICES_LIST_GRID_modifiedPrice";
	public final static String GRID_PAGERID = "sp_1_SERVICES_LIST_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SERVICES_LIST_GRID_pager']";
	
	@FindBy(id = PLCODE_ID)
	private WebElement plCode;

	@FindBy(id = PLSHORTNAME_ID)
	private WebElement plShortName;
	
	@FindBy(id = PLNAME_ID)
	private WebElement plName;
	
	@FindBy(id = PLNAMEAR_ID)
	private WebElement plNameAR;
	
	@FindBy(id = STARTDATE_ID)
	private WebElement startDate;
	
	@FindBy(id = ENDDATE_ID)
	private WebElement endDate;
	
	@FindBy(id = VERSION_ID)
	private WebElement version;
	
	@FindBy(id = GLOBALPRICELIST_ID)
	private WebElement globalPriceList;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = RETRIEVEBUTTON_ID)
	private WebElement retrieveButton;

	public boolean isMandatoryPLShortName()
	{
		return isMandatoryField(plShortName);
	}
	
	public boolean isMandatoryPLName()
	{
		return isMandatoryField(plName);
	}
	
	public boolean isMandatoryMBU()
	{
		return isMandatoryField(mbu);
	}
	
	public boolean isMandatoryEffStartDate()
	{
		return isMandatoryField(startDate);
	}
	
	public boolean isMandatoryEffEndDate()
	{
		return isMandatoryField(endDate);
	}
	
	public boolean fillPLFirstSecDatas(String[] plDatas)
	{
		plShortName.clear();
		plShortName.sendKeys(plDatas[7].trim());
		plName.clear();
		plName.sendKeys(plDatas[8].trim());
		plNameAR.clear();
		plNameAR.sendKeys(plDatas[9].trim());
		startDate.clear();
		startDate.sendKeys(DateTimeConverter.currentISTDateFormat());
//		startDate.sendKeys(plDatas[10].trim());
		endDate.clear();
		endDate.sendKeys(plDatas[11].trim());
		if(!plDatas[12].isEmpty())
		new Select(version).selectByVisibleText(plDatas[12].trim());
		selectOrUnSelectCheckBox(plDatas[13].trim(), globalPriceList);
		if(!plDatas[14].isEmpty())
		new Select(mbu).selectByVisibleText(plDatas[0].trim());
		return endDate.getAttribute("value").trim().equals(plDatas[11].trim());
	}
	
	public boolean retriveService()
	{
		waitForElementId(RETRIEVEBUTTON_ID);
		retrieveButton.click();
		return checkGridEmpty(GRID_ID, GRID_PAGERID);
	}
	
	/**
	 * @return the plCode
	 */
	public WebElement getPlCode() {
		return plCode;
	}

	/**
	 * @return the plShortName
	 */
	public WebElement getPlShortName() {
		return plShortName;
	}

	/**
	 * @return the plName
	 */
	public WebElement getPlName() {
		return plName;
	}

	/**
	 * @return the plNameAR
	 */
	public WebElement getPlNameAR() {
		return plNameAR;
	}

	/**
	 * @return the startDate
	 */
	public WebElement getStartDate() {
		return startDate;
	}

	/**
	 * @return the endDate
	 */
	public WebElement getEndDate() {
		return endDate;
	}

	/**
	 * @return the version
	 */
	public WebElement getVersion() {
		return version;
	}

	/**
	 * @return the globalPriceList
	 */
	public WebElement getGlobalPriceList() {
		return globalPriceList;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the retrieveButton
	 */
	public WebElement getRetrieveButton() {
		return retrieveButton;
	}

}
