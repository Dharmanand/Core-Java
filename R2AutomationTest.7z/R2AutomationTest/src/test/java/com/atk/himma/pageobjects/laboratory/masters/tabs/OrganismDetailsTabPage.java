package com.atk.himma.pageobjects.laboratory.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class OrganismDetailsTabPage extends DriverWaitClass {
	public final static String ADDNEWORGUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	@FindBy(xpath = ADDNEWORGUPBTN_XPATH)
	private WebElement addNewOrgUpBtn;

	public final static String SAVEUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	@FindBy(xpath = SAVEUPBTN_XPATH)
	private WebElement saveUpBtn;

	public final static String CANCELUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	@FindBy(id = CANCELUPBTN_XPATH)
	private WebElement cancelUpBtn;

	public final static String UPDATEUPBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	@FindBy(id = UPDATEUPBTN_XPATH)
	private WebElement updateUpBtn;

	public final static String ORGANISMCODE_NAME = "organismInfo.organismCode";
	@FindBy(name = ORGANISMCODE_NAME)
	private WebElement organismCode;

	public final static String ORGANISMSHNAME_NAME = "organismInfo.organismShortName	";
	@FindBy(name = ORGANISMSHNAME_NAME)
	private WebElement organismShName;

	public final static String ORGANISMDESC_NAME = "organismInfo.organismDesc";
	@FindBy(name = ORGANISMDESC_NAME)
	private WebElement organismDesc;

	public final static String ORGANISMTYPE_NAME = "organismInfo.organismTypeId";
	@FindBy(name = ORGANISMTYPE_NAME)
	private WebElement organismType;

	public WebElement getAddNewOrgUpBtn() {
		return addNewOrgUpBtn;
	}

	public WebElement getSaveUpBtn() {
		return saveUpBtn;
	}

	public WebElement getCancelUpBtn() {
		return cancelUpBtn;
	}

	public WebElement getUpdateUpBtn() {
		return updateUpBtn;
	}

	public WebElement getOrganismCode() {
		return organismCode;
	}

	public WebElement getOrganismShName() {
		return organismShName;
	}

	public WebElement getOrganismDesc() {
		return organismDesc;
	}

	public WebElement getOrganismType() {
		return organismType;
	}

}
