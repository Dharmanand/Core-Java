package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class MedicationFromOurSourcesSection extends DriverWaitClass {
	public final static String MEDOURSRCSEC_XPATH = "//a[text()='Medication From Our Sources']";
	@FindBy(xpath = MEDOURSRCSEC_XPATH)
	private WebElement medOurSourcesSec;

	public final static String FILTER_ID = "PHARMACY_STATUS_SELECT";
	@FindBy(id = FILTER_ID)
	private WebElement filter;

	public final static String SEARCHPERIOD_ID = "PERIOD_SELECT_ID";
	@FindBy(id = SEARCHPERIOD_ID)
	private WebElement searchPeriod;

	public final static String OURMEDSEARCHBTN_ID = "OUR_MEDICATION_FILTER_BUT";
	@FindBy(id = OURMEDSEARCHBTN_ID)
	private WebElement ourMedSearchBtn;

	public final static String MEDFRMOURSRCGRIDTBL_ID = "MEDICATION_FRM_OUR_SRC_GRID";
	@FindBy(id = MEDFRMOURSRCGRIDTBL_ID)
	private WebElement medFrmOurSourceGridTbl;

	public boolean checkMedFromOurSources() {
		return medOurSourcesSec.isDisplayed();
	}

	public void addOurSrcSecData(String[] outPatientListData) throws Exception {
		if (!outPatientListData[74].isEmpty()) {
			new Select(filter).selectByVisibleText(outPatientListData[74]);
		}

		if (!outPatientListData[75].isEmpty()) {
			new Select(searchPeriod)
					.selectByVisibleText(outPatientListData[75]);
		}
		ourMedSearchBtn.click();
		sleepVeryShort();
		waitForElementId(MEDFRMOURSRCGRIDTBL_ID);

	}

	public WebElement getMedOurSourcesSec() {
		return medOurSourcesSec;
	}

	public WebElement getFilter() {
		return filter;
	}

	public WebElement getSearchPeriod() {
		return searchPeriod;
	}

	public WebElement getOurMedSearchBtn() {
		return ourMedSearchBtn;
	}

	public WebElement getMedFrmOurSourceGridTbl() {
		return medFrmOurSourceGridTbl;
	}

}
