package com.atk.himma.pageobjects.contracts.sections.debtordetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AssociatedAgreementsSection extends DriverWaitClass {
	public static final String ASSOCIATEDAGRMNTSSEC_LINKTEXT = "Associated Agreements";
	public final static String ASSOAGRMNTGRIDDIV = "gview_DEBT_AGMNT_LIST";

	@FindBy(linkText = ASSOCIATEDAGRMNTSSEC_LINKTEXT)
	private WebElement associatedAgrmntsSec;

	@FindBy(id = ASSOAGRMNTGRIDDIV)
	private WebElement assoAgrmntGridDiv;

	public boolean checkAssociatedAgrmntData(String[] debtorAgrmntListData) {
		waitForElementId(ASSOAGRMNTGRIDDIV);
		try {
			waitForElementXpathExpression(".//td[@aria-describedby='DEBT_AGMNT_LIST_agreementName' and @title='"
					+ debtorAgrmntListData[9] + "']");
			return webDriver
					.findElement(
							By.xpath(".//td[@aria-describedby='DEBT_AGMNT_LIST_agreementName' and @title='"
									+ debtorAgrmntListData[9] + "']"))
					.isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}

	public WebElement getAssociatedAgrmntsSec() {
		return associatedAgrmntsSec;
	}

	public WebElement getAssoAgrmntGridDiv() {
		return assoAgrmntGridDiv;
	}

}
