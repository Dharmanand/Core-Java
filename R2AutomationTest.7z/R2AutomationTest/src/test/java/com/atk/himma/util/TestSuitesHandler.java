package com.atk.himma.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.maven.reporting.MavenReportException;
import org.testng.TestNG;
import org.testng.xslt.mavenplugin.TestNgXsltMojo;

import com.atk.himma.setup.SeleniumDriverSetup;

public class TestSuitesHandler extends TestNgXsltMojo {

	public static void main(String[] args) throws MavenReportException {
		myTest();
	}

	public static void myTest() throws MavenReportException {
		String stPath[] = new File(TestSuitesHandler.class
				.getProtectionDomain().getCodeSource().getLocation().getPath())
				.getAbsolutePath().split("lib");

		try {
			SeleniumDriverSetup.properties = new Properties();
			SeleniumDriverSetup.properties.load(new FileInputStream(stPath[0]
					+ "src/test/resources/properties/config.properties"));
			System.out.println("---------> " + stPath[0]
					+ "src/test/resources/properties/config.properties");
		} catch (IOException e) {
			e.printStackTrace();
		}

		String filePath = SeleniumDriverSetup.properties
				.getProperty("currentXsltPath");
		SeleniumDriverSetup.scPath = filePath + "/Test-Results/screen-shots/";
		TestNG myTestNG = new TestNG();
		myTestNG.setOutputDirectory(filePath + "/Test-Results/test-output");
		List<String> files = new ArrayList<String>();
		TestSuitesHandler testSuitesHandler = new TestSuitesHandler();
		System.out.println("f.getAbsolutePath() --------->> " + filePath);
		files.add(stPath[0] + "src/test/resources/"
				+ SeleniumDriverSetup.properties.getProperty("testNGXmlFile"));
		myTestNG.setTestSuites(files);
		myTestNG.run();
		System.out.println("-------->>>>>>>>>> " + filePath
				+ "/Test-Results/test-output");
		testSuitesHandler.setSurefireReportDirectory(filePath
				+ "/Test-Results/test-output");
		testSuitesHandler.setOutputDir(filePath
				+ "/Test-Results/testNg-xslt-report");
		testSuitesHandler.executeReport(new Locale("English"));
	}
}
