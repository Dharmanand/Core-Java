package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class OrderDetailsSection extends DriverWaitClass {
	public final static String ORDERDTLSEC_XPATH = "//a[text()='Order Details']";
	@FindBy(xpath = ORDERDTLSEC_XPATH)
	private WebElement orderDtlSec;

	public final static String PHARMACYTAB_XPATH = ".//a[@href='#Pharmacy']";
	@FindBy(xpath = PHARMACYTAB_XPATH)
	private WebElement pharmacyTab;

	public final static String LABORATORYTAB_XPATH = ".//a[@href='#Laboratory']";
	@FindBy(xpath = LABORATORYTAB_XPATH)
	private WebElement laboratoryTab;

	public final static String RADIOLOGYTAB_XPATH = ".//a[@href='#Radiology']";
	@FindBy(xpath = RADIOLOGYTAB_XPATH)
	private WebElement radiologyTab;

	public final static String OTHERSTAB_XPATH = ".//a[@href='#Others']";
	@FindBy(xpath = OTHERSTAB_XPATH)
	private WebElement othersTab;

	public final static String SEARCHPCYTEXT_ID = "SEARCH_PHARMACY_STRING";
	@FindBy(id = SEARCHPCYTEXT_ID)
	private WebElement searchPcyText;

	public final static String SEARCHPCYBTN_ID = "SEARCH_PHARMACY_BUTTON";
	@FindBy(id = SEARCHPCYBTN_ID)
	private WebElement searchPcyBtn;

	public final static String PCYADVSEARCHBTN_ID = "PHARMACY_ADVANCED_SEARCH_BUTTON";
	@FindBy(id = PCYADVSEARCHBTN_ID)
	private WebElement pcyAdvSearchBtn;

	public final static String ADVSEARCHPCYDIV_ID = "PHARMACY_ADVANCED_SEARCH_UI";
	@FindBy(id = ADVSEARCHPCYDIV_ID)
	private WebElement advSearchPcyDiv;

	public final static String PCYMBU_ID = "MBU_ID_SEARCH";
	@FindBy(id = PCYMBU_ID)
	private WebElement pharmacyMBU;

	public final static String DRUGCATEGORY_NAME = "searchCriteria.brandedDrugCategoryId";
	@FindBy(name = DRUGCATEGORY_NAME)
	private WebElement drugCategory;

	public final static String DRUGCODE_NAME = "searchCriteria.brandedDrugCode";
	@FindBy(name = DRUGCODE_NAME)
	private WebElement drugCode;

	public final static String DRUGSHORTNAME_NAME = "searchCriteria.brandedDrugShortName";
	@FindBy(name = DRUGSHORTNAME_NAME)
	private WebElement drugShortName;

	public final static String DOSAGEFORM_NAME = "searchCriteria.drugDosageForm";
	@FindBy(name = DOSAGEFORM_NAME)
	private WebElement dosageForm;

	public final static String DRUGNAME_NAME = "searchCriteria.brandedDrugName";
	@FindBy(name = DRUGNAME_NAME)
	private WebElement drugName;

	public final static String DRUGSTATUS_NAME = "searchCriteria.mainStatus";
	@FindBy(name = DRUGSTATUS_NAME)
	private WebElement drugStatus;

	public final static String ANATOMICALMAINGRP_ID = "PHARMACY_ANATOMICAL_MAIN_GROUP";
	@FindBy(id = ANATOMICALMAINGRP_ID)
	private WebElement anatomicalMainGrp;

	public final static String THERAPEUTICGRP_ID = "PHARMACY_THERAPEUTIC_GROUP";
	@FindBy(id = THERAPEUTICGRP_ID)
	private WebElement therapeuticGrp;

	public final static String PHARMACOLOGICALSUBGRP_ID = "PHARMACY_PHARMACOLOGICAL_GROUP";
	@FindBy(id = PHARMACOLOGICALSUBGRP_ID)
	private WebElement pharmacologicalSubGrp;

	public final static String CHEMICALSUBGRP_ID = "PHARMACY_CHEMICAL_GROUP";
	@FindBy(id = CHEMICALSUBGRP_ID)
	private WebElement chemicalSubGrp;

	public final static String GENERICDRUGCODE_NAME = "searchCriteria.genericDrugCode";
	@FindBy(name = GENERICDRUGCODE_NAME)
	private WebElement genericDrugCode;

	public final static String GENERICDRUGSHNAME_NAME = "searchCriteria.shortName";
	@FindBy(name = GENERICDRUGSHNAME_NAME)
	private WebElement genericDrugShName;

	public final static String GENERICDRUGNAME_NAME = "searchCriteria.drugName";
	@FindBy(name = GENERICDRUGNAME_NAME)
	private WebElement genericDrugName;

	public final static String ADVPCYSEARCHBTN_ID = "ADV_SEARCH_PHARMACY_BUTTON";
	@FindBy(id = ADVPCYSEARCHBTN_ID)
	private WebElement advPcySearchBtn;

	public final static String PCYADVRESETBTN_XPATH = ".//div[@id='PHARMACY_ADVANCED_SEARCH_UI']//input[@value='Reset']";
	@FindBy(xpath = PCYADVRESETBTN_XPATH)
	private WebElement pcyAdvResetBtn;

	public final static String PCYDATALIST_XPATH = "//ul[@id='PHARMACY_MATRIX']//li";
	@FindBy(xpath = PCYDATALIST_XPATH)
	private WebElement pcyDataList;

	public final static String SEARCHLABTEXT_ID = "SEARCH_LABORATORY_STRING";
	@FindBy(id = SEARCHLABTEXT_ID)
	private WebElement searchLabText;

	public final static String SEARCHLABBTN_ID = "SEARCH_LABORATORY_BUTTON";
	@FindBy(id = SEARCHLABBTN_ID)
	private WebElement searchLabBtn;

	public final static String LABADVSEARCHBTN_ID = "LABORATORY_ADVANCED_SEARCH_BUTTON";
	@FindBy(id = LABADVSEARCHBTN_ID)
	private WebElement labAdvSearchBtn;

	public final static String LABADVSEARCHDIV_ID = "LABORATORY_ADVANCED_SEARCH_UI";
	@FindBy(id = LABADVSEARCHDIV_ID)
	private WebElement labAdvSearchDiv;

	public final static String LABSERVDEPT_ID = "LAB_DEPARTMENT";
	@FindBy(id = LABSERVDEPT_ID)
	private WebElement labServDept;

	public final static String LABSERVSPECIALTY_ID = "LAB_SPECIALITY";
	@FindBy(id = LABSERVSPECIALTY_ID)
	private WebElement labServSpecialty;

	public final static String LABSERVSUBSPECIALTY_ID = "LAB_SUB_SPECIALITY";
	@FindBy(id = LABSERVSUBSPECIALTY_ID)
	private WebElement labServSubSpecialty;

	public final static String ADVLABSEARCHBTN_ID = "ADV_SEARCH_LABORATORY_BUTTON";
	@FindBy(id = ADVLABSEARCHBTN_ID)
	private WebElement advLabSearchBtn;

	public final static String ADVLABRESETBTN_ID = "ADV_RESET_LABORATORY_BUTTON";
	@FindBy(id = ADVLABRESETBTN_ID)
	private WebElement advLabResetBtn;

	public final static String LABDATALIST_XPATH = "//ul[@id='LABORATORY_MATRIX']//li";
	@FindBy(xpath = LABDATALIST_XPATH)
	private WebElement labDataList;

	public final static String RADSEARCHTEXT_ID = "RADIOLOGY_SEARCH_STRING";
	@FindBy(id = RADSEARCHTEXT_ID)
	private WebElement radSearchText;

	public final static String RADSEARCHBTN_ID = "SEARCH_RADIOLOGY_BUTTON";
	@FindBy(id = RADSEARCHBTN_ID)
	private WebElement radSearchBtn;

	public final static String RADADVSEARCHBTN_ID = "RADIOLOGY_ADVANCED_SEARCH_BUTTON";
	@FindBy(id = RADADVSEARCHBTN_ID)
	private WebElement radAdvSearchBtn;

	public final static String RADADVSEARCHDIV_ID = "RADIOLOGY_ADVANCED_SEARCH_UI";
	@FindBy(id = RADADVSEARCHDIV_ID)
	private WebElement radAdvSearchDiv;

	public final static String RADSERVDEPT_ID = "RAD_DEPARTMENT";
	@FindBy(id = RADSERVDEPT_ID)
	private WebElement radServDept;

	public final static String RADSERVSPLTY_ID = "RAD_SPECIALITY";
	@FindBy(id = RADSERVSPLTY_ID)
	private WebElement radServSplty;

	public final static String RADSERVSUBSPLTY_ID = "RAD_SUB_SPECIALITY";
	@FindBy(id = RADSERVSUBSPLTY_ID)
	private WebElement radServSubSplty;

	public final static String ADVRADSEARCHBTN_ID = "ADV_SEARCH_RADIOLOGY_BUTTON";
	@FindBy(id = ADVRADSEARCHBTN_ID)
	private WebElement advRadSearchBtn;

	public final static String ADVRADRESETBTN_ID = "ADV_RESET_RADIOLOGY_BUTTON";
	@FindBy(id = ADVRADRESETBTN_ID)
	private WebElement advRadResetBtn;

	public final static String RADDATALIST_XPATH = "//ul[@id='RADIOLOGY_MATRIX']//li";
	@FindBy(xpath = RADDATALIST_XPATH)
	private WebElement radDataList;

	public final static String OTHERSSEARCHTEXT_ID = "OTHER_SRV_SEARCH_STRING";
	@FindBy(id = OTHERSSEARCHTEXT_ID)
	private WebElement othersSearchText;

	public final static String SEARCHOTHERSERVBTN_ID = "SEARCH_OTHER_SRV_BUTTON";
	@FindBy(id = SEARCHOTHERSERVBTN_ID)
	private WebElement searchOtherServBtn;

	public final static String OTHERADVSEARCHBTN_ID = "OTHER_ADVANCED_SEARCH_BUTTON";
	@FindBy(id = OTHERADVSEARCHBTN_ID)
	private WebElement otherAdvSearchBtn;

	public final static String OTHERADVSEARCHDIV_ID = "OTHERS_ADVANCED_SEARCH_UI";
	@FindBy(id = OTHERADVSEARCHDIV_ID)
	private WebElement otherAdvSearchDiv;

	public final static String OTHERSERVDEPT_ID = "OTHER_SRV_DEPARTMENT";
	@FindBy(id = OTHERSERVDEPT_ID)
	private WebElement otherServDept;

	public final static String OTHERSERVSPLTY_ID = "OTHER_SRV_SPECIALITY";
	@FindBy(id = OTHERSERVSPLTY_ID)
	private WebElement otherServSplty;

	public final static String OTHERSERVSUBSPLTY_ID = "OTHER_SRV_SUB_SPECIALITY";
	@FindBy(id = OTHERSERVSUBSPLTY_ID)
	private WebElement otherServSubSplty;

	public final static String ADVSEARCHOTHERSERVBTN_ID = "ADV_SEARCH_OTHER_SRV_BUTTON";
	@FindBy(id = ADVSEARCHOTHERSERVBTN_ID)
	private WebElement advSearchOtherServBtn;

	public final static String ADVRESETOTHERSERVBTN_ID = "ADV_RESET_OTHER_BUTTON";
	@FindBy(id = ADVRESETOTHERSERVBTN_ID)
	private WebElement advResetOtherServBtn;

	public final static String OTHERSDATALIST_XPATH = "//ul[@id='OTHER_SERVICE_MATRIX']//li";
	@FindBy(xpath = OTHERSDATALIST_XPATH)
	private WebElement othersDataList;

	public final static String SELECTIONGRIDTBL_ID = "SELECTION_LIST_GRID";
	@FindBy(id = SELECTIONGRIDTBL_ID)
	private WebElement selectionGridTbl;

	public boolean checkOrderDetailsSec() {
		return orderDtlSec.isDisplayed();
	}

	public boolean checkPharmacyTab() {
		return pharmacyTab.isDisplayed();
	}

	public boolean checkLaboratoryTab() {
		return laboratoryTab.isDisplayed();
	}

	public boolean checkRadiologyTab() {
		return radiologyTab.isDisplayed();
	}

	public boolean checkOthersTab() {
		return othersTab.isDisplayed();
	}

	public boolean clickPharmacyTab() {
		pharmacyTab.click();
		waitForElementId(SEARCHPCYTEXT_ID);
		return searchPcyText.isDisplayed();
	}

	public boolean isPcyDataEmpty() {
		boolean pcyData = false;
		try {
			waitForElementXpathExpression(PCYDATALIST_XPATH);
			pcyData = pcyDataList.isDisplayed();
		} catch (Exception e) {

		}
		return pcyData;
	}

	public void quickSearchPharmacyData(String[] orderEntryListData) {
		searchPcyText.clear();
		searchPcyText.sendKeys(orderEntryListData[19]);
		searchPcyBtn.click();

	}

	public boolean verifyPcySearchData(String[] orderEntryListData) {
		return webDriver.findElement(
				By.xpath(pcyDataList + "//a[contains(text(),'"
						+ orderEntryListData[19] + "')]")).isDisplayed();
	}

	public void advSearchPharmacyData(String[] orderEntryListData) {
		pcyAdvSearchBtn.click();
		waitForElementId(ADVSEARCHPCYDIV_ID);
		if (!orderEntryListData[20].isEmpty()) {
			new Select(pharmacyMBU).selectByVisibleText(orderEntryListData[20]);
		}
		if (!orderEntryListData[20].isEmpty()) {
			new Select(drugCategory)
					.selectByVisibleText(orderEntryListData[21]);
		}
		drugCode.clear();
		drugCode.sendKeys(orderEntryListData[22]);
		drugShortName.clear();
		drugShortName.sendKeys(orderEntryListData[23]);
		if (!orderEntryListData[24].isEmpty()) {
			new Select(dosageForm).selectByVisibleText(orderEntryListData[24]);
		}
		drugName.clear();
		drugName.sendKeys(orderEntryListData[25]);
		if (!orderEntryListData[26].isEmpty()) {
			new Select(drugStatus).selectByVisibleText(orderEntryListData[26]);
		}
		if (!orderEntryListData[27].isEmpty()) {
			new Select(anatomicalMainGrp)
					.selectByVisibleText(orderEntryListData[27]);
		}
		if (!orderEntryListData[28].isEmpty()) {
			new Select(therapeuticGrp)
					.selectByVisibleText(orderEntryListData[28]);
		}
		if (!orderEntryListData[29].isEmpty()) {
			new Select(pharmacologicalSubGrp)
					.selectByVisibleText(orderEntryListData[29]);
		}
		if (!orderEntryListData[30].isEmpty()) {
			new Select(chemicalSubGrp)
					.selectByVisibleText(orderEntryListData[30]);
		}
		genericDrugCode.clear();
		genericDrugCode.sendKeys(orderEntryListData[31]);
		genericDrugShName.clear();
		genericDrugShName.sendKeys(orderEntryListData[32]);
		genericDrugName.clear();
		genericDrugName.sendKeys(orderEntryListData[33]);
		advPcySearchBtn.click();
		waitForElementXpathExpression(PCYDATALIST_XPATH);

	}

	public void selectPharmacyOrderData(String[] orderEntryListData) {
		waitForElementXpathExpression(pcyDataList + "//a[contains(text(),'"
				+ orderEntryListData[19] + "')]");
		webDriver.findElement(
				By.xpath(pcyDataList + "//a[contains(text(),'"
						+ orderEntryListData[19] + "')]")).click();

	}

	public boolean clickLabTab() {
		laboratoryTab.click();
		waitForElementId(SEARCHLABTEXT_ID);
		return searchLabText.isDisplayed();
	}

	public boolean isLabDataEmpty() {
		boolean labData = false;
		try {
			waitForElementXpathExpression(LABDATALIST_XPATH);
			labData = labDataList.isDisplayed();
		} catch (Exception e) {

		}
		return labData;
	}

	public void quickSearchLabData(String[] orderEntryListData) {
		searchLabText.clear();
		searchLabText.sendKeys(orderEntryListData[34]);
		searchLabBtn.click();

	}

	public boolean verifyLabSearchData(String[] orderEntryListData) {
		return webDriver.findElement(
				By.xpath(labDataList + "//a[contains(text(),'"
						+ orderEntryListData[34] + "')]")).isDisplayed();
	}

	public void advSearchLabData(String[] orderEntryListData) {
		labAdvSearchBtn.click();
		waitForElementId(LABADVSEARCHDIV_ID);
		if (!orderEntryListData[35].isEmpty()) {
			new Select(labServDept).selectByVisibleText(orderEntryListData[35]);
		}
		if (!orderEntryListData[36].isEmpty()) {
			new Select(labServSpecialty)
					.selectByVisibleText(orderEntryListData[36]);
		}
		if (!orderEntryListData[37].isEmpty()) {
			new Select(labServSubSpecialty)
					.selectByVisibleText(orderEntryListData[37]);
		}
		advLabSearchBtn.click();
		waitForElementXpathExpression(LABDATALIST_XPATH);
	}

	public void selectLabOrderData(String[] orderEntryListData) {
		waitForElementXpathExpression(labDataList + "//a[contains(text(),'"
				+ orderEntryListData[34] + "')]");
		webDriver.findElement(
				By.xpath(labDataList + "//a[contains(text(),'"
						+ orderEntryListData[34] + "')]")).click();

	}
	
	public boolean clickRadTab() {
		radiologyTab.click();
		waitForElementId(RADSEARCHTEXT_ID);
		return radSearchText.isDisplayed();
	}

	public void quickSearchRadData(String[] orderEntryListData) {
		radSearchText.clear();
		radSearchText.sendKeys(orderEntryListData[38]);
		radSearchBtn.click();

	}

	public boolean isRadDataEmpty() {
		boolean radData = false;
		try {
			waitForElementXpathExpression(RADDATALIST_XPATH);
			radData = radDataList.isDisplayed();
		} catch (Exception e) {

		}
		return radData;
	}

	public boolean verifyRadSearchData(String[] orderEntryListData) {
		return webDriver.findElement(
				By.xpath(radDataList + "//a[contains(text(),'"
						+ orderEntryListData[38] + "')]")).isDisplayed();
	}

	public void advSearchRadData(String[] orderEntryListData) {
		radAdvSearchBtn.click();
		waitForElementId(RADADVSEARCHDIV_ID);
		if (!orderEntryListData[39].isEmpty()) {
			new Select(radServDept).selectByVisibleText(orderEntryListData[39]);
		}
		if (!orderEntryListData[40].isEmpty()) {
			new Select(radServSplty)
					.selectByVisibleText(orderEntryListData[40]);
		}
		if (!orderEntryListData[41].isEmpty()) {
			new Select(radServSubSplty)
					.selectByVisibleText(orderEntryListData[41]);
		}
		advRadSearchBtn.click();
		waitForElementXpathExpression(RADDATALIST_XPATH);

	}
	
	public void selectRadOrderData(String[] orderEntryListData) {
		waitForElementXpathExpression(radDataList + "//a[contains(text(),'"
				+ orderEntryListData[39] + "')]");
		webDriver.findElement(
				By.xpath(labDataList + "//a[contains(text(),'"
						+ orderEntryListData[39] + "')]")).click();

	}

	public boolean clickOthersTab() {
		othersTab.click();
		waitForElementId(OTHERSSEARCHTEXT_ID);
		return othersSearchText.isDisplayed();
	}

	public boolean isOthersDataEmpty() {
		boolean othersData = false;
		try {
			waitForElementXpathExpression(OTHERSDATALIST_XPATH);
			othersData = othersDataList.isDisplayed();
		} catch (Exception e) {

		}
		return othersData;
	}

	public void quickSearchOthersData(String[] orderEntryListData) {
		othersSearchText.clear();
		othersSearchText.sendKeys(orderEntryListData[42]);
		searchOtherServBtn.click();
	}

	public boolean verifyOthersSearchData(String[] orderEntryListData) {
		return webDriver.findElement(
				By.xpath(othersDataList + "//a[contains(text(),'"
						+ orderEntryListData[42] + "')]")).isDisplayed();
	}

	public void advSearchOthersData(String[] orderEntryListData) {
		otherAdvSearchBtn.click();
		waitForElementId(OTHERADVSEARCHDIV_ID);
		if (!orderEntryListData[43].isEmpty()) {
			new Select(otherServDept)
					.selectByVisibleText(orderEntryListData[43]);
		}
		if (!orderEntryListData[44].isEmpty()) {
			new Select(otherServSplty)
					.selectByVisibleText(orderEntryListData[44]);
		}
		if (!orderEntryListData[45].isEmpty()) {
			new Select(otherServSubSplty)
					.selectByVisibleText(orderEntryListData[45]);
		}
		advSearchOtherServBtn.click();
		waitForElementXpathExpression(OTHERSDATALIST_XPATH);

	}
	
	public String verifySelectionListData(String orderEntryListData) {
		waitForElementId(SELECTIONGRIDTBL_ID);
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='SELECTION_LIST_GRID_name' and @title='"
								+ orderEntryListData + "']")).getText();
	}

	public WebElement getOrderDtlSec() {
		return orderDtlSec;
	}

	public WebElement getPharmacyTab() {
		return pharmacyTab;
	}

	public WebElement getLaboratoryTab() {
		return laboratoryTab;
	}

	public WebElement getRadiologyTab() {
		return radiologyTab;
	}

	public WebElement getOthersTab() {
		return othersTab;
	}

	public WebElement getSearchPcyText() {
		return searchPcyText;
	}

	public WebElement getSearchPcyBtn() {
		return searchPcyBtn;
	}

	public WebElement getPsyAdvSearchBtn() {
		return pcyAdvSearchBtn;
	}

	public WebElement getAdvSearchPcyDiv() {
		return advSearchPcyDiv;
	}

	public WebElement getPharmacyMBU() {
		return pharmacyMBU;
	}

	public WebElement getDrugCategory() {
		return drugCategory;
	}

	public WebElement getDrugCode() {
		return drugCode;
	}

	public WebElement getDrugShortName() {
		return drugShortName;
	}

	public WebElement getDosageForm() {
		return dosageForm;
	}

	public WebElement getDrugName() {
		return drugName;
	}

	public WebElement getDrugStatus() {
		return drugStatus;
	}

	public WebElement getAnatomicalMainGrp() {
		return anatomicalMainGrp;
	}

	public WebElement getTherapeuticGrp() {
		return therapeuticGrp;
	}

	public WebElement getPharmacologicalSubGrp() {
		return pharmacologicalSubGrp;
	}

	public WebElement getChemicalSubGrp() {
		return chemicalSubGrp;
	}

	public WebElement getGenericDrugCode() {
		return genericDrugCode;
	}

	public WebElement getGenericDrugShName() {
		return genericDrugShName;
	}

	public WebElement getGenericDrugName() {
		return genericDrugName;
	}

	public WebElement getAdvPcySearchBtn() {
		return advPcySearchBtn;
	}

	public WebElement getPcyAdvResetBtn() {
		return pcyAdvResetBtn;
	}

	public WebElement getPcyDataList() {
		return pcyDataList;
	}

	public WebElement getSearchLabText() {
		return searchLabText;
	}

	public WebElement getSearchLabBtn() {
		return searchLabBtn;
	}

	public WebElement getLabAdvSearchBtn() {
		return labAdvSearchBtn;
	}

	public WebElement getLabAdvSearchDiv() {
		return labAdvSearchDiv;
	}

	public WebElement getLabServDept() {
		return labServDept;
	}

	public WebElement getLabServSpecialty() {
		return labServSpecialty;
	}

	public WebElement getLabServSubSpecialty() {
		return labServSubSpecialty;
	}

	public WebElement getAdvLabSearchBtn() {
		return advLabSearchBtn;
	}

	public WebElement getAdvLabResetBtn() {
		return advLabResetBtn;
	}

	public WebElement getLabDataList() {
		return labDataList;
	}

	public WebElement getRadSearchText() {
		return radSearchText;
	}

	public WebElement getRadSearchBtn() {
		return radSearchBtn;
	}

	public WebElement getRadAdvSearchBtn() {
		return radAdvSearchBtn;
	}

	public WebElement getRadAdvSearchDiv() {
		return radAdvSearchDiv;
	}

	public WebElement getRadServDept() {
		return radServDept;
	}

	public WebElement getRadServSplty() {
		return radServSplty;
	}

	public WebElement getRadServSubSplty() {
		return radServSubSplty;
	}

	public WebElement getAdvRadSearchBtn() {
		return advRadSearchBtn;
	}

	public WebElement getAdvRadResetBtn() {
		return advRadResetBtn;
	}

	public WebElement getRadDataList() {
		return radDataList;
	}

	public WebElement getOthersSearchText() {
		return othersSearchText;
	}

	public WebElement getSearchOtherServBtn() {
		return searchOtherServBtn;
	}

	public WebElement getOtherAdvSearchBtn() {
		return otherAdvSearchBtn;
	}

	public WebElement getOtherAdvSearchDiv() {
		return otherAdvSearchDiv;
	}

	public WebElement getOtherServDept() {
		return otherServDept;
	}

	public WebElement getOtherServSplty() {
		return otherServSplty;
	}

	public WebElement getOtherServSubSplty() {
		return otherServSubSplty;
	}

	public WebElement getAdvSearchOtherServBtn() {
		return advSearchOtherServBtn;
	}

	public WebElement getAdvResetOtherServBtn() {
		return advResetOtherServBtn;
	}

	public WebElement getOthersDataList() {
		return othersDataList;
	}

	public WebElement getSelectionGridTbl() {
		return selectionGridTbl;
	}

}
