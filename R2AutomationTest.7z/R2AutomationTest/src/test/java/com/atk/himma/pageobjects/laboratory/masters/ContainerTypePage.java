package com.atk.himma.pageobjects.laboratory.masters;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.laboratory.masters.tabs.ContainerTypeDetailsTabPage;
import com.atk.himma.pageobjects.laboratory.masters.tabs.ContainerTypeListTabPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class ContainerTypePage extends DriverWaitClass {
	private ContainerTypeListTabPage containerTypeListTabPage;
	private ContainerTypeDetailsTabPage containerTypeDetailsTabPage;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String CONTTYPELISTTAB_XPATH = "//a[@title='Container Type List']";
	@FindBy(xpath = CONTTYPELISTTAB_XPATH)
	private WebElement containerTypeListTab;

	public final static String CONTTYPEDTLTAB_XPATH = "//a[@title='Container Type Details']";
	@FindBy(xpath = CONTTYPEDTLTAB_XPATH)
	private WebElement containerTypeDetailsTab;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		containerTypeListTabPage = PageFactory.initElements(webDriver,
				ContainerTypeListTabPage.class);
		containerTypeListTabPage.setWebDriver(webDriver);
		containerTypeListTabPage.setWebDriverWait(webDriverWait);

		containerTypeDetailsTabPage = PageFactory.initElements(webDriver,
				ContainerTypeDetailsTabPage.class);
		containerTypeDetailsTabPage.setWebDriver(webDriver);
		containerTypeDetailsTabPage.setWebDriverWait(webDriverWait);

	}

	public ContainerTypePage clickOnContainerTypeMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> containerTypeMenuList = new LinkedList<String>();
		containerTypeMenuList.add("Laboratory");
		containerTypeMenuList.add("Masters ");
		menuSelector.clickOnTargetMenu(containerTypeMenuList, "Container Type");
		ContainerTypePage containerTypePage = PageFactory.initElements(
				webDriver, ContainerTypePage.class);
		containerTypePage.setWebDriver(webDriver);
		containerTypePage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return containerTypePage;

	}

	public void navigateToContTypeListPage() throws Exception {
		containerTypeListTab.click();
		waitForElementId(ContainerTypeListTabPage.QUICKSEARCHTXT_ID);
		sleepShort();
	}
	
	public ContainerTypeListTabPage getContainerTypeListTabPage() {
		return containerTypeListTabPage;
	}

	public ContainerTypeDetailsTabPage getContainerTypeDetailsTabPage() {
		return containerTypeDetailsTabPage;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getContainerTypeListTab() {
		return containerTypeListTab;
	}

	public WebElement getContainerTypeDetailsTab() {
		return containerTypeDetailsTab;
	}

}
