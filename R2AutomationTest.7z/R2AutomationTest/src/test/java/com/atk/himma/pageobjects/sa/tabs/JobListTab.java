package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class JobListTab extends DriverWaitClass {
	public final static String SEARCHJOBFORM_ID = "SEARCH_ROLE_FORM";
	@FindBy(id = SEARCHJOBFORM_ID)
	private WebElement searchJobForm;

	public final static String ADDNEWJOBBTN_ID = "newRoleAddButton";
	@FindBy(id = ADDNEWJOBBTN_ID)
	private WebElement addNewJobBtn;

	public final static String JOBNAME_ID = "search_by_name";
	@FindBy(id = JOBNAME_ID)
	private WebElement jobName;

	public final static String MODULENAME_ID = "moduleComboForSearch";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String ROOTORGUNIT_ID = "ROOT_ORG";
	@FindBy(id = ROOTORGUNIT_ID)
	private WebElement rootOrgUnit;

	public final static String MAINBUSINESSUNIT_ID = "MBU_ORG";
	@FindBy(id = MAINBUSINESSUNIT_ID)
	private WebElement mainBusinessUnit;

	public final static String MAINBUSINESSUNITNAME_ID = "BUSINESS_COMBO";
	@FindBy(id = MAINBUSINESSUNITNAME_ID)
	private WebElement mainBusinessUnitName;

	public final static String SEARCHBTN_XPATH = "//input[@value='Search']";
	@FindBy(xpath = SEARCHBTN_XPATH)
	private WebElement searchBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String JOBSGRID_ID = "gbox_rolesMaster";
	@FindBy(id = JOBSGRID_ID)
	private WebElement jobsGrid;

	public final static String CONFIRMATIONMSG_ID = "ConfirmationMessage";
	@FindBy(id = CONFIRMATIONMSG_ID)
	private WebElement confirmMsg;

	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";
	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public final static String EDITLINK_XPATH = ".//table[@id='rolesMaster']/..//a[text()='Edit']";
	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	public final static String DELETELINK_XPATH = ".//table[@id='rolesMaster']/..//a[text()='Delete']";
	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public final static String GRID_ID = "rolesMaster";
	public final static String GRID_ROLENAME_ARIA_DESCRIBEDBY = "rolesMaster_roleName";
	public final static String GRID_PRIVMODNAMES_ARIA_DESCRIBEDBY = "rolesMaster_modulesString";
	public final static String GRID_PRIVGRPNAMES_ARIA_DESCRIBEDBY = "rolesMaster_privilgeGroupNames";
	public final static String GRID_PAGERID = "sp_1_rolesMaster_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rolesMaster_pager']";

	public void clickOnAddNewJob() throws Exception {
		addNewJobBtn.click();
		sleepShort();
	}

	public void searchJobs(String[] editJobsData) throws Exception {
		waitForElementId(MAINBUSINESSUNITNAME_ID);
		sleepShort();
		jobName.clear();
		jobName.sendKeys(editJobsData[0]);
		if (editJobsData[1].isEmpty()) {
			rootOrgUnit.click();
		} else {
			mainBusinessUnit.click();
		}
		sleepVeryShort();
		searchBtn.click();
		sleepShort();
	}
	
	public void privSearchJobs(String[] editJobsData) throws Exception {
		waitForElementId(MAINBUSINESSUNITNAME_ID);
		sleepShort();
		jobName.clear();
		jobName.sendKeys(editJobsData[0]);
		sleepVeryShort();
		searchBtn.click();
		sleepShort();
	}

	public void clickOnEdit(String[] editJobsData) throws Exception {
		clickOnGridAction("rolesMaster_roleName", editJobsData[0], "Edit");
		sleepShort();
	}

	public void clickOnDelete(String[] delJobsData) throws Exception {
		clickOnGridAction("rolesMaster_roleName", delJobsData[0], "Delete");
		sleepShort();
		waitForElementId(CONFIRMATIONMSG_ID);
		confirmYes.click();
		sleepShort();
	}

	public boolean searchGridData(String jobName) {
		boolean result = false;
		try {
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='rolesMaster_roleName' and @title='"
									+ jobName.trim() + "']")).isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

	public WebElement getSearchJobForm() {
		return searchJobForm;
	}

	public WebElement getAddNewJobBtn() {
		return addNewJobBtn;
	}

	public WebElement getJobName() {
		return jobName;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getRootOrgUnit() {
		return rootOrgUnit;
	}

	public WebElement getMainBusinessUnit() {
		return mainBusinessUnit;
	}

	public WebElement getMainBusinessUnitName() {
		return mainBusinessUnitName;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getJobsGrid() {
		return jobsGrid;
	}

	public WebElement getConfirmMsg() {
		return confirmMsg;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
