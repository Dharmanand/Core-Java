package com.atk.himma.pageobjects.apoe;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.apoe.panelpages.AssessmentPlanPage;
import com.atk.himma.pageobjects.apoe.panelpages.ConsultationSummaryPage;
import com.atk.himma.pageobjects.apoe.panelpages.HistoryPage;
import com.atk.himma.pageobjects.apoe.panelpages.ReasonForVisitPage;
import com.atk.himma.pageobjects.apoe.sections.ActiveOrdersForEncounterSection;
import com.atk.himma.pageobjects.apoe.sections.DiagVitalSignsAllergiesDetailsSec;
import com.atk.himma.pageobjects.apoe.sections.FamilyHistorySection;
import com.atk.himma.pageobjects.apoe.sections.MedicalHistorySection;
import com.atk.himma.pageobjects.apoe.sections.MedicationFromOurSourcesSection;
import com.atk.himma.pageobjects.apoe.sections.MedicationFromOutsideSourcesSection;
import com.atk.himma.pageobjects.apoe.sections.NonPharmacologicalTreatmentSection;
import com.atk.himma.pageobjects.apoe.sections.OrderDetailsSection;
import com.atk.himma.pageobjects.apoe.sections.OtherPlanSection;
import com.atk.himma.pageobjects.apoe.sections.PainAssessmentSection;
import com.atk.himma.pageobjects.apoe.sections.PatientEducationSection;
import com.atk.himma.pageobjects.apoe.sections.SocialHistorySection;
import com.atk.himma.pageobjects.apoe.sections.SurgicalHistorySection;
import com.atk.himma.pageobjects.apoe.tabs.ExistingOrderTab;
import com.atk.himma.pageobjects.apoe.tabs.NewOrderTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;

public class ConsultationPage extends DriverWaitClass implements StatusMessages {
	private ReasonForVisitPage reasonForVisitPage;
	private HistoryPage historyPage;
	private AssessmentPlanPage assessmentPlanPage;
	private ConsultationSummaryPage consultationSummaryPage;
	private AllergyPopupPage allergyPopupPage;
	private VitalsPopupPage vitalsPopupPage;
	private DiagnosisPopupPage diagnosisPopupPage;
	private PainAssessmentSection painAssessmentSection;
	private MedicalHistorySection medicalHistorySection;
	private SurgicalHistorySection surgicalHistorySection;
	private FamilyHistorySection familyHistorySection;
	private SocialHistorySection socialHistorySection;
	private MedicationFromOutsideSourcesSection outsideSourcesSection;
	private MedicationFromOurSourcesSection ourSourcesSection;
	private PatientEducationSection patientEducationSection;
	private NonPharmacologicalTreatmentSection nonPharmacologicalTreatmentSection;
	private ActiveOrdersForEncounterSection activeOrdersForEncounterSection;
	private OtherPlanSection otherPlanSection;
	private OrderEntryPage orderEntryPage;
	private NewOrderTab newOrderTab;
	private ExistingOrderTab existingOrderTab;
	private DiagVitalSignsAllergiesDetailsSec diagVitalSignsAllergiesDetailsSec;
	private OrderDetailsSection orderDetailsSection;
	private PharmacyOrderingInfoPopup pharmacyOrderingInfoPopup;
	private LabOrderingInfoPopup labOrderingInfoPopup;
	private RadOrderingInfoPopup radOrderingInfoPopup;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String PREVVISITSMRY_ID = "PREVIOUS_SUMMARY_LINK";
	@FindBy(id = PREVVISITSMRY_ID)
	private WebElement prevVisitSummaryLink;

	public final static String VISITREASON_ID = "REASON_LINK";
	@FindBy(id = VISITREASON_ID)
	private WebElement visitReasonLink;

	public final static String HISTORY_ID = "HISTROY_LINK";
	@FindBy(id = HISTORY_ID)
	private WebElement historyLink;

	public final static String ASSESSMENT_ID = "ASSESSMENT_LINK";
	@FindBy(id = ASSESSMENT_ID)
	private WebElement assessmentPlanLink;

	public final static String CONSSMRY_ID = "CONSULTATION_SUMMARY_LINK";
	@FindBy(id = CONSSMRY_ID)
	private WebElement consSummaryLink;

	public final static String ORDERBTN_XPATH = ".//div[@class='buttoncontainer_botfixed']/input[@value='Order']";
	@FindBy(xpath = ORDERBTN_XPATH)
	private WebElement orderBtn;

	public final static String ADDORVIEWALLERGIESBTN_XPATH = ".//a[@class='AddListItem' and @title='Add / View Allergies...']";
	@FindBy(xpath = ADDORVIEWALLERGIESBTN_XPATH)
	private WebElement addOrViewAllergiesBtn;

	public final static String ADDORVIEWVITALSBTN_XPATH = ".//a[@class='AddListItem' and @title='Add / View Vitals...']";
	@FindBy(xpath = ADDORVIEWVITALSBTN_XPATH)
	private WebElement addOrViewVitalsBtn;

	public final static String ADDORVIEDIAGNOSISBTN_XPATH = ".//a[@class='AddListItem' and @title='Add / View Diagnosis...']";
	@FindBy(xpath = ADDORVIEDIAGNOSISBTN_XPATH)
	private WebElement addOrViewDiagnosisBtn;

	public final static String ALLERGIES_ID = "ALLERGY_SELECT";
	@FindBy(id = ALLERGIES_ID)
	private WebElement allergies;

	public final static String BPSYSTOLIC_NAME = "currentVital.bpSystonic";
	@FindBy(name = BPSYSTOLIC_NAME)
	private WebElement bpSystolic;

	public final static String TEMPERATURE_NAME = "currentVital.temperature";
	@FindBy(name = TEMPERATURE_NAME)
	private WebElement temperature;

	public final static String PULSE_NAME = "currentVital.pulse";
	@FindBy(name = PULSE_NAME)
	private WebElement pulse;

	public final static String RESPIRATORY_NAME = "currentVital.respiratory";
	@FindBy(name = RESPIRATORY_NAME)
	private WebElement respiratory;

	public final static String HEIGHT_NAME = "currentVital.height";
	@FindBy(name = HEIGHT_NAME)
	private WebElement height;

	public final static String WEIGHT_NAME = "currentVital.weight";
	@FindBy(name = WEIGHT_NAME)
	private WebElement weight;

	public final static String BPDIASTOLIC_NAME = "currentVital.bpDiastolic";
	@FindBy(name = BPDIASTOLIC_NAME)
	private WebElement bpDiastolic;

	public final static String BMI_NAME = "currentVital.bmi";
	@FindBy(name = BMI_NAME)
	private WebElement bmi;

	public final static String CHRONICDISEASES_ID = "DIAGNOSIS_CHRONIC_SELECT";
	@FindBy(id = CHRONICDISEASES_ID)
	private WebElement chronicDiseases;

	public final static String VITALSFORM_ID = "VITAL_SIGN_POPUP_FORM";
	@FindBy(id = VITALSFORM_ID)
	private WebElement vitalsPopupForm;

	public final static String HEIGHT_ID = "HEIGHT";
	@FindBy(id = HEIGHT_ID)
	private WebElement vitalsPopupHeight;

	public final static String WEIGHT_ID = "WEIGHT";
	@FindBy(id = WEIGHT_ID)
	private WebElement vitalsPopupWeight;

	public final static String BMI_ID = "BMI";
	@FindBy(id = BMI_ID)
	private WebElement vitalsPopupBMI;

	public final static String RESPIRATORY_ID = "RESPIRATORY";
	@FindBy(id = RESPIRATORY_ID)
	private WebElement vitalsPopupRespiratory;

	public final static String TEMPERATURE_ID = "TEMPERATURE";
	@FindBy(id = TEMPERATURE_ID)
	private WebElement vitalsPopupTemperature;

	public final static String PULSE_ID = "PULSE";
	@FindBy(id = PULSE_ID)
	private WebElement vitalsPopupPulse;

	public final static String BPDIASTOLIC_ID = "BPDIASTOLIC";
	@FindBy(id = BPDIASTOLIC_ID)
	private WebElement vitalsPopupBPDiastolic;

	public final static String BPSYSTONIC_ID = "BPSYSTONIC";
	@FindBy(id = BPSYSTONIC_ID)
	private WebElement vitalsPopupBPSystolic;

	public final static String TAKENBY_ID = "VITAL_CONSULTANT";
	@FindBy(id = TAKENBY_ID)
	private WebElement vitalsPopupTakenBy;

	public final static String DATETIMEIMG_XPATH = "//input[@id='PATIENT_READING_TIME']/../img";
	@FindBy(xpath = DATETIMEIMG_XPATH)
	private WebElement patReadingTime;

	public final static String NOWBUTTON_XPATH = "//div[@id='ui-datepicker-div']//button[@class='ui-datepicker-current ui-state-default ui-priority-primary ui-corner-all']";
	@FindBy(xpath = NOWBUTTON_XPATH)
	private WebElement nowBtn;

	public final static String ADDVITALSBTN_ID = "ADD_VITAL_SIGNS_POP_UP";
	@FindBy(id = ADDVITALSBTN_ID)
	private WebElement addVitalsPopupBtn;

	public final static String RESETVITALSBTN_XPATH = ".//div[@id='vitalSigns_div']/..//input[@value='Reset']";
	@FindBy(xpath = RESETVITALSBTN_XPATH)
	private WebElement resetVitalsBtn;

	public final static String VITALSGRIDTBL_ID = "VITAL_SIGNS_GRID";
	@FindBy(id = VITALSGRIDTBL_ID)
	private WebElement vitalsGridTbl;

	public final static String CANCELVITALSPOPUP_XPATH = "//form[@id='VITAL_SIGN_POPUP_FORM']/..//input[@value='Cancel']";
	@FindBy(xpath = CANCELVITALSPOPUP_XPATH)
	private WebElement cancelVitalsPopup;

	public final static String SAVEVITALSPOPUP_XPATH = "//form[@id='VITAL_SIGN_POPUP_FORM']/..//input[@value='save']";
	@FindBy(xpath = SAVEVITALSPOPUP_XPATH)
	private WebElement saveVitalsPopup;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		reasonForVisitPage = PageFactory.initElements(webDriver,
				ReasonForVisitPage.class);
		reasonForVisitPage.setWebDriver(webDriver);
		reasonForVisitPage.setWebDriverWait(webDriverWait);

		historyPage = PageFactory.initElements(webDriver, HistoryPage.class);
		historyPage.setWebDriver(webDriver);
		historyPage.setWebDriverWait(webDriverWait);

		assessmentPlanPage = PageFactory.initElements(webDriver,
				AssessmentPlanPage.class);
		assessmentPlanPage.setWebDriver(webDriver);
		assessmentPlanPage.setWebDriverWait(webDriverWait);

		consultationSummaryPage = PageFactory.initElements(webDriver,
				ConsultationSummaryPage.class);
		consultationSummaryPage.setWebDriver(webDriver);
		consultationSummaryPage.setWebDriverWait(webDriverWait);

		allergyPopupPage = PageFactory.initElements(webDriver,
				AllergyPopupPage.class);
		allergyPopupPage.setWebDriver(webDriver);
		allergyPopupPage.setWebDriverWait(webDriverWait);

		vitalsPopupPage = PageFactory.initElements(webDriver,
				VitalsPopupPage.class);
		vitalsPopupPage.setWebDriver(webDriver);
		vitalsPopupPage.setWebDriverWait(webDriverWait);

		diagnosisPopupPage = PageFactory.initElements(webDriver,
				DiagnosisPopupPage.class);
		diagnosisPopupPage.setWebDriver(webDriver);
		diagnosisPopupPage.setWebDriverWait(webDriverWait);

		painAssessmentSection = PageFactory.initElements(webDriver,
				PainAssessmentSection.class);
		painAssessmentSection.setWebDriver(webDriver);
		painAssessmentSection.setWebDriverWait(webDriverWait);

		medicalHistorySection = PageFactory.initElements(webDriver,
				MedicalHistorySection.class);
		medicalHistorySection.setWebDriver(webDriver);
		medicalHistorySection.setWebDriverWait(webDriverWait);

		surgicalHistorySection = PageFactory.initElements(webDriver,
				SurgicalHistorySection.class);
		surgicalHistorySection.setWebDriver(webDriver);
		surgicalHistorySection.setWebDriverWait(webDriverWait);

		familyHistorySection = PageFactory.initElements(webDriver,
				FamilyHistorySection.class);
		familyHistorySection.setWebDriver(webDriver);
		familyHistorySection.setWebDriverWait(webDriverWait);

		socialHistorySection = PageFactory.initElements(webDriver,
				SocialHistorySection.class);
		socialHistorySection.setWebDriver(webDriver);
		socialHistorySection.setWebDriverWait(webDriverWait);

		outsideSourcesSection = PageFactory.initElements(webDriver,
				MedicationFromOutsideSourcesSection.class);
		outsideSourcesSection.setWebDriver(webDriver);
		outsideSourcesSection.setWebDriverWait(webDriverWait);

		ourSourcesSection = PageFactory.initElements(webDriver,
				MedicationFromOurSourcesSection.class);
		ourSourcesSection.setWebDriver(webDriver);
		ourSourcesSection.setWebDriverWait(webDriverWait);

		patientEducationSection = PageFactory.initElements(webDriver,
				PatientEducationSection.class);
		patientEducationSection.setWebDriver(webDriver);
		patientEducationSection.setWebDriverWait(webDriverWait);

		nonPharmacologicalTreatmentSection = PageFactory.initElements(
				webDriver, NonPharmacologicalTreatmentSection.class);
		nonPharmacologicalTreatmentSection.setWebDriver(webDriver);
		nonPharmacologicalTreatmentSection.setWebDriverWait(webDriverWait);

		activeOrdersForEncounterSection = PageFactory.initElements(webDriver,
				ActiveOrdersForEncounterSection.class);
		activeOrdersForEncounterSection.setWebDriver(webDriver);
		activeOrdersForEncounterSection.setWebDriverWait(webDriverWait);

		otherPlanSection = PageFactory.initElements(webDriver,
				OtherPlanSection.class);
		otherPlanSection.setWebDriver(webDriver);
		otherPlanSection.setWebDriverWait(webDriverWait);

		orderEntryPage = PageFactory.initElements(webDriver,
				OrderEntryPage.class);
		orderEntryPage.setWebDriver(webDriver);
		orderEntryPage.setWebDriverWait(webDriverWait);

		newOrderTab = PageFactory.initElements(webDriver, NewOrderTab.class);
		newOrderTab.setWebDriver(webDriver);
		newOrderTab.setWebDriverWait(webDriverWait);

		existingOrderTab = PageFactory.initElements(webDriver,
				ExistingOrderTab.class);
		existingOrderTab.setWebDriver(webDriver);
		existingOrderTab.setWebDriverWait(webDriverWait);

		diagVitalSignsAllergiesDetailsSec = PageFactory.initElements(webDriver,
				DiagVitalSignsAllergiesDetailsSec.class);
		diagVitalSignsAllergiesDetailsSec.setWebDriver(webDriver);
		diagVitalSignsAllergiesDetailsSec.setWebDriverWait(webDriverWait);

		orderDetailsSection = PageFactory.initElements(webDriver,
				OrderDetailsSection.class);
		orderDetailsSection.setWebDriver(webDriver);
		orderDetailsSection.setWebDriverWait(webDriverWait);

		pharmacyOrderingInfoPopup = PageFactory.initElements(webDriver,
				PharmacyOrderingInfoPopup.class);
		pharmacyOrderingInfoPopup.setWebDriver(webDriver);
		pharmacyOrderingInfoPopup.setWebDriverWait(webDriverWait);

		labOrderingInfoPopup = PageFactory.initElements(webDriver,
				LabOrderingInfoPopup.class);
		labOrderingInfoPopup.setWebDriver(webDriver);
		labOrderingInfoPopup.setWebDriverWait(webDriverWait);

		radOrderingInfoPopup = PageFactory.initElements(webDriver,
				RadOrderingInfoPopup.class);
		radOrderingInfoPopup.setWebDriver(webDriver);
		radOrderingInfoPopup.setWebDriverWait(webDriverWait);

	}

	public String checkPreviousVisitSummaryPanelLink() {
		return prevVisitSummaryLink.getText();

	}

	public String checkReasonForVisitPanelLink() {
		return visitReasonLink.getText();

	}

	public String checkHistoryPanelLink() {
		return historyLink.getText();

	}

	public String checkAssessmentPlanPanelLink() {
		return assessmentPlanLink.getText();

	}

	public String checkConsSummaryPanelLink() {
		return consSummaryLink.getText();

	}

	public void clickAddViewAllergiesBtn() throws Exception {
		addOrViewAllergiesBtn.click();
		sleepShort();

	}

	public boolean clickReasonForVisitPanelLink() {
		visitReasonLink.click();
		return getReasonForVisitPage().getNewVisitTab().isDisplayed();

	}

	public boolean clickHistoryPanelLink() {
		historyLink.click();
		return getHistoryPage().getHpiTab().isDisplayed();
	}

	public boolean clickAssessmentPlanPanelLink() {
		assessmentPlanLink.click();
		return getAssessmentPlanPage().getDiagAssessTab().isDisplayed();
	}

	public boolean clickConsultationSummaryPanelLink() {
		consSummaryLink.click();
		return getConsultationSummaryPage().getConsRadioBtn().isDisplayed();
	}

	public List<WebElement> getAllergyData(String[] outPatientListData) {
		return new Select(allergies).getOptions();
	}

	public boolean checkOrderBtn() {
		waitForElementXpathExpression(ORDERBTN_XPATH);
		return orderBtn.isDisplayed();
	}

	public String clickOrderButton() throws Exception {
		orderBtn.click();
		sleepShort();
		waitForElementXpathExpression(OrderEntryPage.NEWORDERTAB_XPATH);
		return pageTitle.getText();
	}

	public ReasonForVisitPage getReasonForVisitPage() {
		return reasonForVisitPage;
	}

	public HistoryPage getHistoryPage() {
		return historyPage;
	}

	public AssessmentPlanPage getAssessmentPlanPage() {
		return assessmentPlanPage;
	}

	public ConsultationSummaryPage getConsultationSummaryPage() {
		return consultationSummaryPage;
	}

	public AllergyPopupPage getAllergyPopupPage() {
		return allergyPopupPage;
	}

	public VitalsPopupPage getVitalsPopupPage() {
		return vitalsPopupPage;
	}

	public DiagnosisPopupPage getDiagnosisPopupPage() {
		return diagnosisPopupPage;
	}

	public PainAssessmentSection getPainAssessmentSection() {
		return painAssessmentSection;
	}

	public MedicalHistorySection getMedicalHistorySection() {
		return medicalHistorySection;
	}

	public SurgicalHistorySection getSurgicalHistorySection() {
		return surgicalHistorySection;
	}

	public FamilyHistorySection getFamilyHistorySection() {
		return familyHistorySection;
	}

	public SocialHistorySection getSocialHistorySection() {
		return socialHistorySection;
	}

	public MedicationFromOutsideSourcesSection getOutsideSourcesSection() {
		return outsideSourcesSection;
	}

	public MedicationFromOurSourcesSection getOurSourcesSection() {
		return ourSourcesSection;
	}

	public PatientEducationSection getPatientEducationSection() {
		return patientEducationSection;
	}

	public NonPharmacologicalTreatmentSection getNonPharmacologicalTreatmentSection() {
		return nonPharmacologicalTreatmentSection;
	}

	public ActiveOrdersForEncounterSection getActiveOrdersForEncounterSection() {
		return activeOrdersForEncounterSection;
	}

	public OtherPlanSection getOtherPlanSection() {
		return otherPlanSection;
	}

	public OrderEntryPage getOrderEntryPage() {
		return orderEntryPage;
	}

	public NewOrderTab getNewOrderTab() {
		return newOrderTab;
	}

	public ExistingOrderTab getExistingOrderTab() {
		return existingOrderTab;
	}

	public DiagVitalSignsAllergiesDetailsSec getDiagVitalSignsAllergiesDetailsSec() {
		return diagVitalSignsAllergiesDetailsSec;
	}

	public OrderDetailsSection getOrderDetailsSection() {
		return orderDetailsSection;
	}

	public PharmacyOrderingInfoPopup getPharmacyOrderingInfoPopup() {
		return pharmacyOrderingInfoPopup;
	}

	public LabOrderingInfoPopup getLabOrderingInfoPopup() {
		return labOrderingInfoPopup;
	}

	public RadOrderingInfoPopup getRadOrderingInfoPopup() {
		return radOrderingInfoPopup;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getPrevVisitSummaryLink() {
		return prevVisitSummaryLink;
	}

	public WebElement getVisitReasonLink() {
		return visitReasonLink;
	}

	public WebElement getHistoryLink() {
		return historyLink;
	}

	public WebElement getAssessmentPlanLink() {
		return assessmentPlanLink;
	}

	public WebElement getConsSummaryLink() {
		return consSummaryLink;
	}

	public WebElement getOrderBtn() {
		return orderBtn;
	}

	public WebElement getAddOrViewAllergiesBtn() {
		return addOrViewAllergiesBtn;
	}

	public WebElement getAddOrViewVitalsBtn() {
		return addOrViewVitalsBtn;
	}

	public WebElement getAddOrViewDiagnosisBtn() {
		return addOrViewDiagnosisBtn;
	}

	public WebElement getAllergies() {
		return allergies;
	}

	public WebElement getBpSystolic() {
		return bpSystolic;
	}

	public WebElement getTemperature() {
		return temperature;
	}

	public WebElement getPulse() {
		return pulse;
	}

	public WebElement getRespiratory() {
		return respiratory;
	}

	public WebElement getHeight() {
		return height;
	}

	public WebElement getWeight() {
		return weight;
	}

	public WebElement getBpDiastolic() {
		return bpDiastolic;
	}

	public WebElement getBmi() {
		return bmi;
	}

	public WebElement getChronicDiseases() {
		return chronicDiseases;
	}

	public WebElement getVitalsPopupForm() {
		return vitalsPopupForm;
	}

	public WebElement getVitalsPopupHeight() {
		return vitalsPopupHeight;
	}

	public WebElement getVitalsPopupWeight() {
		return vitalsPopupWeight;
	}

	public WebElement getVitalsPopupBMI() {
		return vitalsPopupBMI;
	}

	public WebElement getVitalsPopupRespiratory() {
		return vitalsPopupRespiratory;
	}

	public WebElement getVitalsPopupTemperature() {
		return vitalsPopupTemperature;
	}

	public WebElement getVitalsPopupPulse() {
		return vitalsPopupPulse;
	}

	public WebElement getVitalsPopupBPDiastolic() {
		return vitalsPopupBPDiastolic;
	}

	public WebElement getVitalsPopupBPSystolic() {
		return vitalsPopupBPSystolic;
	}

	public WebElement getVitalsPopupTakenBy() {
		return vitalsPopupTakenBy;
	}

	public WebElement getPatReadingTime() {
		return patReadingTime;
	}

	public WebElement getNowBtn() {
		return nowBtn;
	}

	public WebElement getAddVitalsPopupBtn() {
		return addVitalsPopupBtn;
	}

	public WebElement getResetVitalsBtn() {
		return resetVitalsBtn;
	}

	public WebElement getVitalsGridTbl() {
		return vitalsGridTbl;
	}

	public WebElement getCancelVitalsPopup() {
		return cancelVitalsPopup;
	}

	public WebElement getSaveVitalsPopup() {
		return saveVitalsPopup;
	}

}
