package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ApprovalListTab extends DriverWaitClass {
	public final static String APPLISTFORM_ID = "SEARCH_APPROVAL_LIST";
	public final static String ADDNEWAPPLISTBTN_ID = "ADD_NEW_APPROVAL_BTN";
	public final static String MBULIST_ID = "S1_MBU_NAME";
	public final static String GLOBALAPPCHKBOX_ID = "APPRVL_GLOBAL_CHBOX";
	public final static String STATUS_ID = "APP_STATUS";
	public final static String SEARCHAPPLISTBTN_ID = "SEARCH";
	public final static String RESETAPPLISTBTN_ID = "APP_RESET";
	public final static String APPLISTGRIDDIV_ID = "SEARCH_APPROVAL_LIST_GRID";
	public final static String VIEWLINK_XPATH = ".//table[@id='APP_GRID_PAT']/..//a[text()='View']";
	public final static String EDITLINK_XPATH = ".//table[@id='APP_GRID_PAT']/..//a[text()='Edit']";
	public final static String DELETELINK_XPATH = ".//table[@id='APP_GRID_PAT']/..//a[text()='Delete']";

	@FindBy(id = APPLISTFORM_ID)
	private WebElement apprvlListForm;

	@FindBy(id = ADDNEWAPPLISTBTN_ID)
	private WebElement addNewApprvlListBtn;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALAPPCHKBOX_ID)
	private WebElement globalApprvlChkBox;

	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(id = SEARCHAPPLISTBTN_ID)
	private WebElement searchApprvlBtn;

	@FindBy(id = RESETAPPLISTBTN_ID)
	private WebElement resetApprvlBtn;

	@FindBy(id = APPLISTGRIDDIV_ID)
	private WebElement apprvlListGridDiv;

	@FindBy(xpath = VIEWLINK_XPATH)
	private WebElement viewLink;

	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public void clickAddNewApprvlList() throws Exception {
		addNewApprvlListBtn.click();
		sleepShort();

	}

	public void searchApprvlList(String[] mbuApprvlData) throws Exception {
		if (!mbuApprvlData[2].isEmpty()) {
			new Select(mbuList).selectByVisibleText(mbuApprvlData[2]);
		}

		if (!mbuApprvlData[4].isEmpty()) {
			new Select(status).selectByVisibleText(mbuApprvlData[4]);
		}
		searchApprvlBtn.click();
		sleepShort();
		waitForElementId(APPLISTGRIDDIV_ID);
	}
	
	public void clickEditLink(String[] apprvlListData) throws Exception {
		clickOnGridAction("APP_GRID_PAT_listName", apprvlListData[1], "Edit");
		sleepShort();

	}

	public WebElement getApprvlListForm() {
		return apprvlListForm;
	}

	public WebElement getAddNewApprvlListBtn() {
		return addNewApprvlListBtn;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalApprvlChkBox() {
		return globalApprvlChkBox;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getSearchApprvlBtn() {
		return searchApprvlBtn;
	}

	public WebElement getResetApprvlBtn() {
		return resetApprvlBtn;
	}

	public WebElement getApprvlListGridDiv() {
		return apprvlListGridDiv;
	}

	public WebElement getViewLink() {
		return viewLink;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
