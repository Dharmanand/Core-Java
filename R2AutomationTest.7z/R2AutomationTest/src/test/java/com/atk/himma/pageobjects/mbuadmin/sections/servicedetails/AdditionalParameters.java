package com.atk.himma.pageobjects.mbuadmin.sections.servicedetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AdditionalParameters extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Additional Parameters";
	public final static String GENDERSPECIFIC_ID = "GENDER_SPECIFIC";
	public final static String GENDER_NAME = "multiselect_GENDER";
	public final static String APPLVISITCATLABEL_ID = "serviceInfo_additionalParameters_visitCategoryIds_values";
	public final static String APPLVISITTYPE_NAME = "multiselect_APPLICABLE_VISIT_TYPE";
	public final static String CHARGABLE_NAME = "serviceInfo.additionalParameters.chargable";
	public final static String ORDARABLE_NAME = "serviceInfo.additionalParameters.ordarable";
	public final static String SERDUR_ID = "SERVICE_DURATION";
	public final static String AGESPECIFIC_ID = "AGE_SPECIFIC";
	public final static String SUBSPECIALITY_ID = "SUB_SPECIALITY";
	public final static String MINAGE_ID = "MIN_AGE";
	public final static String MINAGETYPE_ID = "MIN_AGE_TYPE";
	public final static String MAXAGE_ID = "MAX_AGE";
	public final static String MAXAGETYPE_ID = "MAX_AGE_TYPE";
	public final static String CONSENTTEMPLATE_ID = "CONSENT_TEMPLATE";
	public final static String CONSENTREQUIRED_ID = "CONSENT_REQUIRED";
	public final static String SERDESCRIPTION_NAME = "serviceInfo.additionalParameters.description";
	public final static String SPECIALINSTRUCTIONS_NAME = "serviceInfo.additionalParameters.specialInstructions";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Additional Parameters')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	@FindBy(id = GENDERSPECIFIC_ID)
	private WebElement genderSpecific;

	@FindBy(id = GENDER_NAME)
	private WebElement genderName;

	@FindBy(name = APPLVISITTYPE_NAME)
	private WebElement applVisitType;

	@FindBy(id = SERDUR_ID)
	private WebElement serviceDuration;

	@FindBy(id = AGESPECIFIC_ID)
	private WebElement ageSpecific;

	@FindBy(id = SUBSPECIALITY_ID)
	private WebElement subSpeciality;

	@FindBy(name = CHARGABLE_NAME)
	private WebElement chargable;

	@FindBy(name = ORDARABLE_NAME)
	private WebElement ordarable;

	@FindBy(id = MINAGE_ID)
	private WebElement minimumAge;

	@FindBy(id = MINAGETYPE_ID)
	private WebElement minAgeType;

	@FindBy(id = MAXAGE_ID)
	private WebElement maxAge;

	@FindBy(id = MAXAGETYPE_ID)
	private WebElement maxAgeType;

	@FindBy(id = CONSENTTEMPLATE_ID)
	private WebElement consentTemplate;

	@FindBy(id = CONSENTREQUIRED_ID)
	private WebElement consentRequired;

	@FindBy(name = SERDESCRIPTION_NAME)
	private WebElement SerDesName;

	@FindBy(name = SPECIALINSTRUCTIONS_NAME)
	private WebElement SpecialInstructions;

	public boolean checkAddParamSection() throws InterruptedException {
		waitForElementLinkText(AdditionalParameters.SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean isMandatorychargable() {
		waitForElementLinkText(AdditionalParameters.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		return isMandatoryField(chargable);
	}

	public boolean fillAdditionalParamDatas(String[] serviceDatas) throws InterruptedException {
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		selectOrUnSelectCheckBox(serviceDatas[16].trim(), genderSpecific);
		if (genderSpecific.isSelected())
			selectValueOfMultiselect(GENDER_NAME, serviceDatas[17].trim());
		if (!serviceDatas[18].isEmpty()) {
			String st[] = serviceDatas[18].split("\\,");
			for (int i = 0; i < st.length; i++)
				webDriver.findElement(
						By.xpath(".//*[@id='" + APPLVISITCATLABEL_ID
								+ "']//..//input[@type='checkbox' and @title='"
								+ st[i].trim() + "']")).click();
		}
		if (!serviceDatas[19].isEmpty()) {
			String st[] = serviceDatas[19].split("\\,");
			for (int i = 0; i < st.length; i++)
				selectValueOfMultiselect(APPLVISITTYPE_NAME, st[i].trim());
		}
		if (!serviceDatas[20].isEmpty())
			new Select(chargable).selectByVisibleText(serviceDatas[20].trim());
		if (!serviceDatas[21].isEmpty())
			new Select(ordarable).selectByVisibleText(serviceDatas[21].trim());
		serviceDuration.clear();
		serviceDuration.sendKeys(serviceDatas[22].trim());
		selectOrUnSelectCheckBox(serviceDatas[23].trim(), ageSpecific);
		if (ageSpecific.isSelected()) {
			minimumAge.clear();
			minimumAge.sendKeys(serviceDatas[24].trim());
			new Select(minAgeType).selectByVisibleText(serviceDatas[25].trim());
			maxAge.clear();
			maxAge.sendKeys(serviceDatas[26].trim());
			new Select(maxAgeType).selectByVisibleText(serviceDatas[27].trim());
		}
		selectOrUnSelectCheckBox(serviceDatas[28].trim(), consentRequired);
		if (consentRequired.isSelected())
			new Select(minAgeType).selectByVisibleText(serviceDatas[29].trim());
		SerDesName.clear();
		SerDesName.sendKeys(serviceDatas[30].trim());
		SpecialInstructions.clear();
		SpecialInstructions.sendKeys(serviceDatas[31].trim());
		return consentRequired.isSelected() == Boolean
				.getBoolean(serviceDatas[28].trim());
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the genderSpecific
	 */
	public WebElement getGenderSpecific() {
		return genderSpecific;
	}

	/**
	 * @return the genderName
	 */
	public WebElement getGenderName() {
		return genderName;
	}

	/**
	 * @return the applVisitType
	 */
	public WebElement getApplVisitType() {
		return applVisitType;
	}

	/**
	 * @return the serviceDuration
	 */
	public WebElement getServiceDuration() {
		return serviceDuration;
	}

	/**
	 * @return the ageSpecific
	 */
	public WebElement getAgeSpecific() {
		return ageSpecific;
	}

	/**
	 * @return the subSpeciality
	 */
	public WebElement getSubSpeciality() {
		return subSpeciality;
	}

	/**
	 * @return the minimumAge
	 */
	public WebElement getMinimumAge() {
		return minimumAge;
	}

	/**
	 * @return the minAgeType
	 */
	public WebElement getMinAgeType() {
		return minAgeType;
	}

	/**
	 * @return the maxAge
	 */
	public WebElement getMaxAge() {
		return maxAge;
	}

	/**
	 * @return the maxAgeType
	 */
	public WebElement getMaxAgeType() {
		return maxAgeType;
	}

	/**
	 * @return the consentTemplate
	 */
	public WebElement getConsentTemplate() {
		return consentTemplate;
	}

	/**
	 * @return the consentRequired
	 */
	public WebElement getConsentRequired() {
		return consentRequired;
	}

	/**
	 * @return the serDesName
	 */
	public WebElement getSerDesName() {
		return SerDesName;
	}

	/**
	 * @return the specialInstructions
	 */
	public WebElement getSpecialInstructions() {
		return SpecialInstructions;
	}

	/**
	 * @return the chargable
	 */
	public WebElement getChargable() {
		return chargable;
	}

	/**
	 * @return the ordarable
	 */
	public WebElement getOrdarable() {
		return ordarable;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
