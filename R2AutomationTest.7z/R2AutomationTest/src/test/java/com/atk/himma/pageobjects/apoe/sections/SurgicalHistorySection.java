package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class SurgicalHistorySection extends DriverWaitClass {
	public final static String SURGHISTORYSEC_XPATH = "//a[text()='Surgical History']";
	@FindBy(xpath = SURGHISTORYSEC_XPATH)
	private WebElement surgHistorySec;

	public final static String ADDSURGICALHISTORYBTN_XPATH = ".//a[@class='AddListItem' and @onclick='javascript:addSurgicalHistroy();']";
	@FindBy(xpath = ADDSURGICALHISTORYBTN_XPATH)
	private WebElement addSurgicalHistoryBtn;

	public final static String NOTSIGNIFICANTSURCHKBOX_ID = "NOT_SIGNIFICIANT_SUR_CHK";
	@FindBy(id = NOTSIGNIFICANTSURCHKBOX_ID)
	private WebElement notSignificantSurChkBox;

	public final static String SURHISTORYGRIDTBL_ID = "SURGICAL_HISTROY_GRID";
	@FindBy(id = SURHISTORYGRIDTBL_ID)
	private WebElement surgicalHistoryGridTbl;

	public final static String DESCRIPTION_NAME = "descriptionId";
	@FindBy(name = DESCRIPTION_NAME)
	private WebElement description;

	public final static String COMORBIDITY_NAME = "coMorbidity";
	@FindBy(name = COMORBIDITY_NAME)
	private WebElement coMorbidity;

	public final static String APPROXDATE_NAME = "approximateDate";
	@FindBy(name = APPROXDATE_NAME)
	private WebElement approximateDate;

	public final static String NOTES_NAME = "notes";
	@FindBy(name = NOTES_NAME)
	private WebElement notes;

	public boolean checkSurgHistorySec() {
		return surgHistorySec.isDisplayed();
	}

	public void fillSurgicalHistoryInfo(String[] outPatientListData)
			throws Exception {
		if (Boolean.valueOf(outPatientListData[41])) {
			notSignificantSurChkBox.click();
		} else {
			addSurgicalHistoryBtn.click();
			sleepVeryShort();
			waitForElementId(SURHISTORYGRIDTBL_ID);
			if (!outPatientListData[42].isEmpty()) {
				new Select(description)
						.selectByVisibleText(outPatientListData[42]);
			}
			if (Boolean.valueOf(outPatientListData[43])) {
				coMorbidity.click();
			}
			approximateDate.clear();
			approximateDate.sendKeys(outPatientListData[44]);
			notes.clear();
			notes.sendKeys(outPatientListData[45]);

		}
	}

	public WebElement getSurgHistorySec() {
		return surgHistorySec;
	}

	public WebElement getAddSurgicalHistoryBtn() {
		return addSurgicalHistoryBtn;
	}

	public WebElement getNotSignificantSurChkBox() {
		return notSignificantSurChkBox;
	}

	public WebElement getSurgicalHistoryGridTbl() {
		return surgicalHistoryGridTbl;
	}

	public WebElement getDescription() {
		return description;
	}

	public WebElement getCoMorbidity() {
		return coMorbidity;
	}

	public WebElement getApproximateDate() {
		return approximateDate;
	}

	public WebElement getNotes() {
		return notes;
	}

}
