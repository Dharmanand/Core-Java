package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class GenericDrugsCompSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Generic Drugs Composition";
	public final static String ADDBUTTON_XPATH = "//td[@id='GENERIC_DRUG_GRID_pager_left']//span[@class='ui-icon ui-icon-plus']";
	public final static String POPUPDIV_CSS = "div[class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable']";
	public final static String POPUPHEADER_ID = "ui-dialog-title-GENERIC_DRUG_DIALOG";
	public final static String QUICKSEARCHTXT_ID = "GENERIC_SEARCH_FIELD";
	public final static String SEARCHBUTTON_ID = "GENERIC_DRUG_SEARCH";
	public final static String RESETBUTTON_CSS = "#GENERIC_DRUG_SEARCH + input";
	public final static String ADVSEARCHBUTTON_ID = "GENERIC_DRUG_DIALOG_ADV_SEARCH";

	public final static String GRID_ID = "GENERIC_DRUG_GRID";
	public final static String GRID_DRUGNAME_ARIA_DESCRIBEDBY = "GENERIC_DRUG_GRID_genericDrug.drugName";
	public final static String GRID_THERAPCLASSI_ARIA_DESCRIBEDBY = "GENERIC_DRUG_GRID_therapeuticHierarchy";
	public final static String GRID_STRENGTH_ARIA_DESCRIBEDBY = "GENERIC_DRUG_GRID_StrngthUOM";

	// --------Search Result(s) - Generic Drugs(popup)---------------
	public final static String GRIDSEARCH_ID = "SEARCH_GENERIC_DRUG_GRID";
	public final static String GRIDSEADRUGCD_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_GRID_genericDrugCode";
	public final static String GRIDSEADRUGNM_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_GRID_drugName";
	public final static String GRIDSEATHERCHIER_ARIA_DESCRIBEDBY = "SEARCH_GENERIC_DRUG_GRID_therapeuticHierarchy";

	public final static String ADDTOSELECTBUTTON_ID = "ADD_TO_SELECTED";

	// --------Selected Generic Drugs(popup)---------------
	public final static String GRIDSELECT_ID = "GENERIC_DRUG_GRID";
	public final static String GRIDSELECT_DRUGCODE_ARIA_DESCRIBEDBY = "SELECTED_GENERIC_DRUG_GRID_genericDrugCode";
	public final static String GRIDSELECT_DRUGNAME_ARIA_DESCRIBEDBY = "SELECTED_GENERIC_DRUG_GRID_drugName";
	public final static String GRIDSELECTRCHIER_ARIA_DESCRIBEDBY = "SELECTED_GENERIC_DRUG_GRID_therapeuticHierarchy";

	@FindBy(linkText = ADDTOSELECTBUTTON_ID)
	private WebElement addToSelButton;

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = GRID_ID)
	private WebElement grid;

	@FindBy(xpath = ADDBUTTON_XPATH)
	private WebElement addButton;

	@FindBy(css = POPUPDIV_CSS)
	private WebElement popUp;

	@FindBy(id = POPUPHEADER_ID)
	private WebElement popupHeader;

	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;

	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;

	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;

	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the popUp
	 */
	public WebElement getPopUp() {
		return popUp;
	}

	/**
	 * @return the popupHeader
	 */
	public WebElement getPopupHeader() {
		return popupHeader;
	}

	/**
	 * @return the quickSearchTxt
	 */
	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the advSearchButton
	 */
	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	/**
	 * @return the addToSelect
	 */
	public WebElement getAddToSelButton() {
		return addToSelButton;
	}

		/*public void fillDatasIdentificationDetails(String[] excelData,
		WebDriverWait webDriverWait) throws InterruptedException {
	// getSectionName();
	// sleepVeryShort();
	if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
			"class").trim()))
		getSectionName().click();
	webDriverWait.until(ExpectedConditions
			.visibilityOf(getIdentificationDocument()));
	new Select(getIdentificationDocument())
			.selectByVisibleText(excelData[18].trim());
	getIdentificationNumber().clear();
	getIdentificationNumber().sendKeys(excelData[19].trim());
	
	if (Boolean.getBoolean(excelData[20].trim())) {
		getIsPrimary().click();
	}
*/
}
