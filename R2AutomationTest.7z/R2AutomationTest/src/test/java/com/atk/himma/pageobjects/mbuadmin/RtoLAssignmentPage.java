package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.restolocdetails.RtoLFirstSection;
import com.atk.himma.pageobjects.mbuadmin.tabs.RtoLAssignmentListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class RtoLAssignmentPage extends DriverWaitClass implements StatusMessages, TopControls, RecordStatus{
	
	private RtoLAssignmentListTab rtoLAssignmentListTab;
	private RtoLFirstSection rtoLFirstSection;
	
	public final static String EXPORTTOEXCEL_ID = "RES_SEARCH_GRID_export_btn";

	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";

	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'updated successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Record activated successfully')]";
	
	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Resource to Location Assignment']";	
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement SerCharDetPageTitle;
	
	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;
	
	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	/**
	 * @return the rtoLFirstSection
	 */
	public RtoLFirstSection getRtoLFirstSection() {
		return rtoLFirstSection;
	}

	/**
	 * @return the serCharDetPageTitle
	 */
	public WebElement getSerCharDetPageTitle() {
		return SerCharDetPageTitle;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		
		rtoLAssignmentListTab = PageFactory.initElements(webDriver,
				RtoLAssignmentListTab.class);
		rtoLAssignmentListTab.setWebDriver(webDriver);
		rtoLAssignmentListTab.setWebDriverWait(webDriverWait);

		rtoLFirstSection = PageFactory.initElements(webDriver,
				RtoLFirstSection.class);
		rtoLFirstSection.setWebDriver(webDriver);
		rtoLFirstSection.setWebDriverWait(webDriverWait);
	}
	
	public RtoLAssignmentPage clickOnRtoLAssignMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Resource to Location Assignment");
		RtoLAssignmentPage rtoLAssignmentPage = PageFactory.initElements(webDriver, RtoLAssignmentPage.class);
		rtoLAssignmentPage.setWebDriver(webDriver);
		rtoLAssignmentPage.setWebDriverWait(webDriverWait);
		return rtoLAssignmentPage;
	}

	public String searchResourceWise(String[] resToLocDatas) throws InterruptedException {
		waitForElementId(RtoLAssignmentListTab.MBU_ID);
		
		rtoLAssignmentListTab.getResourceName().clear();
		rtoLAssignmentListTab.getResourceName().sendKeys(resToLocDatas[5].trim());
		
		rtoLAssignmentListTab.getSearchButton().click();
		waitForElementId(RtoLAssignmentListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(RtoLAssignmentListTab.GRID_ID,
				RtoLAssignmentListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY, resToLocDatas[5]);
	}
	
	public String searchLocationWise(String[] resToLocDatas) throws InterruptedException {
		waitForElementId(RtoLAssignmentListTab.MBU_ID);
		rtoLAssignmentListTab.getLocWiseAssignRadio().click();
		waitForElementId(RtoLAssignmentListTab.RESSEARCHGRID_ID);
		rtoLAssignmentListTab.getLocWiseAssignRadio().clear();
		rtoLAssignmentListTab.getLocWiseAssignRadio().sendKeys(resToLocDatas[8].trim());
		rtoLAssignmentListTab.getSearchButton().click();
		sleepShort();
		return waitAndGetGridFirstCellText(RtoLAssignmentListTab.RESSEARCHGRID_ID,
				RtoLAssignmentListTab.GRID_LOCATION_ARIA_DESCRIBEDBY, resToLocDatas[8]);
	}
	
	public boolean assignLocForResWise(String[] rToLDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(RtoLAssignmentListTab.GRID_ID,
				RtoLAssignmentListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY, rToLDatas[5]);
		sleepShort();
		clickOnGridAction(rToLDatas[5], "Assign Location");
		waitForElementName(RtoLFirstSection.MBU_NAME);
		sleepVeryShort();
		return rtoLFirstSection.getResourceName().getAttribute("value").trim().equals(rToLDatas[5].trim());
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		sleepShort();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepShort();
		return detailsUpdateButton.getAttribute("value").trim();

	}
	
	public String activateRtoLAssign() throws InterruptedException, IOException {
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
		
	}
	
	public boolean editResWise(String[] rToLDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(RtoLAssignmentListTab.GRID_ID,
				RtoLAssignmentListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY, rToLDatas[5]);
		sleepShort();
		clickOnGridAction(rToLDatas[5], "Edit");
		waitForElementId(RtoLFirstSection.MBU_NAME);
		sleepVeryShort();
		return rtoLFirstSection.getResourceName().getAttribute("value").trim().equals(rToLDatas[5].trim());
	}
	
	/**
	 * @return the rtoLAssignmentListTab
	 */
	public RtoLAssignmentListTab getRtoLAssignmentListTab() {
		return rtoLAssignmentListTab;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

}
