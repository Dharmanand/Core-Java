package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class TATAttributesSec extends DriverWaitClass {
	public final static String TATATTRSEC_XPATH = "//a[text()='TAT Attributes']";
	@FindBy(xpath = TATATTRSEC_XPATH)
	private WebElement TATAttrSec;

	public final static String TATADDROWBTN_ID = "LAB_TEST_TAT_ADD";
	@FindBy(id = TATADDROWBTN_ID)
	private WebElement TATAddRowBtn;

	public final static String URGENCY_NAME = "urgencyId";
	@FindBy(name = URGENCY_NAME)
	private WebElement urgency;

	public final static String TATVAL_NAME = "tatValue";
	@FindBy(name = TATVAL_NAME)
	private WebElement TATVal;

	public final static String TIMEUNIT_NAME = "timeUnitId";
	@FindBy(name = TIMEUNIT_NAME)
	private WebElement timeUnit;

	public final static String TATGRIDTBL_ID = "LAB_TEST_TAT_GRID";
	@FindBy(name = TATGRIDTBL_ID)
	private WebElement TATGridTbl;

	public WebElement getTATAttrSec() {
		return TATAttrSec;
	}

	public WebElement getTATAddRowBtn() {
		return TATAddRowBtn;
	}

	public WebElement getUrgency() {
		return urgency;
	}

	public WebElement getTATVal() {
		return TATVal;
	}

	public WebElement getTimeUnit() {
		return timeUnit;
	}

	public WebElement getTATGridTbl() {
		return TATGridTbl;
	}

}
