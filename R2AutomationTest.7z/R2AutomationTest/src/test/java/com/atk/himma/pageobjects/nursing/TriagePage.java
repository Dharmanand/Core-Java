package com.atk.himma.pageobjects.nursing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.nursing.sections.TriageFirstSection;
import com.atk.himma.pageobjects.nursing.sections.TriageSection;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;

public class TriagePage extends DriverWaitClass implements StatusMessages {
	private TriageFirstSection triageFirstSection;
	private TriageSection triageSection;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String TRIAGEFORM_ID = "VITAL_SIGN_FORM";
	public final static String SAVEBTN_ID = "SAVE_BUTTON";
	public final static String CANCELBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String CONFIRMATIONMSG_ID = "ConfirmationMessage";
	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(id = TRIAGEFORM_ID)
	private WebElement triageForm;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(id = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	@FindBy(id = CONFIRMATIONMSG_ID)
	private WebElement confirmMsg;

	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		triageFirstSection = PageFactory.initElements(webDriver,
				TriageFirstSection.class);
		triageFirstSection.setWebDriver(webDriver);
		triageFirstSection.setWebDriverWait(webDriverWait);

		triageSection = PageFactory
				.initElements(webDriver, TriageSection.class);
		triageSection.setWebDriver(webDriver);
		triageSection.setWebDriverWait(webDriverWait);
	}

	public String saveTriageInfo() throws Exception {
		saveBtn.click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		sleepVeryShort();
		String msg = webDriver.findElement(By.xpath(MSGENABLE_XPATH)).getText();
		return msg;
	}

	public boolean removeTriageInfo(String[] outPatientListData)
			throws Exception {
		clickOnGridAction("VITAL_SIGNS_GRID_pulse", outPatientListData[26],
				"Remove");
		sleepVeryShort();
		waitForElementId(CONFIRMATIONMSG_ID);
		confirmYes.click();
		sleepVeryShort();
		saveBtn.click();
		sleepShort();
		try {
			return triageSection.checkVitalSignsGridData(outPatientListData);
		} catch (Exception e) {
			return false;
		}

	}

	public String saveNewTriageInfo() throws Exception {
		saveBtn.click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		sleepVeryShort();
		String msg = webDriver.findElement(By.xpath(MSGENABLE_XPATH)).getText();
		webDriver.close();
		webDriver.switchTo().window(parentWindowHandle);
		return msg;
	}

	public TriageFirstSection getTriageFirstSection() {
		return triageFirstSection;
	}

	public TriageSection getTriageSection() {
		return triageSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getTriageForm() {
		return triageForm;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getConfirmMsg() {
		return confirmMsg;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

}
