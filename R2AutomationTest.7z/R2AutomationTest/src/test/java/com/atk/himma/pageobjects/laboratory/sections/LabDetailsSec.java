package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LabDetailsSec extends DriverWaitClass {
	public final static String LABDTLSEC_XPATH = "//a[text()='Lab Details']";
	@FindBy(xpath = LABDTLSEC_XPATH)
	private WebElement labDtlSec;

	public final static String ADDSERVLOOKUP_ID = "ADD_SERVICES_POP_UP";
	@FindBy(id = ADDSERVLOOKUP_ID)
	private WebElement addServLookUp;

	public final static String ADDSERVPOPUPFORM_ID = "LAB_EQUIPMENT_ADD_SERVICE_FORM";
	@FindBy(id = ADDSERVPOPUPFORM_ID)
	private WebElement addServPopUpForm;

	public final static String ADDSERVPOPUPMBU_ID = "mbusId";
	@FindBy(id = ADDSERVPOPUPMBU_ID)
	private WebElement addServPopUpMBU;

	public final static String ADDSERVPOPUPDEPT_ID = "deptId";
	@FindBy(id = ADDSERVPOPUPDEPT_ID)
	private WebElement addServPopUpDept;

	public final static String ADDSERVPOPUPSPEC_ID = "specId";
	@FindBy(id = ADDSERVPOPUPSPEC_ID)
	private WebElement addServPopUpSpec;

	public final static String ADDSERVPOPUPSUBSPEC_ID = "subSpecId";
	@FindBy(id = ADDSERVPOPUPSUBSPEC_ID)
	private WebElement addServPopUpSubSpec;

	public final static String ADDSERVPOPUPSERVTYPE_ID = "serviceTypeId";
	@FindBy(id = ADDSERVPOPUPSERVTYPE_ID)
	private WebElement addServPopUpServType;

	public final static String ADDSERVPOPUPSERVCODE_NAME = "searchCriteria.serviceCode";
	@FindBy(name = ADDSERVPOPUPSERVCODE_NAME)
	private WebElement addServPopUpServCode;

	public final static String ADDSERVPOPUPSERVNAME_NAME = "searchCriteria.serviceName";
	@FindBy(name = ADDSERVPOPUPSERVNAME_NAME)
	private WebElement addServPopUpServName;

	public final static String ADDSERVPOPUPSEARCHBTN_ID = "LAB_EQUIPMENT_SERVICE_SRCH_BUT";
	@FindBy(id = ADDSERVPOPUPSEARCHBTN_ID)
	private WebElement addServPopUpSearchBtn;

	public final static String ADDSERVPOPUPRESETBTN_ID = "RESET_EQUIP_SERVICE";
	@FindBy(id = ADDSERVPOPUPRESETBTN_ID)
	private WebElement addServPopUpResetBtn;

	public final static String ADDSERVPOPUPGRIDTBL_ID = "LAB_EQUIPMENT_SERVICE_RESULT_GRID";
	@FindBy(id = ADDSERVPOPUPGRIDTBL_ID)
	private WebElement addServPopUpGridTbl;

	public final static String ADDSERVTOEQUIPBTN_ID = "ADD_SERVICE_TO_EQUIPMENT";
	@FindBy(id = ADDSERVTOEQUIPBTN_ID)
	private WebElement addServToEquipBtn;

	public final static String EQUIPSERVDTLGRIDTBL_ID = "LAB_EQUIPMENT_SERVICE_DETAILS_GRID";
	@FindBy(id = EQUIPSERVDTLGRIDTBL_ID)
	private WebElement equipServDtlGridTbl;

	public final static String ANALYZERTESTNAME_NAME = "analyzerTestName";
	@FindBy(name = ANALYZERTESTNAME_NAME)
	private WebElement analyzerTestName;

	public WebElement getLabDtlSec() {
		return labDtlSec;
	}

	public WebElement getAddServLookUp() {
		return addServLookUp;
	}

	public WebElement getAddServPopUpForm() {
		return addServPopUpForm;
	}

	public WebElement getAddServPopUpMBU() {
		return addServPopUpMBU;
	}

	public WebElement getAddServPopUpDept() {
		return addServPopUpDept;
	}

	public WebElement getAddServPopUpSpec() {
		return addServPopUpSpec;
	}

	public WebElement getAddServPopUpSubSpec() {
		return addServPopUpSubSpec;
	}

	public WebElement getAddServPopUpServType() {
		return addServPopUpServType;
	}

	public WebElement getAddServPopUpServCode() {
		return addServPopUpServCode;
	}

	public WebElement getAddServPopUpServName() {
		return addServPopUpServName;
	}

	public WebElement getAddServPopUpSearchBtn() {
		return addServPopUpSearchBtn;
	}

	public WebElement getAddServPopUpResetBtn() {
		return addServPopUpResetBtn;
	}

	public WebElement getAddServPopUpGridTbl() {
		return addServPopUpGridTbl;
	}

	public WebElement getAddServToEquipBtn() {
		return addServToEquipBtn;
	}

	public WebElement getEquipServDtlGridTbl() {
		return equipServDtlGridTbl;
	}

	public WebElement getAnalyzerTestName() {
		return analyzerTestName;
	}

}
