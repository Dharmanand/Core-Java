package com.atk.himma.pageobjects.mbuadmin.master.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LocationCategoryMBUListTab extends DriverWaitClass {

	public final static String FORM_ID = "LOCATIONCATEGORY_LIST_FORM";
	public final static String MBULISTTAB_XPATH = "//a[@title='Main Business Unit List']";
	public final static String MBUNAME_ID = "UNIT_NAME";
	public final static String MBUCODE_ID = "UNIT_CODE";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "SEARCH_LOCATION_CATEGORY_INFO";
	public final static String GRID_MBUNAME_ARIA_DESCRIBEDBY = "SEARCH_LOCATION_CATEGORY_INFO_mainBusinessUnit.unitName";
	public final static String GRID_MBUCODE_ARIA_DESCRIBEDBY = "SEARCH_LOCATION_CATEGORY_INFO_mainBusinessUnit.unitCode";
	public final static String GRID_LOCATIONCATEGORY_ARIA_DESCRIBEDBY = "SEARCH_LOCATION_CATEGORY_INFO_baseLVNames";
	public final static String GRID_PAGERID = "sp_1_SEARCH_LOCATION_CATEGORY_INFO_pager";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = MBULISTTAB_XPATH)
	private WebElement mbuListTab;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;

	@FindBy(id = MBUCODE_ID)
	private WebElement mbuCode;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	// ---------------------------------------------- Grid Start

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the mbuListTab
	 */
	public WebElement getMbuListTab() {
		return mbuListTab;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

}
