package com.atk.himma.pageobjects.preg.regsections;

import com.atk.himma.util.DriverWaitClass;

public class PolicyDetailsSection extends DriverWaitClass{

}
