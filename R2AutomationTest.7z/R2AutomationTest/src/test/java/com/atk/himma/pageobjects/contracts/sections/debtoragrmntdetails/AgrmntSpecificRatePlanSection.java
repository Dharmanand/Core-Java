package com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AgrmntSpecificRatePlanSection extends DriverWaitClass {
	public final static String AGRMNTSPECRATEPLANSEC_LINKTEXT = "Agreement Specific Rate Plan";
	public final static String AGRMNTSERVRATEPLAN_ID = "AGMNT_SER_RATE_PLAN_DATA";
	public final static String VIEWRATEPLANBTN_ID = "VIEW_RATEPLAN";
	public final static String EDITRATEPLANBTN_ID = "EDIT_RATEPLAN";
	public final static String CREATERATEPLANBTN_ID = "CREATE_RATEPLAN";

	public final static String CHARGEBASEDONSELLING_ID = "ITEM_CHARGE_ON_AGMNT_DEBT1";
	public final static String CHARGEBASEDONMRP_ID = "ITEM_CHARGE_ON_AGMNT_DEBT2";
	public final static String CHARGEBASEDONCOSTPRICE_ID = "ITEM_CHARGE_ON_AGMNT_DEBT3";
	public final static String ADDROWBTN_ID = "AddRow_debt_ItemForm_Action";

	public final static String ITEMLVL_NAME = "itemLevel";
	public final static String SEARCHLOOKUP_ID = "gridSearchLookup";
	public final static String ITEMLOOKUPFORM_ID = "ITEM_LEVEL_FORM_DEB_AGMNT";
	public final static String MBU_ID = "ITEM_LEVEL_MBU_DEB_AGMNT";
	public final static String ITEMTYPE_ID = "ITEM_LEVEL_ITYPE_DEB_AGMNT";
	public final static String ITEMCATEGORY_ID = "ITEM_LEVEL_ICAT_DEB_AGMNT";
	public final static String ITEMSUBCATEGORY_ID = "ITEM_LEVEL_ISUBCAT_DEB_AGMNT";
	public final static String ITEMCODE_ID = "ITEM_LEVEL_CODE_DEB_AGMNT";
	public final static String ITEMNAME_ID = "ITEM_LEVEL_NAME_DEB_AGMNT";
	public final static String ITEMSEARCHBTN_ID = "ITEM_LEVEL_SEARCH_DEB_AGMNT";
	public final static String ITEMRESETBTN_ID = "ITEM_LEVEL_RESET_DEB_AGMNT";
	public final static String ITEMGRIDDIV_ID = "ITEM_LEVEL_GRID_DIV_DEB_AGMNT";
	public final static String ITEMSUBMIT_ID = "ITEM_LEVEL_SUBMIT_DEB_AGMNT";
	public final static String ITEMCANCEL_ID = "ITEM_LEVEL_CANCEL_DEB_AGMNT";

	public final static String ITEMTYPEFORM_ID = "ITEM_TYPE_FORM_DEB_AGMNT";
	public final static String ITEMTYPENAME_ID = "ITEM_TYPE_NAME_DEB_AGMNT";
	public final static String ITEMTYPECODE_ID = "ITEM_TYPE_CODE_DEB_AGMNT";
	public final static String ITEMTYPESEARCHBTN_ID = "ITEM_TYPE_SEARCH_DEB_AGMNT";
	public final static String ITEMTYPERESETBTN_ID = "ITEM_TYPE_RESET_DEB_AGMNT";
	public final static String ITEMTYPEGRIDDIV_ID = "ITEM_TYPE_GRID_DIV_DEB_AGMNT";
	public final static String ITEMTYPESUBMITBTN_ID = "ITEM_TYPE_SUBMIT_DEB_AGMNT";
	public final static String ITEMTYPECANCELBTN_ID = "ITEM_TYPE_CANCEL_DEB_AGMNT";

	public final static String ITEMCATFORM_ID = "ITEM_CAT_FORM_DEB_AGMNT";
	public final static String ITEMCAT_ITMTYPE_ID = "ITEM_CAT_ITYPE_DEB_AGMNT";
	public final static String ITEMCATNAME_ID = "ITEM_CAT_NAME_DEB_AGMNT";
	public final static String ITEMCATCODE_ID = "ITEM_CAT_CODE_DEB_AGMNT";
	public final static String ITEMCATSEARCHBTN_ID = "ITEM_CAT_SEARCH_DEB_AGMNT";
	public final static String ITEMCATRESETBTN_ID = "ITEM_CAT_RESET_DEB_AGMNT";
	public final static String ITEMCATGRIDDIV_ID = "ITEM_CAT_GRID_DIV_DEB_AGMNT";
	public final static String ITEMCATSUBMITBTN_ID = "ITEM_CAT_SUBMIT_DEB_AGMNT";
	public final static String ITEMCATCANCELBTN_ID = "ITEM_CAT_CANCEL_DEB_AGMNT";

	public final static String ITEMSUBCATFORM_ID = "ITEM_SUB_CAT_FORM_DEB_AGMNT";
	public final static String ITEMSUBCAT_ITMTYPE_ID = "ITEM_SUB_CAT_ITYPE_DEB_AGMNT";
	public final static String ITEMSUBCAT_ITMCAT_ID = "ITEM_SUB_CAT_ICAT_DEB_AGMNT";
	public final static String ITEMSUBCATNAME_ID = "ITEM_SUB_CAT_NAME_DEB_AGMNT";
	public final static String ITEMSUBCATCODE_ID = "ITEM_SUB_CAT_CODE_DEB_AGMNT";
	public final static String ITEMSUBCATSEARCHBTN_ID = "ITEM_SUB_CAT_SEARCH_DEB_AGMNT";
	public final static String ITEMSUBCATRESETBTN_ID = "ITEM_SUB_CAT_RESET_DEB_AGMNT";
	public final static String ITEMSUBCATGRIDDIV_ID = "ITEM_SUB_CAT_GRID_DIV_DEB_AGMNT";
	public final static String ITEMSUBCATSUBMITBTN_ID = "ITEM_SUB_CAT_SUBMIT_DEB_AGMNT";
	public final static String ITEMSUBCATCANCELBTN_ID = "ITEM_SUB_CAT_CANCEL_DEB_AGMNT";

	public final static String MODIFPATTERN_NAME = "modPattern";
	public final static String MODIFTYPE_NAME = "modType";
	public final static String MODIFVALUE_NAME = "modValue";

	private final static String SELLING = "Selling", MRP = "MRP",
			COST_PRICE = "Cost Price", ITEM = "Item", ITEM_TYPE = "Item Type",
			ITEM_CATEGORY = "Item Category",
			ITEM_SUB_CATEGORY = "Item Sub Category";

	@FindBy(linkText = AGRMNTSPECRATEPLANSEC_LINKTEXT)
	private WebElement agrmntSpecRatePlanSec;

	@FindBy(id = AGRMNTSERVRATEPLAN_ID)
	private WebElement agrmntServRatePlan;

	@FindBy(id = VIEWRATEPLANBTN_ID)
	private WebElement viewRatePlanBtn;

	@FindBy(id = EDITRATEPLANBTN_ID)
	private WebElement editRatePlanBtn;

	@FindBy(id = CREATERATEPLANBTN_ID)
	private WebElement createRatePlanBtn;

	@FindBy(id = CHARGEBASEDONSELLING_ID)
	private WebElement chargeBasedOnSelling;

	@FindBy(id = CHARGEBASEDONMRP_ID)
	private WebElement chargeBasedOnMRP;

	@FindBy(id = CHARGEBASEDONCOSTPRICE_ID)
	private WebElement chargeBasedOnCostPrice;

	@FindBy(id = ADDROWBTN_ID)
	private WebElement addRowBtn;

	@FindBy(name = ITEMLVL_NAME)
	private WebElement itemLvlList;

	@FindBy(id = SEARCHLOOKUP_ID)
	private WebElement searchLookUp;

	@FindBy(id = ITEMLOOKUPFORM_ID)
	private WebElement itemLookUpForm;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = ITEMTYPE_ID)
	private WebElement itemType;

	@FindBy(id = ITEMCATEGORY_ID)
	private WebElement itemCategory;

	@FindBy(id = ITEMSUBCATEGORY_ID)
	private WebElement itemSubCategory;

	@FindBy(id = ITEMCODE_ID)
	private WebElement itemCode;

	@FindBy(id = ITEMNAME_ID)
	private WebElement itemName;

	@FindBy(id = ITEMSEARCHBTN_ID)
	private WebElement itemSearchBtn;

	@FindBy(id = ITEMRESETBTN_ID)
	private WebElement itemResetBtn;

	@FindBy(id = ITEMGRIDDIV_ID)
	private WebElement itemGridDiv;

	@FindBy(id = ITEMSUBMIT_ID)
	private WebElement itemSubmit;

	@FindBy(id = ITEMCANCEL_ID)
	private WebElement itemCancel;

	@FindBy(id = ITEMTYPEFORM_ID)
	private WebElement itemTypeForm;

	@FindBy(id = ITEMTYPENAME_ID)
	private WebElement itemTypeName;

	@FindBy(id = ITEMTYPECODE_ID)
	private WebElement itemTypeCode;

	@FindBy(id = ITEMTYPESEARCHBTN_ID)
	private WebElement itemTypeSearchBtn;

	@FindBy(id = ITEMTYPERESETBTN_ID)
	private WebElement itemTypeResetBtn;

	@FindBy(id = ITEMTYPEGRIDDIV_ID)
	private WebElement itemTypeGridDiv;

	@FindBy(id = ITEMTYPESUBMITBTN_ID)
	private WebElement itemTypeSubmitBtn;

	@FindBy(id = ITEMTYPECANCELBTN_ID)
	private WebElement itemTypeCancelBtn;

	@FindBy(id = ITEMCATFORM_ID)
	private WebElement itemCategoryForm;

	@FindBy(id = ITEMCAT_ITMTYPE_ID)
	private WebElement itemCatItemType;

	@FindBy(id = ITEMCATNAME_ID)
	private WebElement itemCatName;

	@FindBy(id = ITEMCATCODE_ID)
	private WebElement itemCatCode;

	@FindBy(id = ITEMCATSEARCHBTN_ID)
	private WebElement itemCatSearchBtn;

	@FindBy(id = ITEMCATRESETBTN_ID)
	private WebElement itemCatResetBtn;

	@FindBy(id = ITEMCATGRIDDIV_ID)
	private WebElement itemCatGridDiv;

	@FindBy(id = ITEMCATSUBMITBTN_ID)
	private WebElement itemCatSubmitBtn;

	@FindBy(id = ITEMCATCANCELBTN_ID)
	private WebElement itemCatCancelBtn;

	@FindBy(id = ITEMSUBCATFORM_ID)
	private WebElement itemSubCatForm;

	@FindBy(id = ITEMSUBCAT_ITMTYPE_ID)
	private WebElement itemSubCatItmType;

	@FindBy(id = ITEMSUBCAT_ITMCAT_ID)
	private WebElement itemSubCatItmCategory;

	@FindBy(id = ITEMSUBCATNAME_ID)
	private WebElement itemSubCatName;

	@FindBy(id = ITEMSUBCATCODE_ID)
	private WebElement itemSubCatCode;

	@FindBy(id = ITEMSUBCATSEARCHBTN_ID)
	private WebElement itemSubCatSearchBtn;

	@FindBy(id = ITEMSUBCATRESETBTN_ID)
	private WebElement itemSubCatResetBtn;

	@FindBy(id = ITEMSUBCATGRIDDIV_ID)
	private WebElement itemSubCatGridDiv;

	@FindBy(id = ITEMSUBCATSUBMITBTN_ID)
	private WebElement itemSubCatSubmitBtn;

	@FindBy(id = ITEMSUBCATCANCELBTN_ID)
	private WebElement itemSubCatCancelBtn;

	@FindBy(name = MODIFPATTERN_NAME)
	private WebElement modifPattern;

	@FindBy(name = MODIFTYPE_NAME)
	private WebElement modifType;

	@FindBy(name = MODIFVALUE_NAME)
	private WebElement modifValue;

	public void addAgrmntSpecRatePlanData(String[] debtorAgrmntListData)
			throws Exception {
		sleepShort();
		if (SELLING.equals(debtorAgrmntListData[54])) {
			chargeBasedOnSelling.click();
		} else if (MRP.equals(debtorAgrmntListData[54])) {
			chargeBasedOnMRP.click();
		} else if (COST_PRICE.equals(debtorAgrmntListData[54])) {
			chargeBasedOnCostPrice.click();
		}
		addRowBtn.click();
		sleepVeryShort();
		if (!debtorAgrmntListData[55].isEmpty()) {
			new Select(itemLvlList)
					.selectByVisibleText(debtorAgrmntListData[55]);
		}
		searchLookUp.click();
		selectItemLevelName(debtorAgrmntListData);
		if (!debtorAgrmntListData[70].isEmpty()) {
			new Select(modifPattern)
					.selectByVisibleText(debtorAgrmntListData[70]);
		}
		if (!debtorAgrmntListData[71].isEmpty()) {
			new Select(modifType).selectByVisibleText(debtorAgrmntListData[71]);
		}
		modifValue.clear();
		modifValue.sendKeys(debtorAgrmntListData[72]);

	}

	private void selectItemLevelName(String[] debtorAgrmntListData)
			throws Exception {
		if (ITEM.equals(debtorAgrmntListData[55])) {
			waitForElementId(ITEMLOOKUPFORM_ID);
			sleepVeryShort();
			if (!debtorAgrmntListData[56].isEmpty()) {
				new Select(itemType)
						.selectByVisibleText(debtorAgrmntListData[56]);
			}
			waitForElementId(ITEMCATEGORY_ID);
			sleepVeryShort();
			if (!debtorAgrmntListData[57].isEmpty()) {
				new Select(itemCategory)
						.selectByVisibleText(debtorAgrmntListData[57]);
			}
			waitForElementId(ITEMSUBCATEGORY_ID);
			sleepVeryShort();
			if (!debtorAgrmntListData[58].isEmpty()) {
				new Select(itemSubCategory)
						.selectByVisibleText(debtorAgrmntListData[58]);
			}
			itemCode.clear();
			itemCode.sendKeys(debtorAgrmntListData[59]);
			itemName.clear();
			itemName.sendKeys(debtorAgrmntListData[60]);
			itemSearchBtn.click();
			sleepShort();
			waitForElementId(ITEMGRIDDIV_ID);
			webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='ITEM_LEVEL_GRID_DEB_AGMNT_itemName' and @title='"
									+ debtorAgrmntListData[60]
									+ "']/..//td[@aria-describedby='ITEM_LEVEL_GRID_DEB_AGMNT_cb']/input"))
					.click();
			itemSubmit.click();

		} else if (ITEM_TYPE.equals(debtorAgrmntListData[55])) {
			waitForElementId(ITEMTYPEFORM_ID);
			itemTypeName.clear();
			itemTypeName.sendKeys(debtorAgrmntListData[61]);

			itemTypeCode.clear();
			itemTypeCode.sendKeys(debtorAgrmntListData[62]);
			itemTypeSearchBtn.click();
			sleepShort();
			waitForElementId(ITEMTYPEGRIDDIV_ID);
			webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='ITEM_TYPE_GRID_DEB_AGMNT_itemCode' and @title='"
									+ debtorAgrmntListData[62]
									+ "']/..//td[@aria-describedby='ITEM_TYPE_GRID_DEB_AGMNT_cb']/input"))
					.click();
			itemTypeSubmitBtn.click();

		} else if (ITEM_CATEGORY.equals(debtorAgrmntListData[55])) {
			waitForElementId(ITEMCATFORM_ID);
			if (!debtorAgrmntListData[63].isEmpty()) {
				new Select(itemCatItemType)
						.selectByVisibleText(debtorAgrmntListData[63]);
			}
			itemCatName.clear();
			itemCatName.sendKeys(debtorAgrmntListData[64]);
			itemCatCode.clear();
			itemCatCode.sendKeys(debtorAgrmntListData[65]);

			sleepShort();
			waitForElementId(ITEMCATGRIDDIV_ID);
			webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='ITEM_CAT_GRID_DEB_AGMNT_itemName' and @title='"
									+ debtorAgrmntListData[64]
									+ "']/..//td[@aria-describedby='ITEM_CAT_GRID_DEB_AGMNT_cb']/input"))
					.click();
			itemCatSubmitBtn.click();

		} else if (ITEM_SUB_CATEGORY.equals(debtorAgrmntListData[55])) {
			waitForElementId(ITEMSUBCATFORM_ID);
			if (!debtorAgrmntListData[66].isEmpty()) {
				new Select(itemSubCatItmType)
						.selectByVisibleText(debtorAgrmntListData[66]);
			}
			if (!debtorAgrmntListData[67].isEmpty()) {
				new Select(itemSubCatItmCategory)
						.selectByVisibleText(debtorAgrmntListData[67]);
			}
			itemSubCatName.clear();
			itemSubCatName.sendKeys(debtorAgrmntListData[68]);

			itemSubCatCode.clear();
			itemSubCatCode.sendKeys(debtorAgrmntListData[69]);
			itemSubCatSearchBtn.click();
			sleepShort();
			waitForElementId(ITEMSUBCATGRIDDIV_ID);
			webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='ITEM_SUB_CAT_GRID_DEB_AGMNT_itemName' and @title='"
									+ debtorAgrmntListData[68]
									+ "']/..//td[@aria-describedby='ITEM_SUB_CAT_GRID_DEB_AGMNT_cb']/input"))
					.click();
			itemSubCatSubmitBtn.click();

		}
	}

	public WebElement getAgrmntSpecRatePlanSec() {
		return agrmntSpecRatePlanSec;
	}

	public WebElement getAgrmntServRatePlan() {
		return agrmntServRatePlan;
	}

	public WebElement getViewRatePlanBtn() {
		return viewRatePlanBtn;
	}

	public WebElement getEditRatePlanBtn() {
		return editRatePlanBtn;
	}

	public WebElement getCreateRatePlanBtn() {
		return createRatePlanBtn;
	}

	public WebElement getChargeBasedOnSelling() {
		return chargeBasedOnSelling;
	}

	public WebElement getChargeBasedOnMRP() {
		return chargeBasedOnMRP;
	}

	public WebElement getChargeBasedOnCostPrice() {
		return chargeBasedOnCostPrice;
	}

	public WebElement getAddRowBtn() {
		return addRowBtn;
	}

	public WebElement getItemLvlList() {
		return itemLvlList;
	}

	public WebElement getSearchLookUp() {
		return searchLookUp;
	}

	public WebElement getItemLookUpForm() {
		return itemLookUpForm;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getItemType() {
		return itemType;
	}

	public WebElement getItemCategory() {
		return itemCategory;
	}

	public WebElement getItemSubCategory() {
		return itemSubCategory;
	}

	public WebElement getItemCode() {
		return itemCode;
	}

	public WebElement getItemName() {
		return itemName;
	}

	public WebElement getItemSearchBtn() {
		return itemSearchBtn;
	}

	public WebElement getItemResetBtn() {
		return itemResetBtn;
	}

	public WebElement getItemGridDiv() {
		return itemGridDiv;
	}

	public WebElement getItemSubmit() {
		return itemSubmit;
	}

	public WebElement getItemCancel() {
		return itemCancel;
	}

	public WebElement getItemTypeForm() {
		return itemTypeForm;
	}

	public WebElement getItemTypeName() {
		return itemTypeName;
	}

	public WebElement getItemTypeCode() {
		return itemTypeCode;
	}

	public WebElement getItemTypeSearchBtn() {
		return itemTypeSearchBtn;
	}

	public WebElement getItemTypeResetBtn() {
		return itemTypeResetBtn;
	}

	public WebElement getItemTypeGridDiv() {
		return itemTypeGridDiv;
	}

	public WebElement getItemTypeSubmitBtn() {
		return itemTypeSubmitBtn;
	}

	public WebElement getItemTypeCancelBtn() {
		return itemTypeCancelBtn;
	}

	public WebElement getItemCategoryForm() {
		return itemCategoryForm;
	}

	public WebElement getItemCatItemType() {
		return itemCatItemType;
	}

	public WebElement getItemCatName() {
		return itemCatName;
	}

	public WebElement getItemCatCode() {
		return itemCatCode;
	}

	public WebElement getItemCatSearchBtn() {
		return itemCatSearchBtn;
	}

	public WebElement getItemCatResetBtn() {
		return itemCatResetBtn;
	}

	public WebElement getItemCatGridDiv() {
		return itemCatGridDiv;
	}

	public WebElement getItemCatSubmitBtn() {
		return itemCatSubmitBtn;
	}

	public WebElement getItemCatCancelBtn() {
		return itemCatCancelBtn;
	}

	public WebElement getItemSubCatForm() {
		return itemSubCatForm;
	}

	public WebElement getItemSubCatItmType() {
		return itemSubCatItmType;
	}

	public WebElement getItemSubCatItmCategory() {
		return itemSubCatItmCategory;
	}

	public WebElement getItemSubCatName() {
		return itemSubCatName;
	}

	public WebElement getItemSubCatCode() {
		return itemSubCatCode;
	}

	public WebElement getItemSubCatSearchBtn() {
		return itemSubCatSearchBtn;
	}

	public WebElement getItemSubCatResetBtn() {
		return itemSubCatResetBtn;
	}

	public WebElement getItemSubCatGridDiv() {
		return itemSubCatGridDiv;
	}

	public WebElement getItemSubCatSubmitBtn() {
		return itemSubCatSubmitBtn;
	}

	public WebElement getItemSubCatCancelBtn() {
		return itemSubCatCancelBtn;
	}

	public WebElement getModifPattern() {
		return modifPattern;
	}

	public WebElement getModifType() {
		return modifType;
	}

	public WebElement getModifValue() {
		return modifValue;
	}

}
