package com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ExclusionListDetailsSection extends DriverWaitClass {
	public final static String EXCLISTDETAILSSEC_LINKTXT = "Exclusion List Details";
	public final static String SERVDEFPATTERN_ID = "DEF_PATTERN_RADIO2";
	public final static String ICDDEFPATTERN_ID = "DEF_PATTERN_RADIO1";
	public final static String ITEMDEFPATTERN_ID = "DEF_PATTERN_RADIO3";

	public final static String SERVEXCGRIDDIV_ID = "ServiceExclusion";
	public final static String ICDEXCGRIDDIV_ID = "ICDExclusion";
	public final static String ITEMEXCGRIDDIV_ID = "ItemExclusion";

	public final static String SERVADDROWBTN_XPATH = "//div[@id='ServiceExclusion']//input[@id='AddRow_ServiceForm_Action']";
	public final static String ICDADDROWBTN_XPATH = "//div[@id='ICDExclusion']//input[@id='AddRow_ICDForm_Action']";
	public final static String ITEMADDROWBTN_XPATH = "//div[@id='ItemExclusion']//input[@id='AddRow_Excl_ItemForm_Action']";

	public final static String SERVLVLLIST_NAME = "serviceLevel";
	public final static String SERVLVLCODE_NAME = "serviceLevelCode";
	public final static String SERVLVLNAME_NAME = "serviceLevelName";
	public final static String GRIDSEARCHLOOKUP_ID = "gridSearchLookup";

	public final static String SERVLVLFORM_ID = "serviceLevelForm";
	public final static String SERVLVLDEPT_ID = "SERV_LEVEL_DEPT";
	public final static String SERVLVLSPLTY_ID = "SERV_LEVEL_SERVSPEC";
	public final static String SERVLVLSUBSPLTY_ID = "SERV_LEVEL_SERVSUBSPEC";
	public final static String SERVLVLTYPE_ID = "SERV_LEVEL_SERTYPE";
	public final static String SERVLVLCODE_ID = "SERV_LEVEL_CODE";
	public final static String SERVNAME_ID = "SERV_LEVEL_NAME";
	public final static String SERVLVLSEARCH_ID = "SERV_LEVEL_SEARCH";
	public final static String SERVLVLRESET_ID = "SERV_LEVEL_RESET";
	public final static String SERVLVLGRIDDIV_ID = "SERV_LEVEL_GRID_DIV";
	public final static String SERVLVLGRIDTBL_ID = "SERV_LEVEL_GRID";
	public final static String SERVLVLGRID_SERNAM_ARIA_DESCRIBEDBY = "SERV_LEVEL_GRID_serviceName";
	public final static String SERVLVLSUBMITBTN_ID = "SERV_LEVEL_SUBMIT";
	public final static String SERVLVLCANCEL_ID = "SERV_LEVEL_CANCEL";

	public final static String SERVTYPEFORM_ID = "serviceTypeformID";
	public final static String SERVTYPENAME_ID = "SERV_TYPE_NAME";
	public final static String SERVTYPECODE_ID = "SERV_TYPE_CODE";
	public final static String SERVTYPESEARCHBTN_ID = "SERV_TYPE_SEARCH";
	public final static String SERVTYPERESETBTN_ID = "SERV_TYPE_RESET";
	public final static String SERVTYPEGRIDDIV_ID = "SERV_TYPE_GRID_DIV";
	public final static String SERVTYPEGRID_ID = "SERV_TYPE_GRID";
	public final static String SERVTYPESUBMITBTN_ID = "SERV_TYPE_SUBMIT";
	public final static String SERVTYPECANCELBTN_ID = "SERV_TYPE_CANCEL";

	public final static String SERVSPLTYFORM_ID = "serviceSpecialtyformId";
	public final static String SERVSPLTYDEPT_ID = "SERV_SPEC_DEPT";
	public final static String SERVSPLTYNAME_ID = "SERV_SPEC_NAME";
	public final static String SERVSPLTYCODE_ID = "SERV_SPEC_CODE";
	public final static String SERVSPLTYSEARCHBTN_ID = "SERV_SPEC_SEARCH";
	public final static String SERVSPLTYRESETBTN_ID = "SERV_SPEC_RESET";
	public final static String SERVSPLTYGRIDDIV_ID = "SERV_SPEC_GRID_DIV";
	public final static String SERVSPLTYGRID_ID = "SERV_SPEC_GRID";
	public final static String SERVSPLTYSUBMITBTN_ID = "SERV_SPEC_SUBMIT";
	public final static String SERVSPLTYCANCEL_ID = "SERV_SPEC_CANCEL";

	public final static String SERVSUBSPLTYFORM_ID = "serviceSubSpecialtyForm";
	public final static String SERVSUBSPLTYDEPT_ID = "SERV_SUB_SPEC_DEPT";
	public final static String SERVSUBSPLTY_SERVSPLTY_ID = "SERV_SUB_SPEC_SERVSPEC";
	public final static String SERVSUBSPLTYNAME_ID = "SERV_SUB_SPEC_NAME";
	public final static String SERVSUBSPLTYCODE_ID = "SERV_SUB_SPEC_CODE";
	public final static String SERVSUBSPLTYSEARCHBTN_ID = "SERV_SUB_SPEC_SEARCH";
	public final static String SERVSUBSPLTYRESETBTN_ID = "SERV_SUB_SPEC_RESET";
	public final static String SERVSUBSPLTYGRIDDIV_ID = "SERV_SUB_SPEC_GRID_DIV";
	public final static String SERVSUBSPLTYGRID_ID = "SERV_SUB_SPEC_GRID";
	public final static String SERVSUBSPLTYSUBMITBTN_ID = "SERV_SUB_SPEC_SUBMIT";
	public final static String SERVSUBSPLTYCANCELBTN_ID = "SERV_SUB_SPEC_CANCEL";

	public final static String INCLUDESERV_NAME = "include";
	public final static String SERVISITCATEG_XPATH = "//div[@id='ServiceExclusion']//button[@class='ui-multiselect ui-state-default']";
	public final static String ICDVISITCATEG_XPATH = "//div[@id='ICDExclusion']//button[@class='ui-multiselect ui-state-default']";
	public final static String ITVISITCATEG_XPATH = "//div[@id='ItemExclusion']//button[@class='ui-multiselect ui-state-default']";
	public final static String SERVPATDISCTYPE_NAME = "type";
	public final static String SERVPATDISCVALUE_NAME = "value";
	public final static String SERVEXCDELLINK_XPATH = ".//table[@id='SERV_GRID']/..//a[text()='Delete']";

	public final static String ICDPTRNDESC_XPATH = "//div[@id='ICDExclusion']//input[@name='icdDesc']";
	public final static String ICDLOOKUPDIV_ID = "icdLookup";
	public final static String ICDCODE_ID = "S_ICD_CODE";
	public final static String ICDDESC_ID = "S_ICD_DESC";
	public final static String ICDSEARCHBTN_ID = "ICD_SEARCH";
	public final static String ICDRESETBTN_ID = "RESET_ICD";
	public final static String ICDGRIDDIV_ID = "DIV_ICD_SEARCH_POPUP";
	public final static String ICDGRID_ID = "ICD_SEARCH_POPUP_GRID";
	public final static String ICDSUBMITBTN_ID = "SUBMIT_ICD_SEARCH";
	public final static String ICDCANCELBTN_ID = "CANCEL_ICD_SEARCH";
	public final static String INCLUDEICD_NAME = "includeFlg";
	public final static String ICDPATDISCTYPE_NAME = "patDiscountType";
	public final static String ICDPATDISCVALUE_NAME = "patDiscountValue";

	public final static String ITEMLVLLIST_NAME = "itemLevel";
	public final static String ITEMLVLCODE_NAME = "itemLevelCode";
	public final static String ITEMLOOKUP_ID = "ITEM_LEVEL_FORM";
	public final static String ITEMTYPE_NAME = "searchCriteriaExcItem.itemTypeId";
	public final static String ITEMCATEGORY_NAME = "searchCriteriaExcItem.itemCategoryId";
	public final static String ITEMSUBCATEGORY_NAME = "searchCriteriaExcItem.itemSubCategoryId";
	public final static String ITEMCODE_NAME = "searchCriteriaExcItem.itemCode";
	public final static String ITEMNAME_NAME = "searchCriteriaExcItem.itemName";
	public final static String ITEMLVLSEARCH_ID = "ITEM_LEVEL_SEARCH";
	public final static String ITEMLVLRESET_ID = "ITEM_LEVEL_RESET";
	public final static String ITEMLVLGRIDDIV_ID = "ITEM_LEVEL_GRID_DIV";
	public final static String ITEMLVLGRID_ID = "ITEM_LEVEL_GRID";
	public final static String ITEMLVLSUBMITBTN_ID = "ITEM_LEVEL_SUBMIT";
	public final static String ITEMLVLCANCELBTN_ID = "ITEM_LEVEL_CANCEL";

	public final static String ITEMTYPEFORM_ID = "ITEM_TYPE_FORM";
	public final static String ITEMTYPENAME_ID = "ITEM_TYPE_NAME";
	public final static String ITEMTYPECODE_ID = "ITEM_TYPE_CODE";
	public final static String ITEMTYPESEARCHBTN_ID = "ITEM_TYPE_SEARCH";
	public final static String ITEMTYPERESETBTN_ID = "ITEM_TYPE_RESET";
	public final static String ITEMTYPEGRIDDIV_ID = "ITEM_TYPE_GRID_DIV";
	public final static String ITEMTYPEGRID_ID = "ITEM_TYPE_GRID";
	public final static String ITEMTYPESUBMITBTN_ID = "ITEM_TYPE_SUBMIT";
	public final static String ITEMTYPECANCELBTN_ID = "ITEM_TYPE_CANCEL";

	public final static String ITEMCATEGORYFORM_ID = "ITEM_CAT_FORM";
	public final static String ITEMCAT_ITEMTYPE_ID = "ITEM_CAT_ITYPE";
	public final static String ITEMCATNAME_ID = "ITEM_CAT_NAME";
	public final static String ITEMCATCODE_ID = "ITEM_CAT_CODE";
	public final static String ITEMCATSEARCHBTN_ID = "ITEM_CAT_SEARCH";
	public final static String ITEMCATRESETBTN_ID = "ITEM_CAT_RESET";
	public final static String ITEMCATGRIDDIV_ID = "ITEM_CAT_GRID_DIV";
	public final static String ITEMCATGRID_ID = "ITEM_CAT_GRID";
	public final static String ITEMCATSUBMITBTN_ID = "ITEM_CAT_SUBMIT";
	public final static String ITEMCATCANCELBTN_ID = "ITEM_CAT_CANCEL";

	public final static String ITEMSUBCATFORM_ID = "ITEM_SUB_CAT_FORM";
	public final static String ITEMSUBCAT_ITMTYPE_ID = "ITEM_SUB_CAT_ITYPE";
	public final static String ITEMSUBCAT_ITMCAT_ID = "ITEM_SUB_CAT_ICAT";
	public final static String ITEMSUBCATNAME_ID = "ITEM_SUB_CAT_NAME";
	public final static String ITEMSUBCATCODE_ID = "ITEM_SUB_CAT_CODE";
	public final static String ITEMSUBCATSEARCHBTN_ID = "ITEM_SUB_CAT_SEARCH";
	public final static String ITEMSUBCATRESETBTN_ID = "ITEM_SUB_CAT_RESET";
	public final static String ITEMSUBCATGRIDDIV_ID = "ITEM_SUB_CAT_GRID_DIV";
	public final static String ITEMSUBCATGRID_ID = "ITEM_SUB_CAT_GRID";
	public final static String ITEMSUBCATSUBMITBTN_ID = "ITEM_SUB_CAT_SUBMIT";
	public final static String ITEMSUBCATCANCELBTN_ID = "ITEM_SUB_CAT_CANCEL";
	public final static String ITEMINCLUDE_NAME = "include";
	public final static String ITEMPATDISCTYPE_NAME = "type";
	public final static String ITEMPATDISCVALUE_NAME = "value";

	public final static String APPLYEXCLISTTOCHKBOX_ID = "Apply_Exclusion_List_To";
	public final static String APPLYEXCLISTTOPOLICYCHKBOX_ID = "Apply_Exclusion_List_To_AGMNT";
	public final static String APPLYEXCLISTTOCLASSCHKBOX_ID = "Apply_the_Above_Exclusion_List_To";
	public final static String AGRMNTSMULTISELECT_NAME = "multiselect_ASSO_EXCLUSION_LIST";
	public final static String POLICYMULTISELECT_NAME = "multiselect_ASSO_POLICY_LIST";
	public final static String CLASSMULTISELECT_NAME = "multiselect_POLICY_APPL_TO_CLASSES_EX";

	private final static String SERVICE = "Service",
			SERVICE_TYPE = "Service Type",
			SERVICE_SPECIALTY = "Service Specialty",
			SERVICE_SUB_SPECIALTY = "Service Sub Specialty", ITEM = "Item",
			ITEM_TYPE = "Item Type", ITEM_CATEGORY = "Item Category",
			ITEM_SUB_CATEGORY = "Item Sub Category",
			SELECTED_AGRMNTS = "Selected Agreements",
			SELECTED_POL = "Selected Policies",
			SELECTED_CLS = "Selected Classes";

	@FindBy(linkText = EXCLISTDETAILSSEC_LINKTXT)
	private WebElement excListDetailsSec;

	@FindBy(id = SERVDEFPATTERN_ID)
	private WebElement servDefPattern;

	@FindBy(id = ICDDEFPATTERN_ID)
	private WebElement icdDefPattern;

	@FindBy(id = ITEMDEFPATTERN_ID)
	private WebElement itemDefPattern;

	@FindBy(id = SERVEXCGRIDDIV_ID)
	private WebElement servExcGridDiv;

	@FindBy(id = ICDEXCGRIDDIV_ID)
	private WebElement icdExcGridDiv;

	@FindBy(id = ITEMEXCGRIDDIV_ID)
	private WebElement itemExcGridDiv;

	@FindBy(xpath = SERVADDROWBTN_XPATH)
	private WebElement addServiceBtn;

	@FindBy(xpath = ICDADDROWBTN_XPATH)
	private WebElement addIcdBtn;

	@FindBy(xpath = ITEMADDROWBTN_XPATH)
	private WebElement addItemBtn;

	@FindBy(name = SERVLVLLIST_NAME)
	private WebElement serviceLvlList;

	@FindBy(name = SERVLVLNAME_NAME)
	private WebElement serviceLvlName;

	@FindBy(id = GRIDSEARCHLOOKUP_ID)
	private WebElement gridSearchLookup;

	@FindBy(id = SERVLVLFORM_ID)
	private WebElement servicePopup;

	@FindBy(id = SERVLVLDEPT_ID)
	private WebElement department;

	@FindBy(id = SERVLVLSPLTY_ID)
	private WebElement serviceSpecialty;

	@FindBy(id = SERVLVLSUBSPLTY_ID)
	private WebElement serviceSubSpecialty;

	@FindBy(id = SERVLVLTYPE_ID)
	private WebElement serviceType;

	@FindBy(id = SERVLVLCODE_ID)
	private WebElement serviceCode;

	@FindBy(id = SERVNAME_ID)
	private WebElement serviceName;

	@FindBy(id = SERVLVLSEARCH_ID)
	private WebElement serviceSearchBtn;

	@FindBy(id = SERVLVLRESET_ID)
	private WebElement serviceResetBtn;

	@FindBy(id = SERVLVLGRIDDIV_ID)
	private WebElement serviceGridDiv;

	@FindBy(id = SERVLVLGRIDTBL_ID)
	private WebElement serviceGridTbl;

	@FindBy(id = SERVLVLSUBMITBTN_ID)
	private WebElement serviceSubmitBtn;

	@FindBy(id = SERVLVLCANCEL_ID)
	private WebElement serviceCancelBtn;

	@FindBy(id = SERVTYPEFORM_ID)
	private WebElement serviceTypeForm;

	@FindBy(id = SERVTYPENAME_ID)
	private WebElement serviceTypeName;

	@FindBy(id = SERVTYPECODE_ID)
	private WebElement serviceTypeCode;

	@FindBy(id = SERVTYPESEARCHBTN_ID)
	private WebElement serviceTypeSearchBtn;

	@FindBy(id = SERVTYPERESETBTN_ID)
	private WebElement serviceTypeResetBtn;

	@FindBy(id = SERVTYPEGRIDDIV_ID)
	private WebElement serviceTypeGridDiv;

	@FindBy(id = SERVTYPESUBMITBTN_ID)
	private WebElement serviceTypeSubmitBtn;

	@FindBy(id = SERVTYPECANCELBTN_ID)
	private WebElement serviceTypeCancelBtn;

	@FindBy(id = SERVSPLTYFORM_ID)
	private WebElement serviceSpltyForm;

	@FindBy(id = SERVSPLTYDEPT_ID)
	private WebElement serviceSpltyDept;

	@FindBy(id = SERVSPLTYNAME_ID)
	private WebElement serviceSpltyName;

	@FindBy(id = SERVSPLTYCODE_ID)
	private WebElement serviceSpltyCode;

	@FindBy(id = SERVSPLTYSEARCHBTN_ID)
	private WebElement serviceSpltySearchBtn;

	@FindBy(id = SERVSPLTYRESETBTN_ID)
	private WebElement serviceSpltyResetBtn;

	@FindBy(id = SERVSPLTYGRIDDIV_ID)
	private WebElement serviceSpltyGridDiv;

	@FindBy(id = SERVSPLTYSUBMITBTN_ID)
	private WebElement serviceSpltySubmitBtn;

	@FindBy(id = SERVSPLTYCANCEL_ID)
	private WebElement serviceSpltyCancelBtn;

	@FindBy(id = SERVSUBSPLTYFORM_ID)
	private WebElement serviceSubSpltyForm;

	@FindBy(id = SERVSUBSPLTYDEPT_ID)
	private WebElement serviceSubSpltyDept;

	@FindBy(id = SERVSUBSPLTY_SERVSPLTY_ID)
	private WebElement serviceSubSplty_ServSplty;

	@FindBy(id = SERVSUBSPLTYNAME_ID)
	private WebElement serviceSubSpltyName;

	@FindBy(id = SERVSUBSPLTYCODE_ID)
	private WebElement serviceSubSpltyCode;

	@FindBy(id = SERVSUBSPLTYSEARCHBTN_ID)
	private WebElement serviceSubSpltySearchBtn;

	@FindBy(id = SERVSUBSPLTYRESETBTN_ID)
	private WebElement serviceSubSpltyResetBtn;

	@FindBy(id = SERVSUBSPLTYGRIDDIV_ID)
	private WebElement serviceSubSpltyGridDiv;

	@FindBy(id = SERVSUBSPLTYSUBMITBTN_ID)
	private WebElement serviceSubSpltySubmitBtn;

	@FindBy(id = SERVSUBSPLTYCANCELBTN_ID)
	private WebElement serviceSubSpltyCancelBtn;

	@FindBy(name = INCLUDESERV_NAME)
	private WebElement includeService;

	@FindBy(xpath = SERVISITCATEG_XPATH)
	private WebElement serVisitCategory;

	@FindBy(xpath = ICDVISITCATEG_XPATH)
	private WebElement icdVisitCategory;

	@FindBy(xpath = ITVISITCATEG_XPATH)
	private WebElement itmVisitCategory;

	@FindBy(name = SERVPATDISCTYPE_NAME)
	private WebElement servPatDiscType;

	@FindBy(name = SERVPATDISCVALUE_NAME)
	private WebElement servPatDiscValue;

	@FindBy(xpath = SERVEXCDELLINK_XPATH)
	private WebElement servExcDelLink;

	@FindBy(xpath = ICDPTRNDESC_XPATH)
	private WebElement icdPatternDesc;

	@FindBy(id = ICDLOOKUPDIV_ID)
	private WebElement icdLookUp;

	@FindBy(id = ICDCODE_ID)
	private WebElement icdCode;

	@FindBy(id = ICDDESC_ID)
	private WebElement icdDesc;

	@FindBy(id = ICDSEARCHBTN_ID)
	private WebElement icdSearchBtn;

	@FindBy(id = ICDRESETBTN_ID)
	private WebElement icdResetBtn;

	@FindBy(id = ICDGRIDDIV_ID)
	private WebElement icdGridDiv;

	@FindBy(id = ICDSUBMITBTN_ID)
	private WebElement icdSubmitBtn;

	@FindBy(id = ICDCANCELBTN_ID)
	private WebElement icdCancelBtn;

	@FindBy(name = INCLUDEICD_NAME)
	private WebElement includeIcd;

	@FindBy(name = ICDPATDISCTYPE_NAME)
	private WebElement icdPatDiscType;

	@FindBy(name = ICDPATDISCVALUE_NAME)
	private WebElement icdPatDiscValue;

	@FindBy(name = ITEMLVLLIST_NAME)
	private WebElement itemLevel;

	@FindBy(id = ITEMLOOKUP_ID)
	private WebElement itemLookup;

	@FindBy(name = ITEMTYPE_NAME)
	private WebElement itemType;

	@FindBy(name = ITEMCATEGORY_NAME)
	private WebElement itemCategory;

	@FindBy(name = ITEMSUBCATEGORY_NAME)
	private WebElement itemSubCategory;

	@FindBy(name = ITEMCODE_NAME)
	private WebElement itemCode;

	@FindBy(name = ITEMNAME_NAME)
	private WebElement itemName;

	@FindBy(id = ITEMLVLSEARCH_ID)
	private WebElement itemSearchBtn;

	@FindBy(id = ITEMLVLRESET_ID)
	private WebElement itemResetBtn;

	@FindBy(id = ITEMLVLGRIDDIV_ID)
	private WebElement itemGridDiv;

	@FindBy(id = ITEMLVLSUBMITBTN_ID)
	private WebElement itemSubmitBtn;

	@FindBy(id = ITEMLVLCANCELBTN_ID)
	private WebElement itemCancelBtn;

	@FindBy(id = ITEMTYPEFORM_ID)
	private WebElement itemTypeForm;

	@FindBy(id = ITEMTYPENAME_ID)
	private WebElement itemTypeName;

	@FindBy(id = ITEMTYPECODE_ID)
	private WebElement itemTypeCode;

	@FindBy(id = ITEMTYPESEARCHBTN_ID)
	private WebElement itemTypeSearchBtn;

	@FindBy(id = ITEMTYPERESETBTN_ID)
	private WebElement itemTypeResetBtn;

	@FindBy(id = ITEMTYPEGRIDDIV_ID)
	private WebElement itemTypeGridDiv;

	@FindBy(id = ITEMTYPESUBMITBTN_ID)
	private WebElement itemTypeSubmitBtn;

	@FindBy(id = ITEMTYPECANCELBTN_ID)
	private WebElement itemTypeCancelBtn;

	@FindBy(id = ITEMCATEGORYFORM_ID)
	private WebElement itemCategoryForm;

	@FindBy(id = ITEMCAT_ITEMTYPE_ID)
	private WebElement itemCat_itemType;

	@FindBy(id = ITEMCATNAME_ID)
	private WebElement itemCatName;

	@FindBy(id = ITEMCATCODE_ID)
	private WebElement itemCatCode;

	@FindBy(id = ITEMCATSEARCHBTN_ID)
	private WebElement itemCatSearchBtn;

	@FindBy(id = ITEMCATRESETBTN_ID)
	private WebElement itemCatResetBtn;

	@FindBy(id = ITEMCATGRIDDIV_ID)
	private WebElement itemCatGridDiv;

	@FindBy(id = ITEMCATSUBMITBTN_ID)
	private WebElement itemCatSubmitBtn;

	@FindBy(id = ITEMCATCANCELBTN_ID)
	private WebElement itemCatCancelBtn;

	@FindBy(id = ITEMSUBCATFORM_ID)
	private WebElement itemSubCatForm;

	@FindBy(id = ITEMSUBCAT_ITMTYPE_ID)
	private WebElement itemSubCat_itmType;

	@FindBy(id = ITEMSUBCAT_ITMCAT_ID)
	private WebElement itemSubCat_itmCategory;

	@FindBy(id = ITEMSUBCATNAME_ID)
	private WebElement itemSubCatName;

	@FindBy(id = ITEMSUBCATCODE_ID)
	private WebElement itemSubCatCode;

	@FindBy(id = ITEMSUBCATSEARCHBTN_ID)
	private WebElement itemSubCatSearchBtn;

	@FindBy(id = ITEMSUBCATRESETBTN_ID)
	private WebElement itemSubCatResetBtn;

	@FindBy(id = ITEMSUBCATGRIDDIV_ID)
	private WebElement itemSubCatGridDiv;

	@FindBy(id = ITEMSUBCATSUBMITBTN_ID)
	private WebElement itemSubCatSubmitBtn;

	@FindBy(id = ITEMSUBCATCANCELBTN_ID)
	private WebElement itemSubCatCancelBtn;

	@FindBy(name = ITEMINCLUDE_NAME)
	private WebElement includeItem;

	@FindBy(name = ITEMPATDISCTYPE_NAME)
	private WebElement itemPatDiscType;

	@FindBy(name = ITEMPATDISCVALUE_NAME)
	private WebElement itemPatDiscValue;

	@FindBy(id = APPLYEXCLISTTOCHKBOX_ID)
	private WebElement applyExcListToChkBox;

	@FindBy(id = APPLYEXCLISTTOPOLICYCHKBOX_ID)
	private WebElement applyExcListToPolicyChkBox;

	@FindBy(id = APPLYEXCLISTTOCLASSCHKBOX_ID)
	private WebElement applyExcListToClassChkBox;

	@FindBy(name = AGRMNTSMULTISELECT_NAME)
	private WebElement agrmntsMultiselectChkBox;

	@FindBy(name = POLICYMULTISELECT_NAME)
	private WebElement policyMultiselectChkBox;

	@FindBy(name = CLASSMULTISELECT_NAME)
	private WebElement classMultiselectChkBox;

	public void addServiceExclusionData(String[] serviceExclusionListData)
			throws Exception {
		servDefPattern.click();
		sleepVeryShort();
		waitForElementId(SERVEXCGRIDDIV_ID);
		addServiceBtn.click();
		sleepVeryShort();
		new Select(serviceLvlList)
				.selectByVisibleText(serviceExclusionListData[1]);
		gridSearchLookup.click();
		sleepShort();
		selectServiceLevelName(serviceExclusionListData);
		sleepMedium();
		selectVisitCategory(serVisitCategory,
				"multiselect_new_service_excn_1_visitCategory",
				serviceExclusionListData[18]);

		if (SERVICE.equals(serviceExclusionListData[1])) {
			if (Boolean.valueOf(serviceExclusionListData[17])) {
				includeService.click();
			} else {
				new Select(servPatDiscType)
						.selectByVisibleText(serviceExclusionListData[19]);
				servPatDiscValue.clear();
				servPatDiscValue.sendKeys(serviceExclusionListData[20]);
			}
		} else {
			new Select(servPatDiscType)
					.selectByVisibleText(serviceExclusionListData[19]);
			servPatDiscValue.clear();
			servPatDiscValue.sendKeys(serviceExclusionListData[20]);

		}

	}

	public void addICDExclusionData(String[] icdExclusionListData)
			throws Exception {
		icdDefPattern.click();
		sleepVeryShort();
		waitForElementId(ICDEXCGRIDDIV_ID);
		addIcdBtn.click();
		sleepVeryShort();
		gridSearchLookup.click();
		sleepShort();
		waitForElementId(ICDLOOKUPDIV_ID);
		icdCode.clear();
		icdCode.sendKeys(icdExclusionListData[1]);
		icdDesc.clear();
		icdDesc.sendKeys(icdExclusionListData[2]);
		icdSearchBtn.click();
		clickOnCheckBoxGridItem(ICDGRID_ID, icdExclusionListData[2].trim());
		icdSubmitBtn.click();
		sleepMedium();
		selectVisitCategory(icdVisitCategory,
				"multiselect_new_icd_row1_visitCategory",
				icdExclusionListData[3]);

		if (Boolean.valueOf(icdExclusionListData[4])) {
			includeIcd.click();
		} else {
			new Select(icdPatDiscType)
					.selectByVisibleText(icdExclusionListData[5]);
			icdPatDiscValue.clear();
			icdPatDiscValue.sendKeys(icdExclusionListData[6]);
		}

	}

	public void addItemExclusionData(String[] itemExclusionListData)
			throws Exception {
		itemDefPattern.click();
		sleepVeryShort();
		waitForElementId(ITEMEXCGRIDDIV_ID);
		addItemBtn.click();
		sleepVeryShort();
		new Select(itemLevel).selectByVisibleText(itemExclusionListData[1]);
		gridSearchLookup.click();
		sleepShort();
		selectItemLevelName(itemExclusionListData);
		sleepMedium();
		selectVisitCategory(itmVisitCategory,
				"multiselect_new_item_excn_1_visitCategory",
				itemExclusionListData[17]);
		if (ITEM.equals(itemExclusionListData[1])) {
			if (Boolean.valueOf(itemExclusionListData[16])) {
				includeItem.click();
			} else {
				new Select(itemPatDiscType)
						.selectByVisibleText(itemExclusionListData[18]);
				itemPatDiscValue.clear();
				itemPatDiscValue.sendKeys(itemExclusionListData[19]);
			}
		} else {
			new Select(servPatDiscType)
					.selectByVisibleText(itemExclusionListData[18]);
			itemPatDiscValue.clear();
			itemPatDiscValue.sendKeys(itemExclusionListData[19]);

		}

	}

	private void selectItemLevelName(String[] itemExclusionListData)
			throws Exception {
		if (ITEM.equals(itemExclusionListData[1])) {
			waitForElementId(ITEMLOOKUP_ID);
			if (!itemExclusionListData[2].isEmpty()) {
				new Select(itemType)
						.selectByVisibleText(itemExclusionListData[2]);
			}
			if (!itemExclusionListData[3].isEmpty()) {
				new Select(itemCategory)
						.selectByVisibleText(itemExclusionListData[3]);
			}
			waitForElementName(ITEMSUBCATEGORY_NAME);
			sleepVeryShort();
			if (!itemExclusionListData[4].isEmpty()) {
				new Select(itemSubCategory)
						.selectByVisibleText(itemExclusionListData[4]);
			}

			itemCode.clear();
			itemCode.sendKeys(itemExclusionListData[5]);

			itemName.clear();
			itemName.sendKeys(itemExclusionListData[6]);
			itemSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMLVLGRID_ID,
					itemExclusionListData[6].trim());
			itemSubmitBtn.click();

		} else if (ITEM_TYPE.equals(itemExclusionListData[1])) {
			waitForElementId(ITEMTYPEFORM_ID);
			itemTypeName.clear();
			itemTypeName.sendKeys(itemExclusionListData[7]);

			itemTypeCode.clear();
			itemTypeCode.sendKeys(itemExclusionListData[8]);
			itemTypeSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMTYPEGRID_ID,
					itemExclusionListData[8].trim());
			itemTypeSubmitBtn.click();

		} else if (ITEM_CATEGORY.equals(itemExclusionListData[1])) {
			waitForElementId(ITEMCATEGORYFORM_ID);
			if (!itemExclusionListData[9].isEmpty()) {
				new Select(itemCat_itemType)
						.selectByVisibleText(itemExclusionListData[9]);
			}
			itemCatName.clear();
			itemCatName.sendKeys(itemExclusionListData[10]);
			itemCatCode.clear();
			itemCatCode.sendKeys(itemExclusionListData[11]);
			itemCatSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMCATGRID_ID,
					itemExclusionListData[10].trim());
			itemCatSubmitBtn.click();

		} else if (ITEM_SUB_CATEGORY.equals(itemExclusionListData[1])) {
			waitForElementId(ITEMSUBCATFORM_ID);
			if (!itemExclusionListData[13].isEmpty()) {
				new Select(itemSubCat_itmType)
						.selectByVisibleText(itemExclusionListData[12]);
			}
			if (!itemExclusionListData[13].isEmpty()) {
				new Select(itemSubCat_itmCategory)
						.selectByVisibleText(itemExclusionListData[13]);
			}
			itemSubCatName.clear();
			itemSubCatName.sendKeys(itemExclusionListData[14]);

			itemSubCatCode.clear();
			itemSubCatCode.sendKeys(itemExclusionListData[15]);
			itemSubCatSearchBtn.click();
			clickOnCheckBoxGridItem(ITEMSUBCATGRID_ID,
					itemExclusionListData[14].trim());
			itemSubCatSubmitBtn.click();

		}

	}

	private void selectServiceLevelName(String[] serviceExclusionListData)
			throws Exception {
		if (SERVICE.equals(serviceExclusionListData[1])) {
			waitForElementId(SERVLVLFORM_ID);
			waitForElementId(SERVLVLDEPT_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[2].isEmpty()) {
				new Select(department)
						.selectByVisibleText(serviceExclusionListData[2]);
			}
			waitForElementId(SERVLVLSPLTY_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[3].isEmpty()) {
				new Select(serviceSpecialty)
						.selectByVisibleText(serviceExclusionListData[3]);
			}
			waitForElementId(SERVLVLSUBSPLTY_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[4].isEmpty()) {
				new Select(serviceSubSpecialty)
						.selectByVisibleText(serviceExclusionListData[4]);
			}
			waitForElementId(SERVLVLTYPE_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[5].isEmpty()) {
				new Select(serviceType)
						.selectByVisibleText(serviceExclusionListData[5]);
			}
			waitForElementId(SERVLVLCODE_ID);
			sleepVeryShort();
			serviceCode.clear();
			serviceCode.sendKeys(serviceExclusionListData[6]);
			waitForElementId(SERVNAME_ID);
			sleepVeryShort();
			serviceName.clear();
			serviceName.sendKeys(serviceExclusionListData[7]);
			serviceSearchBtn.click();
			clickOnCheckBoxGridItem(SERVLVLGRIDTBL_ID,
					serviceExclusionListData[7].trim());
			serviceSubmitBtn.click();

		} else if (SERVICE_TYPE.equals(serviceExclusionListData[1])) {
			waitForElementId(SERVTYPEFORM_ID);
			sleepVeryShort();
			serviceTypeName.clear();
			serviceTypeName.sendKeys(serviceExclusionListData[8]);

			serviceTypeCode.clear();
			serviceTypeCode.sendKeys(serviceExclusionListData[9]);
			serviceTypeSearchBtn.click();
			clickOnCheckBoxGridItem(SERVTYPEGRID_ID,
					serviceExclusionListData[8].trim());
			serviceTypeSubmitBtn.click();

		} else if (SERVICE_SPECIALTY.equals(serviceExclusionListData[1])) {
			waitForElementId(SERVSPLTYFORM_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[10].isEmpty()) {
				new Select(serviceSpltyDept)
						.selectByVisibleText(serviceExclusionListData[10]);
			}
			serviceSpltyName.clear();
			serviceSpltyName.sendKeys(serviceExclusionListData[11]);
			serviceSpltyCode.clear();
			serviceSpltyCode.sendKeys(serviceExclusionListData[12]);
			serviceSpltySearchBtn.click();
			clickOnCheckBoxGridItem(SERVSPLTYGRID_ID,
					serviceExclusionListData[11].trim());
			serviceSpltySubmitBtn.click();

		} else if (SERVICE_SUB_SPECIALTY.equals(serviceExclusionListData[1])) {
			waitForElementId(SERVSUBSPLTYFORM_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[13].isEmpty()) {
				new Select(serviceSubSpltyDept)
						.selectByVisibleText(serviceExclusionListData[13]);
			}
			waitForElementId(SERVSUBSPLTY_SERVSPLTY_ID);
			sleepVeryShort();
			if (!serviceExclusionListData[14].isEmpty()) {
				new Select(serviceSubSplty_ServSplty)
						.selectByVisibleText(serviceExclusionListData[14]);
			}
			waitForElementId(SERVSUBSPLTYNAME_ID);
			serviceSubSpltyName.clear();
			serviceSubSpltyName.sendKeys(serviceExclusionListData[15]);

			waitForElementId(SERVSUBSPLTYCODE_ID);
			serviceSubSpltyCode.clear();
			serviceSubSpltyCode.sendKeys(serviceExclusionListData[16]);
			serviceSubSpltySearchBtn.click();
			clickOnCheckBoxGridItem(SERVSUBSPLTYGRID_ID,
					serviceExclusionListData[15].trim());
			serviceSubSpltySubmitBtn.click();

		}

	}

	public void applyExcListToAgrmnts(String[] debtorListData) throws Exception {
		applyExcListToChkBox.click();
		sleepShort();
		selectRadioButtonAsLabelText(debtorListData[37]);
		if (SELECTED_AGRMNTS.equals(debtorListData[37])) {
			String[] temp;
			String delimiter = "\\,";
			temp = debtorListData[38].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				String xpath = "//input[@name='" + AGRMNTSMULTISELECT_NAME
						+ "' and @title='" + temp[i] + "']";
				waitForElementXpathExpression(xpath);
				sleepVeryShort();
				webDriver.findElement(By.xpath(xpath)).click();
			}
		}
	}

	public void applyExcListToPolicies(String[] policyListData)
			throws Exception {
		applyExcListToPolicyChkBox.click();
		sleepShort();
		selectRadioButtonAsLabelText(policyListData[73]);
		if (SELECTED_POL.equals(policyListData[73])) {
			String[] temp;
			String delimiter = "\\,";
			temp = policyListData[74].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				webDriver.findElement(
						By.xpath("//input[@name='" + POLICYMULTISELECT_NAME
								+ "' and @title='" + temp[i] + "']")).click();
			}
		}

	}

	public void applyExcListToClasses(String[] classListData) throws Exception {
		applyExcListToClassChkBox.click();
		sleepShort();
		selectRadioButtonAsLabelText(classListData[40]);
		if (SELECTED_CLS.equals(classListData[40])) {
			String[] temp;
			String delimiter = "\\,";
			temp = classListData[41].split(delimiter);
			for (int i = 0; i < temp.length; i++) {
				webDriver.findElement(
						By.xpath("//input[@name='" + CLASSMULTISELECT_NAME
								+ "' and @title='" + temp[i] + "']")).click();
			}
		}
	}

	private void selectVisitCategory(WebElement catBtn, String name,
			String visitCat) throws Exception {
		sleepShort();
		catBtn.click();
		String[] temp;
		String delimiter = "\\,";
		temp = visitCat.split(delimiter);
		for (int i = 0; i < temp.length; i++) {
			webDriver.findElement(
					By.xpath("//input[@name='" + name + "' and @title='"
							+ temp[i] + "']")).click();
		}
	}

	public String checkItemLevelData(String[] itemExclusionListData) {
		return new Select(itemLevel).getFirstSelectedOption().getText();
	}

	public void clickExcListRecord(String[] servExcListData) throws Exception {
		waitForElementXpathExpression(".//td[@aria-describedby='SERV_GRID_serviceLevelName' and @title='"
				+ servExcListData[7] + "']");
		webDriver
				.findElement(
						By.xpath(".//td[@aria-describedby='SERV_GRID_serviceLevelName' and @title='"
								+ servExcListData[7] + "']")).click();
		sleepShort();

	}

	public boolean checkExcGrid(String[] serviceExclusionListData)
			throws Exception {
		try {
			String servName = "//td[@aria-describedby='SERV_GRID_serviceLevelName' and @title='"
					+ serviceExclusionListData[7] + "']";
			waitForElementXpathExpression(servName);
			sleepVeryShort();
			boolean res = webDriver.findElement(By.xpath(servName))
					.isDisplayed();
			return res;

		} catch (Exception e) {
			return false;
		}

	}

	public WebElement getExcListDetailsSec() {
		return excListDetailsSec;
	}

	public WebElement getServDefPattern() {
		return servDefPattern;
	}

	public WebElement getIcdDefPattern() {
		return icdDefPattern;
	}

	public WebElement getItemDefPattern() {
		return itemDefPattern;
	}

	public WebElement getServExcGridDiv() {
		return servExcGridDiv;
	}

	public WebElement getIcdExcGridDiv() {
		return icdExcGridDiv;
	}

	public WebElement getItemExcGridDiv() {
		return itemExcGridDiv;
	}

	public WebElement getAddServiceBtn() {
		return addServiceBtn;
	}

	public WebElement getAddIcdBtn() {
		return addIcdBtn;
	}

	public WebElement getAddItemBtn() {
		return addItemBtn;
	}

	public WebElement getServiceLvlList() {
		return serviceLvlList;
	}

	public WebElement getServiceLvlName() {
		return serviceLvlName;
	}

	public WebElement getGridSearchLookup() {
		return gridSearchLookup;
	}

	public WebElement getServicePopup() {
		return servicePopup;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getServiceSpecialty() {
		return serviceSpecialty;
	}

	public WebElement getServiceSubSpecialty() {
		return serviceSubSpecialty;
	}

	public WebElement getServiceType() {
		return serviceType;
	}

	public WebElement getServiceCode() {
		return serviceCode;
	}

	public WebElement getServiceName() {
		return serviceName;
	}

	public WebElement getServiceSearchBtn() {
		return serviceSearchBtn;
	}

	public WebElement getServiceResetBtn() {
		return serviceResetBtn;
	}

	public WebElement getServiceGridDiv() {
		return serviceGridDiv;
	}

	public WebElement getServiceGridTbl() {
		return serviceGridTbl;
	}

	public WebElement getServiceSubmitBtn() {
		return serviceSubmitBtn;
	}

	public WebElement getServiceCancelBtn() {
		return serviceCancelBtn;
	}

	public WebElement getIncludeService() {
		return includeService;
	}

	public WebElement getSerVisitCategory() {
		return serVisitCategory;
	}

	public WebElement getIcdVisitCategory() {
		return icdVisitCategory;
	}

	public WebElement getItmVisitCategory() {
		return itmVisitCategory;
	}

	public WebElement getServPatDiscType() {
		return servPatDiscType;
	}

	public WebElement getServPatDiscValue() {
		return servPatDiscValue;
	}

	public WebElement getServExcDelLink() {
		return servExcDelLink;
	}

	public WebElement getIcdPatternDesc() {
		return icdPatternDesc;
	}

	public WebElement getIcdLookUp() {
		return icdLookUp;
	}

	public WebElement getIcdCode() {
		return icdCode;
	}

	public WebElement getIcdDesc() {
		return icdDesc;
	}

	public WebElement getIcdSearchBtn() {
		return icdSearchBtn;
	}

	public WebElement getIcdResetBtn() {
		return icdResetBtn;
	}

	public WebElement getIcdGridDiv() {
		return icdGridDiv;
	}

	public WebElement getIcdSubmitBtn() {
		return icdSubmitBtn;
	}

	public WebElement getIcdCancelBtn() {
		return icdCancelBtn;
	}

	public WebElement getIncludeIcd() {
		return includeIcd;
	}

	public WebElement getIcdPatDiscType() {
		return icdPatDiscType;
	}

	public WebElement getIcdPatDiscValue() {
		return icdPatDiscValue;
	}

	public WebElement getItemLevel() {
		return itemLevel;
	}

	public WebElement getItemLookup() {
		return itemLookup;
	}

	public WebElement getItemType() {
		return itemType;
	}

	public WebElement getItemCategory() {
		return itemCategory;
	}

	public WebElement getItemSubCategory() {
		return itemSubCategory;
	}

	public WebElement getItemCode() {
		return itemCode;
	}

	public WebElement getItemName() {
		return itemName;
	}

	public WebElement getItemSearchBtn() {
		return itemSearchBtn;
	}

	public WebElement getItemResetBtn() {
		return itemResetBtn;
	}

	public WebElement getItemGridDiv() {
		return itemGridDiv;
	}

	public WebElement getItemSubmitBtn() {
		return itemSubmitBtn;
	}

	public WebElement getItemCancelBtn() {
		return itemCancelBtn;
	}

	public WebElement getIncludeItem() {
		return includeItem;
	}

	public WebElement getItemPatDiscType() {
		return itemPatDiscType;
	}

	public WebElement getItemPatDiscValue() {
		return itemPatDiscValue;
	}

	public WebElement getServiceTypeForm() {
		return serviceTypeForm;
	}

	public WebElement getServiceTypeName() {
		return serviceTypeName;
	}

	public WebElement getServiceTypeCode() {
		return serviceTypeCode;
	}

	public WebElement getServiceTypeSearchBtn() {
		return serviceTypeSearchBtn;
	}

	public WebElement getServiceTypeResetBtn() {
		return serviceTypeResetBtn;
	}

	public WebElement getServiceTypeGridDiv() {
		return serviceTypeGridDiv;
	}

	public WebElement getServiceTypeSubmitBtn() {
		return serviceTypeSubmitBtn;
	}

	public WebElement getServiceTypeCancelBtn() {
		return serviceTypeCancelBtn;
	}

	public WebElement getServiceSpltyForm() {
		return serviceSpltyForm;
	}

	public WebElement getServiceSpltyDept() {
		return serviceSpltyDept;
	}

	public WebElement getServiceSpltyName() {
		return serviceSpltyName;
	}

	public WebElement getServiceSpltyCode() {
		return serviceSpltyCode;
	}

	public WebElement getServiceSpltySearchBtn() {
		return serviceSpltySearchBtn;
	}

	public WebElement getServiceSpltyResetBtn() {
		return serviceSpltyResetBtn;
	}

	public WebElement getServiceSpltyGridDiv() {
		return serviceSpltyGridDiv;
	}

	public WebElement getServiceSpltySubmitBtn() {
		return serviceSpltySubmitBtn;
	}

	public WebElement getServiceSpltyCancelBtn() {
		return serviceSpltyCancelBtn;
	}

	public WebElement getServiceSubSpltyForm() {
		return serviceSubSpltyForm;
	}

	public WebElement getServiceSubSpltyDept() {
		return serviceSubSpltyDept;
	}

	public WebElement getServiceSubSplty_ServSplty() {
		return serviceSubSplty_ServSplty;
	}

	public WebElement getServiceSubSpltyName() {
		return serviceSubSpltyName;
	}

	public WebElement getServiceSubSpltyCode() {
		return serviceSubSpltyCode;
	}

	public WebElement getServiceSubSpltySearchBtn() {
		return serviceSubSpltySearchBtn;
	}

	public WebElement getServiceSubSpltyResetBtn() {
		return serviceSubSpltyResetBtn;
	}

	public WebElement getServiceSubSpltyGridDiv() {
		return serviceSubSpltyGridDiv;
	}

	public WebElement getServiceSubSpltySubmitBtn() {
		return serviceSubSpltySubmitBtn;
	}

	public WebElement getServiceSubSpltyCancelBtn() {
		return serviceSubSpltyCancelBtn;
	}

	public WebElement getItemTypeForm() {
		return itemTypeForm;
	}

	public WebElement getItemTypeName() {
		return itemTypeName;
	}

	public WebElement getItemTypeCode() {
		return itemTypeCode;
	}

	public WebElement getItemTypeSearchBtn() {
		return itemTypeSearchBtn;
	}

	public WebElement getItemTypeResetBtn() {
		return itemTypeResetBtn;
	}

	public WebElement getItemTypeGridDiv() {
		return itemTypeGridDiv;
	}

	public WebElement getItemTypeSubmitBtn() {
		return itemTypeSubmitBtn;
	}

	public WebElement getItemTypeCancelBtn() {
		return itemTypeCancelBtn;
	}

	public WebElement getItemCategoryForm() {
		return itemCategoryForm;
	}

	public WebElement getItemCat_itemType() {
		return itemCat_itemType;
	}

	public WebElement getItemCatName() {
		return itemCatName;
	}

	public WebElement getItemCatCode() {
		return itemCatCode;
	}

	public WebElement getItemCatSearchBtn() {
		return itemCatSearchBtn;
	}

	public WebElement getItemCatResetBtn() {
		return itemCatResetBtn;
	}

	public WebElement getItemCatGridDiv() {
		return itemCatGridDiv;
	}

	public WebElement getItemCatSubmitBtn() {
		return itemCatSubmitBtn;
	}

	public WebElement getItemCatCancelBtn() {
		return itemCatCancelBtn;
	}

	public WebElement getItemSubCatForm() {
		return itemSubCatForm;
	}

	public WebElement getItemSubCat_itmType() {
		return itemSubCat_itmType;
	}

	public WebElement getItemSubCat_itmCategory() {
		return itemSubCat_itmCategory;
	}

	public WebElement getItemSubCatName() {
		return itemSubCatName;
	}

	public WebElement getItemSubCatCode() {
		return itemSubCatCode;
	}

	public WebElement getItemSubCatSearchBtn() {
		return itemSubCatSearchBtn;
	}

	public WebElement getItemSubCatResetBtn() {
		return itemSubCatResetBtn;
	}

	public WebElement getItemSubCatGridDiv() {
		return itemSubCatGridDiv;
	}

	public WebElement getItemSubCatSubmitBtn() {
		return itemSubCatSubmitBtn;
	}

	public WebElement getItemSubCatCancelBtn() {
		return itemSubCatCancelBtn;
	}

	public WebElement getApplyExcListToChkBox() {
		return applyExcListToChkBox;
	}

	public WebElement getApplyExcListToPolicyChkBox() {
		return applyExcListToPolicyChkBox;
	}

	public WebElement getApplyExcListToClassChkBox() {
		return applyExcListToClassChkBox;
	}

	public WebElement getPolicyMultiselectChkBox() {
		return policyMultiselectChkBox;
	}

	public WebElement getClassMultiselectChkBox() {
		return classMultiselectChkBox;
	}

	public WebElement getAgrmntsMultiselectChkBox() {
		return agrmntsMultiselectChkBox;
	}

}
