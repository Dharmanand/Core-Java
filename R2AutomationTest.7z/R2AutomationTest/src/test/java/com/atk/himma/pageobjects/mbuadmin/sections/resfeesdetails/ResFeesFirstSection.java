package com.atk.himma.pageobjects.mbuadmin.sections.resfeesdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ResFeesFirstSection extends DriverWaitClass{
	
	public final static String MBU_NAME = "employeeResource.mbuName";
	public final static String DEPARTMENT_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div/div[2]/div/div/div/form/div[3]/table/tbody/tr/td/fieldset/span[2]/input";
	public final static String RESCATEGORY_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div/div[2]/div/div/div/form/div[3]/table/tbody/tr/td/fieldset/input[4]";
	public final static String RESTYPE_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div/div[2]/div/div/div/form/div[3]/table/tbody/tr/td/fieldset/input[5]";
	public final static String RESCODE_ID = "RESOURCE_CODE";
	public final static String RESNAME_ID = "RESOURCE_NAME";
	public final static String RESDESIGNATION_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div/div[2]/div/div/div/form/div[3]/table/tbody/tr/td/fieldset/input[8]";
	
	@FindBy(name = MBU_NAME)
	private WebElement mbu;
	
	@FindBy(xpath = DEPARTMENT_XPATH)
	private WebElement department;
	
	@FindBy(xpath = RESCATEGORY_XPATH)
	private WebElement resCategory;
	
	@FindBy(xpath = RESTYPE_XPATH)
	private WebElement resType;
	
	@FindBy(id = RESCODE_ID)
	private WebElement resCode;
	
	@FindBy(id = RESNAME_ID)
	private WebElement resName;
	
	@FindBy(xpath = RESDESIGNATION_XPATH)
	private WebElement resDesignation;

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the resCategory
	 */
	public WebElement getResCategory() {
		return resCategory;
	}

	/**
	 * @return the resType
	 */
	public WebElement getResType() {
		return resType;
	}

	/**
	 * @return the resCode
	 */
	public WebElement getResCode() {
		return resCode;
	}

	/**
	 * @return the resName
	 */
	public WebElement getResName() {
		return resName;
	}

	/**
	 * @return the resDesignation
	 */
	public WebElement getResDesignation() {
		return resDesignation;
	}
	
}
