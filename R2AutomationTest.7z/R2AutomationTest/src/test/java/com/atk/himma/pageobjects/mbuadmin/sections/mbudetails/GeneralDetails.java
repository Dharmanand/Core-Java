package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class GeneralDetails extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "General Details";

	public final static String ADDRESSLINE1_ID = "ADDRESSLINE1";
	public final static String ADDRESSLINE2_ID = "ADDRESSLINE2";
	public final static String COUNTRYDD_ID = "countryDD";
	public final static String CITYDD_ID = "cityDD";
	public final static String STATEDD_ID = "stateDD";
	public final static String POSTALCODE_ID = "POSTAL_CODE";

	public final static String POSTBOXNUMBER_ID = "POST_BOX_NUMBER";
	public final static String PRICOUNTRYCODE_ID = "PRIMARY_COUNTRY_CODE";
	public final static String PRIMARYNUMBER_ID = "PRIMARY_NUMBER";
	public final static String SECCOUNTRYCODE_ID = "SECONDRY_COUNTRY_CODE";
	public final static String SECNUMBER_ID = "SECONDRY_NUMBER";

	public final static String FAXCOUNTRYCODE_ID = "FAX_COUNTRY_CODE";
	public final static String FAXNUMBER_ID = "FAX_NUMBER";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'General Details')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = ADDRESSLINE1_ID)
	private WebElement addressLine1;

	@FindBy(id = ADDRESSLINE2_ID)
	private WebElement addressLine2;

	@FindBy(id = COUNTRYDD_ID)
	private WebElement countryDD;

	@FindBy(id = STATEDD_ID)
	private WebElement stateDD;

	@FindBy(id = CITYDD_ID)
	private WebElement cityDD;

	@FindBy(id = POSTALCODE_ID)
	private WebElement postalCode;

	@FindBy(id = POSTBOXNUMBER_ID)
	private WebElement postBoxNumber;

	@FindBy(id = PRICOUNTRYCODE_ID)
	private WebElement landPhone1Code;

	@FindBy(id = PRIMARYNUMBER_ID)
	private WebElement landPhone1Number;

	@FindBy(id = SECCOUNTRYCODE_ID)
	private WebElement landPhone2Code;

	@FindBy(id = SECNUMBER_ID)
	private WebElement landPhone2Number;

	@FindBy(id = FAXCOUNTRYCODE_ID)
	private WebElement faxCountryCode;

	@FindBy(id = FAXNUMBER_ID)
	private WebElement faxNumber;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkGenDetSecOpen() throws InterruptedException {
		waitForElementLinkText(GeneralDetails.SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatasOfGenDetSec(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(GeneralDetails.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(GeneralDetails.ADDRESSLINE1_ID);
		sleepShort();
		getAddressLine1().clear();
		getAddressLine1().sendKeys(mbuDatas[13].trim());
		getAddressLine2().clear();
		getAddressLine2().sendKeys(mbuDatas[14].trim());
		new Select(getCountryDD()).selectByVisibleText(mbuDatas[15].trim());
		sleepShort();
		new Select(getStateDD()).selectByVisibleText(mbuDatas[16].trim());
		sleepShort();
		new Select(getCityDD()).selectByVisibleText(mbuDatas[17].trim());
		getPostalCode().clear();
		getPostalCode().sendKeys(mbuDatas[18].trim());
		getPostBoxNumber().clear();
		getPostBoxNumber().sendKeys(mbuDatas[19].trim());
		new Select(getLandPhone1Code())
				.selectByVisibleText(mbuDatas[20].trim());
		getLandPhone1Number().clear();
		getLandPhone1Number().sendKeys(mbuDatas[21].trim());
		new Select(getLandPhone2Code())
				.selectByVisibleText(mbuDatas[22].trim());
		getLandPhone2Number().clear();
		getLandPhone2Number().sendKeys(mbuDatas[23].trim());
		new Select(getFaxCountryCode())
				.selectByVisibleText(mbuDatas[24].trim());
		getFaxNumber().clear();
		getFaxNumber().sendKeys(mbuDatas[25].trim());
		return addressLine1.getAttribute("value").trim().equals(mbuDatas[13].trim());
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addressLine1
	 */
	public WebElement getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public WebElement getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @return the countryDD
	 */
	public WebElement getCountryDD() {
		return countryDD;
	}

	/**
	 * @return the stateDD
	 */
	public WebElement getStateDD() {
		return stateDD;
	}

	/**
	 * @return the cityDD
	 */
	public WebElement getCityDD() {
		return cityDD;
	}

	/**
	 * @return the postalCode
	 */
	public WebElement getPostalCode() {
		return postalCode;
	}

	/**
	 * @return the faxCountryCode
	 */
	public WebElement getFaxCountryCode() {
		return faxCountryCode;
	}

	/**
	 * @return the faxNumber
	 */
	public WebElement getFaxNumber() {
		return faxNumber;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the landPhone1Code
	 */
	public WebElement getLandPhone1Code() {
		return landPhone1Code;
	}

	/**
	 * @return the landPhone2Code
	 */
	public WebElement getLandPhone2Code() {
		return landPhone2Code;
	}

	/**
	 * @return the postBoxNumber
	 */
	public WebElement getPostBoxNumber() {
		return postBoxNumber;
	}

	/**
	 * @return the landPhone1Number
	 */
	public WebElement getLandPhone1Number() {
		return landPhone1Number;
	}

	/**
	 * @return the landPhone2Number
	 */
	public WebElement getLandPhone2Number() {
		return landPhone2Number;
	}

}
