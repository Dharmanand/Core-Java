package com.atk.himma.pageobjects.contracts.sections.policydetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PolicyDetailsFirstSection extends DriverWaitClass {
	public final static String POLICYCODE_ID = "POLICY_CODE";
	public final static String POLICYREFNUM_ID = "POLICY_REF_NUM";
	public final static String POLICYTYPE_ID = "POLICY_TYPE";
	public final static String POLICYNAME_ID = "POLICY_NAME";
	public final static String DBTRNAME_ID = "AGMNT_POP_NAME";
	public final static String POLICYNAMEAR_NAME = "policyInfo.policyNameAr";
	public final static String DEBTORLOOKUP_ID = "debtor_lookup_id";
	public final static String DEBTORLOOKUPFORM_ID = "debtoragmntNameformId";
	public final static String DEBTORLOOKUPMBU_ID = "ARMNT_SERDEBT_MBU";
	public final static String GLOBALDBTRCHKBOX_ID = "DEB_GLOBAL_CHBOX_POPUP";
	public final static String DEBTORTYPE_ID = "ARMNT_SERDEBT_DT";
	public final static String DEBTORCATEGORY_ID = "ARMNT_SERDEBT_DC";
	public final static String DEBTORNAME_ID = "ARMNT_SERDEBT_DN";
	public final static String DEBTORSEARCHBTN_ID = "searchDebatorNameId";
	public final static String DEBTORRESETBTN_ID = "ARMNT_SERDEBT_RESET";
	public final static String DEBTORGRIDDIV_ID = "ARMNT_SERDEBT_GRID_DIV_POLICY";
	public final static String AGRMNTNAME_ID = "POLICY_AGREEMENT_NAME";
	public final static String MBU_ID = "MBU_NAME";
	public final static String GLOBALPOLCHKBOX_ID = "POLICY_GLOBAL_CHBOX_MAIN";
	public final static String POLICYSTARTDATE_ID = "POLICY_START_DATE";
	public final static String POLICYENDDATE_ID = "POLICY_END_DATE";

	@FindBy(id = POLICYCODE_ID)
	private WebElement policyCode;

	@FindBy(id = POLICYREFNUM_ID)
	private WebElement policyRefNum;

	@FindBy(id = POLICYTYPE_ID)
	private WebElement policyType;

	@FindBy(id = POLICYNAME_ID)
	private WebElement policyName;

	@FindBy(id = DBTRNAME_ID)
	private WebElement debtorNameTxt;

	@FindBy(name = POLICYNAMEAR_NAME)
	private WebElement policyNameAr;

	@FindBy(id = DEBTORLOOKUP_ID)
	private WebElement debtorLookup;

	@FindBy(id = DEBTORLOOKUPFORM_ID)
	private WebElement debtorLookupForm;

	@FindBy(id = DEBTORLOOKUPMBU_ID)
	private WebElement debtorLookupMBU;

	@FindBy(id = GLOBALDBTRCHKBOX_ID)
	private WebElement globalDbtrChkBox;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = DEBTORCATEGORY_ID)
	private WebElement debtorCategory;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = DEBTORSEARCHBTN_ID)
	private WebElement debtorSearchBtn;

	@FindBy(id = DEBTORRESETBTN_ID)
	private WebElement debtorResetBtn;

	@FindBy(id = DEBTORGRIDDIV_ID)
	private WebElement debtorGridDiv;

	@FindBy(id = AGRMNTNAME_ID)
	private WebElement agrmntName;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = GLOBALPOLCHKBOX_ID)
	private WebElement globalPolChkBox;

	@FindBy(id = POLICYSTARTDATE_ID)
	private WebElement policyStartDate;

	@FindBy(id = POLICYENDDATE_ID)
	private WebElement policyEndDate;

	public boolean isMandPolicyRefNum() {
		waitForElementId(POLICYREFNUM_ID);
		return isMandatoryField(policyRefNum);
	}

	public boolean isMandPolicyType() {
		waitForElementId(POLICYTYPE_ID);
		return isMandatoryField(policyType);
	}

	public boolean isMandPolicyName() {
		waitForElementId(POLICYNAME_ID);
		return isMandatoryField(policyName);
	}

	public boolean isMandDebtorName() {
		waitForElementId(DEBTORNAME_ID);
		return isMandatoryField(debtorNameTxt);
	}

	public boolean isMandAgreementName() {
		waitForElementId(AGRMNTNAME_ID);
		return isMandatoryField(agrmntName);
	}

	public boolean isMandMBUName() {
		waitForElementId(MBU_ID);
		return isMandatoryField(mbu);
	}

	public void fillData(String[] policyListData) throws Exception {
		waitForElementId(POLICYREFNUM_ID);
		sleepLong();
		policyRefNum.clear();
		policyRefNum.sendKeys(policyListData[0]);
		waitForElementId(POLICYTYPE_ID);
		if (!policyListData[1].isEmpty()) {
			new Select(policyType).selectByVisibleText(policyListData[1]);
		}
		waitForElementId(POLICYNAME_ID);
		policyName.clear();
		policyName.sendKeys(policyListData[2]);

		waitForElementName(POLICYNAMEAR_NAME);
		policyNameAr.clear();
		policyNameAr.sendKeys(policyListData[3]);

		debtorLookup.click();
		sleepVeryShort();
		waitForElementId(DEBTORLOOKUPFORM_ID);
		if (!policyListData[9].isEmpty()) {
			new Select(debtorLookupMBU).selectByVisibleText(policyListData[9]);
		}
		if (Boolean.valueOf(policyListData[4])) {
			globalDbtrChkBox.click();
		}
		if (!policyListData[5].isEmpty()) {
			new Select(debtorType).selectByVisibleText(policyListData[5]);
		}
		if (!policyListData[6].isEmpty()) {
			new Select(debtorCategory).selectByVisibleText(policyListData[6]);
		}
		debtorName.clear();
		debtorName.sendKeys(policyListData[7]);
		debtorSearchBtn.click();
		sleepShort();
		waitForElementId(DEBTORGRIDDIV_ID);
		clickOnGridAction("AGMNT_DEBT_DETAILS_GRID_debtorName",
				policyListData[7], "Select");
		sleepShort();
		if (!policyListData[8].isEmpty()) {
			new Select(agrmntName).selectByVisibleText(policyListData[8]);
		}
		sleepShort();
		if (!policyListData[9].isEmpty()) {
			new Select(mbu).selectByVisibleText(policyListData[9]);
		}
		if (Boolean.valueOf(policyListData[10])) {
			globalPolChkBox.click();
		}
		if (!policyListData[11].isEmpty()) {
			policyStartDate.clear();
			policyStartDate.sendKeys(policyListData[11]);
		}
		if (!policyListData[12].isEmpty()) {
			policyEndDate.clear();
			policyEndDate.sendKeys(policyListData[12]);
		}

	}
	
	public String getSelectedAgrment() {
		waitForElementId(AGRMNTNAME_ID);
		return new Select(agrmntName).getFirstSelectedOption().getText();
	}

	public String getSelectedMBU() {
		return new Select(mbu).getFirstSelectedOption().getText();
	}

	public WebElement getPolicyCode() {
		return policyCode;
	}

	public WebElement getPolicyRefNum() {
		return policyRefNum;
	}

	public WebElement getPolicyType() {
		return policyType;
	}

	public WebElement getPolicyName() {
		return policyName;
	}

	public WebElement getDebtorNameTxt() {
		return debtorNameTxt;
	}

	public WebElement getPolicyNameAr() {
		return policyNameAr;
	}

	public WebElement getDebtorLookup() {
		return debtorLookup;
	}

	public WebElement getDebtorLookupForm() {
		return debtorLookupForm;
	}

	public WebElement getDebtorLookupMBU() {
		return debtorLookupMBU;
	}

	public WebElement getGlobalDbtrChkBox() {
		return globalDbtrChkBox;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getDebtorCategory() {
		return debtorCategory;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorSearchBtn() {
		return debtorSearchBtn;
	}

	public WebElement getDebtorResetBtn() {
		return debtorResetBtn;
	}

	public WebElement getDebtorGridDiv() {
		return debtorGridDiv;
	}

	public WebElement getAgrmntName() {
		return agrmntName;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getGlobalPolChkBox() {
		return globalPolChkBox;
	}

	public WebElement getPolicyStartDate() {
		return policyStartDate;
	}

	public WebElement getPolicyEndDate() {
		return policyEndDate;
	}

}
