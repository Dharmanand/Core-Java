package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class DWMParameters extends DriverWaitClass {

	public final static String DIAGNOSISCODE_ID = "DIAGNOSIS_CODE_ID";
	public final static String UPLOADDICTIONARYPATH_NAME = "mbuSetup.otherParameters.dictionaryPath";
	public final static String SECTIONNAME_LINKTEXT = "Doctors Workbench Module Parameters";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Doctors Workbench Module Parameters')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = DIAGNOSISCODE_ID)
	private WebElement diagnosisCode;

	@FindBy(name = UPLOADDICTIONARYPATH_NAME)
	private WebElement uploadDictionaryPath;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	/**
	 * @return the diagnosisCode
	 */
	public WebElement getDiagnosisCode() {
		return diagnosisCode;
	}

	/**
	 * @return the uploadDictionaryPath
	 */
	public WebElement getUploadDictionaryPath() {
		return uploadDictionaryPath;
	}

	public boolean checkMoreAppointParams() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatasToTriageConsul(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			sectionName.click();
		waitForElementId(DIAGNOSISCODE_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(mbuDatas[0].trim(), diagnosisCode);
		uploadDictionaryPath.clear();
		uploadDictionaryPath.sendKeys(mbuDatas[0].trim());
		return (uploadDictionaryPath.getAttribute("value").trim()
				.equals(mbuDatas[0].trim()));
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}
}
