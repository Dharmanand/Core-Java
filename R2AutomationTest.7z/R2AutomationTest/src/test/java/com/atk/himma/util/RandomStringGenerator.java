package com.atk.himma.util;

import java.util.Random;

public class RandomStringGenerator {

	private static final String NUM_LIST = "1234567890";
	private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String SPE_CHAR_LIST = "*=`^$!~&<>?/#@+_-\\:,.\\;\"\'(){}[]'";

	/**
	 * This method generates random string
	 * @Case 1: returns numeric Random string.
	 * @Case 2: returns character Random string.
	 * @Case 3: returns special character Random string.
	 * @Case 4: returns numeric and character Random string.
	 * @Case 5: returns numeric, character & special character Random string.
	 * @Default: returns IllegalArgumentException().
	 * @return
	 */
	public static String generateRandomString(int randomNoLength, int caseNo) {
		StringBuffer randStr = new StringBuffer();
		int number = 0;
		char ch = '\u0000';
		for (int i = 0; i < randomNoLength; i++) {
			switch (caseNo) {
			case 1:
				number = getRandomNumber(NUM_LIST);
				ch = NUM_LIST.charAt(number);
				break;
			case 2:
				number = getRandomNumber(CHAR_LIST);
				ch = CHAR_LIST.charAt(number);
				break;
			case 3:
				number = getRandomNumber(SPE_CHAR_LIST);
				ch = (SPE_CHAR_LIST).charAt(number);
				break;
			case 4:
				number = getRandomNumber(NUM_LIST + CHAR_LIST);
				ch = (NUM_LIST + CHAR_LIST).charAt(number);
				break;
			case 5:
				number = getRandomNumber(NUM_LIST + CHAR_LIST + SPE_CHAR_LIST);
				ch = (NUM_LIST + CHAR_LIST + SPE_CHAR_LIST).charAt(number);
				break;
			default:
				throw new IllegalArgumentException();
			}
			randStr.append(ch);
		}
		return randStr.toString();
	}

	/**
	 * This method generates random numbers
	 * 
	 * @return int
	 */
	private static int getRandomNumber(String charList) {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(charList.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}

}
