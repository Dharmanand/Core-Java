package com.atk.himma.pageobjects.laboratory.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class ContainerTypeDetailsTabPage extends DriverWaitClass implements
		StatusMessages, RecordStatus {
	public final static String ADDNEWUPBTN_ID = "ADD_NEW_UP";
	@FindBy(id = ADDNEWUPBTN_ID)
	private WebElement addNewUpBtn;

	public final static String SAVEUPBTN_ID = "SAVE_UP";
	@FindBy(id = SAVEUPBTN_ID)
	private WebElement saveUpBtn;

	public final static String CANCELUPBTN_ID = "CANCEL_UP";
	@FindBy(id = CANCELUPBTN_ID)
	private WebElement cancelUpBtn;

	public final static String UPDATEUPBTN_ID = "UPDATE_UP";
	@FindBy(id = UPDATEUPBTN_ID)
	private WebElement updateUpBtn;

	public final static String CONTTYPECODETXT_ID = "CONTAINER_TYPE_CODE_TXT";
	@FindBy(id = CONTTYPECODETXT_ID)
	private WebElement contTypeCodeTxt;

	public final static String CONTTYPESHNAME_ID = "SHORT_NAME_TXT";
	@FindBy(id = CONTTYPESHNAME_ID)
	private WebElement contTypeShName;

	public final static String CONTTYPEDESC_ID = "CONTAINER_DESC_TXT";
	@FindBy(id = CONTTYPEDESC_ID)
	private WebElement contTypeDesc;

	public final static String CAPACITY_ID = "CAPACITY_TXT";
	@FindBy(id = CAPACITY_ID)
	private WebElement capacity;

	public final static String UOM_ID = "UOM";
	@FindBy(id = UOM_ID)
	private WebElement uom;

	public final static String ADDITIVE_ID = "ADDITIVE";
	@FindBy(id = ADDITIVE_ID)
	private WebElement additive;

	public boolean isMandContTypeShName() {
		waitForElementId(CONTTYPESHNAME_ID);
		return isMandatoryField(contTypeShName);
	}

	public boolean isMandContTypeDesc() {
		waitForElementId(CONTTYPEDESC_ID);
		return isMandatoryField(contTypeDesc);
	}

	public void fillContainerTypeDetails(String[] containerTypeData) {
		contTypeShName.clear();
		contTypeShName.sendKeys(containerTypeData[1]);
		contTypeDesc.clear();
		contTypeDesc.sendKeys(containerTypeData[2]);
		capacity.clear();
		capacity.sendKeys(containerTypeData[3]);
		new Select(uom).selectByVisibleText(containerTypeData[4]);
		new Select(additive).selectByVisibleText(containerTypeData[5]);

	}

	public String getSelectedUOM() {
		return new Select(uom).getFirstSelectedOption().getText();
	}

	public void saveContainerDetails() throws Exception {
		saveUpBtn.click();
		waitForElementId(UPDATEUPBTN_ID);
		sleepShort();
	}

	public String activateRecord() throws Exception {
		waitForElementId(MAINSTATUSLABEL_ID);
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickAddMoreContainerType() throws Exception {
		addNewUpBtn.click();
		waitForElementId(SAVEUPBTN_ID);
		sleepShort();
	}

	public String verifyContTypeDesc(String[] containerTypeData) {
		return contTypeDesc.getAttribute("value");
	}
	
	public String updateContainerTypeData(String[] containerTypeData) throws Exception {
		contTypeDesc.clear();
		contTypeDesc.sendKeys(containerTypeData[2]);
		updateUpBtn.click();
		sleepShort();
		return contTypeDesc.getAttribute("value");
	}

	public WebElement getAddNewUpBtn() {
		return addNewUpBtn;
	}

	public WebElement getSaveUpBtn() {
		return saveUpBtn;
	}

	public WebElement getCancelUpBtn() {
		return cancelUpBtn;
	}

	public WebElement getUpdateUpBtn() {
		return updateUpBtn;
	}

	public WebElement getContTypeCodeTxt() {
		return contTypeCodeTxt;
	}

	public WebElement getContTypeShName() {
		return contTypeShName;
	}

	public WebElement getContTypeDesc() {
		return contTypeDesc;
	}

	public WebElement getCapacity() {
		return capacity;
	}

	public WebElement getUom() {
		return uom;
	}

	public WebElement getAdditive() {
		return additive;
	}

}
