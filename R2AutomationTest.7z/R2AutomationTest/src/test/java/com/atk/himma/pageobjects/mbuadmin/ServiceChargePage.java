package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.serchargetariffdef.TariffDefinitionIndividual;
import com.atk.himma.pageobjects.mbuadmin.tabs.ServiceChargeListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ServiceChargePage extends DriverWaitClass implements StatusMessages, TopControls, RecordStatus{

	private ServiceChargeListTab serviceChargeListTab;
	private TariffDefinitionIndividual tariffDefinitionIndividual;
	
	public final static String EXPORTTOEXCEL_ID = "CHARGE_LIST_GRID_export_btn";
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Service Charge']";
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement SerCharDetPageTitle;
	
	@FindBy(xpath = DETAILSADDNEWBUTTON_XPATH)
	private WebElement addNewButton;
	
	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;
	
	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		
		serviceChargeListTab = PageFactory.initElements(webDriver,
				ServiceChargeListTab.class);
		serviceChargeListTab.setWebDriver(webDriver);
		serviceChargeListTab.setWebDriverWait(webDriverWait);

		tariffDefinitionIndividual = PageFactory.initElements(webDriver,
				TariffDefinitionIndividual.class);
		tariffDefinitionIndividual.setWebDriver(webDriver);
		tariffDefinitionIndividual.setWebDriverWait(webDriverWait);
	}
	
	public ServiceChargePage clickOnServiceChargeMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Service Charge");
		ServiceChargePage serviceChargePage = PageFactory.initElements(webDriver, ServiceChargePage.class);
		serviceChargePage.setWebDriver(webDriver);
		serviceChargePage.setWebDriverWait(webDriverWait);
		return serviceChargePage;
	}

	public String searchServCharge(String[] serChargDatas) throws InterruptedException {
		waitForElementId(ServiceChargeListTab.MBU_ID);
		waitForElementId(ServiceChargeListTab.SERVICENAME_ID);
		sleepVeryShort();
		serviceChargeListTab.getServiceName().clear();
		serviceChargeListTab.getServiceName().sendKeys(serChargDatas[7]);
		serviceChargeListTab.getSearchButton().click();
		waitForElementId(ServiceChargeListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(ServiceChargeListTab.GRID_ID,
				ServiceChargeListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serChargDatas[7]);
	}

	public boolean defineServiceCharge(String[] serChargDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(ServiceChargeListTab.GRID_ID,
				ServiceChargeListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serChargDatas[7]);
		sleepShort();
		clickOnGridAction(serChargDatas[7], "Define Charge");
		waitForElementName(TariffDefinitionIndividual.SERVICENAME_NAME);
		sleepVeryShort();
		return tariffDefinitionIndividual.getServiceName().getAttribute("value").trim().equals(serChargDatas[7].trim());
	}
	
	public boolean editServiceCharge(String[] serChargDatas) throws InterruptedException {
		waitAndGetGridFirstCellText(ServiceChargeListTab.GRID_ID,
				ServiceChargeListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serChargDatas[7]);
		sleepShort();
		clickOnGridAction(serChargDatas[7], "Edit");
		waitForElementId(TariffDefinitionIndividual.SERVICENAME_NAME);
		sleepVeryShort();
		return tariffDefinitionIndividual.getServiceName().getAttribute("value").trim().equals(serChargDatas[7].trim());
	}
	
	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		sleepShort();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		return detailsUpdateButton.getAttribute("value").trim();
	}

	public String activateRecord() throws InterruptedException {
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, ACTIVATEMSG_XPATH);
	}
	
	/**
	 * @return the serviceChargeListTab
	 */
	public ServiceChargeListTab getServiceChargeListTab() {
		return serviceChargeListTab;
	}

	/**
	 * @return the tariffDefinitionIndividual
	 */
	public TariffDefinitionIndividual getTariffDefinitionIndividual() {
		return tariffDefinitionIndividual;
	}

	/**
	 * @return the serCharDetPageTitle
	 */
	public WebElement getSerCharDetPageTitle() {
		return SerCharDetPageTitle;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

//	public String searchServiceCharge(String[] serviceDatas) throws InterruptedException {
//		waitForElementId(ServiceListTab.MBU_ID);
//		new Select(serviceChargeListTab.getMbu()).selectByVisibleText(serviceDatas[0]);
//		serviceChargeListTab.getServiceName().clear();
//		serviceChargeListTab.getServiceName().sendKeys(serviceDatas[4]);
//		new Select(serviceChargeListTab.getStatus()).selectByVisibleText(serviceDatas[8]);
//		serviceChargeListTab.getSearchButton().click();
//		waitForElementId(ServiceListTab.GRID_ID);
//		sleepShort();
//		return waitAndGetGridFirstCellText(ServiceListTab.GRID_ID,
//				ServiceListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serviceDatas[4]);
//	}
//	
}
