package com.atk.himma.pageobjects.appointsched;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.sections.appointSections.ClinicsAvailability;
import com.atk.himma.pageobjects.appointsched.sections.appointSections.PhysicianAvailability;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class Appointments extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	public final static String MENULINK_XPATH = "//a[contains(text(),'Appointment Scheduling')]/..//a[text()='Appointments']";
	
	private ClinicsAvailability clinicsAvailability;
	private PhysicianAvailability physicianAvailability;
	private AppointmentDairy appointmentDairy;
	private ManageBooking manageBooking;

	public void setInstance(WebDriver webDriver, WebDriverWait webDriverWait) {

		clinicsAvailability = PageFactory.initElements(webDriver,
				ClinicsAvailability.class);
		clinicsAvailability.setWebDriver(webDriver);
		clinicsAvailability.setWebDriverWait(webDriverWait);

		physicianAvailability = PageFactory.initElements(webDriver,
				PhysicianAvailability.class);
		physicianAvailability.setWebDriver(webDriver);
		physicianAvailability.setWebDriverWait(webDriverWait);

		appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.setWebDriver(webDriver);
		appointmentDairy.setWebDriverWait(webDriverWait);
		
		manageBooking = PageFactory.initElements(webDriver,
				ManageBooking.class);
		manageBooking.setWebDriver(webDriver);
		manageBooking.setWebDriverWait(webDriverWait);
		manageBooking.setInstance(webDriver, webDriverWait);
		
	}

	public Appointments clickOnAppointmentsMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Appointment Scheduling");
		menuSelector.clickOnTargetMenu(menuList, "Appointments");
		Appointments appointments = PageFactory.initElements(webDriver,
				Appointments.class);
		appointments.setWebDriver(webDriver);
		appointments.setWebDriverWait(webDriverWait);
		return appointments;
	}
	
	/**
	 * @return the clinicsAvailability
	 */
	public ClinicsAvailability getClinicsAvailability() {
		return clinicsAvailability;
	}

	/**
	 * @return the physicianAvailability
	 */
	public PhysicianAvailability getPhysicianAvailability() {
		return physicianAvailability;
	}

	/**
	 * @return the appointmentDairy
	 */
	public AppointmentDairy getAppointmentDairy() {
		return appointmentDairy;
	}

	/**
	 * @return the manageBooking
	 */
	public ManageBooking getManageBooking() {
		return manageBooking;
	}

}
