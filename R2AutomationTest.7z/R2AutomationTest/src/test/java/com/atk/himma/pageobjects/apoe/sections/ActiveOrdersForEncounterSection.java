package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ActiveOrdersForEncounterSection extends DriverWaitClass {
	public final static String ACTIVEORDFORENCSEC_XPATH = "//a[text()='Active Orders for this Encounter']";
	@FindBy(xpath = ACTIVEORDFORENCSEC_XPATH)
	private WebElement activeOrdersForEncSec;

	public WebElement getActiveOrdersForEncSec() {
		return activeOrdersForEncSec;
	}

	public boolean checkActiveOrdersForEncSec() {
		return activeOrdersForEncSec.isDisplayed();
	}

}
