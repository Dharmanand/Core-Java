package com.atk.himma.pageobjects.laboratory;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.laboratory.sections.AdditionalParametersSec;
import com.atk.himma.pageobjects.laboratory.sections.SensitivityPanelDetailsDefaultSec;
import com.atk.himma.pageobjects.laboratory.tabs.SensitivityPanelListTabPage;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class SensitivityPanelPage extends DriverWaitClass {
	private SensitivityPanelListTabPage sensitivityPanelListTabPage;
	private SensitivityPanelDetailsDefaultSec sensitivityPanelDetailsDefaultSec;
	private AdditionalParametersSec additionalParametersSec;

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	public final static String SENSITIVITYPANELLISTTAB_XPATH = "//a[@title='Sensitivity Panel List']";
	@FindBy(xpath = SENSITIVITYPANELLISTTAB_XPATH)
	private WebElement sensitivityPanelListTab;

	public final static String SENSITIVITYPANELDTLTAB_XPATH = "//a[@title='Sensitivity Panel Details']";
	@FindBy(xpath = SENSITIVITYPANELDTLTAB_XPATH)
	private WebElement sensitivityPanelDetailsTab;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		sensitivityPanelListTabPage = PageFactory.initElements(webDriver,
				SensitivityPanelListTabPage.class);
		sensitivityPanelListTabPage.setWebDriver(webDriver);
		sensitivityPanelListTabPage.setWebDriverWait(webDriverWait);

		sensitivityPanelDetailsDefaultSec = PageFactory.initElements(webDriver,
				SensitivityPanelDetailsDefaultSec.class);
		sensitivityPanelDetailsDefaultSec.setWebDriver(webDriver);
		sensitivityPanelDetailsDefaultSec.setWebDriverWait(webDriverWait);

		additionalParametersSec = PageFactory.initElements(webDriver,
				AdditionalParametersSec.class);
		additionalParametersSec.setWebDriver(webDriver);
		additionalParametersSec.setWebDriverWait(webDriverWait);
	}

	public SensitivityPanelPage clickOnSensitivityPanelMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> sensitivityPanelMenuList = new LinkedList<String>();
		sensitivityPanelMenuList.add("Laboratory");
		menuSelector.clickOnTargetMenu(sensitivityPanelMenuList,
				"Sensitivity Panel");
		SensitivityPanelPage sensitivityPanelPage = PageFactory.initElements(
				webDriver, SensitivityPanelPage.class);
		sensitivityPanelPage.setWebDriver(webDriver);
		sensitivityPanelPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return sensitivityPanelPage;

	}

	public SensitivityPanelListTabPage getSensitivityPanelListTabPage() {
		return sensitivityPanelListTabPage;
	}

	public SensitivityPanelDetailsDefaultSec getSensitivityPanelDetailsDefaultSec() {
		return sensitivityPanelDetailsDefaultSec;
	}

	public AdditionalParametersSec getAdditionalParametersSec() {
		return additionalParametersSec;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getSensitivityPanelListTab() {
		return sensitivityPanelListTab;
	}

	public WebElement getSensitivityPanelDetailsTab() {
		return sensitivityPanelDetailsTab;
	}

}
