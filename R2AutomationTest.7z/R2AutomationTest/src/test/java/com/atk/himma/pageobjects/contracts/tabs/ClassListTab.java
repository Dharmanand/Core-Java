package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ClassListTab extends DriverWaitClass {
	public final static String CLASSLISTFORM_ID = "CLASS_LIST_FORM";
	public final static String ADDNEWCLASSBTN_ID = "ADD_NEW_CLASS_BTN";
	public final static String SEARCHCLSMBU_ID = "SEARCH_CLASS_MBU";
	public final static String GLOBALCLSCHKBOX_ID = "CLASS_GLOBAL_CHBOX";
	public final static String SEARCHCLSDEBTOR_ID = "debtor_search_class";
	public final static String SEARCHCLSDEBTORTYPE_ID = "SEARCH_CLASS_DTYPE";
	public final static String SEARCHCLSAGRMNTNAME_ID = "SEARCH_CLASS_ANAME";
	public final static String POLICYLOOKUP_XPATH = "//div[@id='CLASS_LIST_TAB']//a[@class='lookup']";
	public final static String POLICYLOOKUPFORM_ID = "classPolicyNameformIdMain";
	public final static String POLICYLOOKUPMBU_ID = "CLASS_POLICY_MBU";
	public final static String GLOBALPOLCHKBOX_ID = "CL_POL_CHBOX_POPUP";
	public final static String POLICYLOOKUPDBTRNAME_ID = "CLASS_POLICY_DEBTORNAME";
	public final static String POLICYLOOKUPAGRMNTNAME_ID = "CLASS_POLICY_AGRMNTNAME";
	public final static String POLICYLOOKUPPOLNAME_ID = "CLASS_POLICY_PNAME";
	public final static String POLICYLOOKUPPOLREFNUM_ID = "CLASS_POLICY_REFNUMBER";
	public final static String POLICYLOOKUPSEARCHBTN_ID = "searchPolicyNameIdMain";
	public final static String POLICYLOOKUPRESETBTN_ID = "CLASS_POLICY_RESET_MAIN";
	public final static String POLICYLOOKUPGRIDDIV_ID = "CLASS_POLICY_SEARCH_GRID_DIV_MAIN";
	public final static String CLSSTATUS_ID = "SEARCH_CLASS_STATUS";
	public final static String CLSNAME_ID = "SEARCH_CLASS_CNAME";
	public final static String CLSCODE_ID = "SEARCH_CLASS_CODE";
	public final static String CLSSEARCHBTN_ID = "CLASS_SEARCH";
	public final static String CLSRESETBTN_ID = "RESET_CLASS_LIST";
	public final static String CLSGRIDDIV_ID = "CLASS_SEARCH_GRID";
	public static final String VIEWCLSLINK_XPATH = ".//table[@id='CLASS_LIST']/..//a[text()='View']";
	public static final String DELCLSLINK_XPATH = ".//table[@id='CLASS_LIST']/..//a[text()='Delete']";
	public static final String EDITCLSLINK_XPATH = ".//table[@id='CLASS_LIST']/..//a[text()='Edit']";

	@FindBy(id = CLASSLISTFORM_ID)
	private WebElement classListForm;

	@FindBy(id = ADDNEWCLASSBTN_ID)
	private WebElement addNewClassBtn;

	@FindBy(id = SEARCHCLSMBU_ID)
	private WebElement searchClsMbu;

	@FindBy(id = GLOBALCLSCHKBOX_ID)
	private WebElement globalClsChkBox;

	@FindBy(id = SEARCHCLSDEBTOR_ID)
	private WebElement searchClsDebtorName;

	@FindBy(id = SEARCHCLSDEBTORTYPE_ID)
	private WebElement searchClsDebtorType;

	@FindBy(id = SEARCHCLSAGRMNTNAME_ID)
	private WebElement searchClsAgrmntName;

	@FindBy(xpath = POLICYLOOKUP_XPATH)
	private WebElement policyLookup;

	@FindBy(id = POLICYLOOKUPFORM_ID)
	private WebElement policyLookupForm;

	@FindBy(id = POLICYLOOKUPMBU_ID)
	private WebElement policyLookupMBU;

	@FindBy(id = GLOBALPOLCHKBOX_ID)
	private WebElement globalPolChkBox;

	@FindBy(id = POLICYLOOKUPDBTRNAME_ID)
	private WebElement polLookupDbtrName;

	@FindBy(id = POLICYLOOKUPAGRMNTNAME_ID)
	private WebElement polLookupAgrmntName;

	@FindBy(id = POLICYLOOKUPPOLNAME_ID)
	private WebElement polLookupPolName;

	@FindBy(id = POLICYLOOKUPPOLREFNUM_ID)
	private WebElement polLookupPolRefNum;

	@FindBy(id = POLICYLOOKUPSEARCHBTN_ID)
	private WebElement polLookupSearchBtn;

	@FindBy(id = POLICYLOOKUPRESETBTN_ID)
	private WebElement polLookupResetBtn;

	@FindBy(id = POLICYLOOKUPGRIDDIV_ID)
	private WebElement polLookupGridDiv;

	@FindBy(id = CLSSTATUS_ID)
	private WebElement classStatus;

	@FindBy(id = CLSNAME_ID)
	private WebElement className;

	@FindBy(id = CLSCODE_ID)
	private WebElement classCode;

	@FindBy(id = CLSSEARCHBTN_ID)
	private WebElement classSearchBtn;

	@FindBy(id = CLSRESETBTN_ID)
	private WebElement classReserBtn;

	@FindBy(id = CLSGRIDDIV_ID)
	private WebElement classGridDiv;

	@FindBy(xpath = VIEWCLSLINK_XPATH)
	private WebElement viewClassLink;

	@FindBy(xpath = DELCLSLINK_XPATH)
	private WebElement delClassLink;

	@FindBy(xpath = EDITCLSLINK_XPATH)
	private WebElement editClassLink;

	public void clickAddNewClass() throws Exception {
		addNewClassBtn.click();
		sleepShort();

	}

	public void searchClass(String[] classListData) throws Exception {
		waitForPageLoaded(webDriver);
		sleepShort();
		if (!classListData[6].isEmpty()) {
			new Select(searchClsMbu).selectByVisibleText(classListData[6]);
		}
		waitForElementId(SEARCHCLSDEBTOR_ID);
		sleepVeryShort();
		if (!classListData[2].isEmpty()) {
			new Select(searchClsDebtorName)
					.selectByVisibleText(classListData[2]);
		}
		waitForElementId(SEARCHCLSAGRMNTNAME_ID);
		sleepVeryShort();
		if (!classListData[3].isEmpty()) {
			new Select(searchClsAgrmntName)
					.selectByVisibleText(classListData[3]);
		}
		className.clear();
		className.sendKeys(classListData[0]);
		classSearchBtn.click();
		waitForElementId(CLSGRIDDIV_ID);
		clickOnGridAction("CLASS_LIST_className", classListData[0], "Edit");
		sleepShort();
		waitForPageLoaded(webDriver);

	}

	public void searchClassList(String[] classData) throws Exception {
		waitForPageLoaded(webDriver);
		sleepShort();
		if (!classData[6].isEmpty()) {
			new Select(searchClsMbu).selectByVisibleText(classData[6]);
		}
		waitForElementId(SEARCHCLSDEBTOR_ID);
		sleepVeryShort();
		if (!classData[2].isEmpty()) {
			new Select(searchClsDebtorName).selectByVisibleText(classData[2]);
		}
		waitForElementId(SEARCHCLSAGRMNTNAME_ID);
		sleepVeryShort();
		if (!classData[3].isEmpty()) {
			new Select(searchClsAgrmntName).selectByVisibleText(classData[3]);
		}
		className.clear();
		className.sendKeys(classData[0]);
		classSearchBtn.click();
		waitForElementId(CLSGRIDDIV_ID);
		sleepShort();

	}
	
	public void clickEditClsLink(String[] classData) throws Exception {
		clickOnGridAction("CLASS_LIST_className", classData[0], "Edit");
		sleepShort();
		
	}

	public WebElement getClassListForm() {
		return classListForm;
	}

	public WebElement getAddNewClassBtn() {
		return addNewClassBtn;
	}

	public WebElement getSearchClsMbu() {
		return searchClsMbu;
	}

	public WebElement getGlobalClsChkBox() {
		return globalClsChkBox;
	}

	public WebElement getSearchClsDebtorName() {
		return searchClsDebtorName;
	}

	public WebElement getSearchClsDebtorType() {
		return searchClsDebtorType;
	}

	public WebElement getSearchClsAgrmntName() {
		return searchClsAgrmntName;
	}

	public WebElement getPolicyLookup() {
		return policyLookup;
	}

	public WebElement getPolicyLookupForm() {
		return policyLookupForm;
	}

	public WebElement getPolicyLookupMBU() {
		return policyLookupMBU;
	}

	public WebElement getGlobalPolChkBox() {
		return globalPolChkBox;
	}

	public WebElement getPolLookupDbtrName() {
		return polLookupDbtrName;
	}

	public WebElement getPolLookupAgrmntName() {
		return polLookupAgrmntName;
	}

	public WebElement getPolLookupPolName() {
		return polLookupPolName;
	}

	public WebElement getPolLookupPolRefNum() {
		return polLookupPolRefNum;
	}

	public WebElement getPolLookupSearchBtn() {
		return polLookupSearchBtn;
	}

	public WebElement getPolLookupResetBtn() {
		return polLookupResetBtn;
	}

	public WebElement getPolLookupGridDiv() {
		return polLookupGridDiv;
	}

	public WebElement getClassStatus() {
		return classStatus;
	}

	public WebElement getClassName() {
		return className;
	}

	public WebElement getClassCode() {
		return classCode;
	}

	public WebElement getClassSearchBtn() {
		return classSearchBtn;
	}

	public WebElement getClassReserBtn() {
		return classReserBtn;
	}

	public WebElement getClassGridDiv() {
		return classGridDiv;
	}

	public WebElement getViewClassLink() {
		return viewClassLink;
	}

	public WebElement getDelClassLink() {
		return delClassLink;
	}

	public WebElement getEditClassLink() {
		return editClassLink;
	}

}
