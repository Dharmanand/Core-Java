package com.atk.himma.pageobjects.sa.admin;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.admin.tabs.SequenceCodeDetailsTab;
import com.atk.himma.pageobjects.sa.admin.tabs.SequenceCodeListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class SequenceCodeGeneratorPage extends DriverWaitClass implements
		StatusMessages {
	private SequenceCodeListTab sequenceCodeListTab;
	private SequenceCodeDetailsTab sequenceCodeDetailsTab;
	
	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Admin ')]/..//a[contains(text(),'Sequence Code Generator')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		sequenceCodeListTab = PageFactory.initElements(webDriver,
				SequenceCodeListTab.class);
		sequenceCodeListTab.setWebDriver(webDriver);
		sequenceCodeListTab.setWebDriverWait(webDriverWait);

		sequenceCodeDetailsTab = PageFactory.initElements(webDriver,
				SequenceCodeDetailsTab.class);
		sequenceCodeDetailsTab.setWebDriver(webDriver);
		sequenceCodeDetailsTab.setWebDriverWait(webDriverWait);
	}

	public SequenceCodeGeneratorPage clickOnSequenceCodeGeneratorMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> scgParentMenuList = new LinkedList<String>();
		scgParentMenuList.add("System Administration");
		scgParentMenuList.add("Admin ");
		menuSelector.clickOnTargetMenu(scgParentMenuList,
				"Sequence Code Generator");
		SequenceCodeGeneratorPage sequenceCodeGeneratorPage = PageFactory
				.initElements(webDriver, SequenceCodeGeneratorPage.class);
		sequenceCodeGeneratorPage.setWebDriver(webDriver);
		sequenceCodeGeneratorPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForPageLoaded(webDriver);
		return sequenceCodeGeneratorPage;

	}

	public SequenceCodeListTab getSequenceCodeListTab() {
		return sequenceCodeListTab;
	}

	public SequenceCodeDetailsTab getSequenceCodeDetailsTab() {
		return sequenceCodeDetailsTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
