package com.atk.himma.test.pharmacy;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.pharmacy.master.TherapClassificationsPage;
import com.atk.himma.pageobjects.pharmacy.tabs.SolnDiluentListTab;
import com.atk.himma.setup.SeleniumDriverSetup;

public class TherapeuticClassTest extends SeleniumDriverSetup {

	TherapClassificationsPage therapClassificationsPage;
	List<String[]> therapClassDatas;

	@Test
	public void test001checkTherapClassLink() {

		therapClassificationsPage = PageFactory.initElements(webDriver,
				TherapClassificationsPage.class);
		therapClassificationsPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		therapClassificationsPage = therapClassificationsPage
				.checkTherapClassificationsLink(webDriver, webDriverWait);
		therapClassificationsPage
				.waitForElementXpathExpression(TherapClassificationsPage.GRID_ID);
		Assert.assertEquals(therapClassificationsPage.getTherapeuticGrp()
				.getText(), "Solution / Diluent",
				"Fail to Appear 'Therapeutic Class' Link");

	}

	@Test(dependsOnMethods = { "test001checkTherapClassLink" })
	public void test002clickTherapClassMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("mrdExcel"));
		therapClassDatas = excelReader.read(properties
				.getProperty("mrdSpecRequest"));
		therapClassificationsPage.clickTherapClassificationsMenu();
		doDirtyFormCheck();
		therapClassificationsPage.waitForElementId(SolnDiluentListTab.GRID_ID);
		therapClassificationsPage
				.waitForElementCssSelector(TherapClassificationsPage.SAVEBUTTON_CSS);
		Assert.assertEquals(therapClassificationsPage.getSaveButton()
				.getAttribute("value").trim(), "Save",
				"Fail: to open 'Therapeutic Class' page");
	}

	@Test(dependsOnMethods = { "test002clickTherapClassMenuLink" })
	public void test003isMandatoryAnatMainGroup() throws Exception {
		Assert.assertTrue(therapClassificationsPage.isMandatoryAnatMainGroup(),
				"Fail to click 'Anatomical Main Group'");
	}

	@Test(dependsOnMethods = { "test002clickTherapClassMenuLink" })
	public void test004isMandatoryTherapeuticGrp() throws Exception {
		Assert.assertTrue(
				therapClassificationsPage.isMandatoryTherapeuticGrp(),
				"Fail to click 'Therapeutic Group'");
	}

	@Test(dependsOnMethods = { "test002clickTherapClassMenuLink" })
	public void test005isMandatoryPharmacoLogicalubGrp() throws Exception {
		Assert.assertTrue(
				therapClassificationsPage.isMandatoryPharmacoLogicalubGrp(),
				"Fail to click 'Pharmacological SubGroup'");
	}

	@Test(dependsOnMethods = { "test002clickTherapClassMenuLink" })
	public void test006ClearData() throws Exception {
		for (String[] st : therapClassDatas) {
			Assert.assertTrue(therapClassificationsPage.clearData(st),
					"Fail to fill 'test006ClearData'");
		}
	}

	@Test(dependsOnMethods = { "test002clickTherapClassMenuLink" })
	public void test007AddData() throws Exception {
		for (String[] st : therapClassDatas) {
			Assert.assertTrue(therapClassificationsPage.addData(st),
					"Fail to fill 'test007AddData'");
		}
	}

	@Test(dependsOnMethods = { "test002clickTherapClassMenuLink" })
	public void test008FillTherapClassDatas() throws Exception {
		for (String[] st : therapClassDatas) {
			Assert.assertTrue(
					therapClassificationsPage.fillTherapClassifDatas(st),
					"Fail to fill 'test009fillTherapClassDatas'");
		}
	}

	@Test(dependsOnMethods = { "test008fillTherapClassDatas" })
	public void test009SaveData() throws Exception {
		for (String[] st : therapClassDatas) {
			Assert.assertTrue(therapClassificationsPage.saveData(st),
					"Fail to click 'test010saveData'");
		}
	}
}
