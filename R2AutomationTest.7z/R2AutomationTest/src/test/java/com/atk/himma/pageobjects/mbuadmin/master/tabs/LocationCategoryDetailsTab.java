package com.atk.himma.pageobjects.mbuadmin.master.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LocationCategoryDetailsTab extends DriverWaitClass {

	public final static String FORM_ID = "LOCATION_CATEGORY_DETAILS";
	public final static String MBUCODE_NAME = "mainBusinessUnit.unitCode";
	public final static String MBUNAME_NAME = "mainBusinessUnit.unitName";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String APPLLOCCAT_NAME = "multiselect_LOCATION_CATEGORY_HIERARCHY";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(name = MBUCODE_NAME)
	private WebElement mbuCode;

	@FindBy(name = MBUNAME_NAME)
	private WebElement mbuName;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	// Grid Start -----------------------------------------

	public void clickOnApplicableLocationCategory(String appLocCategory) {
		String appLocCatXpath = "//input[@title='" + appLocCategory.trim()
				+ "' and @name='" + APPLLOCCAT_NAME + "']";
		waitForElementXpathExpression(appLocCatXpath);
		webDriver.findElement(By.xpath(appLocCatXpath)).click();
	}
	
	public void unSelectApplicableLocationCategory(WebElement appLocCategory) throws InterruptedException {
		waitForElementVisibilityOf(appLocCategory);
		if(appLocCategory.isSelected())
			appLocCategory.click();
	}

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}
}
