package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ConsumablesSection extends DriverWaitClass{
	
	public final static String ADDROWBUTTON_CSS = "#editConsumableDetAuth + input[value='Add Row']";
	
//	-----------GRID--------------
	public final static String GRID_ID = "ITEM_GRID";
	public final static String GRID_ITEMCODE_ARIA_DESCRIBEDBY = "ITEM_GRID_itemCode";
	public final static String GRID_ITEMNAME_ARIA_DESCRIBEDBY = "ITEM_GRID_itemName";
	public final static String GRID_QUALITY_ARIA_DESCRIBEDBY = "ITEM_GRID_quantity";
	public final static String GRID_UOM_ARIA_DESCRIBEDBY = "ITEM_GRID_uomId";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "ITEM_GRID_actions";
	public final static String GRID_PAGERID = "sp_1_ITEM_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_ITEM_GRID_pager']";

//	-----------GRID's Fields--------------
	public final static String ITEMCODETXT_CSS = "td[aria-describedby='"+GRID_ITEMCODE_ARIA_DESCRIBEDBY+"'] span input[name='itemCode']";
	public final static String ITEMNAMETXT_CSS = "td[aria-describedby='"+GRID_ITEMNAME_ARIA_DESCRIBEDBY+"'] span input[name='itemName']";
	public final static String POPUP_CSS = "td[aria-describedby='"+GRID_ITEMNAME_ARIA_DESCRIBEDBY+"'] span a[name='itemName']";
	public final static String QUALITYTXT_CSS = "td[aria-describedby='"+GRID_QUALITY_ARIA_DESCRIBEDBY+"'] span input[name='quantity']";
	public final static String LOOKUP_CSS = "td[aria-describedby='"+GRID_UOM_ARIA_DESCRIBEDBY+"'] input[name='serviceName']";
	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_ITEMNAME_ARIA_DESCRIBEDBY+"']/span/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";

	@FindBy(css = ADDROWBUTTON_CSS)
	private WebElement addRowButton;
	
	@FindBy(css = ITEMNAMETXT_CSS)
	private WebElement itemNameTxt;
	
	@FindBy(css = ITEMCODETXT_CSS)
	private WebElement itemCodeTxt;
	
	@FindBy(css = POPUP_CSS)
	private WebElement popup;
	
	@FindBy(css = QUALITYTXT_CSS)
	private WebElement qualityTxt;
	
	@FindBy(css = LOOKUP_CSS)
	private WebElement lookup;
	
	@FindBy(css = DELETEACTION_GE_XPATH)
	private WebElement deleteAction;

	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the itemNameTxt
	 */
	public WebElement getItemNameTxt() {
		return itemNameTxt;
	}

	/**
	 * @return the itemCodeTxt
	 */
	public WebElement getItemCodeTxt() {
		return itemCodeTxt;
	}

	/**
	 * @return the popup
	 */
	public WebElement getPopup() {
		return popup;
	}

	/**
	 * @return the qualityTxt
	 */
	public WebElement getQualityTxt() {
		return qualityTxt;
	}

	/**
	 * @return the lookup
	 */
	public WebElement getLookup() {
		return lookup;
	}

	/**
	 * @return the deleteAction
	 */
	public WebElement getDeleteAction() {
		return deleteAction;
	}
	
}
