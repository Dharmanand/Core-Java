package com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ClinicFirstSection extends DriverWaitClass {

	public final static String CLINICCODE_ID = "clinicCode";
	public final static String CLINICSHORTNAME_ID = "shortName";
	public final static String CLINICNAME_NAME = "clinicLocation.locationName";
	public final static String CLINICNAMEAR_ID = "clinicNameNL";
	public final static String MBU_ID = "MBU_LIST_TAB2";
	public final static String DEPARTMENT_ID = "DEPARTMENT_LIST_TAB2";
	public final static String SPECIALITY_ID = "SPECIALITY_LIST_TAB2";
	public final static String SUBSPECIALITY_ID = "SUB_SPECIALITY_LIST_TAB2";
	public final static String LOCATIONCATEGORY_ID = "LOCATION_CATEGORY_TEXT";
	public final static String PH1COUNCODE_ID = "mainPhCountryCode";
	public final static String PH1LOCALNO_ID = "mainPhLocalNo";

	public final static String PH2COUNCODE_ID = "secPhCountryCode";
	public final static String PH2LOCALNO_ID = "secPhLocalNo";

	public final static String ISAGESPECIFIC_ID = "IS_AGE_SPECIFIC";
	public final static String MINAGE_ID = "MIN_AGE";
	public final static String MINAGETYPE_ID = "MIN_AGE_TYPE";

	public final static String MAXAGE_ID = "MAX_AGE";
	public final static String MAXAGETYPE_ID = "MAX_AGE_TYPE";
	public final static String ISGENDERSPECIFIC_ID = "IS_GENDER_SPECIFIC";
	public final static String GENDER_NAME = "multiselect_GENDER";

	@FindBy(id = CLINICCODE_ID)
	private WebElement clinicCode;

	@FindBy(id = CLINICSHORTNAME_ID)
	private WebElement clinicShortName;

	@FindBy(name = CLINICNAME_NAME)
	private WebElement clinicName;

	@FindBy(id = CLINICNAMEAR_ID)
	private WebElement clinicNameAr;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	@FindBy(id = SPECIALITY_ID)
	private WebElement speciality;

	@FindBy(id = SUBSPECIALITY_ID)
	private WebElement subSpeciality;

	@FindBy(id = LOCATIONCATEGORY_ID)
	private WebElement locationCategory;

	@FindBy(id = PH1COUNCODE_ID)
	private WebElement ph1CounCode;

	@FindBy(id = PH1LOCALNO_ID)
	private WebElement ph1LocalNo;

	@FindBy(id = PH2COUNCODE_ID)
	private WebElement ph2CounCode;

	@FindBy(id = PH2LOCALNO_ID)
	private WebElement ph2LocalNo;

	@FindBy(id = ISAGESPECIFIC_ID)
	private WebElement isAgeSpecific;

	@FindBy(id = MINAGE_ID)
	private WebElement minAge;

	@FindBy(id = MINAGETYPE_ID)
	private WebElement minAgeType;

	@FindBy(id = MAXAGE_ID)
	private WebElement maxAge;

	@FindBy(id = MAXAGETYPE_ID)
	private WebElement maxAgeType;

	@FindBy(id = ISGENDERSPECIFIC_ID)
	private WebElement isGenderSpecific;

	@FindBy(id = GENDER_NAME)
	private WebElement gender;

	public boolean isMandatoryClinicShName() {
		return isMandatoryField(clinicShortName);
	}

	public boolean isMandatoryClinicName() {
		return isMandatoryField(clinicName);
	}

	public boolean isMandatoryMBU() {
		return isMandatoryField(mbu);
	}

	public boolean fillServiceFirstSecDatas(String[] clinicDatas)
			throws InterruptedException {
		waitForElementName(CLINICNAME_NAME);
		sleepShort();
		clinicShortName.clear();
		clinicShortName.sendKeys(clinicDatas[6].trim());
		clinicName.clear();
		clinicName.sendKeys(clinicDatas[7].trim());
		clinicNameAr.clear();
		clinicNameAr.sendKeys(clinicDatas[8].trim());
		if (!clinicDatas[0].isEmpty())
			new Select(mbu).selectByVisibleText(clinicDatas[0].trim());
		if (!clinicDatas[9].isEmpty())
			new Select(department).selectByVisibleText(clinicDatas[9].trim());
		if (!clinicDatas[10].isEmpty())
			new Select(speciality).selectByVisibleText(clinicDatas[10].trim());
		if (!clinicDatas[11].isEmpty())
			new Select(subSpeciality).selectByVisibleText(clinicDatas[11]
					.trim());
		if (!clinicDatas[12].isEmpty())
			new Select(ph1CounCode).selectByVisibleText(clinicDatas[12].trim());
		ph1LocalNo.clear();
		ph1LocalNo.sendKeys(clinicDatas[13].trim());
		if (!clinicDatas[14].isEmpty())
			new Select(ph2CounCode).selectByVisibleText(clinicDatas[14].trim());
		ph2LocalNo.clear();
		ph2LocalNo.sendKeys(clinicDatas[15].trim());

		selectOrUnSelectCheckBox(clinicDatas[16].trim(), isAgeSpecific);
		if (isAgeSpecific.isSelected()) {
			minAge.clear();
			minAge.sendKeys(clinicDatas[16].trim());
			new Select(minAgeType).selectByVisibleText(clinicDatas[17].trim());
			maxAge.clear();
			maxAge.sendKeys(clinicDatas[18].trim());
			new Select(maxAgeType).selectByVisibleText(clinicDatas[19].trim());
		}
		selectOrUnSelectCheckBox(clinicDatas[20].trim(), isGenderSpecific);
		if (isGenderSpecific.isSelected())
			selectValueOfMultiselect(GENDER_NAME, clinicDatas[21].trim());
		return isGenderSpecific.isSelected() == Boolean.valueOf(clinicDatas[21]
				.trim());
	}

	/**
	 * @return the clinicCode
	 */
	public WebElement getClinicCode() {
		return clinicCode;
	}

	/**
	 * @return the shortName
	 */
	public WebElement getClinicShortName() {
		return clinicShortName;
	}

	/**
	 * @return the clinicName
	 */
	public WebElement getClinicName() {
		return clinicName;
	}

	/**
	 * @return the clinicNameAr
	 */
	public WebElement getClinicNameAr() {
		return clinicNameAr;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the speciality
	 */
	public WebElement getSpeciality() {
		return speciality;
	}

	/**
	 * @return the subSpeciality
	 */
	public WebElement getSubSpeciality() {
		return subSpeciality;
	}

	/**
	 * @return the locationCategory
	 */
	public WebElement getLocationCategory() {
		return locationCategory;
	}

	/**
	 * @return the ph1CounCode
	 */
	public WebElement getPh1CounCode() {
		return ph1CounCode;
	}

	/**
	 * @return the ph1LocalNo
	 */
	public WebElement getPh1LocalNo() {
		return ph1LocalNo;
	}

	/**
	 * @return the ph2CounCode
	 */
	public WebElement getPh2CounCode() {
		return ph2CounCode;
	}

	/**
	 * @return the ph2LocalNo
	 */
	public WebElement getPh2LocalNo() {
		return ph2LocalNo;
	}

	/**
	 * @return the isAgeSpecific
	 */
	public WebElement getIsAgeSpecific() {
		return isAgeSpecific;
	}

	/**
	 * @return the minAge
	 */
	public WebElement getMinAge() {
		return minAge;
	}

	/**
	 * @return the minAgeType
	 */
	public WebElement getMinAgeType() {
		return minAgeType;
	}

	/**
	 * @return the maxAge
	 */
	public WebElement getMaxAge() {
		return maxAge;
	}

	/**
	 * @return the maxAgeType
	 */
	public WebElement getMaxAgeType() {
		return maxAgeType;
	}

	/**
	 * @return the isGenderSpecific
	 */
	public WebElement getIsGenderSpecific() {
		return isGenderSpecific;
	}

	/**
	 * @return the gender
	 */
	public WebElement getGender() {
		return gender;
	}

}
