package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class OrgUnitSearchPopupPage extends DriverWaitClass {
	public final static String EDITBTN_ID = "ORG_SEARCH_FRM";
	@FindBy(id = EDITBTN_ID)
	private WebElement orgSearchForm;

	public final static String ROOTORG_ID = "ROOT_ORG";
	@FindBy(id = ROOTORG_ID)
	private WebElement rootOrg;

	public final static String MBUORG_ID = "MBU_ORG";
	@FindBy(id = MBUORG_ID)
	private WebElement mbuOrg;

	public final static String MBUNAME_ID = "MAIN_BUSINESS_UNIT";
	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;

	public final static String ORGUNITTYPE_NAME = "searchCriteria.unitType";
	@FindBy(name = ORGUNITTYPE_NAME)
	private WebElement orgUnitType;

	public final static String ORGNAMECODE_NAME = "searchCriteria.unitName";
	@FindBy(name = ORGNAMECODE_NAME)
	private WebElement orgNameCode;

	public final static String ORGPOPUPSEARCHBTN_ID = "searchId";
	@FindBy(id = ORGPOPUPSEARCHBTN_ID)
	private WebElement orgPopupSearchBtn;

	public final static String ORGPOPUPCANCELBTN_NAME = "cancel";
	@FindBy(name = ORGPOPUPCANCELBTN_NAME)
	private WebElement orgPopupCancelBtn;

	public final static String ORGPOPUPSEARCHRESULTGRID_ID = "gbox_ORG_POPUP_SEARCH_RESULT";
	@FindBy(id = ORGPOPUPSEARCHRESULTGRID_ID)
	private WebElement orgPopupSearchResultGrid;

	public void searchUnit(String ouName, String mbu, String ouType)
			throws Exception {
		if (mbu.isEmpty()) {
			sleepShort();
			rootOrg.click();
		} else {
			sleepShort();
			mbuOrg.click();
			new Select(mbuName).selectByVisibleText(mbu);
		}
		if (ouType != null && !ouType.isEmpty()) {
			new Select(orgUnitType).selectByVisibleText(ouType);
		}
		orgNameCode.clear();
		orgNameCode.sendKeys(ouName);
		orgPopupSearchBtn.click();
		sleepShort();
		clickOnGridAction("ORG_POPUP_SEARCH_RESULT_unitName", ouName, "Select");
	}

	public WebElement getOrgSearchForm() {
		return orgSearchForm;
	}

	public WebElement getRootOrg() {
		return rootOrg;
	}

	public WebElement getMbuOrg() {
		return mbuOrg;
	}

	public WebElement getMbuName() {
		return mbuName;
	}

	public WebElement getOrgUnitType() {
		return orgUnitType;
	}

	public WebElement getOrgNameCode() {
		return orgNameCode;
	}

	public WebElement getOrgPopupSearchBtn() {
		return orgPopupSearchBtn;
	}

	public WebElement getOrgPopupCancelBtn() {
		return orgPopupCancelBtn;
	}

	public WebElement getOrgPopupSearchResultGrid() {
		return orgPopupSearchResultGrid;
	}

}
