package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.ServicePage;
import com.atk.himma.pageobjects.mbuadmin.tabs.ServiceListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ServiceTest extends SeleniumDriverSetup {

	List<String[]> serviceDatas;
	ServicePage servicePage;

	@Test(description = "Open Service Page")
	public void clickOnServiceMenu() throws InterruptedException {
		servicePage = PageFactory.initElements(webDriver, ServicePage.class);
		servicePage = servicePage.clickOnServiceMenu(webDriver, webDriverWait);
		servicePage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		servicePage
				.waitForElementXpathExpression(ServiceListTab.SEARCHBUTTON_XPATH);
		Assert.assertEquals(servicePage.getServiceListTab().getServiceListTab()
				.getAttribute("title").trim(), "Service List",
				"Fail to open Service page.");
	}

	// [Service] Open Form
	@Test(description = "Open Service Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkServiceMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		servicePage = PageFactory.initElements(webDriver, ServicePage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList, "Service");
		servicePage.setWebDriver(webDriver);
		servicePage.setWebDriverWait(webDriverWait);
		servicePage.waitForElementXpathExpression(ServicePage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[Service] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ServicePage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Service] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			servicePage = servicePage.clickOnServiceMenu(webDriver,
					webDriverWait);
			servicePage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(servicePage);
			servicePage
					.waitForElementXpathExpression(ServiceListTab.SEARCHBUTTON_XPATH);
			Assert.assertEquals(servicePage.getServiceListTab()
					.getServiceListTab().getAttribute("title").trim(),
					"Service List", "Fail to open Service page.");
		}
	}

	@Test(description = "click On Add New Button", dependsOnMethods = "clickOnServiceMenu")
	public void test1ClickOnAddNewButton() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		serviceDatas = excelReader.read(properties.getProperty("service"));
		for (String st[] : serviceDatas.subList(0, 1))
			Assert.assertEquals(servicePage.clickOnAddNewSerButton(st), true,
					"Fail to click On Add New Button.");
	}

	@Test(description = "click Mandatory Service Short Name", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test2IsMandatorySerShortName() {

		Assert.assertEquals(servicePage.getServiceFirstSection()
				.isMandatorySerShortName(), true,
				"Fail to Mandatory Service Short Name.");
	}

	@Test(description = "click Mandatory Service Name", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test3IsMandatoryServiceName() {
		Assert.assertEquals(servicePage.getServiceFirstSection()
				.isMandatoryServiceName(), true,
				"Fail to Mandatory Service Name.");
	}

	@Test(description = "click Mandatory MBU", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test4IsMandatoryMBU() {
		Assert.assertEquals(servicePage.getServiceFirstSection()
				.isMandatoryServiceName(), true, "Fail to Mandatory MBU.");
	}

	@Test(description = "click Mandatory Service Type", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test5IsMandatoryServiceType() {
		Assert.assertEquals(servicePage.getServiceFirstSection()
				.isMandatoryServiceType(), true,
				"Fail to Mandatory Service Type.");
	}

	@Test(description = "Fill datas of Service First Section", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test5FillServiceFirstSecDatas() {
		for (String st[] : serviceDatas.subList(0, 1))
			Assert.assertEquals(servicePage.getServiceFirstSection()
					.fillServiceFirstSecDatas(st), true,
					"Fail to Fill datas of Service First Section");
	}

	@Test(description = "check Add Paramameter Section", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test6CheckAddParamSec() throws InterruptedException {
		Assert.assertEquals(servicePage.getAdditionalParameters()
				.checkAddParamSection(), true,
				"Fail to Fill datas of Service First Section");
	}

	@Test(description = "check Add Paramameter Section", dependsOnMethods = "test6CheckAddParamSec")
	public void test7IsMandatorychargable() throws InterruptedException {
		Assert.assertEquals(servicePage.getAdditionalParameters()
				.isMandatorychargable(), true,
				"Fail to Fill datas of Service First Section");
	}

	@Test(description = "fill Additional Param Datas", dependsOnMethods = "test6CheckAddParamSec")
	public void test8IillAdditionalParamDatas() throws InterruptedException {
		for (String st[] : serviceDatas.subList(0, 1))
			Assert.assertEquals(servicePage.getAdditionalParameters()
					.fillAdditionalParamDatas(st), true,
					"Fail to fill Additional Param Datas");
	}

	@Test(description = "check Administration Parameter Section", dependsOnMethods = "test6CheckAddParamSec")
	public void test9CheckAdminisParamSec() throws InterruptedException {
		Assert.assertEquals(servicePage.getAdministrativeParameters()
				.checkAdminisParamSection(), false,
				"check Administration Parameter Section");
	}

	@Test(description = "fill Datas MBU Timings", dependsOnMethods = "test9CheckAdminisParamSec")
	public void test10FillAdministrativeDatas() throws InterruptedException {
		for (String st[] : serviceDatas.subList(0, 1))
			Assert.assertEquals(servicePage.getAdministrativeParameters()
					.fillDatas(st), true, "Fail to fill Datas MBU Timings");
	}

	@Test(description = "Save Service", dependsOnMethods = "test10FillAdministrativeDatas")
	public void test11SaveService() throws InterruptedException, IOException {
		Assert.assertEquals(servicePage.saveDetailsPage().contains("Update"),
				true, "Fail to Save Service.");
	}

	@Test(description = "Activate Service", dependsOnMethods = "test11SaveService")
	public void test12ActivateService() throws InterruptedException, IOException {
		Assert.assertEquals(servicePage.activateService().contains("Active"),
				true, "Fail to Activate Service.");
	}

	@Test(description = "Save All Service Datas MBU Timings", dependsOnMethods = {
			"clickOnServiceMenu", "test11SaveService" }, alwaysRun = true)
	public void test13AddMoreServiceDatas() throws InterruptedException, IOException {
		for (String st[] : serviceDatas.subList(1, serviceDatas.size())) {
			Assert.assertEquals(servicePage.clickAddNewButton(st), true,
					"Fail to click On Add New Button.");
			Assert.assertEquals(servicePage.getAdministrativeParameters()
					.fillDatas(st), true, "Fail to fill Datas MBU Timings");
			Assert.assertEquals(servicePage.getServiceFirstSection()
					.fillServiceFirstSecDatas(st), true,
					"Fail to Fill datas of Service First Section");
			Assert.assertEquals(servicePage.getAdditionalParameters()
					.fillAdditionalParamDatas(st), true,
					"Fail to fill Additional Param Datas");
			Assert.assertEquals(servicePage.getAdministrativeParameters()
					.fillDatas(st), true, "Fail to fill Datas MBU Timings");
			Assert.assertEquals(servicePage.saveDetailsPage()
					.contains("Update"), true, "Fail to Save Service.");
			Assert.assertEquals(servicePage.activateService()
					.contains("Active"), true, "Fail to Activate Service.");
		}
	}
	@Test(description = "Check Duplicate Data For service", dependsOnMethods = {
			"test11SaveService" }, alwaysRun = true)
	public void test14CheckDuplicateSerData() throws InterruptedException, IOException {
		for (String st[] : serviceDatas.subList(0, 1)) {
			Assert.assertEquals(servicePage.clickAddNewButton(st), true,
					"Fail to click On Add New Button.");
			Assert.assertEquals(servicePage.getAdministrativeParameters()
					.fillDatas(st), true, "Fail to fill Datas MBU Timings");
			Assert.assertEquals(servicePage.getServiceFirstSection()
					.fillServiceFirstSecDatas(st), true,
					"Fail to Fill datas of Service First Section");
			Assert.assertEquals(servicePage.getAdditionalParameters()
					.fillAdditionalParamDatas(st), true,
					"Fail to fill Additional Param Datas");
			Assert.assertEquals(servicePage.getAdministrativeParameters()
					.fillDatas(st), true, "Fail to fill Datas MBU Timings");
			Assert.assertTrue(servicePage.saveDuplicateData(st), "Fail Check Duplicate Data For service.");
		}
	}

/*	@Test(dependsOnMethods = { "checkServiceMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Clinic for Privilege")
	public void searchServiceForPrivilege() throws Exception {
		servicePage.getServiceListTab().getServiceListTab().click();
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		serviceDatas = excelReader.read(properties.getProperty("service"));
		for (String st[] : serviceDatas.subList(0, 1))
			Assert.assertEquals(servicePage.searchService(st), st[4].trim(),
					"Fail to Search MBU result");
	}

	// [List Tab] Add New (Button)
		@Test(dependsOnMethods = { "checkServiceMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Add New (Button) for Privilege")
		public void checkAddNewButtonPrivilege() throws IOException {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("MBU Administration").get("Service")
					.get("[List Tab] Add New (Button)");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.xpath(ServiceListTab.ADDNEWSERVICEBUTTON_XPATH));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [List Tab] Add New (Button)");
		}

	
	// [List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchServiceForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check View link for Privilege")
	public void checkViewLinkPrivilege() throws IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		serviceDatas = excelReader.read(properties.getProperty("service"));
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ serviceDatas.subList(0, 1).get(0)[4].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid)");
	}

	// [List Tab] Delete(Link in the search result grid)
	@Test(dependsOnMethods = { "searchServiceForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check View link for Privilege")
	public void checkDeleteLinkPrivilege() throws IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		serviceDatas = excelReader.read(properties.getProperty("service"));
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[List Tab] Delete(Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ serviceDatas.subList(0, 1).get(0)[4].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete(Link in the search result grid)");
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "searchServiceForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Check Edit Link for Privilege")
	public void checkEditLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ serviceDatas.subList(0, 1).get(0)[4].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid)");
		servicePage.clickOnGridAction(
				serviceDatas.subList(0, 1).get(0)[4].trim(), "Edit");
		servicePage
				.waitForElementXpathExpression(ServicePage.UPDATECONFMSG_XPATH);
	}

	// [Details Tab] [Section: Additional Parameters] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Additional Parameters section privileges")
	public void checkAddParamSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[Details Tab] [Section: Additional Parameters] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(AdditionalParameters.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Registration Configuration] View");
	}

	// [Details Tab] [Section: Administrative Parameters] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Administrative Parameters section privileges")
	public void checkAdmParamSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[Details Tab] [Section: Administrative Parameters] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(AdministrativeParameters.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"[Details Tab] [Section: Administrative Parameters] View");
	}

	// [Details Tab] [Section: Service Location] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Service Location section privileges")
	public void checkSerLocSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Service")
				.get("[Details Tab] [Section: Service Location] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(RegConfiguration.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Service Location] View");
	}

	// [Details Tab] [Section: Service Code Standard and Additional References]
	// View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Service Code Standard and Additional References section privileges")
	public void checkSerCodeStandSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Service")
				.get("[Details Tab] [Section: Service Code Standard and Additional References] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(SerCodeStandAddReferences.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(
				actualPrivilege,
				expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Service Code Standard and Additional References] View");
	}*/
}
