package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RadEquipmentFirstSection extends DriverWaitClass{
	
	public final static String EQUIPMENTCODE_NAME = "radEqupDetails.equipmentCode";
	public final static String EQUIPSHORTNAME_NAME = "radEqupDetails.equipShortName";
	public final static String EQUIPMENTNAME_NAME = "radEqupDetails.equipmentName";
	public final static String MBU_NAME = "radEqupDetails.mbuName";
	public final static String DEPARTMENT_NAME = "radEqupDetails.departName_ID";
	public final static String RESOURCECAT_NAME = "radEqupDetails.resourceCategory";
	public final static String RESOURCETYPE_NAME = "radEqupDetails.resourceType";
	public final static String RECORDSTATUS_NAME = "radEqupDetails.recordStatus";

	@FindBy(name = EQUIPMENTCODE_NAME)
	private WebElement equipmentCode;
	
	@FindBy(name = EQUIPSHORTNAME_NAME)
	private WebElement equipShortName;
	
	@FindBy(name = EQUIPMENTNAME_NAME)
	private WebElement equipmentName;
	
	@FindBy(name = MBU_NAME)
	private WebElement mbuName;
	
	@FindBy(name = DEPARTMENT_NAME)
	private WebElement departmentName;
	
	@FindBy(name = RESOURCECAT_NAME)
	private WebElement resourceCatName;
	
	/**
	 * @return the equipmentCode
	 */
	public WebElement getEquipmentCode() {
		return equipmentCode;
	}

	/**
	 * @return the equipShortName
	 */
	public WebElement getEquipShortName() {
		return equipShortName;
	}

	/**
	 * @return the equipmentName
	 */
	public WebElement getEquipmentName() {
		return equipmentName;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the departmentName
	 */
	public WebElement getDepartmentName() {
		return departmentName;
	}

	/**
	 * @return the resourceCatName
	 */
	public WebElement getResourceCatName() {
		return resourceCatName;
	}

	/**
	 * @return the resourceType
	 */
	public WebElement getResourceType() {
		return resourceType;
	}

	/**
	 * @return the recordStatus
	 */
	public WebElement getRecordStatus() {
		return recordStatus;
	}

	@FindBy(name = RESOURCETYPE_NAME)
	private WebElement resourceType;
	
	@FindBy(name = RECORDSTATUS_NAME)
	private WebElement recordStatus;
	
}
