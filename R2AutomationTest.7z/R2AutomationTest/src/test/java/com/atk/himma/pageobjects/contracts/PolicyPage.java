package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.AssociatedClassesSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.PolicyDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.PolicyDocumentScanSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.PolicyGeneralParametersSection;
import com.atk.himma.pageobjects.contracts.tabs.PolicyListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class PolicyPage extends DriverWaitClass implements StatusMessages,
		RecordStatus {
	private PolicyListTab policyListTab;
	private PolicyDetailsFirstSection policyDetailsFirstSection;
	private PolicyDocumentScanSection policyDocumentScanSection;
	private AssociatedClassesSection associatedClassesSection;
	private PolicyGeneralParametersSection policyGeneralParametersSection;
	private ExclusionListDetailsSection exclusionListDetailsSection;
	private ApprovalListDetailsSection approvalListDetailsSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[text()= 'Policy']";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String POLICYDETAILSFORM_ID = "POLICY_DETAILS_FORM";
	public final static String ADDNEWBTN_XPATH = "//form[@id='POLICY_DETAILS_FORM']//input[@value='Add New']";
	public final static String SAVEBTN_XPATH = "//form[@id='POLICY_DETAILS_FORM']//input[@value='Save']";
	public final static String CANCELBTN_XPATH = "//form[@id='POLICY_DETAILS_FORM']//input[@value='Cancel']";
	public final static String UPDATEBTN_XPATH = "//form[@id='POLICY_DETAILS_FORM']//input[@value='Update']";
	public final static String COPYBTN_XPATH = "//form[@id='POLICY_DETAILS_FORM']//input[@value='Copy']";
	public final static String GOTOAGRMNTBTN_ID = "GO_TO_AGR";
	public final static String CREATENEWCLASSBTN_ID = "GO_TO_CLASS";

	public final static String EXCLISTDETAILSSECTION_ID = "POLICY_EX_SECTION_title";
	public final static String EXCSECTIONDIV_ID = "POLICY_EX_SECTION";
	public final static String APPRVLLISTDETAILSSECTION_ID = "POLICY_APP_SECTION_title";
	public final static String APPRVLSECTIONDIV_ID = "POLICY_APP_SECTION";
	

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = POLICYDETAILSFORM_ID)
	private WebElement policyDetailsForm;

	@FindBy(xpath = ADDNEWBTN_XPATH)
	private WebElement addNewBtn;

	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	@FindBy(xpath = COPYBTN_XPATH)
	private WebElement copyBtn;

	@FindBy(id = GOTOAGRMNTBTN_ID)
	private WebElement goToAgrmntBtn;

	@FindBy(id = CREATENEWCLASSBTN_ID)
	private WebElement createNewClassBtn;

	@FindBy(id = EXCLISTDETAILSSECTION_ID)
	private WebElement excListDetailsSection;

	@FindBy(id = EXCSECTIONDIV_ID)
	private WebElement excSectionDiv;

	@FindBy(id = APPRVLLISTDETAILSSECTION_ID)
	private WebElement apprvlListDetailsSection;

	@FindBy(id = APPRVLSECTIONDIV_ID)
	private WebElement apprvlSectionDiv;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		policyListTab = PageFactory
				.initElements(webDriver, PolicyListTab.class);
		policyListTab.setWebDriver(webDriver);
		policyListTab.setWebDriverWait(webDriverWait);

		policyDetailsFirstSection = PageFactory.initElements(webDriver,
				PolicyDetailsFirstSection.class);
		policyDetailsFirstSection.setWebDriver(webDriver);
		policyDetailsFirstSection.setWebDriverWait(webDriverWait);

		policyDocumentScanSection = PageFactory.initElements(webDriver,
				PolicyDocumentScanSection.class);
		policyDocumentScanSection.setWebDriver(webDriver);
		policyDocumentScanSection.setWebDriverWait(webDriverWait);

		associatedClassesSection = PageFactory.initElements(webDriver,
				AssociatedClassesSection.class);
		associatedClassesSection.setWebDriver(webDriver);
		associatedClassesSection.setWebDriverWait(webDriverWait);

		policyGeneralParametersSection = PageFactory.initElements(webDriver,
				PolicyGeneralParametersSection.class);
		policyGeneralParametersSection.setWebDriver(webDriver);
		policyGeneralParametersSection.setWebDriverWait(webDriverWait);

		exclusionListDetailsSection = PageFactory.initElements(webDriver,
				ExclusionListDetailsSection.class);
		exclusionListDetailsSection.setWebDriver(webDriver);
		exclusionListDetailsSection.setWebDriverWait(webDriverWait);

		approvalListDetailsSection = PageFactory.initElements(webDriver,
				ApprovalListDetailsSection.class);
		approvalListDetailsSection.setWebDriver(webDriver);
		approvalListDetailsSection.setWebDriverWait(webDriverWait);

	}

	public PolicyPage clickOnPolicyMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "Policy");
		PolicyPage policyPage = PageFactory.initElements(webDriver,
				PolicyPage.class);
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return policyPage;
	}

	public void collapseExpandExcSection() throws Exception {
		waitForElementId(EXCLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getExcListDetailsSection().getAttribute(
				"class"))) {
			excListDetailsSection.click();
			sleepMedium();
			waitForElementId(EXCSECTIONDIV_ID);
		}

	}

	public void collapseExpandApprvlSection() throws Exception {
		waitForElementId(APPRVLLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getApprvlListDetailsSection().getAttribute(
				"class"))) {
			apprvlListDetailsSection.click();
			sleepMedium();
			waitForElementId(APPRVLSECTIONDIV_ID);
		}

	}

	public void savePolicy() throws Exception {
		saveBtn.click();
		sleepShort();
		waitForElementXpathExpression(UPDATEBTN_XPATH);
		sleepMedium();

	}

	public String activateRecord() throws Exception {
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickCreateNewClassBtn() throws Exception {
		createNewClassBtn.click();
		doDirtyPopUpCheck();
		sleepShort();
		waitForPageLoaded(webDriver);

	}

	public String verifyPolicy(String[] policyListData) {
		ClassPage classPage = PageFactory.initElements(webDriver,
				ClassPage.class);
		classPage.setWebDriver(webDriver);
		classPage.setWebDriverWait(webDriverWait);
		classPage.initPages(webDriver, webDriverWait);
		String policyName = classPage.getClassDetailsFirstSection()
				.getPolicyName().getAttribute("value");
		classPage.getGoToPolBtn().click();
		return policyName;
	}

	public void clickOnGoToPolicyBtn() throws Exception {
		waitForElementId(GOTOAGRMNTBTN_ID);
		sleepVeryShort();
		goToAgrmntBtn.click();
		doDirtyPopUpCheck();
	}

	public boolean verifyDebtorAgrmntAssociatedPolicy(String[] policyListData) {
		DebtorAgreementPage debtorAgreementPage = PageFactory.initElements(
				webDriver, DebtorAgreementPage.class);
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		debtorAgreementPage.initPages(webDriver, webDriverWait);
		return debtorAgreementPage.getAssociatedPoliciesSection()
				.checkAssociatedPolData(policyListData);
	}

	public void collapseExpandAgreementExcSection() throws Exception {
		DebtorAgreementPage debtorAgreementPage = PageFactory.initElements(
				webDriver, DebtorAgreementPage.class);
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		debtorAgreementPage.initPages(webDriver, webDriverWait);
		debtorAgreementPage.collapseExpandExcSection();
	}

	public void collapseExpandAgreementApprvlSection() throws Exception {
		DebtorAgreementPage debtorAgreementPage = PageFactory.initElements(
				webDriver, DebtorAgreementPage.class);
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		debtorAgreementPage.initPages(webDriver, webDriverWait);
		debtorAgreementPage.collapseExpandApprvlSection();
		waitForPageLoaded(webDriver);

	}

	public void updateAgreementDetails() throws InterruptedException {
		DebtorAgreementPage debtorAgreementPage = PageFactory.initElements(
				webDriver, DebtorAgreementPage.class);
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		debtorAgreementPage.getUpdateBtn().click();
		waitForPageLoaded(webDriver);
	}

	public PolicyListTab getPolicyListTab() {
		return policyListTab;
	}

	public PolicyDetailsFirstSection getPolicyDetailsFirstSection() {
		return policyDetailsFirstSection;
	}

	public PolicyDocumentScanSection getPolicyDocumentScanSection() {
		return policyDocumentScanSection;
	}

	public AssociatedClassesSection getAssociatedClassesSection() {
		return associatedClassesSection;
	}

	public PolicyGeneralParametersSection getPolicyGeneralParametersSection() {
		return policyGeneralParametersSection;
	}

	public ExclusionListDetailsSection getExclusionListDetailsSection() {
		return exclusionListDetailsSection;
	}

	public ApprovalListDetailsSection getApprovalListDetailsSection() {
		return approvalListDetailsSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getPolicyDetailsForm() {
		return policyDetailsForm;
	}

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getGoToAgrmntBtn() {
		return goToAgrmntBtn;
	}

	public WebElement getCreateNewClassBtn() {
		return createNewClassBtn;
	}

	public WebElement getExcListDetailsSection() {
		return excListDetailsSection;
	}

	public WebElement getExcSectionDiv() {
		return excSectionDiv;
	}

	public WebElement getApprvlListDetailsSection() {
		return apprvlListDetailsSection;
	}

	public WebElement getApprvlSectionDiv() {
		return apprvlSectionDiv;
	}

	public WebElement getActivateRecord() {
		return activateRecord;
	}

}