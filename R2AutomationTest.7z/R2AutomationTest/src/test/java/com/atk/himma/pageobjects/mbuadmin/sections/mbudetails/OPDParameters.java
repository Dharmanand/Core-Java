package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class OPDParameters extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Out Patient Department Parameters";
	public final static String ADDBUTTONGRID_XPATH = ".//*[@id='VISIT_PARAMETERS_GRID_pager_left']/table/tbody/tr/td/div/span";
	public final static String SLOTINTERVAL_ID = "SLOTINTERVAL";
	public final static String SLOTBLOCKDURATION_ID = "SLOTBLOCKDURATION";
	public final static String ALLOWEDNOSHOWS_ID = "ALLOWEDNOSHOWS";
	public final static String NOSHOWBLOCKDURATION_ID = "NOSHOWBLOCKDURATION";
	public final static String ONAPPTSTATUSMODIFIC_ID = "onApptStatusModification";
	public final static String ONAPPOINTMENTREMINDER_ID = "onApptReminder";
	public final static String ARECONSULCHARGED_ID = "ARE_CONSULTATION_CHARGED";
	public final static String CHARGEPATTERN_ID = "CHARGE_PATTERN";
	public final static String TRIAGEBEFOREPO_ID = "TRIAGE_BEFORE_PO";
	public final static String POSTBOXNUMBER_ID = "POST_BOX_NUMBER";

	public final static String POPUPFORM_ID = "VISIT_PARAMETERS_FORM";
	public final static String POPUPTITLE_ID = "ui-dialog-title-visitParametersDialog";
	public final static String VISITPARAMVISITCAT_ID = "VISIT_PARAM_VISIT_CATEGORY";
	public final static String VISITPARAMVISITTYPE_ID = "VISIT_PARAM_VISIT_TYPE";
	public final static String FOLLOWUPSALLOWED_ID = "NUMBER_ALLOWED_PERVISIT";
	public final static String FOLLOWUPDURATION_ID = "DURATION_OF_ELIGIBILITY";

	public final static String SUBMITBUTTON_ID = "submitSessionPopup";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_sml']//input[@value='Cancel']";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Out Patient Department Parameters')]/..";

	public final static String GRIDID_ID = "VISIT_PARAMETERS_GRID";
	public final static String GRID_VISITCATEGORY_ID = "VISIT_PARAMETERS_GRID_visitCategoryText";
	public final static String GRID_VISITTYPE_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_visitTypeText";
	public final static String GRID_ALLOWEDPERVISIT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_allowedPerVisit";
	public final static String GRID_ELIGDUR_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_eligibilityDuration";
	public final static String GRID_PAGERID = "sp_1_VISIT_PARAMETERS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_VISIT_PARAMETERS_GRID_pager']";

	@FindBy(id = TRIAGEBEFOREPO_ID)
	private WebElement triageBeforeConsult;

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButtonGrid;

	@FindBy(id = SLOTINTERVAL_ID)
	private WebElement slotInterval;

	@FindBy(id = SLOTBLOCKDURATION_ID)
	private WebElement slotBlockDuration;

	@FindBy(id = ALLOWEDNOSHOWS_ID)
	private WebElement permisibleNo;

	@FindBy(id = NOSHOWBLOCKDURATION_ID)
	private WebElement revokeBlockAfter;

	@FindBy(id = ONAPPTSTATUSMODIFIC_ID)
	private WebElement onApptStatusModific;

	@FindBy(id = ONAPPOINTMENTREMINDER_ID)
	private WebElement onAppointReminder;

	@FindBy(id = ARECONSULCHARGED_ID)
	private WebElement areConsulCharged;

	@FindBy(id = CHARGEPATTERN_ID)
	private WebElement chargePattern;

	@FindBy(id = POPUPFORM_ID)
	private WebElement popupForm;

	@FindBy(id = POPUPTITLE_ID)
	private WebElement popupTitle;

	@FindBy(id = VISITPARAMVISITCAT_ID)
	private WebElement visitParamVisitCat;

	@FindBy(id = VISITPARAMVISITTYPE_ID)
	private WebElement visitParamVisitType;

	@FindBy(id = FOLLOWUPSALLOWED_ID)
	private WebElement followupsAllowed;

	@FindBy(id = FOLLOWUPDURATION_ID)
	private WebElement followupDuration;

	@FindBy(id = POSTBOXNUMBER_ID)
	private WebElement postBoxNumber;

	@FindBy(id = GRIDID_ID)
	private WebElement gridID;

	@FindBy(id = SUBMITBUTTON_ID)
	private WebElement submitButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	@FindBy(xpath = GRID_PAGERID)
	private WebElement gridPager;

	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement gridNextPageXpath;

	public boolean checkOPDRegSection() throws InterruptedException {
		waitForElementLinkText(RegConfiguration.SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean isMandatorySlotInterval() {
		waitForElementLinkText(RegConfiguration.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		return isMandatoryField(slotInterval);
	}

	public boolean isMandSlotBlInterval() {
		waitForElementLinkText(RegConfiguration.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		return isMandatoryField(slotBlockDuration);
	}

	public boolean fillDatasUpToSMSSection(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(OPDParameters.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(SLOTINTERVAL_ID);
		sleepVeryShort();
		slotInterval.clear();
		slotInterval.sendKeys(mbuDatas[41].trim());
		slotBlockDuration.clear();
		slotBlockDuration.sendKeys(mbuDatas[42].trim());
		permisibleNo.clear();
		permisibleNo.sendKeys(mbuDatas[43].trim());
		revokeBlockAfter.clear();
		revokeBlockAfter.sendKeys(mbuDatas[44].trim());
		selectOrUnSelectCheckBox(mbuDatas[45].trim(), onApptStatusModific);
		selectOrUnSelectCheckBox(mbuDatas[46].trim(), onAppointReminder);
		return (onAppointReminder.isSelected() == Boolean.valueOf(mbuDatas[46]));
	}

	public boolean fillDatasToConsulCharged(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(OPDParameters.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(ARECONSULCHARGED_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(mbuDatas[47].trim(), areConsulCharged);
		if(areConsulCharged.isSelected())
		{
			waitForElementId(CHARGEPATTERN_ID);
			new Select(chargePattern).selectByVisibleText(mbuDatas[48].trim());
		}
		return (areConsulCharged.isSelected() == Boolean.valueOf(mbuDatas[47]));
	}

	public boolean isMandFreeChargePattern() {
		waitForElementId(CHARGEPATTERN_ID);
		return isMandatoryField(chargePattern);
	}

	public boolean fillDatasToTriageConsul(String[] mbuDatas)
			throws InterruptedException {
		waitForElementId(TRIAGEBEFOREPO_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(mbuDatas[49].trim(), triageBeforeConsult);
		return (triageBeforeConsult.isSelected() == Boolean
				.valueOf(mbuDatas[49]));
	}

	public String clickOnAddButton(String[] mbuDatas)
			throws InterruptedException {
		waitForElementXpathExpression(ADDBUTTONGRID_XPATH);
		addButtonGrid.click();
		waitForElementId(POPUPTITLE_ID);
		sleepVeryShort();
		return popupTitle.getText().trim();
	}

	public boolean isMandVisitCategory() {
		waitForElementId(VISITPARAMVISITCAT_ID);
		return isMandatoryField(visitParamVisitCat);
	}

	public boolean isMandVisitType() {
		waitForElementId(VISITPARAMVISITTYPE_ID);
		return isMandatoryField(visitParamVisitType);
	}

	public boolean isMandFollowUpsAllowed() {
		waitForElementId(FOLLOWUPSALLOWED_ID);
		return isMandatoryField(followupsAllowed);
	}

	public boolean isMandFollowUpsDuration() {
		waitForElementId(FOLLOWUPDURATION_ID);
		return isMandatoryField(followupsAllowed);
	}

	public boolean fillDatasToPopUp(String[] mbuDatas)
			throws InterruptedException {
		new Select(visitParamVisitCat).selectByVisibleText(mbuDatas[50].trim());
		new Select(visitParamVisitType).selectByVisibleText(mbuDatas[51].trim());
		followupsAllowed.clear();
		followupsAllowed.sendKeys(mbuDatas[52].trim());
		followupDuration.clear();
		followupDuration.sendKeys(mbuDatas[53].trim());
		return (followupDuration.getAttribute("value").trim()
				.equals(mbuDatas[53].trim()));
	}

	public boolean submitFollowUpDatas() throws InterruptedException {
		waitForElementId(SUBMITBUTTON_ID);
		submitButton.click();
		waitForElementId(GRIDID_ID);
		sleepVeryShort();
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addButtonGrid
	 */
	public WebElement getAddButtonGrid() {
		return addButtonGrid;
	}

	/**
	 * @return the slotInterval
	 */
	public WebElement getSlotInterval() {
		return slotInterval;
	}

	/**
	 * @return the slotBlockDuration
	 */
	public WebElement getSlotBlockDuration() {
		return slotBlockDuration;
	}

	/**
	 * @return the onApptStatusModific
	 */
	public WebElement getOnApptStatusModific() {
		return onApptStatusModific;
	}

	/**
	 * @return the areConsulCharged
	 */
	public WebElement getAreConsulCharged() {
		return areConsulCharged;
	}

	/**
	 * @return the chargePattern
	 */
	public WebElement getChargePattern() {
		return chargePattern;
	}

	/**
	 * @return the popupForm
	 */
	public WebElement getPopupForm() {
		return popupForm;
	}

	/**
	 * @return the popupTitle
	 */
	public WebElement getPopupTitle() {
		return popupTitle;
	}

	/**
	 * @return the visitParamVisitCat
	 */
	public WebElement getVisitParamVisitCat() {
		return visitParamVisitCat;
	}

	/**
	 * @return the visitParamVisitType
	 */
	public WebElement getVisitParamVisitType() {
		return visitParamVisitType;
	}

	/**
	 * @return the followupsAllowed
	 */
	public WebElement getFollowupsAllowed() {
		return followupsAllowed;
	}

	/**
	 * @return the followupDuration
	 */
	public WebElement getFollowupDuration() {
		return followupDuration;
	}

	/**
	 * @return the postBoxNumber
	 */
	public WebElement getPostBoxNumber() {
		return postBoxNumber;
	}

	/**
	 * @return the gridID
	 */
	public WebElement getGridID() {
		return gridID;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the gridNextPageXpath
	 */
	public WebElement getGridNextPageXpath() {
		return gridNextPageXpath;
	}

	/**
	 * @return the onAppointReminder
	 */
	public WebElement getOnAppointReminder() {
		return onAppointReminder;
	}

	/**
	 * @return the triageBeforeConsult
	 */
	public WebElement getTriageBeforeConsult() {
		return triageBeforeConsult;
	}

	/**
	 * @return the permisibleNo
	 */
	public WebElement getPermisibleNo() {
		return permisibleNo;
	}

	/**
	 * @return the revokeBlockAfter
	 */
	public WebElement getRevokeBlockAfter() {
		return revokeBlockAfter;
	}

}
