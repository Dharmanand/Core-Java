package com.atk.himma.pageobjects.contracts.sections.policydetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AssociatedClassesSection extends DriverWaitClass {
	public static final String ASSOCIATEDCLSSEC_LINKTEXT = "Associated Classes";
	public final static String ASSOCLSGRIDDIV_ID = "gview_ASSOCIATED_CLASS_GRID";

	@FindBy(linkText = ASSOCIATEDCLSSEC_LINKTEXT)
	private WebElement assoClassSec;

	@FindBy(id = ASSOCLSGRIDDIV_ID)
	private WebElement assoClassGridDiv;

	public WebElement getAssoClassSec() {
		return assoClassSec;
	}

	public WebElement getAssoClassGridDiv() {
		return assoClassGridDiv;
	}

	public boolean checkAssociatedClsData(String[] classListData)
			throws Exception {
		waitForElementId(ASSOCLSGRIDDIV_ID);
		sleepShort();
		try {
			waitForElementXpathExpression(".//td[@aria-describedby='ASSOCIATED_CLASS_GRID_className' and @title='"
					+ classListData[0] + "']");
			return webDriver
					.findElement(
							By.xpath(".//td[@aria-describedby='ASSOCIATED_CLASS_GRID_className' and @title='"
									+ classListData[0] + "']")).isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}

}
