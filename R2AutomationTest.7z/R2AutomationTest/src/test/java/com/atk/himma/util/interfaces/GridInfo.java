package com.atk.himma.util.interfaces;

import java.util.List;

import org.openqa.selenium.WebElement;

public interface GridInfo {

	public String waitForGridFirstDuplicateCellText(String gridID, String tdAriaDescribedby);

	public String waitAndGetGridFirstCellText(String gridID,
			String textOutPutTdAriaDescribedby, String searchText);
	public boolean clickOnCheckBoxGridItem(String gridID,
			String searchText);
	public List<WebElement> waitForGridAllDuplicateCellText(
			String tdAriaDescribedby);

	public boolean checkGridEmpty(String gridID, String gridPagerID);

	public void clickOnGridAction(String tdAriaDescribedby, String searchText,
			String actionLink);

	public void waitForGridSearchText(String searchText);

	public boolean waitForGridAction(String searchText, String actionLink);
	
	public void clickOnGridAction(String searchText, String actionLink);
	
	public int countGridAllRows(String gridID, String tdAriaDescribedby);
	
	public String getGridCellData(String gridID, String inputIdAriaDescribedby, String inputText, String outputIdAriaDescribedby);
	
	
}
