package com.atk.himma.pageobjects.mbuadmin.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.master.tabs.StoreTypeDetailsTab;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.StoreTypeMBUListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class StoreTypePage extends DriverWaitClass implements StatusMessages {

	private StoreTypeMBUListTab storeTypeMBUListTab;
	private StoreTypeDetailsTab storeTypeDetailsTab;

	public final static String PAGETITLE_ID = "PAGE_TITLE";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Store Type')]";
	
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		storeTypeMBUListTab = PageFactory.initElements(webDriver,
				StoreTypeMBUListTab.class);
		storeTypeMBUListTab.setWebDriver(webDriver);
		storeTypeMBUListTab.setWebDriverWait(webDriverWait);

		storeTypeDetailsTab = PageFactory.initElements(webDriver,
				StoreTypeDetailsTab.class);
		storeTypeDetailsTab.setWebDriver(webDriver);
		storeTypeDetailsTab.setWebDriverWait(webDriverWait);
	}

	public StoreTypePage clickOnStoreTypeMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Store Type");
		StoreTypePage storeTypePage = PageFactory.initElements(webDriver,
				StoreTypePage.class);
		storeTypePage.setWebDriver(webDriver);
		storeTypePage.setWebDriverWait(webDriverWait);
		return storeTypePage;
	}

	public String searchVisitCategory(String[] storeTypeData)
			throws InterruptedException {
		waitForElementId(StoreTypeMBUListTab.FORM_ID);
		waitForElementId(StoreTypeMBUListTab.GRID_ID);
		storeTypeMBUListTab.getMbuName().clear();
		storeTypeMBUListTab.getMbuName().sendKeys(storeTypeData[0]);
		storeTypeMBUListTab.getSearchButton().click();
		waitForElementId(StoreTypeMBUListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(StoreTypeMBUListTab.GRID_ID,
				StoreTypeMBUListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY,
				storeTypeData[0].trim());
	}

	public String clickOnEditLink(String[] storeTypeData) {
		clickOnGridAction(storeTypeData[0].trim(), "Edit");
		waitForElementId(StoreTypeDetailsTab.GRID_ID);
		waitForElementXpathExpression(StoreTypeDetailsTab.SAVEBUTTON_XPATH);
		waitForElementName(StoreTypeDetailsTab.MBUNAME_NAME);
		return storeTypeDetailsTab.getMbuName().getAttribute("value").trim();
	}

	public String clickOnAddRecordGridButton() throws InterruptedException {
		waitForElementId(StoreTypeDetailsTab.GRID_ID);
		sleepShort();
		storeTypeDetailsTab.getAddRecordGridButton().click();
		waitForElementId(StoreTypeDetailsTab.POPUPTITLE_ID);
		return storeTypeDetailsTab.getPopUpTitle().getText().trim();
	}

	public String saveVisitCategory(String[] storeTypeData)
			throws InterruptedException {
		waitForElementId(StoreTypeDetailsTab.POPUPTITLE_ID);
		new Select(storeTypeDetailsTab.getStoreType())
				.selectByVisibleText(storeTypeData[1].trim());
		String[] str = storeTypeData[2].split("\\,");
		List<WebElement> allItemCategory = webDriver.findElements(By
				.name(StoreTypeDetailsTab.ITEMCATEGORIES_NAME));
		for (WebElement we : allItemCategory)
			storeTypeDetailsTab.unSelectItemCategory(we);
		for (int i = 0; i < str.length; i++)
			storeTypeDetailsTab.clickOnItemCategory(str[i].trim());
		storeTypeDetailsTab.getSubmitButtonPopup().click();
		waitForGridSearchText(storeTypeData[1].trim());
		storeTypeDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		sleepShort();
		return statusMessage.getText().trim();
	}

	public String editVisitCategory(String[] storeTypeData)
			throws InterruptedException {
		waitForElementId(StoreTypeDetailsTab.GRID_ID);
		webDriver.findElement(
				By.xpath(".//td[@title='" + storeTypeData[1].trim().trim()
						+ "']/..//a[@title='Edit']")).click();
		new Select(storeTypeDetailsTab.getStoreType())
				.selectByVisibleText(storeTypeData[1].trim());
		String[] str = storeTypeData[2].split("\\,");
		List<WebElement> allItemCategory = webDriver.findElements(By
				.name(StoreTypeDetailsTab.ITEMCATEGORIES_NAME));
		for (WebElement we : allItemCategory)
			storeTypeDetailsTab.unSelectItemCategory(we);
		for (int i = 0; i < str.length; i++)
			storeTypeDetailsTab.clickOnItemCategory(str[i]);
		storeTypeDetailsTab.getUpdateButtonPopup().click();
		waitForGridSearchText(storeTypeData[1].trim());
		storeTypeDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		sleepShort();
		return statusMessage.getText().trim();
	}

	public String cancelVisitCategory(String[] storeTypeData)
			throws InterruptedException {
		waitForElementId(StoreTypeMBUListTab.GRID_ID);
		storeTypeDetailsTab.getCancelButton().click();
		waitForElementId(StoreTypeDetailsTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(StoreTypeMBUListTab.GRID_ID,
				StoreTypeMBUListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY,
				storeTypeData[0].trim()).trim();

	}

	/**
	 * @return the storeTypeMBUListTab
	 */
	public StoreTypeMBUListTab getStoreTypeMBUListTab() {
		return storeTypeMBUListTab;
	}

	/**
	 * @return the storeTypeDetailsTab
	 */
	public StoreTypeDetailsTab getStoreTypeDetailsTab() {
		return storeTypeDetailsTab;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

}
