package com.atk.himma.pageobjects.mbuadmin.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.master.tabs.LocationCategoryDetailsTab;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.LocationCategoryMBUListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class LocationCategoryPage extends DriverWaitClass implements
		StatusMessages {

	private LocationCategoryMBUListTab locationCategoryMBUListTab;
	private LocationCategoryDetailsTab locationCategoryDetailsTab;

	public final static String PAGETITLE_ID = "PAGE_TITLE";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Location Category')]";
	
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		locationCategoryMBUListTab = PageFactory.initElements(webDriver,
				LocationCategoryMBUListTab.class);
		locationCategoryMBUListTab.setWebDriver(webDriver);
		locationCategoryMBUListTab.setWebDriverWait(webDriverWait);

		locationCategoryDetailsTab = PageFactory.initElements(webDriver,
				LocationCategoryDetailsTab.class);
		locationCategoryDetailsTab.setWebDriver(webDriver);
		locationCategoryDetailsTab.setWebDriverWait(webDriverWait);
	}

	public LocationCategoryPage clickOnLocationCategoryMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Location Category");
		LocationCategoryPage locationCategoryPage = PageFactory.initElements(
				webDriver, LocationCategoryPage.class);
		locationCategoryPage.setWebDriver(webDriver);
		locationCategoryPage.setWebDriverWait(webDriverWait);
		return locationCategoryPage;
	}

	public String searchLocationCategory(String[] locationCategoryData)
			throws InterruptedException {
		waitForElementId(LocationCategoryMBUListTab.FORM_ID);
		waitForElementId(LocationCategoryMBUListTab.GRID_ID);
		locationCategoryMBUListTab.getMbuName().clear();
		locationCategoryMBUListTab.getMbuName().sendKeys(
				locationCategoryData[0]);
		locationCategoryMBUListTab.getSearchButton().click();
		waitForElementId(LocationCategoryMBUListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(LocationCategoryMBUListTab.GRID_ID,
				LocationCategoryMBUListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY,
				locationCategoryData[0].trim());
	}

	public String clickOnEditLink(String[] locationCategoryData) {
		clickOnGridAction(locationCategoryData[0].trim(), "Edit");
		waitForElementName(LocationCategoryDetailsTab.APPLLOCCAT_NAME);
		waitForElementXpathExpression(LocationCategoryDetailsTab.SAVEBUTTON_XPATH);
		return locationCategoryDetailsTab.getMbuName().getAttribute("value")
				.trim();
	}

	public String saveLocationCategory(String[] locationCategoryData)
			throws InterruptedException {
		waitForElementXpathExpression(LocationCategoryDetailsTab.SAVEBUTTON_XPATH);
		String[] str = locationCategoryData[1].split("\\,");
		List<WebElement> allApplCategory = webDriver.findElements(By
				.name(LocationCategoryDetailsTab.APPLLOCCAT_NAME));
		for (WebElement we : allApplCategory)
			locationCategoryDetailsTab.unSelectApplicableLocationCategory(we);
		for (int i = 0; i < str.length; i++)

			locationCategoryDetailsTab.clickOnApplicableLocationCategory(str[i]
					.trim());
		locationCategoryDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		return statusMessage.getText().trim();
	}

	public String cancelLocationCategory(String[] locationCategoryData)
			throws InterruptedException {
		waitForElementXpathExpression(LocationCategoryDetailsTab.CANCELBUTTON_XPATH);
		String[] str = locationCategoryData[1].split("\\,");
		List<WebElement> allApplCategory = webDriver.findElements(By
				.name(LocationCategoryDetailsTab.APPLLOCCAT_NAME));
		for (WebElement we : allApplCategory)
			locationCategoryDetailsTab.unSelectApplicableLocationCategory(we);
		for (int i = 0; i < str.length; i++)
			locationCategoryDetailsTab.clickOnApplicableLocationCategory(str[i]
					.trim());
		locationCategoryDetailsTab.getCancelButton().click();
		waitForElementId(LocationCategoryMBUListTab.GRID_ID);
		return waitAndGetGridFirstCellText(LocationCategoryMBUListTab.GRID_ID,
				LocationCategoryMBUListTab.GRID_MBUNAME_ARIA_DESCRIBEDBY,
				locationCategoryData[0].trim());
	}

	/**
	 * @return the locationCategoryMBUListTab
	 */
	public LocationCategoryMBUListTab getLocationCategoryMBUListTab() {
		return locationCategoryMBUListTab;
	}

	/**
	 * @param locationCategoryMBUListTab
	 *            the locationCategoryMBUListTab to set
	 */
	public void setLocationCategoryMBUListTab(
			LocationCategoryMBUListTab locationCategoryMBUListTab) {
		this.locationCategoryMBUListTab = locationCategoryMBUListTab;
	}

	/**
	 * @return the locationCategoryDetailsTab
	 */
	public LocationCategoryDetailsTab getLocationCategoryDetailsTab() {
		return locationCategoryDetailsTab;
	}

	/**
	 * @param locationCategoryDetailsTab
	 *            the locationCategoryDetailsTab to set
	 */
	public void setLocationCategoryDetailsTab(
			LocationCategoryDetailsTab locationCategoryDetailsTab) {
		this.locationCategoryDetailsTab = locationCategoryDetailsTab;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @param pageTitle
	 *            the pageTitle to set
	 */
	public void setPageTitle(WebElement pageTitle) {
		this.pageTitle = pageTitle;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
