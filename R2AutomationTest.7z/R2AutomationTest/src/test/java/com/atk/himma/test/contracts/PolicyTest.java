package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.contracts.PolicyPage;
import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.AssociatedClassesSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.PolicyDocumentScanSection;
import com.atk.himma.pageobjects.contracts.sections.policydetails.PolicyGeneralParametersSection;
import com.atk.himma.pageobjects.contracts.tabs.PolicyListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class PolicyTest extends SeleniumDriverSetup {
	PolicyPage policyPage;
	List<String[]> policyList;
	List<String[]> agrmntList;
	List<String[]> serviceExclusionList;
	List<String[]> icdExclusionList;
	List<String[]> itemExclusionList;
	List<String[]> serviceApprvlList;
	List<String[]> icdApprvlList;
	List<String[]> itemApprvlList;

	@Test(description = "Open Policy Page")
	public void test001OpenPolicyPage() throws Exception {
		policyPage = PageFactory.initElements(webDriver, PolicyPage.class);
		policyPage = policyPage.clickOnPolicyMenu(webDriver, webDriverWait);
		policyPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		policyList = excelReader.read(properties.getProperty("policy"));
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		icdExclusionList = excelReader.read(properties
				.getProperty("ICDExcListDetails"));
		itemExclusionList = excelReader.read(properties
				.getProperty("itemExcListDetails"));
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		icdApprvlList = excelReader.read(properties
				.getProperty("ICDApprvListDetails"));
		itemApprvlList = excelReader.read(properties
				.getProperty("itemApprvListDetails"));
		agrmntList = excelReader
				.read(properties.getProperty("debtorAgreement"));

		Assert.assertNotNull(policyPage);
		policyPage.waitForElementVisibilityOf(policyPage.getPolicyListTab()
				.getPolicyListForm());
		policyPage.waitForElementVisibilityOf(policyPage.getPolicyListTab()
				.getMbuList());
		Assert.assertTrue(policyPage.getPolicyListTab().getMbuList()
				.isDisplayed());

	}

	@Test(description = "Check For Add New Policy Button", dependsOnMethods = { "test001OpenPolicyPage" })
	public void test002CheckForAddNewPolicyBtn() throws Exception {
		Assert.assertTrue(policyPage.getPolicyListTab().getAddNewPolicyBtn()
				.isDisplayed());
	}

	@Test(description = "Click On Add New Policy Button", dependsOnMethods = { "test002CheckForAddNewPolicyBtn" })
	public void test003ClickOnAddNewPolicyBtn() throws Exception {
		policyPage.getPolicyListTab().clickAddNewPolicy();
		policyPage
				.waitForElementVisibilityOf(policyPage.getPolicyDetailsForm());
		policyPage.waitForElementVisibilityOf(policyPage
				.getPolicyDetailsFirstSection().getPolicyName());
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.getPolicyName().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Policy Reference Num Field", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test004ValidatePolicyRefNumMandatoryField() throws Exception {
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.isMandPolicyRefNum());

	}

	@Test(description = "Validate Mandatory for Policy Type Field", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test005ValidatePolicyTypeMandatoryField() throws Exception {
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.isMandPolicyType());

	}

	@Test(description = "Validate Mandatory for Policy Name Field", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test006ValidatePolicyNameMandatoryField() throws Exception {
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.isMandPolicyName());

	}

	@Test(description = "Validate Mandatory for Debtor Name Field", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test007ValidateDebtorNameMandatoryField() throws Exception {
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.isMandDebtorName());

	}

	@Test(description = "Validate Mandatory for Agreement Field", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test008ValidateAgreementNameMandatoryField() throws Exception {
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.isMandAgreementName());

	}

	@Test(description = "Validate Mandatory for MBU Name Field", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test009ValidateMBUMandatoryField() throws Exception {
		Assert.assertTrue(policyPage.getPolicyDetailsFirstSection()
				.isMandMBUName());

	}

	@Test(description = "Fill Policy First Section Fields", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test010AddPolicyFirstSectionData() throws Exception {
		if (policyList != null && !policyList.isEmpty()) {
			for (String[] policyListData : policyList.subList(0, 1)) {
				policyPage.getPolicyDetailsFirstSection().fillData(
						policyListData);
				Assert.assertEquals(policyPage.getPolicyDetailsFirstSection()
						.getSelectedMBU(), policyListData[9]);

			}
		}

	}

	@Test(description = "Fill Policy Documentt Section Fields", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test011AddPolicyDocSectionData() throws Exception {
		if (policyList != null && !policyList.isEmpty()) {
			for (String[] policyListData : policyList.subList(0, 1)) {
				policyPage.getPolicyDocumentScanSection().addPolicyDocsData(
						policyListData);
				Assert.assertTrue(policyPage.getPolicyDocumentScanSection()
						.checkPolicyDocGrid(policyListData));

			}
		}

	}

	@Test(description = "Fill Policy General Parameters Section Fields", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test012AddPolicyGeneralParamSectionData() throws Exception {
		if (policyList != null && !policyList.isEmpty()) {
			for (String[] policyListData : policyList.subList(0, 1)) {
				policyPage.getPolicyGeneralParametersSection()
						.addPolicyGeneralParamData(policyListData);

			}
		}

	}

	@Test(description = "Expand Exclusion List Details Section", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test013ExpandExclusionListDetailsSection() throws Exception {
		policyPage.collapseExpandExcSection();
		Assert.assertTrue(policyPage.getExcSectionDiv().isDisplayed());

	}

	@Test(description = "Expand Approval List Details Section", dependsOnMethods = { "test003ClickOnAddNewPolicyBtn" })
	public void test014ExpandApprovalListDetailsSection() throws Exception {
		policyPage.collapseExpandApprvlSection();
		Assert.assertTrue(policyPage.getApprvlSectionDiv().isDisplayed());

	}

	@Test(description = "Add Service Pattern Exclusion List Details", dependsOnMethods = { "test013ExpandExclusionListDetailsSection" })
	public void test0015AddServiceExclusionListDetailsData() throws Exception {
		if (serviceExclusionList != null && !serviceExclusionList.isEmpty()) {
			for (String[] serviceExclusionListData : serviceExclusionList
					.subList(3, 4)) {
				policyPage.getExclusionListDetailsSection()
						.addServiceExclusionData(serviceExclusionListData);
				Assert.assertEquals(policyPage.getExclusionListDetailsSection()
						.getServiceLvlName().getAttribute("value"),
						serviceExclusionListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Exclusion List Details", dependsOnMethods = { "test013ExpandExclusionListDetailsSection" })
	public void test0016AddICDExclusionListDetailsData() throws Exception {
		if (icdExclusionList != null && !icdExclusionList.isEmpty()) {
			for (String[] icdExclusionListData : icdExclusionList.subList(3, 4)) {
				policyPage.getExclusionListDetailsSection()
						.addICDExclusionData(icdExclusionListData);
				Assert.assertEquals(policyPage.getExclusionListDetailsSection()
						.getIcdPatternDesc().getAttribute("value"),
						icdExclusionListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Exclusion List Details", dependsOnMethods = { "test013ExpandExclusionListDetailsSection" })
	public void test0017AddItemExclusionListDetailsData() throws Exception {
		if (itemExclusionList != null && !itemExclusionList.isEmpty()) {
			for (String[] itemExclusionListData : itemExclusionList.subList(2,
					3)) {
				policyPage.getExclusionListDetailsSection()
						.addItemExclusionData(itemExclusionListData);
				Assert.assertEquals(policyPage.getExclusionListDetailsSection()
						.checkItemLevelData(itemExclusionListData),
						itemExclusionListData[1]);
			}
		}
	}

	@Test(description = "Add Service Pattern Approval List Details", dependsOnMethods = { "test014ExpandApprovalListDetailsSection" })
	public void test018AddServiceApprovalListDetailsData() throws Exception {
		if (serviceApprvlList != null && !serviceApprvlList.isEmpty()) {
			for (String[] serviceApprvlListData : serviceApprvlList.subList(3,
					4)) {
				policyPage.getApprovalListDetailsSection()
						.addServiceApprvlData(serviceApprvlListData);
				Assert.assertEquals(policyPage.getApprovalListDetailsSection()
						.getServiceLvlName().getAttribute("value"),
						serviceApprvlListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Approval List Details", dependsOnMethods = { "test014ExpandApprovalListDetailsSection" })
	public void test019AddICDApprvlListDetailsData() throws Exception {
		if (icdApprvlList != null && !icdApprvlList.isEmpty()) {
			for (String[] icdApprvlListData : icdApprvlList.subList(3, 4)) {
				policyPage.getApprovalListDetailsSection().addICDApprvlData(
						icdApprvlListData);
				Assert.assertEquals(policyPage.getApprovalListDetailsSection()
						.getIcdDescription().getAttribute("value"),
						icdApprvlListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Approval List Details", dependsOnMethods = { "test014ExpandApprovalListDetailsSection" })
	public void test020AddItemApprvlListDetailsData() throws Exception {
		if (itemApprvlList != null && !itemApprvlList.isEmpty()) {
			for (String[] itemApprvlListData : itemApprvlList.subList(3, 4)) {
				policyPage.getApprovalListDetailsSection().addItemApprvlData(
						itemApprvlListData);
				Assert.assertEquals(policyPage.getApprovalListDetailsSection()
						.checkItemLevelData(itemApprvlListData),
						itemApprvlListData[1]);
			}
		}
	}

	@Test(description = "Save Policy", dependsOnMethods = { "test010AddPolicyFirstSectionData" })
	public void test021SavePolicyDetails() throws Exception {
		policyPage.savePolicy();
		Assert.assertTrue(policyPage.getUpdateBtn().isEnabled()
				&& policyPage.getAddNewBtn().isEnabled());
	}

	@Test(description = "Activate Record", dependsOnMethods = { "test021SavePolicyDetails" })
	public void test022ActivateRecord() throws Exception {
		Assert.assertEquals(policyPage.activateRecord().contains("Active"),
				true, "Failed Activate Record");

	}

	@Test(description = "Verify Policy Associated to Debtor Agreement", dependsOnMethods = { "test022ActivateRecord" })
	public void test023VerifyDebtorAgrmntAssociatedPolicy() throws Exception {
		if (policyList != null && !policyList.isEmpty()) {
			policyPage.clickOnGoToPolicyBtn();
			for (String[] policyListData : policyList.subList(0, 1)) {
				Assert.assertTrue(policyPage
						.verifyDebtorAgrmntAssociatedPolicy(policyListData));

			}
		}

	}

	@Test(description = "Apply Exclusion List to Policy", dependsOnMethods = { "test023VerifyDebtorAgrmntAssociatedPolicy" })
	public void test024ApplyExcListToPolicy() throws Exception {
		policyPage.collapseExpandAgreementExcSection();
		for (String[] agrmntData : agrmntList.subList(0, 1)) {
			policyPage.getExclusionListDetailsSection().applyExcListToPolicies(
					agrmntData);
		}

	}

	@Test(description = "Apply Approval List to Policy", dependsOnMethods = { "test023VerifyDebtorAgrmntAssociatedPolicy" })
	public void test025ApplyApprvlListToPolicy() throws Exception {
		policyPage.collapseExpandAgreementApprvlSection();
		for (String[] agrmntData : agrmntList.subList(0, 1)) {
			policyPage.getApprovalListDetailsSection()
					.applyApprvlListToPolicies(agrmntData);
		}

	}

	@Test(description = "Update Agreement Details", dependsOnMethods = { "test023VerifyDebtorAgrmntAssociatedPolicy" })
	public void test026UpdateAgreementDetails() throws Exception {
		policyPage.updateAgreementDetails();
	}

	@Test(description = "Search Policy", dependsOnMethods = { "test023VerifyDebtorAgrmntAssociatedPolicy" })
	public void test027SearchPolicy() throws Exception {
		policyPage.clickOnPolicyMenu(webDriver, webDriverWait);
		for (String[] policyListData : policyList.subList(0, 1)) {
			policyPage.getPolicyListTab().searchPolicy(policyListData);
		}

	}

	@Test(description = "Verify Agreement Exclusion List Details in Policy", dependsOnMethods = { "test027SearchPolicy" })
	public void test028VerifyAgreementExcListInPolicy() throws Exception {
		for (String[] serviceExcListData : serviceExclusionList.subList(2, 3)) {
			policyPage.collapseExpandExcSection();
			Assert.assertTrue(policyPage.getExclusionListDetailsSection()
					.checkExcGrid(serviceExcListData));
		}

	}

	@Test(description = "Verify Agreement Approval List Details in Policy", dependsOnMethods = { "test027SearchPolicy" })
	public void test029VerifyAgreementApprvlListInPolicy() throws Exception {
		for (String[] serviceApprvlListData : serviceApprvlList.subList(2, 3)) {
			policyPage.collapseExpandApprvlSection();
			Assert.assertTrue(policyPage.getApprovalListDetailsSection()
					.checkApprvlGrid(serviceApprvlListData));

		}

	}

	@Test(description = "Verify Policy Name in Class Creation", dependsOnMethods = { "test027SearchPolicy" })
	public void test030VerifyPolicyName() throws Exception {
		policyPage.clickCreateNewClassBtn();
		for (String[] policyListData : policyList.subList(0, 1)) {
			Assert.assertEquals(policyPage.verifyPolicy(policyListData),
					policyListData[2]);
		}

	}

	// [Policy] Open Form
	@Test(description = "Check Policy Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckPolicyPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		policyPage = PageFactory.initElements(webDriver, PolicyPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> polParentMenuList = new LinkedList<String>();
		polParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(polParentMenuList, "Policy");
		policyPage.setWebDriver(webDriver);
		policyPage.setWebDriverWait(webDriverWait);
		policyPage.waitForElementXpathExpression(PolicyPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy").get("[Policy] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PolicyPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Policy] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			policyPage = policyPage.clickOnPolicyMenu(webDriver, webDriverWait);
			policyPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(policyPage);
			policyPage.waitForElementVisibilityOf(policyPage.getPolicyListTab()
					.getPolicyListForm());
			policyPage.sleepShort();
			Assert.assertEquals(policyPage.getPageTitle().getText(), "Policy");
		}

	}

	// [List Tab] Add New Policy (Button)
	@Test(description = "Check Add New Policy Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckPolicyPageMenuLink")
	public void test02CheckAddNewPolicyBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[List Tab] Add New Policy (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PolicyListTab.ADDNEWPOLICYBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Add New Policy (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link in Policy List grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckPolicyPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		policyList = excelReader.read(properties.getProperty("policy"));
		for (String[] policyData : policyList) {
			policyPage.getPolicyListTab().searchPolicyList(policyData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PolicyListTab.VIEWPOLLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link in Policy List grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckPolicyPageMenuLink")
	public void test04CheckLink2Delete() throws Exception {
		policyList = excelReader.read(properties.getProperty("policy"));
		for (String[] policyData : policyList) {
			policyPage.getPolicyListTab().searchPolicyList(policyData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PolicyListTab.DELPOLLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link in Policy List grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckPolicyPageMenuLink")
	public void test05CheckLink3Edit() throws Exception {
		policyList = excelReader.read(properties.getProperty("policy"));
		for (String[] policyData : policyList) {
			policyPage.getPolicyListTab().searchPolicyList(policyData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PolicyListTab.EDITPOLLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		policyPage.getPolicyListTab().clickEditPolLink(policyList.get(0));
	}

	// [Details Tab][Section: Agreement Documents Scan] View
	@Test(description = "Check Agreement Doc Scan Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test06CheckAgrmntDocScanSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[Details Tab][Section: Agreement Documents Scan] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(PolicyDocumentScanSection.POLDOCSCANSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Agreement Documents Scan] View privilege");
	}

	// [Details Tab][Section: Policy Document Scan] Add Document (Button)
	@Test(description = "Check Agreement Doc Scan Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckAgrmntDocScanSec")
	public void test11CheckAddDocBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy Document Scan] Add Document (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PolicyDocumentScanSection.ADDROWPOLBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy Document Scan] Add Document (Button) privilege");
	}

	// [Details Tab][Section: Policy Document Scan] View Document (Link in the
	// grid)
	@Test(description = "Check View Document Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckAgrmntDocScanSec")
	public void test12CheckViewDocLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy Document Scan] View Document (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(PolicyDocumentScanSection.VIEWDOCLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy Document Scan] View Document (Link in the grid) privilege");
	}

	// [Details Tab][Section: Policy Document Scan] Delete Document (Link in the
	// grid)
	@Test(description = "Check Delete Document Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckAgrmntDocScanSec")
	public void test13CheckDeleteDocLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy Document Scan] Delete Document (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(PolicyDocumentScanSection.DELETEDOCLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy Document Scan] Delete Document (Link in the grid) privilege");
	}

	// [Details Tab][Section: Associated Classes] View
	@Test(description = "Check Associated Classes Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test07CheckAssociatedClassesSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[Details Tab][Section: Associated Classes] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(AssociatedClassesSection.ASSOCIATEDCLSSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Associated Classes] View privilege");
	}

	// [Details Tab][Section: Policy General Parameters] View
	@Test(description = "Check Policy General Parameters Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test08CheckPolGenParamSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[Details Tab][Section: Policy General Parameters] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(PolicyGeneralParametersSection.POLGENPARAMSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy General Parameters] View privilege");
	}

	// [Details Tab][Section: Policy General Parameters] Visit Coverage (Check
	// box group)
	@Test(description = "Check Visit Coverage Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckPolGenParamSec")
	public void test14CheckVisitCoverageChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy General Parameters] Visit Coverage (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PolicyGeneralParametersSection.VISITCOVERAGECHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy General Parameters] Visit Coverage (Check box group) privilege");
	}

	// [Details Tab][Section: Policy General Parameters] Age Coverage Limit
	// (Check box group)
	@Test(description = "Check Age Coverage Limit Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckPolGenParamSec")
	public void test15CheckAgeCoverageChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy General Parameters] Age Coverage Limit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PolicyGeneralParametersSection.AGECOVLIMITCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy General Parameters] Age Coverage Limit (Check box group) privilege");
	}

	// [Details Tab][Section: Policy General Parameters] Policy Credit Limit
	// (Check box group)
	@Test(description = "Check Policy Credit Limit Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckPolGenParamSec")
	public void test16CheckPolCreditLimitChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy General Parameters] Policy Credit Limit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PolicyGeneralParametersSection.POLICYCDTLIMITCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy General Parameters] Policy Credit Limit (Check box group) privilege");
	}

	// [Details Tab][Section: Policy General Parameters] Credit Limit Duration
	// (Check box group)
	@Test(description = "Check Credit Limit Duration Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckPolGenParamSec")
	public void test17CheckCreditLimitDurChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy General Parameters] Credit Limit Duration (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PolicyGeneralParametersSection.CDTLIMITDURCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy General Parameters] Credit Limit Duration (Check box group) privilege");
	}

	// [Details Tab][Section: Policy General Parameters] Apply the Above Policy
	// General Parameters To (Check box group)
	@Test(description = "Check Apply the Above Policy General Param To Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckPolGenParamSec")
	public void test18CheckApplyAboveGenParamToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Policy General Parameters] Apply the Above Policy General Parameters To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(PolicyGeneralParametersSection.APPLYPARAMTOCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Policy General Parameters] Apply the Above Policy General Parameters To (Check box group) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] View
	@Test(description = "Check Exclusion List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test09CheckExcListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[Details Tab][Section: Exclusion List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ExclusionListDetailsSection.EXCLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] View privilege");
		if (actualPrivilage)
			policyPage.collapseExpandExcSection();
	}

	// [Details Tab][Section: Exclusion List Details] Add Record (Button)
	@Test(description = "Check Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test19CheckExcAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Exclusion List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Edit Record (Inline
	// editing in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test20CheckExcInlineEditRecord() throws Exception {
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		policyPage.getExclusionListDetailsSection().clickExcListRecord(
				serviceExclusionList.get(3));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.name(ExclusionListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link In Exc Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test21CheckDelLinkInExcGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVEXCDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Apply the Above Exclusion
	// List To (Check box group)
	@Test(description = "Check Apply the Above Exclusion List to Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test22CheckApplyExcListToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Exclusion List Details] Apply the Above Exclusion List To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ExclusionListDetailsSection.APPLYEXCLISTTOCLASSCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Apply the Above Exclusion List To (Check box group) privilege");
	}

	// [Details Tab][Section: Approval List Details] View
	@Test(description = "Check Approval List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test10CheckApprvlListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Policy")
				.get("[Details Tab][Section: Approval List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ApprovalListDetailsSection.APPRVLLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] View privilege");
		if (actualPrivilage)
			policyPage.collapseExpandApprvlSection();
	}

	// [Details Tab][Section: Approval List Details] Add Record (Button)
	@Test(description = "Check Approval List Details Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test23CheckAppAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Approval List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Approval List Details] Edit Record (Inline editing
	// in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test24CheckInlineEditRecord() throws Exception {
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		policyPage.getApprovalListDetailsSection().clickApprvlListRecord(
				serviceApprvlList.get(3));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.name(ApprovalListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link in Approval List Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test25CheckDelLinkInApprvlGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Approval List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVAPPRVLDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Apply the Above Approval
	// List To (Check box group)
	@Test(description = "Check Apply the Above Approval List to Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test26CheckApplyApprvlToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Policy")
				.get("[Details Tab][Section: Approval List Details] Apply the Above Approval List To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ApprovalListDetailsSection.APPLYAPPRVLLISTTOCLSCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Apply the Above Approval List To (Check box group) privilege");
	}

	// [Details Tab][Section: Applicable Main Business Units] View

	// [Details Tab][Section: Audit Trail] View

}
