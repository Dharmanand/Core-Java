package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class DebtorAgreementListTab extends DriverWaitClass {
	public final static String DEBTORAGRMNTLISTFORM_ID = "DEBATOR_AGRMNT_LIST_FORM";
	public final static String ADDNEWAGRMNTBTN_ID = "ADD_NEW_AGREEMENT_BTN";
	public final static String MBULIST_ID = "SEARCH_AGMNT_MBU";
	public final static String GLOBALDEBTORCHKBOX_ID = "AGR_GLOBAL_CHBOX";
	public final static String DEBTORTYPE_ID = "SEARCH_AGMNT_DTYPE";
	public final static String AGRMNTSIGNYR_ID = "SEARCH_AGMNT_SNYEAR";
	public final static String AGRMNTEXPYR_ID = "SEARCH_AGMNT_EXYEAR";
	public final static String AGRMNTREFCODE_ID = "SEARCH_AGMNT_REFCODE";
	public final static String DEBTORNAME_ID = "SEARCH_AGMNT_DNAME";
	public final static String STATUS_ID = "SEARCH_AGMNT_STATUS";
	public final static String DEBTOR_ID = "SEARCH_AGMNT_DCODE";
	public final static String AGRMNTSEARCHBTN_ID = "DEBT_AGMNT_SEARCH";
	public final static String AGRMNTRESETBTN_ID = "RESET_DEBT_AGMNT_LIST";
	public final static String AGRMNTGRIDDIV_ID = "DEBT_AGMNT_SEARCH_GRID";
	public final static String VIEWLINK_XPATH = ".//table[@id='DEBT_AGMNT_LIST']/..//a[text()='View']";
	public final static String EDITLINK_XPATH = ".//table[@id='DEBT_AGMNT_LIST']/..//a[text()='Edit']";
	public final static String DELETELINK_XPATH = ".//table[@id='DEBT_AGMNT_LIST']/..//a[text()='Delete']";

	@FindBy(id = DEBTORAGRMNTLISTFORM_ID)
	private WebElement debtorAgrmntListForm;

	@FindBy(id = ADDNEWAGRMNTBTN_ID)
	private WebElement addNewAgrmntBtn;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALDEBTORCHKBOX_ID)
	private WebElement globalAgrmntChkBox;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = AGRMNTSIGNYR_ID)
	private WebElement agrmntSignYr;

	@FindBy(id = AGRMNTEXPYR_ID)
	private WebElement agrmntExpYr;

	@FindBy(id = AGRMNTREFCODE_ID)
	private WebElement agrmntRefCode;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(id = DEBTOR_ID)
	private WebElement debtorCode;

	@FindBy(id = AGRMNTSEARCHBTN_ID)
	private WebElement agrmntSearchBtn;

	@FindBy(id = AGRMNTRESETBTN_ID)
	private WebElement agrmntResetBtn;

	@FindBy(id = AGRMNTGRIDDIV_ID)
	private WebElement agrmntGridDiv;

	@FindBy(xpath = VIEWLINK_XPATH)
	private WebElement viewLink;

	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public void clickAddNewDebtorAgrmnt() throws Exception {
		addNewAgrmntBtn.click();
		sleepShort();

	}

	public void searchDebtorAgreement(String[] debtorAgrmntListData)
			throws Exception {
		waitForPageLoaded(webDriver);
		sleepShort();
		if (!debtorAgrmntListData[3].isEmpty()) {
			new Select(mbuList).selectByVisibleText(debtorAgrmntListData[3]);
		}
		agrmntRefCode.clear();
		agrmntRefCode.sendKeys(debtorAgrmntListData[0]);

		if (!debtorAgrmntListData[7].isEmpty()) {
			new Select(debtorName).selectByVisibleText(debtorAgrmntListData[7]);
		}
		agrmntSearchBtn.click();
		waitForElementId(AGRMNTGRIDDIV_ID);
		clickOnGridAction("DEBT_AGMNT_LIST_agreementName",
				debtorAgrmntListData[9], "Edit");
		waitForPageLoaded(webDriver);
		sleepShort();

	}

	public void searchAgrmntList(String[] debtorAgrmntData) throws Exception {
		if (!debtorAgrmntData[3].isEmpty()) {
			new Select(mbuList).selectByVisibleText(debtorAgrmntData[3]);
		}

		if (Boolean.valueOf(debtorAgrmntData[4])) {
			globalAgrmntChkBox.click();
		}

		if (!debtorAgrmntData[5].isEmpty()) {
			new Select(debtorType).selectByVisibleText(debtorAgrmntData[5]);
		}

		if (!debtorAgrmntData[7].isEmpty()) {
			new Select(debtorName).selectByVisibleText(debtorAgrmntData[7]);
		}
		agrmntRefCode.clear();
		agrmntRefCode.sendKeys(debtorAgrmntData[0]);

		agrmntSearchBtn.click();
		waitForElementId(AGRMNTGRIDDIV_ID);
		sleepShort();

	}
	
	public void clickEditLink(String[] agreementData) throws Exception {
		clickOnGridAction("DEBT_AGMNT_LIST_agreementName", agreementData[9], "Edit");
		sleepShort();
		
	}

	public WebElement getDebtorAgrmntListForm() {
		return debtorAgrmntListForm;
	}

	public WebElement getAddNewAgrmntBtn() {
		return addNewAgrmntBtn;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalAgrmntChkBox() {
		return globalAgrmntChkBox;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getAgrmntSignYr() {
		return agrmntSignYr;
	}

	public WebElement getAgrmntExpYr() {
		return agrmntExpYr;
	}

	public WebElement getAgrmntRefCode() {
		return agrmntRefCode;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getDebtorCode() {
		return debtorCode;
	}

	public WebElement getAgrmntSearchBtn() {
		return agrmntSearchBtn;
	}

	public WebElement getAgrmntResetBtn() {
		return agrmntResetBtn;
	}

	public WebElement getAgrmntGridDiv() {
		return agrmntGridDiv;
	}

	public WebElement getViewLink() {
		return viewLink;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
