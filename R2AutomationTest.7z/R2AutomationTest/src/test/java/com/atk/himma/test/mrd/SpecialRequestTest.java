package com.atk.himma.test.mrd;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mrd.MRDDesktopPage;
import com.atk.himma.pageobjects.mrd.SpecialRequestPage;
import com.atk.himma.pageobjects.mrd.tabs.SpecialRequestList;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class SpecialRequestTest extends SeleniumDriverSetup implements
		StatusMessages, RecordStatus {

	SpecialRequestPage specialRequestPage;
	List<String[]> mrdSpecReqDatas;

	@Test
	public void checkSpecialRequestLink() {

		specialRequestPage = PageFactory.initElements(webDriver,
				SpecialRequestPage.class);
		specialRequestPage = specialRequestPage.checkSpecReqLink(webDriver,
				webDriverWait);
		specialRequestPage
				.waitForElementXpathExpression(MRDDesktopPage.MRDDESKTOPMENULINK_XPATH);
		Assert.assertEquals(specialRequestPage.getSpecialRequest(),
				"Special Request", "Fail to Appear MRD Desktop Link");
	}

	@Test(dependsOnMethods = { "checkMRDDesktopLink" })
	public void clickSpecReqMenuLink() throws Exception {

		specialRequestPage.clickOnSpecReqMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		specialRequestPage.waitForElementId(SpecialRequestList.GRID_ID);
		Assert.assertEquals(specialRequestPage.getPageTitle().getText().trim(),
				"Special Request List", "Fail: to open MRD Desktop page");
		excelReader.setInputFile(properties.getProperty("mrdExcel"));
		mrdSpecReqDatas = excelReader.read(properties
				.getProperty("mrdSpecRequest"));
	}

	@Test
	public void createMRRequest() {

		
		
	}

	@Test
	public void updateMRRequest() {

	}

	@Test
	public void editMRRequest() {

	}

	@Test
	public void addMoreMRVolForSP() {

	}

	@Test
	public void addMoreMRVolForOP() {

	}

	@Test
	public void editMRVolForOP() {

	}

	@Test
	public void editMRVolume() {

	}

	@Test
	public void deleteMRVolume() {

	}

	@Test
	public void viewSpecialRequest() {

	}

	@Test
	public void checkEditInProgMRR() {

	}

	@Test
	public void cancelMRRequest() {

	}

	@Test
	public void quickSearchWOData() {

	}

	@Test
	public void quickSearchWithMRN() {

	}

	@Test
	public void quickSearchWithReqNo() {

	}

	@Test
	public void verifyReset() {

	}

	@Test
	public void searchByAdvSearch() {

	}

	@Test
	public void restInAdvSearch() {

	}

	@Test
	public void VerfySearchByDefaultInSR() {

	}

	// MR Desktop
	
	/*
	 * Send an MR Volume which is requested by the requester and then the
	 * dispatch of which has been canceled by the MRD after dispatching
	 */
	 
	@Test
	public void sendMRVolume() {

	}
	
	/*
	 * Send an MR volume which has been requested in a special request and
	 * having "New" MR status
	 */
	
	@Test
	public void sendMRVolOfNewMR() {
		
	}
	
	/*
	 * MRD can cancel the dispatch of any of the dispatched volume(s) requested
	 * in a special request
	 */
	
	@Test
	public void cancelDispatch() {
		
	}
	
	/*
	 * Receive the MR volume(s) requested in a Special Request which has been
	 * sent from MRD
	 */

	@Test
	public void receiveMRVolume() {
		
	}
	
	/*
	 * Return back the MR volume(s) requested in a Special Request which have
	 * been sent from MRD and then received by the requester
	 */

	@Test
	public void returnBackMRVolume() {
		
	}
	
	
}
