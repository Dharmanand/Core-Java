package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BrandedDrugFirstSection {

	public final String DRUGCODE_NAME = "brandedDrug.brandedDrugCode";
	public final String DRUGSHORTNAME_NAME = "brandedDrug.brandedDrugShortName";
	public final String DRUGNAME_NAME = "brandedDrug.brandedDrugName";
	public final String DRUGARNAME_NAME = "brandedDrug.brandedDrugNameAR";
	public final String DRUGCATEGORY_CSS = "#BRANDED_DRUG_himma_pharmacy_brandedDrug_defaultSection_drugCategory + span > input[type=text]";
	public final String DRUGSUBCAT_CSS = "#BRANDED_DRUG_himma_pharmacy_brandedDrug_defaultSection_drugSubCategory + span > input[type=text]";
	public final String DRUGSTATUS_CSS = "#BRANDED_DRUG_himma_pharmacy_brandedDrug_defaultSection_status + span > input[type=text]";

	@FindBy(name = DRUGCODE_NAME)
	private WebElement drugCode;

	@FindBy(name = DRUGSHORTNAME_NAME)
	private WebElement drugShortName;

	@FindBy(name = DRUGNAME_NAME)
	private WebElement drugName;

	@FindBy(name = DRUGARNAME_NAME)
	private WebElement drugArName;

	@FindBy(css = DRUGCATEGORY_CSS)
	private WebElement drugCategory;

	@FindBy(css = DRUGSUBCAT_CSS)
	private WebElement drugSubCat;

	@FindBy(css = DRUGSTATUS_CSS)
	private WebElement drugStatus;

	/**
	 * @return the drugCode
	 */
	public WebElement getDrugCode() {
		return drugCode;
	}

	/**
	 * @return the drugShortName
	 */
	public WebElement getDrugShortName() {
		return drugShortName;
	}

	/**
	 * @return the drugName
	 */
	public WebElement getDrugName() {
		return drugName;
	}

	/**
	 * @return the drugArName
	 */
	public WebElement getDrugArName() {
		return drugArName;
	}

	/**
	 * @return the drugCategory
	 */
	public WebElement getDrugCategory() {
		return drugCategory;
	}

	/**
	 * @return the drugSubCat
	 */
	public WebElement getDrugSubCat() {
		return drugSubCat;
	}

	/**
	 * @return the drugStatus
	 */
	public WebElement getDrugStatus() {
		return drugStatus;
	}

}
