package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ResourceFeesListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "RESOURCE_FEES_LIST_PAGE";
	public final static String RESOURCEFEESLIST_XPATH = "//a[@title='Resource Fees List']";
	public final static String MBU_ID = "MBU_ID_NAME";
	public final static String DEPARTMENT_ID = "RES_DEP_NAME";
	public final static String RESOURCETYPE_ID = "RES_TYPE_NAME";
	public final static String RESOURCENAME_ID = "RES_NAME";
	public final static String RESOURCECODE_ID = "RES_CODE_NAME";
	public final static String RESOURCECATEGORY_ID = "RES_CAT_NAME";
	public final static String STATUS_ID = "RES_STATUS_NAME";
	public final static String SEARCHBUTTON_XPATH = "(//span[@class='buttoncontainer_lrg_gb']//input[@value='Search'])[1]";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "RESOURCE_NAME_LIST";
	public final static String GRID_RESCODE_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_employeeResource.resourceCode";
	public final static String GRID_FULLNAME_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_employeeResource.resourceName.fullName";
	public final static String GRID_RESOURCETYPE_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_employeeResource.resourceTypeText";
	public final static String GRID_DESIGNATION_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_employeeResource.designationText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_employeeResource.departmentText";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_employeeResource.mbuName";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "RESOURCE_NAME_LIST_resourceFees.recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_RESOURCE_NAME_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_RESOURCE_NAME_LIST_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = RESOURCEFEESLIST_XPATH)
	private WebElement resourceFeesListTab;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = RESOURCETYPE_ID)
	private WebElement resourceType;
	
	@FindBy(id = RESOURCENAME_ID)
	private WebElement resourceName;
	
	@FindBy(id = RESOURCECODE_ID)
	private WebElement resourceCode;
	
	@FindBy(id = RESOURCECATEGORY_ID)
	private WebElement resourceCategory;
	
	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the resourceFeesListTab
	 */
	public WebElement getResourceFeesListTab() {
		return resourceFeesListTab;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the resourceType
	 */
	public WebElement getResourceType() {
		return resourceType;
	}

	/**
	 * @return the resourceName
	 */
	public WebElement getResourceName() {
		return resourceName;
	}

	/**
	 * @return the resourceCode
	 */
	public WebElement getResourceCode() {
		return resourceCode;
	}

	/**
	 * @return the resourceCategory
	 */
	public WebElement getResourceCategory() {
		return resourceCategory;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

}
