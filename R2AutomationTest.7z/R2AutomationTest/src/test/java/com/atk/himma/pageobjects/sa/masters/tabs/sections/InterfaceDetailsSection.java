package com.atk.himma.pageobjects.sa.masters.tabs.sections;

import com.atk.himma.util.DriverWaitClass;

public class InterfaceDetailsSection extends DriverWaitClass{

	
	
}
