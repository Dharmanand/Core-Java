package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.preg.master.IdentificationDocumentPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class IdentificationDocumentTest extends SeleniumDriverSetup {

	List<String[]> identificationDocDatas;
	IdentificationDocumentPage identificationDocumentPage;

	@Test(description = "Open Identification Doc Page")
	public void openIdentificationDocPage() throws InterruptedException {
		identificationDocumentPage = PageFactory.initElements(webDriver,
				IdentificationDocumentPage.class);
		identificationDocumentPage = identificationDocumentPage
				.clickOnIdentificationDocMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(identificationDocumentPage);
		identificationDocumentPage
				.waitForElementXpathExpression(IdentificationDocumentPage.SAVE_XPATH);
		identificationDocumentPage.sleepVeryShort();
		Assert.assertEquals(identificationDocumentPage.getPageTitle().getText()
				.trim(), "Identification Document");
	}

	// [Identification Document Type] Open Form
	@Test(description = "Open Identification Document Type Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkIdenDocMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		identificationDocumentPage = PageFactory.initElements(webDriver,
				IdentificationDocumentPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		baseLVParentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"Identification Document");
		identificationDocumentPage.setWebDriver(webDriver);
		identificationDocumentPage.setWebDriverWait(webDriverWait);
		identificationDocumentPage
				.waitForElementXpathExpression(IdentificationDocumentPage.MENULINK_XPATH);
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("Identification Document Type")
				.get("[Identification Document] Open Form");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(IdentificationDocumentPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Identification Document Type] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			identificationDocumentPage = identificationDocumentPage
					.clickOnIdentificationDocMenu(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(identificationDocumentPage);
			identificationDocumentPage
					.waitForElementXpathExpression(IdentificationDocumentPage.CANCEL_XPATH);
			identificationDocumentPage.sleepShort();
			Assert.assertEquals(identificationDocumentPage.getPageTitle()
					.getText(), "Identification Document");
		}
	}

	@Test(dependsOnMethods = { "openIdentificationDocPage" }, description = "Save Identification Doc Page")
	public void test1SaveIdentDocPage() throws IOException,
			InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		identificationDocDatas = excelReader.read(properties.getProperty("identificationDocument"));
		for (String[] st : identificationDocDatas.subList(0, 2)) {
			Assert.assertEquals(identificationDocumentPage
					.saveIdentificationDocPage(st, webDriver, webDriverWait),
					true, "Fail to Save Identification Document");
		}
	}

	@Test(dependsOnMethods = { "test1SaveIdentDocPage" }, description = "View Identification Doc Page")
	public void test2ViewIdentificationDocPage() throws IOException,
			InterruptedException {
		for (String[] st : identificationDocDatas.subList(0, 2)) {
			Assert.assertEquals(
					identificationDocumentPage.viewRow(st, st[0].trim()), true);
		}
	}

	@Test(dependsOnMethods = { "test1SaveIdentDocPage" }, description = "Edit Identification Doc Page")
	public void test3EditIdentificationDocPage() throws IOException,
			InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		identificationDocDatas = excelReader
				.read(properties.getProperty("updateIdentificationDocument"));
		for (String[] st : identificationDocDatas.subList(1, 2)) {
			String getMsg = identificationDocumentPage
					.editRow(st, st[0].trim());
			if (getMsg.contains("modified successfully.")) {
				Assert.assertTrue(true);
			} else if (getMsg
					.contains("already exist, please try with other name.")) {
				Assert.assertTrue(true);
			} else
				Assert.assertTrue(false);
		}
	}

	@Test(dependsOnMethods = { "test1SaveIdentDocPage" }, groups = { "Delete Identification Document" })
	public void test4DeleteIdentificationDocPage() throws IOException,
			InterruptedException {
		identificationDocDatas = excelReader
				.read(properties.getProperty("updateIdentificationDocument"));
		for (String[] st : identificationDocDatas.subList(1, 2)) {
			String getMsg = identificationDocumentPage.deleteRow(st,
					st[0].trim());
			if (getMsg.contains("deleted successfully.")) {
				Assert.assertTrue(true);
			} else if (getMsg
					.contains("is already in use, you can not delete it.")) {
				Assert.assertTrue(true);
			} else
				Assert.assertTrue(false);
		}
	}
	
	@Test(dependsOnMethods = { "checkIdenDocMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Save Identification Doc Page")
	@Parameters("identDocAction")
	public void saveIdentDocPage(String identDocAction) throws IOException,
			InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		identificationDocDatas = excelReader.read(properties.getProperty("identificationDocument"));
		for (String[] st : identificationDocDatas.subList(3, 4)) {
			if (identDocAction.equalsIgnoreCase("Save"))
				Assert.assertEquals(
						identificationDocumentPage.saveIdentificationDocPage(
								st, webDriver, webDriverWait), true,
						"Fail to Save Identification Document");
			else if (identDocAction.equalsIgnoreCase("Save")
					|| identDocAction.equalsIgnoreCase("Search")) {
				Assert.assertTrue(
						identificationDocumentPage.searchRecord(st[1].trim(), st[0].trim()),
						"Fail to Search");
			}
		}
	}
	
// 	[Identification Document] View (Link in the search result grid)
		@Test(description = "Open Identification Document Add New Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "saveIdentDocPage")
		public void checkViewButtonPrivilege() throws InterruptedException, IOException {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Patient Registration")
					.get("Identification Document Type")
					.get("[Identification Document] View (Link in the search result grid)");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.xpath(".//td[@title='" + identificationDocDatas.subList(3, 4).get(0)[1].trim()
							+ "']/..//a[text()='View']"));
			System.out
			.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Identification Document] View (Link in the search result grid) Form privilege");
		}
	
// 	[Identification Document] Delete(Link in the search result grid)
		@Test(description = "Open Identification Document Delete Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "saveIdentDocPage")
		public void checkDeleteButtonPrivilege() throws InterruptedException, IOException {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Patient Registration")
					.get("Identification Document Type")
					.get("[Identification Document] Delete(Link in the search result grid)");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.xpath(".//td[@title='" + identificationDocDatas.subList(3, 4).get(0)[1].trim()
							+ "']/..//a[text()='Delete']"));
			System.out
			.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Identification Document] Delete(Link in the search result grid) privilege");
		}
		
// 	[Identification Document] Edit (Link in the search result grid)
		@Test(description = "Open Identification Document Edit Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "saveIdentDocPage")
		public void checkEditButtonPrivilege() throws InterruptedException, IOException {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Patient Registration")
					.get("Identification Document Type")
					.get("[Identification Document] Edit (Link in the search result grid)");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.xpath(".//td[@title='" + identificationDocDatas.subList(3, 4).get(0)[1].trim()
							+ "']/..//a[text()='Edit']"));
			System.out
			.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Identification Document] Edit (Link in the search result grid)  privilege");
			if(expectedPrivilage)
			{
				identificationDocumentPage.clickOnGridAction(identificationDocDatas.subList(3, 4).get(0)[1].trim(), "Edit");
				identificationDocumentPage.waitForElementXpathExpression(IdentificationDocumentPage.UPDATEBUTTON_XPATH);
			}
		}
	
// 	[Identification Document] Add New (Button)
		@Test(description = "Open Identification Document Add New Button", groups = { "checkPrivilegesGrp" }, dependsOnMethods = {"saveIdentDocPage", "checkEditButtonPrivilege"})
		public void checkAddNewButtonPrivilege() throws InterruptedException, IOException {
			boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("Patient Registration")
					.get("Identification Document Type")
					.get("[Identification Document] Add New (Button)");
			System.out.println("privFilter----------> " + expectedPrivilage);
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver, By.xpath(IdentificationDocumentPage.ADDNEW_XPATH));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Identification Document] Add New (Button) Form privilege");
		}
}
