package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ClinicListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "CLINIC_LIST";
	public final static String CLINICLISTTAB_XPATH = "//a[@title='Clinic List']";
	public final static String ADDNEWCLINICBUTTON_ID = "ADD_NEW_CLINIC";
	public final static String MBUNAME_ID = "MBU_LIST_TAB1";
	public final static String DEPARTMENT_ID = "DEPARTMENT_LIST_TAB1";
	public final static String CLINICNAME_ID = "clinicName";
	public final static String CLINICCODE_NAME = "searchCriteria.locationCode";
	public final static String SPECAILITY_ID = "SPECAILITY_LIST_TAB1";
	public final static String STATUS_ID = "STATUS_LIST_TAB1";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "clinicResults";
	public final static String GRID_CLINICCODE_ARIA_DESCRIBEDBY = "clinicResults_locationCode";
	public final static String GRID_CLINICNAME_ARIA_DESCRIBEDBY = "mbuGridList_mbuSetup.shortName";
	public final static String GRID_SPECIALTY_ARIA_DESCRIBEDBY = "clinicResults_specialtyText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "clinicResults_departmentText";
	public final static String GRID_MBUNAME_ARIA_DESCRIBEDBY = "clinicResults_mbuText";
	public final static String GRID_PAGERID = "sp_1_clinicResults_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_clinicResults_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = CLINICLISTTAB_XPATH)
	private WebElement clinicListTab;
	
	@FindBy(id = ADDNEWCLINICBUTTON_ID)
	private WebElement addNewClinicButton;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = CLINICNAME_ID)
	private WebElement clinicName;
	
	@FindBy(name = CLINICCODE_NAME)
	private WebElement clinicCode; 
	
	@FindBy(id = SPECAILITY_ID)
	private WebElement specialty; 
	
	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	// pager
	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the clinicListTab
	 */
	public WebElement getClinicListTab() {
		return clinicListTab;
	}

	/**
	 * @return the addNewClinicButton
	 */
	public WebElement getAddNewClinicButton() {
		return addNewClinicButton;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the clinicName
	 */
	public WebElement getClinicName() {
		return clinicName;
	}

	/**
	 * @return the clinicCode
	 */
	public WebElement getClinicCode() {
		return clinicCode;
	}

	/**
	 * @return the specialty
	 */
	public WebElement getSpecialty() {
		return specialty;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

}
