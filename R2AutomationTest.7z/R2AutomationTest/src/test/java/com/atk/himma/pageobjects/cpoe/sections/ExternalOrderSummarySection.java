package com.atk.himma.pageobjects.cpoe.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ExternalOrderSummarySection extends DriverWaitClass {
	public final static String EXTORDERSERVTYPE_ID = "EXT_ORD_SVC_TYPE";
	public final static String EXTORDERGRIDDIV_ID = "EXT_ORDER_GRID_DIV";
	public final static String ADDNEWORDPLUSBTN_XPATH = "//div[@id='EXTERNAL_ORDER_SUMMARY_GRID_pager']//span[@class='ui-icon ui-icon-plus']";
	public final static String ADDNEWORDPOPUP_ID = "EXT_ORDERS_ADD_NEW_POPUP";
	public final static String EXTSERVITEM_ID = "EXT_NAME";
	public final static String EXTSERVTYPE_ID = "EXT_ORD_TYPE";
	public final static String EXTQUANTITY_ID = "EXT_QUANTITY";
	public final static String EXTINSTRUCTIONS_ID = "EXT_INSTRUCTIONS";
	public final static String SUBMITORDBTN_XPATH = "//form[@id='EXT_ORDERS_ADD_NEW_POPUP']//input[@value='Submit']";
	public final static String CANCELORDBTN_XPATH = "//form[@id='EXT_ORDERS_ADD_NEW_POPUP']//input[@value='Cancel']";

	@FindBy(id = EXTORDERSERVTYPE_ID)
	private WebElement extOrderServiceType;

	@FindBy(id = EXTORDERGRIDDIV_ID)
	private WebElement extOrderGridDiv;

	@FindBy(xpath = ADDNEWORDPLUSBTN_XPATH)
	private WebElement addNewOrderPlusBtn;

	@FindBy(id = ADDNEWORDPOPUP_ID)
	private WebElement addNewOrderPopup;

	@FindBy(id = EXTSERVITEM_ID)
	private WebElement extServItem;

	@FindBy(id = EXTSERVTYPE_ID)
	private WebElement extServType;

	@FindBy(id = EXTQUANTITY_ID)
	private WebElement extServQuantity;

	@FindBy(id = EXTINSTRUCTIONS_ID)
	private WebElement extServInstructions;

	@FindBy(xpath = SUBMITORDBTN_XPATH)
	private WebElement submitOrderBtn;

	@FindBy(xpath = CANCELORDBTN_XPATH)
	private WebElement cancelOrderBtn;

	public void addExtOrder(String[] outPatientListData) throws Exception {
		if (!outPatientListData[40].isEmpty()) {
			new Select(extOrderServiceType)
					.selectByVisibleText(outPatientListData[40]);
		}
		addNewOrderPlusBtn.click();
		waitForElementId(ADDNEWORDPOPUP_ID);
		sleepVeryShort();
		extServItem.clear();
		extServItem.sendKeys(outPatientListData[41]);
		if (!outPatientListData[42].isEmpty()) {
			new Select(extServType).selectByVisibleText(outPatientListData[42]);
		}
		extServQuantity.clear();
		extServQuantity.sendKeys(outPatientListData[43]);
		extServInstructions.clear();
		extServInstructions.sendKeys(outPatientListData[44]);
		submitOrderBtn.click();

	}

	public boolean checkExtOrderGridData(String[] outPatientListData) {
		try {
			waitForElementXpathExpression("//td[@aria-describedby='EXTERNAL_ORDER_SUMMARY_GRID_name' and @title='"
					+ outPatientListData[41] + "']");
			return webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='EXTERNAL_ORDER_SUMMARY_GRID_name' and @title='"
									+ outPatientListData[41] + "']"))
					.isDisplayed();
		} catch (Exception e) {
			return false;
		}

	}

	public WebElement getExtOrderServiceType() {
		return extOrderServiceType;
	}

	public WebElement getExtOrderGridDiv() {
		return extOrderGridDiv;
	}

	public WebElement getAddNewOrderPlusBtn() {
		return addNewOrderPlusBtn;
	}

	public WebElement getAddNewOrderPopup() {
		return addNewOrderPopup;
	}

	public WebElement getExtServItem() {
		return extServItem;
	}

	public WebElement getExtServType() {
		return extServType;
	}

	public WebElement getExtServQuantity() {
		return extServQuantity;
	}

	public WebElement getExtServInstructions() {
		return extServInstructions;
	}

	public WebElement getSubmitOrderBtn() {
		return submitOrderBtn;
	}

	public WebElement getCancelOrderBtn() {
		return cancelOrderBtn;
	}

}
