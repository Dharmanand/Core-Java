package com.atk.himma.pageobjects.mbuadmin.sections.itemdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ItemFirstSection extends DriverWaitClass {

	public final static String ITEMCODE_NAME = "itemInfo.itemCode";
	public final static String ITEMREFCODE_NAME = "itemInfo.itemReferenceCode";
	public final static String ITEMNAME_NAME = "itemInfo.itemName";
	public final static String ITEMNAMEAR_NAME = "itemInfo.itemNameAR";
	public final static String MBU_ID = "ITEM_MBU_ID";
	public final static String ITEMTYPE_NAME = "itemInfo.itemTypeId";
	public final static String ITEMCATEGORY_ID = "ITEM_CATEGORY_DETAIL";
	public final static String ITEMSUBCATEGORY_NAME = "itemInfo.itemSubCategoryId";
	public final static String NOTE_NAME = "itemInfo.note";
	public final static String APPLMEDORDCHECKBOX_ID = "APPL_MEDICAL_ORDER";
	public final static String GLOBALITEMCHECKBOX_ID = "IS_GLOBAL_ITEM";

	@FindBy(name = ITEMCODE_NAME)
	private WebElement itemCode;

	@FindBy(name = ITEMREFCODE_NAME)
	private WebElement itemRefCode;

	@FindBy(name = ITEMNAME_NAME)
	private WebElement itemName;

	@FindBy(name = ITEMNAMEAR_NAME)
	private WebElement itemNameAR;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(name = ITEMTYPE_NAME)
	private WebElement itemType;

	@FindBy(id = ITEMCATEGORY_ID)
	private WebElement itemCategory;

	@FindBy(name = ITEMSUBCATEGORY_NAME)
	private WebElement itemSubCategory;

	@FindBy(name = NOTE_NAME)
	private WebElement note;

	@FindBy(id = APPLMEDORDCHECKBOX_ID)
	private WebElement applForMedOrders;

	@FindBy(id = GLOBALITEMCHECKBOX_ID)
	private WebElement globalItem;

	public boolean isMandatoryItemName() {
		return isMandatoryField(itemName);
	}

	public boolean isMandatoryMBU() {
		return isMandatoryField(mbu);
	}

	public boolean isMandatoryItemType() {
		return isMandatoryField(itemType);
	}

	public boolean isMandatoryItemCategory() {
		return isMandatoryField(itemCategory);
	}

	public boolean fillDatas(String[] itemDatas) throws InterruptedException {
		waitForElementId(MBU_ID);
		sleepShort();
		itemRefCode.clear();
		itemRefCode.sendKeys(itemDatas[8].trim());
		itemName.clear();
		itemName.sendKeys(itemDatas[9].trim());
		itemNameAR.clear();
		itemNameAR.sendKeys(itemDatas[10].trim());
		if (!itemDatas[11].trim().isEmpty())
			new Select(itemType).selectByVisibleText(itemDatas[11].trim());
		if (!itemDatas[12].trim().isEmpty())
			new Select(itemCategory).selectByVisibleText(itemDatas[12].trim());
		if (!itemDatas[13].trim().isEmpty()) {
			waitForElementName(ITEMSUBCATEGORY_NAME);
			sleepShort();
			new Select(itemSubCategory).selectByVisibleText(itemDatas[13]
					.trim());
		}
		note.clear();
		note.sendKeys(itemDatas[14].trim());
		selectOrUnSelectCheckBox(itemDatas[15].trim(), applForMedOrders);
		selectOrUnSelectCheckBox(itemDatas[16].trim(), globalItem);
		return note.getAttribute("value").trim().equals(itemDatas[14].trim());
	}

	/**
	 * @return the itemCode
	 */
	public WebElement getItemCode() {
		return itemCode;
	}

	/**
	 * @return the itemRefCode
	 */
	public WebElement getItemRefCode() {
		return itemRefCode;
	}

	/**
	 * @return the itemName
	 */
	public WebElement getItemName() {
		return itemName;
	}

	/**
	 * @return the itemNameAR
	 */
	public WebElement getItemNameAR() {
		return itemNameAR;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the itemType
	 */
	public WebElement getItemType() {
		return itemType;
	}

	/**
	 * @return the itemCategory
	 */
	public WebElement getItemCategory() {
		return itemCategory;
	}

	/**
	 * @return the itemSubCategory
	 */
	public WebElement getItemSubCategory() {
		return itemSubCategory;
	}

	/**
	 * @return the note
	 */
	public WebElement getNote() {
		return note;
	}

	/**
	 * @return the applForMedOrders
	 */
	public WebElement getApplForMedOrders() {
		return applForMedOrders;
	}

	/**
	 * @return the globalItem
	 */
	public WebElement getGlobalItem() {
		return globalItem;
	}

}
