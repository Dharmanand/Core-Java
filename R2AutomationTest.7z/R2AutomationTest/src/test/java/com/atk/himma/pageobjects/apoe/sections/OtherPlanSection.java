package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class OtherPlanSection extends DriverWaitClass {
	public final static String OTHERPLANSEC_XPATH = "//a[text()='Other Plan']";
	@FindBy(xpath = OTHERPLANSEC_XPATH)
	private WebElement otherPlanSec;

	public final static String OTHERPLAN_NAME = "consultationSummary.plan.otherPlan";
	@FindBy(name = OTHERPLAN_NAME)
	private WebElement otherPlan;

	public void addOtherPlanSecData(String[] outPatientListData) {
		otherPlan.clear();
		otherPlan.sendKeys(outPatientListData[78]);

	}

	public WebElement getOtherPlanSec() {
		return otherPlanSec;
	}

	public WebElement getOtherPlan() {
		return otherPlan;
	}

	public boolean checkOtherPlanSec() {
		return otherPlanSec.isDisplayed();
	}

}
