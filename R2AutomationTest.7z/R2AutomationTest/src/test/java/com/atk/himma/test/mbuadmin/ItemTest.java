package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.ItemPage;
import com.atk.himma.pageobjects.mbuadmin.sections.itemdetails.ItemFirstSection;
import com.atk.himma.pageobjects.mbuadmin.tabs.ItemListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ItemTest extends SeleniumDriverSetup{
	
	List<String[]> itemDatas;
	ItemPage itemPage;
	
	@Test(description="Open Item Page")
	public void clickOnItemMenu() throws InterruptedException {
		itemPage = PageFactory.initElements(webDriver, ItemPage.class);
		itemPage = itemPage.clickOnItemMenu(webDriver, webDriverWait);
		itemPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		itemPage
				.waitForElementXpathExpression(ItemListTab.ITEMLISTTAB_XPATH);
		itemPage.sleepShort();
		Assert.assertEquals(itemPage.getItemListTab().getItemListTab().getAttribute("title").trim(),
				"Item List", "Fail to open Item List.");
	}

	// [Item] Open Form
	@Test(description = "Open Item Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkItemMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		itemPage = PageFactory.initElements(webDriver, ItemPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Item");
		itemPage.setWebDriver(webDriver);
		itemPage.setWebDriverWait(webDriverWait);
		itemPage.waitForElementXpathExpression(ItemPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Item Type").get("[Item] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ItemPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Item] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			itemPage = itemPage.clickOnItemMenu(webDriver, webDriverWait);
			itemPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			itemPage.waitForElementVisibilityOf(itemPage.getItemListTab()
					.getSearchButton());
			Assert.assertEquals(itemPage.getItemListTab().getItemListTab()
					.getAttribute("title").trim(), "Item List",
					"Fail to open Item List.");
			itemPage.waitForElementXpathExpression(ItemListTab.ADDNEWITEMBUTTON_XPATH);
			itemPage.sleepVeryShort();
			itemPage.getItemListTab().getAddNewItemButton().click();
			itemPage.waitForElementId(ItemFirstSection.MBU_ID);
			itemPage.waitForElementId(ItemFirstSection.ITEMCATEGORY_ID);
			itemPage.sleepShort();
		}
	}
	
	@Test(description="click On Add New Button", dependsOnMethods="clickOnItemMenu")
	public void test1ClickOnAddNewButton() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		itemDatas = excelReader.read(properties.getProperty("item"));
		for (String st[] : itemDatas)
		Assert.assertEquals(itemPage.clickOnAddNewItem(st),
				true, "Fail to click On Add New Button.");
	}

	@Test(description="click Mandatory Clinic Short Name", dependsOnMethods="test1ClickOnAddNewButton")
	public void test2IsMandClinicShName() {
			Assert.assertEquals(itemPage.getItemFirstSection().isMandatoryItemName(),
					true, "Fail to Mandatory Clinic Short Name.");
	}
	
	@Test(description="click Mandatory MBU", dependsOnMethods="test1ClickOnAddNewButton")
	public void test3IsMandMBU() {
		Assert.assertEquals(itemPage.getItemFirstSection().isMandatoryMBU(),
				true, "Fail to Mandatory MBU");
	}
	
	@Test(description="click Mandatory Item Type", dependsOnMethods="test1ClickOnAddNewButton")
	public void test4IsMandItemType() {
		Assert.assertEquals(itemPage.getItemFirstSection().isMandatoryItemType(),
				true, "Fail to Mandatory Item Type.");
	}
	
	@Test(description="click Mandatory Item Category", dependsOnMethods="test1ClickOnAddNewButton")
	public void test5IsMandItemCat() {
		Assert.assertEquals(itemPage.getItemFirstSection().isMandatoryItemCategory(),
				true, "Fail to Mandatory Item Category.");
	}
	
	@Test(description="Fill datas of Item First Section", dependsOnMethods={"test1ClickOnAddNewButton"})
	public void test6FillItemFirstSecDatas() throws InterruptedException {
		for (String st[] : itemDatas)
		Assert.assertEquals(itemPage.getItemFirstSection().fillDatas(st),
				true, "Fail to Fill datas of Item First Section");
	}

	@Test(description="check Time Duration for Consultation Services Section", dependsOnMethods={"test1ClickOnAddNewButton"})
	public void test7CheckBusTimSection() throws InterruptedException {
			Assert.assertEquals(itemPage.getItemGeneralDetails().checkGenDetailsSection(),
					true, "Fail to Check Time Duration for Consultation Services Section");
	}
	
	@Test(description="Fill datas of Time Duration for Consultation Services", dependsOnMethods={"test7CheckBusTimSection"})
	public void test8FillTimeDurConSerDatas() throws InterruptedException {
		for (String st[] : itemDatas)
			Assert.assertEquals(itemPage.getItemGeneralDetails().fillDatas(st),
					true, "Fail to Fill datas of Time Duration for Consultation Services Section");
	}
	
	@Test(description="Save Item", dependsOnMethods={"test8FillTimeDurConSerDatas"})
	public void test9SaveItem() throws InterruptedException, IOException {
			Assert.assertEquals(itemPage.saveDetailsPage().contains(
					"Update"), true,"Fail to Save Item.");
	}
	
	@Test(description="Activate Item", dependsOnMethods="test9SaveItem")
	public void test10ActivateItem() throws InterruptedException, IOException {
		Assert.assertEquals(itemPage.activateItem().contains(
				"Active"), true,"Fail to Activate Item.");
	}
	
	@Test(description="Check Duplicate Item Data", dependsOnMethods={"test9SaveItem"})
	public void test11SaveDuplicateItem() throws InterruptedException, IOException {
		for (String st[] : itemDatas)
		{
			itemPage.waitForElementXpathExpression(ItemPage.DETAILSUPDATEBUTTON_XPATH);
			itemPage.getAddNewButton().click();
			itemPage.waitForElementXpathExpression(ItemPage.DETAILSSAVEBUTTON_XPATH);
			Assert.assertEquals(itemPage.getItemFirstSection().fillDatas(st),
					true, "Fail to Fill datas of Item First Section");
			Assert.assertEquals(itemPage.getItemGeneralDetails().fillDatas(st),
					true, "Fail to Fill datas of Time Duration for Consultation Services Section");
			Assert.assertTrue(itemPage.saveDuplicateData(st),"Fail to Check Duplicate Item Data");
		}
	}
	
//	// [Details Tab] [Section: Audit Trail] View
//	public void checkAuditTrailSection() {
//		
//	}
	
	@Test(dependsOnMethods = { "checkItemMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Clinic for Privilege")
	public void searchItemForPrivilege() throws Exception {
		itemPage.clickClinicListTab();
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		itemDatas = excelReader.read(properties.getProperty("item"));
		for (String st[] : itemDatas.subList(0, 1))
			Assert.assertEquals(itemPage.searchItemPage(st[9].trim()), st[9].trim(),
					"Fail to Search Item result");
	}
	
	// [List Tab] Add New (Button)
	@Test(dependsOnMethods = { "searchItemForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Check [List Tab] Add New (Button) Privilege")
	public void checkAddNewButtonPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Item Detail")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ItemListTab.ADDNEWITEMBUTTON_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");
	}
	
//	[List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchItemForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] View (Link in the search result grid) link for Privilege")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Item Detail")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ itemDatas.subList(0, 1).get(0)[9].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");

	}

//	[List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "searchItemForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Edit (Link in the search result grid) link for Privilege")
	public void checkEditLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Item Detail")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ itemDatas.subList(0, 1).get(0)[9].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");

	}
	
//	[List Tab] Delete(Link in the search result grid)
	@Test(dependsOnMethods = { "searchItemForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Delete(Link in the search result grid) link for Privilege")
	public void checkDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Item Detail")
				.get("[List Tab] Delete(Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ itemDatas.subList(0, 1).get(0)[9].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete(Link in the search result grid) privilege");
	}
}
