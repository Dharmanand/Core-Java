package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ItemRequiredSection extends DriverWaitClass{
	
	public final static String ADDROWBUTTON_ID = "addNewItemRequired";
	
//	-----------GRID--------------
	public final static String GRID_ID = "rsir_GRID";
	public final static String GRID_ITEMNAME_ARIA_DESCRIBEDBY = "rsir_GRID_itemName";
	public final static String GRID_QUALITY_ARIA_DESCRIBEDBY = "rsir_GRID_quantity";
	public final static String GRID_UOM_ARIA_DESCRIBEDBY = "rsir_GRID_uom";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "rsir_GRID_action";
	public final static String GRID_PAGERID = "sp_1_rsir_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rsir_GRID_pager']";

//	-----------GRID's Fields--------------
	public final static String ITEMNAMETXT_CSS = "td[aria-describedby='"+GRID_ITEMNAME_ARIA_DESCRIBEDBY+"'] span input[name='itemName']";
	public final static String LOOKUP_CSS = "td[aria-describedby='"+GRID_ITEMNAME_ARIA_DESCRIBEDBY+"'] span a[name='itemName']";
	public final static String LOCCATEGORYTXT_CSS = "td[aria-describedby='"+GRID_QUALITY_ARIA_DESCRIBEDBY+"'] input[name='quantity']";
	public final static String UOMDD_CSS = "td[aria-describedby='"+GRID_UOM_ARIA_DESCRIBEDBY+"'] span input[name='uom']";
	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_ITEMNAME_ARIA_DESCRIBEDBY+"']/span/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";

	@FindBy(id = ADDROWBUTTON_ID)
	private WebElement addRowButton;
	
	@FindBy(css = ITEMNAMETXT_CSS)
	private WebElement itemNameTxt;
	
	@FindBy(css = LOOKUP_CSS)
	private WebElement Lookup;
	
	@FindBy(css = LOCCATEGORYTXT_CSS)
	private WebElement locCategoryTxt;
	
	@FindBy(css = UOMDD_CSS)
	private WebElement uomDD;
	
	@FindBy(css = DELETEACTION_GE_XPATH)
	private WebElement deleteAction;

	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the itemNameTxt
	 */
	public WebElement getItemNameTxt() {
		return itemNameTxt;
	}

	/**
	 * @return the lookup
	 */
	public WebElement getLookup() {
		return Lookup;
	}

	/**
	 * @return the locCategoryTxt
	 */
	public WebElement getLocCategoryTxt() {
		return locCategoryTxt;
	}

	/**
	 * @return the uomDD
	 */
	public WebElement getUomDD() {
		return uomDD;
	}

	/**
	 * @return the deleteAction
	 */
	public WebElement getDeleteAction() {
		return deleteAction;
	}
	
}
