package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class IdentificationDetailsSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Identification Details";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	private final static String IDENTIFICATIONDOCUMENT_ID = "IDDOCTYPEID";

	@FindBy(id = IDENTIFICATIONDOCUMENT_ID)
	private WebElement identificationDocument;

	private final static String IDENTIFICATIONNUMBER_ID = "identificationNumber";

	@FindBy(id = IDENTIFICATIONNUMBER_ID)
	private WebElement identificationNumber;

	private final static String ISPRIMARY_ID = "IsPrimary10";

	@FindBy(id = ISPRIMARY_ID)
	private WebElement isPrimary;

	private final static String ISSUEDATE_ID = "issueDatePicker0";

	@FindBy(id = ISSUEDATE_ID)
	private WebElement issueDate;

	private final static String EXPIRYDATE_ID = "expryDatePicker0";

	@FindBy(id = EXPIRYDATE_ID)
	private WebElement expiryDate;

	private final static String issuePlace_ID = "documentIssuePlace";

	@FindBy(id = issuePlace_ID)
	private WebElement issuePlace;

	private final static String UPLOADDOCUMENT_ID = "identiDetailsList_0__documentPath";

	@FindBy(id = UPLOADDOCUMENT_ID)
	private WebElement uploadDocument;

	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Identification Details')]/..";

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public void fillDatasIdentificationDetails(String[] excelData,
			WebDriverWait webDriverWait) throws InterruptedException {
		// getSectionName();
		// sleepVeryShort();
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions
				.visibilityOf(getIdentificationDocument()));
		new Select(getIdentificationDocument())
				.selectByVisibleText(excelData[18].trim());
		getIdentificationNumber().clear();
		getIdentificationNumber().sendKeys(excelData[19].trim());

		if (Boolean.getBoolean(excelData[20].trim())) {
			getIsPrimary().click();
		}

		getIssueDate().clear();
		getIssueDate().sendKeys(excelData[21].trim());
		getExpiryDate().clear();
		getExpiryDate().sendKeys(excelData[22].trim());
		getIssuePlace().clear();
		getIssuePlace().sendKeys(excelData[23].trim());
		getUploadDocument().sendKeys(excelData[24].trim());
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the identificationDocument
	 */
	public WebElement getIdentificationDocument() {
		return identificationDocument;
	}

	/**
	 * @return the identificationNumber
	 */
	public WebElement getIdentificationNumber() {
		return identificationNumber;
	}

	/**
	 * @return the isPrimary
	 */
	public WebElement getIsPrimary() {
		return isPrimary;
	}

	/**
	 * @return the issueDate
	 */
	public WebElement getIssueDate() {
		return issueDate;
	}

	/**
	 * @return the expiryDate
	 */
	public WebElement getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @return the issuePlace
	 */
	public WebElement getIssuePlace() {
		return issuePlace;
	}

	/**
	 * @return the uploadDocument
	 */
	public WebElement getUploadDocument() {
		return uploadDocument;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the identificationdocumentId
	 */
	public static String getIdentificationdocumentId() {
		return IDENTIFICATIONDOCUMENT_ID;
	}

	/**
	 * @return the identificationnumberId
	 */
	public static String getIdentificationnumberId() {
		return IDENTIFICATIONNUMBER_ID;
	}

	/**
	 * @return the isprimaryId
	 */
	public static String getIsprimaryId() {
		return ISPRIMARY_ID;
	}

	/**
	 * @return the issuedateId
	 */
	public static String getIssuedateId() {
		return ISSUEDATE_ID;
	}

	/**
	 * @return the expirydateId
	 */
	public static String getExpirydateId() {
		return EXPIRYDATE_ID;
	}

	/**
	 * @return the issueplaceId
	 */
	public static String getIssueplaceId() {
		return issuePlace_ID;
	}

	/**
	 * @return the uploaddocumentId
	 */
	public static String getUploaddocumentId() {
		return UPLOADDOCUMENT_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
