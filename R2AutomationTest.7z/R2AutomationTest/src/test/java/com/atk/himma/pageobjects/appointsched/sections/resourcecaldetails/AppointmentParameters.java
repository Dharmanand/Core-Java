package com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class AppointmentParameters extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Appointment Parameters";
	public final static String OVERRIDECLINICPARAM_ID = "OVERRIDE_CLINIC_PARAM";
	public final static String ADDBUTTONTABLE_XPATH = ".//*[@id='VISIT_PARAMETERS_GRID_pager_left']/table/tbody/tr/td/div/span";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Appointment Parameter')]/..";
	
//	Pop Up Search Consultation Services

	public final static String POPUPFORM_ID = "addVisitParameterForm";
	public final static String POPUPTITLE_ID = "ui-dialog-title-visitParametersDialog";
	public final static String VISITCATPOPUP_ID = "RES_VISIT_CATEGORY";
	public final static String VISITTYPEPOPUP_ID = "VISIT_TYPE";
	public final static String NUMALLOPERVISIT_ID = "NUMBER_ALLOWED_PER_VISIT";
	public final static String FOLLOWUPELIGPOPUP_ID = "DURATION_FOR_ELIGIBILITY";

	public final static String SUBMITBUTTON_XPATH = "//form[@id='addVisitParameterForm']//span[@class='buttoncontainer_sml']//input[@value='Submit']";
	public final static String CANCELBUTTON_XPATH = "//form[@id='addVisitParameterForm']//span[@class='buttoncontainer_sml']//input[@value='Cancel']";

	public final static String GRIDID_ID = "VISIT_PARAMETERS_GRID";
	public final static String GRID_VISITCATEGORY_ID = "VISIT_PARAMETERS_GRID_visitCategoryText";
	public final static String GRID_VISITTYPE_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_visitTypeText";
	public final static String GRID_ALLOWEDPERVISIT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_allowedPerVisit";
	public final static String GRID_ELIGIBILITYDURATION_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_eligibilityDuration";
	public final static String GRID_PAGERID = "sp_1_VISIT_PARAMETERS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_VISIT_PARAMETERS_GRID_pager']";
	
//	Pop Up End

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = OVERRIDECLINICPARAM_ID)
	private WebElement overrideClinicParam;
	
	@FindBy(xpath = ADDBUTTONTABLE_XPATH)
	private WebElement addButtonTable;
	
	@FindBy(id = POPUPFORM_ID)
	private WebElement popupForm;
	
	@FindBy(id = POPUPTITLE_ID)
	private WebElement popupTitle;
	
	@FindBy(id = VISITCATPOPUP_ID)
	private WebElement visitCatPopup;
	
	@FindBy(id = VISITTYPEPOPUP_ID)
	private WebElement visitTypePopup;
	
	@FindBy(id = NUMALLOPERVISIT_ID)
	private WebElement numAlloPerVisit;
	
	@FindBy(id = FOLLOWUPELIGPOPUP_ID)
	private WebElement followUpEligPopup;
	
	@FindBy(xpath= SUBMITBUTTON_XPATH)
	private WebElement submitButton;
	
	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	public boolean checkAppointParamSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public String clickOnAddButton(String[] resCalDatas)
			throws InterruptedException {
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			sectionName.click();
		waitForElementId(OVERRIDECLINICPARAM_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(resCalDatas[26].trim(), overrideClinicParam);
		addButtonTable.click();
		waitForElementId(POPUPTITLE_ID);
		sleepVeryShort();
		return popupTitle.getText().trim();
	}

	public boolean isMandVisitCategory() {
		waitForElementId(VISITCATPOPUP_ID);
		return isMandatoryField(visitCatPopup);
	}

	public boolean isMandVisitType() {
		waitForElementId(VISITTYPEPOPUP_ID);
		return isMandatoryField(visitTypePopup);
	}

	public boolean isMandNumAllPerVisit() {
		waitForElementId(NUMALLOPERVISIT_ID);
		return isMandatoryField(numAlloPerVisit);
	}

	public boolean isMandFollowUpsDuration() {
		waitForElementId(FOLLOWUPELIGPOPUP_ID);
		return isMandatoryField(followUpEligPopup);
	}

	public boolean fillDatasToPopUp(String[] resCalDatas)
			throws InterruptedException {
		new Select(visitCatPopup).selectByVisibleText(resCalDatas[27].trim());
		new Select(visitTypePopup).selectByVisibleText(resCalDatas[28].trim());
		numAlloPerVisit.clear();
		numAlloPerVisit.sendKeys(resCalDatas[29].trim());
		followUpEligPopup.clear();
		followUpEligPopup.sendKeys(resCalDatas[30].trim());
		return (followUpEligPopup.getAttribute("value").trim()
				.equals(resCalDatas[30].trim()));
	}

	public boolean submitFollowUpDatas() throws InterruptedException {
		waitForElementXpathExpression(SUBMITBUTTON_XPATH);
		submitButton.click();
		waitForElementId(GRIDID_ID);
		sleepVeryShort();
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}
	public boolean cancelFollowUpDatas() throws InterruptedException {
		waitForElementXpathExpression(SUBMITBUTTON_XPATH);
		cancelButton.click();
		waitForElementId(GRIDID_ID);
		sleepVeryShort();
		return addButtonTable.isEnabled();
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the overrideClinicParam
	 */
	public WebElement getOverrideClinicParam() {
		return overrideClinicParam;
	}

	/**
	 * @return the addButtonTable
	 */
	public WebElement getAddButtonTable() {
		return addButtonTable;
	}

	/**
	 * @return the popupForm
	 */
	public WebElement getPopupForm() {
		return popupForm;
	}

	/**
	 * @return the popupTitle
	 */
	public WebElement getPopupTitle() {
		return popupTitle;
	}

	/**
	 * @return the visitCatPopup
	 */
	public WebElement getVisitCatPopup() {
		return visitCatPopup;
	}

	/**
	 * @return the visitTypePopup
	 */
	public WebElement getVisitTypePopup() {
		return visitTypePopup;
	}

	/**
	 * @return the numAlloPerVisit
	 */
	public WebElement getNumAlloPerVisit() {
		return numAlloPerVisit;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the followUpEligPopup
	 */
	public WebElement getFollowUpEligPopup() {
		return followUpEligPopup;
	}

}
