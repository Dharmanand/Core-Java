package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.JsTreeSelector;

public class PositionInformationTab extends DriverWaitClass {
	public final static String CREATEPOSFORM_ID = "POSITION_FORM";
	@FindBy(id = CREATEPOSFORM_ID)
	private WebElement createPosForm;

	public final static String ADDNEWPOSBTN_XPATH = "//form[@id='UPDATE_POSITION_FORM']//input[@value='Add New Position']";
	@FindBy(xpath = ADDNEWPOSBTN_XPATH)
	private WebElement addNewPosBtn;

	public final static String SAVEBTN_XPATH = "//input[@value='Save']";
	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	public final static String CANCELBTN_XPATH = "//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String UPDATEBTN_XPATH = "//input[@value='Update']";
	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	public final static String POSITIONNAME_ID = "POSITION_TITLE";
	@FindBy(id = POSITIONNAME_ID)
	private WebElement positionName;

	public final static String POSITIONCODE_ID = "POSITION_CODE";
	@FindBy(id = POSITIONCODE_ID)
	private WebElement positionCode;

	public final static String ORGUNITLOOKUP_XPATH = "//input[@id='ORG_UNIT_NAME']/../a[@title='Organization Unit Search']";
	@FindBy(xpath = ORGUNITLOOKUP_XPATH)
	private WebElement orgUnitLookup;

	public final static String JOB_ID = "ORG_ROLES_ID";
	@FindBy(id = JOB_ID)
	private WebElement job;

	public final static String REPORTINGPOSITIONLOOKUP_XPATH = "//input[@id='REPORTING_POSITION_TEXT']/../a[@title='Reporting Position Search']";
	@FindBy(xpath = REPORTINGPOSITIONLOOKUP_XPATH)
	private WebElement reportingPositionLookup;

	public final static String REPORTINGPOSSEARCHFORM_NAME = "reportingPositionSearch";
	@FindBy(name = REPORTINGPOSSEARCHFORM_NAME)
	private WebElement reportingPosSearchForm;

	public final static String ROOTPARENTORGUNIT_ID = "ROOT_ORG_POS";
	@FindBy(id = ROOTPARENTORGUNIT_ID)
	private WebElement rootParentOrgUnit;

	public final static String MBUPARENTORGUNIT_ID = "MBU_ORG_POS";
	@FindBy(id = MBUPARENTORGUNIT_ID)
	private WebElement mbuParentOrgUnit;

	public final static String MBUFORPOS_ID = "mainBusinessUnitForPosId";
	@FindBy(id = MBUFORPOS_ID)
	private WebElement mbuForPos;

	public final static String TREECONTAINERDIV_ID = "jsTreeForPosition";
	@FindBy(id = TREECONTAINERDIV_ID)
	private WebElement treeContainerDiv;

	public final static String REPPOSTREEDIV_ID = "repPositionTreeId";
	@FindBy(id = REPPOSTREEDIV_ID)
	private WebElement repPosTreeDiv;

	public final static String REPPOSGRID_ID = "posSelectGrid";
	@FindBy(id = REPPOSGRID_ID)
	private WebElement repPosGrid;

	public final static String CLEARBTN_ID = "clearLink";
	@FindBy(id = CLEARBTN_ID)
	private WebElement clearBtn;

	public final static String POSDESCRIPTION_ID = "POSITION_DESCRIPTION";
	@FindBy(id = POSDESCRIPTION_ID)
	private WebElement posDescription;

	public final static String AUDITTRAIL = "auditViewId_title";
	@FindBy(id = AUDITTRAIL)
	private WebElement auditTrail;

	public void addPosition(String[] posHierarchyData) throws Exception {
		sleepShort();
		confirmOkDialogBox();
		sleepVeryShort();
		waitForElementId(POSITIONNAME_ID);
		positionName.clear();
		positionName.sendKeys(posHierarchyData[0]);
		orgUnitLookup.click();
		OrgUnitSearchPopupPage orgUnitSearchPopupPage = PageFactory
				.initElements(webDriver, OrgUnitSearchPopupPage.class);
		orgUnitSearchPopupPage.setWebDriver(webDriver);
		orgUnitSearchPopupPage.setWebDriverWait(webDriverWait);
		orgUnitSearchPopupPage.searchUnit(posHierarchyData[1],
				posHierarchyData[2], posHierarchyData[3]);
		sleepShort();

		if (!posHierarchyData[4].isEmpty()) {
			new Select(job).selectByVisibleText(posHierarchyData[4]);
		}

		if (!posHierarchyData[5].isEmpty() && !posHierarchyData[7].isEmpty()) {
			reportingPositionLookup.click();
			sleepMedium();
			waitForElementId(MBUFORPOS_ID);
			if (posHierarchyData[6].isEmpty()) {
				rootParentOrgUnit.click();
				sleepVeryShort();
			} else {
				mbuParentOrgUnit.click();
				sleepVeryShort();
				new Select(mbuForPos).selectByVisibleText(posHierarchyData[6]);
			}
			waitForElementId(TREECONTAINERDIV_ID);
			sleepShort();
			new JsTreeSelector(webDriver, webDriverWait)
					.expandTree(REPPOSTREEDIV_ID);
			new JsTreeSelector(webDriver, webDriverWait).selectTreeNode(
					REPPOSTREEDIV_ID, posHierarchyData[7], posHierarchyData[6]);
			waitForElementId(REPPOSGRID_ID);
			sleepVeryShort();
			clickOnGridAction("gridtable_orgInfo_positionTitle",
					posHierarchyData[5], "Select");
			sleepVeryShort();
		}

		saveBtn.click();
		sleepMedium();
	}

	public void clickAddNewPos() throws Exception {
		addNewPosBtn.click();
		sleepVeryShort();
	}

	public void clickCancel() throws Exception {
		sleepShort();
		confirmOkDialogBox();
		sleepVeryShort();
		cancelBtn.click();
		sleepVeryShort();
	}

	public void updatePosition(String[] editPosData) throws Exception {
		waitForElementId(POSITIONNAME_ID);
		positionName.clear();
		positionName.sendKeys(editPosData[0]);

		if (!editPosData[4].isEmpty()) {
			new Select(job).selectByVisibleText(editPosData[4]);
		}

		if (!editPosData[5].isEmpty() && !editPosData[7].isEmpty()) {
			reportingPositionLookup.click();
			sleepMedium();
			waitForElementId(MBUFORPOS_ID);
			if (editPosData[6].isEmpty()) {
				rootParentOrgUnit.click();
				sleepVeryShort();
			} else {
				mbuParentOrgUnit.click();
				sleepVeryShort();
				new Select(mbuForPos).selectByVisibleText(editPosData[6]);
			}
			waitForElementId(TREECONTAINERDIV_ID);
			sleepShort();
			new JsTreeSelector(webDriver, webDriverWait)
					.expandTree(REPPOSTREEDIV_ID);
			new JsTreeSelector(webDriver, webDriverWait).selectTreeNode(
					REPPOSTREEDIV_ID, editPosData[7], editPosData[6]);
			waitForElementId(REPPOSGRID_ID);
			sleepVeryShort();
			clickOnGridAction("gridtable_orgInfo_positionTitle",
					editPosData[5], "Select");
			sleepVeryShort();
		}
	}

	public void clickOnUpdate() throws Exception {
		updateBtn.click();
		sleepShort();
	}

	public WebElement getCreatePosForm() {
		return createPosForm;
	}

	public WebElement getAddNewPosBtn() {
		return addNewPosBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getPositionName() {
		return positionName;
	}

	public WebElement getPositionCode() {
		return positionCode;
	}

	public WebElement getOrgUnitLookup() {
		return orgUnitLookup;
	}

	public WebElement getJob() {
		return job;
	}

	public WebElement getReportingPositionLookup() {
		return reportingPositionLookup;
	}

	public WebElement getReportingPosSearchForm() {
		return reportingPosSearchForm;
	}

	public WebElement getRootParentOrgUnit() {
		return rootParentOrgUnit;
	}

	public WebElement getMbuParentOrgUnit() {
		return mbuParentOrgUnit;
	}

	public WebElement getMbuForPos() {
		return mbuForPos;
	}

	public WebElement getTreeContainerDiv() {
		return treeContainerDiv;
	}

	public WebElement getRepPosTreeDiv() {
		return repPosTreeDiv;
	}

	public WebElement getRepPosGrid() {
		return repPosGrid;
	}

	public WebElement getClearBtn() {
		return clearBtn;
	}

	public WebElement getPosDescription() {
		return posDescription;
	}

	public WebElement getAuditTrail() {
		return auditTrail;
	}

}