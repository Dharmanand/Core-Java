package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class ContactDetailsSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Contact Details";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Contact Details')]/..";

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	private final static String CONTACTTYPE_NAME = "contDetailsList[0].contactType";

	@FindBy(name = CONTACTTYPE_NAME)
	private WebElement contactType;

	private final static String ADDRESSLINE1_ID = "addressLine10";

	@FindBy(id = ADDRESSLINE1_ID)
	private WebElement addressLine1;

	private final static String ADDRESSLINE2_ID = "addressLine20";

	@FindBy(id = ADDRESSLINE2_ID)
	private WebElement addressLine2;

	private final static String COUNTRY_ID = "countryId0";

	@FindBy(id = COUNTRY_ID)
	private WebElement country;

	private final static String DISTRICT_ID = "districtId";

	@FindBy(id = DISTRICT_ID)
	private WebElement district;

	private final static String CITYORLOCALITY_ID = "cityLocId";

	@FindBy(id = CITYORLOCALITY_ID)
	private WebElement cityOrLocality;

	private final static String POSTBOXNO_ID = "poBoxNo0";

	@FindBy(id = POSTBOXNO_ID)
	private WebElement postBoxNo;

	private final static String POSTCODE_ID = "postCode0";

	@FindBy(id = POSTCODE_ID)
	private WebElement postCode;

	private final static String MOBILECODE_ID = "contMob0";

	@FindBy(id = MOBILECODE_ID)
	private WebElement mobileCode;

	private final static String MOBILENUMBER_ID = "contsmobpNo0";

	@FindBy(id = MOBILENUMBER_ID)
	private WebElement mobileNumber;

	private final static String HOMEPHONECODE_ID = "contPhone0";

	@FindBy(id = HOMEPHONECODE_ID)
	private WebElement homePhoneCode;

	private final static String HOMEPHONENUMBER_ID = "contshmNo0";

	@FindBy(id = HOMEPHONENUMBER_ID)
	private WebElement homePhoneNumber;

	private final static String WORKPHONECODE_ID = "sworkPh0";

	@FindBy(id = WORKPHONECODE_ID)
	private WebElement workPhoneCode;

	private final static String WORKPHONENUMBER_ID = "sworkNo0";

	@FindBy(id = WORKPHONENUMBER_ID)
	private WebElement workPhoneNumber;

	private final static String WORKPHONEEXTNUMBER_ID = "sworkExtNo0";

	@FindBy(id = WORKPHONEEXTNUMBER_ID)
	private WebElement workPhoneExtNumber;

	private final static String FAXCODE_ID = "faxCode0";

	@FindBy(id = FAXCODE_ID)
	private WebElement faxCode;

	private final static String FAXNUMBER_ID = "faxNumber0";

	@FindBy(id = FAXNUMBER_ID)
	private WebElement faxNumber;

	private final static String EMAIL_ID = "contEmail";

	@FindBy(id = EMAIL_ID)
	private WebElement email;

	public void fillDatasContactDetails(String[] excelData,
			WebDriverWait webDriverWait) throws InterruptedException {

		// getSectionName().click();
		// sleepVeryShort();
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getContactType()));
		new Select(getContactType()).selectByVisibleText(excelData[25].trim());
		getAddressLine1().clear();
		getAddressLine1().sendKeys(excelData[26].trim());
		getAddressLine2().clear();
		getAddressLine2().sendKeys(excelData[27].trim());
		sleepVeryShort();
		new Select(getCountry()).selectByVisibleText(excelData[28].trim());
		waitForElementId(DISTRICT_ID);
		sleepVeryShort();
		new Select(getDistrict()).selectByVisibleText(excelData[29].trim());
		waitForElementId(CITYORLOCALITY_ID);
		sleepVeryShort();
		new Select(getCityOrLocality()).selectByVisibleText(excelData[30]
				.trim());
		getPostBoxNo().clear();
		getPostBoxNo().sendKeys(excelData[31].trim());
		getPostCode().clear();
		getPostCode().sendKeys(excelData[32].trim());

		new Select(getMobileCode()).selectByVisibleText(excelData[33].trim());
		getMobileNumber().clear();
		getMobileNumber().sendKeys(excelData[34].trim());
		new Select(getHomePhoneCode())
				.selectByVisibleText(excelData[35].trim());
		getHomePhoneNumber().clear();
		getHomePhoneNumber().sendKeys(excelData[36].trim());
		new Select(getWorkPhoneCode())
				.selectByVisibleText(excelData[37].trim());
		getWorkPhoneNumber().clear();
		getWorkPhoneNumber().sendKeys(excelData[38].trim());
		getWorkPhoneExtNumber().clear();
		getWorkPhoneExtNumber().sendKeys(excelData[39].trim());
		new Select(getFaxCode()).selectByVisibleText(excelData[40].trim());
		getFaxNumber().clear();
		getFaxNumber().sendKeys(excelData[41].trim());
		getEmail().clear();
		getEmail().sendKeys(excelData[42].trim());
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the contactType
	 */
	public WebElement getContactType() {
		return contactType;
	}

	/**
	 * @return the addressLine1
	 */
	public WebElement getAddressLine1() {
		return addressLine1;
	}

	/**
	 * @return the addressLine2
	 */
	public WebElement getAddressLine2() {
		return addressLine2;
	}

	/**
	 * @return the country
	 */
	public WebElement getCountry() {
		return country;
	}

	/**
	 * @return the district
	 */
	public WebElement getDistrict() {
		return district;
	}

	/**
	 * @return the cityOrLocality
	 */
	public WebElement getCityOrLocality() {
		return cityOrLocality;
	}

	/**
	 * @return the postBoxNo
	 */
	public WebElement getPostBoxNo() {
		return postBoxNo;
	}

	/**
	 * @return the postCode
	 */
	public WebElement getPostCode() {
		return postCode;
	}

	/**
	 * @return the mobileCode
	 */
	public WebElement getMobileCode() {
		return mobileCode;
	}

	/**
	 * @return the mobileNumber
	 */
	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the homePhoneCode
	 */
	public WebElement getHomePhoneCode() {
		return homePhoneCode;
	}

	/**
	 * @return the homePhoneNumber
	 */
	public WebElement getHomePhoneNumber() {
		return homePhoneNumber;
	}

	/**
	 * @return the workPhoneCode
	 */
	public WebElement getWorkPhoneCode() {
		return workPhoneCode;
	}

	/**
	 * @return the workPhoneNumber
	 */
	public WebElement getWorkPhoneNumber() {
		return workPhoneNumber;
	}

	/**
	 * @return the workPhoneExtNumber
	 */
	public WebElement getWorkPhoneExtNumber() {
		return workPhoneExtNumber;
	}

	/**
	 * @return the email
	 */
	public WebElement getEmail() {
		return email;
	}

	/**
	 * @return the faxCode
	 */
	public WebElement getFaxCode() {
		return faxCode;
	}

	/**
	 * @return the faxNumber
	 */
	public WebElement getFaxNumber() {
		return faxNumber;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the contacttypeName
	 */
	public static String getContacttypeName() {
		return CONTACTTYPE_NAME;
	}

	/**
	 * @return the addressline1Id
	 */
	public static String getAddressline1Id() {
		return ADDRESSLINE1_ID;
	}

	/**
	 * @return the addressline2Id
	 */
	public static String getAddressline2Id() {
		return ADDRESSLINE2_ID;
	}

	/**
	 * @return the countryId
	 */
	public static String getCountryId() {
		return COUNTRY_ID;
	}

	/**
	 * @return the districtId
	 */
	public static String getDistrictId() {
		return DISTRICT_ID;
	}

	/**
	 * @return the cityorlocalityId
	 */
	public static String getCityorlocalityId() {
		return CITYORLOCALITY_ID;
	}

	/**
	 * @return the postboxnoId
	 */
	public static String getPostboxnoId() {
		return POSTBOXNO_ID;
	}

	/**
	 * @return the postcodeId
	 */
	public static String getPostcodeId() {
		return POSTCODE_ID;
	}

	/**
	 * @return the mobilecodeId
	 */
	public static String getMobilecodeId() {
		return MOBILECODE_ID;
	}

	/**
	 * @return the mobilenumberId
	 */
	public static String getMobilenumberId() {
		return MOBILENUMBER_ID;
	}

	/**
	 * @return the homephonecodeId
	 */
	public static String getHomephonecodeId() {
		return HOMEPHONECODE_ID;
	}

	/**
	 * @return the homephonenumberId
	 */
	public static String getHomephonenumberId() {
		return HOMEPHONENUMBER_ID;
	}

	/**
	 * @return the workphonecodeId
	 */
	public static String getWorkphonecodeId() {
		return WORKPHONECODE_ID;
	}

	/**
	 * @return the workphonenumberId
	 */
	public static String getWorkphonenumberId() {
		return WORKPHONENUMBER_ID;
	}

	/**
	 * @return the workphoneextnumberId
	 */
	public static String getWorkphoneextnumberId() {
		return WORKPHONEEXTNUMBER_ID;
	}

	/**
	 * @return the faxcodeId
	 */
	public static String getFaxcodeId() {
		return FAXCODE_ID;
	}

	/**
	 * @return the faxnumberId
	 */
	public static String getFaxnumberId() {
		return FAXNUMBER_ID;
	}

	/**
	 * @return the emailId
	 */
	public static String getEmailId() {
		return EMAIL_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
