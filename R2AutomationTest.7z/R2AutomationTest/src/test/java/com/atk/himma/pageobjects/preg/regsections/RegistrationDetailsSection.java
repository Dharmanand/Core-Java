package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RegistrationDetailsSection extends DriverWaitClass{
	
	private final static String SECTIONNAME_LINKTEXT = "Registration Details";
	
	@FindBy(linkText=SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}
	
}
