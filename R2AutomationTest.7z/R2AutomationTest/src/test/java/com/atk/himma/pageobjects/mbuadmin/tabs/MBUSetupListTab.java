package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class MBUSetupListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "mbuSearch";
	public final static String MBULISTTAB_XPATH = "//a[@title='Main Business Unit List']";
	public final static String MBUNAME_ID = "shortNameSearch";
	public final static String MBUTYPE_ID = "MBU_TYPE";
	public final static String SHORTNAME_ID = "shortNameSearch";
	public final static String MBUCODE_ID = "mbuCodeSearch";
	public final static String STATUS_ID = "mbuNameSearchDD";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "mbuGridList";
	public final static String GRID_MBUCODE_ARIA_DESCRIBEDBY = "mbuGridList_mainBusinessUnit.unitCode";
	public final static String GRID_SHORTNAME_ARIA_DESCRIBEDBY = "mbuGridList_mbuSetup.shortName";
	public final static String GRID_MBUTYPE_ARIA_DESCRIBEDBY = "mbuGridList_mbuSetup.mbuTypeText";
	public final static String GRID_MBUNAME_ARIA_DESCRIBEDBY = "mbuGridList_mainBusinessUnit.unitName";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "mbuGridList_mbuSetup.recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_mbuGridList_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_mbuGridList_pager']/span";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = MBULISTTAB_XPATH)
	private WebElement mbuListTab;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;

	@FindBy(id = MBUTYPE_ID)
	private WebElement mbuType;

	@FindBy(id = SHORTNAME_ID)
	private WebElement shortName;

	@FindBy(id = MBUCODE_ID)
	private WebElement mbuCode;

	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	// ---------------------------------------------- Grid Start
	// -----------------------------------------

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	// pager
	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the mbuListTab
	 */
	public WebElement getMbuListTab() {
		return mbuListTab;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the mbuType
	 */
	public WebElement getMbuType() {
		return mbuType;
	}

	/**
	 * @return the shortName
	 */
	public WebElement getShortName() {
		return shortName;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the status
	 */
	public WebElement getStatus() {
		return status;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	// ---------------------------------------------- Grid End
	// -----------------------------------------
}
