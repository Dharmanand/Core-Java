package com.atk.himma.pageobjects.mbuadmin.sections.resfeesdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ServiceTariffModifier extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Service Tariff Modifier";
	
	public final static String PERCENTAGE_ID = "MODIFICATION_PATTERN_PERCENTAGE";
	public final static String AMOUNT_ID = "MODIFICATION_PATTERN_AMOUNT";
	public final static String MODIFIERVALUE_ID = "RESOURCE_MODIFIER_VALUE";
	public final static String LOOKUP_ID = "SERACH_SERVICE";
	public final static String MBU_ID = "MBUTEXT_RESOURCE_FEES";
	public final static String SERVICENAME_ID = "SERVICE_NAME_RESOURCE_FEES";
	public final static String SERDEPARTMENT_ID = "SERVICE_DEPARTMENT_RESOURCE_FEES";
	public final static String PERCENTRADIO_ID = "MODIFICATION_PATTERN_PERCENTAGE";
	public final static String AMOUNTRADIO_ID = "MODIFICATION_PATTERN_AMOUNT";
	public final static String SERVICECODE_ID = "SERVICE_CODE_RESOURCE_FEES";
	public final static String SERBASETARIFF_ID = "SERVICE_BASE_TARIFF_RESOURCE_FEES";
	public final static String SERBASETARIFFCURRENCY_ID = "SERVICE_BASE_TARIFF_CURRENCY";
	public final static String MODIFIERTYPE_ID = "RESOURCE_MODIFIER_TYPE";
	public final static String RESSERVICETARIFF_ID = "RESOURCE_SERVICE_TARIFF";
	public final static String RESSERTARIFFCURRENCY_ID = "RESOURCE_SERVICE_TARIFF_CURRENCY";
	public final static String ADDBUTTON_ID = "SERVICE_TARIFF_MODIFIER_ADD";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Service Tariff Modifier')]/..";
	
//	POPUP
	public final static String PUSERFORM_ID = "SERVICE_LOOKUP";
	public final static String PUSERTITLE_ID = "ui-dialog-title-RESOURCE_FEE_SEARCH";
	public final static String PUMBU_ID = "SER_NAME_POPUP_MBU";
	public final static String PUDEPARTMENT_ID = "SER_NAME_POPUP_DEPT";
	public final static String PUSPECIALTY_ID = "SER_NAME_POPUP_SPECIALITY";
	public final static String PUSUBSPECIALITY_ID = "SER_NAME_POPUP_SUB_SPECIALITY";
	public final static String PUSERVICETYPE_NAME = "nameSearchCriteria.serviceTypeId";
	public final static String PUSERVICECODE_NAME = "nameSearchCriteria.serviceCode";
	public final static String PUSERVICENAME_NAME = "nameSearchCriteria.serviceName";
	
	public final static String SEARCHBUTTON_XPATH = "//form[@id='SERVICE_LOOKUP']//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//form[@id='SERVICE_LOOKUP']//span[@class='buttoncontainer_mid']//input[@value='Reset']";
	
	public final static String GRIDPOP_ID = "RESOURCE_FEES_DETAILS_GRID";
	public final static String GRIDPOP_SERVICENAME_ARIA_DESCRIBEDBY = "RESOURCE_FEES_DETAILS_GRID_serviceInfo.serviceName";
	public final static String GRIDPOP_SERVICECODE_ARIA_DESCRIBEDBY = "RESOURCE_FEES_DETAILS_GRID_serviceInfo.serviceCode";
	public final static String GRIDPOP_BASEPRICE_ARIA_DESCRIBEDBY = "RESOURCE_FEES_DETAILS_GRID_modifiedPrice";
	public final static String GRIDPOP_PAGERID = "sp_1_RESOURCE_FEES_DETAILS_GRID_pager";
//	
	public final static String GRID_ID = "CODE_REFERENCE_TARIFF_LIST_GRID";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "CODE_REFERENCE_TARIFF_LIST_GRID_serviceInfo.serviceName";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "CODE_REFERENCE_TARIFF_LIST_GRID_serviceInfo.serviceCode";
	public final static String GRID_PAGERID = "sp_1_CODE_REFERENCE_TARIFF_LIST_GRID_pager";

	
	@FindBy(id = SERVICENAME_ID)
	private WebElement serviceName;
	
	@FindBy(id = PERCENTAGE_ID)
	private WebElement percentage;
	
	@FindBy(id = AMOUNT_ID)
	private WebElement amount;
	
	@FindBy(id = MODIFIERVALUE_ID)
	private WebElement modifierValue;
	
	@FindBy(id = PUSERFORM_ID)
	private WebElement puSerForm;
	
	@FindBy(id = PUSERTITLE_ID)
	private WebElement puSerTitle;
	
	@FindBy(id = PUMBU_ID)
	private WebElement puMBU;
	
	@FindBy(id = PUDEPARTMENT_ID)
	private WebElement puDepartment;
	
	@FindBy(id = PUSPECIALTY_ID)
	private WebElement puSpecialty;
	
	@FindBy(id = PUSUBSPECIALITY_ID)
	private WebElement puSubSpeciality;
	
	@FindBy(name = PUSERVICETYPE_NAME)
	private WebElement puServiceType;
	
	@FindBy(name = PUSERVICECODE_NAME)
	private WebElement puServiceCode;
	
	@FindBy(name = PUSERVICENAME_NAME)
	private WebElement puServiceName;
	
	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;
	
	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = LOOKUP_ID)
	private WebElement lookUp;
	
	@FindBy(id = SERDEPARTMENT_ID)
	private WebElement serDepartment;
	
	@FindBy(id = PERCENTRADIO_ID)
	private WebElement percentRadio;
	
	@FindBy(id = AMOUNTRADIO_ID)
	private WebElement amountRadio;
	
	@FindBy(id = SERVICECODE_ID)
	private WebElement serviceCode;
	
	@FindBy(id = SERBASETARIFF_ID)
	private WebElement serBaseTariff;
	
	@FindBy(id = SERBASETARIFFCURRENCY_ID)
	private WebElement serBaseTariffCurrency;
	
	@FindBy(id = MODIFIERTYPE_ID)
	private WebElement modifierType;
	
	@FindBy(id = RESSERVICETARIFF_ID)
	private WebElement resServiceTariff;
	
	@FindBy(id = RESSERTARIFFCURRENCY_ID)
	private WebElement resSerTariffCurrency;
	
	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;

	public boolean checkRegConfigSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillResourceFeeDatas(String[] resFeeDatas)
			throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(LOOKUP_ID);
		sleepVeryShort();
		lookUp.click();
		waitForElementId(PUSERFORM_ID);
		sleepVeryShort();
		puServiceName.click();
		puServiceName.sendKeys(resFeeDatas[12].trim());
		searchButton.click();
		waitForElementId(GRIDPOP_ID);
		clickOnGridAction(resFeeDatas[12].trim(), "Select");
		sleepShort();
		new Select(modifierType).selectByVisibleText(resFeeDatas[13].trim());
		selectRadioButtonAsLabelText(resFeeDatas[14].trim());
		modifierValue.sendKeys(resFeeDatas[15].trim());
		addButton.click();
		sleepShort();
		System.out.println("---*****************--->>>>"+serviceName.getAttribute("value").trim());
		return waitAndGetGridFirstCellText(GRID_ID, GRID_SERVICENAME_ARIA_DESCRIBEDBY, resFeeDatas[12].trim()).equals(resFeeDatas[12].trim());
	}
	
	/**
	 * @return the puSerForm
	 */
	public WebElement getPuSerForm() {
		return puSerForm;
	}

	/**
	 * @return the puSerTitle
	 */
	public WebElement getPuSerTitle() {
		return puSerTitle;
	}

	/**
	 * @return the puMBU
	 */
	public WebElement getPuMBU() {
		return puMBU;
	}

	/**
	 * @return the puDepartment
	 */
	public WebElement getPuDepartment() {
		return puDepartment;
	}

	/**
	 * @return the puSpecialty
	 */
	public WebElement getPuSpecialty() {
		return puSpecialty;
	}

	/**
	 * @return the puSubSpeciality
	 */
	public WebElement getPuSubSpeciality() {
		return puSubSpeciality;
	}

	/**
	 * @return the puServiceType
	 */
	public WebElement getPuServiceType() {
		return puServiceType;
	}

	/**
	 * @return the puServiceCode
	 */
	public WebElement getPuServiceCode() {
		return puServiceCode;
	}

	/**
	 * @return the puServiceName
	 */
	public WebElement getPuServiceName() {
		return puServiceName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the lookUp
	 */
	public WebElement getLookUp() {
		return lookUp;
	}

	/**
	 * @return the serDepartment
	 */
	public WebElement getSerDepartment() {
		return serDepartment;
	}

	/**
	 * @return the percentRadio
	 */
	public WebElement getPercentRadio() {
		return percentRadio;
	}

	/**
	 * @return the amountRadio
	 */
	public WebElement getAmountRadio() {
		return amountRadio;
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the serBaseTariff
	 */
	public WebElement getSerBaseTariff() {
		return serBaseTariff;
	}

	/**
	 * @return the serBaseTariffCurrency
	 */
	public WebElement getSerBaseTariffCurrency() {
		return serBaseTariffCurrency;
	}

	/**
	 * @return the modifierType
	 */
	public WebElement getModifierType() {
		return modifierType;
	}

	/**
	 * @return the resServiceTariff
	 */
	public WebElement getResServiceTariff() {
		return resServiceTariff;
	}

	/**
	 * @return the resSerTariffCurrency
	 */
	public WebElement getResSerTariffCurrency() {
		return resSerTariffCurrency;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the percentage
	 */
	public WebElement getPercentage() {
		return percentage;
	}

	/**
	 * @return the amount
	 */
	public WebElement getAmount() {
		return amount;
	}

	/**
	 * @return the modifierValue
	 */
	public WebElement getModifierValue() {
		return modifierValue;
	}
	
}
