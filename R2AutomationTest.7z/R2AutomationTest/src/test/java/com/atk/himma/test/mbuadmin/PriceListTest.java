package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.PriceListPage;
import com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails.PriceListFirstSection;
import com.atk.himma.pageobjects.mbuadmin.tabs.PriceListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class PriceListTest extends SeleniumDriverSetup{

	List<String[]> priceListDatas;
	PriceListPage priceListPage;

	@Test(description="Open Service Page")
	public void clickOnPLMenu() throws InterruptedException {
		priceListPage = PageFactory.initElements(webDriver, PriceListPage.class);
		priceListPage = priceListPage.clickOnPriceListMenu(webDriver, webDriverWait);
		priceListPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(priceListPage);
		priceListPage
				.waitForElementVisibilityOf(priceListPage
						.getPriceListTab().getSearchButton());
		priceListPage
		.waitForElementXpathExpression(PriceListTab.SEARCHBUTTON_XPATH);
		priceListPage.sleepShort();
		Assert.assertEquals(priceListPage.getPriceListTab().getPriceListTab().getAttribute("title").trim(),
				"Price List", "Fail to open Price List page.");
	}

	// [Price List] Open Form
	@Test(description = "Open Price List Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkPriceListMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		priceListPage = PageFactory.initElements(webDriver,
				PriceListPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"Price List");
		priceListPage.setWebDriver(webDriver);
		priceListPage.setWebDriverWait(webDriverWait);
		priceListPage
				.waitForElementXpathExpression(PriceListPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[Price List] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PriceListPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Price List] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			priceListPage = priceListPage.clickOnPriceListMenu(webDriver, webDriverWait);
			priceListPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(priceListPage);
			priceListPage
					.waitForElementVisibilityOf(priceListPage
							.getPriceListTab().getSearchButton());
			priceListPage
			.waitForElementXpathExpression(PriceListTab.SEARCHBUTTON_XPATH);
			priceListPage.sleepShort();
			Assert.assertEquals(priceListPage.getPriceListTab().getPriceListTab().getAttribute("title").trim(),
					"Price List", "Fail to open Price List page.");
			priceListPage.waitForElementXpathExpression(PriceListTab.ADDNEWPLBUTTON_XPATH);
//			priceListPage.sleepVeryShort();
//			priceListPage.getPriceListTab().getAddNewPLButton().click();
//			priceListPage.waitForElementId(PriceListFirstSection.MBU_ID);
//			priceListPage.waitForElementId(PriceListFirstSection.MBU_ID);
			priceListPage.sleepShort();
		}
	}

	@Test(description="click On Add New Button", dependsOnMethods="clickOnPLMenu")
	public void test1ClickOnAddNewButton() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		priceListDatas = excelReader.read(properties.getProperty("priceList"));
		for (String st[] : priceListDatas)
		Assert.assertEquals(priceListPage.clickOnAddNewButton(st),
				true, "Fail to click On Add New Button.");
	}
	
	@Test(description="click Mandatory Service Short Name", dependsOnMethods="test1ClickOnAddNewButton")
	public void test2IsMandatoryPLShortName() {
			Assert.assertEquals(priceListPage.getPriceListFirstSection().isMandatoryPLShortName(),
					true, "Fail to Mandatory Service Short Name.");
	}
	
	@Test(description="Check Mandatory Price List Name", dependsOnMethods="test1ClickOnAddNewButton")
	public void test3IsMandatoryPLName() {
		Assert.assertEquals(priceListPage.getPriceListFirstSection().isMandatoryPLName(),
				true, "Fail to Check Mandatory Price List Name");
	}
	
	@Test(description="Check Mandatory Price List MBU", dependsOnMethods="test1ClickOnAddNewButton")
	public void test4IsMandatoryMBU() {
		Assert.assertEquals(priceListPage.getPriceListFirstSection().isMandatoryMBU(),
				true, "Fail to Check Mandatory Price List MBU");
	}
	
	@Test(description="Check Mandatory Price List Effective Start Date", dependsOnMethods="test1ClickOnAddNewButton")
	public void test5IsMandatoryEffStartDate() {
		Assert.assertEquals(priceListPage.getPriceListFirstSection().isMandatoryEffStartDate(),
				true, "Fail to Check Mandatory Price List Effective Start Date");
	}
	
	@Test(description="Check Mandatory Price List Effective End Date", dependsOnMethods="test1ClickOnAddNewButton")
	public void test6IsMandatoryEffEndDate() {
		Assert.assertEquals(priceListPage.getPriceListFirstSection().isMandatoryEffEndDate(),
				true, "Fail to Check Mandatory Price List Effective End Date");
	}
	
	@Test(description="Fill datas of Price List First Section", dependsOnMethods="test1ClickOnAddNewButton")
	public void test7FillPLFirstSecDatas() {
		for (String st[] : priceListDatas)
			Assert.assertEquals(priceListPage.getPriceListFirstSection().fillPLFirstSecDatas(st),
					true, "Fail to Fill datas of Price List First Section.");
	}
	
	@Test(description="Retrive Services", dependsOnMethods={"test1ClickOnAddNewButton"})
	public void test8RetriveService() {
			Assert.assertEquals(priceListPage.getPriceListFirstSection().retriveService(),
					false, "Fail to Retrive Services");
	}
	
	@Test(description="Check open Price Modification Parameters", dependsOnMethods={"test1ClickOnAddNewButton"})
	public void test9CheckPriceModifParamSec() throws InterruptedException {
		Assert.assertEquals(priceListPage.getPriceModificationParameters().checkPriceModifParamSection(),
				true, "Fail to Check open Price Modification Parameters");
	}
	
	@Test(description="Fill datas of Price Modification Parameters", dependsOnMethods="test9CheckPriceModifParamSec")
	public void test10FillPLModParamDatas() throws InterruptedException {
		for (String st[] : priceListDatas)
			Assert.assertEquals(priceListPage.getPriceModificationParameters().fillDatas(st),
					true, "Fail to Fill datas of Price Modification Parameters");
	}
	
	@Test(description="Check Service Price List Open", dependsOnMethods={"test1ClickOnAddNewButton", "test10FillPLModParamDatas"})
	public void test11CheckSerPriceListOpen() throws InterruptedException {
		Assert.assertEquals(priceListPage.getServicePriceList().checkServicePriceListOpen(),
				true, "Fail to Service Price List Open");
	}
	
	@Test(description="Save Price List Datas", dependsOnMethods={"test11CheckSerPriceListOpen"})
	public void  test12SavePLDatas() throws InterruptedException, IOException {
			Assert.assertEquals(priceListPage.saveDetailsPage().contains("Update"),
					true, "Failed to Save Price List Datas");
	}
	
	@Test(description="Activate Record", dependsOnMethods="test12SavePLDatas")
	public void  test13ActivateRecord() throws InterruptedException, IOException {
		Assert.assertEquals(priceListPage.activateService().contains("Active"),
				true, "Failed Activate Record");
	}
	
	/*@Test(description="Check Duplicate Price List Data", dependsOnMethods={"test12SavePLDatas"})
	public void test11SaveDuplicatePLData() throws InterruptedException, IOException {
		for (String st[] : priceListDatas)
		{
			priceListPage.waitForElementXpathExpression(PriceListPage.DETAILSUPDATEBUTTON_XPATH);
			priceListPage.getAddNewButton().click();
			priceListPage.waitForElementXpathExpression(PriceListPage.DETAILSSAVEBUTTON_XPATH);
			Assert.assertEquals(priceListPage.getPriceListFirstSection().fillPLFirstSecDatas(st),
					true, "Fail to Fill datas of Price List First Section.");
			Assert.assertTrue(priceListPage.saveDuplicateData(st),"Fail to Check Duplicate Price List Data");
		}
	}*/
	
//	[List Tab] Add New (Button)
	@Test(dependsOnMethods = { "checkPriceListMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Add New (Button) for Privilege")
	public void checkAddNewButtonPrivilege() throws IOException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(PriceListTab.ADDNEWPLBUTTON_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button)");
	}

	@Test(dependsOnMethods = { "checkPriceListMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Price List for Privilege")
	public void searchPLPrivilege() throws Exception {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		priceListDatas = excelReader.read(properties.getProperty("priceList"));
		for (String st[] : priceListDatas.subList(0, 1))
			Assert.assertEquals(
					priceListPage.searchPriceListData(st[8].trim()),
					st[8].trim(), "Fail to Search Price List");
	}
	
//	[List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchPLPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "[List Tab] View (Link in the search result grid)")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ priceListDatas.subList(0, 1).get(0)[8].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");
	}
	
	
//	[List Tab] Delete(Link in the search result grid)
	@Test(dependsOnMethods = { "searchPLPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "[List Tab] Delete(Link in the search result grid)")
	public void checkDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[List Tab] Delete(Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ priceListDatas.subList(0, 1).get(0)[8].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete(Link in the search result grid) privilege");
	}
//	[List Tab] Export to Excel (Button)
	@Test(dependsOnMethods = { "searchPLPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Export to Excel (Button) for Privilege")
	public void checkExpToExcelButPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[List Tab] Export to Excel (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PriceListPage.EXPORTTOEXCEL_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Export to Excel (Button) privilege");
	}
//	[List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "searchPLPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Edit (Link in the search result grid) link for Privilege")
	public void checkEditLinkPrivilege() throws InterruptedException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+  priceListDatas.subList(0, 1).get(0)[8].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
		priceListPage.clickOnGridAction(priceListDatas.subList(0, 1).get(0)[8].trim(), "Edit");
		priceListPage.waitForElementId(PriceListFirstSection.MBU_ID);
		priceListPage.sleepShort();
	}
//	[Details Tab] Publish New Version (Button)
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [Details Tab] Publish New Version (Button) for Privilege")
	public void checkPubNewVerButPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[Details Tab] Publish New Version (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PriceListPage.PUBLISHNEWVERSION_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Details Tab] Publish New Version (Button) privilege");
	}
	
//	[Details Tab] Copy (Button)
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [Details Tab] Copy (Button) for Privilege")
	public void checkCopyButPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Price List")
				.get("[Details Tab] Copy (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PriceListPage.COPYBUTTON_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Details Tab] Copy (Button) privilege");
	}
	
//	[Details Tab] [Section: Audit Trail] View
	
	
}
