package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.contracts.DebtorPage;
import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.AssociatedAgreementsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.ContactPersonDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.DebtorGeneralDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.DebtorSpecificDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.DebtorListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class DebtorTest extends SeleniumDriverSetup {
	DebtorPage debtorPage;
	List<String[]> debtorList;
	List<String[]> serviceExclusionList;
	List<String[]> icdExclusionList;
	List<String[]> itemExclusionList;
	List<String[]> serviceApprvlList;
	List<String[]> icdApprvlList;
	List<String[]> itemApprvlList;

	@Test(description = "Open Debtor Page")
	public void test001OpenDebtorPage() throws Exception {
		debtorPage = PageFactory.initElements(webDriver, DebtorPage.class);
		debtorPage = debtorPage.clickOnDebtorMenu(webDriver, webDriverWait);
		debtorPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		debtorList = excelReader.read(properties.getProperty("debtor"));
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		icdExclusionList = excelReader.read(properties
				.getProperty("ICDExcListDetails"));
		itemExclusionList = excelReader.read(properties
				.getProperty("itemExcListDetails"));
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		icdApprvlList = excelReader.read(properties
				.getProperty("ICDApprvListDetails"));
		itemApprvlList = excelReader.read(properties
				.getProperty("itemApprvListDetails"));

		Assert.assertNotNull(debtorPage);
		debtorPage.waitForElementVisibilityOf(debtorPage.getDebtorListTab()
				.getDebtorListForm());
		debtorPage.waitForElementVisibilityOf(debtorPage.getDebtorListTab()
				.getMbuList());
		Assert.assertTrue(debtorPage.getDebtorListTab().getMbuList()
				.isDisplayed());

	}

	@Test(description = "Check For Add New Debtor Button", dependsOnMethods = { "test001OpenDebtorPage" })
	public void test002CheckForAddNewDebtorBtn() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorListTab().getAddNewDebtorBtn()
				.isDisplayed());
	}

	@Test(description = "Click On Add New Debtor Button", dependsOnMethods = { "test002CheckForAddNewDebtorBtn" })
	public void test003ClickOnAddNewDebtorBtn() throws Exception {
		debtorPage.getDebtorListTab().clickAddNewDebtor();
		debtorPage
				.waitForElementVisibilityOf(debtorPage.getDebtorDetailsForm());
		debtorPage.waitForElementVisibilityOf(debtorPage
				.getDebtorDetailsFirstSection().getDebtorName());
		Assert.assertTrue(debtorPage.getDebtorDetailsFirstSection()
				.getDebtorName().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Debtor Short Name", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test004ValidateDebtorShNameMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorDetailsFirstSection()
				.isMandDebtorShName());

	}

	@Test(description = "Validate Mandatory for Debtor Name", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test005ValidateDebtorNameMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorDetailsFirstSection()
				.isMandDebtorName());

	}

	@Test(description = "Validate Mandatory for MBU", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test006ValidateMBUMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorDetailsFirstSection().isMandMBU());

	}

	@Test(description = "Fill Debtor First Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test007AddDebtorFirstSectionData() throws Exception {
		if (debtorList != null && !debtorList.isEmpty()) {
			for (String[] debtorListData : debtorList.subList(0, 1)) {
				debtorPage.getDebtorDetailsFirstSection().fillData(
						debtorListData);
				Assert.assertEquals(debtorPage.getDebtorDetailsFirstSection()
						.getSelectedMBU(), debtorListData[3]);
			}
		}

	}

	@Test(description = "Validate Mandatory for Country", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test008ValidateCountryMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorGeneralDetailsSection()
				.isMandCountry());
	}

	@Test(description = "Validate Mandatory for District", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test009ValidateDistrictMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorGeneralDetailsSection()
				.isMandDistrict());
	}

	@Test(description = "Validate Mandatory for City/Locality", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test010ValidateCityLocalMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorGeneralDetailsSection()
				.isMandCityLocal());
	}

	@Test(description = "Validate Mandatory for Land Phone 1", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test011ValidateLandPh1MandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorGeneralDetailsSection()
				.isMandLandPh1());
	}

	@Test(description = "Fill Debtor General Details Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test012AddDebtorGeneralDetailsSectionData() throws Exception {
		if (debtorList != null && !debtorList.isEmpty()) {
			for (String[] debtorListData : debtorList.subList(0, 1)) {
				debtorPage.getDebtorGeneralDetailsSection()
						.fillDebtorGeneralDetailsData(debtorListData);
				Assert.assertEquals(debtorPage.getDebtorGeneralDetailsSection()
						.getSelectedCountry(), debtorListData[9]);
			}
		}
	}

	@Test(description = "Validate Mandatory for Currency", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test013ValidateCurrencyMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getDebtorSpecificDetailsSection()
				.isMandCurrency());

	}

	@Test(description = "Fill Debtor Specific Details Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test014AddDebtorSpecificDetailsSectionData() throws Exception {
		if (debtorList != null && !debtorList.isEmpty()) {
			for (String[] debtorListData : debtorList.subList(0, 1)) {
				debtorPage.getDebtorSpecificDetailsSection()
						.fillDebtorSpecificDetailsData(debtorListData);
				Assert.assertEquals(debtorPage
						.getDebtorSpecificDetailsSection()
						.getSelectedCurrency(), debtorListData[23]);
			}
		}

	}

	@Test(description = "Validate Mandatory for Contact Person Name Field", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test015ValidateContactPersonNameMandatoryField()
			throws Exception {
		Assert.assertTrue(debtorPage.getContactPersonDetailsSection()
				.isMandPersonName());

	}

	@Test(description = "Validate Mandatory for Mobile Phone Field", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test016ValidateMobPhMandatoryField() throws Exception {
		Assert.assertTrue(debtorPage.getContactPersonDetailsSection()
				.isMandMobPh());

	}

	@Test(description = "Fill Contact Person Details Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test017AddContactPersonDetailsSectionData() throws Exception {
		if (debtorList != null && !debtorList.isEmpty()) {
			for (String[] debtorListData : debtorList.subList(0, 1)) {
				debtorPage.getContactPersonDetailsSection()
						.fillContactPersonDetailsData(debtorListData);
				Assert.assertEquals(debtorPage.getContactPersonDetailsSection()
						.getSelectedMobCC(), debtorListData[33]);
			}
		}

	}

	@Test(description = "Expand Exclusion List Details Section", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test018ExpandExclusionListDetailsSection() throws Exception {
		debtorPage.collapseExpandExcSection();
		Assert.assertTrue(debtorPage.getExcSectionDiv().isDisplayed());

	}

	@Test(description = "Expand Approval List Details Section", dependsOnMethods = { "test003ClickOnAddNewDebtorBtn" })
	public void test019ExpandApprovalListDetailsSection() throws Exception {
		debtorPage.collapseExpandApprvlSection();
		Assert.assertTrue(debtorPage.getApprvlSectionDiv().isDisplayed());

	}

	@Test(description = "Add Service Pattern Exclusion List Details", dependsOnMethods = { "test018ExpandExclusionListDetailsSection" })
	public void test020AddServiceExclusionListDetailsData() throws Exception {
		if (serviceExclusionList != null && !serviceExclusionList.isEmpty()) {
			for (String[] serviceExclusionListData : serviceExclusionList
					.subList(1, 2)) {
				debtorPage.getExclusionListDetailsSection()
						.addServiceExclusionData(serviceExclusionListData);
				Assert.assertEquals(debtorPage.getExclusionListDetailsSection()
						.getServiceLvlName().getAttribute("value"),
						serviceExclusionListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Exclusion List Details", dependsOnMethods = { "test018ExpandExclusionListDetailsSection" })
	public void test021AddICDExclusionListDetailsData() throws Exception {
		if (icdExclusionList != null && !icdExclusionList.isEmpty()) {
			for (String[] icdExclusionListData : icdExclusionList.subList(1, 2)) {
				debtorPage.getExclusionListDetailsSection()
						.addICDExclusionData(icdExclusionListData);
				Assert.assertEquals(debtorPage.getExclusionListDetailsSection()
						.getIcdPatternDesc().getAttribute("value"),
						icdExclusionListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Exclusion List Details", dependsOnMethods = { "test018ExpandExclusionListDetailsSection" })
	public void test022AddItemExclusionListDetailsData() throws Exception {
		if (itemExclusionList != null && !itemExclusionList.isEmpty()) {
			for (String[] itemExclusionListData : itemExclusionList.subList(1,
					2)) {
				debtorPage.getExclusionListDetailsSection()
						.addItemExclusionData(itemExclusionListData);
				Assert.assertEquals(debtorPage.getExclusionListDetailsSection()
						.checkItemLevelData(itemExclusionListData),
						itemExclusionListData[1]);
			}
		}
	}

	@Test(description = "Add Service Pattern Approval List Details", dependsOnMethods = { "test019ExpandApprovalListDetailsSection" })
	public void test023AddServiceApprovalListDetailsData() throws Exception {

		if (serviceApprvlList != null && !serviceApprvlList.isEmpty()) {
			for (String[] serviceApprvlListData : serviceApprvlList.subList(1,
					2)) {
				debtorPage.getApprovalListDetailsSection()
						.addServiceApprvlData(serviceApprvlListData);
				Assert.assertEquals(debtorPage.getApprovalListDetailsSection()
						.getServiceLvlName().getAttribute("value"),
						serviceApprvlListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Approval List Details", dependsOnMethods = { "test019ExpandApprovalListDetailsSection" })
	public void test024AddICDApprvlListDetailsData() throws Exception {
		if (icdApprvlList != null && !icdApprvlList.isEmpty()) {
			for (String[] icdApprvlListData : icdApprvlList.subList(1, 2)) {
				debtorPage.getApprovalListDetailsSection().addICDApprvlData(
						icdApprvlListData);
				Assert.assertEquals(debtorPage.getApprovalListDetailsSection()
						.getIcdDescription().getAttribute("value"),
						icdApprvlListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Approval List Details", dependsOnMethods = { "test019ExpandApprovalListDetailsSection" })
	public void test025AddItemApprvlListDetailsData() throws Exception {
		if (itemApprvlList != null && !itemApprvlList.isEmpty()) {
			for (String[] itemApprvlListData : itemApprvlList.subList(1, 2)) {
				debtorPage.getApprovalListDetailsSection().addItemApprvlData(
						itemApprvlListData);
				Assert.assertEquals(debtorPage.getApprovalListDetailsSection()
						.checkItemLevelData(itemApprvlListData),
						itemApprvlListData[1]);
			}
		}
	}

	@Test(description = "Save Debtor", dependsOnMethods = {
			"test007AddDebtorFirstSectionData",
			"test012AddDebtorGeneralDetailsSectionData",
			"test014AddDebtorSpecificDetailsSectionData",
			"test017AddContactPersonDetailsSectionData" })
	public void test026SaveDebtor() throws Exception {
		debtorPage.saveDebtor();
		Assert.assertTrue(debtorPage.getUpdateBtn().isEnabled()
				&& debtorPage.getAddNewDebtorBtn().isEnabled());

	}

	@Test(description = "Activate Record", dependsOnMethods = { "test026SaveDebtor" })
	public void test027ActivateRecord() throws Exception {
		Assert.assertEquals(debtorPage.activateRecord().contains("Active"),
				true, "Failed Activate Record");

	}

	@Test(description = "Verify Debtor Name in Agreement Creation", dependsOnMethods = { "test027ActivateRecord" })
	public void test028VerifyDebtorName() throws Exception {
		debtorPage.clickAddNewAgrmntBtn();
		for (String[] debtorListData : debtorList.subList(0, 1)) {
			String debName = debtorPage.verifyDebtor(debtorListData);
			Assert.assertEquals(debName, debtorListData[1]);
		}

	}

	@Test(description = "Check Add New Functionality", dependsOnMethods = { "test027ActivateRecord" })
	public void test029CheckAddNewFun() throws Exception {
		debtorPage.clickAddNewBtn();
		String debShName = debtorPage.getDebtorDetailsFirstSection()
				.checkFieldValue();
		Assert.assertEquals(debShName, "", "Failed Add New Functionality");

	}

	// [Debtor] Open Form
	@Test(description = "Check Debtor Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckDebtorPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		debtorPage = PageFactory.initElements(webDriver, DebtorPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> dbtrParentMenuList = new LinkedList<String>();
		dbtrParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(dbtrParentMenuList, "Debtor");
		debtorPage.setWebDriver(webDriver);
		debtorPage.setWebDriverWait(webDriverWait);
		debtorPage.waitForElementXpathExpression(DebtorPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor").get("[Debtor] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Debtor] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			debtorPage = debtorPage.clickOnDebtorMenu(webDriver, webDriverWait);
			debtorPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(debtorPage);
			debtorPage.waitForElementVisibilityOf(debtorPage.getDebtorListTab()
					.getDebtorListForm());
			debtorPage.sleepShort();
			Assert.assertEquals(debtorPage.getPageTitle().getText(), "Debtor");
		}

	}

	// [List Tab] Add New Debtor (Button)
	@Test(description = "Check Add New Debtor Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorPageMenuLink")
	public void test02CheckAddNewDebtorBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[List Tab] Add New Debtor (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(DebtorListTab.ADDNEWDEBTORBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Add New Debtor (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		debtorList = excelReader.read(properties.getProperty("debtor"));
		for (String[] debtorData : debtorList) {
			debtorPage.getDebtorListTab().searchDebtorList(debtorData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorListTab.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorPageMenuLink")
	public void test04CheckLink2Delete() throws Exception {
		debtorList = excelReader.read(properties.getProperty("debtor"));
		for (String[] debtorData : debtorList) {
			debtorPage.getDebtorListTab().searchDebtorList(debtorData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorPageMenuLink")
	public void test05CheckLink3Edit() throws Exception {
		debtorList = excelReader.read(properties.getProperty("debtor"));
		for (String[] debtorData : debtorList) {
			debtorPage.getDebtorListTab().searchDebtorList(debtorData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		debtorPage.getDebtorListTab().clickEditLink(debtorList.get(0));
	}

	// [Details Tab][Section: Debtor General Details] View
	@Test(description = "Check Debtor General Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test06CheckDbtrGnlDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[Details Tab][Section: Debtor General Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(DebtorGeneralDetailsSection.DEBTORGENLDETAILSSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Debtor General Details] View privilege");
	}

	// [Details Tab][Section: Debtor Specific Details] View
	@Test(description = "Check Debtor General Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test07CheckDbtrSpecDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[Details Tab][Section: Debtor Specific Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(DebtorSpecificDetailsSection.DEBTORSPECDETAILSSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Debtor Specific Details] View privilege");
	}

	// [Details Tab][Section: Contact Person(s) Details] View
	@Test(description = "Check Contact Person(s) Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test08CheckContactPersonDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[Details Tab][Section: Contact Person(s) Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ContactPersonDetailsSection.CONTACTPERSONDETAILSSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Details Tab][Section: Contact Person(s) Details] View privilege");
	}

	// [Details Tab][Section: Associated Agreements] View
	@Test(description = "Check Associated Agreements Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test09CheckAssociatedAgreementsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[Details Tab][Section: Associated Agreements] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(AssociatedAgreementsSection.ASSOCIATEDAGRMNTSSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Associated Agreements] View privilege");
	}

	// [Details Tab][Section: Exclusion List Details] View
	@Test(description = "Check Exclusion List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test10CheckExcListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[Details Tab][Section: Exclusion List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ExclusionListDetailsSection.EXCLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] View privilege");
		if (actualPrivilage)
			debtorPage.collapseExpandExcSection();
	}

	// [Details Tab][Section: Exclusion List Details] Add Record (Button)
	@Test(description = "Check Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckExcListDetailsSec")
	public void test12CheckExcAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Exclusion List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Edit Record (Inline
	// editing in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckExcListDetailsSec")
	public void test13CheckExcInlineEditRecord() throws Exception {
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		debtorPage.getExclusionListDetailsSection().clickExcListRecord(
				serviceExclusionList.get(1));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.name(ExclusionListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link In Exc Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckExcListDetailsSec")
	public void test14CheckDelLinkInExcGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVEXCDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Apply the Above Exclusion
	// List To (Check box group)
	@Test(description = "Check Apply the Above Exclusion List to Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckExcListDetailsSec")
	public void test15CheckApplyExcListToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Exclusion List Details] Apply the Above Exclusion List To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ExclusionListDetailsSection.APPLYEXCLISTTOCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Apply the Above Exclusion List To (Check box group) privilege");
	}

	// [Details Tab][Section: Approval List Details] View
	@Test(description = "Check Approval List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test11CheckApprvlListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor")
				.get("[Details Tab][Section: Approval List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ApprovalListDetailsSection.APPRVLLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] View privilege");
		if (actualPrivilage)
			debtorPage.collapseExpandApprvlSection();
	}

	// [Details Tab][Section: Approval List Details] Add Record (Button)
	@Test(description = "Check Approval List Details Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test11CheckApprvlListDetailsSec")
	public void test16CheckAppAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Approval List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Approval List Details] Edit Record (Inline editing
	// in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test11CheckApprvlListDetailsSec")
	public void test17CheckInlineEditRecord() throws Exception {
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		debtorPage.getApprovalListDetailsSection().clickApprvlListRecord(
				serviceApprvlList.get(1));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.name(ApprovalListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link in Approval List Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test11CheckApprvlListDetailsSec")
	public void test18CheckDelLinkInApprvlGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Approval List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVAPPRVLDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Apply the Above Approval
	// List To (Check box group)
	@Test(description = "Check Apply the Above Approval List to Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test11CheckApprvlListDetailsSec")
	public void test19CheckApplyApprvlToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor")
				.get("[Details Tab][Section: Approval List Details] Apply the Above Approval List To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ApprovalListDetailsSection.APPLYAPPRVLLISTTOCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Apply the Above Approval List To (Check box group) privilege");
	}

	// [Details Tab][Section: Applicable Main Business Units] View

	// [Details Tab][Section: Audit Trail] View

}
