package com.atk.himma.pageobjects.pharmacy.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class TherapClassificationsPage extends DriverWaitClass {

	public final static String FORM_ID = "THERAPEUTIC_CLASS_FORM";
	public final static String SAVEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Save']";
	public final static String CANCELBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Cancel']";
	public final static String SEARCHBUTTON_ID = "SEARCH_BUTTON";
	public final static String ADDBUTTON_ID = "ADD_BUTTON";
	public final static String ANATMAINGROUP_ID = "ANATOMICAL_MAIN_GROUP_ID";
	public final static String THERAPEUTICGRP_ID = "THERAPEUTIC_GROUP_ID";
	public final static String PHARLOGSUBGRP_ID = "PHARMACOLOGICAL_SUB_GROUP_ID";

	public final static String GRID_ID = "THERAPEUTIC_CLASS_MASTER_GRID";
	public final static String GRID_ANATMAINGROUP_ARIA_DESCRIBEDBY = "THERAPEUTIC_CLASS_MASTER_GRID_anatomicalMainGroupText";
	public final static String GRID_THERAPEUTICGROUP_ARIA_DESCRIBEDBY = "THERAPEUTIC_CLASS_MASTER_GRID_therapeuticGroupText";
	public final static String GRID_PHARLOGSUBGRP_ARIA_DESCRIBEDBY = "THERAPEUTIC_CLASS_MASTER_GRID_pharmacologicalSubGroupText";
	public final static String GRID_CHEMSUBGROUP_ARIA_DESCRIBEDBY = "THERAPEUTIC_CLASS_MASTER_GRID_chemicalSubGroupText";
	public final static String GRID_PAGERID = "sp_1_THERAPEUTIC_CLASS_MASTER_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_THERAPEUTIC_CLASS_MASTER_GRID_pager']";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = SAVEBUTTON_CSS)
	private WebElement saveButton;

	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButton;
	
	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(id = ANATMAINGROUP_ID)
	private WebElement anatMainGroup;

	@FindBy(id = THERAPEUTICGRP_ID)
	private WebElement therapeuticGrp;

	@FindBy(id = PHARLOGSUBGRP_ID)
	private WebElement pharmacoLogicalubGrp;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the anatmainGroup
	 */
	public WebElement getAnatMainGroup() {
		return anatMainGroup;
	}

	/**
	 * @return the therapeuticGrp
	 */
	public WebElement getTherapeuticGrp() {
		return therapeuticGrp;
	}

	/**
	 * @return the pharmacoLogicalubGrp
	 */
	public WebElement getPharmacoLogicalubGrp() {
		return pharmacoLogicalubGrp;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}
	
	public TherapClassificationsPage setInstanceOfAllSection(
			WebDriver webDriver, WebDriverWait webDriverWait) {
		TherapClassificationsPage therapClassificationsPage = PageFactory
				.initElements(webDriver, TherapClassificationsPage.class);
		therapClassificationsPage.setWebDriver(webDriver);
		therapClassificationsPage.setWebDriverWait(webDriverWait);
		return therapClassificationsPage;
	}

	public TherapClassificationsPage checkTherapClassificationsLink(
			WebDriver webDriver, WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(menuList, "Therapeutic Class");
		TherapClassificationsPage therapClassificationsPage = PageFactory
				.initElements(webDriver, TherapClassificationsPage.class);
		return therapClassificationsPage;
	}

	public TherapClassificationsPage clickTherapClassificationsMenu()
			throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Therapeutic Class");
		TherapClassificationsPage therapClassificationsPage = PageFactory
				.initElements(webDriver, TherapClassificationsPage.class);
		therapClassificationsPage.setWebDriver(webDriver);
		therapClassificationsPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForElementId(GRID_ID);
		return therapClassificationsPage;
	}

	public void selORUnSelChemicalSubGrp(String chemicalSubGrps, boolean selectFlag) {
		String chemSubGrps[] = chemicalSubGrps.split("\\,");
		for (String chSubGrp : chemSubGrps) {
			WebElement element = webDriver
					.findElement(By.xpath("//span[contains(text(), '"
							+ chSubGrp.trim()
							+ "')]/../input[@name='multiselect_CHEMICAL_SUB_GROUP_ID']"));
			if ((!element.isSelected() && selectFlag) || (element.isSelected() && !selectFlag))
				element.click();
		}
	}
	
	public boolean isMandatoryAnatMainGroup() {
		return isMandatoryField(anatMainGroup);
	}

	public boolean isMandatoryTherapeuticGrp() {
		return isMandatoryField(therapeuticGrp);
	}

	public boolean isMandatoryPharmacoLogicalubGrp() {
		return isMandatoryField(pharmacoLogicalubGrp);
	}

	public boolean fillTherapClassifDatas(String[] therapClassifDatas) {
		
		if (!therapClassifDatas[0].isEmpty()) {
			new Select(anatMainGroup).selectByVisibleText(therapClassifDatas[0].trim());
		}
		
		if (!therapClassifDatas[1].isEmpty()) {
			new Select(therapeuticGrp).selectByVisibleText(therapClassifDatas[1].trim());
		}
		
		if (!therapClassifDatas[2].isEmpty()) {
			new Select(pharmacoLogicalubGrp).selectByVisibleText(therapClassifDatas[2].trim());
		}
		
		if (!therapClassifDatas[3].isEmpty()) {
			selORUnSelChemicalSubGrp(therapClassifDatas[3], true);
		}
		
		return new Select(pharmacoLogicalubGrp).getFirstSelectedOption().getText().trim() == therapClassifDatas[2]
				.trim();
	}
	
	public boolean clearData(String[] therapClassifDatas) throws InterruptedException
	{
		waitForElementId(CANCELBUTTON_CSS);
		fillTherapClassifDatas(therapClassifDatas);
		cancelButton.click();
		sleepShort();
		return new Select(anatMainGroup).getFirstSelectedOption().getText().trim().equals("Select");
	}
	
	public boolean addData(String[] therapClassifDatas) throws InterruptedException
	{
		fillTherapClassifDatas(therapClassifDatas);
		waitForPageLoaded(webDriver);
		return waitAndGetGridFirstCellText(GRID_ID, GRID_ANATMAINGROUP_ARIA_DESCRIBEDBY, therapClassifDatas[0].trim()).trim().equals(therapClassifDatas[0].trim());
	}
	
	public boolean saveData(String[] therapClassifDatas) throws InterruptedException {
		waitForElementCssSelector(SAVEBUTTON_CSS);
		saveButton.click();
		waitForPageLoaded(webDriver);
		return clickOnCheckBoxGridItem(GRID_ID,therapClassifDatas[0].trim());
	}

	public boolean searchData() throws InterruptedException
	{
		waitForElementId(SEARCHBUTTON_ID);
		searchButton.click();
		sleepShort();
		return new Select(anatMainGroup).getFirstSelectedOption().getText().trim().equals("Select");
	}
	
}
