package com.atk.himma.pageobjects.contracts.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class DebtorListTab extends DriverWaitClass {
	public final static String DEBTORLISTFORM_ID = "DEBTOR_FORM";
	public final static String ADDNEWDEBTORBTN_ID = "ADD_NEW_DEBTOR_S";
	public final static String MBULIST_ID = "MBU_S";
	public final static String GLOBALDEBTORCHKBOX_ID = "DEB_GLOBAL_CHBOX";
	public final static String DEBTORTYPE_ID = "DEBTOR_TYPE_S";
	public final static String DEBTORCATEGORY_ID = "DEBTOR_CATEGORY_S";
	public final static String DEBTORNAME_ID = "DEBTOR_NAME_S";
	public final static String DEBTORSHORTNAME_ID = "DEBTOR_SHORT_NAME_S";
	public final static String DEBTORCODE_ID = "DEBTOR_CODE_S";
	public final static String STATUS_ID = "MAIN_STATUS_S";
	public final static String DEBTORSEARCHBTN_XPATH = "//form[@id='DEBTOR_FORM']//input[@value='Search']";
	public final static String DEBTORRESETBTN_XPATH = "//form[@id='DEBTOR_FORM']//input[@value='Reset ']";
	public final static String DEBTORSEARCHGRID_ID = "DEBTOR_SEARCH_GRID";
	public final static String VIEWLINK_XPATH = ".//table[@id='debtor_search_grid']/..//a[text()='View']";
	public final static String EDITLINK_XPATH = ".//table[@id='debtor_search_grid']/..//a[text()='Edit']";
	public final static String DELETELINK_XPATH = ".//table[@id='debtor_search_grid']/..//a[text()='Delete']";

	@FindBy(id = DEBTORLISTFORM_ID)
	private WebElement debtorListForm;

	@FindBy(id = ADDNEWDEBTORBTN_ID)
	private WebElement addNewDebtorBtn;

	@FindBy(id = MBULIST_ID)
	private WebElement mbuList;

	@FindBy(id = GLOBALDEBTORCHKBOX_ID)
	private WebElement globalDebtorChkBox;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = DEBTORCATEGORY_ID)
	private WebElement debtorCategory;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = DEBTORSHORTNAME_ID)
	private WebElement debtorShortName;

	@FindBy(id = DEBTORCODE_ID)
	private WebElement debtorCode;

	@FindBy(id = STATUS_ID)
	private WebElement status;

	@FindBy(xpath = DEBTORSEARCHBTN_XPATH)
	private WebElement debtorSearchBtn;

	@FindBy(xpath = DEBTORRESETBTN_XPATH)
	private WebElement debtorResetBtn;

	@FindBy(xpath = DEBTORSEARCHGRID_ID)
	private WebElement debtorSearchGrid;

	@FindBy(xpath = VIEWLINK_XPATH)
	private WebElement viewLink;

	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public void clickAddNewDebtor() throws Exception {
		addNewDebtorBtn.click();
		sleepShort();

	}

	public void searchDebtorList(String[] debtorData) throws Exception {
		if (!debtorData[3].isEmpty()) {
			new Select(mbuList).selectByVisibleText(debtorData[3]);
		}

		if (Boolean.valueOf(debtorData[4])) {
			globalDebtorChkBox.click();
		}

		if (!debtorData[6].isEmpty()) {
			new Select(debtorType).selectByVisibleText(debtorData[6]);
		}

		if (!debtorData[5].isEmpty()) {
			new Select(debtorCategory).selectByVisibleText(debtorData[5]);
		}

		if (!debtorData[1].isEmpty()) {
			new Select(debtorName).selectByVisibleText(debtorData[1]);
		}
		debtorShortName.clear();
		debtorShortName.sendKeys(debtorData[0]);

		debtorSearchBtn.click();
		waitForElementId(DEBTORSEARCHGRID_ID);
		sleepShort();

	}
	
	public void clickEditLink(String[] debtorData) throws Exception {
		clickOnGridAction("debtor_search_grid_debtorName", debtorData[1], "Edit");
		sleepShort();
		
	}

	public WebElement getDebtorListForm() {
		return debtorListForm;
	}

	public WebElement getAddNewDebtorBtn() {
		return addNewDebtorBtn;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalDebtorChkBox() {
		return globalDebtorChkBox;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getDebtorCategory() {
		return debtorCategory;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorShortName() {
		return debtorShortName;
	}

	public WebElement getDebtorCode() {
		return debtorCode;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getDebtorSearchBtn() {
		return debtorSearchBtn;
	}

	public WebElement getDebtorResetBtn() {
		return debtorResetBtn;
	}

	public WebElement getDebtorSearchGrid() {
		return debtorSearchGrid;
	}

	public WebElement getViewLink() {
		return viewLink;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
