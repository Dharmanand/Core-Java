package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.contracts.MBUApprovalListPage;
import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.ApprovalListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class MBUApprovalListTest extends SeleniumDriverSetup {
	MBUApprovalListPage mbuApprovalListPage;
	List<String[]> mbuApprovalList;
	List<String[]> serviceApprvlList;
	List<String[]> icdApprvlList;
	List<String[]> itemApprvlList;

	@Test(description = "Open MBU Approval List Page")
	public void test1OpenMBUApprovalListPage() throws Exception {
		mbuApprovalListPage = PageFactory.initElements(webDriver,
				MBUApprovalListPage.class);
		mbuApprovalListPage = mbuApprovalListPage.clickOnMBUApprovalListMenu(
				webDriver, webDriverWait);
		mbuApprovalListPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		Assert.assertNotNull(mbuApprovalListPage);
		mbuApprovalListPage.waitForElementVisibilityOf(mbuApprovalListPage
				.getApprovalListTab().getApprvlListForm());
		mbuApprovalListPage.waitForElementVisibilityOf(mbuApprovalListPage
				.getApprovalListTab().getMbuList());
		Assert.assertTrue(mbuApprovalListPage.getApprovalListTab().getMbuList()
				.isDisplayed());
	}

	@Test(description = "Check for Add New Approval List Button", dependsOnMethods = { "test1OpenMBUApprovalListPage" })
	public void test2CheckForAddNewApprvlListBtn() throws Exception {
		Assert.assertTrue(mbuApprovalListPage.getApprovalListTab()
				.getAddNewApprvlListBtn().isDisplayed());
	}

	@Test(description = "Click On Add New Approval List Button", dependsOnMethods = { "test2CheckForAddNewApprvlListBtn" })
	public void test3ClickOnAddNewApprvlListBtn() throws Exception {
		mbuApprovalListPage.getApprovalListTab().clickAddNewApprvlList();
		mbuApprovalListPage.waitForElementVisibilityOf(mbuApprovalListPage
				.getAppListDetailsForm());
		mbuApprovalListPage.waitForElementVisibilityOf(mbuApprovalListPage
				.getAppDetailsFirstSection().getAppListName());
		Assert.assertTrue(mbuApprovalListPage.getAppDetailsFirstSection()
				.getAppListName().isDisplayed());
	}

	@Test(description = "Validate Approval List Name Mandatory Field in First Section", dependsOnMethods = { "test3ClickOnAddNewApprvlListBtn" })
	public void test4ValidateApprvlListNameMandatoryField() throws Exception {
		Assert.assertTrue(mbuApprovalListPage.getAppDetailsFirstSection()
				.isMandApprvlListName());
	}

	@Test(description = "Validate Mandatory Fields in First Section", dependsOnMethods = { "test3ClickOnAddNewApprvlListBtn" })
	public void test5ValidateMBUMandatoryField() throws Exception {
		Assert.assertTrue(mbuApprovalListPage.getAppDetailsFirstSection()
				.isMandMBU());
	}

	@Test(description = "Add Data for Approval Details First section", dependsOnMethods = { "test3ClickOnAddNewApprvlListBtn" })
	public void test6AddApprvlListFistSectionData() throws Exception {
		mbuApprovalList = excelReader.read(properties
				.getProperty("MBUApprvList"));
		if (mbuApprovalList != null && !mbuApprovalList.isEmpty()) {
			mbuApprovalListPage.getAppDetailsFirstSection().fillData(
					mbuApprovalList.get(0));

		}
	}

	@Test(description = "Add Service Pattern Approval List Details", dependsOnMethods = { "test6AddApprvlListFistSectionData" })
	public void test7AddServiceApprovalListDetailsData() throws Exception {
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		if (serviceApprvlList != null && !serviceApprvlList.isEmpty()) {
			for (String[] serviceApprvlListData : serviceApprvlList.subList(0,
					1)) {
				mbuApprovalListPage.getApprovalListDetailsSection()
						.addServiceApprvlData(serviceApprvlListData);
				Assert.assertEquals(mbuApprovalListPage
						.getApprovalListDetailsSection().getServiceLvlName()
						.getAttribute("value"), serviceApprvlListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Approval List Details", dependsOnMethods = { "test6AddApprvlListFistSectionData" })
	public void test8AddICDApprvlListDetailsData() throws Exception {
		icdApprvlList = excelReader.read(properties
				.getProperty("ICDApprvListDetails"));
		if (icdApprvlList != null && !icdApprvlList.isEmpty()) {
			for (String[] icdApprvlListData : icdApprvlList.subList(0, 1)) {
				mbuApprovalListPage.getApprovalListDetailsSection()
						.addICDApprvlData(icdApprvlListData);
				Assert.assertEquals(mbuApprovalListPage
						.getApprovalListDetailsSection().getIcdDescription()
						.getAttribute("value"), icdApprvlListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Approval List Details", dependsOnMethods = { "test6AddApprvlListFistSectionData" })
	public void test9AddItemApprvlListDetailsData() throws Exception {
		itemApprvlList = excelReader.read(properties
				.getProperty("itemApprvListDetails"));
		if (itemApprvlList != null && !itemApprvlList.isEmpty()) {
			for (String[] itemApprvlListData : itemApprvlList.subList(0, 1)) {
				mbuApprovalListPage.getApprovalListDetailsSection()
						.addItemApprvlData(itemApprvlListData);
				Assert.assertEquals(
						mbuApprovalListPage.getApprovalListDetailsSection()
								.checkItemLevelData(itemApprvlListData),
						itemApprvlListData[1]);
			}
		}
	}

	@Test(description = "Save Approval List", dependsOnMethods = { "test9AddItemApprvlListDetailsData" })
	public void test10SaveApprovalListDetails() throws Exception {
		mbuApprovalListPage.saveApprvlListDetails();
		Assert.assertTrue(mbuApprovalListPage.getUpdateBtn().isEnabled()
				&& mbuApprovalListPage.getAddNewBtn().isEnabled());
	}

	@Test(description = "Activate Record", dependsOnMethods = { "test10SaveApprovalListDetails" })
	public void test11ActivateRecord() throws Exception {
		Assert.assertEquals(
				mbuApprovalListPage.activateRecord().contains("Active"), true,
				"Failed Activate Record");

	}

	@Test(description = "Check Copy Approval List Details Functionality", dependsOnMethods = { "test11ActivateRecord" })
	public void test12CheckCopyFun() throws Exception {
		if (serviceApprvlList != null && !serviceApprvlList.isEmpty()) {
			for (String[] serviceApprvlListData : serviceApprvlList.subList(0,
					1)) {
				mbuApprovalListPage.clickCopy();
				Assert.assertTrue(mbuApprovalListPage
						.getApprovalListDetailsSection().checkApprvlGrid(
								serviceApprvlListData));
			}

		}

	}

	@Test(description = "Add More New Approval Lists", dependsOnMethods = { "test11ActivateRecord" })
	public void test13AddMoreNewApprovalList() throws Exception {
		mbuApprovalListPage.clickAddMoreNewApprvlList();
		Assert.assertEquals(mbuApprovalListPage.getAppDetailsFirstSection()
				.checkFieldValue(), "");
	}

	@Test(description = "Check Global Approval", dependsOnMethods = { "test13AddMoreNewApprovalList" })
	public void test14CheckGlobalApproval() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		List<String[]> saOrgStructList = excelReader.read(properties
				.getProperty("orgStruct"));
		Assert.assertEquals(mbuApprovalListPage.getAppDetailsFirstSection()
				.checkGlobalApprvl(), saOrgStructList.get(0)[0]);
	}

	@Test(description = "Check Cancel Functionality", dependsOnMethods = { "test14CheckGlobalApproval" }, alwaysRun = true)
	public void test15CheckCancelFun() throws Exception {
		mbuApprovalListPage.clickCancel();
		Assert.assertTrue(mbuApprovalListPage.getApprovalListTab()
				.getApprvlListGridDiv().isDisplayed());
	}

	// [MBU Approval List] Open Form
	@Test(description = "Check MBU Approval List Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckMBUApprovalListPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		mbuApprovalListPage = PageFactory.initElements(webDriver,
				MBUApprovalListPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> appvlParentMenuList = new LinkedList<String>();
		appvlParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(appvlParentMenuList,
				"MBU Approval List");
		mbuApprovalListPage.setWebDriver(webDriver);
		mbuApprovalListPage.setWebDriverWait(webDriverWait);
		mbuApprovalListPage
				.waitForElementXpathExpression(MBUApprovalListPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Approval List")
				.get("[MBU Approval List] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(MBUApprovalListPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [MBU Approval List] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			mbuApprovalListPage = mbuApprovalListPage
					.clickOnMBUApprovalListMenu(webDriver, webDriverWait);
			mbuApprovalListPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(mbuApprovalListPage);
			mbuApprovalListPage.waitForElementVisibilityOf(mbuApprovalListPage
					.getApprovalListTab().getApprvlListForm());
			mbuApprovalListPage.sleepShort();
			Assert.assertEquals(mbuApprovalListPage.getPageTitle().getText(),
					"Main Business Unit Approval List");
		}
	}

	// [List Tab] Add New Approval List (Button)
	@Test(description = "Check Add New Exclusion List Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUApprovalListPageMenuLink")
	public void test02CheckAddNewExcListBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Approval List")
				.get("[List Tab] Add New Approval List (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(ApprovalListTab.ADDNEWAPPLISTBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Add New Approval List (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUApprovalListPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		mbuApprovalList = excelReader.read(properties
				.getProperty("MBUApprvList"));
		for (String[] mbuApprvlData : mbuApprovalList) {
			mbuApprovalListPage.getApprovalListTab().searchApprvlList(
					mbuApprvlData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Approval List")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApprovalListTab.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUApprovalListPageMenuLink")
	public void test04CheckLink2Delete() throws Exception {
		mbuApprovalList = excelReader.read(properties
				.getProperty("MBUApprvList"));
		for (String[] mbuApprvlData : mbuApprovalList) {
			mbuApprovalListPage.getApprovalListTab().searchApprvlList(
					mbuApprvlData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Approval List")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApprovalListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckMBUApprovalListPageMenuLink")
	public void test05CheckLink3Edit() throws Exception {
		mbuApprovalList = excelReader.read(properties
				.getProperty("MBUApprvList"));
		for (String[] mbuApprvlData : mbuApprovalList) {
			mbuApprovalListPage.getApprovalListTab().searchApprvlList(
					mbuApprvlData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Approval List")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ApprovalListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		mbuApprovalListPage.getApprovalListTab().clickEditLink(
				mbuApprovalList.get(0));
	}

	// [Details Tab][Section: Approval List Details] View
	@Test(description = "Check Approval List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test06CheckApprvlListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("MBU Approval List")
				.get("[Details Tab][Section: Approval List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ApprovalListDetailsSection.APPRVLLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] View privilege");
	}

	// [Details Tab][Section: Approval List Details] Add Record (Button)
	@Test(description = "Check Approval List Details Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckApprvlListDetailsSec")
	public void test07CheckAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("MBU Approval List")
				.get("[Details Tab][Section: Approval List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Approval List Details] Edit Record (Inline editing
	// in the grid))
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckApprvlListDetailsSec")
	public void test08CheckInlineEditRecord() throws Exception {
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		mbuApprovalListPage.getApprovalListDetailsSection()
				.clickApprvlListRecord(serviceApprvlList.get(0));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("MBU Approval List")
				.get("[Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid))");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.name(ApprovalListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid)) privilege");
	}

	// [Details Tab][Section: Approval List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link in Approval List Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckApprvlListDetailsSec")
	public void test09CheckDelLinkInApprvlGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("MBU Approval List")
				.get("[Details Tab][Section: Approval List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVAPPRVLDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Applicable Main Business Units] View

	// [Details Tab][Section: Audit Trail] View

}
