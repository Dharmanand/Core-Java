package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.AssociatedAgreementsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.ContactPersonDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.DebtorDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.DebtorGeneralDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtordetails.DebtorSpecificDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.DebtorListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class DebtorPage extends DriverWaitClass implements StatusMessages,
		RecordStatus {
	private DebtorListTab debtorListTab;
	private DebtorDetailsFirstSection debtorDetailsFirstSection;
	private DebtorGeneralDetailsSection debtorGeneralDetailsSection;
	private DebtorSpecificDetailsSection debtorSpecificDetailsSection;
	private ContactPersonDetailsSection contactPersonDetailsSection;
	private AssociatedAgreementsSection associatedAgreementsSection;
	private ExclusionListDetailsSection exclusionListDetailsSection;
	private ApprovalListDetailsSection approvalListDetailsSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[text()= 'Debtor']";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String DEBTORDETAILSFORM_ID = "DEBTOR_DETAILS_FORM";
	public final static String ADDNEWDEBTORBTN_ID = "ADD_NEW_DEBTOR";
	public final static String SAVEBTN_XPATH = "//form[@id='DEBTOR_DETAILS_FORM']//input[@value='Save']";
	public final static String CANCELBTN_XPATH = "//form[@id='DEBTOR_DETAILS_FORM']//input[@value='Cancel']";
	public final static String UPDATEBTN_ID = "UPDATE_BUTTON";
	public final static String ADDNEWAGMTBTN_ID = "ADD_NEW_AGR";
	public final static String EXCLISTDETAILSSECTION_ID = "DEBTOR_EX_SECTION_title";
	public final static String EXCSECTIONDIV_ID = "DEBTOR_EX_SECTION";
	public final static String APPRVLLISTDETAILSSECTION_ID = "DEBTOR_APP_SECTION_title";
	public final static String APPRVLSECTIONDIV_ID = "DEBTOR_APP_SECTION";
	

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = DEBTORDETAILSFORM_ID)
	private WebElement debtorDetailsForm;

	@FindBy(id = ADDNEWDEBTORBTN_ID)
	private WebElement addNewDebtorBtn;

	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	@FindBy(id = ADDNEWAGMTBTN_ID)
	private WebElement addNewAgmtBtn;

	@FindBy(id = EXCSECTIONDIV_ID)
	private WebElement excSectionDiv;

	@FindBy(id = EXCLISTDETAILSSECTION_ID)
	private WebElement excListDetailsSection;

	@FindBy(id = APPRVLLISTDETAILSSECTION_ID)
	private WebElement apprvlListDetailsSection;

	@FindBy(id = APPRVLSECTIONDIV_ID)
	private WebElement apprvlSectionDiv;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		debtorListTab = PageFactory
				.initElements(webDriver, DebtorListTab.class);
		debtorListTab.setWebDriver(webDriver);
		debtorListTab.setWebDriverWait(webDriverWait);

		debtorDetailsFirstSection = PageFactory.initElements(webDriver,
				DebtorDetailsFirstSection.class);
		debtorDetailsFirstSection.setWebDriver(webDriver);
		debtorDetailsFirstSection.setWebDriverWait(webDriverWait);

		debtorGeneralDetailsSection = PageFactory.initElements(webDriver,
				DebtorGeneralDetailsSection.class);
		debtorGeneralDetailsSection.setWebDriver(webDriver);
		debtorGeneralDetailsSection.setWebDriverWait(webDriverWait);

		debtorSpecificDetailsSection = PageFactory.initElements(webDriver,
				DebtorSpecificDetailsSection.class);
		debtorSpecificDetailsSection.setWebDriver(webDriver);
		debtorSpecificDetailsSection.setWebDriverWait(webDriverWait);

		contactPersonDetailsSection = PageFactory.initElements(webDriver,
				ContactPersonDetailsSection.class);
		contactPersonDetailsSection.setWebDriver(webDriver);
		contactPersonDetailsSection.setWebDriverWait(webDriverWait);

		associatedAgreementsSection = PageFactory.initElements(webDriver,
				AssociatedAgreementsSection.class);
		associatedAgreementsSection.setWebDriver(webDriver);
		associatedAgreementsSection.setWebDriverWait(webDriverWait);

		exclusionListDetailsSection = PageFactory.initElements(webDriver,
				ExclusionListDetailsSection.class);
		exclusionListDetailsSection.setWebDriver(webDriver);
		exclusionListDetailsSection.setWebDriverWait(webDriverWait);

		approvalListDetailsSection = PageFactory.initElements(webDriver,
				ApprovalListDetailsSection.class);
		approvalListDetailsSection.setWebDriver(webDriver);
		approvalListDetailsSection.setWebDriverWait(webDriverWait);

	}

	public DebtorPage clickOnDebtorMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "Debtor");
		DebtorPage debtorPage = PageFactory.initElements(webDriver,
				DebtorPage.class);
		debtorPage.setWebDriver(webDriver);
		debtorPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return debtorPage;
	}

	public void collapseExpandExcSection() throws Exception {
		waitForElementId(EXCLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getExcListDetailsSection().getAttribute(
				"class"))) {
			excListDetailsSection.click();
			sleepMedium();
		}

	}

	public void collapseExpandApprvlSection() throws Exception {
		waitForElementId(APPRVLLISTDETAILSSECTION_ID);
		sleepShort();
		if ("CollapseExpand".equals(getApprvlListDetailsSection().getAttribute(
				"class"))) {
			apprvlListDetailsSection.click();
			sleepMedium();
		}

	}

	public void saveDebtor() throws Exception {
		saveBtn.click();
		waitForElementId(UPDATEBTN_ID);
		sleepShort();

	}

	public String activateRecord() throws Exception {
		waitForElementId(MAINSTATUSLABEL_ID);
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickAddNewBtn() throws Exception {
		waitForElementId(ADDNEWDEBTORBTN_ID);
		sleepVeryShort();
		addNewDebtorBtn.click();
		sleepShort();
		waitForElementXpathExpression(SAVEBTN_XPATH);

	}

	public void clickAddNewAgrmntBtn() throws Exception {
		waitForElementId(ADDNEWAGMTBTN_ID);
		addNewAgmtBtn.click();
		doDirtyPopUpCheck();
		sleepShort();

	}

	public String verifyDebtor(String[] debtorListData) throws Exception {
		DebtorAgreementPage debtorAgreementPage = PageFactory.initElements(
				webDriver, DebtorAgreementPage.class);
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		debtorAgreementPage.initPages(webDriver, webDriverWait);
		String dbtrName = debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().getDebtorNameText()
				.getAttribute("value");
		sleepVeryShort();
		debtorAgreementPage.getGoToDebtorBtn().click();
		sleepShort();
		doDirtyPopUpCheck();
		return dbtrName;
	}

	public DebtorListTab getDebtorListTab() {
		return debtorListTab;
	}

	public DebtorDetailsFirstSection getDebtorDetailsFirstSection() {
		return debtorDetailsFirstSection;
	}

	public DebtorGeneralDetailsSection getDebtorGeneralDetailsSection() {
		return debtorGeneralDetailsSection;
	}

	public DebtorSpecificDetailsSection getDebtorSpecificDetailsSection() {
		return debtorSpecificDetailsSection;
	}

	public ContactPersonDetailsSection getContactPersonDetailsSection() {
		return contactPersonDetailsSection;
	}

	public AssociatedAgreementsSection getAssociatedAgreementsSection() {
		return associatedAgreementsSection;
	}

	public ExclusionListDetailsSection getExclusionListDetailsSection() {
		return exclusionListDetailsSection;
	}

	public ApprovalListDetailsSection getApprovalListDetailsSection() {
		return approvalListDetailsSection;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getDebtorDetailsForm() {
		return debtorDetailsForm;
	}

	public WebElement getAddNewDebtorBtn() {
		return addNewDebtorBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getAddNewAgmtBtn() {
		return addNewAgmtBtn;
	}

	public WebElement getExcListDetailsSection() {
		return excListDetailsSection;
	}

	public WebElement getApprvlListDetailsSection() {
		return apprvlListDetailsSection;
	}

	public WebElement getExcSectionDiv() {
		return excSectionDiv;
	}

	public WebElement getApprvlSectionDiv() {
		return apprvlSectionDiv;
	}

	public WebElement getActivateRecord() {
		return activateRecord;
	}

}
