package com.atk.himma.test.sa;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.admin.SequenceCodeGeneratorPage;
import com.atk.himma.setup.SeleniumDriverSetup;

@Test(groups = { "functionalTestGrp" })
public class SequenceCodeTest extends SeleniumDriverSetup {
	SequenceCodeGeneratorPage sequenceCodeGeneratorPage;
	List<String[]> saScgList;

	@Test(description = "Open Sequence Code Generator Page")
	public void openSequenceCodeGenerator() throws Exception {
		sequenceCodeGeneratorPage = PageFactory.initElements(webDriver,
				SequenceCodeGeneratorPage.class);
		sequenceCodeGeneratorPage = sequenceCodeGeneratorPage
				.clickOnSequenceCodeGeneratorMenu(webDriver, webDriverWait);
		sequenceCodeGeneratorPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(sequenceCodeGeneratorPage);
		sequenceCodeGeneratorPage
				.waitForElementVisibilityOf(sequenceCodeGeneratorPage
						.getSequenceCodeListTab().getSequenceCodeForm());
		Assert.assertTrue(sequenceCodeGeneratorPage.getSequenceCodeListTab()
				.getMbuName().isDisplayed());
	}

	@Test(description = "Create Sequence Codes", dependsOnMethods = { "openSequenceCodeGenerator" })
	public void createSequenceCode() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		saScgList = excelReader.read(properties.getProperty("SCG").trim());
		if (saScgList != null && !saScgList.isEmpty()) {
			sequenceCodeGeneratorPage.getSequenceCodeListTab()
					.addNewSequnceCode();
			sequenceCodeGeneratorPage.getSequenceCodeDetailsTab().setWebDriver(
					webDriver);
			sequenceCodeGeneratorPage.getSequenceCodeDetailsTab()
					.setWebDriverWait(webDriverWait);
			sequenceCodeGeneratorPage.getSequenceCodeDetailsTab()
					.waitForElementVisibilityOf(
							sequenceCodeGeneratorPage
									.getSequenceCodeDetailsTab()
									.getSeqCodeDetailsForm());
			for (String[] scdata : saScgList.subList(1, saScgList.size())) {
				sequenceCodeGeneratorPage.getSequenceCodeDetailsTab()
						.addSeqCode(scdata);
				Assert.assertTrue(sequenceCodeGeneratorPage
						.getSequenceCodeDetailsTab().getUpdateBtn().isEnabled()
						&& sequenceCodeGeneratorPage
								.getSequenceCodeDetailsTab().searchGridData(
										scdata[5]));
				sequenceCodeGeneratorPage.getSequenceCodeDetailsTab()
						.addNewSequenceCode();
			}
		}
	}
}
