package com.atk.himma.pageobjects.mbuadmin.sections.servicedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SerCodeStandAddReferences extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Service Code Standard and Additional References";
	public final static String ADDBUTTONGRID_XPATH = "//td[@id='CODE_REFERENCE_GRID_pager_left']//div[@class='ui-pg-div']/span";
	public final static String POPUPFORMID_ID = "CODE_REFERENCE_POPUP";
	public final static String POPUPTITLE_ID = "ui-dialog-title-codeReferenceDialog";
	public final static String CodeRef_ID = "STANDARD_ID";
	public final static String CODEREFDESCR_ID = "OTHER";
	public final static String CODEREFNAME_ID = "CODE_REFERENCE_ID";
	public final static String CODE_ID = "CODE";
	public final static String SubmitButtonPopup_XPATH = "//form[@id='CODE_REFERENCE_POPUP']//input[@value='Submit']";
	public final static String CancelButtonPopup_XPATH = "//form[@id='CODE_REFERENCE_POPUP']//input[@value='Cancel']";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButtonGrid;
	
	@FindBy(id = POPUPFORMID_ID)
	private WebElement popupFormId;
	
	@FindBy(id = POPUPTITLE_ID)
	private WebElement popupTitle;
	
	@FindBy(id = CodeRef_ID)
	private WebElement codeReference;
	
	@FindBy(id = CODEREFDESCR_ID)
	private WebElement codeRefDescr;
	
	@FindBy(id = CODEREFNAME_ID)
	private WebElement codeRefName;
	
	@FindBy(id = CODE_ID)
	private WebElement code;
	
	@FindBy(xpath = SubmitButtonPopup_XPATH)
	private WebElement submitButtonPopup;
	
	@FindBy(xpath = CancelButtonPopup_XPATH)
	private WebElement cancelButtonPopup;

	/**
	 * @return the submitbuttonpopupXpath
	 */
	public static String getSubmitbuttonpopupXpath() {
		return SubmitButtonPopup_XPATH;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addButtonGrid
	 */
	public WebElement getAddButtonGrid() {
		return addButtonGrid;
	}

	/**
	 * @return the popupFormId
	 */
	public WebElement getPopupFormId() {
		return popupFormId;
	}

	/**
	 * @return the popupTitle
	 */
	public WebElement getPopupTitle() {
		return popupTitle;
	}

	/**
	 * @return the codeReference
	 */
	public WebElement getCodeReference() {
		return codeReference;
	}

	/**
	 * @return the codeRefDescr
	 */
	public WebElement getCodeRefDescr() {
		return codeRefDescr;
	}

	/**
	 * @return the codeRefName
	 */
	public WebElement getCodeRefName() {
		return codeRefName;
	}

	/**
	 * @return the code
	 */
	public WebElement getCode() {
		return code;
	}

	/**
	 * @return the submitButtonPopup
	 */
	public WebElement getSubmitButtonPopup() {
		return submitButtonPopup;
	}

	/**
	 * @return the cancelButtonPopup
	 */
	public WebElement getCancelButtonPopup() {
		return cancelButtonPopup;
	}
}
