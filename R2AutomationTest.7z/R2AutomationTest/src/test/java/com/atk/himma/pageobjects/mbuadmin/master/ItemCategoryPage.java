/**
 * @author kumar
 */
package com.atk.himma.pageobjects.mbuadmin.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class ItemCategoryPage extends DriverWaitClass implements StatusMessages {

	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String FORM_ID = "ITEM_CATEGORY";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String ITEMCATEGORY_ID = "ITEM_CATEGORY_ID";
	public final static String ITEMSUBCATEGORY_NAME = "multiselect_ITEM_SUB_CATEGORY_ID";
	public final static String ITEMSUBCATEGORY_XPATH = "//ul[@class='ui-multiselect-checkboxes ui-helper-reset']//input[@name='multiselect_ITEM_SUB_CATEGORY_ID']";
	public final static String ADDBUTTON_ID = "ADD_BUTTON";
	public final static String UPDATEBUTTON_ID = "UPDATE_BUTTON";
	public final static String CLEARBUTTON_XPATH = "//span[@class='buttoncontainer_mid_gb']//input[@value='Clear']";
	public final static String GRID_ID = "ITEM_CATEGORY_GRID";
	public final static String GRID_ITEM_CATEGORY_ARIA_DESCRIBEDBY = "ITEM_CATEGORY_GRID_baseLV.longDesc";
	public final static String GRID_ITEM_SUBCATEGORY_ARIA_DESCRIBEDBY = "ITEM_CATEGORY_GRID_";
	public final static String GRID_PAGER_ID = "sp_1_ITEM_CATEGORY_GRID_pager";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Item Category')]";
	
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Saved Successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Updated Successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(),'Record activated successfully')]";
	public final static String DELETEDIALOGYES_ID = "MSG_DIALOG_YES";

	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;

	@FindBy(id = DELETEDIALOGYES_ID)
	private WebElement deleteDialogYesButton;

	public WebElement getDeleteDialogYesButton() {
		return deleteDialogYesButton;
	}

	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;

	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(id = ITEMCATEGORY_ID)
	private WebElement itemCategory;

	@FindBy(name = ITEMSUBCATEGORY_NAME)
	private WebElement itemSubCategpry;

	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;

	@FindBy(id = UPDATEBUTTON_ID)
	private WebElement updateButton;

	@FindBy(xpath = CLEARBUTTON_XPATH)
	private WebElement clearButton;

	@FindBy(id = GRID_ID)
	private WebElement grid;

	@FindBy(id = GRID_PAGER_ID)
	private WebElement gridPager;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public ItemCategoryPage clickOnItemCategoryMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Item Category");
		setWebDriver(webDriver);
		setWebDriverWait(webDriverWait);
		waitForElementId(FORM_ID);
		ItemCategoryPage itemCategoryPage = PageFactory.initElements(webDriver,
				ItemCategoryPage.class);
		itemCategoryPage.setWebDriver(webDriver);
		itemCategoryPage.setWebDriverWait(webDriverWait);
		return itemCategoryPage;
	}

	public String addItemCategoryInGrid(String[] itemCategoryDatas) {
		waitForElementXpathExpression(SAVEBUTTON_XPATH);
		new Select(itemCategory).selectByVisibleText(itemCategoryDatas[0]);
		String[] str = itemCategoryDatas[1].split("\\,");
		for (int i = 0; i < str.length; i++)
			clickOnItemSubCategory(str[i]);
		addButton.click();
		String rowXpath = ".//table[@id='" + GRID_ID + "']//td[@title='"
				+ itemCategoryDatas[0].trim() + "']";
		waitForElementXpathExpression(rowXpath);
		return webDriver.findElement(By.xpath(rowXpath)).getText().trim();
	}

	public boolean saveItemCategory(String[] itemCategoryDatas)
			throws InterruptedException {
		String rowXpath = ".//table[@id='" + GRID_ID + "']//td[@title='"
				+ itemCategoryDatas[0].trim() + "']";
		waitForElementXpathExpression(rowXpath);
		saveButton.click();
		try {
			waitForGridSearchText(itemCategoryDatas[0]);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean editItemCategory(String[] itemCategoryDatas)
			throws InterruptedException {
		String rowXpath = ".//table[@id='" + GRID_ID + "']//td[@title='"
				+ itemCategoryDatas[0].trim() + "']";
		waitForElementXpathExpression(rowXpath);
		clickOnGridAction(itemCategoryDatas[0].trim(), "Edit");
		updateItemCategoryInGrid(itemCategoryDatas);
		return saveItemCategory(itemCategoryDatas);
	}

	public String updateItemCategoryInGrid(String[] itemCategoryDatas)
			throws InterruptedException {
		waitForElementId(UPDATEBUTTON_ID);
		sleepShort();
		String[] str = itemCategoryDatas[1].split("\\,");
		for (int i = 0; i < str.length; i++)
			clickOnItemSubCategory(str[i]);
		updateButton.click();
		String rowXpath = ".//table[@id='" + GRID_ID + "']//td[@title='"
				+ itemCategoryDatas[0].trim() + "']";
		waitForElementXpathExpression(rowXpath);
		return webDriver.findElement(By.xpath(rowXpath)).getText().trim();
	}

	public boolean deleteItemCategory(String[] itemCategoryDatas)
			throws InterruptedException {
		String rowXpath = ".//table[@id='" + GRID_ID + "']//td[@title='"
				+ itemCategoryDatas[0].trim() + "']";
		waitForElementXpathExpression(rowXpath);
		sleepVeryShort();
		clickOnGridAction(itemCategoryDatas[0].trim(), "Delete");
		waitForElementId(DELETEDIALOGYES_ID);
		sleepVeryShort();
		deleteDialogYesButton.click();
		sleepShort();
		saveButton.click();
		waitForElementXpathExpression(SAVECONFMSG_XPATH);
		try {
			waitForGridSearchText(itemCategoryDatas[0]);
			return false;
		} catch (Exception e) {
			return true;
		}
	}

	public void clickOnItemSubCategory(String itemSubCategory) {
		String itemSubCategoryXpath = "//input[@title='"
				+ itemSubCategory.trim() + "' and @name='"
				+ ITEMSUBCATEGORY_NAME + "']";
		waitForElementXpathExpression(itemSubCategoryXpath);
		if (!webDriver.findElement(By.xpath(itemSubCategoryXpath)).isSelected())
			webDriver.findElement(By.xpath(itemSubCategoryXpath)).click();
	}

	public void unSelectItemSubCategory(WebElement itemSubCategory) {
		boolean flag = itemSubCategory.isSelected();
		System.out.println("Flag----> " + flag);
		if (flag)
			itemSubCategory.click();
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the itemCategpry
	 */
	public WebElement getItemCategory() {
		return itemCategory;
	}

	/**
	 * @return the itemSubCategpry
	 */
	public WebElement getItemSubCategpry() {
		return itemSubCategpry;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}

	/**
	 * @return the clearButton
	 */
	public WebElement getClearButton() {
		return clearButton;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

}
