package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RegConfiguration extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Registration Configuration";

	public final static String REGINFOVALIDITY_ID = "REGISTRATION_INFO_VALIDITY";
	public final static String REGVALPERIOD_ID = "VALPERIOD";
	public final static String DISPPATIENTPHOTO_ID = "dispPhoto";
	public final static String REGFEECOLLECREQUIRED_ID = "feeRequired";

	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Registration Configuration')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = REGINFOVALIDITY_ID)
	private WebElement regInfoValidity;

	@FindBy(id = REGVALPERIOD_ID)
	private WebElement regValPeriod;

	@FindBy(id = DISPPATIENTPHOTO_ID)
	private WebElement dispPatientPhoto;

	@FindBy(id = REGFEECOLLECREQUIRED_ID)
	private WebElement regFeeCollecRequired;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkRegConfigSection() throws InterruptedException {
		waitForElementLinkText(RegConfiguration.SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatasInSection(String[] mbuDatas)
			throws InterruptedException {
		waitForElementLinkText(BusinessTimings.SECTIONNAME_LINKTEXT);
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		waitForElementId(REGINFOVALIDITY_ID);
		sleepVeryShort();
		selectOrUnSelectCheckBox(mbuDatas[37], regInfoValidity);
		sleepVeryShort();
		if (regInfoValidity.isSelected()) {
			regValPeriod.clear();
			regValPeriod.sendKeys(mbuDatas[38].trim());
		}
		selectOrUnSelectCheckBox(mbuDatas[39], dispPatientPhoto);
		selectOrUnSelectCheckBox(mbuDatas[40], regFeeCollecRequired);
		return (regFeeCollecRequired.isSelected() == Boolean
				.parseBoolean(mbuDatas[40]));
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the regInfoValidity
	 */
	public WebElement getRegInfoValidity() {
		return regInfoValidity;
	}

	/**
	 * @return the regValPeriod
	 */
	public WebElement getRegValPeriod() {
		return regValPeriod;
	}

	/**
	 * @return the dispPatientPhoto
	 */
	public WebElement getDispPatientPhoto() {
		return dispPatientPhoto;
	}

	/**
	 * @return the regFeeCollecRequired
	 */
	public WebElement getRegFeeCollecRequired() {
		return regFeeCollecRequired;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
