package com.atk.himma.pageobjects.mrd;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ManageMRVolPage extends DriverWaitClass implements StatusMessages,
		RecordStatus, TopControls {

	static String subWindowHandle;
	public static final String FORM_XPATH = "//form[@id='cmrForm' and @name='createMRVolumeForm']";
	public static final String PATFNAME_CLASS = "patientfname";
	public static final String PATLNAME_CLASS = "patientlname";
	public static final String PATBORN_XPATH = "(//div[@class='patientinfoDiv clearfix']//span[text()=' Born : ']/..//span[@class='bold'])[0]";
	public static final String VISITSTATUS_XPATH = "(//div[@class='patientinfoDiv clearfix']//span[text()=' Visit Status ']/..//span[@class='bold'])[1]";
	public static final String PATGENDER_XPATH = "(//div[@class='patientinfoDiv clearfix']//span[text()=' Gender : ']/..//span[@class='bold'])[0]";
	public static final String PATPRIMAYDOC_XPATH = "(//div[@class='patientinfoDiv clearfix']//span[text()='Primary Doctor']/..//span[@class='bold'])[0]";
	public static final String PATMRN_XPATH = "(//div[@class='patientinfoDiv clearfix']//span[text()='MRN : ']/..//span[@class='bold'])[1]";
	public static final String PATTYPE_XPATH = "(//div[@class='patientinfoDiv clearfix']//span[text()='Patient Type']/..//span[@class='bold'])[1]";

	public static final String PATADDRESS_XPATH = "//span[@class='patienthighlightDiv clearfix']//span[text()=' Address : ']/../span[@class='normal']";
	public static final String PATPHONEEMAIL_XPATH = "//span[@class='patienthighlightDiv clearfix']//span[text()=' Phone & email : ']/../span[@class='normal']";
	public static final String PATKNOWNALLERGIE_CSS = "span.allergiestxt";
	public static final String PATBANNEREXPCOLL_XPATH = "//img[@src='/himma-preg/images/trigger_arrow_transparent.png']/..";
	public static final String PATADDNEWBUTTON_ID = "ADD_NEW_VOLUM_BTN";
	public static final String PATCANCELBUTTON_CSS = "#ADD_NEW_VOLUM_BTN ~ input[value='Cancel']";

	// ---------------------------------------------------Grid--------------------------------------------------------------------
	public final static String GRID_ID = "MR_VOLUME_GRID";
	public static final String GRID_VOLUME_ARIA_DESCRIBEDBY = "MR_VOLUME_GRID_volume";
	public static final String GRID_SLOT_NO_ARIA_DESCRIBEDBY = "MR_VOLUME_GRID_rackNumberText";
	public static final String GRID_PERMLOC_ARIA_DESCRIBEDBY = "MR_VOLUME_GRID_permLocation";
	public static final String GRID_CURRLOC_ARIA_DESCRIBEDBY = "MR_VOLUME_GRID_currentLocation";
	public static final String GRID_MRSTATUS_ARIA_DESCRIBEDBY = "MR_VOLUME_GRID_mrStatus";

	public static final String GRID_PAGER_ID = "sp_1_MR_VOLUME_GRID_pager";

	// --------------------------slot no drop down
	// ------------------------------------------------------
	public final static String SLOT_NO_ID = "SLOT_NO";
	public final static String ASSIGN_SLOT_ID = "ASSIGN_RACK_SLOT";

	@FindBy(xpath = SLOT_NO_ID)
	private WebElement slotNo;

	@FindBy(xpath = ASSIGN_SLOT_ID)
	private WebElement assignSlotButton;

	@FindBy(xpath = FORM_XPATH)
	private WebElement form;

	@FindBy(className = PATLNAME_CLASS)
	private WebElement patName;

	@FindBy(xpath = PATBORN_XPATH)
	private WebElement patBorn;

	@FindBy(xpath = VISITSTATUS_XPATH)
	private WebElement visitStatus;

	@FindBy(xpath = PATGENDER_XPATH)
	private WebElement patGender;

	@FindBy(xpath = PATPRIMAYDOC_XPATH)
	private WebElement patPrimayDoc;

	@FindBy(xpath = PATMRN_XPATH)
	private WebElement patMRN;

	@FindBy(xpath = PATTYPE_XPATH)
	private WebElement patType;

	@FindBy(xpath = PATADDRESS_XPATH)
	private WebElement patAddress;

	@FindBy(xpath = PATPHONEEMAIL_XPATH)
	private WebElement patPhoneEMail;

	@FindBy(css = PATKNOWNALLERGIE_CSS)
	private WebElement patKnownAllergie;

	@FindBy(xpath = PATBANNEREXPCOLL_XPATH)
	private WebElement patBannerExpcoll;

	@FindBy(id = PATADDNEWBUTTON_ID)
	private WebElement patAddNewButton;

	@FindBy(css = PATCANCELBUTTON_CSS)
	private WebElement patCancelButton;

	@FindBy(id = MSGDIALOG_YES_ID)
	private WebElement msgDialogYesButton;

	@FindBy(id = MSGDIALOG_NO_ID)
	private WebElement msgDialogNoButton;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the patName
	 */
	public WebElement getPatName() {
		return patName;
	}

	/**
	 * @return the patBorn
	 */
	public WebElement getPatBorn() {
		return patBorn;
	}

	/**
	 * @return the visitStatus
	 */
	public WebElement getVisitStatus() {
		return visitStatus;
	}

	/**
	 * @return the patGender
	 */
	public WebElement getPatGender() {
		return patGender;
	}

	/**
	 * @return the patPrimayDoc
	 */
	public WebElement getPatPrimayDoc() {
		return patPrimayDoc;
	}

	/**
	 * @return the patMRN
	 */
	public WebElement getPatMRN() {
		return patMRN;
	}

	/**
	 * @return the patType
	 */
	public WebElement getPatType() {
		return patType;
	}

	/**
	 * @return the patAddress
	 */
	public WebElement getPatAddress() {
		return patAddress;
	}

	/**
	 * @return the patPhoneEMail
	 */
	public WebElement getPatPhoneEMail() {
		return patPhoneEMail;
	}

	/**
	 * @return the patKnownAllergie
	 */
	public WebElement getPatKnownAllergie() {
		return patKnownAllergie;
	}

	/**
	 * @return the patBannerExpcoll
	 */
	public WebElement getPatBannerExpcoll() {
		return patBannerExpcoll;
	}

	/**
	 * @return the patAddNewButton
	 */
	public WebElement getPatAddNewButton() {
		return patAddNewButton;
	}

	/**
	 * @return the patCancelButton
	 */
	public WebElement getPatCancelButton() {
		return patCancelButton;
	}

	public boolean verifyVolCreation() throws InterruptedException {

		waitForPageLoaded(webDriver);
		waitForElementId(GRID_ID);
		return checkGridEmpty(GRID_ID, GRID_PAGER_ID);

	}

	public boolean verifyPatBanner(String patName) throws InterruptedException {

		waitForPageLoaded(webDriver);
		waitForElementClassName(PATFNAME_CLASS);
		waitForElementClassName(PATLNAME_CLASS);
		waitForElementXpathExpression(PATADDRESS_XPATH);
		waitForElementXpathExpression(PATPHONEEMAIL_XPATH);
		waitForElementCssSelector(PATKNOWNALLERGIE_CSS);
		return StringUtils.containsIgnoreCase(this.patName.getText().trim(),
				patName.trim());

	}

	public String verifyAddNewButton() throws InterruptedException {

		waitForPageLoaded(webDriver);
		waitForElementId(PATADDNEWBUTTON_ID);
		return this.patAddNewButton.getAttribute("value").trim();

	}

	public boolean verifyEditSlotLink(String volumeNo)
			throws InterruptedException {

		waitForPageLoaded(webDriver);
		return waitForGridAction(volumeNo, "Edit Slot");

	}

	public boolean verifyPrintLabelLink(String volumeNo)
			throws InterruptedException {

		waitForPageLoaded(webDriver);
		return waitForGridAction(volumeNo, "Print Label");

	}

	public boolean verifyDeleteLink(String volumeNo)
			throws InterruptedException {

		waitForPageLoaded(webDriver);
		return waitForGridAction(volumeNo, "Delete");

	}

	public boolean editSlot(String atVolumeNo, String requiredSlotNo)
			throws InterruptedException {

		waitForPageLoaded(webDriver);
		clickOnGridAction(atVolumeNo, "Edit Slot");
		waitForElementId(SLOT_NO_ID);
		new Select(slotNo).selectByVisibleText(atVolumeNo);
		assignSlotButton.click();
		sleepVeryShort();
		return getGridCellData(GRID_ID, GRID_VOLUME_ARIA_DESCRIBEDBY,
				atVolumeNo.trim(), GRID_SLOT_NO_ARIA_DESCRIBEDBY).trim().equals(
				requiredSlotNo.trim());

	}

	public boolean clickOnAddNewButton() throws InterruptedException {

		waitForPageLoaded(webDriver);
		waitForElementId(GRID_ID);
		int countRows = countGridAllRows(GRID_ID, GRID_VOLUME_ARIA_DESCRIBEDBY);
		waitForElementId(PATADDNEWBUTTON_ID);
		patAddNewButton.click();
		doDirtyPopUpCheck();
		sleepVeryShort();
		waitForElementId(GRID_ID);
		waitForElementId(PATADDNEWBUTTON_ID);
		return countGridAllRows(GRID_ID, GRID_VOLUME_ARIA_DESCRIBEDBY) > countRows;

	}

	public boolean clickonPrintLabelLink(String volumeNo)
			throws InterruptedException {
		waitForPageLoaded(webDriver);
		clickOnGridAction(volumeNo, "Print Label");
		waitForElementId(MSGDIALOG_YES_ID);
		getMsgDialogYesButton().click();
		sleepMedium();
		subWindowHandle = webDriver.getWindowHandle();
		parentWindowHandles = webDriver.getWindowHandles();
		String printPageUrl = null;
		WebDriver childDriver = null;
		for (String winHandle : parentWindowHandles) {
			childDriver = webDriver.switchTo().window(winHandle);
		}
		printPageUrl = childDriver.getCurrentUrl();
		waitForPageLoaded(webDriver);
		sleepShort();
		boolean checkUrl = printPageUrl
				.contains("http://abkqar1:8080/himma-preg/reports/printFolderLabel.action?mrNumber=");
		// childDriver.close();
		// sleepLong();
		return checkUrl;
	}

	/**
	 * @return the msgDialogYesButton
	 */
	public WebElement getMsgDialogYesButton() {
		return msgDialogYesButton;
	}

	/**
	 * @return the msgDialogNoButton
	 */
	public WebElement getMsgDialogNoButton() {
		return msgDialogNoButton;
	}

	/**
	 * @return the slotNo
	 */
	public WebElement getSlotNo() {
		return slotNo;
	}

	/**
	 * @return the assignSlot
	 */
	public WebElement getAssignSlotButton() {
		return assignSlotButton;
	}
}
