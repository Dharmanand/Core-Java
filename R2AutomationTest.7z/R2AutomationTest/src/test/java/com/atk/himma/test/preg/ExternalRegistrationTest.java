package com.atk.himma.test.preg;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.preg.ExternalRegistrationPage;
import com.atk.himma.pageobjects.preg.regsections.ContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.IdentificationDetailsSection;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ExternalRegistrationTest extends SeleniumDriverSetup {

	List<String[]> pregDatas;
	ExternalRegistrationPage externalRegistrationPage;

	@Test(description = "Open External Registration Page")
	public void openExternalRegPage() throws InterruptedException {
		externalRegistrationPage = PageFactory.initElements(webDriver,
				ExternalRegistrationPage.class);
		externalRegistrationPage = externalRegistrationPage
				.clickOnExterRegMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		externalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		Assert.assertNotNull(externalRegistrationPage);
		externalRegistrationPage
				.waitForElementVisibilityOf(externalRegistrationPage
						.getFormName());
		externalRegistrationPage
				.waitForElementId(ExternalRegistrationPage.FORMNAME_ID);
		externalRegistrationPage.sleepVeryShort();
		Assert.assertEquals(externalRegistrationPage.getPageTitle().getText(),
				"External Registration");
	}

	// [External Registration] Open Form
	@Test(description = "Open External Registration Page Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkExterRegMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		externalRegistrationPage = PageFactory.initElements(webDriver,
				ExternalRegistrationPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList,
				"Emergency Registration");
		externalRegistrationPage.setWebDriver(webDriver);
		externalRegistrationPage.setWebDriverWait(webDriverWait);
		externalRegistrationPage
				.waitForElementXpathExpression(ExternalRegistrationPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration").get("External Registration")
				.get("[External Registration] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ExternalRegistrationPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [External Registration] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			externalRegistrationPage = externalRegistrationPage
					.clickOnExterRegMenu(webDriver, webDriverWait);
			externalRegistrationPage.setInstanceOfAllSection(webDriver,
					webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(externalRegistrationPage);
			externalRegistrationPage
					.waitForElementId(ExternalRegistrationPage.FORMNAME_ID);
			externalRegistrationPage.sleepShort();
			Assert.assertEquals(externalRegistrationPage.getPageTitle()
					.getText(), "External Registration");
		}
	}

	@Test(dependsOnMethods = { "openExternalRegPage" }, description = "Save External Registration Record")
	public void test1SaveExterRegPage() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("PREGExcel"));
		pregDatas = excelReader.read(properties.getProperty("externalReg"));
		externalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas) {
			externalRegistrationPage
					.waitForElementVisibilityOf(externalRegistrationPage
							.getSaveButton());
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.SAVEBUTTON_XPATH);
			externalRegistrationPage.saveExterRegPage(st, webDriver,
					webDriverWait);
			Assert.assertNotNull(externalRegistrationPage);
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.UPDATEBUTTON_XPATH);
			externalRegistrationPage.sleepVeryShort();
			Assert.assertEquals(externalRegistrationPage.getRegType().getText()
					.trim(), "EXTERNAL");
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.UPDATEBUTTON_XPATH);
			Assert.assertNotNull(externalRegistrationPage.getUpdateButton(),
					"save successfully Exter. Reg. datas.");
		}
	}

	@Test(dependsOnMethods = { "test1SaveExterRegPage" }, description = "Update External Registration Record")
	public void test2UpdateExterRegPage() throws IOException, InterruptedException {
		pregDatas = excelReader.read(properties.getProperty("updateExternalReg"));
		externalRegistrationPage.setInstanceOfAllSection(webDriver,
				webDriverWait);
		for (String[] st : pregDatas) {
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.UPDATEBUTTON_XPATH);
			externalRegistrationPage.updateExterRegPage(st, webDriver,
					webDriverWait);
			Assert.assertNotNull(externalRegistrationPage);
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.MSGENABLE_XPATH);
			externalRegistrationPage.sleepVeryShort();
			Assert.assertEquals(externalRegistrationPage.getRegType().getText()
					.trim(), "EXTERNAL");
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.ACTIVATE_XPATH);
			externalRegistrationPage.sleepVeryShort();
			externalRegistrationPage.activateRecord(
					ExternalRegistrationPage.ACTIVATE_ID,
					ExternalRegistrationPage.MAINSTATUSLABEL_ID);
			externalRegistrationPage
					.waitForElementXpathExpression(ExternalRegistrationPage.NEWREGISTRATIONBUTTON_XPATH);
			Assert.assertNotNull(externalRegistrationPage.getUpdateButton(),
					"Update successfully Exter. Reg. datas.");
		}
	}

	// [External Registration][Section: Identification Details] Manage
	@Test(dependsOnMethods = { "checkExterRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Identification Details section privileges")
	public void checkIdentDetSecPrivileges() {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("External Registration")
				.get("[External Registration][Section: Identification Details] Manage");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(IdentificationDetailsSection.SECTIONNAME_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Identification Details] Manage");
	}

	// [External Registration][Section: Contact Details] Manage
	@Test(dependsOnMethods = { "checkExterRegMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Contact Details section privileges")
	public void checkContactDetailsPrivileges() {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Patient Registration")
				.get("External Registration")
				.get("[External Registration][Section: Contact Details] Manage");
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(ContactDetailsSection.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail Privilege of [Section: Contact Details]  Manage");
	}
}
