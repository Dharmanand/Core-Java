package com.atk.himma.pageobjects.laboratory.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class LabTestListTabPage extends DriverWaitClass {
	public final static String LABTESTQSEARCHTXT_ID = "LAB_TEST_QUICK_SEARCH_TEXT";
	@FindBy(id = LABTESTQSEARCHTXT_ID)
	private WebElement labTestQSearchTxt;

	public final static String LABTESTQSEARCHBTN_ID = "LAB_TEST_QUCK_SERCH_BUT";
	@FindBy(id = LABTESTQSEARCHBTN_ID)
	private WebElement labTestQSearchBtn;

	public final static String ADVLABTESTSEARCHBTN_ID = "LAB_TEST_LIST_ADVCD_SRCH_BUT";
	@FindBy(id = ADVLABTESTSEARCHBTN_ID)
	private WebElement LABTESTADVSEARCHBTN;

	public final static String LABTESTADVSEARCHDIV_ID = "LAB_TEST_LIST_ADVCD_SRCH_DIV";
	@FindBy(id = LABTESTADVSEARCHDIV_ID)
	private WebElement labTestAdvSearchDiv;

	public final static String LABTESTADVMBU_ID = "LAB_TEST_LIST_ADVNCD_MBU_ID";
	@FindBy(id = LABTESTADVMBU_ID)
	private WebElement labTestAdvMbu;

	public final static String GLOBALSERVCHKBOX_ID = "GLOBAL_SERVICE_SEARCH";
	@FindBy(id = GLOBALSERVCHKBOX_ID)
	private WebElement globalServChkbox;

	public final static String LABTESTADVDEPT_ID = "deptId";
	@FindBy(id = LABTESTADVDEPT_ID)
	private WebElement labTestAdvDept;

	public final static String LABTESTADVSPLTY_ID = "specId";
	@FindBy(id = LABTESTADVSPLTY_ID)
	private WebElement labTestAdvSplty;

	public final static String LABTESTADVSUBSPLTY_ID = "subSpecId";
	@FindBy(id = LABTESTADVSUBSPLTY_ID)
	private WebElement labTestAdvSubSplty;

	public final static String LABTESTADVSERVCLASS_NAME = "searchCriteria.serviceClass";
	@FindBy(name = LABTESTADVSERVCLASS_NAME)
	private WebElement labTestAdvServClass;

	public final static String LABTESTADVSERVTYPE_ID = "LAB_ADVSERCH_SERVICE_TYPE";
	@FindBy(id = LABTESTADVSERVTYPE_ID)
	private WebElement labTestAdvServType;

	public final static String LABTESTADVSTATUS_NAME = "searchCriteria.mainStatus";
	@FindBy(name = LABTESTADVSTATUS_NAME)
	private WebElement labTestAdvStatus;

	public final static String LABTESTADVSERVCODE_NAME = "searchCriteria.serviceCode";
	@FindBy(name = LABTESTADVSERVCODE_NAME)
	private WebElement labTestAdvServCode;

	public final static String LABTESTADVSERVNAME_NAME = "searchCriteria.serviceName";
	@FindBy(name = LABTESTADVSERVNAME_NAME)
	private WebElement labTestAdvServName;

	public final static String LABTESTADVSEARCHBTN_ID = "LAB_TEST_ADVNCD_SERCH_BUT";
	@FindBy(id = LABTESTADVSEARCHBTN_ID)
	private WebElement labTestAdvSearchBtn;

	public final static String LABTESTADVRESETBTN_ID = "LAB_ADVSERCH_RESET_BUT";
	@FindBy(id = LABTESTADVRESETBTN_ID)
	private WebElement labTestadvresetbtn;

	public final static String LABTESTLISTEXPORTBTN_ID = "LAB_TEST_SEARCH_GRID_export_btn";
	@FindBy(id = LABTESTLISTEXPORTBTN_ID)
	private WebElement labTestListExportBtn;

	public final static String LABTESTLISTGRIDTBL_ID = "LAB_TEST_SEARCH_GRID";
	@FindBy(id = LABTESTLISTGRIDTBL_ID)
	private WebElement labTestListGridTbl;

	public WebElement getLabTestQSearchTxt() {
		return labTestQSearchTxt;
	}

	public WebElement getLabTestQSearchBtn() {
		return labTestQSearchBtn;
	}

	public WebElement getLABTESTADVSEARCHBTN() {
		return LABTESTADVSEARCHBTN;
	}

	public WebElement getLabTestAdvSearchDiv() {
		return labTestAdvSearchDiv;
	}

	public WebElement getLabTestAdvMbu() {
		return labTestAdvMbu;
	}

	public WebElement getGlobalServChkbox() {
		return globalServChkbox;
	}

	public WebElement getLabTestAdvDept() {
		return labTestAdvDept;
	}

	public WebElement getLabTestAdvSplty() {
		return labTestAdvSplty;
	}

	public WebElement getLabTestAdvSubSplty() {
		return labTestAdvSubSplty;
	}

	public WebElement getLabTestAdvServClass() {
		return labTestAdvServClass;
	}

	public WebElement getLabTestAdvServType() {
		return labTestAdvServType;
	}

	public WebElement getLabTestAdvStatus() {
		return labTestAdvStatus;
	}

	public WebElement getLabTestAdvServCode() {
		return labTestAdvServCode;
	}

	public WebElement getLabTestAdvServName() {
		return labTestAdvServName;
	}

	public WebElement getLabTestAdvSearchBtn() {
		return labTestAdvSearchBtn;
	}

	public WebElement getLabTestadvresetbtn() {
		return labTestadvresetbtn;
	}

	public WebElement getLabTestListExportBtn() {
		return labTestListExportBtn;
	}

	public WebElement getLabTestListGridTbl() {
		return labTestListGridTbl;
	}

}
