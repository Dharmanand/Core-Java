package com.atk.himma.pageobjects.sa.masters;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class DepartmentPage extends DriverWaitClass implements StatusMessages {
	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;
	
	public final static String DEPTFORM_ID = "DEPARTMENT_FORM";
	@FindBy(id = DEPTFORM_ID)
	private WebElement deptForm;

	public final static String SAVEBTN_XPATH = "//input[@value='Save']";
	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String DEPARTMENT_ID = "DEPARTMENT_ID";
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	public final static String SPECIALTY_ID = "SPECIALTY_ID";
	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;

	public final static String ADDBTN_ID = "ADD_BUTTON";
	@FindBy(id = ADDBTN_ID)
	private WebElement addBtn;

	public final static String CLEARBTN_XPATH = "//input[@value='Clear']";
	@FindBy(xpath = CLEARBTN_XPATH)
	private WebElement clearBtn;

	public final static String DEPTGRID_ID = "gbox_DEPARTMENT_GRID";

	public static final String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Department')]";
	@FindBy(id = DEPTGRID_ID)
	private WebElement deptGrid;
	
	public DepartmentPage clickOnDepartmentMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> deptParentMenuList = new LinkedList<String>();
		deptParentMenuList.add("System Administration");
		deptParentMenuList.add("Masters ");
		menuSelector.clickOnTargetMenu(deptParentMenuList, "Department");
		DepartmentPage departmentPage = PageFactory.initElements(webDriver,
				DepartmentPage.class);
		departmentPage.setWebDriver(webDriver);
		departmentPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return departmentPage;

	}

	public void mapDSS(String[] dssData) throws Exception {
		new Select(department).selectByVisibleText(dssData[0]);
		new Select(specialty).selectByVisibleText(dssData[1]);
		String[] subSpltyArray;
		String delimiter = "\\,";
		subSpltyArray = dssData[2].split(delimiter);
		for (int i = 0; i < subSpltyArray.length; i++) {
			webDriver.findElement(
					By.xpath("//input[@title='" + subSpltyArray[i] + "']"))
					.click();
		}
		addBtn.click();
		sleepVeryShort();
	}

	public void saveDSS() throws Exception {
		saveBtn.click();
		sleepShort();
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public WebElement getDeptForm() {
		return deptForm;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getSpecialty() {
		return specialty;
	}

	public WebElement getAddBtn() {
		return addBtn;
	}

	public WebElement getClearBtn() {
		return clearBtn;
	}

	public WebElement getDeptGrid() {
		return deptGrid;
	}

	public boolean searchGridData(String department, String specialty,
			String subSpecialty) {
		boolean result = false;
		try {
			waitForElementXpathExpression("//td[@aria-describedby='DEPARTMENT_GRID_baseLV.longDesc' and @title='"
					+ department.trim() + "']");
			sleepVeryShort();
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='DEPARTMENT_GRID_baseLV.longDesc' and @title='"
									+ department.trim() + "']")).isDisplayed()
					&& webDriver
							.findElement(
									By.xpath("//td[@aria-describedby='DEPARTMENT_GRID_' and @title='"
											+ specialty.trim() + "']"))
							.isDisplayed()
					&& webDriver.findElement(
							By.xpath("//td[contains(@title, '"
									+ subSpecialty.trim() + "')]"))
							.isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

}
