package com.atk.himma.test.mrd;

import java.util.List;

import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mrd.MRLengthOfStayPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class MRLengthOfStayTest extends SeleniumDriverSetup implements
StatusMessages, RecordStatus{

	MRLengthOfStayPage mrLengthOfStayPage;
	List<String[]> mrLengthOfSP;
	
	/*
	 * Verify the appearance of "MRD" menu link in order to access the
	 * "MR Length of Stay" screen for a privileged user
	 */

	@Test
	public void checkMRLengOfStayLink(){
		
//		mrLengthOfStayPage = PageFactory.initElements(webDriver,
//				MRLengthOfStayPage.class);
//		mrLengthOfStayPage = mrLengthOfStayPage.checkMRLengOfStayLink(webDriver,
//				webDriverWait);
//		mrLengthOfStayPage
//				.waitForElementXpathExpression(MRDDesktopPage.MRDDESKTOPMENULINK_XPATH);
//		Assert.assertEquals(mrLengthOfStayPage.getSpecialRequest(),
//				"Special Request", "Fail to Appear MRD Desktop Link");
		
	}
	
	/*
	 * Verify the accessibility to "MR Length of Stay" screen for a privileged
	 * user
	 */
	
	@Test
	public void searchDesireMBUName(){
		
	}
	
	/* Search the desired MBU using MBU code */
	
	@Test
	public void searchDesireMBUCode(){
		
	}
	
	/* Search all active existing MBUs */
	
	@Test
	public void searchAllActiveMBU(){
		
	}
	
	@Test
	public void verifyConfigureLink(){
		
	}
	
	@Test
	public void verifyEditLink(){
		
	}
	
	@Test
	public void verifyDeleteLink(){
		
	}
	
	@Test
	public void editExistingRecord(){
		
	}
	
	@Test
	public void verofyCancelButton(){
		
	}
	
	
}
