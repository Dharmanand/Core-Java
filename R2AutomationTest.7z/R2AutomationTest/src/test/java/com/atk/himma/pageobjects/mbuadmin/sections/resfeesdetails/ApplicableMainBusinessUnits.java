package com.atk.himma.pageobjects.mbuadmin.sections.resfeesdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ApplicableMainBusinessUnits extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Applicable Main Business Units";
	
	public final static String APPLMBU_NAME = "multiselect_MBULIST";
	
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Applicable Main Business Units')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement puSerForm;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(name = APPLMBU_NAME)
	private WebElement applMBU;

	public boolean checkApplMBUSection() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public boolean fillDatas(String[] resFeeDatas)
			throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		return selectValueOfMultiselect(APPLMBU_NAME, resFeeDatas[16].trim());
	}
	
	
	/**
	 * @return the puSerForm
	 */
	public WebElement getPuSerForm() {
		return puSerForm;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the applMBU
	 */
	public WebElement getApplMBU() {
		return applMBU;
	}
	
}
