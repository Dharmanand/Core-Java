package com.atk.himma.pageobjects.appointsched.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ReserveTab extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	public final static String FORMNAME_ID = "TEMP_REG_FRM";
	public final static String RESERVETAB_XPATH = "//li[@id='APP_TAB_RESERVE']//a[@title='Reserve']";
	public final static String REGISTERCONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(), 'registered successfully']";

	@FindBy(xpath = REGISTERCONFMSG_XPATH)
	private WebElement registerConfMsg;

	@FindBy(xpath = RESERVETAB_XPATH)
	private WebElement reserveTab;

	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	public final static String PREVIOUSBUTTON_XPATH = "//div[@id='PatientDetails']//span[@class='buttoncontainer_vlrg_top']//input[@value='Previous']";

	@FindBy(xpath = PREVIOUSBUTTON_XPATH)
	private WebElement previousButton;

	public final static String NEXTBUTTON_XPATH = "//div[@id='PatientDetails']//span[@class='buttoncontainer_vlrg_top']//input[@value='Next']";

	@FindBy(xpath = NEXTBUTTON_XPATH)
	private WebElement nextButton;

	public final static String REGISTERBUTTON_XPATH = "//div[@id='PatientDetails']//span[@class='buttoncontainer_vlrg_top']//input[@value='Register']";

	@FindBy(xpath = REGISTERBUTTON_XPATH)
	private WebElement registerButton;

	public final static String CANCELBUTTON_ID = "RESERVE_CANCEL_UP";

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	public final static String FIRSTNAME_ID = "firstGivenName";

	@FindBy(id = FIRSTNAME_ID)
	private WebElement firstName;

	public final static String LASTNAME_ID = "familyName";

	@FindBy(id = LASTNAME_ID)
	private WebElement lastName;

	public final static String REGISTRATIONNAME_ID = "TEMP_REG_FRM_patiInfoDetails_registrationType";

	@FindBy(id = REGISTRATIONNAME_ID)
	private WebElement registrationName;

	public final static String DOBDATEPICK_ID = "dobDatePick";

	@FindBy(id = DOBDATEPICK_ID)
	private WebElement dateOfBirth;

	public final static String GENDER_ID = "gender";

	@FindBy(id = GENDER_ID)
	private WebElement gender;

	public final static String MOBCONTRYCODE_ID = "smob";

	@FindBy(id = GENDER_ID)
	private WebElement mobContryCode;

	public final static String MOBNUMBER_ID = "smobpNo";

	@FindBy(id = MOBNUMBER_ID)
	private WebElement mobileNo;

	public final static String IDENTIFICATIONDOC_ID = "IDDOCTYPEID";

	@FindBy(id = IDENTIFICATIONDOC_ID)
	private WebElement identificationDoc;

	public final static String IDENTIFICATIONNO_ID = "identificationNumber";

	@FindBy(id = IDENTIFICATIONNO_ID)
	private WebElement identificationNo;

	public boolean isFirstNameMandatory() {
		waitForElementId(FIRSTNAME_ID);
		return isMandatoryField(firstName);
	}

	public boolean isLastNameMandatory() {
		waitForElementId(LASTNAME_ID);
		return isMandatoryField(lastName);
	}

	public boolean isDateOfBirthMandatory() {
		waitForElementId(DOBDATEPICK_ID);
		return isMandatoryField(dateOfBirth);
	}

	public boolean isPriMobNoCodeMandatory() {
		waitForElementId(MOBCONTRYCODE_ID);
		return isMandatoryField(mobContryCode);
	}

	public boolean isPriMobNoMandatory() {
		waitForElementId(MOBNUMBER_ID);
		return isMandatoryField(mobileNo);
	}

	public void fillDatas(String[] appointDatas) {
		firstName.clear();
		firstName.sendKeys(appointDatas[12].trim());
		lastName.clear();
		lastName.sendKeys(appointDatas[13].trim());
		dateOfBirth.clear();
		dateOfBirth.sendKeys(appointDatas[14].trim());
		if (!appointDatas[13].isEmpty())
			new Select(gender).selectByVisibleText(appointDatas[15].trim());
		if (!appointDatas[14].isEmpty()) {
			new Select(mobContryCode).selectByVisibleText(appointDatas[16]
					.trim());
			mobileNo.clear();
			mobileNo.sendKeys(appointDatas[17].trim());
		}
	}

	public boolean registerDatas(String[] appointDatas)
			throws InterruptedException {
		waitForElementXpathExpression(REGISTERBUTTON_XPATH);
		sleepVeryShort();
		registerButton.click();
		waitForElementId(AppointmentDairy.BACKTOAPPOINTBUTTON_XPATH);
		waitForElementId(AppointmentDairy.FROZENCONFMSG_XPATH);
		sleepVeryShort();
		AppointmentDairy appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.setWebDriver(webDriver);
		appointmentDairy.setWebDriverWait(webDriverWait);
		return appointmentDairy.getFrozenMsg().getText()
				.contains("Frozen the Slots Successfully");
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the previousButton
	 */
	public WebElement getPreviousButton() {
		return previousButton;
	}

	/**
	 * @return the nextButton
	 */
	public WebElement getNextButton() {
		return nextButton;
	}

	/**
	 * @return the registerButton
	 */
	public WebElement getRegisterButton() {
		return registerButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the firstName
	 */
	public WebElement getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public WebElement getLastName() {
		return lastName;
	}

	/**
	 * @return the registrationName
	 */
	public WebElement getRegistrationName() {
		return registrationName;
	}

	/**
	 * @return the dateOfBirth
	 */
	public WebElement getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @return the gender
	 */
	public WebElement getGender() {
		return gender;
	}

	/**
	 * @return the mobContryCode
	 */
	public WebElement getMobContryCode() {
		return mobContryCode;
	}

	/**
	 * @return the mobileNo
	 */
	public WebElement getMobileNo() {
		return mobileNo;
	}

	/**
	 * @return the identificationDoc
	 */
	public WebElement getIdentificationDoc() {
		return identificationDoc;
	}

	/**
	 * @return the identificationNo
	 */
	public WebElement getIdentificationNo() {
		return identificationNo;
	}

	/**
	 * @return the reserveTab
	 */
	public WebElement getReserveTab() {
		return reserveTab;
	}

	/**
	 * @return the registerConfMsg
	 */
	public WebElement getRegisterConfMsg() {
		return registerConfMsg;
	}
}
