package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.master.VisitCategoryPage;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.VisitCategoryDetailsTab;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.VisitCategoryMBUListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class VisitCategoryTest extends SeleniumDriverSetup {

	List<String[]> visitCategoryDatas;
	VisitCategoryPage visitCategoryPage;

	@Test(description = "Open Visit Category Page")
	public void openVisitCategoryPage() {
		visitCategoryPage = PageFactory.initElements(webDriver,
				VisitCategoryPage.class);
		visitCategoryPage = visitCategoryPage.clickOnVisitCategoryMenu(
				webDriver, webDriverWait);
		visitCategoryPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(visitCategoryPage);
		visitCategoryPage.waitForElementVisibilityOf(visitCategoryPage
				.getmbuListTab().getForm());
		visitCategoryPage
				.waitForElementXpathExpression(VisitCategoryMBUListTab.MBULISTTAB_XPATH);
		Assert.assertEquals(visitCategoryPage.getmbuListTab().getMbuListTab()
				.getAttribute("title").trim(), "Main Business Unit List");
	}

	// [Visit Category] Open Form
	@Test(description = "Open Visit Category Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkVisitCategoryMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		visitCategoryPage = PageFactory.initElements(webDriver,
				VisitCategoryPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		parentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Visit Category");
		visitCategoryPage.setWebDriver(webDriver);
		visitCategoryPage.setWebDriverWait(webDriverWait);
		visitCategoryPage
				.waitForElementXpathExpression(VisitCategoryPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Visit Category")
				.get("[Visit Category] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(VisitCategoryPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Visit Category] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			visitCategoryPage = visitCategoryPage.clickOnVisitCategoryMenu(
					webDriver, webDriverWait);
			visitCategoryPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(visitCategoryPage);
			visitCategoryPage.waitForElementVisibilityOf(visitCategoryPage
					.getmbuListTab().getForm());
			visitCategoryPage
					.waitForElementXpathExpression(VisitCategoryMBUListTab.MBULISTTAB_XPATH);
			Assert.assertEquals(visitCategoryPage.getmbuListTab()
					.getMbuListTab().getAttribute("title").trim(),
					"Main Business Unit List");
		}
	}

	@Test(description = "Search Visit Category Data", dependsOnMethods = { "openVisitCategoryPage" })
	public void test1SearchVisitCategory() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		visitCategoryDatas = excelReader.read(properties.getProperty("visitCategory"));
		visitCategoryPage
				.waitForElementXpathExpression(VisitCategoryMBUListTab.MBULISTTAB_XPATH);
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.searchVisitCategory(st)
					.trim(), st[0].trim(), st[0] + " is not Available");
	}

	@Test(description = "click on Edit Link", dependsOnMethods = { "test1SearchVisitCategory" })
	public void test2ClickOnEditLink() throws InterruptedException {
		visitCategoryPage
				.waitForElementXpathExpression(VisitCategoryMBUListTab.MBULISTTAB_XPATH);
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.clickOnEditLink(st).trim(),
					st[0].trim(), st[0] + " click 'Edit' is failed");
	}

	@Test(description = "Click on Add Button of Grid", dependsOnMethods = { "test2ClickOnEditLink" })
	public void test3ClickOnAddButton() throws InterruptedException {
		visitCategoryPage.waitForElementId(VisitCategoryDetailsTab.FORM_ID);
		Assert.assertEquals(visitCategoryPage.clickOnAddRecordGridButton()
				.trim(), "Add Record", "'Add Record' is failed to click");
	}

	@Test(description = "Save Visit Category", dependsOnMethods = { "test3ClickOnAddButton" })
	public void test4SaveVisitCategory() {
		visitCategoryPage.waitForElementId(VisitCategoryDetailsTab.FORM_ID);
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.saveVisitCategory(st).trim()
					.contains("created successfully."), true, st[0]
					+ " 'Save' failed.");
	}

	@Test(description = "Activate Visit Category", dependsOnMethods = { "test4SaveVisitCategory" })
	public void test5ActivateVisitCategory() {
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.activateVisitCategory(st)
					.trim(), "Deactivate", st[0]
					+ " 'Activete Visit Category' failed.");
	}

	@Test(description = "Deactivate Visit Category", dependsOnMethods = { "test4SaveVisitCategory" })
	public void test6DeactiveteVisitCategory() {
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.deActivateVisitCategory(st)
					.trim(), "Activate", st[0]
					+ " 'Deactivete Visit Category' failed.");
	}

	@Test(description = "Edit Visit Category", dependsOnMethods = { "test4SaveVisitCategory" })
	public void test7EditVisitCategory() throws InterruptedException {
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.editVisitCategory(st).trim()
					.contains("Save"), true, st[0]
					+ " 'Edit Visit Category' failed.");
	}

	@Test(description = "Cancel Visit Category", dependsOnMethods = { "test4SaveVisitCategory" })
	public void test8CancelVisitCategory() {
		for (String st[] : visitCategoryDatas)
			Assert.assertEquals(visitCategoryPage.cancelVisitCategory(st)
					.trim(), st[0].trim(), st[0]
					+ " 'Cancel Visit Category' failed.");
	}
}
