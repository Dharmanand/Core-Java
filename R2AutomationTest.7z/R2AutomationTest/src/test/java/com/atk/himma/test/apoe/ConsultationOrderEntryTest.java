package com.atk.himma.test.apoe;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.apoe.ConsultationPage;
import com.atk.himma.pageobjects.desktop.DesktopDataPage;
import com.atk.himma.setup.SeleniumDriverSetup;

public class ConsultationOrderEntryTest extends SeleniumDriverSetup {
	DesktopDataPage desktopDataPage;
	ConsultationPage consultationPage;
	List<String[]> outPatientList;
	List<String[]> orderEntryList;

	@Test(description = "Open Dr. Workbench Page")
	public void test001OpenDrWorkBenchPage() throws Exception {
		desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage = desktopDataPage.clickOnDrWorkBenchMenu(webDriver,
				webDriverWait);
		desktopDataPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties
				.getProperty("OutpatientDesktopExcel"));
		excelReader.setInputFile(properties.getProperty("OrderEntryExcel"));
		outPatientList = excelReader.read(properties
				.getProperty("outPatientDesktop"));
		orderEntryList = excelReader.read(properties.getProperty("orderEntry"));
		Assert.assertNotNull(desktopDataPage);
		desktopDataPage.waitForElementVisibilityOf(desktopDataPage.getMbu());
		Assert.assertTrue(desktopDataPage.getMbu().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Search From Date Field", dependsOnMethods = { "test001OpenDrWorkBenchPage" })
	public void test002ValidateFromDateMandatoryField() throws Exception {
		Assert.assertTrue(desktopDataPage.isMandFromDate());
	}

	@Test(description = "Fill Search Criteria Fields", dependsOnMethods = { "test001OpenDrWorkBenchPage" })
	public void test003FillSearchCriteriaData() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				Assert.assertEquals(
						desktopDataPage.fillSearchCriteria(outPatientListData),
						outPatientListData[0]);
			}
		}
	}

	@Test(description = "Search OutPatient(s) By Patient Filter Criteria", dependsOnMethods = { "test001OpenDrWorkBenchPage" })
	public void test004SearchOutPatientsByPatient() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByPatient(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"drDeskGridList", outPatientListData[15]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Service Filter Criteria", dependsOnMethods = { "test001OpenDrWorkBenchPage" })
	public void test005SearchOutPatientsByService() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByService(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"drDeskGridList", outPatientListData[22]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Physician", dependsOnMethods = { "test001OpenDrWorkBenchPage" })
	public void test006SearchOutPatientsByPhysician() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.quickSearchOutPatients();
				Assert.assertTrue(desktopDataPage.checkGridData(
						"drDeskGridList", outPatientListData[12]));
			}
		}

	}

	@Test(description = "Verify that, Consultation link in Dr.Desktop navigates to Consultation page.", dependsOnMethods = { "test001OpenDrWorkBenchPage" })
	public void test007NavigateToConsultationPage() throws Exception {
		consultationPage = PageFactory.initElements(webDriver,
				ConsultationPage.class);
		consultationPage.initPages(webDriver, webDriverWait);
		consultationPage.setWebDriver(webDriver);
		consultationPage.setWebDriverWait(webDriverWait);
		for (String[] outPatientListData : outPatientList) {
			Assert.assertEquals(
					desktopDataPage.clickOnConsultationLink(outPatientListData),
					"Consultation");
		}
	}

	@Test(description = "Check 'Previous Visit Summary' Panel Menu Link", dependsOnMethods = { "test007NavigateToConsultationPage" })
	public void test008CheckPreviousVisitSummary() throws Exception {
		Assert.assertEquals(
				consultationPage.checkPreviousVisitSummaryPanelLink(),
				"Previous Visit Summary");

	}

	@Test(description = "Check 'Reason For Visit' Panel Menu Link", dependsOnMethods = { "test007NavigateToConsultationPage" })
	public void test009CheckReasonForVisit() throws Exception {
		Assert.assertEquals(consultationPage.checkReasonForVisitPanelLink(),
				"Reason for Visit");

	}

	@Test(description = "Check 'History' Panel Menu Link", dependsOnMethods = { "test007NavigateToConsultationPage" })
	public void test010CheckHistory() throws Exception {
		Assert.assertEquals(consultationPage.checkHistoryPanelLink(), "History");

	}

	@Test(description = "Check 'Assessment & Plan' Panel Menu Link", dependsOnMethods = { "test007NavigateToConsultationPage" })
	public void test011CheckAssessmentPlan() throws Exception {
		Assert.assertEquals(consultationPage.checkAssessmentPlanPanelLink(),
				"Assessment & Plan");

	}

	@Test(description = "Check 'Consultation Summary' Panel Menu Link", dependsOnMethods = { "test007NavigateToConsultationPage" })
	public void test012CheckConsultationSummary() throws Exception {
		Assert.assertEquals(consultationPage.checkConsSummaryPanelLink(),
				"Consultation Summary");

	}

	@Test(description = "Click 'Reason For Visit' Panel Menu Link", dependsOnMethods = { "test009CheckReasonForVisit" })
	public void test013ClickReasonForVisit() throws Exception {
		Assert.assertTrue(consultationPage.clickReasonForVisitPanelLink());

	}

	@Test(description = "Fill Reason For New Visit", dependsOnMethods = { "test013ClickReasonForVisit" })
	public void test014FillReasonForNewVisit() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getReasonForVisitPage().fillNewVisitDefaultSec(
					outPatientListData);
			Assert.assertEquals(consultationPage.getReasonForVisitPage()
					.getNewChiefComplaint().getAttribute("value"),
					outPatientListData[23]);

			Assert.assertEquals(consultationPage.getReasonForVisitPage()
					.getHistoryOfPresentIllness().getAttribute("value"),
					outPatientListData[24]);

		}
	}

	@Test(description = "Fill Pain Assessment Section", dependsOnMethods = { "test013ClickReasonForVisit" })
	public void test015FillPainAssessmentSection() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getPainAssessmentSection().fillPainAssessmentSec(
					outPatientListData);
			Assert.assertEquals(consultationPage.getPainAssessmentSection()
					.getRelieveAggrvtFactors().getAttribute("value"),
					outPatientListData[34]);
			Assert.assertEquals(consultationPage.getPainAssessmentSection()
					.getDailyPainAffects().getAttribute("value"),
					outPatientListData[35]);

		}
	}

	@Test(description = "Save Reason for New Visit", dependsOnMethods = { "test013ClickReasonForVisit" })
	public void test016SaveNewVisitReason() throws Exception {
		consultationPage.getReasonForVisitPage().saveNewVisitReason();
		Assert.assertEquals(consultationPage.getReasonForVisitPage()
				.getNewVisitUpdateBtn().getAttribute("value"), "Update");
	}

	@Test(description = "Click Follow up Details Tab", dependsOnMethods = { "test013ClickReasonForVisit" })
	public void test017ClickFollowupDetailsTab() throws Exception {
		consultationPage.getReasonForVisitPage().clickFollowupDetailsTab();
		Assert.assertEquals(consultationPage.getReasonForVisitPage()
				.getFollowUpDetailsSaveBtn().getAttribute("value"), "Save");
	}

	@Test(description = "Fill Followup Details", dependsOnMethods = { "test017ClickFollowupDetailsTab" })
	public void test018FillFollowupDetails() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getReasonForVisitPage().fillFollowupDetails(
					outPatientListData);
			Assert.assertEquals(consultationPage.getReasonForVisitPage()
					.getFollowUpDetailsSaveBtn().getAttribute("value"), "Save");
		}

	}

	@Test(description = "Save Followup Details", dependsOnMethods = { "test017ClickFollowupDetailsTab" })
	public void test019SaveFollowupDetails() throws Exception {
		consultationPage.getReasonForVisitPage().clickSaveFllowupDetails();
		Assert.assertEquals(consultationPage.getReasonForVisitPage()
				.getFollowUpDetailsUpdateBtn().getAttribute("value"), "Update");

	}

	@Test(description = "Click 'History' Panel Menu Link", dependsOnMethods = { "test010CheckHistory" })
	public void test020ClickHistory() throws Exception {
		Assert.assertTrue(consultationPage.clickHistoryPanelLink());

	}

	@Test(description = "Check for Medication Tab", dependsOnMethods = { "test020ClickHistory" })
	public void test021CheckMedicationsTab() throws Exception {
		Assert.assertEquals(consultationPage.getHistoryPage()
				.checkMedicationTab(), "Medications");

	}

	@Test(description = "Check for Medical History Section", dependsOnMethods = { "test020ClickHistory" })
	public void test022CheckMedHistorySec() throws Exception {
		Assert.assertTrue(consultationPage.getMedicalHistorySection()
				.checkMedHistorySec());

	}

	@Test(description = "Check for Surgical History Section", dependsOnMethods = { "test020ClickHistory" })
	public void test023CheckSurgicalHistorySec() throws Exception {
		Assert.assertTrue(consultationPage.getSurgicalHistorySection()
				.checkSurgHistorySec());

	}

	@Test(description = "Check for Family History Section", dependsOnMethods = { "test020ClickHistory" })
	public void test024CheckFamilyHistorySec() throws Exception {
		Assert.assertTrue(consultationPage.getFamilyHistorySection()
				.checkFamilyHistorySec());

	}

	@Test(description = "Check for Social History Section", dependsOnMethods = { "test020ClickHistory" })
	public void test025CheckSocialHistorySec() throws Exception {
		Assert.assertTrue(consultationPage.getSocialHistorySection()
				.checkSocialHistorySec());

	}

	@Test(description = "Fill Medical History Section Info", dependsOnMethods = { "test022CheckMedHistorySec" })
	public void test026FillMedHistorySectionInfo() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getMedicalHistorySection().fillMedHistoryInfo(
					outPatientListData);
			Assert.assertEquals(consultationPage.getMedicalHistorySection()
					.getMedicalHistoryNotes().getAttribute("value"),
					outPatientListData[40]);
		}

	}

	@Test(description = "Fill Surgical History Section Info", dependsOnMethods = { "test023CheckSurgicalHistorySec" })
	public void test027FillSurgicalHistorySectionInfo() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getSurgicalHistorySection()
					.fillSurgicalHistoryInfo(outPatientListData);
			Assert.assertEquals(consultationPage.getSurgicalHistorySection()
					.getNotes().getAttribute("value"), outPatientListData[45]);
		}

	}

	@Test(description = "Fill Family History Section Info", dependsOnMethods = { "test024CheckFamilyHistorySec" })
	public void test028FillFamilyHistorySectionInfo() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getFamilyHistorySection().fillFamilyHistoryInfo(
					outPatientListData);
			Assert.assertEquals(consultationPage.getFamilyHistorySection()
					.getNotes().getAttribute("value"), outPatientListData[50]);
		}

	}

	@Test(description = "Fill Social History Section Info", dependsOnMethods = { "test025CheckSocialHistorySec" })
	public void test029FillSocialHistorySectionInfo() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getSocialHistorySection().fillSocialHistoryInfo(
					outPatientListData);
			Assert.assertEquals(consultationPage.getSocialHistorySection()
					.getOccupation().getAttribute("value"),
					outPatientListData[53]);
		}

	}

	@Test(description = "Save HPI Details", dependsOnMethods = { "test029FillSocialHistorySectionInfo" }, alwaysRun = true)
	public void test030SaveHPIDetails() throws Exception {
		consultationPage.getHistoryPage().clickSaveHPI();
		Assert.assertEquals(consultationPage.getHistoryPage().getHpiUpdateBtn()
				.getAttribute("value"), "Update");

	}

	@Test(description = "Click Medications Tab", dependsOnMethods = { "test021CheckMedicationsTab" })
	public void test031ClickMedicationsTab() throws Exception {
		consultationPage.getHistoryPage().clickMedicationsTab();
		Assert.assertEquals(consultationPage.getHistoryPage()
				.getMedicationsSaveBtn().getAttribute("value"), "Save");

	}

	@Test(description = "Check for Medication From Outside Sources Section", dependsOnMethods = { "test031ClickMedicationsTab" })
	public void test032CheckMedFromOutsideSourcesSec() throws Exception {
		Assert.assertTrue(consultationPage.getOutsideSourcesSection()
				.checkMedFromOutsideSources());

	}

	@Test(description = "Check for Medication From Our Sources Section", dependsOnMethods = { "test031ClickMedicationsTab" })
	public void test033CheckMedFromOurSourcesSec() throws Exception {
		Assert.assertTrue(consultationPage.getOurSourcesSection()
				.checkMedFromOurSources());

	}

	@Test(description = "Add Medication From Outside Sources Section data", dependsOnMethods = { "test032CheckMedFromOutsideSourcesSec" })
	public void test034AddMedFromOutsideSourcesSecData() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getOutsideSourcesSection().addOutsideSrcSecData(
					outPatientListData);
			Assert.assertEquals(consultationPage.getOutsideSourcesSection()
					.getNotes().getAttribute("value"), outPatientListData[73]);
		}
	}

	@Test(description = "Add Medication From Our Sources Section data", dependsOnMethods = { "test033CheckMedFromOurSourcesSec" })
	public void test035AddMedFromOurSourcesSecData() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getOurSourcesSection().addOurSrcSecData(
					outPatientListData);
			// Assert.assertEquals(consultationPage.getOurSourcesSection(),
			// outPatientListData[75]);

		}
	}

	@Test(description = "Save Medications Details", dependsOnMethods = { "test035AddMedFromOurSourcesSecData" }, alwaysRun = true)
	public void test036SaveMedicationsDetails() throws Exception {
		consultationPage.getHistoryPage().saveMedicationsDetails();
		Assert.assertEquals(consultationPage.getHistoryPage().getHpiUpdateBtn()
				.getAttribute("value"), "Update");

	}

	@Test(description = "Click 'Assessment & Plan' Panel Menu Link", dependsOnMethods = { "test011CheckAssessmentPlan" })
	public void test037ClickAssessmentPlan() throws Exception {
		Assert.assertTrue(consultationPage.clickAssessmentPlanPanelLink());
	}

	@Test(description = "Click Plan Tab", dependsOnMethods = { "test037ClickAssessmentPlan" })
	public void test038ClickPlanTab() throws Exception {
		consultationPage.getAssessmentPlanPage().clickPlanTab();
		Assert.assertEquals(consultationPage.getAssessmentPlanPage()
				.getPlanSaveBtn().getAttribute("value"), "Save");
	}

	@Test(description = "Check for Patient Education Section", dependsOnMethods = { "test038ClickPlanTab" })
	public void test039CheckPatientEducationSec() throws Exception {
		Assert.assertTrue(consultationPage.getPatientEducationSection()
				.checkPatEducationSec());

	}

	@Test(description = "Check for Non-Pharmacological Treatment Section", dependsOnMethods = { "test038ClickPlanTab" })
	public void test040CheckNonPharmTreatSec() throws Exception {
		Assert.assertTrue(consultationPage
				.getNonPharmacologicalTreatmentSection()
				.checkNonPharmTreatSec());

	}

	@Test(description = "Check for Active Orders for this Encounter Section", dependsOnMethods = { "test038ClickPlanTab" })
	public void test041CheckActiveOrdersForEncounterSec() throws Exception {
		Assert.assertTrue(consultationPage.getActiveOrdersForEncounterSection()
				.checkActiveOrdersForEncSec());

	}

	@Test(description = "Check for Other Plan Section", dependsOnMethods = { "test038ClickPlanTab" })
	public void test042CheckOtherPlanSec() throws Exception {
		Assert.assertTrue(consultationPage.getOtherPlanSection()
				.checkOtherPlanSec());

	}

	@Test(description = "Add Patient Education Section Data", dependsOnMethods = { "test039CheckPatientEducationSec" })
	public void test043AddPatientEducationSecData() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getPatientEducationSection()
					.addPatientEducationSecData(outPatientListData);
			Assert.assertEquals(consultationPage.getPatientEducationSection()
					.getPatientEducationNotes().getAttribute("value"),
					outPatientListData[76]);
		}
	}

	@Test(description = "Add Non-Pharmacological Treatment Section Data", dependsOnMethods = { "test040CheckNonPharmTreatSec" })
	public void test044AddNonPharmTreatSecData() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getNonPharmacologicalTreatmentSection()
					.addNonPharmTreatSecData(outPatientListData);
			Assert.assertEquals(consultationPage
					.getNonPharmacologicalTreatmentSection().getNonPharmNotes()
					.getAttribute("value"), outPatientListData[77]);
		}
	}

	@Test(description = "Add Active Orders for this Encounter Section Data", dependsOnMethods = { "test041CheckActiveOrdersForEncounterSec" })
	public void test045AddActiveOrdForEncSecData() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			// Assert.assertTrue(consultationPage
			// .getActiveOrdersForEncounterSection());
		}
	}

	@Test(description = "Add Other Plan Section Data", dependsOnMethods = { "test042CheckOtherPlanSec" })
	public void test046AddOtherPlanSecData() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			consultationPage.getOtherPlanSection().addOtherPlanSecData(
					outPatientListData);
			Assert.assertEquals(consultationPage.getOtherPlanSection()
					.getOtherPlan().getAttribute("value"),
					outPatientListData[78]);
		}
	}

	@Test(description = "Save Plan Details", dependsOnMethods = { "test046AddOtherPlanSecData" }, alwaysRun = true)
	public void test047SavePlanDetails() throws Exception {
		consultationPage.getAssessmentPlanPage().savePlanDetails();
		Assert.assertEquals(consultationPage.getAssessmentPlanPage()
				.getPlanUpdateBtn().getAttribute("value"), "Update");

	}

	@Test(description = "Click 'Consultation Summary' Panel Menu Link", dependsOnMethods = { "test012CheckConsultationSummary" })
	public void test048ClickConsultationSummary() throws Exception {
		Assert.assertTrue(consultationPage.clickConsultationSummaryPanelLink());
	}

	@Test(description = "Save Consultation Summary Details", dependsOnMethods = { "test048ClickConsultationSummary" })
	public void test049SaveConsultationSummaryDetails() throws Exception {
		consultationPage.getConsultationSummaryPage().saveConsSummaryDetails();
		Assert.assertEquals(consultationPage.getConsultationSummaryPage()
				.getConSummmaryUpdateBtn().getAttribute("value"), "Update");
	}

	@Test(description = "Check for Order Button", dependsOnMethods = { "test049SaveConsultationSummaryDetails" }, alwaysRun = true)
	public void test050CheckOrderBtn() throws Exception {
		Assert.assertTrue(consultationPage.checkOrderBtn());

	}

	@Test(description = "Click Order Button", dependsOnMethods = { "test050CheckOrderBtn" })
	public void test051ClickOrderBtn() throws Exception {
		Assert.assertEquals(consultationPage.clickOrderButton(), "Order Entry");

	}

	@Test(description = "Check for New Order Tab", dependsOnMethods = { "test051ClickOrderBtn" })
	public void test052CheckNewOrderTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderEntryPage()
				.checkNewOrderTab());

	}

	@Test(description = "Check for Existing Order Tab", dependsOnMethods = { "test051ClickOrderBtn" })
	public void test053CheckExistingOrderTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderEntryPage()
				.checkExistingOrderTab());

	}

	@Test(description = "Check Diagnosis, Vital Signs, Allergies Details Section", dependsOnMethods = { "test051ClickOrderBtn" })
	public void test054CheckDiagVitalsAllergiesSec() throws Exception {
		Assert.assertTrue(consultationPage
				.getDiagVitalSignsAllergiesDetailsSec()
				.checkDiagVitalsAllergiesSec());

	}

	@Test(description = "Check Order Details Section", dependsOnMethods = { "test051ClickOrderBtn" })
	public void test055CheckOrderDetailsSec() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.checkOrderDetailsSec());

	}

	@Test(description = "Check Add/View Diagnosis.. Button", dependsOnMethods = { "test054CheckDiagVitalsAllergiesSec" })
	public void test056CheckAddViewDiagnosisBtn() throws Exception {
		Assert.assertTrue(consultationPage
				.getDiagVitalSignsAllergiesDetailsSec()
				.checkAddViewDiagnosisBtn());

	}

	@Test(description = "Check Add/View Allergies.. Button", dependsOnMethods = { "test054CheckDiagVitalsAllergiesSec" })
	public void test057CheckAddViewAlrgyBtn() throws Exception {
		Assert.assertTrue(consultationPage
				.getDiagVitalSignsAllergiesDetailsSec().checkAddViewAlrgyBtn());

	}

	@Test(description = "Check Vitals.. Button", dependsOnMethods = { "test054CheckDiagVitalsAllergiesSec" })
	public void test058CheckAddViewVitalsBtn() throws Exception {
		Assert.assertTrue(consultationPage
				.getDiagVitalSignsAllergiesDetailsSec().checkAddViewVitalsBtn());

	}

	@Test(description = "Click Add/View Allergies.. BUtton", dependsOnMethods = { "test057CheckAddViewAlrgyBtn" })
	public void test059ClickAddViewAllergiesBtn() throws Exception {
		consultationPage.getDiagVitalSignsAllergiesDetailsSec()
				.clickAddViewAllergiesBtn();
		Assert.assertTrue(consultationPage.getAllergyPopupPage()
				.getAllergyName().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Allergy Name", dependsOnMethods = { "test059ClickAddViewAllergiesBtn" })
	public void test060ValidateAllergyNameMandatoryField() throws Exception {
		Assert.assertTrue(consultationPage.getAllergyPopupPage()
				.isMandAllergyName());
	}

	@Test(description = "Reset Allergy Details", dependsOnMethods = { "test059ClickAddViewAllergiesBtn" })
	public void test061ResetAllergyDetails() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getAllergyPopupPage().addAllergyDetails(
					orderEntryListData);
			consultationPage.getAllergyPopupPage().clickResetAlrgyBtn();
			Assert.assertEquals(consultationPage.getAllergyPopupPage()
					.getAllergyName().getAttribute("value"), "");
		}
	}

	@Test(description = "Add Allergy Details", dependsOnMethods = { "test059ClickAddViewAllergiesBtn" })
	public void test062AddAllergyDetails() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getAllergyPopupPage().addAllergyDetails(
					orderEntryListData);
			consultationPage.getAllergyPopupPage().clickAddAlrgyBtn();
			Assert.assertEquals(consultationPage.getAllergyPopupPage()
					.chkAlrgyDataGrid(orderEntryListData),
					orderEntryListData[0]);
		}
	}

	@Test(description = "Check Edit action link", dependsOnMethods = { "test062AddAllergyDetails" })
	public void test063CheckEditLink() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			Assert.assertTrue(consultationPage.getAllergyPopupPage()
					.chkEditLink(orderEntryListData));
		}
	}

	@Test(description = "Check Delete action link", dependsOnMethods = { "test062AddAllergyDetails" })
	public void test064CheckDeleteLink() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			Assert.assertTrue(consultationPage.getAllergyPopupPage()
					.chkDeleteLink(orderEntryListData));
		}
	}

	@Test(description = "Edit Allergy Details", dependsOnMethods = { "test063CheckEditLink" })
	public void test065EditAllergyDtl() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getAllergyPopupPage().editAllergyDetails(
					orderEntryListData);
			consultationPage.getAllergyPopupPage().clickUpdateAlrgyBtn();
			Assert.assertEquals(consultationPage.getAllergyPopupPage()
					.chkUpdatedAlrgyDtl(orderEntryListData),
					orderEntryListData[1]);
		}
	}

	@Test(description = "Delete Allergy Details", dependsOnMethods = { "test064CheckDeleteLink" })
	public void test066DeleteAllergyDtl() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			Assert.assertFalse(consultationPage.getAllergyPopupPage()
					.deleteAllergyDetails(orderEntryListData));
		}
	}

	@Test(description = "Save Allergy Details", dependsOnMethods = { "test066DeleteAllergyDtl" }, alwaysRun = true)
	public void test067SaveAllergyDetails() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getAllergyPopupPage().saveAlrgyDetails();
			Assert.assertEquals(
					consultationPage.getDiagVitalSignsAllergiesDetailsSec()
							.getAllergyData(orderEntryListData),
					orderEntryListData[0]);
		}
	}

	@Test(description = "Verify Edit & Delete links in Allerigies data grid not Displaying after user Submit Order", dependsOnMethods = { "test067SaveAllergyDetails" })
	public void test068VerifyNoEditDeleteLinkInAlrgy() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getDiagVitalSignsAllergiesDetailsSec()
					.clickAddViewAllergiesBtn();
			Assert.assertFalse(consultationPage.getAllergyPopupPage()
					.chkEditLink(orderEntryListData));
			Assert.assertFalse(consultationPage.getAllergyPopupPage()
					.chkDeleteLink(orderEntryListData));
		}
	}

	@Test(description = "Verify Cancel button closes Allergy popup", dependsOnMethods = { "test068VerifyNoEditDeleteLink" })
	public void test069VerifyCancelBtnCloseAlrgyPopup() throws Exception {
		consultationPage.getAllergyPopupPage().clickCancelBtn();
		Assert.assertFalse(consultationPage.getAllergyPopupPage()
				.isAlrgyPopupDisplayed());
	}

	@Test(description = "Click Add/View Allergies.. BUtton", dependsOnMethods = { "test058CheckAddViewVitalsBtn" })
	public void test070ClickAddViewVitalsBtn() throws Exception {
		consultationPage.getDiagVitalSignsAllergiesDetailsSec()
				.clickAddViewVitalsBtn();
		Assert.assertTrue(consultationPage.getVitalsPopupPage()
				.getVitalsPopupForm().isDisplayed());

	}

	@Test(description = "Reset Vitals Details", dependsOnMethods = { "test070ClickAddViewVitalsBtn" })
	public void test071ResetVitalsDetails() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getVitalsPopupPage().addVitalsDetails(
					orderEntryListData);
			consultationPage.getVitalsPopupPage().clickResetVitalsBtn();
			Assert.assertEquals(consultationPage.getVitalsPopupPage()
					.getVitalsPopupHeight().getAttribute("value"), "");
		}
	}

	@Test(description = "Add Vitals Details", dependsOnMethods = { "test070ClickAddViewVitalsBtn" })
	public void test072AddVitalsDetails() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getVitalsPopupPage().addVitalsDetails(
					orderEntryListData);
			consultationPage.getVitalsPopupPage().clickAddVitalsBtn();
			Assert.assertEquals(consultationPage.getVitalsPopupPage()
					.checkVitalsDataGrid(orderEntryListData),
					orderEntryListData[11]);
		}
	}

	@Test(description = "Check Edit action link", dependsOnMethods = { "test072AddVitalsDetails" })
	public void test073CheckEditLink() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			Assert.assertTrue(consultationPage.getVitalsPopupPage()
					.checkEditLink(orderEntryListData));
		}
	}

	@Test(description = "Check Remove action link", dependsOnMethods = { "test072AddVitalsDetails" })
	public void test074CheckRemoveLink() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			Assert.assertTrue(consultationPage.getVitalsPopupPage()
					.checkRemoveLink(orderEntryListData));
		}
	}

	@Test(description = "Edit Vitals Details", dependsOnMethods = { "test073CheckEditLink" })
	public void test075EditVitalsDtl() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getVitalsPopupPage().editVitalsDetails(
					orderEntryListData);
			consultationPage.getVitalsPopupPage().clickUpdateVitalsBtn();
			Assert.assertEquals(consultationPage.getVitalsPopupPage()
					.checkUpdatedVitalsDtl(orderEntryListData),
					orderEntryListData[12]);
		}
	}

	@Test(description = "Remove Vitals Details", dependsOnMethods = { "test074CheckRemoveLink" })
	public void test076DeleteVitalsDtl() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			Assert.assertFalse(consultationPage.getVitalsPopupPage()
					.removeVitalsDetails(orderEntryListData));
		}
	}

	@Test(description = "Submit Vitals Details", dependsOnMethods = { "test076DeleteVitalsDtl" }, alwaysRun = true)
	public void test077SubmitVitalsDetails() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getVitalsPopupPage().submitVitalsDetails();
			Assert.assertEquals(consultationPage
					.getDiagVitalSignsAllergiesDetailsSec().getO2Saturation()
					.getAttribute("value"), orderEntryListData[17]);

		}
	}

	@Test(description = "Verify Edit & Delete links in Vitals data grid not Displaying after user Submit Order", dependsOnMethods = { "test077SubmitVitalsDetails" })
	public void test078VerifyNoEditDeleteLinkInVitals() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getDiagVitalSignsAllergiesDetailsSec()
					.clickAddViewVitalsBtn();
			Assert.assertFalse(consultationPage.getVitalsPopupPage()
					.checkEditLink(orderEntryListData));
			Assert.assertFalse(consultationPage.getVitalsPopupPage()
					.checkRemoveLink(orderEntryListData));
		}
	}

	@Test(description = "Verify Cancel button closes Allergy popup", dependsOnMethods = { "test078VerifyNoEditDeleteLinkInVitals" })
	public void test079VerifyCancelBtnCloseVitalsPopup() throws Exception {
		consultationPage.getVitalsPopupPage().clickCancelBtn();
		Assert.assertFalse(consultationPage.getVitalsPopupPage()
				.isVitalsPopupDisplayed());
	}

	@Test(description = "Check Pharmacy Tab", dependsOnMethods = { "test055CheckOrderDetailsSec" })
	public void test080CheckPharmacyTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.checkPharmacyTab());

	}

	@Test(description = "Check Laboratory Tab", dependsOnMethods = { "test055CheckOrderDetailsSec" })
	public void test081CheckLaboratoryTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.checkLaboratoryTab());

	}

	@Test(description = "Check Radiology Tab", dependsOnMethods = { "test055CheckOrderDetailsSec" })
	public void test082CheckRadiologyTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.checkRadiologyTab());

	}

	@Test(description = "Check Others Tab", dependsOnMethods = { "test055CheckOrderDetailsSec" })
	public void test083CheckOthersTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.checkOthersTab());

	}

	@Test(description = "Click Pharmacy Tab", dependsOnMethods = { "test080CheckPharmacyTab" })
	public void test084ClickPharmacyTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.clickPharmacyTab());

	}

	@Test(description = "Check Pharmacy Tab data empty before search", dependsOnMethods = { "test084ClickPharmacyTab" })
	public void test085CheckPharmacyTab() throws Exception {
		Assert.assertFalse(consultationPage.getOrderDetailsSection()
				.isPcyDataEmpty());

	}

	@Test(description = "Check Pharmacy Order Details Quick Search", dependsOnMethods = { "test084ClickPharmacyTab" })
	public void test086CheckPharmacyQuickSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().quickSearchPharmacyData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyPcySearchData(orderEntryListData));
		}

	}

	@Test(description = "Check Pharmacy Order Details Adv.Search", dependsOnMethods = { "test084ClickPharmacyTab" })
	public void test087CheckPharmacyAdvSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().advSearchPharmacyData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyPcySearchData(orderEntryListData));
		}

	}

	@Test(description = "Select Pharmacy Order data", dependsOnMethods = { "test087CheckPharmacyAdvSearch" })
	public void test088SelectPharmacyOrderData() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().selectPharmacyOrderData(
					orderEntryListData);
			consultationPage.getPharmacyOrderingInfoPopup().addPcyOrderInfo(
					orderEntryListData);
			Assert.assertEquals(consultationPage.getOrderDetailsSection()
					.verifySelectionListData(orderEntryListData[19]),
					orderEntryListData[19]);
		}

	}

	@Test(description = "Click Laboratory Tab", dependsOnMethods = { "test081CheckLaboratoryTab" })
	public void test089ClickLabTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.clickLabTab());

	}

	@Test(description = "Check Laboratory Tab data empty before search", dependsOnMethods = { "test089ClickLabTab" })
	public void test090CheckLabTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.isLabDataEmpty());

	}

	@Test(description = "Check Laboratory Order Details Quick Search", dependsOnMethods = { "test089ClickLabTab" })
	public void test091CheckLabQuickSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().quickSearchLabData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyLabSearchData(orderEntryListData));
		}

	}

	@Test(description = "Check Laboratory Order Details Adv.Search", dependsOnMethods = { "test089ClickLabTab" })
	public void test092CheckLabAdvSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().advSearchLabData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyLabSearchData(orderEntryListData));
		}

	}

	@Test(description = "Select Laboratory Order data", dependsOnMethods = { "test092CheckLabAdvSearch" })
	public void test093SelectLabOrderData() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().selectLabOrderData(
					orderEntryListData);
			consultationPage.getLabOrderingInfoPopup().addLabOrderInfo(
					orderEntryListData);
			Assert.assertEquals(consultationPage.getOrderDetailsSection()
					.verifySelectionListData(orderEntryListData[34]),
					orderEntryListData[34]);
		}

	}

	@Test(description = "Click Radiology Tab", dependsOnMethods = { "test082CheckRadiologyTab" })
	public void test094ClickRadTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.clickRadTab());

	}

	@Test(description = "Check Radiology Tab data empty before search", dependsOnMethods = { "test094ClickRadTab" })
	public void test095CheckRadTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.isRadDataEmpty());

	}

	@Test(description = "Check Radiology Order Details Quick Search", dependsOnMethods = { "test094ClickRadTab" })
	public void test096CheckRadQuickSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().quickSearchRadData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyRadSearchData(orderEntryListData));
		}

	}

	@Test(description = "Check Radiology Order Details Adv.Search", dependsOnMethods = { "test094ClickRadTab" })
	public void test097CheckRadAdvSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().advSearchRadData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyRadSearchData(orderEntryListData));
		}

	}
	
	@Test(description = "Select Radiology Order data", dependsOnMethods = { "test094ClickRadTab" })
	public void test102SelectRadOrderData() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().selectRadOrderData(
					orderEntryListData);
			consultationPage.getRadOrderingInfoPopup().addRadOrderInfo(
					orderEntryListData);
			Assert.assertEquals(consultationPage.getOrderDetailsSection()
					.verifySelectionListData(orderEntryListData[38]),
					orderEntryListData[38]);
		}

	}

	@Test(description = "Click Others Tab", dependsOnMethods = { "test083CheckOthersTab" })
	public void test098ClickOthersTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.clickOthersTab());

	}

	@Test(description = "Check Others Tab data empty before search", dependsOnMethods = { "test098ClickOthersTab" })
	public void test099CheckOthersTab() throws Exception {
		Assert.assertTrue(consultationPage.getOrderDetailsSection()
				.isOthersDataEmpty());

	}

	@Test(description = "Check Others Order Details Quick Search", dependsOnMethods = { "test098ClickOthersTab" })
	public void test100CheckOthersQuickSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().quickSearchOthersData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyOthersSearchData(orderEntryListData));
		}

	}

	@Test(description = "Check Others Order Details Adv.Search", dependsOnMethods = { "test098ClickOthersTab" })
	public void test101CheckOthersAdvSearch() throws Exception {
		for (String[] orderEntryListData : orderEntryList) {
			consultationPage.getOrderDetailsSection().advSearchOthersData(
					orderEntryListData);
			Assert.assertTrue(consultationPage.getOrderDetailsSection()
					.verifyOthersSearchData(orderEntryListData));
		}

	}
	

}