package com.atk.himma.pageobjects.contracts.sections.rateplandetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class RPDetailsFirstSection extends DriverWaitClass {
	public final static String RPCODE_ID = "RATE_PLAN_CODE";
	public final static String RPREFNUM_ID = "RATE_PLAN_REF_NUM";
	public final static String RPSHORTNAME_ID = "RATEPLAN_SHORT_NAME";
	public final static String RPNAME_ID = "RATE_PLAN_NAME";
	public final static String RPNAMEAR_ID = "RATEPLAN_ARABIC_NAME";
	public final static String RPSTARTDATE_ID = "START_DATE";
	public final static String RPENDDATE_ID = "END_DATE";
	public final static String DBTRNAMETXT_ID = "AGMNT_POP_NAME";
	public final static String DEBTORLOOKUP_ID = "RATE_PLAN_POP_UP";
	public final static String DEBTORPOPUPFORM_ID = "debtoragmntNameformId";
	public final static String DEBTMBU_ID = "ARMNT_SERDEBT_MBU";
	public final static String GLOBALDEBTORCHKBOX_ID = "DEB_GLOBAL_CHBOX_POPUP";
	public final static String DEBTORTYPE_ID = "ARMNT_SERDEBT_DT";
	public final static String DEBTORCATEGORY_ID = "ARMNT_SERDEBT_DC";
	public final static String DEBTORNAME_ID = "ARMNT_SERDEBT_DN";
	public final static String DEBTORSEARCHBTN_ID = "searchDebatorNameId";
	public final static String DEBTORRESETBTN_ID = "ARMNT_SERDEBT_RESET";
	public final static String DEBTORGRIDDIV_ID = "ARMNT_SERDEBT_GRID_DIV";
	public final static String AGRMNTNAME_ID = "agreementName_details";
	public final static String MBU_ID = "mainBusinessUnit_details";
	public final static String VERSION_ID = "version_details";
	public final static String VIEWVERSION_ID = "VIEW_VERSION";
	public final static String GLOBALRP_ID = "RATE_GLOBAL_CHBOX_MAIN";
	public final static String BASEREFTARIFF_ID = "BASE_REF_TARIFF";
	public final static String RETRIEVEBTN_ID = "RETRIEVE";

	@FindBy(id = RPCODE_ID)
	private WebElement ratePlanCode;

	@FindBy(id = RPREFNUM_ID)
	private WebElement ratePlanRefNum;

	@FindBy(id = RPSHORTNAME_ID)
	private WebElement ratePlanShortName;

	@FindBy(id = RPNAME_ID)
	private WebElement ratePlanName;

	@FindBy(id = RPNAMEAR_ID)
	private WebElement ratePlanNameAr;

	@FindBy(id = RPSTARTDATE_ID)
	private WebElement effectiveStartDate;

	@FindBy(id = RPENDDATE_ID)
	private WebElement effectiveEndDate;

	@FindBy(id = DBTRNAMETXT_ID)
	private WebElement debtorNameTxt;

	@FindBy(id = DEBTORLOOKUP_ID)
	private WebElement debtorLookup;

	@FindBy(id = DEBTORPOPUPFORM_ID)
	private WebElement debtorLookupForm;

	@FindBy(id = DEBTMBU_ID)
	private WebElement debtorMBU;

	@FindBy(id = GLOBALDEBTORCHKBOX_ID)
	private WebElement globalDebtorChkBox;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	@FindBy(id = DEBTORCATEGORY_ID)
	private WebElement debtorCategory;

	@FindBy(id = DEBTORNAME_ID)
	private WebElement debtorName;

	@FindBy(id = DEBTORSEARCHBTN_ID)
	private WebElement debtorSearchBtn;

	@FindBy(id = DEBTORRESETBTN_ID)
	private WebElement debtorResetBtn;

	@FindBy(id = DEBTORGRIDDIV_ID)
	private WebElement debtorGridDiv;

	@FindBy(id = AGRMNTNAME_ID)
	private WebElement agrmntName;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = VERSION_ID)
	private WebElement version;

	@FindBy(id = VIEWVERSION_ID)
	private WebElement viewVersion;

	@FindBy(id = GLOBALRP_ID)
	private WebElement globalRatePlanChkBox;

	@FindBy(id = BASEREFTARIFF_ID)
	private WebElement baseRefTariff;

	@FindBy(id = RETRIEVEBTN_ID)
	private WebElement retrieveBtn;

	public boolean isMandRatePlanName() {
		waitForElementId(RPNAME_ID);
		return isMandatoryField(ratePlanName);
	}

	public boolean isMandDebtorName() {
		waitForElementId(DBTRNAMETXT_ID);
		return isMandatoryField(debtorNameTxt);
	}

	public boolean isMandAgrmntName() {
		waitForElementId(AGRMNTNAME_ID);
		return isMandatoryField(agrmntName);
	}

	public boolean isMandMBUName() {
		waitForElementId(MBU_ID);
		return isMandatoryField(mbu);
	}

	public boolean isMandStartDate() {
		waitForElementId(RPSTARTDATE_ID);
		return isMandatoryField(effectiveStartDate);
	}

	public boolean isMandEndDate() {
		waitForElementId(RPENDDATE_ID);
		return isMandatoryField(effectiveEndDate);
	}

	public void fillData(String[] ratePlanListData) throws Exception {
		waitForElementId(RPREFNUM_ID);
		sleepLong();
		ratePlanRefNum.clear();
		ratePlanRefNum.sendKeys(ratePlanListData[0]);
		ratePlanShortName.clear();
		ratePlanShortName.sendKeys(ratePlanListData[1]);
		ratePlanName.clear();
		ratePlanName.sendKeys(ratePlanListData[2]);
		ratePlanNameAr.clear();
		ratePlanNameAr.sendKeys(ratePlanListData[3]);
		debtorLookup.click();
		waitForElementId(DEBTORLOOKUP_ID);
		if (Boolean.valueOf(ratePlanListData[4])) {
			globalDebtorChkBox.click();
		}
		if (!ratePlanListData[5].isEmpty()) {
			new Select(debtorType).selectByVisibleText(ratePlanListData[5]);
		}
		if (!ratePlanListData[6].isEmpty()) {
			new Select(debtorCategory).selectByVisibleText(ratePlanListData[6]);
		}
		debtorName.clear();
		debtorName.sendKeys(ratePlanListData[7]);
		debtorSearchBtn.click();
		sleepVeryShort();
		waitForElementId(DEBTORGRIDDIV_ID);
		clickOnGridAction("AGMNT_DEBT_DETAILS_GRID_debtorName",
				ratePlanListData[7], "Select");
		sleepShort();
		if (!ratePlanListData[8].isEmpty()) {
			new Select(agrmntName).selectByVisibleText(ratePlanListData[8]);
		}
		sleepVeryShort();
		if (!ratePlanListData[9].isEmpty()) {
			new Select(mbu).selectByVisibleText(ratePlanListData[9]);
		}
		sleepShort();
		if (!ratePlanListData[10].isEmpty()) {
			effectiveStartDate.clear();
			effectiveStartDate.sendKeys(ratePlanListData[10]);
		}
		if (!ratePlanListData[11].isEmpty()) {
			effectiveEndDate.clear();
			effectiveEndDate.sendKeys(ratePlanListData[11]);
		}

		retrieveBtn.click();
		sleepShort();

	}

	public String getSelectedMBU() {
		return new Select(mbu).getFirstSelectedOption().getText();
	}

	public WebElement getRatePlanCode() {
		return ratePlanCode;
	}

	public WebElement getRatePlanRefNum() {
		return ratePlanRefNum;
	}

	public WebElement getRatePlanShortName() {
		return ratePlanShortName;
	}

	public WebElement getRatePlanName() {
		return ratePlanName;
	}

	public WebElement getRatePlanNameAr() {
		return ratePlanNameAr;
	}

	public WebElement getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public WebElement getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public WebElement getDebtorNameTxt() {
		return debtorNameTxt;
	}

	public WebElement getDebtorLookup() {
		return debtorLookup;
	}

	public WebElement getDebtorLookupForm() {
		return debtorLookupForm;
	}

	public WebElement getDebtorMBU() {
		return debtorMBU;
	}

	public WebElement getGlobalDebtorChkBox() {
		return globalDebtorChkBox;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

	public WebElement getDebtorCategory() {
		return debtorCategory;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorSearchBtn() {
		return debtorSearchBtn;
	}

	public WebElement getDebtorResetBtn() {
		return debtorResetBtn;
	}

	public WebElement getDebtorGridDiv() {
		return debtorGridDiv;
	}

	public WebElement getAgrmntName() {
		return agrmntName;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getVersion() {
		return version;
	}

	public WebElement getViewVersion() {
		return viewVersion;
	}

	public WebElement getGlobalRatePlanChkBox() {
		return globalRatePlanChkBox;
	}

	public WebElement getBaseRefTariff() {
		return baseRefTariff;
	}

	public WebElement getRetrieveBtn() {
		return retrieveBtn;
	}

}
