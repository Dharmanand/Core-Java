package com.atk.himma.pageobjects.contracts.sections.policydetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PolicyDocumentScanSection extends DriverWaitClass {
	public static final String POLDOCSCANSEC_LINKTEXT = "Policy Document Scan";
	public final static String ADDROWPOLBTN_ID = "AddRow_PolDocButton";
	public final static String POLDOCSCANDIV_ID = "policyDocumentsScan_div";
	public final static String POLDOCNAME_ID = "POLICY_DOCUMENT_NAME";
	public final static String ADDFILESBTN_NAME = "fileUploadDetails.fileUpload";
	public final static String ADDBTN_ID = "ADD_DOCUMENT";
	public final static String CANCELROWBTN_ID = "CancelRow_PolDoc";
	public final static String POLDOCGRIDDIV_ID = "POLICY_DOCUMENT_GRID_DIV";
	public static final String VIEWDOCLINK_XPATH = ".//table[@id='POLICY_DOCUMENT_GRID']/..//a[text()=' View ']";
	public static final String DELETEDOCLINK_XPATH = ".//table[@id='POLICY_DOCUMENT_GRID']/..//a[text()=' Delete ']";

	@FindBy(linkText = POLDOCSCANSEC_LINKTEXT)
	private WebElement polDocScanSec;

	@FindBy(id = ADDROWPOLBTN_ID)
	private WebElement addRowPolBtn;

	@FindBy(id = POLDOCSCANDIV_ID)
	private WebElement polDocScanDiv;

	@FindBy(id = POLDOCNAME_ID)
	private WebElement polDocName;

	@FindBy(name = ADDFILESBTN_NAME)
	private WebElement addFilesBtn;

	@FindBy(id = ADDBTN_ID)
	private WebElement addBtn;

	@FindBy(id = CANCELROWBTN_ID)
	private WebElement cancelBtn;

	@FindBy(id = POLDOCGRIDDIV_ID)
	private WebElement policyDocGridDiv;

	@FindBy(xpath = VIEWDOCLINK_XPATH)
	private WebElement viewDocLink;

	@FindBy(xpath = DELETEDOCLINK_XPATH)
	private WebElement deleteDocLink;

	public void addPolicyDocsData(String[] policyListData) throws Exception {
		waitForElementId(ADDROWPOLBTN_ID);
		addRowPolBtn.click();
		sleepVeryShort();
		waitForElementId(POLDOCSCANDIV_ID);
		polDocName.clear();
		polDocName.sendKeys(policyListData[13]);
		addFilesBtn.sendKeys(policyListData[14]);
		addBtn.click();
		waitForElementId(POLDOCGRIDDIV_ID);

	}

	public boolean checkPolicyDocGrid(String[] policyListData) {
		try {
			waitForElementXpathExpression(".//td[@aria-describedby='POLICY_DOCUMENT_GRID_documentName' and @title='"
					+ policyListData[13] + "']");
			return webDriver
					.findElement(
							By.xpath(".//td[@aria-describedby='POLICY_DOCUMENT_GRID_documentName' and @title='"
									+ policyListData[13] + "']")).isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public WebElement getPolDocScanSec() {
		return polDocScanSec;
	}

	public WebElement getAddRowPolBtn() {
		return addRowPolBtn;
	}

	public WebElement getPolDocScanDiv() {
		return polDocScanDiv;
	}

	public WebElement getPolDocName() {
		return polDocName;
	}

	public WebElement getAddFilesBtn() {
		return addFilesBtn;
	}

	public WebElement getAddBtn() {
		return addBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getPolicyDocGridDiv() {
		return policyDocGridDiv;
	}

	public WebElement getViewDocLink() {
		return viewDocLink;
	}

	public WebElement getDeleteDocLink() {
		return deleteDocLink;
	}

}
