package com.atk.himma.pageobjects.appointsched;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails.AppointmentParameters;
import com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails.AvailabilityConfiguration;
import com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails.CalendarParameters;
import com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails.NonAvailabilityConfiguration;
import com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails.ResCalDetFirstSec;
import com.atk.himma.pageobjects.appointsched.tabs.ResourceCalendarListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ResourceCalendarPage extends DriverWaitClass implements
		StatusMessages, TopControls, RecordStatus {

	private ResourceCalendarListTab resourceCalendarListTab;
	private ResCalDetFirstSec resCalDetFirstSec;
	private CalendarParameters calendarParameters;
	private AppointmentParameters appointmentParameters;
	private AvailabilityConfiguration availabilityConfiguration;
	private NonAvailabilityConfiguration nonAvailabilityConfiguration;

	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";// saved
																															// successfully
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSADDMOREBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add More']";
	public final static String DETAILSCOPYBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Copy']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSVIEWCALBUTTON_XPATH = "VIEW_CALENDAR_LINK1";

	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement resCalDetailsPageTitle;

	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;

	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;

	@FindBy(xpath = DETAILSADDMOREBUTTON_XPATH)
	private WebElement detailsAddMoreButton;

	@FindBy(xpath = DETAILSCOPYBUTTON_XPATH)
	private WebElement detailsCopyButton;

	@FindBy(xpath = DETAILSVIEWCALBUTTON_XPATH)
	private WebElement detailsViewCalButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		resourceCalendarListTab = PageFactory.initElements(webDriver,
				ResourceCalendarListTab.class);
		resourceCalendarListTab.setWebDriver(webDriver);
		resourceCalendarListTab.setWebDriverWait(webDriverWait);

		resCalDetFirstSec = PageFactory.initElements(webDriver,
				ResCalDetFirstSec.class);
		resCalDetFirstSec.setWebDriver(webDriver);
		resCalDetFirstSec.setWebDriverWait(webDriverWait);

		calendarParameters = PageFactory.initElements(webDriver,
				CalendarParameters.class);
		calendarParameters.setWebDriver(webDriver);
		calendarParameters.setWebDriverWait(webDriverWait);

		appointmentParameters = PageFactory.initElements(webDriver,
				AppointmentParameters.class);
		appointmentParameters.setWebDriver(webDriver);
		appointmentParameters.setWebDriverWait(webDriverWait);

		availabilityConfiguration = PageFactory.initElements(webDriver,
				AvailabilityConfiguration.class);
		availabilityConfiguration.setWebDriver(webDriver);
		availabilityConfiguration.setWebDriverWait(webDriverWait);

		nonAvailabilityConfiguration = PageFactory.initElements(webDriver,
				NonAvailabilityConfiguration.class);
		nonAvailabilityConfiguration.setWebDriver(webDriver);
		nonAvailabilityConfiguration.setWebDriverWait(webDriverWait);
	}

	public ResourceCalendarPage clickOnResCalenMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws InterruptedException {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Appointment Scheduling");
		menuSelector.clickOnTargetMenu(menuList, "Resource Calendar");
		ResourceCalendarPage resourceCalendarPage = PageFactory.initElements(
				webDriver, ResourceCalendarPage.class);
		resourceCalendarPage.setWebDriver(webDriver);
		resourceCalendarPage.setWebDriverWait(webDriverWait);
		return resourceCalendarPage;
	}

	public String searchResource(String[] resCalDatas)
			throws InterruptedException {
		waitForElementId(ResourceCalendarListTab.GRID_ID);
		waitForElementId(ResourceCalendarListTab.MBU_ID);
		sleepVeryShort();
		if (!resCalDatas[1].isEmpty())
			new Select(resourceCalendarListTab.getMbu())
					.selectByVisibleText(resCalDatas[1].trim());
		if (resCalDatas[0].trim().equals("Resource")) {
			resourceCalendarListTab.getResourceName().clear();
			resourceCalendarListTab.getResourceName().sendKeys(
					resCalDatas[7].trim());
		} else if (resCalDatas[0].trim().equals("Location")) {
			resourceCalendarListTab.getLocationName().clear();
			resourceCalendarListTab.getLocationName().sendKeys(
					resCalDatas[7].trim());
		}
		resourceCalendarListTab.getSearchButton().click();
		waitForElementId(ResourceCalendarListTab.GRID_ID);
		sleepShort();
		if (resCalDatas[0].trim().equals("Resource")) {
			return waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
					ResourceCalendarListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY,
					resCalDatas[7]);
		} else if (resCalDatas[0].trim().equals("Location")) {
			return waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
					ResourceCalendarListTab.GRID_LOCATIONNAME_ARIA_DESCRIBEDBY,
					resCalDatas[7]);
		} else
			return null;
	}

	public String searchLocation(String[] resCalDatas)
			throws InterruptedException {
		waitForElementId(ResourceCalendarListTab.GRID_ID);
		waitForElementId(ResourceCalendarListTab.MBU_ID);
		sleepVeryShort();
		if (!resCalDatas[0].isEmpty()) {
			new Select(resourceCalendarListTab.getCalenderType())
					.selectByVisibleText(resCalDatas[0].trim());
			waitForPageLoaded(webDriver);
		}
		// waitForElementName(ResourceCalendarListTab.LOCATIONNAME_NAME);
		waitForPageLoaded(webDriver);
		sleepVeryShort();

		if (!resCalDatas[1].isEmpty())
			new Select(resourceCalendarListTab.getMbu())
					.selectByVisibleText(resCalDatas[1].trim());

		resourceCalendarListTab.getLocationName().clear();
		resourceCalendarListTab.getLocationName().sendKeys(
				resCalDatas[7].trim());
		resourceCalendarListTab.getSearchButton().click();
		waitForElementId(ResourceCalendarListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
				ResourceCalendarListTab.GRID_LOCATIONNAME_ARIA_DESCRIBEDBY,
				resCalDatas[7]);
	}

	public boolean clickOnConfigureLink(String[] resCalDatas)
			throws InterruptedException {
		if (new Select(resourceCalendarListTab.getCalenderType())
				.getFirstSelectedOption().getText().trim().equals("Resource"))
			waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
					ResourceCalendarListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY,
					resCalDatas[7]);
		if (new Select(resourceCalendarListTab.getCalenderType())
				.getFirstSelectedOption().getText().trim().equals("Location"))
			waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
					ResourceCalendarListTab.GRID_LOCATIONNAME_ARIA_DESCRIBEDBY,
					resCalDatas[7]);
		sleepShort();
		clickOnGridAction(resCalDatas[7], "Configure");
		waitForPageLoaded(webDriver);
		waitForElementId(ResCalDetFirstSec.MBU_ID);
		sleepVeryShort();
		if (resCalDatas[0].trim().equals("Resource")) {
			waitForElementId(ResCalDetFirstSec.RESONAME_ID);
			return resCalDetFirstSec.getResoName().getAttribute("value")
					.contains(resCalDatas[7].trim());
		} else if (resCalDatas[0].trim().equals("Location")) {
			waitForElementId(ResCalDetFirstSec.LOCNAME_ID);
			return resCalDetFirstSec.getLocName().getAttribute("value")
					.contains(resCalDatas[7].trim());
		} else
			return false;
	}

	public boolean clickOnRCListTab(String[] resCalDatas)
			throws InterruptedException {
		waitForElementXpathExpression(ResourceCalendarListTab.RESCALLISTTAB_XPATH);
		sleepVeryShort();
		resourceCalendarListTab.getResCalListTab().click();
		waitForElementId(ResourceCalendarListTab.GRID_ID);
		sleepShort();
		return searchResource(resCalDatas).contains(resCalDatas[7].trim());
	}

	public boolean clickOnEditLink(String[] resCalDatas)
			throws InterruptedException {
		waitForElementId(ResourceCalendarListTab.GRID_ID);
		sleepVeryShort();

		if (resCalDatas[0].trim().equals("Resource")) {
			waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
					ResourceCalendarListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY,
					resCalDatas[7]);
		} else if (resCalDatas[0].trim().equals("Location")) {
			waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
					ResourceCalendarListTab.GRID_LOCATIONNAME_ARIA_DESCRIBEDBY,
					resCalDatas[7]);
		}
		sleepShort();
		clickOnGridAction(resCalDatas[7], "Edit");
		waitForElementId(ResCalDetFirstSec.MBU_ID);

		if (resCalDatas[0].trim().equals("Resource")) {
			waitForElementId(ResCalDetFirstSec.RESONAME_ID);
			sleepVeryShort();
			return resCalDetFirstSec.getResoName().getAttribute("value")
					.contains(resCalDatas[7].trim());
		} else if (resCalDatas[0].trim().equals("Location")) {
			waitForElementId(ResCalDetFirstSec.LOCNAME_ID);
			sleepVeryShort();
			return resCalDetFirstSec.getLocName().getAttribute("value")
					.contains(resCalDatas[7].trim());
		} else
			return false;
	}

	public boolean editResourceCalender(String[] resCalDatas)
			throws InterruptedException {
		waitAndGetGridFirstCellText(ResourceCalendarListTab.GRID_ID,
				ResourceCalendarListTab.GRID_RESOURCENAME_ARIA_DESCRIBEDBY,
				resCalDatas[7]);
		sleepShort();
		clickOnGridAction(resCalDatas[7], "Edit");
		waitForElementId(ResCalDetFirstSec.MBU_ID);
		waitForElementId(ResCalDetFirstSec.RESONAME_ID);
		sleepVeryShort();
		return resCalDetFirstSec.getResoName().getAttribute("value")
				.contains(resCalDatas[7].trim());
	}

	public String updateResCalDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		detailsUpdateButton.click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		return statusMessage.getText().trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		return statusMessage.getText().trim();

	}

	public String activateRecord() throws InterruptedException {
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	/**
	 * @return the resourceCalendarListTab
	 */
	public ResourceCalendarListTab getResourceCalendarListTab() {
		return resourceCalendarListTab;
	}

	/**
	 * @return the resCalDetFirstSec
	 */
	public ResCalDetFirstSec getResCalDetFirstSec() {
		return resCalDetFirstSec;
	}

	/**
	 * @return the calendarParameters
	 */
	public CalendarParameters getCalendarParameters() {
		return calendarParameters;
	}

	/**
	 * @return the appointmentParameters
	 */
	public AppointmentParameters getAppointmentParameters() {
		return appointmentParameters;
	}

	/**
	 * @return the availabilityConfiguration
	 */
	public AvailabilityConfiguration getAvailabilityConfiguration() {
		return availabilityConfiguration;
	}

	/**
	 * @return the nonAvailabilityConfiguration
	 */
	public NonAvailabilityConfiguration getNonAvailabilityConfiguration() {
		return nonAvailabilityConfiguration;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the detailsAddMoreButton
	 */
	public WebElement getDetailsAddMoreButton() {
		return detailsAddMoreButton;
	}

	/**
	 * @return the detailsCopyButton
	 */
	public WebElement getDetailsCopyButton() {
		return detailsCopyButton;
	}

	/**
	 * @return the detailsViewCalButton
	 */
	public WebElement getDetailsViewCalButton() {
		return detailsViewCalButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the resCalDetailsPageTitle
	 */
	public WebElement getResCalDetailsPageTitle() {
		return resCalDetailsPageTitle;
	}

}
