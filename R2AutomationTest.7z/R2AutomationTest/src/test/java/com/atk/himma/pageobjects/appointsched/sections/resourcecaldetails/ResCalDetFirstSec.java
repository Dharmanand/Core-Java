package com.atk.himma.pageobjects.appointsched.sections.resourcecaldetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;

public class ResCalDetFirstSec extends DriverWaitClass{
	
	public final static String CALENDERCODE_ID = "setupCalCodeTF";
	public final static String MBU_ID = "mbusId";
	public final static String DEPARTMENT_ID = "deptId";
	public final static String SPECIALITY_ID = "specId";
	public final static String SUBSPECIALITY_ID = "subSpecId";
	public final static String RESONAME_ID = "setupResNameTF";
	public final static String LOCNAME_ID = "setupLocNameTF";
	public final static String RESOURCECODE_NAME = "resourceCalendar.resourceCode";
	public final static String LOCATION_ID= "locId";
	public final static String CALENDER_ID= "resCalSetupCalPerDD";
	public final static String CALSTDATE_ID= "resCalSetupFromDate";
	public final static String CALTODATE_ID= "resCalSetupToDate";
	public final static String ISAGESPECIFIC_ID= "IS_AGE_SPECIFIC";
	public final static String MINAGE_ID= "MIN_AGE";
	public final static String MINAGETYPE_ID= "MIN_AGE_TYPE";
	public final static String MAXAGE_ID= "MAX_AGE";
	public final static String MAXAGETYPE_ID= "MAX_AGE_TYPE";
	public final static String ISGENDERSPECIFIC_ID= "IS_GENDER_SPECIFIC";
	public final static String GENDER_NAME= "multiselect_GENDER";
	

	@FindBy(id = CALENDERCODE_ID)
	private WebElement calenderCode;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	@FindBy(id = SPECIALITY_ID)
	private WebElement speciality;

	@FindBy(name = SUBSPECIALITY_ID)
	private WebElement subSpeciality;

	@FindBy(id = RESONAME_ID)
	private WebElement resoName;
	
	@FindBy(id = LOCNAME_ID)
	private WebElement locName;
	
	@FindBy(name = RESOURCECODE_NAME)
	private WebElement resourceCode;

	@FindBy(xpath = LOCATION_ID)
	private WebElement location;

	@FindBy(className = CALENDER_ID)
	private WebElement calender;

	@FindBy(id = CALSTDATE_ID)
	private WebElement calStDate;

	@FindBy(id = CALTODATE_ID)
	private WebElement calToDate;

	@FindBy(id = ISAGESPECIFIC_ID)
	private WebElement isAgeSpecific;

	@FindBy(xpath = MINAGE_ID)
	private WebElement minAge;

	@FindBy(id = MINAGETYPE_ID)
	private WebElement minAgeType;

	@FindBy(id = MAXAGE_ID)
	private WebElement maxAge;
	
	@FindBy(id = MAXAGETYPE_ID)
	private WebElement maxAgeType;
	
	@FindBy(id = ISGENDERSPECIFIC_ID)
	private WebElement isGenderSpecific;
	
	@FindBy(id = GENDER_NAME)
	private WebElement gender;

	public boolean checkResCalFirstSection()
			throws InterruptedException {
		boolean flag = false;
		waitForElementId(MBU_ID);
		flag = getCalStDate().isDisplayed();
		flag = getCalToDate().isDisplayed() && flag;
		return flag;
	}

// 	Please enter a valid date/time(eg: 30/01/2014)
	public String calFromDateValid() throws Exception {
		waitForElementId(CALSTDATE_ID);
		return checkTxtLengValidation(calStDate, 3, 1);
	}
	
// 	Please enter a valid date/time(eg: 30/01/2014)
	public String calToDateValid() throws Exception {
		waitForElementId(CALTODATE_ID);
		return checkTxtLengValidation(calToDate, 3, 1);
	}
	
	public boolean fillDatasOfFirstSection(String[] resCalDatas) throws InterruptedException
			  {
		waitForElementId(MBU_ID);
		sleepShort();
		calStDate.clear();
		calStDate.sendKeys(DateTimeConverter.currentISTDateFormat());
		calToDate.clear();
		calToDate.sendKeys(resCalDatas[13].trim());
		selectOrUnSelectCheckBox(resCalDatas[14].trim(), isAgeSpecific);
		if(isAgeSpecific.isSelected())
		{
			minAge.clear();
			minAge.sendKeys(resCalDatas[15].trim());
			minAgeType.clear();
			minAgeType.sendKeys(resCalDatas[16].trim());
		}
		selectOrUnSelectCheckBox(resCalDatas[17].trim(), isGenderSpecific);
		if(isAgeSpecific.isSelected())
		{
			minAge.clear();
			minAge.sendKeys(resCalDatas[18].trim());
			minAgeType.clear();
			minAgeType.sendKeys(resCalDatas[19].trim());
		}
		return isGenderSpecific.isSelected() == Boolean.valueOf(resCalDatas[17].trim());
	}

	/**
	 * @return the calenderCode
	 */
	public WebElement getCalenderCode() {
		return calenderCode;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the speciality
	 */
	public WebElement getSpeciality() {
		return speciality;
	}

	/**
	 * @return the subSpeciality
	 */
	public WebElement getSubSpeciality() {
		return subSpeciality;
	}

	/**
	 * @return the resoName
	 */
	public WebElement getResoName() {
		return resoName;
	}

	/**
	 * @return the resourceCode
	 */
	public WebElement getResourceCode() {
		return resourceCode;
	}

	/**
	 * @return the location
	 */
	public WebElement getLocation() {
		return location;
	}

	/**
	 * @return the calender
	 */
	public WebElement getCalender() {
		return calender;
	}

	/**
	 * @return the calStDate
	 */
	public WebElement getCalStDate() {
		return calStDate;
	}

	/**
	 * @return the calToDate
	 */
	public WebElement getCalToDate() {
		return calToDate;
	}

	/**
	 * @return the isAgeSpecific
	 */
	public WebElement getIsAgeSpecific() {
		return isAgeSpecific;
	}

	/**
	 * @return the minAge
	 */
	public WebElement getMinAge() {
		return minAge;
	}

	/**
	 * @return the minAgeType
	 */
	public WebElement getMinAgeType() {
		return minAgeType;
	}

	/**
	 * @return the maxAge
	 */
	public WebElement getMaxAge() {
		return maxAge;
	}

	/**
	 * @return the maxAgeType
	 */
	public WebElement getMaxAgeType() {
		return maxAgeType;
	}

	/**
	 * @return the isGenderSpecific
	 */
	public WebElement getIsGenderSpecific() {
		return isGenderSpecific;
	}

	/**
	 * @return the gender
	 */
	public WebElement getGender() {
		return gender;
	}

	/**
	 * @return the locName
	 */
	public WebElement getLocName() {
		return locName;
	}
}
