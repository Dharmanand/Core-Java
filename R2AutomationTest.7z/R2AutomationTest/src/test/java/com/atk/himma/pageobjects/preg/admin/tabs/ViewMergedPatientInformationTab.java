package com.atk.himma.pageobjects.preg.admin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ViewMergedPatientInformationTab extends DriverWaitClass{

	public final static String VIEWMERGEPATIENTINFOTAB_XPATH = "//li[@id='viewPatientMergeTag']//span";

	@FindBy(xpath = VIEWMERGEPATIENTINFOTAB_XPATH)
	private WebElement viewMergePatientInfoTab;
	
	private final static String ENTERMERGEDMRN_ID = "mrnoId";
	
	@FindBy(id = ENTERMERGEDMRN_ID)
	private WebElement enterMergedMRN;
	
	private final static String SEARCHBUTTON_ID = "viewPrMrNO";
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	private final static String GRIDTABLE_XPATH = "//table[@class='ui-jqgrid-htable']";
	
	@FindBy(xpath = GRIDTABLE_XPATH)
	private WebElement gridTable;

	private final static String GRIDPAGER_ID= "sp_1_viewMergeMrNo_pager";
	
	@FindBy(id = GRIDPAGER_ID)
	private WebElement gridPager;
	
	private final static String GRIDPAGERNEXT_XPATH= "//td[@id='next_viewMergeMrNo_pager']/span";
	
	@FindBy(xpath = GRIDPAGERNEXT_XPATH)
	private WebElement gridPagerNext;
	
	private final static String VIEWMERGEMRNO_PRIMARYMRNO__ARIADESCRIBEDBY= "viewMergeMrNo_sprimaryMrno";
	private final static String VIEWMERGEMRNO_MRNO__ARIADESCRIBEDBY= "viewMergeMrNo_smrNumber";
	private final static String VIEWMERGEMRNO_PATIENTNAME__ARIADESCRIBEDBY= "viewMergeMrNo_sgivenName";
	private final static String VIEWMERGEMRNO_GENDER__ARIADESCRIBEDBY= "viewMergeMrNo_sgender";
	private final static String VIEWMERGEMRNO_AGE__ARIADESCRIBEDBY= "viewMergeMrNo_formattedAge";
	private final static String VIEWMERGEMRNO_DATEOFBIRTH__ARIADESCRIBEDBY= "viewMergeMrNo_dtdob";
	private final static String VIEWMERGEMRNO_IDENTIFICATIONNO__ARIADESCRIBEDBY= "viewMergeMrNo_sidentityNo";
	
	
	/**
	 * @return the viewmergepatientinfotabXpath
	 */
	public static String getViewmergepatientinfotabXpath() {
		return VIEWMERGEPATIENTINFOTAB_XPATH;
	}

	/**
	 * @return the viewMergePatientInfoTab
	 */
	public WebElement getViewMergePatientInfoTab() {
		return viewMergePatientInfoTab;
	}

	/**
	 * @return the entermergedmrnId
	 */
	public static String getEntermergedmrnId() {
		return ENTERMERGEDMRN_ID;
	}

	/**
	 * @return the enterMergedMRN
	 */
	public WebElement getEnterMergedMRN() {
		return enterMergedMRN;
	}

	/**
	 * @return the searchbuttonId
	 */
	public static String getSearchbuttonId() {
		return SEARCHBUTTON_ID;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the gridtableXpath
	 */
	public static String getGridtableXpath() {
		return GRIDTABLE_XPATH;
	}

	/**
	 * @return the gridTable
	 */
	public WebElement getGridTable() {
		return gridTable;
	}

	/**
	 * @return the viewmergemrnoPrimarymrnoAriadescribedby
	 */
	public static String getViewmergemrnoPrimarymrnoAriadescribedby() {
		return VIEWMERGEMRNO_PRIMARYMRNO__ARIADESCRIBEDBY;
	}

	/**
	 * @return the viewmergemrnoMrnoAriadescribedby
	 */
	public static String getViewmergemrnoMrnoAriadescribedby() {
		return VIEWMERGEMRNO_MRNO__ARIADESCRIBEDBY;
	}

	/**
	 * @return the viewmergemrnoPatientnameAriadescribedby
	 */
	public static String getViewmergemrnoPatientnameAriadescribedby() {
		return VIEWMERGEMRNO_PATIENTNAME__ARIADESCRIBEDBY;
	}

	/**
	 * @return the viewmergemrnoGenderAriadescribedby
	 */
	public static String getViewmergemrnoGenderAriadescribedby() {
		return VIEWMERGEMRNO_GENDER__ARIADESCRIBEDBY;
	}

	/**
	 * @return the viewmergemrnoAgeAriadescribedby
	 */
	public static String getViewmergemrnoAgeAriadescribedby() {
		return VIEWMERGEMRNO_AGE__ARIADESCRIBEDBY;
	}

	/**
	 * @return the viewmergemrnoDateofbirthAriadescribedby
	 */
	public static String getViewmergemrnoDateofbirthAriadescribedby() {
		return VIEWMERGEMRNO_DATEOFBIRTH__ARIADESCRIBEDBY;
	}

	/**
	 * @return the viewmergemrnoIdentificationnoAriadescribedby
	 */
	public static String getViewmergemrnoIdentificationnoAriadescribedby() {
		return VIEWMERGEMRNO_IDENTIFICATIONNO__ARIADESCRIBEDBY;
	}

	/**
	 * @return the gridpagerId
	 */
	public static String getGridpagerId() {
		return GRIDPAGER_ID;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the gridpagernextXpath
	 */
	public static String getGridpagernextXpath() {
		return GRIDPAGERNEXT_XPATH;
	}

	/**
	 * @return the gridPagerNext
	 */
	public WebElement getGridPagerNext() {
		return gridPagerNext;
	}

}
