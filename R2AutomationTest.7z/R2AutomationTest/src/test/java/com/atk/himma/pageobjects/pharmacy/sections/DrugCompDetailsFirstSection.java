package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class DrugCompDetailsFirstSection extends DriverWaitClass{

	public final static String FORM_ID = "DRUG_COMP_DETAILS";
	public final static String SAVEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Save']";
	public final static String UPDATEBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Update']";
	public final static String ADDNEWBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Add New']";
	public final static String COPYBUTTON_CSS = ".buttoncontainer_vlrg_top input[value='Copy']";
	public final static String CANCELBUTTON_ID = "DRUG_COMP_CANCEL_UP";
	public final static String DRUGCOMPCODE_NAME = "drugCompSolDiluent.code";
	public final static String DRUGCOMPSHDESC_ID = "SHORT_DESC";
	public final static String DRUGCOMPDESC_ID = "DESCRIPTION";
	public final static String DEFAULTUOM_ID = "UOM";
	public final static String ROUTE_ID = "ROUTE";
	public final static String ITEMCATEGORY_CSS = "#DRUG_COMP_DETAILS_drugCompSolDiluent_itemCategory + input";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = SAVEBUTTON_CSS)
	private WebElement saveButton;
	
	@FindBy(css = UPDATEBUTTON_CSS)
	private WebElement updateButton;
	
	@FindBy(css = ADDNEWBUTTON_CSS)
	private WebElement addNewButton;
	
	@FindBy(css = COPYBUTTON_CSS)
	private WebElement copyButton;
	
	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	@FindBy(name = DRUGCOMPCODE_NAME)
	private WebElement drugCompCode;

	@FindBy(id = DRUGCOMPSHDESC_ID)
	private WebElement drugCompShortDesc;
	
	@FindBy(id = DRUGCOMPDESC_ID)
	private WebElement drugCompDesc;
	
	@FindBy(id = DEFAULTUOM_ID)
	private WebElement defaultUOM;

	@FindBy(id = ROUTE_ID)
	private WebElement route;

	@FindBy(id = ITEMCATEGORY_CSS)
	private WebElement itemCategory;
	
	public WebElement getForm() {
		return form;
	}

	public WebElement getSaveButton() {
		return saveButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getDrugCompCode() {
		return drugCompCode;
	}

	public WebElement getDrugCompShortDesc() {
		return drugCompShortDesc;
	}

	public WebElement getDefaultUOM() {
		return defaultUOM;
	}

	public WebElement getRoute() {
		return route;
	}

	public WebElement getItemCategory() {
		return itemCategory;
	}
	
	public WebElement getDrugCompDesc() {
		return drugCompDesc;
	}
	
	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	/**
	 * @return the copyButton
	 */
	public WebElement getCopyButton() {
		return copyButton;
	}
}
