package com.atk.himma.pageobjects.sa.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class BaseLoVDetailsTab extends DriverWaitClass {
	public final static String BASELVADDFORM_ID = "baselvform";
	@FindBy(id = BASELVADDFORM_ID)
	private WebElement baseLVAddForm;

	public final static String ADDNEWBASELVBTN_ID = "ADDNEW_BASELV_ID_DET";
	@FindBy(id = ADDNEWBASELVBTN_ID)
	private WebElement addNewBaseLVBtn;

	public final static String SAVEBTN_ID = "SAVE_BASELV_ID";
	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	public final static String UPDATEBTN_ID = "UPDATE_BASELV_ID";
	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	public final static String CANCELBTN_ID = "CANCEL_BASELV_ID";
	@FindBy(id = CANCELBTN_ID)
	private WebElement cancelBtn;

	public final static String MODULENAME_ID = "moduleIdDetails";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String ENTITY_ID = "entityTypeIdDetails";
	@FindBy(id = ENTITY_ID)
	private WebElement entity;

	public final static String LANGUAGE_NAME = "baseLV.langCode";
	@FindBy(name = LANGUAGE_NAME)
	private WebElement language;

	public final static String STATUS_NAME = "baseLV.status";
	@FindBy(name = STATUS_NAME)
	private WebElement status;

	public final static String SHORTNAME_ID = "dispShortDesc";
	@FindBy(id = SHORTNAME_ID)
	private WebElement shortName;

	public final static String LONGNAME_ID = "longDesc";
	@FindBy(id = LONGNAME_ID)
	private WebElement longName;

	public void addBaseLoV(String[] baseLVData) throws Exception {
		waitForElementId(MODULENAME_ID);
		new Select(moduleName).selectByVisibleText(baseLVData[0]);
		waitForElementId(ENTITY_ID);
		sleepVeryShort();
		new Select(entity).selectByVisibleText(baseLVData[1]);
		new Select(language).selectByVisibleText(baseLVData[2]);
		new Select(status).selectByVisibleText(baseLVData[3]);
		shortName.sendKeys(baseLVData[4]);
		longName.sendKeys(baseLVData[5]);
		saveBtn.click();
		sleepShort();
	}

	public void clickAddNewDtls() throws Exception {
		addNewBaseLVBtn.click();
		sleepShort();
	}

	public boolean isMandModuleName() {
		waitForElementId(MODULENAME_ID);
		return isMandatoryField(moduleName);
	}

	public boolean isMandEntity() {
		waitForElementId(ENTITY_ID);
		return isMandatoryField(entity);
	}

	public boolean isMandLanguage() {
		waitForElementName(LANGUAGE_NAME);
		return isMandatoryField(language);
	}

	public boolean isMandStatus() {
		waitForElementName(STATUS_NAME);
		return isMandatoryField(status);
	}

	public boolean isMandShortName() {
		waitForElementId(SHORTNAME_ID);
		return isMandatoryField(shortName);
	}

	public boolean isMandLongName() {
		waitForElementId(LONGNAME_ID);
		return isMandatoryField(longName);
	}

	public WebElement getBaseLVAddForm() {
		return baseLVAddForm;
	}

	public WebElement getAddNewBaseLVBtn() {
		return addNewBaseLVBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getEntity() {
		return entity;
	}

	public WebElement getLanguage() {
		return language;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getShortName() {
		return shortName;
	}

	public WebElement getLongName() {
		return longName;
	}

}
