package com.atk.himma.pageobjects.mbuadmin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PackageListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "packagesSearch";
	public final static String PACKAGELISTTAB_XPATH = "//a[@title='Package List']";
	public final static String MBUNAME_ID = "PACKAGES_MBU_ID_SEARCH";
	public final static String DEPARTMENT_ID = "PACKAGES_DEPARTMENT";
	public final static String PACKAGESTYPE_ID = "PACKAGES_TYPE";
	public final static String PACKAGESDELIVERY_ID = "PACKAGES_DELIVERY";
	public final static String PACKAGESNAME_ID = "PACKAGES_NAME";
	public final static String SEARCHGLOBALPKG_ID = "SEARCH_GLOBAL_PKG";
	public final static String SPECIALITY_ID = "PACKAGES_SPECIALITY";
	public final static String PACKAGECODE_ID = "PACKAGES_CODE";
	public final static String PKGSTATUS_ID = "PKG_STATUS";
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@value='Reset']";
	public final static String GRID_ID = "SEARCH_PACKAGE_LIST";
	public final static String GRID_PKGCODE_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.serviceCode";
	public final static String GRID_PKGNAME_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.serviceName";
	public final static String GRID_PKGCATEGORY_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.specialtyText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.departmentText";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.mbuText";
	public final static String GRID_PKGTYPE_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_pkgTypeText";
	public final static String GRID_PKGDELEVERY_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.additionalParameters.visitCategoryText";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "SEARCH_PACKAGE_LIST_serviceInfo.recordStatus.mainStatusText";
	public final static String GRID_PAGERID = "sp_1_SEARCH_PACKAGE_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_PACKAGE_LIST_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = PACKAGELISTTAB_XPATH)
	private WebElement packageListTab;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = PACKAGESTYPE_ID)
	private WebElement packageType;
	
	@FindBy(id = PACKAGESDELIVERY_ID)
	private WebElement packageDelivery;
	
	@FindBy(id = PACKAGESNAME_ID)
	private WebElement packageName;
	
	@FindBy(id = SEARCHGLOBALPKG_ID)
	private WebElement searchGlobalPkg;
	
	@FindBy(id = SPECIALITY_ID)
	private WebElement speciality;
	
	@FindBy(id = PACKAGECODE_ID)
	private WebElement packageCode;
	
	@FindBy(id = PKGSTATUS_ID)
	private WebElement packageStatus;

	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the packageListTab
	 */
	public WebElement getPackageListTab() {
		return packageListTab;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the packageType
	 */
	public WebElement getPackageType() {
		return packageType;
	}

	/**
	 * @return the packageDelivery
	 */
	public WebElement getPackageDelivery() {
		return packageDelivery;
	}

	/**
	 * @return the packageName
	 */
	public WebElement getPackageName() {
		return packageName;
	}

	/**
	 * @return the searchGlobalPkg
	 */
	public WebElement getSearchGlobalPkg() {
		return searchGlobalPkg;
	}

	/**
	 * @return the speciality
	 */
	public WebElement getSpeciality() {
		return speciality;
	}

	/**
	 * @return the packageCode
	 */
	public WebElement getPackageCode() {
		return packageCode;
	}

	/**
	 * @return the packageStatus
	 */
	public WebElement getPackageStatus() {
		return packageStatus;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

}
