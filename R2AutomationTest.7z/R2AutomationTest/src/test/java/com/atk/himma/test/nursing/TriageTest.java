package com.atk.himma.test.nursing;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.desktop.DesktopDataPage;
import com.atk.himma.pageobjects.nursing.TriagePage;
import com.atk.himma.pageobjects.nursing.sections.TriageSection;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class TriageTest extends SeleniumDriverSetup {

	LoginPage loginPage;
	DesktopDataPage desktopDataPage;
	TriagePage triagePage;
	List<String[]> outPatientList;

	@Test(description = "Open Nursing Desktop Page")
	public void openNursingDesktopPage() throws Exception {
		desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage = desktopDataPage.clickOnNursingDesktopMenu(webDriver,
				webDriverWait);
		desktopDataPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("NursingDesktopExcel"));
		Assert.assertNotNull(desktopDataPage);
		desktopDataPage.waitForElementVisibilityOf(desktopDataPage.getMbu());
		Assert.assertTrue(desktopDataPage.getMbu().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Search From Date Field", dependsOnMethods = { "openNursingDesktopPage" })
	public void validateFromDateMandatoryField() throws Exception {
		Assert.assertTrue(desktopDataPage.isMandFromDate());
	}

	@Test(description = "Fill Search Criteria Fields", dependsOnMethods = { "openNursingDesktopPage" })
	public void fillSearchCriteriaData() throws Exception {
		outPatientList = excelReader.read(properties
				.getProperty("nursingDesktop"));
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.fillSearchCriteria(outPatientListData);
			}
		}
	}

	@Test(description = "Search OutPatient(s) By Physician Filter Criteria", dependsOnMethods = { "openNursingDesktopPage" })
	public void searchOutPatientsByPhysician() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage
						.searchOutPatientsByPhysician(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"nursingDeskGridList", outPatientListData[12]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Patient Filter Criteria", dependsOnMethods = { "openNursingDesktopPage" })
	public void searchOutPatientsByPatient() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByPatient(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"nursingDeskGridList", outPatientListData[15]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Service Filter Criteria", dependsOnMethods = { "openNursingDesktopPage" })
	public void searchOutPatientsByService() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByService(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"nursingDeskGridList", outPatientListData[22]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Location Filter Criteria", dependsOnMethods = { "openNursingDesktopPage" })
	public void searchOutPatientsByLocation() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByLocation(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"nursingDeskGridList", outPatientListData[6]));
			}
		}

	}

	@Test(description = "Quick Search OutPatient(s) By Location", dependsOnMethods = { "openNursingDesktopPage" })
	public void quickSearchByLocation() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.quickSearchByLoc(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"nursingDeskGridList", outPatientListData[6]));
			}
		}

	}

	@Test(description = "Add Triage Parameters", dependsOnMethods = { "quickSearchByLocation" })
	public void addTriageData() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			triagePage = PageFactory.initElements(webDriver, TriagePage.class);
			triagePage.initPages(webDriver, webDriverWait);
			triagePage.setWebDriver(webDriver);
			triagePage.setWebDriverWait(webDriverWait);
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.clickOnTriageLink(outPatientListData);
				triagePage.getTriageSection().addTriageData(outPatientListData);
				Assert.assertTrue(triagePage.getTriageSection()
						.checkVitalSignsGridData(outPatientListData));
			}
		}
	}

	@Test(description = "Save Triage Data", dependsOnMethods = { "addTriageData" })
	public void saveTriageInformation() throws Exception {
		Assert.assertEquals(triagePage.saveTriageInfo(),
				"Triage Values Saved Successfully...");

	}

	@Test(description = "Remove Triage Data", dependsOnMethods = { "saveTriageInformation" })
	public void removeTriageInformation() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			Assert.assertFalse(triagePage.removeTriageInfo(outPatientListData));
		}
	}

	@Test(description = "Add New Triage Data", dependsOnMethods = { "saveTriageInformation" })
	public void addNewTriageInformation() throws Exception {
		for (String[] outPatientListData : outPatientList) {
			triagePage.getTriageSection().addTriageData(outPatientListData);
			Assert.assertTrue(triagePage.getTriageSection()
					.checkVitalSignsGridData(outPatientListData));
			Assert.assertEquals(triagePage.saveNewTriageInfo(),
					"Triage Values Saved Successfully...");

		}
	}

	@Test(description = "Sign Out", dependsOnMethods = "saveTriageInformation")
	public void signOut() throws Exception {
		loginPage = triagePage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "signOut")
	public void login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(7,
				excelReader.read(properties.getProperty("loginSheetName"))),
				"User Home", "Failed Login");
	}

	// [Nursing Desktop] Open Form
	@Test(description = "Check Nursing Desktop Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckNursingDesktopPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("NursingDesktopExcel"));
		desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> nursingParentMenuList = new LinkedList<String>();
		nursingParentMenuList.add("Nursing");
		menuSelector.mouseOverOnTargetMenu(nursingParentMenuList,
				"Nursing Desktop");
		desktopDataPage.setWebDriver(webDriver);
		desktopDataPage.setWebDriverWait(webDriverWait);
		desktopDataPage
				.waitForElementXpathExpression(DesktopDataPage.NURMENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Nursing").get("Nursing Desktop")
				.get("[Nursing Desktop] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DesktopDataPage.NURMENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Nursing Desktop] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			desktopDataPage = desktopDataPage.clickOnNursingDesktopMenu(
					webDriver, webDriverWait);
			desktopDataPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(desktopDataPage);
			desktopDataPage.waitForElementVisibilityOf(desktopDataPage
					.getOpdForm());
			desktopDataPage.sleepShort();
			Assert.assertEquals(desktopDataPage.getPageTitle().getText(),
					"Nursing Desktop");
		}

	}

	// [Nursing Desktop] Triage

	// [Triage][Section:Triage] Add Triage (Button)
	@Test(description = "Check Triage Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckNursingDesktopPageMenuLink")
	public void test02CheckTriageLink() throws Exception {
		outPatientList = excelReader.read(properties
				.getProperty("nursingDesktop"));
		for (String[] outPatientListData : outPatientList) {
			desktopDataPage.quickSearchByLoc(outPatientListData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Nursing").get("Nursing Desktop")
				.get("[Triage][Section:Triage] Add Triage (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DesktopDataPage.TRIAGELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Triage][Section:Triage] Add Triage (Button) privilege");
		if (actualPrivilage)
			desktopDataPage.clickOnTriageLink(outPatientList.get(0));
	}

	// [Triage][Section:Triage] Edit Triage (Link)
	@Test(description = "Check Edit Triage Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test02CheckTriageLink")
	public void test03CheckEditTriageLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Nursing").get("Triage")
				.get("[Triage][Section:Triage] Edit Triage (Link)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(TriageSection.EDITTRIAGELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Triage][Section:Triage] Edit Triage (Link) privilege");
	}

	// [Triage][Section:Triage] Delete Triage (Link)
	@Test(description = "Check Delete Triage Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test02CheckTriageLink")
	public void test04CheckDelTriageLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Nursing").get("Triage")
				.get("[Triage][Section:Triage] Delete Triage (Link)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(TriageSection.REMOVETRIAGELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Triage][Section:Triage] Delete Triage (Link) privilege");
	}

}
