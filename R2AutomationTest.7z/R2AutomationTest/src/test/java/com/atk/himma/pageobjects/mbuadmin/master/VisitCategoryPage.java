/**
 * @author kumar
 */
package com.atk.himma.pageobjects.mbuadmin.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.master.tabs.VisitCategoryDetailsTab;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.VisitCategoryMBUListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class VisitCategoryPage extends DriverWaitClass implements
		StatusMessages {

	private VisitCategoryMBUListTab mbuListTab;
	private VisitCategoryDetailsTab visitCategoryDetailsTab;

	public final static String PAGETITLE_ID = "PAGE_TITLE";

	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Visit Category')]";
	
	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		mbuListTab = PageFactory.initElements(webDriver,
				VisitCategoryMBUListTab.class);
		mbuListTab.setWebDriver(webDriver);
		mbuListTab.setWebDriverWait(webDriverWait);

		visitCategoryDetailsTab = PageFactory.initElements(webDriver,
				VisitCategoryDetailsTab.class);
		visitCategoryDetailsTab.setWebDriver(webDriver);
		visitCategoryDetailsTab.setWebDriverWait(webDriverWait);
	}

	public VisitCategoryPage clickOnVisitCategoryMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Visit Category");
		VisitCategoryPage visitCategoryPage = PageFactory.initElements(
				webDriver, VisitCategoryPage.class);
		visitCategoryPage.setWebDriver(webDriver);
		visitCategoryPage.setWebDriverWait(webDriverWait);
		return visitCategoryPage;
	}

	public String searchVisitCategory(String[] visitCategoryData)
			throws InterruptedException {
		waitForElementId(VisitCategoryMBUListTab.FORM_ID);
		waitForElementId(VisitCategoryMBUListTab.GRID_ID);
		mbuListTab.getMbuName().clear();
		mbuListTab.getMbuName().sendKeys(visitCategoryData[0]);
		mbuListTab.getSearchButton().click();
		waitForElementId(VisitCategoryMBUListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(VisitCategoryMBUListTab.GRID_ID,
				VisitCategoryMBUListTab.GRID_MBUName_ARIA_DESCRIBEDBY,
				visitCategoryData[0].trim());
	}

	public String clickOnEditLink(String[] visitCategoryData)
			throws InterruptedException {
		sleepShort();
		clickOnGridAction(visitCategoryData[0].trim(), "Edit");
		waitForElementId(VisitCategoryDetailsTab.GRID_ID);
		waitForElementXpathExpression(VisitCategoryDetailsTab.SAVEBUTTON_XPATH);
		return visitCategoryDetailsTab.getMbuName().getAttribute("value")
				.trim();
	}

	public String clickOnAddRecordGridButton() throws InterruptedException {
		waitForElementId(VisitCategoryDetailsTab.GRID_ID);
		sleepShort();
		visitCategoryDetailsTab.getAddRecordGridButton().click();
		waitForElementId(VisitCategoryDetailsTab.POPUPTITLE_ID);
		return visitCategoryDetailsTab.getPopUpTitle().getText().trim();
	}

	public String saveVisitCategory(String[] visitCategoryData) {
		waitForElementId(VisitCategoryDetailsTab.POPUPTITLE_ID);
		new Select(visitCategoryDetailsTab.getVisitCategoryName())
				.selectByVisibleText(visitCategoryData[1].trim());
		String[] str = visitCategoryData[2].split("\\,");
		for (int i = 0; i < str.length; i++)
			visitCategoryDetailsTab.clickOnVisitType(str[i]);
		str = visitCategoryData[3].split("\\,");
		for (int i = 0; i < str.length; i++)
			visitCategoryDetailsTab.clickOnApplicableBillingClass(str[i]);
		visitCategoryDetailsTab.getAddButtonPopUp().click();
		waitForGridSearchText(visitCategoryData[1].trim());
		visitCategoryDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		return statusMessage.getText().trim();
	}

	public String activateVisitCategory(String[] visitCategoryData) {
		waitForElementId(VisitCategoryDetailsTab.GRID_ID);
		WebElement link = webDriver.findElements(
				By.xpath(".//td[@title='" + visitCategoryData[1].trim()
						+ "']/..//a")).get(1);
		if (link.getText().trim().equals("Activate"))
			link.click();
		waitForElementXpathExpression(".//td[@title='"
				+ visitCategoryData[1].trim()
				+ "']/..//a[contains(text(), 'Deactivate')]");
		return webDriver
				.findElements(
						By.xpath(".//td[@title='"
								+ visitCategoryData[1].trim().trim()
								+ "']/..//a")).get(1).getText().trim();
	}

	public String deActivateVisitCategory(String[] visitCategoryData) {
		waitForElementId(VisitCategoryDetailsTab.GRID_ID);
		WebElement link = webDriver.findElements(
				By.xpath(".//td[@title='" + visitCategoryData[1].trim().trim()
						+ "']/..//a")).get(1);
		if (link.getText().trim().equals("Deactivate"))
			link.click();
		waitForElementXpathExpression(".//td[@title='"
				+ visitCategoryData[1].trim().trim()
				+ "']/..//a[contains(text(), 'Activate')]");
		return webDriver
				.findElements(
						By.xpath(".//td[@title='"
								+ visitCategoryData[1].trim().trim()
								+ "']/..//a")).get(1).getText().trim();
	}

	public String editVisitCategory(String[] visitCategoryData)
			throws InterruptedException {
		waitForElementId(VisitCategoryDetailsTab.GRID_ID);
		webDriver.findElement(
				By.xpath(".//td[@title='" + visitCategoryData[1].trim().trim()
						+ "']/..//a[@title='Edit']")).click();
		sleepShort();
		new Select(visitCategoryDetailsTab.getVisitCategoryName())
				.selectByVisibleText(visitCategoryData[1].trim());
		String[] str = visitCategoryData[2].split("\\,");
		for (int i = 0; i < str.length; i++)
			visitCategoryDetailsTab.clickOnVisitType(str[i]);
		str = visitCategoryData[3].split("\\,");
		for (int i = 0; i < str.length; i++)
			visitCategoryDetailsTab.clickOnApplicableBillingClass(str[i]);
		visitCategoryDetailsTab.getUpdateButtonPopUp().click();
		waitForGridSearchText(visitCategoryData[1].trim());
		visitCategoryDetailsTab.getSaveButton().click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		sleepShort();
		return visitCategoryDetailsTab.getSaveButton().getAttribute("value")
				.trim();
	}

	public String cancelVisitCategory(String[] visitCategoryData) {
		waitForElementId(VisitCategoryDetailsTab.GRID_ID);
		visitCategoryDetailsTab.getCanceButton().click();
		waitForElementId(VisitCategoryMBUListTab.GRID_ID);
		return waitAndGetGridFirstCellText(VisitCategoryMBUListTab.GRID_ID,
				VisitCategoryMBUListTab.GRID_MBUName_ARIA_DESCRIBEDBY,
				visitCategoryData[0].trim()).trim();
	}

	/**
	 * @return the mbuListTab
	 */
	public VisitCategoryMBUListTab getmbuListTab() {
		return mbuListTab;
	}

	/**
	 * @return the visitCategoryDetailsTab
	 */
	public VisitCategoryDetailsTab getVisitCategoryDetailsTab() {
		return visitCategoryDetailsTab;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the statusMessageSave
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
