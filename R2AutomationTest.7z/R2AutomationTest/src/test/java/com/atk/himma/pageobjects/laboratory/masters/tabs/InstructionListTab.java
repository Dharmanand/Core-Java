package com.atk.himma.pageobjects.laboratory.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class InstructionListTab extends DriverWaitClass {
	public final static String ADDNEWINSTRBTN_ID = "addNew";
	@FindBy(id = ADDNEWINSTRBTN_ID)
	private WebElement addNewInstrBtn;

	public final static String INSTRSEARCHTXT_ID = "instrSearchField";
	@FindBy(id = INSTRSEARCHTXT_ID)
	private WebElement instrSearchTxt;

	public final static String INSTRSEARCHBTN_ID = "instrSearchBtn";
	@FindBy(id = INSTRSEARCHBTN_ID)
	private WebElement instrsearchBtn;

	public final static String INSTRADVSEARCHBTN_ID = "INSTR_ADV_SEARCH";
	@FindBy(id = INSTRADVSEARCHBTN_ID)
	private WebElement instrAdvSearchBtn;

	public final static String INSTRADVSEARCHDIV_ID = "INSTR_ADV_SEARCH_DIV";
	@FindBy(id = INSTRADVSEARCHDIV_ID)
	private WebElement instrAdvSearchDiv;

	public final static String INSTRSHNAME_NAME = "searchCriteria.instrShortName";
	@FindBy(name = INSTRSHNAME_NAME)
	private WebElement instrShName;

	public final static String INSTRTYPE_NAME = "searchCriteria.instrType";
	@FindBy(name = INSTRTYPE_NAME)
	private WebElement instrType;

	public final static String STATUS_NAME = "searchCriteria.mainStatus";
	@FindBy(name = STATUS_NAME)
	private WebElement status;

	public final static String INSTRDESC_NAME = "searchCriteria.instrDesc";
	@FindBy(name = INSTRDESC_NAME)
	private WebElement instrDesc;

	public final static String ADVSEARCHBTN_ID = "advSearch";
	@FindBy(id = ADVSEARCHBTN_ID)
	private WebElement advSearchBtn;

	public final static String ADVRESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = ADVRESETBTN_XPATH)
	private WebElement advResetBtn;

	public final static String INSTREXPTOEXCELBTN_ID = "instrucionlist_grid_export_btn";
	@FindBy(id = INSTREXPTOEXCELBTN_ID)
	private WebElement instrExpToExcelBtn;

	public final static String INSTRLISTTBL_ID = "instrucionlist_grid";
	@FindBy(id = INSTRLISTTBL_ID)
	private WebElement instrListTbl;

	public WebElement getAddNewInstrBtn() {
		return addNewInstrBtn;
	}

	public WebElement getInstrSearchTxt() {
		return instrSearchTxt;
	}

	public WebElement getInstrsearchBtn() {
		return instrsearchBtn;
	}

	public WebElement getInstrAdvSearchBtn() {
		return instrAdvSearchBtn;
	}

	public WebElement getInstrAdvSearchDiv() {
		return instrAdvSearchDiv;
	}

	public WebElement getInstrShName() {
		return instrShName;
	}

	public WebElement getInstrType() {
		return instrType;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getInstrDesc() {
		return instrDesc;
	}

	public WebElement getAdvSearchBtn() {
		return advSearchBtn;
	}

	public WebElement getAdvResetBtn() {
		return advResetBtn;
	}

	public WebElement getInstrExpToExcelBtn() {
		return instrExpToExcelBtn;
	}

	public WebElement getInstrListTbl() {
		return instrListTbl;
	}

}
