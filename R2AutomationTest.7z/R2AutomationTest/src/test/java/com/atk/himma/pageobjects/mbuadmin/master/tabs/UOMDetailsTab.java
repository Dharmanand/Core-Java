package com.atk.himma.pageobjects.mbuadmin.master.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class UOMDetailsTab extends DriverWaitClass {

	public final static String FORM_ID = "UOM_DETAILS_FORM";
	public final static String UOMDETAILSTAB_XPATH = "//a[@title='Unit Of measurement Details']";
	public final static String ADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String UOMCODE_NAME = "uomDetail.uomCode";
	public final static String UOMNAME_NAME = "uomDetail.uomName";
	public final static String UOMNAMEAR_NAME = "uomDetail.uomNameAR";
	public final static String MAINSTATUSTEXT_ID = "MAIN_STATUS_TEXT";
	public final static String MAINSTATUS_ID = "UPDATE_MAIN_STATUS";
	public final static String GRID_ID = "UOM_CONVERSION";
	public final static String GRIDADDBUTTON_XPATH = "//div[@class='ui-pg-div']//span[@class='ui-icon ui-icon-plus']";
	public final static String GRIDPOPUPFORM_ID = "UOM_CONVERSION_POPUP";
	public final static String GRIDUOMNAMEPOPUP_ID = "UOM_NAME_POPUP";
	public final static String GRIDUOMCODEPOPUP_ID = "UOM_CODE_POPUP";
	public final static String GRIDCONVFACTPOPUP_ID = "CONVERSION_FACTOR_POPUP";
	public final static String GRIDSUBMITBUTPOPUP_ID = "SUBMIT_BUTTON";
	public final static String GRIDCANCELBUTPOPUP_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='buttoncontainer_mid']";
	public final static String GRID_UOMCODE_ARIA_DESCRIBEDBY = "SEARCH_UOM_LIST_uomCode";
	public final static String GRID_UOMNAME_ARIA_DESCRIBEDBY = "SEARCH_UOM_LIST_uomName";
	public final static String GRID_MAINSTATUSTEXT_ARIA_DESCRIBEDBY = "SEARCH_UOM_LIST_recordStatus.mainStatusText";
	public final static String GRID_PAGER_ID = "sp_1_SEARCH_UOM_LIST_pager";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = UOMDETAILSTAB_XPATH)
	private WebElement uomDetailsTab;

	@FindBy(xpath = ADDNEWBUTTON_XPATH)
	private WebElement addNewButton;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(name = UOMCODE_NAME)
	private WebElement uomCode;

	@FindBy(name = UOMNAME_NAME)
	private WebElement uomName;

	@FindBy(name = UOMNAMEAR_NAME)
	private WebElement uomNameAr;

	@FindBy(id = MAINSTATUSTEXT_ID)
	private WebElement mainStatusText;

	@FindBy(id = MAINSTATUS_ID)
	private WebElement mainStatus;

	@FindBy(id = GRID_ID)
	private WebElement grid;

	@FindBy(xpath = GRIDADDBUTTON_XPATH)
	private WebElement gridAddButton;

	@FindBy(id = GRIDPOPUPFORM_ID)
	private WebElement gridPopUpForm;

	@FindBy(id = GRIDUOMNAMEPOPUP_ID)
	private WebElement gridPopUpUomName;

	@FindBy(id = GRIDUOMCODEPOPUP_ID)
	private WebElement gridPopUpUomCode;

	@FindBy(id = GRIDCONVFACTPOPUP_ID)
	private WebElement gridPopUpConvertFactor;

	@FindBy(id = GRIDSUBMITBUTPOPUP_ID)
	private WebElement gridPopUpSubmitButton;

	@FindBy(xpath = GRIDCANCELBUTPOPUP_XPATH)
	private WebElement gridPopUpCancelButton;
	
	@FindBy(id = GRID_PAGER_ID)
	private WebElement gridPager;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the uomDetailsTab
	 */
	public WebElement getUomDetailsTab() {
		return uomDetailsTab;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the uomCode
	 */
	public WebElement getUomCode() {
		return uomCode;
	}

	/**
	 * @return the uomName
	 */
	public WebElement getUomName() {
		return uomName;
	}

	/**
	 * @return the uomNameAr
	 */
	public WebElement getUomNameAr() {
		return uomNameAr;
	}

	/**
	 * @return the mainStatusText
	 */
	public WebElement getMainStatusText() {
		return mainStatusText;
	}

	/**
	 * @return the mainStatus
	 */
	public WebElement getMainStatus() {
		return mainStatus;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the gridAddButton
	 */
	public WebElement getGridAddButton() {
		return gridAddButton;
	}

	/**
	 * @return the gridPopUpForm
	 */
	public WebElement getGridPopUpForm() {
		return gridPopUpForm;
	}

	/**
	 * @return the gridPopUpUomName
	 */
	public WebElement getGridPopUpUomName() {
		return gridPopUpUomName;
	}

	/**
	 * @return the gridPopUpUomCode
	 */
	public WebElement getGridPopUpUomCode() {
		return gridPopUpUomCode;
	}

	/**
	 * @return the gridPopUpConvertFactor
	 */
	public WebElement getGridPopUpConvertFactor() {
		return gridPopUpConvertFactor;
	}

	/**
	 * @return the gridPopUpSubmitButton
	 */
	public WebElement getGridPopUpSubmitButton() {
		return gridPopUpSubmitButton;
	}

	/**
	 * @return the gridPopUpCancelButton
	 */
	public WebElement getGridPopUpCancelButton() {
		return gridPopUpCancelButton;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

}
