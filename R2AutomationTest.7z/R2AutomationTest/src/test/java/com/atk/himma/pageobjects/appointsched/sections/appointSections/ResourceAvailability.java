package com.atk.himma.pageobjects.appointsched.sections.appointSections;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ResourceAvailability extends DriverWaitClass implements
		StatusMessages, TopControls {
	
	public final static String SEARCHBYPHYSICIAN_ID = "physicianSearchPage";
	public final static String SEARCHBYCLINIC_ID = "clinicSearchPage";
	public final static String QUICKFINDTXT_ID = "quickFindTxt";
	public final static String QUICKSEARCHBUTTON_XPATH = "//form[@id='searchPhysicianForm1']//input[@type='submit' and @value='Search']";
	public final static String SEARCHRESOURCE_ID = "SEARCH_RESOURCE";
	public final static String RESET_XPATH = "//span[@class='buttoncontainer_lrg_gb']//input[@type='submit' and @value='Reset']";

	public final static String GRID_ID = "recourceAvailableGrid";

	@FindBy(id = PAGETITLE_ID)
	protected WebElement pageTitle;

	@FindBy(id = GRID_ID)
	protected WebElement grid;

	@FindBy(id = SEARCHBYPHYSICIAN_ID)
	protected WebElement searchByPhysRadioBox;

	@FindBy(id = SEARCHBYCLINIC_ID)
	protected WebElement searchByClinicRadioBox;

	@FindBy(id = QUICKFINDTXT_ID)
	protected WebElement quickFindTxt;

	@FindBy(id = SEARCHRESOURCE_ID)
	protected WebElement searchResourceButton;

	@FindBy(xpath = QUICKSEARCHBUTTON_XPATH)
	protected WebElement quickSearchButton;

	@FindBy(xpath = RESET_XPATH)
	protected WebElement resetButton;

	public boolean quickSearchPhysician(String resourceName)
			throws InterruptedException {
		waitForElementId(QUICKFINDTXT_ID);
		quickFindTxt.clear();
		quickFindTxt.sendKeys(resourceName.trim());
		quickSearchButton.click();
		waitForElementId(GRID_ID);
		sleepShort();
		String elementXpath = "//span[@class='ui-icon ui-icon-circlesmall-minus tree-wrap-ltr']/..[contains(text(),'"
				+ resourceName.trim() + "')]";
		try {
			waitForElementXpathExpression(elementXpath);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	protected int dateColumnCount(String date) {
		List<WebElement> sessionDates = webDriver
				.findElements(By
						.xpath("//th[@class='ui-state-default ui-th-column-header ui-th-ltr' and @role='columnheader']"));
		int i = 0;
		for (WebElement we : sessionDates) {
			i++;
			if (we.getText().contains(date.trim())) {
				break;
			}
		}
		return (4 + i * 3);
	}

	protected AppointmentDairy clickAvailDateResSession(String elementXpath)
			throws InterruptedException {
		waitForElementId(GRID_ID);
		sleepShort();
		try {
			waitForElementXpathExpression(elementXpath);
			sleepVeryShort();
			webDriver.findElement(By.xpath(elementXpath)).click();
			sleepVeryShort();
			waitForElementXpathExpression(AppointmentDairy.BACKTOAPPOINTBUTTON_XPATH);
			AppointmentDairy appointmentDairy = PageFactory.initElements(
					webDriver, AppointmentDairy.class);
			appointmentDairy.setWebDriver(webDriver);
			appointmentDairy.setWebDriverWait(webDriverWait);
			return appointmentDairy;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @return the searchByPhysRadioBox
	 */
	public WebElement getSearchByPhysRadioBox() {
		return searchByPhysRadioBox;
	}

	/**
	 * @return the quickFindTxt
	 */
	public WebElement getQuickFindTxt() {
		return quickFindTxt;
	}

	/**
	 * @return the searchResourceButton
	 */
	public WebElement getSearchResourceButton() {
		return searchResourceButton;
	}

	/**
	 * @return the quickSearchButton
	 */
	public WebElement getQuickSearchButton() {
		return quickSearchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the grid
	 */
	public WebElement getGrid() {
		return grid;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the searchByClinicRadioBox
	 */
	public WebElement getSearchByClinicRadioBox() {
		return searchByClinicRadioBox;
	}
}
