package com.atk.himma.pageobjects.preg.regsections;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class PersonalDetailsSection extends DriverWaitClass{

	public final static String SECTIONNAME_LINKTEXT = "Personal Details";
	
	@FindBy(linkText=SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	private final static String BIRTHCOUNTRY_NAME = "persDetails.birthCountry";
	
	@FindBy(name=BIRTHCOUNTRY_NAME)
	private WebElement birthCountry;
	
	private final static String MARTIALSTATUS_NAME = "persDetails.maritalStatus";
	
	@FindBy(name=MARTIALSTATUS_NAME)
	private WebElement martialStatus;
	
	private final static String MOBILECODE_ID = "smob";
	
	@FindBy(id=MOBILECODE_ID)
	private WebElement mobileCode;
	
	private final static String MOBILENUMBER_ID = "smobpNo";
	
	@FindBy(id=MOBILENUMBER_ID)
	private WebElement mobileNumber;
	
	private final static String BIRTHPLACE_ID = "birthPlace";
	
	@FindBy(id=BIRTHPLACE_ID)
	private WebElement birthPlace;
	
	private final static String LANGUAGE_ID = "patientLanguage";
	
	@FindBy(id=LANGUAGE_ID)
	private WebElement language;
	
	private final static String HOMEPHONECODE_ID = "shomePh";
	
	@FindBy(id=HOMEPHONECODE_ID)
	private WebElement homePhoneCode;
	
	private final static String HOMEPHONENUMBER_ID = "shmNo";
	
	@FindBy(id=HOMEPHONENUMBER_ID)
	private WebElement homePhoneNumber;
	
	private final static String RACE_NAME = "persDetails.race";
	
	@FindBy(name=RACE_NAME)
	private WebElement race;
	
	private final static String RELIGION_ID = "patientReligion";
	
	@FindBy(id=RELIGION_ID)
	private WebElement religion;
	
	private final static String OCCUPATION_NAME = "persDetails.occupation";
	
	@FindBy(name=OCCUPATION_NAME)
	private WebElement occupation;
	
	private final static String EDUCATION_NAME = "persDetails.education";
	
	@FindBy(name=EDUCATION_NAME)
	private WebElement education;
	
	private final static String ORIGIN_ID = "patientOrigin";
	
	@FindBy(id=ORIGIN_ID)
	private WebElement origin;
	
	private final static String BLOODGROUP_NAME = "persDetails.bloodGroup";
	
	@FindBy(name=BLOODGROUP_NAME)
	private WebElement bloodGroup;
	
	private final static String HANDICAP_ID = "Handicap";
	
	@FindBy(id=HANDICAP_ID)
	private WebElement handicap;
	
	private final static String ALLERGIC_ID = "Allergic";
	
	@FindBy(id=ALLERGIC_ID)
	private WebElement allergic ;
	
	private final static String translatorRequired_ID = "Translator Required";
	
	@FindBy(id=translatorRequired_ID)
	private WebElement translatorRequired ;
	
	private final static String ISBLOODGROUPVALIDATED_ID = "Is blood group validated?";
	
	@FindBy(id=ISBLOODGROUPVALIDATED_ID)
	private WebElement isBloodGroupValidated ;
	
	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Personal Details')]/..";
	
	@FindBy(xpath=SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	public void fillDatasOfPersonalDetailsSection(String[] excelData, WebDriverWait webDriverWait) throws InterruptedException
	{
//		getSectionName().click();
//		sleepVeryShort();
		if(!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute("class").trim()))
		getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getBirthCountry()));
		new Select(getBirthCountry()).selectByVisibleText(excelData[43].trim());
		getBirthPlace().clear();
		getBirthPlace().sendKeys(excelData[44].trim());
		new Select(getMartialStatus()).selectByVisibleText(excelData[45].trim());
		new Select(getLanguage()).selectByVisibleText(excelData[46].trim());
		new Select(getMobileCode()).selectByVisibleText(excelData[47].trim());
		new Select(getHomePhoneCode()).selectByVisibleText(excelData[48].trim());
		getMobileNumber().clear();
		getMobileNumber().sendKeys(excelData[49].trim());
		getHomePhoneNumber().clear();
		getHomePhoneNumber().sendKeys(excelData[50].trim());
		new Select(getRace()).selectByVisibleText(excelData[51].trim());
		new Select(getEducation()).selectByVisibleText(excelData[52].trim());
		new Select(getReligion()).selectByVisibleText(excelData[53].trim());
		new Select(getOrigin()).selectByVisibleText(excelData[54].trim());
		new Select(getOccupation()).selectByVisibleText(excelData[55].trim());
		new Select(getBloodGroup()).selectByVisibleText(excelData[56].trim());
		if (Boolean.getBoolean(excelData[57].trim())) {
			getHandicap().click();
		}
		if (Boolean.getBoolean(excelData[58].trim())) {
			getAllergic().click();
		}
		if (Boolean.getBoolean(excelData[59].trim())) {
			getTranslatorRequired().click();
		}
		if (Boolean.getBoolean(excelData[60].trim())) {
			getBloodGroup().click();
		}
	}
	
	public boolean compareBaseLovData(Map<String, List<String>> masterDatas) 
	{
		if(!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute("class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getBirthCountry()));
		boolean flag = true;
		 List<WebElement> race = new Select(this.race).getOptions();
		 List<String> longNames = masterDatas.get("Race");
		 for(WebElement we : race)
		 {
			 String str = we.getText().trim();
			if(longNames.contains(str) || str.equals("Select"))
				flag = flag && true;
			else
				flag = false;
		 }
		 return flag;
	}
	
	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the birthCountry
	 */
	public WebElement getBirthCountry() {
		return birthCountry;
	}

	/**
	 * @return the martialStatus
	 */
	public WebElement getMartialStatus() {
		return martialStatus;
	}

	/**
	 * @return the mobileCode
	 */
	public WebElement getMobileCode() {
		return mobileCode;
	}

	/**
	 * @return the mobileNumber
	 */
	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the birthPlace
	 */
	public WebElement getBirthPlace() {
		return birthPlace;
	}

	/**
	 * @return the language
	 */
	public WebElement getLanguage() {
		return language;
	}

	/**
	 * @return the homePhoneCode
	 */
	public WebElement getHomePhoneCode() {
		return homePhoneCode;
	}

	/**
	 * @return the homePhoneNumber
	 */
	public WebElement getHomePhoneNumber() {
		return homePhoneNumber;
	}

	/**
	 * @return the race
	 */
	public WebElement getRace() {
		return race;
	}

	/**
	 * @return the religion
	 */
	public WebElement getReligion() {
		return religion;
	}

	/**
	 * @return the occupation
	 */
	public WebElement getOccupation() {
		return occupation;
	}

	/**
	 * @return the education
	 */
	public WebElement getEducation() {
		return education;
	}

	/**
	 * @return the origin
	 */
	public WebElement getOrigin() {
		return origin;
	}

	/**
	 * @return the bloodGroup
	 */
	public WebElement getBloodGroup() {
		return bloodGroup;
	}

	/**
	 * @return the handicap
	 */
	public WebElement getHandicap() {
		return handicap;
	}

	/**
	 * @return the allergic
	 */
	public WebElement getAllergic() {
		return allergic;
	}

	/**
	 * @return the translatorRequired
	 */
	public WebElement getTranslatorRequired() {
		return translatorRequired;
	}

	/**
	 * @return the isBloodGroupValidated
	 */
	public WebElement getIsBloodGroupValidated() {
		return isBloodGroupValidated;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the birthcountryName
	 */
	public static String getBirthcountryName() {
		return BIRTHCOUNTRY_NAME;
	}

	/**
	 * @return the martialstatusName
	 */
	public static String getMartialstatusName() {
		return MARTIALSTATUS_NAME;
	}

	/**
	 * @return the mobilecodeId
	 */
	public static String getMobilecodeId() {
		return MOBILECODE_ID;
	}

	/**
	 * @return the mobilenumberId
	 */
	public static String getMobilenumberId() {
		return MOBILENUMBER_ID;
	}

	/**
	 * @return the birthplaceId
	 */
	public static String getBirthplaceId() {
		return BIRTHPLACE_ID;
	}

	/**
	 * @return the languageId
	 */
	public static String getLanguageId() {
		return LANGUAGE_ID;
	}

	/**
	 * @return the homephonecodeId
	 */
	public static String getHomephonecodeId() {
		return HOMEPHONECODE_ID;
	}

	/**
	 * @return the homephonenumberId
	 */
	public static String getHomephonenumberId() {
		return HOMEPHONENUMBER_ID;
	}

	/**
	 * @return the raceName
	 */
	public static String getRaceName() {
		return RACE_NAME;
	}

	/**
	 * @return the religionId
	 */
	public static String getReligionId() {
		return RELIGION_ID;
	}

	/**
	 * @return the occupationName
	 */
	public static String getOccupationName() {
		return OCCUPATION_NAME;
	}

	/**
	 * @return the educationName
	 */
	public static String getEducationName() {
		return EDUCATION_NAME;
	}

	/**
	 * @return the originId
	 */
	public static String getOriginId() {
		return ORIGIN_ID;
	}

	/**
	 * @return the bloodgroupName
	 */
	public static String getBloodgroupName() {
		return BLOODGROUP_NAME;
	}

	/**
	 * @return the handicapId
	 */
	public static String getHandicapId() {
		return HANDICAP_ID;
	}

	/**
	 * @return the allergicId
	 */
	public static String getAllergicId() {
		return ALLERGIC_ID;
	}

	/**
	 * @return the translatorrequiredId
	 */
	public static String getTranslatorrequiredId() {
		return translatorRequired_ID;
	}

	/**
	 * @return the isbloodgroupvalidatedId
	 */
	public static String getIsbloodgroupvalidatedId() {
		return ISBLOODGROUPVALIDATED_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}
	
	
}
