package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.otherlocationdetails.OtherLocFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.otherlocationdetails.SubscribingLocations;
import com.atk.himma.pageobjects.mbuadmin.tabs.OtherLocListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class OtherLocationPage extends DriverWaitClass implements StatusMessages, TopControls, RecordStatus{
	
	private OtherLocListTab otherLocListTab;
	private OtherLocFirstSection otherLocFirstSection;
	private SubscribingLocations subscribingLocations;
	
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Other Location']";
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement otherLocDetailsPageTitle;
	
	@FindBy(xpath = DETAILSADDNEWBUTTON_XPATH)
	private WebElement addNewButton;
	
	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;
	
	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		
		otherLocListTab = PageFactory.initElements(webDriver,
				OtherLocListTab.class);
		otherLocListTab.setWebDriver(webDriver);
		otherLocListTab.setWebDriverWait(webDriverWait);

		otherLocFirstSection = PageFactory.initElements(webDriver,
				OtherLocFirstSection.class);
		otherLocFirstSection.setWebDriver(webDriver);
		otherLocFirstSection.setWebDriverWait(webDriverWait);

		subscribingLocations = PageFactory.initElements(webDriver,
				SubscribingLocations.class);
		subscribingLocations.setWebDriver(webDriver);
		subscribingLocations.setWebDriverWait(webDriverWait);
		
	}
	
	public OtherLocationPage clickOnOtherLocMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Other Location");
		OtherLocationPage otherLocationPage = PageFactory.initElements(webDriver, OtherLocationPage.class);
		otherLocationPage.setWebDriver(webDriver);
		otherLocationPage.setWebDriverWait(webDriverWait);
		return otherLocationPage;
	}

	public String searchClinic(String[] otherLocDatas) throws InterruptedException {
		waitForElementId(OtherLocListTab.MBUNAME_ID);
		new Select(otherLocListTab.getMbuName()).selectByVisibleText(otherLocDatas[0]);
		return waitAndGetGridFirstCellText(OtherLocListTab.GRID_ID,
				OtherLocListTab.GRID_LOCNAME_ARIA_DESCRIBEDBY, otherLocDatas[7].trim());
	}
	
	public boolean clickOnAddNewOtherLoc(String[] otherLocaDatas) throws InterruptedException {
		waitForElementXpathExpression(OtherLocListTab.ADDNEWOTHERLOCBUTTON_XPATH);
		sleepVeryShort();
		otherLocListTab.getAddNewOtherLocButton().click();
		waitForElementId(OtherLocFirstSection.MBU_ID);
		sleepVeryShort();
		return new Select(otherLocFirstSection.getMbu()).getFirstSelectedOption().getText().trim().equals(otherLocaDatas[0].trim());
	}
	
	public String updateDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		detailsUpdateButton.click();
		waitForElementXpathExpression(MSGENABLE_XPATH);
		return statusMessage.getText().trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		sleepShort();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepShort();
		return detailsUpdateButton.getAttribute("value").trim();

	}
	
	public boolean saveDuplicateData(String[] otherLocDatas) throws InterruptedException, IOException {
		try{
			waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
			detailsSaveButton.click();
		new WebDriverWait(webDriver, shortTimeInterval).until(ExpectedConditions.presenceOfElementLocated(By
				.xpath(DETAILSUPDATEBUTTON_XPATH)));
		sleepVeryShort();
		return false;
		}
		catch (Exception e) {
			return searchData(otherLocDatas).equals(otherLocDatas[7].trim());
		}
	}
	
	public String searchData(String[] otherLocDatas) {
		waitForElementXpathExpression(OtherLocListTab.OTHERLOCLISTTAB_XPATH);
		otherLocListTab.getOtherLocListTab().click();
		waitForElementId(OtherLocListTab.GRID_ID);
		otherLocListTab.getLocationName().clear();
		otherLocListTab.getLocationName().sendKeys(otherLocDatas[7].trim());
		otherLocListTab.getSearchButton().click();
		return waitForGridFirstDuplicateCellText(OtherLocListTab.GRID_ID, OtherLocListTab.GRID_LOCNAME_ARIA_DESCRIBEDBY);
	}
	
	public String activate() throws InterruptedException, IOException {
		
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
		
	}
	
	public void clickOtherLocListTab() throws InterruptedException
	{
		waitForElementId(OtherLocFirstSection.MBU_ID);
		otherLocListTab.getOtherLocListTab().click();
		waitForElementXpathExpression(OtherLocListTab.SEARCHBUTTON_XPATH);
		sleepVeryShort();
	}
	
	public String searchOtherLocData(String otherLocName) throws InterruptedException, IOException {
		waitForElementXpathExpression(OtherLocListTab.SEARCHBUTTON_XPATH);
		otherLocListTab.getLocationName().clear();
		otherLocListTab.getLocationName().sendKeys(otherLocName.trim());
		otherLocListTab.getSearchButton().click();
		waitForElementId(OtherLocListTab.GRID_ID);
		waitForGridSearchText(otherLocName.trim());
		sleepVeryShort();
		return waitAndGetGridFirstCellText(OtherLocListTab.GRID_ID, OtherLocListTab.GRID_LOCNAME_ARIA_DESCRIBEDBY, otherLocName.trim()).trim();
	}
	
	/**
	 * @return the otherLocListTab
	 */
	public OtherLocListTab getOtherLocListTab() {
		return otherLocListTab;
	}

	/**
	 * @return the otherLocFirstSection
	 */
	public OtherLocFirstSection getOtherLocFirstSection() {
		return otherLocFirstSection;
	}

	/**
	 * @return the subscribingLocations
	 */
	public SubscribingLocations getSubscribingLocations() {
		return subscribingLocations;
	}

	/**
	 * @return the otherLocDetailsPageTitle
	 */
	public WebElement getOtherLocDetailsPageTitle() {
		return otherLocDetailsPageTitle;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}
}
