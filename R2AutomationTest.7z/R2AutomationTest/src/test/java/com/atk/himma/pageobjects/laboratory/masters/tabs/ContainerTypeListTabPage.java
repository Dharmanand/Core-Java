package com.atk.himma.pageobjects.laboratory.masters.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ContainerTypeListTabPage extends DriverWaitClass {
	public final static String ADDNEWCONTTYPEBTN_ID = "ADD_NEW";
	@FindBy(id = ADDNEWCONTTYPEBTN_ID)
	private WebElement addNewContainerTypeBtn;

	public final static String QUICKSEARCHTXT_ID = "QUICK_SEARCH";
	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;

	public final static String QUICKSEARCHBTN_ID = "QUICK_SEARCH_BTN";
	@FindBy(id = QUICKSEARCHBTN_ID)
	private WebElement quickSearchBtn;

	public final static String ADVSEARCHBTN_ID = "ADVANCE_SEARCH";
	@FindBy(id = ADVSEARCHBTN_ID)
	private WebElement advSearchBtn;

	public final static String ADVSEARCHDIV_ID = "ADVANCE_SEARCH_DIV";
	@FindBy(id = ADVSEARCHDIV_ID)
	private WebElement advSearchDiv;

	public final static String CONTTYPESHNAME_ID = "ADV_SEARCH1";
	@FindBy(id = CONTTYPESHNAME_ID)
	private WebElement containerTypeShName;

	public final static String STATUS_ID = "STATUS";
	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String CONTTYPEDESC_ID = "ADV_SEARCH2";
	@FindBy(id = CONTTYPEDESC_ID)
	private WebElement containerTypeDesc;

	public final static String SEARCHADVBTN_ID = "ADV_BTN";
	@FindBy(id = SEARCHADVBTN_ID)
	private WebElement searchAdvBtn;

	public final static String RESETADVBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETADVBTN_XPATH)
	private WebElement resetAdvBtn;

	public final static String CONTTYPELISTEXPBTN_ID = "CONTAINER_TYPE_LIST_export_btn";
	@FindBy(id = CONTTYPELISTEXPBTN_ID)
	private WebElement contTypeListExportBtn;

	public final static String CONTTYPELISTTBL_ID = "CONTAINER_TYPE_LIST";
	@FindBy(id = CONTTYPELISTTBL_ID)
	private WebElement contTypeListTbl;

	public String checkAddNewContTypeBtn() {
		waitForElementId(ADDNEWCONTTYPEBTN_ID);
		return addNewContainerTypeBtn.getAttribute("value");
	}

	public void clickAddNewContTypeBtn() throws Exception {
		addNewContainerTypeBtn.click();
		sleepShort();
	}

	public String searchContainerTypeList(String[] containerTypeData)
			throws Exception {
		quickSearchTxt.clear();
		quickSearchTxt.sendKeys(containerTypeData[1]);
		quickSearchBtn.click();
		waitForElementId(CONTTYPELISTTBL_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(CONTTYPELISTTBL_ID,
				"CONTAINER_TYPE_LIST_containerShortName", containerTypeData[1]);
	}

	public void deleteContainerTypeData(String[] containerTypeData)
			throws Exception {
		clickOnGridAction("CONTAINER_TYPE_LIST_containerShortName",
				containerTypeData[1], "Delete");
		sleepShort();
		deleteRecord();

	}

	public void clickEditContainerData(String[] containerTypeData) {
		clickOnGridAction("CONTAINER_TYPE_LIST_containerShortName",
				containerTypeData[1], "Edit");
		waitForElementId(ContainerTypeDetailsTabPage.CONTTYPEDESC_ID);
		

	}

	public boolean searchGridData(String searchText) {
		boolean result = false;
		try {
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='CONTAINER_TYPE_LIST_containerShortName' and @title='"
									+ searchText.trim() + "']")).isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

	public WebElement getAddNewContainerTypeBtn() {
		return addNewContainerTypeBtn;
	}

	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	public WebElement getQuickSearchBtn() {
		return quickSearchBtn;
	}

	public WebElement getAdvSearchBtn() {
		return advSearchBtn;
	}

	public WebElement getAdvSearchDiv() {
		return advSearchDiv;
	}

	public WebElement getContainerTypeShName() {
		return containerTypeShName;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getContainerTypeDesc() {
		return containerTypeDesc;
	}

	public WebElement getSearchAdvBtn() {
		return searchAdvBtn;
	}

	public WebElement getResetAdvBtn() {
		return resetAdvBtn;
	}

	public WebElement getContTypeListExportBtn() {
		return contTypeListExportBtn;
	}

	public WebElement getContTypeListTbl() {
		return contTypeListTbl;
	}

}
