package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ContactDetailsSection extends DriverWaitClass {
	public final static String CONTACTDETAILSSECTION_LINKTXT = "Contact Details";
	@FindBy(linkText = CONTACTDETAILSSECTION_LINKTXT)
	private WebElement contactDetailsSectionLinkTxt;

	public final static String OFFICEPHCC_NAME = "contactDetailsList[0].officePhone.countryCode";
	@FindBy(name = OFFICEPHCC_NAME)
	private WebElement officePhCC;

	public final static String OFFICENUMBER_ID = "offnumber";
	@FindBy(id = OFFICENUMBER_ID)
	private WebElement officeNumber;

	public final static String EMAIL_ID = "email";
	@FindBy(id = EMAIL_ID)
	private WebElement email;

	public final static String MOBCC_ID = "contactmobcc";
	@FindBy(id = MOBCC_ID)
	private WebElement mobCC;

	public final static String MOBNUMBER_ID = "mobNumber";
	@FindBy(id = MOBNUMBER_ID)
	private WebElement mobNumber;

	public final static String PAGER_ID = "pager";
	@FindBy(id = PAGER_ID)
	private WebElement pager;

	public void fillContactDetails(String[] appUserData) {
		if (!appUserData[31].isEmpty()) {
			new Select(officePhCC).selectByVisibleText(appUserData[31]);
		}
		officeNumber.clear();
		officeNumber.sendKeys(appUserData[32]);

		email.clear();
		email.sendKeys(appUserData[33]);

		if (!appUserData[34].isEmpty()) {
			new Select(mobCC).selectByVisibleText(appUserData[34]);
		}

		mobNumber.clear();
		mobNumber.sendKeys(appUserData[35]);

		pager.clear();
		pager.sendKeys(appUserData[36]);
	}

	public WebElement getContactDetailsSectionLinkTxt() {
		return contactDetailsSectionLinkTxt;
	}

	public WebElement getOfficePhCC() {
		return officePhCC;
	}

	public WebElement getOfficeNumber() {
		return officeNumber;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getMobCC() {
		return mobCC;
	}

	public WebElement getMobNumber() {
		return mobNumber;
	}

	public WebElement getPager() {
		return pager;
	}

}
