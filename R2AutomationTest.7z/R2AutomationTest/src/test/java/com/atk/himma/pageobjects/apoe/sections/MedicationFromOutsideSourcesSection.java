package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class MedicationFromOutsideSourcesSection extends DriverWaitClass {
	public final static String MEDOUTSRCSEC_XPATH = "//a[text()='Medication From The Outside Sources']";
	@FindBy(xpath = MEDOUTSRCSEC_XPATH)
	private WebElement medOutsideSourcesSec;

	public final static String ADDMEDICATIONBTN_XPATH = ".//a[@class='AddListItem' and @onclick='javascript:addMedication();']";
	@FindBy(xpath = ADDMEDICATIONBTN_XPATH)
	private WebElement addMedicationBtn;

	public final static String MEDICATIONFRMOUTSRCGRIDTBL_ID = "MEDICATION_FRM_OUT_SRC_GRID";
	@FindBy(id = MEDICATIONFRMOUTSRCGRIDTBL_ID)
	private WebElement medicationFrmOutSrcGridTbl;

	public final static String MEDNAME_NAME = "medicationName";
	@FindBy(name = MEDNAME_NAME)
	private WebElement medicationName;

	public final static String DOSSAGEDETL_NAME = "dossageDetail";
	@FindBy(name = DOSSAGEDETL_NAME)
	private WebElement dossageDetail;

	public final static String STARTEDDATE_NAME = "startedDate";
	@FindBy(name = STARTEDDATE_NAME)
	private WebElement startedDate;

	public final static String STATUS_NAME = "status";
	@FindBy(name = STATUS_NAME)
	private WebElement status;

	public final static String NOTES_NAME = "notes";
	@FindBy(name = NOTES_NAME)
	private WebElement notes;

	public boolean checkMedFromOutsideSources() {
		return medOutsideSourcesSec.isDisplayed();
	}

	public void addOutsideSrcSecData(String[] outPatientListData)
			throws Exception {
		addMedicationBtn.click();
		sleepVeryShort();
		waitForElementId(MEDICATIONFRMOUTSRCGRIDTBL_ID);
		medicationName.clear();
		medicationName.sendKeys(outPatientListData[69]);
		dossageDetail.clear();
		dossageDetail.sendKeys(outPatientListData[70]);
		startedDate.clear();
		startedDate.sendKeys(outPatientListData[71]);
		if (!outPatientListData[72].isEmpty()) {
			new Select(status).selectByVisibleText(outPatientListData[72]);
		}
		notes.clear();
		notes.sendKeys(outPatientListData[73]);
		
	}

	public WebElement getMedOutsideSourcesSec() {
		return medOutsideSourcesSec;
	}

	public WebElement getAddMedicationBtn() {
		return addMedicationBtn;
	}

	public WebElement getMedicationFrmOutSrcGridTbl() {
		return medicationFrmOutSrcGridTbl;
	}

	public WebElement getMedicationName() {
		return medicationName;
	}

	public WebElement getDossageDetail() {
		return dossageDetail;
	}

	public WebElement getStartedDate() {
		return startedDate;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getNotes() {
		return notes;
	}

}
