package com.atk.himma.pageobjects.contracts.sections.rateplandetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class RatePlanTariffSection extends DriverWaitClass {
	public static final String RATEPLANTARIFFSEC_LINKTEXT = "Rate Plan Tariff";
	public final static String DEPARTMENT_ID = "filterDepartment";
	public final static String SPECIALTY_ID = "filterSpeciality_id";
	public final static String SUBSPECIALTY_ID = "filterSub_speciality_id";
	public final static String SERVICETYPE_ID = "filterService_type";
	public final static String SERVICENAME_ID = "filterService_Name";
	public final static String SERVICECODE_ID = "filterService_code";
	public final static String MODIFPRICESERVICESCHKBOX_ID = "CHECK_MODIFIED_PRICE_SERVICES";
	public final static String ADDSERVBTN_ID = "ADD_SERVICES";
	public final static String APPLYFILTERBTN_XPATH = "//input[@value='Apply Filter']";
	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	public final static String SERVGRIDDIV_ID = "SERVICE_INFO_GRID";
	public final static String EXPORTTOEXCELBTN_ID = "serviceInfo_grid_export_btn";
	public static final String VIEWSERVLINK_XPATH = ".//table[@id='serviceInfo_grid']/..//a[text()='View']";

	@FindBy(linkText = RATEPLANTARIFFSEC_LINKTEXT)
	private WebElement ratePlanTariffSec;

	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;

	@FindBy(id = SUBSPECIALTY_ID)
	private WebElement subSpecialty;

	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;

	@FindBy(id = SERVICENAME_ID)
	private WebElement serviceName;

	@FindBy(id = SERVICECODE_ID)
	private WebElement serviceCode;

	@FindBy(id = MODIFPRICESERVICESCHKBOX_ID)
	private WebElement modifPriceServChkBox;

	@FindBy(id = ADDSERVBTN_ID)
	private WebElement addServBtn;

	@FindBy(xpath = APPLYFILTERBTN_XPATH)
	private WebElement applyFilterBtn;

	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	@FindBy(id = SERVGRIDDIV_ID)
	private WebElement servGridDiv;

	@FindBy(id = EXPORTTOEXCELBTN_ID)
	private WebElement exportToExcel;

	@FindBy(xpath = VIEWSERVLINK_XPATH)
	private WebElement viewServiceLink;

	public WebElement getRatePlanTariffSec() {
		return ratePlanTariffSec;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getSpecialty() {
		return specialty;
	}

	public WebElement getSubSpecialty() {
		return subSpecialty;
	}

	public WebElement getServiceType() {
		return serviceType;
	}

	public WebElement getServiceName() {
		return serviceName;
	}

	public WebElement getServiceCode() {
		return serviceCode;
	}

	public WebElement getModifPriceServChkBox() {
		return modifPriceServChkBox;
	}

	public WebElement getAddServBtn() {
		return addServBtn;
	}

	public WebElement getApplyFilterBtn() {
		return applyFilterBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getServGridDiv() {
		return servGridDiv;
	}

	public WebElement getExportToExcel() {
		return exportToExcel;
	}

	public WebElement getViewServiceLink() {
		return viewServiceLink;
	}

}
