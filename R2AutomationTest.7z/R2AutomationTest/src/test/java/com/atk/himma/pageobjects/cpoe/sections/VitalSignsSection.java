package com.atk.himma.pageobjects.cpoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class VitalSignsSection extends DriverWaitClass {
	public final static String ADDNEWVITALSIGNSBTN_ID = "AddRow_VitalSignsButton";
	public final static String HEIGHT_ID = "HEIGHT";
	public final static String WEIGHT_ID = "WEIGHT";
	public final static String TEMPERATURE_ID = "TEMPERATURE";
	public final static String PULSE_ID = "PULSE";
	public final static String BPSYSTONIC_ID = "BPSYSTONIC";
	public final static String BPDIASTOLIC_ID = "BPDIASTOLIC";
	public final static String RESPIRATORY_ID = "RESPIRATORY";
	public final static String BMI_ID = "BMI";
	public final static String KNOWN_ALLERGIES_ID = "KNOWN_ALLERGIES";
	public final static String TAKENBY_ID = "VITAL_CONSULTANT";
	public final static String PATREADINGTIME_ID = "PATIENT_READING_TIME";
	public final static String ADDVITALSIGNSBTN_ID = "ADD_VITAL_SIGNS";
	public final static String CANCELVITALSIGNSBTN_ID = "CANCEL_VITAL_SIGNS";
	public final static String VITALSIGNSGRIDDIV_ID = "VITAL_SIGNS_DIV";

	@FindBy(id = ADDNEWVITALSIGNSBTN_ID)
	private WebElement addNewVitalSignsBtn;

	@FindBy(id = HEIGHT_ID)
	private WebElement height;

	@FindBy(id = WEIGHT_ID)
	private WebElement weight;

	@FindBy(id = TEMPERATURE_ID)
	private WebElement temperature;

	@FindBy(id = PULSE_ID)
	private WebElement pulse;

	@FindBy(id = BPSYSTONIC_ID)
	private WebElement bpSystonic;

	@FindBy(id = BPDIASTOLIC_ID)
	private WebElement bpDiastolic;

	@FindBy(id = RESPIRATORY_ID)
	private WebElement respiratory;

	@FindBy(id = BMI_ID)
	private WebElement bmi;

	@FindBy(id = KNOWN_ALLERGIES_ID)
	private WebElement knownAllergies;

	@FindBy(id = TAKENBY_ID)
	private WebElement takenBy;

	@FindBy(id = PATREADINGTIME_ID)
	private WebElement patReadingTime;

	@FindBy(id = ADDVITALSIGNSBTN_ID)
	private WebElement addVitalSignsBtn;

	@FindBy(id = CANCELVITALSIGNSBTN_ID)
	private WebElement cancelVitalSignsBtn;

	@FindBy(id = VITALSIGNSGRIDDIV_ID)
	private WebElement vitalSignsGridDiv;

	public WebElement getAddNewVitalSignsBtn() {
		return addNewVitalSignsBtn;
	}

	public WebElement getHeight() {
		return height;
	}

	public WebElement getWeight() {
		return weight;
	}

	public WebElement getTemperature() {
		return temperature;
	}

	public WebElement getPulse() {
		return pulse;
	}

	public WebElement getBpSystonic() {
		return bpSystonic;
	}

	public WebElement getBpDiastolic() {
		return bpDiastolic;
	}

	public WebElement getRespiratory() {
		return respiratory;
	}

	public WebElement getBmi() {
		return bmi;
	}

	public WebElement getKnownAllergies() {
		return knownAllergies;
	}

	public WebElement getTakenBy() {
		return takenBy;
	}

	public WebElement getPatReadingTime() {
		return patReadingTime;
	}

	public WebElement getAddVitalSignsBtn() {
		return addVitalSignsBtn;
	}

	public WebElement getCancelVitalSignsBtn() {
		return cancelVitalSignsBtn;
	}

	public WebElement getVitalSignsGridDiv() {
		return vitalSignsGridDiv;
	}

}
