package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.HomePage;
import com.atk.himma.pageobjects.baselov.BaseLovPage;
import com.atk.himma.pageobjects.baselov.tabs.BaseLoVDetailsTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class BaseLovTest extends SeleniumDriverSetup {

	List<String[]> baseLovDatas;
	BaseLovPage baseLovPage;

	@Test(description = "Open Base Lov Page")
	public void openBaseLovPage() throws InterruptedException {
		HomePage homePage = PageFactory.initElements(webDriver, HomePage.class);
		baseLovPage = homePage.clickOnBaseLovMenu(webDriver, webDriverWait,
				"MBU Administration");
		baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(baseLovPage);
		baseLovPage.waitForElementVisibilityOf(baseLovPage.getBaseLoVListTab()
				.getForm());
		baseLovPage.waitForElementVisibilityOf(baseLovPage.getBaseLoVListTab()
				.getAddNewBaseLoVButton());
		Assert.assertEquals(baseLovPage.getBaseLoVListTab().getBaseLoVListTab()
				.getAttribute("title").trim(), "Base LoV List");
	}

	// [Base LV] Open Form
	@Test(description = "Open Base LV Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkBaseLovMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		PageFactory.initElements(webDriver, BaseLovPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("MBU Administration");
		baseLVParentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList, "Base LV");
		baseLovPage.setWebDriver(webDriver);
		baseLovPage.setWebDriverWait(webDriverWait);
		baseLovPage
				.waitForElementXpathExpression(BaseLovPage.MBUBASELOVMENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Base LV")
				.get("[Base LV] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(BaseLovPage.MBUBASELOVMENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Base LV] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			baseLovPage.clickOnBaseLovMenu(webDriver, webDriverWait,
					"MBU Administration");
			baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(baseLovPage);
			baseLovPage.waitForElementVisibilityOf(baseLovPage
					.getBaseLoVListTab().getAddNewBaseLoVButton());
			baseLovPage.sleepShort();
			Assert.assertEquals(baseLovPage.getPageTitle().getText(),
					"Base LoV");
		}
	}

	@Test(dependsOnMethods = { "openBaseLovPage" }, description = "Save Base Lov Page")
	public void test1SaveBaseLovPage() throws Exception {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		baseLovDatas = excelReader.read(properties.getProperty("baseLV"));
		baseLovPage.setInstanceOfAllSection(webDriver, webDriverWait);
		for (String[] st : baseLovDatas) {

			baseLovPage.saveBaseLovPage(st, webDriver, webDriverWait);
			Assert.assertNotNull(baseLovPage);
			baseLovPage
					.waitForElementXpathExpression(BaseLovPage.SAVECONFMSG_XPATH);
			baseLovPage.sleepVeryShort();
			Assert.assertEquals(baseLovPage.getSaveConfMsg().getText()
					.contains("values saved successfully"), true);
			baseLovPage.waitForElementId(BaseLoVDetailsTab.UPDATEBUTTON_ID);
			Assert.assertEquals(baseLovPage.getBaseLoVDetailsTab()
					.getUpdateButton().getAttribute("value"), "Update", "");
			break;
		}
	}

	@Test(dependsOnMethods = { "test1SaveBaseLovPage" }, description = "Update Base Lov Page")
	public void test2UpdateBaseLovPage() throws IOException,
			InterruptedException {

		for (String[] st : baseLovDatas) {
			baseLovPage.waitForElementId(BaseLoVDetailsTab.UPDATEBUTTON_ID);
			baseLovPage.updateBaseLovPage(st);
			Assert.assertNotNull(baseLovPage);
			baseLovPage
					.waitForElementXpathExpression(BaseLovPage.UPDATECONFMSG_XPATH);
			Assert.assertEquals(baseLovPage.getUpdateConfMsg().getText()
					.contains("values updated successfully"), true);
			baseLovPage.waitForElementId(BaseLoVDetailsTab.UPDATEBUTTON_ID);
			Assert.assertEquals(baseLovPage.getBaseLoVDetailsTab()
					.getUpdateButton().getAttribute("value"), "Update");
			break;
		}
	}

	@Test(description = "Check Duplicate Base Lov Data", dependsOnMethods = { "test1SaveBaseLovPage" })
	public void test3SaveDuplicateOtherLoc() throws InterruptedException,
			IOException {
		for (String st[] : baseLovDatas) {
			Assert.assertTrue(baseLovPage.saveDuplicateData(st),
					"Fail to Check Duplicate other location Data");
			break;
		}
	}

}
