package com.atk.himma.pageobjects.appointsched.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class FreezeTab extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	public final static String FORMNAME_ID = "FREEZ_SLOT";
	public final static String FREEZETAB_XPATH = "//li[@id='APP_TAB_FREEZE']//a[@title='Freeze']";

	@FindBy(xpath = FREEZETAB_XPATH)
	private WebElement freezeTab;
	
	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	public final static String SAVEBUTTON_ID = "FREEZE_ID";

	@FindBy(id = SAVEBUTTON_ID)
	private WebElement saveButton;

	public final static String CANCELBUTTON_ID = "FREEZE_BACK_TO_DAIRY";

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	public final static String STARTTIME_ID = "START_TIME_FREEZ";

	@FindBy(id = STARTTIME_ID)
	private WebElement startTime;

	public final static String ENDTIME_ID = "FREEZING_END_TIME";

	@FindBy(id = ENDTIME_ID)
	private WebElement endTime;

	public final static String REASON_ID = "REASON_ID";

	@FindBy(id = REASON_ID)
	private WebElement reason;

	public final static String COMMENT_NAME = "freezingInfo.comments";

	@FindBy(name = COMMENT_NAME)
	private WebElement comment;

	public boolean isReasonMandatory() throws InterruptedException {
		waitForElementId(REASON_ID);
		sleepVeryShort();
		return isMandatoryField(reason);
	}

	public boolean fillDatas(String[] appointDatas) {
		endTime.clear();
		if (!appointDatas[6].trim().isEmpty())
			endTime.sendKeys(appointDatas[6].trim());
		new Select(reason).selectByVisibleText(appointDatas[7].trim());
		comment.clear();
		comment.sendKeys(appointDatas[8].trim());
		return comment.getAttribute("value").trim().equals(appointDatas[8].trim());
	}

	public boolean saveDatas() throws InterruptedException {
		waitForElementId(SAVEBUTTON_ID);
		sleepVeryShort();
		saveButton.click();
		waitForElementXpathExpression(AppointmentDairy.BACKTOAPPOINTBUTTON_XPATH);
		waitForElementXpathExpression(AppointmentDairy.FROZENCONFMSG_XPATH);
		sleepVeryShort();
		AppointmentDairy appointmentDairy = PageFactory.initElements(webDriver,
				AppointmentDairy.class);
		appointmentDairy.setWebDriver(webDriver);
		appointmentDairy.setWebDriverWait(webDriverWait);
		return appointmentDairy.getFrozenMsg().getText()
				.contains("Frozen the Slots Successfully");
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the startTime
	 */
	public WebElement getStartTime() {
		return startTime;
	}

	/**
	 * @return the endTime
	 */
	public WebElement getEndTime() {
		return endTime;
	}

	/**
	 * @return the reason
	 */
	public WebElement getReason() {
		return reason;
	}

	/**
	 * @return the comment
	 */
	public WebElement getComment() {
		return comment;
	}

	/**
	 * @return the freezeTab
	 */
	public WebElement getFreezeTab() {
		return freezeTab;
	}
}
