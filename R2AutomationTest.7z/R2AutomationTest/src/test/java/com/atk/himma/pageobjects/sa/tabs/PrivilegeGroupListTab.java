package com.atk.himma.pageobjects.sa.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class PrivilegeGroupListTab extends DriverWaitClass {
	public final static String VIEWPRIVGRPFORM_NAME = "viewPrivGroups";
	@FindBy(name = VIEWPRIVGRPFORM_NAME)
	private WebElement viewPrivGrpForm;

	public final static String CANCELPRIVGRPFORM_NAME = "cancelPrivGroups";
	@FindBy(name = CANCELPRIVGRPFORM_NAME)
	private WebElement cancelPrivGrpForm;

	public final static String FINDPRIVGRPFORM_NAME = "findPrivGroups";
	@FindBy(name = FINDPRIVGRPFORM_NAME)
	private WebElement findPrivGrpForm;

	public final static String ADDNEWPRIVGROUPBTN_ID = "ADD_NEW_PRIV_GRP_BTN";
	@FindBy(id = ADDNEWPRIVGROUPBTN_ID)
	private WebElement addNewPrivGroupBtn;

	public final static String PRIVGROUPNAME_ID = "privGroupName";
	@FindBy(id = PRIVGROUPNAME_ID)
	private WebElement privGroupName;

	public final static String MODULENAME_ID = "moduleTab1";
	@FindBy(id = MODULENAME_ID)
	private WebElement moduleName;

	public final static String SEARCHBTN_XPATH = "//input[@value='Search']";
	@FindBy(xpath = SEARCHBTN_XPATH)
	private WebElement searchBtn;

	public final static String RESETBTN_XPATH = "//input[@value='Reset']";
	@FindBy(xpath = RESETBTN_XPATH)
	private WebElement resetBtn;

	public final static String PRIVGRPSGRID_ID = "gbox_privGroupInfo";
	@FindBy(id = PRIVGRPSGRID_ID)
	private WebElement privGrpsGrid;

	public final static String CONFIRMATIONMSG_ID = "ConfirmationMessage";
	@FindBy(id = CONFIRMATIONMSG_ID)
	private WebElement confirmMsg;

	public final static String CONFIRMYES_ID = "MSG_DIALOG_YES";
	@FindBy(id = CONFIRMYES_ID)
	private WebElement confirmYes;

	public final static String CONFIRMNO_ID = "MSG_DIALOG_NO";
	@FindBy(id = CONFIRMNO_ID)
	private WebElement confirmNo;

	public final static String EDITLINK_XPATH = ".//table[@id='privGroupInfo']/..//a[text()='Edit']";
	@FindBy(xpath = EDITLINK_XPATH)
	private WebElement editLink;

	public final static String DELETELINK_XPATH = ".//table[@id='privGroupInfo']/..//a[text()='Delete']";
	@FindBy(xpath = DELETELINK_XPATH)
	private WebElement deleteLink;

	public final static String GRID_ID = "privGroupInfo";
	public final static String GRID_PRIVGRPNAME_ARIA_DESCRIBEDBY = "privGroupInfo_privGrpName";
	public final static String GRID_PAGERID = "sp_1_privGroupInfo_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_privGroupInfo_pager']";

	public void clickOnAddNewPrivGrp() throws Exception {
		addNewPrivGroupBtn.click();
		sleepShort();
	}

	public void searchPrivilegeGroup(String[] editPrivGrpData) throws Exception {
		waitForElementId(PRIVGROUPNAME_ID);
		sleepVeryShort();
		privGroupName.clear();
		privGroupName.sendKeys(editPrivGrpData[0]);
		new Select(moduleName).selectByVisibleText(editPrivGrpData[1]);
		searchBtn.click();
		sleepShort();
	}

	public void searchPrivilegeGroup(String editPrivGrpData) throws Exception {
		waitForElementId(PRIVGROUPNAME_ID);
		sleepVeryShort();
		privGroupName.clear();
		privGroupName.sendKeys(editPrivGrpData);
		searchBtn.click();
		sleepShort();
	}

	public void clickOnEdit(String[] editPrivGrpData) throws Exception {
		clickOnEdit(editPrivGrpData[0]);
	}

	public void clickOnEdit(String editPrivGrpData) throws Exception {
		clickOnGridAction("privGroupInfo_privGrpName", editPrivGrpData, "Edit");
		waitForElementXpathExpression(PrivilegeGroupInformationTab.UPDATEBTN_XPATH);
		sleepShort();
	}

	public void clickOnDelete(String[] delPrivGrpData) throws Exception {
		clickOnGridAction("privGroupInfo_privGrpName", delPrivGrpData[0],
				"Delete");
		sleepVeryShort();
		waitForElementId(CONFIRMATIONMSG_ID);
		confirmYes.click();
		sleepShort();
	}

	public boolean searchGridData(String privGrpName) {
		boolean result = false;
		try {
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='privGroupInfo_privGrpName' and @title='"
									+ privGrpName.trim() + "']")).isDisplayed();
			return result;
		} catch (Exception e) {
			return result;
		}
	}

	public WebElement getViewPrivGrpForm() {
		return viewPrivGrpForm;
	}

	public WebElement getFindPrivGrpForm() {
		return findPrivGrpForm;
	}

	public WebElement getCancelPrivGrpForm() {
		return cancelPrivGrpForm;
	}

	public WebElement getAddNewPrivGroupBtn() {
		return addNewPrivGroupBtn;
	}

	public WebElement getPrivGroupName() {
		return privGroupName;
	}

	public WebElement getModuleName() {
		return moduleName;
	}

	public WebElement getSearchBtn() {
		return searchBtn;
	}

	public WebElement getResetBtn() {
		return resetBtn;
	}

	public WebElement getPrivGrpsGrid() {
		return privGrpsGrid;
	}

	public WebElement getConfirmMsg() {
		return confirmMsg;
	}

	public WebElement getConfirmYes() {
		return confirmYes;
	}

	public WebElement getConfirmNo() {
		return confirmNo;
	}

	public WebElement getEditLink() {
		return editLink;
	}

	public WebElement getDeleteLink() {
		return deleteLink;
	}

}
