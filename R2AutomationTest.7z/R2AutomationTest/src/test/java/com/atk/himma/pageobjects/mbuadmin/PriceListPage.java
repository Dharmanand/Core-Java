package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails.PriceListFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails.PriceModificationParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails.ServicePriceList;
import com.atk.himma.pageobjects.mbuadmin.tabs.OtherLocListTab;
import com.atk.himma.pageobjects.mbuadmin.tabs.PriceListTab;
import com.atk.himma.pageobjects.mbuadmin.tabs.ServiceListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class PriceListPage extends DriverWaitClass implements StatusMessages,
TopControls, RecordStatus
{
	private PriceListTab priceListTab;
	private PriceListFirstSection priceListFirstSection;
	private PriceModificationParameters priceModificationParameters;
	private ServicePriceList servicePriceList;
	
	public final static String EXPORTTOEXCEL_ID = "PRICE_LIST_GRID_export_btn";
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New']";
	public final static String PUBLISHNEWVERSION_ID = "APPLY_VERSION_BUTTON";
	public final static String COPYBUTTON_ID = "COPY_BUTTON";
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Saved Successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Updated Successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Record activated successfully')]";
	
	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Price List']";
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = DETAILSADDNEWBUTTON_XPATH)
	private WebElement addNewButton;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;
	
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement MbuDetailsPageTitle;
	
	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;
	
	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;
	
	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	
	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		
		priceListTab = PageFactory.initElements(webDriver,
				PriceListTab.class);
		priceListTab.setWebDriver(webDriver);
		priceListTab.setWebDriverWait(webDriverWait);

		priceListFirstSection = PageFactory.initElements(webDriver,
				PriceListFirstSection.class);
		priceListFirstSection.setWebDriver(webDriver);
		priceListFirstSection.setWebDriverWait(webDriverWait);

		priceModificationParameters = PageFactory.initElements(webDriver,
				PriceModificationParameters.class);
		priceModificationParameters.setWebDriver(webDriver);
		priceModificationParameters.setWebDriverWait(webDriverWait);

		servicePriceList = PageFactory.initElements(webDriver,
				ServicePriceList.class);
		servicePriceList.setWebDriver(webDriver);
		servicePriceList.setWebDriverWait(webDriverWait);

	}
	
	public PriceListPage clickOnPriceListMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Price List");
		PriceListPage priceListPage = PageFactory.initElements(webDriver, PriceListPage.class);
		priceListPage.setWebDriver(webDriver);
		priceListPage.setWebDriverWait(webDriverWait);
		return priceListPage;
	}

	public String searchService(String[] PriceListDatas) throws InterruptedException {
		waitForElementId(PriceListTab.MBU_ID);
		new Select(priceListTab.getMbu()).selectByVisibleText(PriceListDatas[0].trim());
		selectOrUnSelectCheckBox(PriceListDatas[1], priceListTab.getSearchGlobalPL());
		priceListTab.getPriceListName().clear();
		priceListTab.getPriceListName().sendKeys(PriceListDatas[2].trim());
		priceListTab.getPriceCode().clear();
		priceListTab.getPriceCode().sendKeys(PriceListDatas[3].trim());
		priceListTab.getStartDate().clear();
		priceListTab.getStartDate().sendKeys(PriceListDatas[4].trim());
		priceListTab.getEndDate().clear();
		priceListTab.getEndDate().sendKeys(PriceListDatas[5].trim());
		new Select(priceListTab.getStatus()).selectByVisibleText(PriceListDatas[6]);
		priceListTab.getSearchButton().click();
		waitForElementId(ServiceListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(ServiceListTab.GRID_ID,
				ServiceListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, PriceListDatas[2]);
	}
	
	public boolean clickOnAddNewButton(String[] serviceDatas) throws InterruptedException {
		waitForElementXpathExpression(PriceListTab.ADDNEWPLBUTTON_XPATH);
		sleepVeryShort();
		priceListTab.getAddNewPLButton().click();
		waitForElementId(PriceListFirstSection.MBU_ID);
		sleepVeryShort();
		return new Select(priceListFirstSection.getMbu()).getFirstSelectedOption().getText().trim().equals(serviceDatas[0].trim());
	}
	
	public String updateServiceDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		detailsUpdateButton.click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		return updateConfMsg.getText().trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		sleepTooShort();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepTooShort();
		return detailsUpdateButton.getAttribute("value").trim();

	}
	
	public boolean saveDuplicateData(String[] priceListDatas) throws InterruptedException, IOException {
		try{
			waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
			detailsSaveButton.click();
		new WebDriverWait(webDriver, shortTimeInterval).until(ExpectedConditions.presenceOfElementLocated(By
				.xpath(DETAILSUPDATEBUTTON_XPATH)));
		sleepVeryShort();
		return false;
		}
		catch (Exception e) {
			return searchData(priceListDatas).equals(priceListDatas[7].trim());
		}
	}
	
	public String searchData(String[] priceListDatas) {
		waitForElementXpathExpression(PriceListTab.PRICELISTTAB_XPATH);
		priceListTab.getPriceListTab().click();
		waitForElementId(PriceListTab.GRID_ID);
		priceListTab.getPriceListName().clear();
		priceListTab.getPriceListName().sendKeys(priceListDatas[10].trim());
		priceListTab.getSearchButton().click();
		return waitForGridFirstDuplicateCellText(PriceListTab.GRID_ID, PriceListTab.GRID_PLNAME_ARIA_DESCRIBEDBY);
	}
	
	public String activateService() throws InterruptedException, IOException {
		
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
		
	}
	
	public void clickPriceListTab() throws InterruptedException
	{
		waitForElementId(PriceListTab.MBU_ID);
		priceListTab.getPriceListTab().click();
		waitForElementXpathExpression(PriceListTab.SEARCHBUTTON_XPATH);
		sleepVeryShort();
	}
	
	public String searchPriceListData(String priceListName) throws InterruptedException, IOException {
		waitForElementXpathExpression(PriceListTab.SEARCHBUTTON_XPATH);
		priceListTab.getPriceListName().clear();
		priceListTab.getPriceListName().sendKeys(priceListName.trim());
		priceListTab.getSearchButton().click();
		waitForElementId(PriceListTab.GRID_ID);
		waitForGridSearchText(priceListName.trim());
		sleepVeryShort();
		return waitAndGetGridFirstCellText(PriceListTab.GRID_ID, PriceListTab.GRID_PLNAME_ARIA_DESCRIBEDBY, priceListName.trim()).trim();
	}
	
	/**
	 * @return the priceListTab
	 */
	public PriceListTab getPriceListTab() {
		return priceListTab;
	}

	/**
	 * @return the priceListFirstSection
	 */
	public PriceListFirstSection getPriceListFirstSection() {
		return priceListFirstSection;
	}

	/**
	 * @return the priceModificationParameters
	 */
	public PriceModificationParameters getPriceModificationParameters() {
		return priceModificationParameters;
	}

	/**
	 * @return the servicePriceList
	 */
	public ServicePriceList getServicePriceList() {
		return servicePriceList;
	}

	/**
	 * @return the mbuDetailsPageTitle
	 */
	public WebElement getMbuDetailsPageTitle() {
		return MbuDetailsPageTitle;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}
}
