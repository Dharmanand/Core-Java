package com.atk.himma.pageobjects.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.mbuadmin.sections.servicedetails.AdditionalParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.servicedetails.AdministrativeParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.servicedetails.SerCodeStandAddReferences;
import com.atk.himma.pageobjects.mbuadmin.sections.servicedetails.ServiceFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.servicedetails.ServiceLocation;
import com.atk.himma.pageobjects.mbuadmin.tabs.ServiceListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ServicePage extends DriverWaitClass implements StatusMessages, TopControls, RecordStatus{
	
	private ServiceListTab serviceListTab;
	private ServiceFirstSection serviceFirstSection;
	private AdditionalParameters additionalParameters;
	private AdministrativeParameters administrativeParameters;
	private ServiceLocation serviceLocation;
	private SerCodeStandAddReferences serCodeStandAddReferences;
	
	public final static String DETAILSPAGETITLE_ID = "PAGE_TITLE";
	public final static String DETAILSSAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String DETAILSCANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String DETAILSUPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	public final static String DETAILSADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New ']";
	
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Saved successfully')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Updated successfully')]";
	public final static String ACTIVATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Record activated successfully')]";
	
	public final static String MENULINK_XPATH = "//a[contains(text(),'MBU Administration')]/..//a[text()='Service']";
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = DETAILSADDNEWBUTTON_XPATH)
	private WebElement addNewButton;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = ACTIVATECONFMSG_XPATH)
	private WebElement activateConfMsg;
	
	@FindBy(id = DETAILSPAGETITLE_ID)
	private WebElement MbuDetailsPageTitle;
	
	@FindBy(xpath = SIGNOUT_XPATH)
	private WebElement signOut;
	
	@FindBy(xpath = DETAILSSAVEBUTTON_XPATH)
	private WebElement detailsSaveButton;

	@FindBy(xpath = DETAILSCANCELBUTTON_XPATH)
	private WebElement detailsCancelButton;
	
	@FindBy(xpath = DETAILSUPDATEBUTTON_XPATH)
	private WebElement detailsUpdateButton;
	
	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		
		serviceListTab = PageFactory.initElements(webDriver,
				ServiceListTab.class);
		serviceListTab.setWebDriver(webDriver);
		serviceListTab.setWebDriverWait(webDriverWait);

		serviceFirstSection = PageFactory.initElements(webDriver,
				ServiceFirstSection.class);
		serviceFirstSection.setWebDriver(webDriver);
		serviceFirstSection.setWebDriverWait(webDriverWait);

		additionalParameters = PageFactory.initElements(webDriver,
				AdditionalParameters.class);
		additionalParameters.setWebDriver(webDriver);
		additionalParameters.setWebDriverWait(webDriverWait);

		administrativeParameters = PageFactory.initElements(webDriver,
				AdministrativeParameters.class);
		administrativeParameters.setWebDriver(webDriver);
		administrativeParameters.setWebDriverWait(webDriverWait);

		serviceLocation = PageFactory.initElements(webDriver,
				ServiceLocation.class);
		serviceLocation.setWebDriver(webDriver);
		serviceLocation.setWebDriverWait(webDriverWait);

		serCodeStandAddReferences = PageFactory
				.initElements(webDriver, SerCodeStandAddReferences.class);
		serCodeStandAddReferences.setWebDriver(webDriver);
		serCodeStandAddReferences.setWebDriverWait(webDriverWait);
		
	}
	
	public ServicePage clickOnServiceMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("MBU Administration");
		menuSelector.clickOnTargetMenu(menuList, "Service");
		ServicePage servicePage = PageFactory.initElements(webDriver, ServicePage.class);
		servicePage.setWebDriver(webDriver);
		servicePage.setWebDriverWait(webDriverWait);
		return servicePage;
	}

	public String searchService(String[] serviceDatas) throws InterruptedException {
		waitForElementId(ServiceListTab.MBU_ID);
		new Select(serviceListTab.getMbu()).selectByVisibleText(serviceDatas[0]);
		serviceListTab.getServiceName().clear();
		serviceListTab.getServiceName().sendKeys(serviceDatas[4]);
		new Select(serviceListTab.getStatus()).selectByVisibleText(serviceDatas[8]);
		serviceListTab.getSearchButton().click();
		waitForElementId(ServiceListTab.GRID_ID);
		sleepShort();
		return waitAndGetGridFirstCellText(ServiceListTab.GRID_ID,
				ServiceListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY, serviceDatas[4]);
	}
	
	public boolean clickOnAddNewSerButton(String[] serviceDatas) throws InterruptedException {
		waitForElementXpathExpression(ServiceListTab.ADDNEWSERVICEBUTTON_XPATH);
		sleepVeryShort();
		serviceListTab.getAddNewService().click();
		waitForElementId(ServiceFirstSection.SERMBU_ID);
		sleepVeryShort();
		return new Select(serviceFirstSection.getMbu()).getFirstSelectedOption().getText().trim().equals(serviceDatas[0].trim());
	}
	
	public boolean clickAddNewButton(String[] serviceDatas) throws InterruptedException {
		waitForElementXpathExpression(DETAILSADDNEWBUTTON_XPATH);
		sleepVeryShort();
		addNewButton.click();
		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		sleepVeryShort();
		return new Select(serviceFirstSection.getMbu()).getFirstSelectedOption().getText().trim().equals(serviceDatas[0].trim());
	}
	
	public String updateServiceDetails() throws InterruptedException {
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepVeryShort();
		detailsUpdateButton.click();
		waitForElementXpathExpression(UPDATECONFMSG_XPATH);
		return updateConfMsg.getText().trim();
	}

	public String saveDetailsPage() throws InterruptedException, IOException {

		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		waitForElementXpathExpression(DETAILSUPDATEBUTTON_XPATH);
		sleepShort();
		return detailsUpdateButton.getAttribute("value").trim();

	}
	public boolean saveDuplicateData(String[] serviceDatas) throws InterruptedException, IOException {
		try{
		waitForElementXpathExpression(DETAILSSAVEBUTTON_XPATH);
		detailsSaveButton.click();
		new WebDriverWait(webDriver, shortTimeInterval).until(ExpectedConditions.presenceOfElementLocated(By
				.xpath(DETAILSUPDATEBUTTON_XPATH)));
		sleepVeryShort();
		return false;
		}
		catch (Exception e) {
			return searchData(serviceDatas).equals(serviceDatas[10].trim());
		}
	}
	
	public String searchData(String[] serviceDatas) {
		waitForElementXpathExpression(ServiceListTab.SERVICELIST_XPATH);
		serviceListTab.getServiceListTab().click();
		waitForElementId(ServiceListTab.GRID_ID);
		serviceListTab.getServiceName().clear();
		serviceListTab.getServiceName().sendKeys(serviceDatas[10].trim());
		serviceListTab.getSearchButton().click();
		return waitForGridFirstDuplicateCellText(ServiceListTab.GRID_ID, ServiceListTab.GRID_SERVICENAME_ARIA_DESCRIBEDBY);
	}
	
	public String activateService() throws InterruptedException, IOException {
		waitForElementXpathExpression(ACTIVATE_XPATH);
		sleepVeryShort();
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
		
	}
	
	/**
	 * @return the serviceListTab
	 */
	public ServiceListTab getServiceListTab() {
		return serviceListTab;
	}

	/**
	 * @return the serviceFirstSection
	 */
	public ServiceFirstSection getServiceFirstSection() {
		return serviceFirstSection;
	}

	/**
	 * @return the additionalParameters
	 */
	public AdditionalParameters getAdditionalParameters() {
		return additionalParameters;
	}

	/**
	 * @return the administrativeParameters
	 */
	public AdministrativeParameters getAdministrativeParameters() {
		return administrativeParameters;
	}

	/**
	 * @return the serviceLocation
	 */
	public ServiceLocation getServiceLocation() {
		return serviceLocation;
	}

	/**
	 * @return the serCodeStandAddReferences
	 */
	public SerCodeStandAddReferences getSerCodeStandAddReferences() {
		return serCodeStandAddReferences;
	}

	/**
	 * @return the mbuDetailsPageTitle
	 */
	public WebElement getMbuDetailsPageTitle() {
		return MbuDetailsPageTitle;
	}

	/**
	 * @return the signOut
	 */
	public WebElement getSignOut() {
		return signOut;
	}

	/**
	 * @return the detailsSaveButton
	 */
	public WebElement getDetailsSaveButton() {
		return detailsSaveButton;
	}

	/**
	 * @return the detailsCancelButton
	 */
	public WebElement getDetailsCancelButton() {
		return detailsCancelButton;
	}

	/**
	 * @return the detailsUpdateButton
	 */
	public WebElement getDetailsUpdateButton() {
		return detailsUpdateButton;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the activateRecord
	 */
	public WebElement getActivateRecord() {
		return activateRecord;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the activateConfMsg
	 */
	public WebElement getActivateConfMsg() {
		return activateConfMsg;
	}

	/**
	 * @return the addNewButton
	 */
	public WebElement getAddNewButton() {
		return addNewButton;
	}
	
}
