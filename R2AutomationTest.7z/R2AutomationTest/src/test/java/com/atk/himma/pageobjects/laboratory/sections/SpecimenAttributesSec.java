package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SpecimenAttributesSec extends DriverWaitClass {
	public final static String SPECATTRSEC_XPATH = "//a[text()='Specimen Attributes']";
	@FindBy(xpath = SPECATTRSEC_XPATH)
	private WebElement specAttrSec;

	public final static String SPECDISPTIME_ID = "SPECIMEN_DISPATCH_TIME";
	@FindBy(id = SPECDISPTIME_ID)
	private WebElement specDispTime;

	public final static String FASTINGSPECCHKBOX_ID = "FASTING_SPECIMEN";
	@FindBy(id = FASTINGSPECCHKBOX_ID)
	private WebElement fastingSpecChkBox;

	public final static String SPECADDROWBTN_ID = "SPECIMEN_ADD_ROW_ID";
	@FindBy(id = SPECADDROWBTN_ID)
	private WebElement specAddRowBtn;

	public final static String SPECATTRGRIDTBL_ID = "LAB_TEST_SPECIMEN_ATTRIBUTES_GRID";
	@FindBy(id = SPECATTRGRIDTBL_ID)
	private WebElement specAttrGgridTbl;

	public final static String DEFAULT_NAME = "defaultValue";
	@FindBy(name = DEFAULT_NAME)
	private WebElement defaultVal;

	public final static String SPECTYPE_NAME = "specimenTypeId";
	@FindBy(name = SPECTYPE_NAME)
	private WebElement specType;

	public final static String CONTAINERTYPE_NAME = "containerType.containerTypeId";
	@FindBy(name = CONTAINERTYPE_NAME)
	private WebElement containerType;

	public final static String MAXVOLUME_NAME = "maxValume";
	@FindBy(name = MAXVOLUME_NAME)
	private WebElement maxVolume;

	public final static String UOM_NAME = "uomId";
	@FindBy(name = UOM_NAME)
	private WebElement uom;

	public final static String FIXATIVEREQCHKBOX_NAME = "fixativeRequired";
	@FindBy(name = FIXATIVEREQCHKBOX_NAME)
	private WebElement fixativeReqChkBox;

	public final static String ANATOMICSITEREQCHKBOX_NAME = "anatomicSiteRequired";
	@FindBy(name = ANATOMICSITEREQCHKBOX_NAME)
	private WebElement anatomicSiteReqChkBox;

	public WebElement getSpecAttrSec() {
		return specAttrSec;
	}

	public WebElement getSpecDispTime() {
		return specDispTime;
	}

	public WebElement getFastingSpecChkBox() {
		return fastingSpecChkBox;
	}

	public WebElement getSpecAddRowBtn() {
		return specAddRowBtn;
	}

	public WebElement getSpecAttrGgridTbl() {
		return specAttrGgridTbl;
	}

	public WebElement getDefaultVal() {
		return defaultVal;
	}

	public WebElement getSpecType() {
		return specType;
	}

	public WebElement getContainerType() {
		return containerType;
	}

	public WebElement getMaxVolume() {
		return maxVolume;
	}

	public WebElement getUom() {
		return uom;
	}

	public WebElement getFixativeReqChkBox() {
		return fixativeReqChkBox;
	}

	public WebElement getAnatomicSiteReqChkBox() {
		return anatomicSiteReqChkBox;
	}

}
