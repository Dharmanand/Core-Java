package com.atk.himma.pageobjects.mrd.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class LengthOfStayDetailsTab extends DriverWaitClass implements
		StatusMessages, TopControls, RecordStatus {

	public static final String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Update']";
	public static final String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Cancel']";
	public static final String MBUCODE_CLASS = "mainBusinessUnit.unitCode";
	public static final String MBUNAME_CLASS = "mainBusinessUnit.unitName";
	public static final String GRID_ID = "VISIT_PARAMETERS_GRID";
	public static final String GRID_VISITCATTEXT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_visitCatText";
	public static final String GRID_VISITYPETEXT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_visitTypeText";
	public static final String GRID_ALLOWEDTIME_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_allowedTime";
	public static final String GRID_ALLOWEDTIMETEXT_ARIA_DESCRIBEDBY = "VISIT_PARAMETERS_GRID_allowedTimeText";
	public static final String GRID_ADDBUTTON = "//div[@id='VISIT_PARAMETERS_GRID_pager']//span[@class='ui-icon ui-icon-plus']";

//	------------------------------------------ Add Record Pop Up---------------------------------------
	
	public static final String POPUPFORM_ID = "POPUP_STAY_DETAILS";
	public static final String POPUPVISITCATNAME_ID = "VISIT_CATEGORY";
	public static final String POPUPALLOWEDTIME_ID = "ALLOWED_TIME";
	public static final String POPUPALLOWEDTIMETYPE_ID = "ALLOWED_TIME_TYPE";
	public static final String POPUPADDBUTTON_ID = "ADD_BUTTON";
	public static final String POPUPCANCELBUTTON_ID = "CANCEL_BUTTON";
	
	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;
	
	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;
	
	@FindBy(className = MBUCODE_CLASS)
	private WebElement mbuCode;
	
	@FindBy(className = MBUNAME_CLASS)
	private WebElement mbuName;
	
	@FindBy(id = POPUPFORM_ID)
	private WebElement popUpForm;
	
	@FindBy(id = POPUPVISITCATNAME_ID)
	private WebElement popupVisitCatName;
	
	@FindBy(id = POPUPALLOWEDTIME_ID)
	private WebElement popupAllowedTime;
	
	@FindBy(id = POPUPALLOWEDTIMETYPE_ID)
	private WebElement popupAllowedTimeType;
	
	@FindBy(id = POPUPADDBUTTON_ID)
	private WebElement popupAddButton;
	
	@FindBy(id = POPUPCANCELBUTTON_ID)
	private WebElement popupCancelButton;
	
	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the popUpForm
	 */
	public WebElement getPopUpForm() {
		return popUpForm;
	}

	/**
	 * @return the popupVisitCatName
	 */
	public WebElement getPopupVisitCatName() {
		return popupVisitCatName;
	}

	/**
	 * @return the popupAllowedTime
	 */
	public WebElement getPopupAllowedTime() {
		return popupAllowedTime;
	}

	/**
	 * @return the popupAllowedTimeType
	 */
	public WebElement getPopupAllowedTimeType() {
		return popupAllowedTimeType;
	}

	/**
	 * @return the popupAddButton
	 */
	public WebElement getPopupAddButton() {
		return popupAddButton;
	}

	/**
	 * @return the popupCancelButton
	 */
	public WebElement getPopupCancelButton() {
		return popupCancelButton;
	}
}
