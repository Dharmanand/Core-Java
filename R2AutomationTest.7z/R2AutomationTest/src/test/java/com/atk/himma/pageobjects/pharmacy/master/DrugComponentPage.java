package com.atk.himma.pageobjects.pharmacy.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.pharmacy.sections.DrugCompDetailsFirstSection;
import com.atk.himma.pageobjects.pharmacy.tabs.DrugComponentListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class DrugComponentPage extends DriverWaitClass {

	private DrugComponentListTab drugComponentListTab;
	private DrugCompDetailsFirstSection drugCompDetailsFirstSection;

	public final static String DRUGCOMPONENTLINK_LINKTEXT = "Drug / Component";
	public final static String DRUGCOMPONENTLISTTAB_LINKTEXT = "Drug / Component List";
	public final static String DRUGCOMPONENTDETAILSTAB_LINKTEXT = "Drug / Component Details";

	@FindBy(linkText = DRUGCOMPONENTLINK_LINKTEXT)
	private WebElement drugComponentLink;

	@FindBy(linkText = DRUGCOMPONENTLISTTAB_LINKTEXT)
	private WebElement drugComponentList;

	@FindBy(linkText = DRUGCOMPONENTDETAILSTAB_LINKTEXT)
	private WebElement drugComponentDetails;

	public DrugComponentPage setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		drugComponentListTab = PageFactory.initElements(webDriver,
				DrugComponentListTab.class);
		drugComponentListTab.setWebDriver(webDriver);
		drugComponentListTab.setWebDriverWait(webDriverWait);
		drugCompDetailsFirstSection = PageFactory.initElements(webDriver,
				DrugCompDetailsFirstSection.class);
		drugCompDetailsFirstSection.setWebDriver(webDriver);
		drugCompDetailsFirstSection.setWebDriverWait(webDriverWait);
		DrugComponentPage drugComponentPage = PageFactory.initElements(
				webDriver, DrugComponentPage.class);
		drugComponentPage.setWebDriver(webDriver);
		drugComponentPage.setWebDriverWait(webDriverWait);
		return drugComponentPage;
	}

	public DrugComponentPage checkDrugComponentLink(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(menuList, "Drug / Component");
		DrugComponentPage drugComponentPage = PageFactory.initElements(
				webDriver, DrugComponentPage.class);
		return drugComponentPage;
	}

	public DrugComponentPage clickOnDrugComponentMenu() throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Drug / Component");
		DrugComponentPage drugComponentPage = PageFactory.initElements(
				webDriver, DrugComponentPage.class);
		drugComponentPage.setWebDriver(webDriver);
		drugComponentPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForElementId(DrugComponentListTab.GRID_ID);
		return drugComponentPage;
	}

	public boolean clickOnAddNewDrugCompBtn() throws Exception {
		waitForElementId(DrugComponentListTab.ADDNEWGENDRUGBUTTON_ID);
		drugComponentListTab.getAddNewGenDrugButton().click();
		waitForElementId(DrugComponentListTab.ADDNEWGENDRUGBUTTON_ID);
		waitForElementId(DrugCompDetailsFirstSection.FORM_ID);
		return drugCompDetailsFirstSection.getSaveButton().isDisplayed();
	}

	public boolean isReadonlyDrugCompCode() {
		return isReadonlyField(drugCompDetailsFirstSection.getDrugCompCode());
	}

	public boolean isMandatoryDrugCompDescr() {
		return isMandatoryField(drugCompDetailsFirstSection
				.getDrugCompShortDesc());
	}

	public boolean isMandatoryDefaultUOM() {
		return isMandatoryField(drugCompDetailsFirstSection
				.getDrugCompShortDesc());
	}

	public boolean isMandatoryRoute() {
		return isMandatoryField(drugCompDetailsFirstSection.getRoute());
	}

	public boolean isReadonlyItemCategory() {
		return isReadonlyField(drugCompDetailsFirstSection.getItemCategory());
	}

	public boolean fillDrugComponentDatas(String[] drugCompDatas) {
		if (!drugCompDatas[0].isEmpty()) {
			drugCompDetailsFirstSection.getDrugCompShortDesc().clear();
			drugCompDetailsFirstSection.getDrugCompShortDesc().sendKeys(
					drugCompDatas[0].trim());
		}
		if (!drugCompDatas[1].isEmpty()) {
			drugCompDetailsFirstSection.getDrugCompDesc().clear();
			drugCompDetailsFirstSection.getDrugCompDesc().sendKeys(
					drugCompDatas[1].trim());
		}
		if (!drugCompDatas[2].isEmpty()) {
			new Select(drugCompDetailsFirstSection.getDefaultUOM())
					.selectByVisibleText(drugCompDatas[2].trim());
		}
		if (!drugCompDatas[3].isEmpty()) {
			new Select(drugCompDetailsFirstSection.getRoute())
					.selectByVisibleText(drugCompDatas[3].trim());
		}
		return drugCompDetailsFirstSection.getDrugCompDesc()
				.getAttribute("value").trim() == drugCompDatas[1].trim();
	}

	public boolean saveData() {
		waitForElementCssSelector(DrugCompDetailsFirstSection.SAVEBUTTON_CSS);
		drugCompDetailsFirstSection.getSaveButton().click();
		waitForElementCssSelector(DrugCompDetailsFirstSection.UPDATEBUTTON_CSS);
		return drugCompDetailsFirstSection.getUpdateButton().isDisplayed();
	}

	public boolean updateData(String[] drugCompDatas) {

		waitForElementCssSelector(DrugCompDetailsFirstSection.UPDATEBUTTON_CSS);
		if (!drugCompDatas[0].isEmpty()) {
			drugCompDetailsFirstSection.getDrugCompShortDesc().clear();
			drugCompDetailsFirstSection.getDrugCompShortDesc().sendKeys(
					drugCompDatas[0].trim());
		}
		if (!drugCompDatas[1].isEmpty()) {
			drugCompDetailsFirstSection.getDrugCompDesc().clear();
			drugCompDetailsFirstSection.getDrugCompDesc().sendKeys(
					drugCompDatas[1].trim());
		}
		if (!drugCompDatas[2].isEmpty()) {
			new Select(drugCompDetailsFirstSection.getDefaultUOM())
					.selectByVisibleText(drugCompDatas[2].trim());
		}
		if (!drugCompDatas[3].isEmpty()) {
			new Select(drugCompDetailsFirstSection.getRoute())
					.selectByVisibleText(drugCompDatas[3].trim());
		}
		drugCompDetailsFirstSection.getUpdateButton().click();
		waitForElementCssSelector(DrugCompDetailsFirstSection.UPDATEBUTTON_CSS);
		return drugCompDetailsFirstSection.getDrugCompDesc()
				.getAttribute("value").trim() == drugCompDatas[1].trim();
	}

	/**
	 * @return the drugComponentListTab
	 */
	public DrugComponentListTab getDrugComponentListTab() {
		return drugComponentListTab;
	}

	/**
	 * @return the drugCompDetailsFirstSection
	 */
	public DrugCompDetailsFirstSection getDrugCompDetailsFirstSection() {
		return drugCompDetailsFirstSection;
	}

	/**
	 * @return the drugComponentList
	 */
	public WebElement getDrugComponentList() {
		return drugComponentList;
	}

	/**
	 * @return the drugComponentDetails
	 */
	public WebElement getDrugComponentDetails() {
		return drugComponentDetails;
	}

	/**
	 * @return the drugComponentLink
	 */
	public WebElement getDrugComponentLink() {
		return drugComponentLink;
	}
}
