package com.atk.himma.pageobjects.contracts.sections.classdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class ClassDetailsFirstSection extends DriverWaitClass {
	public final static String CLSCODE_ID = "CLASS_CODE";
	public final static String CLSNAME_ID = "CLASS_NAME";
	public final static String POLICYNAME_ID = "POLICY_NAME";
	public final static String POLNAMELOOKUP_XPATH = "//form[@id='CLASS_DETAILS_FORM']//a[@class='lookup']";
	public final static String POLNAMELOOKUPFORM_ID = "classPolicyNameformId";
	public final static String POLNAMELOOKUPMBU_ID = "CLASS_POLICY_MBU_DET";
	public final static String GLOBALPOLCHKBOX_ID = "CLASS_POL_POPUP_MAIN";
	public final static String POLNAMELOOKUPDBTRNAME_ID = "CLASS_POLICY_DEBTORNAME_DET";
	public final static String POLNAMELOOKUPAGRMNTNAME_ID = "CLASS_POLICY_AGRMNTNAME_DET";
	public final static String POLNAMELOOKUPPOLNAME_ID = "CLASS_POLICY_PNAME_DET";
	public final static String POLNAMELOOKUPPOLREFNUM_ID = "CLASS_POLICY_REFNUMBER_DET";
	public final static String POLNAMELOOKUPSEARCHBTN_ID = "searchPolicyNameId";
	public final static String POLNAMELOOKUPRESETBTN_ID = "CLASS_POLICY_RESET_DET";
	public final static String POLNAMELOOKUPGRIDDIV_ID = "CLASS_POLICY_SEARCH_GRID_DIV";
	public final static String MBU_ID = "MBU_NAME";
	public final static String GLOBALCLSCHKBOX_ID = "CLASS_GLOBAL_CHBOX_MAIN";

	@FindBy(id = CLSCODE_ID)
	private WebElement clsCode;

	@FindBy(id = CLSNAME_ID)
	private WebElement clsName;

	@FindBy(id = POLICYNAME_ID)
	private WebElement policyName;

	@FindBy(xpath = POLNAMELOOKUP_XPATH)
	private WebElement polNameLookup;

	@FindBy(id = POLNAMELOOKUPFORM_ID)
	private WebElement polNameLookupForm;

	@FindBy(id = POLNAMELOOKUPMBU_ID)
	private WebElement polNameLookupMBU;

	@FindBy(id = GLOBALPOLCHKBOX_ID)
	private WebElement globalPolChkBox;

	@FindBy(id = POLNAMELOOKUPDBTRNAME_ID)
	private WebElement polNameLookupDbtrName;

	@FindBy(id = POLNAMELOOKUPAGRMNTNAME_ID)
	private WebElement polNameLookupAgrmntName;

	@FindBy(id = POLNAMELOOKUPPOLNAME_ID)
	private WebElement polNameLookupPolName;

	@FindBy(id = POLNAMELOOKUPPOLREFNUM_ID)
	private WebElement polNameLookupPolRefNum;

	@FindBy(id = POLNAMELOOKUPSEARCHBTN_ID)
	private WebElement polNameLookupSearchBtn;

	@FindBy(id = POLNAMELOOKUPRESETBTN_ID)
	private WebElement polNameLookupResetBtn;

	@FindBy(id = POLNAMELOOKUPGRIDDIV_ID)
	private WebElement polNameLookupGridDiv;

	@FindBy(id = MBU_ID)
	private WebElement mbu;

	@FindBy(id = GLOBALCLSCHKBOX_ID)
	private WebElement globalClsChkBox;

	public boolean isMandClassName() {
		waitForElementId(CLSNAME_ID);
		return isMandatoryField(clsName);
	}

	public boolean isMandPolicyName() {
		waitForElementId(POLICYNAME_ID);
		return isMandatoryField(policyName);
	}

	public boolean isMandMBUName() {
		waitForElementId(MBU_ID);
		return isMandatoryField(mbu);
	}

	public void fillData(String[] classListData) throws Exception {
		waitForElementId(CLSNAME_ID);
		sleepLong();
		clsName.clear();
		clsName.sendKeys(classListData[0]);
		polNameLookup.click();
		sleepShort();
		waitForElementId(POLNAMELOOKUPFORM_ID);
		if (!classListData[6].isEmpty()) {
			new Select(polNameLookupMBU).selectByVisibleText(classListData[6]);
		}
		if (Boolean.valueOf(classListData[1])) {
			globalPolChkBox.click();
		}
		if (!classListData[2].isEmpty()) {
			new Select(polNameLookupDbtrName)
					.selectByVisibleText(classListData[2]);
		}
		sleepVeryShort();
		if (!classListData[3].isEmpty()) {
			new Select(polNameLookupAgrmntName)
					.selectByVisibleText(classListData[3]);
		}
		polNameLookupPolName.clear();
		polNameLookupPolName.sendKeys(classListData[4]);
		polNameLookupPolRefNum.clear();
		polNameLookupPolRefNum.sendKeys(classListData[5]);
		polNameLookupSearchBtn.click();
		sleepShort();
		waitForElementId(POLNAMELOOKUPGRIDDIV_ID);
		clickOnGridAction("CLASS_POLICY_DETAILS_GRID_policyName",
				classListData[4], "Select");
		sleepVeryShort();
		if (!classListData[6].isEmpty()) {
			new Select(mbu).selectByVisibleText(classListData[6]);
		}
		if (Boolean.valueOf(classListData[7])) {
			globalClsChkBox.click();
		}

	}

	public String getSelectedMBU() {
		return new Select(mbu).getFirstSelectedOption().getText();
	}

	public WebElement getClsCode() {
		return clsCode;
	}

	public WebElement getClsName() {
		return clsName;
	}

	public WebElement getPolicyName() {
		return policyName;
	}

	public WebElement getPolNameLookup() {
		return polNameLookup;
	}

	public WebElement getPolNameLookupForm() {
		return polNameLookupForm;
	}

	public WebElement getPolNameLookupMBU() {
		return polNameLookupMBU;
	}

	public WebElement getGlobalPolChkBox() {
		return globalPolChkBox;
	}

	public WebElement getPolNameLookupDbtrName() {
		return polNameLookupDbtrName;
	}

	public WebElement getPolNameLookupAgrmntName() {
		return polNameLookupAgrmntName;
	}

	public WebElement getPolNameLookupPolName() {
		return polNameLookupPolName;
	}

	public WebElement getPolNameLookupPolRefNum() {
		return polNameLookupPolRefNum;
	}

	public WebElement getPolNameLookupSearchBtn() {
		return polNameLookupSearchBtn;
	}

	public WebElement getPolNameLookupResetBtn() {
		return polNameLookupResetBtn;
	}

	public WebElement getPolNameLookupGridDiv() {
		return polNameLookupGridDiv;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getGlobalClsChkBox() {
		return globalClsChkBox;
	}

}
