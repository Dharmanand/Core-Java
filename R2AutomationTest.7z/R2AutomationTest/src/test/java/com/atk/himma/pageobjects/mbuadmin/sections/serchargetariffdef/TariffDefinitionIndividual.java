package com.atk.himma.pageobjects.mbuadmin.sections.serchargetariffdef;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class TariffDefinitionIndividual extends DriverWaitClass {

	public final static String SERVICEDEFFORM_ID = "TARIFF_DEFINITION_FORM";
	public final static String SERVICECODE_NAME = "serviceInfo.serviceCode";
	public final static String SERVICENAME_NAME = "serviceInfo.serviceName";
	public final static String MBU_NAME = "mbuName";
	public final static String DEPARTMENT_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div[2]/div/div/div/form/div[3]/span[3]/input";
	public final static String SPECIALTY_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div[2]/div/div/div/form/div[3]/input[5]";
	public final static String SERVICETYPE_XPATH = "/html/body/div/div/div[3]/div/div[2]/div/div[2]/div/div/div/form/div[3]/input[7]";
	public final static String BASEPRICE_ID = "BASE_PRICE";
	public final static String SELLINGPRICE_ID = "SELLING_PRICE";
	public final static String DEPOSITAMOUNT_ID = "DEPOSIT_AMOUNT";
	public final static String SECDEPAMOUNT_ID = "SECURITY_DEPOSIT_AMOUNT";
	public final static String PRICEDIFFFOREXTPATIENT_ID = "PRICE_DIFF_FOR_EXT_PATIENT";
	public final static String PRICE_ID = "PRICE";
	public final static String SERPRICENEGOTIABLE_ID = "SERVICE_PRICE_NEGOTIABLE";
	public final static String MINPRICE_ID = "MINIMUM_PRICE";
	public final static String MAXPRICE_ID = "MAXIMUM_PRICE";

	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_bottom']//input[@value='Save']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_bottom']//input[@value='Cancel']";

	@FindBy(id = SERVICEDEFFORM_ID)
	private WebElement serviceDefForm;

	@FindBy(name = SERVICECODE_NAME)
	private WebElement serviceCode;

	@FindBy(name = SERVICENAME_NAME)
	private WebElement serviceName;

	@FindBy(name = MBU_NAME)
	private WebElement mbu;

	@FindBy(xpath = DEPARTMENT_XPATH)
	private WebElement department;

	@FindBy(xpath = SPECIALTY_XPATH)
	private WebElement specialty;

	@FindBy(xpath = SERVICETYPE_XPATH)
	private WebElement serviceType;

	@FindBy(id = BASEPRICE_ID)
	private WebElement basePrice;

	@FindBy(id = SELLINGPRICE_ID)
	private WebElement sellingPrice;

	@FindBy(id = DEPOSITAMOUNT_ID)
	private WebElement depositAmount;

	@FindBy(id = SECDEPAMOUNT_ID)
	private WebElement secDepAmount;

	@FindBy(id = PRICEDIFFFOREXTPATIENT_ID)
	private WebElement priceDiffForExtPatient;

	@FindBy(id = PRICE_ID)
	private WebElement price;

	@FindBy(id = SERPRICENEGOTIABLE_ID)
	private WebElement serPriceNegotiable;

	@FindBy(id = MINPRICE_ID)
	private WebElement minPrice;

	@FindBy(id = MAXPRICE_ID)
	private WebElement maxPrice;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	public boolean fillTariffDefDatas(String[] serChargDatas) throws Exception {
		waitForElementId(BASEPRICE_ID);
		sleepVeryShort();
		basePrice.clear();
		basePrice.sendKeys(serChargDatas[10].trim());
		waitForElementId(SELLINGPRICE_ID);
		sleepTooShort();
		sellingPrice.clear();
		sellingPrice.sendKeys(serChargDatas[11].trim());
		waitForElementId(DEPOSITAMOUNT_ID);
		sleepTooShort();
		depositAmount.clear();
		depositAmount.sendKeys(serChargDatas[12].trim());
		waitForElementId(SECDEPAMOUNT_ID);
		sleepTooShort();
		secDepAmount.clear();
		secDepAmount.sendKeys(serChargDatas[13].trim());
		selectOrUnSelectCheckBox(serChargDatas[14].trim(),
				priceDiffForExtPatient);
		if (priceDiffForExtPatient.isSelected())
			price.sendKeys(serChargDatas[15].trim());
		selectOrUnSelectCheckBox(serChargDatas[16].trim(), serPriceNegotiable);
		if (serPriceNegotiable.isSelected()) {
			minPrice.sendKeys(serChargDatas[17].trim());
			maxPrice.sendKeys(serChargDatas[18].trim());
		}
		return secDepAmount.getAttribute("value").trim()
				.equals(serChargDatas[13].trim());
	}

	/**
	 * @return the serviceDefForm
	 */
	public WebElement getServiceDefForm() {
		return serviceDefForm;
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the specialty
	 */
	public WebElement getSpecialty() {
		return specialty;
	}

	/**
	 * @return the serviceType
	 */
	public WebElement getServiceType() {
		return serviceType;
	}

	/**
	 * @return the basePrice
	 */
	public WebElement getBasePrice() {
		return basePrice;
	}

	/**
	 * @return the sellingPrice
	 */
	public WebElement getSellingPrice() {
		return sellingPrice;
	}

	/**
	 * @return the depositAmount
	 */
	public WebElement getDepositAmount() {
		return depositAmount;
	}

	/**
	 * @return the secDepAmount
	 */
	public WebElement getSecDepAmount() {
		return secDepAmount;
	}

	/**
	 * @return the priceDiffForExtPatient
	 */
	public WebElement getPriceDiffForExtPatient() {
		return priceDiffForExtPatient;
	}

	/**
	 * @return the price
	 */
	public WebElement getPrice() {
		return price;
	}

	/**
	 * @return the serPriceNegotiable
	 */
	public WebElement getSerPriceNegotiable() {
		return serPriceNegotiable;
	}

	/**
	 * @return the minPrice
	 */
	public WebElement getMinPrice() {
		return minPrice;
	}

	/**
	 * @return the maxPrice
	 */
	public WebElement getMaxPrice() {
		return maxPrice;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

}
