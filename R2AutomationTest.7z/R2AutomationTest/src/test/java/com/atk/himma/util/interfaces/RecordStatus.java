package com.atk.himma.util.interfaces;

public interface RecordStatus {
	
	static final String ACTIVATE_ID = "UPDATE_MAIN_STATUS";
	static final String ACTIVATE_XPATH = "//input[@id='UPDATE_MAIN_STATUS' and @value='Activate']";
	static final String INACTIVATE_XPATH = "//input[@id='UPDATE_MAIN_STATUS' and @value='Inactivate']";
	static final String MAINSTATUSLABEL_ID = "MAIN_STATUS_TEXT";
}
