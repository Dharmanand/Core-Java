package com.atk.himma.pageobjects.appointsched;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.tabs.AuditTrailTab;
import com.atk.himma.pageobjects.appointsched.tabs.BookTab;
import com.atk.himma.pageobjects.appointsched.tabs.FreezeTab;
import com.atk.himma.pageobjects.appointsched.tabs.ReserveTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class ManageBooking extends DriverWaitClass implements StatusMessages,
TopControls, RecordStatus{

	private BookTab bookTab;
	private ReserveTab reserveTab;
	private FreezeTab freezeTab;
	private AuditTrailTab auditTrailTab;
	
	public void setInstance(WebDriver webDriver, WebDriverWait webDriverWait) {

		bookTab = PageFactory.initElements(webDriver,
				BookTab.class);
		bookTab.setWebDriver(webDriver);
		bookTab.setWebDriverWait(webDriverWait);

		reserveTab = PageFactory.initElements(webDriver,
				ReserveTab.class);
		reserveTab.setWebDriver(webDriver);
		reserveTab.setWebDriverWait(webDriverWait);

		freezeTab = PageFactory.initElements(webDriver,
				FreezeTab.class);
		freezeTab.setWebDriver(webDriver);
		freezeTab.setWebDriverWait(webDriverWait);
		
//		auditTrailTab = PageFactory.initElements(webDriver,
//				AuditTrailTab.class);
//		auditTrailTab.setWebDriver(webDriver);
//		auditTrailTab.setWebDriverWait(webDriverWait);
	}

	/**
	 * @return the bookTab
	 */
	public BookTab getBookTab() {
		return bookTab;
	}

	/**
	 * @return the reserveTab
	 */
	public ReserveTab getReserveTab() {
		return reserveTab;
	}

	/**
	 * @return the freezeTab
	 */
	public FreezeTab getFreezeTab() {
		return freezeTab;
	}

	/**
	 * @return the auditTrailTab
	 */
	public AuditTrailTab getAuditTrailTab() {
		return auditTrailTab;
	}
}
