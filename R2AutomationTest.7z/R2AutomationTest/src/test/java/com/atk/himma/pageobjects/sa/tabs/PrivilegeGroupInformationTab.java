package com.atk.himma.pageobjects.sa.tabs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.JsTreeSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

public class PrivilegeGroupInformationTab extends DriverWaitClass {
	public final static String PRIVGRPADDMODIFYFORM_ID = "privGrpAddModifyForm";
	@FindBy(id = PRIVGRPADDMODIFYFORM_ID)
	private WebElement privGrpAddModifyForm;

	public final static String ADDNEWPRIVGRPBTN_XPATH = "//form[@id='privGrpAddModifyForm']//input[@value='Add New Privilege Group']";
	@FindBy(xpath = ADDNEWPRIVGRPBTN_XPATH)
	private WebElement addNewPrivGrpBtn;

	public final static String SAVEBTN_XPATH = "//input[@value='Save']";
	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	public final static String CANCELBTN_XPATH = "//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String UPDATEBTN_XPATH = "//input[@value='Update']";
	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	public final static String PRIVGRPNAME_ID = "privGrpName";
	@FindBy(id = PRIVGRPNAME_ID)
	private WebElement privGrpName;

	public final static String PRIVGRPDESCRIPTION_ID = "privGrpDesc";
	@FindBy(id = PRIVGRPDESCRIPTION_ID)
	private WebElement privGrpDescription;

	public final static String MODULE_ID = "MODULE";
	@FindBy(id = MODULE_ID)
	private WebElement module;

	public final static String TREESPAN_ID = "jqStrutsTree";
	@FindBy(id = TREESPAN_ID)
	private WebElement treeSpan;

	public final static String TREEDIV_ID = "moduleTree";
	@FindBy(id = TREEDIV_ID)
	private WebElement treeDiv;

	public final static String TREECHECKBOX_CLASSNAME = "jstree-checkbox";
	@FindBy(className = TREECHECKBOX_CLASSNAME)
	private WebElement treeCheckBox;

	public final static String AUDITTRAIL = "auditViewId_title";
	@FindBy(id = AUDITTRAIL)
	private WebElement auditTrail;

	public void addNewPrivGrp(String[] privGrpData) throws Exception {
		waitForElementId(PRIVGRPNAME_ID);
		privGrpName.clear();
		privGrpName.sendKeys(privGrpData[0]);
		new Select(module).selectByVisibleText(privGrpData[1]);
		waitForElementId(TREESPAN_ID);
		waitForElementId(TREEDIV_ID);
		sleepShort();
		if (!privGrpData[2].isEmpty()) {
			String[] privSetArray = privGrpData[2].split(",");
			for (String privSet : privSetArray) {
				getTreeDiv().findElement(
						By.xpath("//a[text()='" + privSet.trim()
								+ "']/ins[@class='jstree-checkbox']")).click();
			}
		}

		if (!privGrpData[3].isEmpty()) {
			String[] individualPrivArray = privGrpData[3].split(",");
			for (String individualPriv : individualPrivArray) {
				List<WebElement> privilegeWEList = getTreeDiv()
						.findElements(
								By.xpath("//a[text()='" + individualPriv.trim()
										+ "']"));
				if (privilegeWEList.size() == 0) {
					throw new Exception("Privilege '" + individualPriv
							+ "' not found in module '" + privGrpData[1] + "'");
				} else if (privilegeWEList.size() == 1) {
					privilegeWEList.get(0)
							.findElement(By.className("jstree-checkbox"))
							.click();
				} else {
					privilegeWEList.get(1)
							.findElement(By.className("jstree-checkbox"))
							.click();
				}
			}
		}
		saveBtn.click();
		waitForElementXpathExpression(UPDATEBTN_XPATH);
		sleepShort();
	}

	public void clickOnAddNewPrivGrpBtn() throws Exception {
		addNewPrivGrpBtn.click();
		sleepShort();
	}

	public void clickOnCancel() throws Exception {
		cancelBtn.click();
		sleepShort();
	}

	public void updatePrivGrpData(String[] editPrivGrpData) throws Exception {
		waitForElementId(PRIVGRPADDMODIFYFORM_ID);
		waitForElementId(TREEDIV_ID);
		sleepShort();
		new JsTreeSelector(webDriver, webDriverWait).expandTree(TREEDIV_ID);
		sleepShort();
		if (!editPrivGrpData[2].isEmpty()) {
			String[] privSetArray = editPrivGrpData[2].split(",");
			for (String privSet : privSetArray) {
				getTreeDiv().findElement(
						By.xpath("//a[text()='" + privSet.trim()
								+ "']/ins[@class='jstree-checkbox']")).click();
			}
		}

		if (!editPrivGrpData[3].isEmpty()) {
			String[] individualPrivArray = editPrivGrpData[3].split(",");
			for (String individualPriv : individualPrivArray) {
				List<WebElement> privilegeWEList = getTreeDiv()
						.findElements(
								By.xpath("//a[text()='" + individualPriv.trim()
										+ "']"));
				if (privilegeWEList.size() == 0) {
					throw new Exception("Privilege '" + individualPriv
							+ "' not found in module '" + editPrivGrpData[1]
							+ "'");
				} else if (privilegeWEList.size() == 1) {
					privilegeWEList.get(0)
							.findElement(By.className("jstree-checkbox"))
							.click();
				} else {
					privilegeWEList.get(1)
							.findElement(By.className("jstree-checkbox"))
							.click();
				}
			}
		}
		sleepVeryShort();
		updateBtn.click();
		sleepShort();
	}

	public void setPrivilegeForCheck(String[] privGrpData) throws Exception {
		waitForElementId(PRIVGRPADDMODIFYFORM_ID);
		waitForElementId(TREEDIV_ID);
		sleepShort();
		new JsTreeSelector(webDriver, webDriverWait).expandTree(TREEDIV_ID);
		sleepShort();
		if (!privGrpData[3].isEmpty()) {
			String[] privSetArray = privGrpData[3].split(",");
			for (String privSet : privSetArray) {
				getTreeDiv().findElement(
						By.xpath("//a[text()='" + privSet.trim()
								+ "']/ins[@class='jstree-checkbox']")).click();
			}
		}

		if (!privGrpData[3].isEmpty()) {
			String[] individualPrivArray = privGrpData[3].split(",");
			for (String individualPriv : individualPrivArray) {
				List<WebElement> privilegeWEList = getTreeDiv()
						.findElements(
								By.xpath("//a[text()='" + individualPriv.trim()
										+ "']"));
				if (privilegeWEList.size() == 0) {
					throw new Exception("Privilege '" + individualPriv
							+ "' not found in module '" + privGrpData[1] + "'");
				} else if (privilegeWEList.size() == 1) {
					privilegeWEList.get(0)
							.findElement(By.className("jstree-checkbox"))
							.click();
				} else {
					privilegeWEList.get(1)
							.findElement(By.className("jstree-checkbox"))
							.click();
				}
			}
		}
		sleepVeryShort();
		updateBtn.click();
		sleepShort();
	}

	public boolean setPrivilegeForCheck(List<String> privGrpData,
			String moduleName, List<String> formNames) throws Exception {
		waitForElementId(PRIVGRPADDMODIFYFORM_ID);
		waitForElementId(TREEDIV_ID);
		sleepShort();
		// new JsTreeSelector(webDriver, webDriverWait).expandTree(TREEDIV_ID);
		// sleepShort();
		uncheckRootPrivilege(moduleName.trim());
		int j = 0;
		for (String st : privGrpData) {
			String[] privileges = st.split(";");
			for (int i = 0; i < privileges.length; i++) {
				doCheckUncheckPrivilege(formNames.get(j).trim(),
						privileges[i].trim());
			}
			j++;
		}
		sleepVeryShort();
		updateBtn.click();
		waitForPageLoaded(webDriver);
		sleepShort();
		JsTreeSelector jsTreeSelector = new JsTreeSelector(webDriver,
				webDriverWait);
		jsTreeSelector.expandTree(TREEDIV_ID);
		boolean flag = true;
		j = 0;
		PrivilegesDataExecutor.formPrivileges = new HashMap<String, Map<String, Boolean>>();
		Map<String, Boolean> getPrivileges = new HashMap<String, Boolean>();
		for (String st : privGrpData) {
			String[] privileges = st.split(";");

			for (int i = 0; i < privileges.length; i++) {
				System.out.println(formNames.get(j).trim()
						+ " "
						+ privileges[i].trim()
						+ "---------->>>>>>>"
						+ findCheckUncheckPrivilege(formNames.get(j).trim(),
								privileges[i].trim()));
				flag = flag
						&& findCheckUncheckPrivilege(formNames.get(j).trim(),
								privileges[i].trim());
				getPrivileges.put(privileges[i].trim(), flag);
			}
			PrivilegesDataExecutor.formPrivileges.put(formNames.get(j).trim(),
					getPrivileges);
			j++;
		}
		PrivilegesDataExecutor.allModCollecPrivileges.put(moduleName,
				PrivilegesDataExecutor.formPrivileges);
		return flag;
	}

	public boolean setMenuPrivilegeForCheck(List<String> privGrpData,
			String moduleName, List<String> formNames) throws Exception {
		waitForElementId(PRIVGRPADDMODIFYFORM_ID);
		waitForElementId(TREEDIV_ID);
		sleepShort();
		// new JsTreeSelector(webDriver, webDriverWait).expandTree(TREEDIV_ID);
		// sleepShort();
		uncheckRootPrivilege(moduleName.trim());
		int j = 0;
		for (String st : privGrpData) {
			String[] privileges = st.split(";");
			for (int i = 0; i < privileges.length; i++) {
				if (privileges[i].trim().contains("Open Form")) {
					doCheckUncheckPrivilege(formNames.get(j).trim(),
							privileges[i].trim());
				}
			}
			j++;
		}
		sleepVeryShort();
		updateBtn.click();
		waitForPageLoaded(webDriver);
		sleepShort();
		JsTreeSelector jsTreeSelector = new JsTreeSelector(webDriver,
				webDriverWait);
		jsTreeSelector.expandTree(TREEDIV_ID);
		boolean flag = true;
		j = 0;
		PrivilegesDataExecutor.formPrivileges = new HashMap<String, Map<String, Boolean>>();
		Map<String, Boolean> getPrivileges = new HashMap<String, Boolean>();

		for (String st : privGrpData) {
			String[] privileges = st.split(";");
			for (int i = 0; i < privileges.length; i++) {
				if (privileges[i].trim().contains("Open Form")) {
					System.out.println(formNames.get(j).trim()
							+ " "
							+ privileges[i].trim()
							+ "---------->>>>>>>"
							+ findCheckUncheckPrivilege(
									formNames.get(j).trim(),
									privileges[i].trim()));
					flag = flag
							&& findCheckUncheckPrivilege(formNames.get(j)
									.trim().trim(), privileges[i].trim());
					getPrivileges.put(privileges[i].trim(), flag);
				} else
					getPrivileges.put(privileges[i].trim(), false);
			}
			PrivilegesDataExecutor.formPrivileges.put(formNames.get(j).trim(),
					getPrivileges);
			j++;
		}
		PrivilegesDataExecutor.allModCollecPrivileges.put(moduleName,
				PrivilegesDataExecutor.formPrivileges);
		return flag;
	}

	// Check the privileges
	private void uncheckRootPrivilege(String moduleName)
			throws InterruptedException {
		String xpathEx = "//a[text()='" + moduleName.trim()
				+ "']/ins[@class='jstree-checkbox']";
		waitForElementXpathExpression(xpathEx);
		sleepVeryShort();
		String classValue = webDriver.findElement(By.xpath(xpathEx + "/../.."))
				.getAttribute("class");
		if (classValue.contains("jstree-checked")) {
			webDriver.findElement(By.xpath(xpathEx)).click();
		} else if (classValue.contains("jstree-undetermined")) {
			webDriver.findElement(By.xpath(xpathEx)).click();
			webDriver.findElement(By.xpath(xpathEx)).click();
		}
	}

	// Un-Check the privileges
	public void checkRootPrivilege(String moduleName)
			throws InterruptedException {
		String xpathEx = "//a[text()='" + moduleName.trim()
				+ "']/ins[@class='jstree-checkbox']";
		waitForElementXpathExpression(xpathEx);
		sleepVeryShort();
		String classValue = webDriver.findElement(By.xpath(xpathEx + "/../.."))
				.getAttribute("class");
		if (classValue.contains("jstree-undetermined")) {
			webDriver.findElement(By.xpath(xpathEx)).click();
		} else if (classValue.contains("jstree-unchecked")) {
			webDriver.findElement(By.xpath(xpathEx)).click();
		}
	}

	private void doCheckUncheckPrivilege(String formName, String PrivilegeName)
			throws InterruptedException {
		String xpathEx = "//a[text()='" + formName.trim()
				+ "']/..//a[contains(text(),'" + PrivilegeName.trim()
				+ "')]/ins[@class='jstree-checkbox']";
		waitForElementXpathExpression(xpathEx);
		webDriver.findElement(By.xpath(xpathEx)).click();
	}

	public boolean findCheckUncheckPrivilege(String formName,
			String PrivilegeName) throws InterruptedException {
		String xpathEx = "//a[text()='" + formName.trim()
				+ "']/..//a[contains(text(),'" + PrivilegeName.trim()
				+ "')]/ins[@class='jstree-checkbox']/../..";
		waitForElementXpathExpression(xpathEx);
		return webDriver.findElement(By.xpath(xpathEx)).getAttribute("class")
				.contains("jstree-checked");
	}

	public WebElement getPrivGrpAddModifyForm() {
		return privGrpAddModifyForm;
	}

	public WebElement getAddNewPrivGrpBtn() {
		return addNewPrivGrpBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getPrivGrpName() {
		return privGrpName;
	}

	public WebElement getPrivGrpDescription() {
		return privGrpDescription;
	}

	public WebElement getModule() {
		return module;
	}

	public WebElement getTreeSpan() {
		return treeSpan;
	}

	public WebElement getTreeDiv() {
		return treeDiv;
	}

	public WebElement getTreeCheckBox() {
		return treeCheckBox;
	}

	public WebElement getAuditTrail() {
		return auditTrail;
	}

}
