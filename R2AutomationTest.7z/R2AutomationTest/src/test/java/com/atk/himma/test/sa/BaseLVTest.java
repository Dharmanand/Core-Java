package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.masters.BaseLVPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class BaseLVTest extends SeleniumDriverSetup {
	BaseLVPage baseLVPage;

	@Test(description = "Open BaseLOV Page")
	public void openBaseLV() throws Exception {
		baseLVPage = PageFactory.initElements(webDriver, BaseLVPage.class);
		baseLVPage = baseLVPage.clickOnBaseLVMenu(webDriver, webDriverWait);
		baseLVPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		Assert.assertNotNull(baseLVPage);
		baseLVPage.waitForElementVisibilityOf(baseLVPage.getBaseLoVListTab()
				.getBaseLVSearchForm());
		Assert.assertTrue(baseLVPage.getBaseLoVListTab().getModuleName()
				.isDisplayed());

	}

	@Test(description = "Check for Add New Base LoV", dependsOnMethods = { "openBaseLV" })
	public void checkForAddNewBaseLoVBtn() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVListTab().getAddNewBaseLoVBtn()
				.isDisplayed());
	}

	@Test(description = "Click On Add New BaseLoV Button", dependsOnMethods = { "checkForAddNewBaseLoVBtn" })
	public void clickOnAddNewBaseLoVBtn() throws Exception {
		baseLVPage.getBaseLoVListTab().clickOnAddBaseLoVBtn();
		baseLVPage.waitForElementVisibilityOf(baseLVPage.getBaseLoVDetailsTab()
				.getModuleName());
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().getModuleName()
				.isDisplayed());
	}

	@Test(description = "Validate Module Name Mandatory Field", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void validateModuleNameMandatoryField() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().isMandModuleName());
	}

	@Test(description = "Validate Entity Mandatory Field", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void validateEntityMandatoryField() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().isMandEntity());
	}

	@Test(description = "Validate Language Mandatory Field", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void validateLanguageMandatoryField() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().isMandLanguage());
	}

	@Test(description = "Validate Status Mandatory Field", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void validateStatusMandatoryField() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().isMandStatus());
	}

	@Test(description = "Validate Short Name Mandatory Field", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void validateShortNameMandatoryField() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().isMandShortName());
	}

	@Test(description = "Validate Long Name Mandatory Field", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void validateLongNameMandatoryField() throws Exception {
		Assert.assertTrue(baseLVPage.getBaseLoVDetailsTab().isMandLongName());
	}

	@Test(description = "Add BaseLOV", dependsOnMethods = { "clickOnAddNewBaseLoVBtn" })
	public void addBaseLoV() throws Exception {
		List<String[]> baseLoVList = excelReader.read(properties.getProperty("baseLov").trim());
		if (baseLoVList != null && !baseLoVList.isEmpty()) {
			for (String[] baseLVData : baseLoVList) {
				baseLVPage.getBaseLoVDetailsTab().addBaseLoV(baseLVData);
				Assert.assertNotNull(baseLVPage.getBaseLoVDetailsTab()
						.getUpdateBtn());
				baseLVPage.getBaseLoVDetailsTab().waitForElementVisibilityOf(
						baseLVPage.getBaseLoVDetailsTab().getAddNewBaseLVBtn());
				baseLVPage.getBaseLoVDetailsTab().clickAddNewDtls();
				baseLVPage.getBaseLoVDetailsTab().waitForElementVisibilityOf(
						baseLVPage.getBaseLoVDetailsTab().getSaveBtn());
				Assert.assertNotNull(baseLVPage.getBaseLoVDetailsTab()
						.getSaveBtn());
			}
		}
	}
	
	//[Base LV] Open Form
		@Test(description = "Checking for BaseLOV Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
		public void checkBaseLVMenuLink() throws Exception {
			excelReader.setInputFile(properties.getProperty("SAExcel").trim());
			baseLVPage = PageFactory.initElements(webDriver, BaseLVPage.class);
			MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
			List<String> baseLVParentMenuList = new LinkedList<String>();
			baseLVParentMenuList.add("System Administration");
			baseLVParentMenuList.add("Masters ");
			menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList, "Base LV");
			baseLVPage.setWebDriver(webDriver);
			baseLVPage.setWebDriverWait(webDriverWait);
			baseLVPage.waitForElementXpathExpression(BaseLVPage.MENULINK_XPATH);

			boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
					.get("System Admin").get("Base LV")
					.get("[Base LV] Open Form");
			System.out.println("privFilter----------> " + actualPrivilage);
			boolean expectedPrivilage = PrivilegesDataExecutor
					.testPrivilege(webDriver, By.xpath(BaseLVPage.MENULINK_XPATH));
			System.out
					.println("ExpectedPrivilage --------->> " + expectedPrivilage);
			Assert.assertEquals(actualPrivilage, expectedPrivilage,
					"Fail to check [Base LV] Open Form privilege");
			if (actualPrivilage && expectedPrivilage) {
				baseLVPage = baseLVPage.clickOnBaseLVMenu(webDriver, webDriverWait);
				baseLVPage.initPages(webDriver, webDriverWait);
				doDirtyFormCheck();
				Assert.assertNotNull(baseLVPage);
				baseLVPage.waitForElementVisibilityOf(baseLVPage
						.getBaseLoVListTab().getBaseLVSearchForm());
				baseLVPage.sleepShort();
				Assert.assertEquals(baseLVPage.getPageTitle().getText(), "Base LoV");
			}
		}

}
