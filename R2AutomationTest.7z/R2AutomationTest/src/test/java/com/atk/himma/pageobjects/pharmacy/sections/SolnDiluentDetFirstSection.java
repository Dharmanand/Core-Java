package com.atk.himma.pageobjects.pharmacy.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SolnDiluentDetFirstSection {

	public final static String FORM_ID = "SOL_DILUENT_DETAILS";
	public final static String SAVEBUTTON_CSS = ".buttoncontainer_vlrg_top + input";
	public final static String CANCELBUTTON_ID = "SOL_DILUENT_CANCEL_UP";
	public final static String SOLNDILCODE_NAME = "drugCompSolDiluent.code.code";
	public final static String SOLNDILSHDESC_ID = "SHORT_DESC";
	public final static String SOLNDILDESC_ID = "DESCRIPTION";
	public final static String DEFAULTUOM_ID = "UOM";
	public final static String ROUTE_ID = "ROUTE";
	public final static String ITEMCATEGORY_CSS = "#SOL_DILUENT_DETAILS_drugCompSolDiluent_itemCategory + input";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = SAVEBUTTON_CSS)
	private WebElement saveButton;

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	@FindBy(name = SOLNDILCODE_NAME)
	private WebElement solnDilCode;

	@FindBy(id = SOLNDILSHDESC_ID)
	private WebElement solnDilShortDesc;

	@FindBy(id = DEFAULTUOM_ID)
	private WebElement defaultUOM;

	@FindBy(id = ROUTE_ID)
	private WebElement route;

	public WebElement getForm() {
		return form;
	}

	public WebElement getSaveButton() {
		return saveButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getSolnDilCode() {
		return solnDilCode;
	}

	public WebElement getSolnDilShortDesc() {
		return solnDilShortDesc;
	}

	public WebElement getDefaultUOM() {
		return defaultUOM;
	}

	public WebElement getRoute() {
		return route;
	}

	public WebElement getItemCategory() {
		return itemCategory;
	}

	@FindBy(id = ITEMCATEGORY_CSS)
	private WebElement itemCategory;
}
