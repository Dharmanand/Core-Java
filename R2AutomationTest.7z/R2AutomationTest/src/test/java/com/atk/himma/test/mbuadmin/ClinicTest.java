package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.ClinicPage;
import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.AppointmentParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.ClinicFirstSection;
import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.TimeDuraConsulServices;
import com.atk.himma.pageobjects.mbuadmin.tabs.ClinicListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class ClinicTest extends SeleniumDriverSetup {

	List<String[]> clinicDatas;
	ClinicPage clinicPage;

	@Test(description = "Open Clinic Page")
	public void clickOnClinicMenu() throws InterruptedException {
		clinicPage = PageFactory.initElements(webDriver, ClinicPage.class);
		clinicPage = clinicPage.clickOnClinicMenu(webDriver, webDriverWait);
		clinicPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		clinicPage
				.waitForElementXpathExpression(ClinicListTab.SEARCHBUTTON_XPATH);
		clinicPage.sleepShort();
		Assert.assertEquals(clinicPage.getClinicListTab().getClinicListTab()
				.getAttribute("title").trim(), "Clinic List",
				"Fail to open Clinic List.");
	}

	// [Clinic] Open Form
	@Test(description = "Open Clinic Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkClinicMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		clinicPage = PageFactory.initElements(webDriver, ClinicPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Clinic");
		clinicPage.setWebDriver(webDriver);
		clinicPage.setWebDriverWait(webDriverWait);
		clinicPage.waitForElementXpathExpression(ClinicPage.MENULINK_XPATH);
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Clinic")
				.get("[Clinic] Open Form");
		System.out.println("privFilter----------> " + actualPrivilege);
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ClinicPage.MENULINK_XPATH));
		System.out
				.println("expectedPrivilege --------->> " + expectedPrivilege);
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail to check [Clinic] Open Form privilege");
		if (actualPrivilege && expectedPrivilege) {
			clinicPage = clinicPage.clickOnClinicMenu(webDriver, webDriverWait);
			clinicPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			clinicPage
					.waitForElementXpathExpression(ClinicListTab.SEARCHBUTTON_XPATH);
			clinicPage.sleepShort();
			Assert.assertEquals(clinicPage.getClinicListTab()
					.getClinicListTab().getAttribute("title").trim(),
					"Clinic List", "Fail to open Clinic List.");
			clinicPage.waitForElementId(ClinicListTab.ADDNEWCLINICBUTTON_ID);
			clinicPage.sleepVeryShort();
			clinicPage.getClinicListTab().getAddNewClinicButton().click();
			clinicPage.waitForElementId(ClinicFirstSection.MBU_ID);
			clinicPage.waitForElementId(ClinicFirstSection.CLINICSHORTNAME_ID);
			clinicPage.sleepShort();
		}
	}

	@Test(description = "click On Add New Button", dependsOnMethods = "clickOnClinicMenu")
	public void test1ClickOnAddNewButton() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		clinicDatas = excelReader.read(properties.getProperty("clinic"));
		for (String st[] : clinicDatas)
			Assert.assertEquals(clinicPage.clickOnAddNewButton(st), true,
					"Fail to click On Add New Button.");
	}

	@Test(description = "click Mandatory Clinic Short Name", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test2IsMandatoryClinicShName() {
		Assert.assertEquals(clinicPage.getClinicFirstSection()
				.isMandatoryClinicShName(), true,
				"Fail to Mandatory Clinic Short Name.");
	}

	@Test(description = "click Mandatory Clinic Name", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test3IsMandatoryClinicName() {
		Assert.assertEquals(clinicPage.getClinicFirstSection()
				.isMandatoryClinicName(), true,
				"Fail to Mandatory Clinic Name.");
	}

	@Test(description = "click Mandatory MBU", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test4IsMandatoryMBU() {
		Assert.assertEquals(
				clinicPage.getClinicFirstSection().isMandatoryMBU(), true,
				"Fail to Mandatory MBU.");
	}

	@Test(description = "Fill datas of Clinic First Section", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test5FillServiceFirstSecDatas() throws InterruptedException {
		for (String st[] : clinicDatas)
			Assert.assertEquals(clinicPage.getClinicFirstSection()
					.fillServiceFirstSecDatas(st), true,
					"Fail to Fill datas of Clinic First Section");
	}

	@Test(description = "check Time Duration for Consultation Services Section", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test6CheckTimeDurConSerSection() throws InterruptedException {
		Assert.assertEquals(clinicPage.getTimeDuraConsulServices()
				.checkSection(), true,
				"Fail to Check Time Duration for Consultation Services Section");
	}

	@Test(description = "check Appointment Parameters Section", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test7CheckAppointParamSection() throws InterruptedException {
		Assert.assertEquals(clinicPage.getAppointmentParameters()
				.checkAppointParamSection(), true,
				"Fail to Check Appointment Parameters Section");
	}

	@Test(description = "Fill datas of Time Duration for Consultation Services", dependsOnMethods = "test6CheckTimeDurConSerSection")
	public void test8FillTimeDurConSerDatas() throws InterruptedException {
		for (String st[] : clinicDatas)
			Assert.assertEquals(clinicPage.getTimeDuraConsulServices()
					.fillDatas(st), true,
					"Fail to Fill datas of Time Duration for Consultation Services Section");
	}
	
	/*@Test(description = "Fill datas of Appointment Parameters", dependsOnMethods = "test7CheckAppointParamSection")
	public void fillAppointParamDatas() throws InterruptedException {
		for (String st[] : clinicDatas)
			Assert.assertEquals(clinicPage.getAppointmentParameters()
					.fillDatas(st), true,
					"Fail to Fill datas of Appointment Parameters Section");
	}*/

	@Test(description = "Save Service", dependsOnMethods = "test8FillTimeDurConSerDatas")
	public void test9SaveClinic() throws InterruptedException, IOException {
		Assert.assertEquals(clinicPage.saveDetailsPage().contains("Update"),
				true, "Fail to Save Service.");
	}

	@Test(description = "Activate Service", dependsOnMethods = "test9SaveClinic")
	public void test10ActivateClinic() throws InterruptedException, IOException {
		Assert.assertEquals(clinicPage.activateClinic().contains("Active"),
				true, "Fail to Activate Service.");
	}

	@Test(description="Check Duplicate Clinic Data", dependsOnMethods={"test9SaveClinic"})
	public void test11SaveDuplicateClinic() throws InterruptedException, IOException {
		for (String st[] : clinicDatas)
		{
			clinicPage.waitForElementXpathExpression(ClinicPage.DETAILSUPDATEBUTTON_XPATH);
			clinicPage.getAddNewButton().click();
			clinicPage.waitForElementXpathExpression(ClinicPage.DETAILSSAVEBUTTON_XPATH);
			Assert.assertEquals(clinicPage.getClinicFirstSection()
					.fillServiceFirstSecDatas(st), true,
					"Fail to Fill datas of Clinic First Section");
			Assert.assertEquals(clinicPage.getTimeDuraConsulServices()
					.fillDatas(st), true,
					"Fail to Fill datas of Time Duration for Consultation Services Section");
			Assert.assertTrue(clinicPage.saveDuplicateData(st),"Fail to Check Duplicate Clinic Data");
		}
	}
	
	
	// [Details Tab] [Section: Time Duration for Consultation Services] View
	@Test(dependsOnMethods = { "checkClinicMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Time Duration for Consultation Services section privileges")
	public void checkTimeDurConsulSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Clinic")
				.get("[Details Tab] [Section: Time Duration for Consultation Services] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(TimeDuraConsulServices.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(
				actualPrivilege,
				expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Time Duration for Consultation Services] View");
	}

	// [Details Tab] [Section: Appointment Parameters] View
	@Test(dependsOnMethods = { "checkClinicMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking Appointment Parameters section privileges")
	public void checkAppointParamSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Clinic")
				.get("[Details Tab] [Section: Appointment Parameters] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(AppointmentParameters.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Appointment Parameters] View");
	}

	/*@Test(dependsOnMethods = { "checkClinicMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Clinic for Privilege")
	public void searchClinicForPrivilege() throws Exception {
		clinicPage.clickClinicListTab();
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		clinicDatas = excelReader.read(properties.getProperty("clinic"));
		for (String st[] : clinicDatas.subList(0, 1))
			Assert.assertEquals(clinicPage.searchClinic(st), st[7].trim(),
					"Fail to Search Clinic result");
	}

	// [List Tab] Add New (Button)
	@Test(dependsOnMethods = { "searchClinicForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Check [List Tab] Add New (Button) Privilege")
	public void checkAddNewButtonPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Clinic")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(ClinicListTab.ADDNEWCLINICBUTTON_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");
	}
		
	// [List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchClinicForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check View link for Privilege")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Clinic")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ clinicDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");

	}

	// [List Tab] Delete(Link in the search result grid)
	@Test(dependsOnMethods = { "searchClinicForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Check Delete Link for Privilege")
	public void checkDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Clinic")
				.get("[List Tab] Delete(Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ clinicDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete(Link in the search result grid) privilege");
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "searchClinicForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Check Edit Link for Privilege")
	public void checkEditLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Clinic")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ clinicDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
	}*/
}
