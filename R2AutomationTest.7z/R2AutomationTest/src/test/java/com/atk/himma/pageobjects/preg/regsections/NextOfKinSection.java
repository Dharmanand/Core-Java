package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class NextOfKinSection extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Next of Kin";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	private final static String KINMRNLOOKUP_LINKTEXT = "kinsMrnid";
	
	@FindBy(linkText = KINMRNLOOKUP_LINKTEXT)
	private WebElement kinMrnLookup;

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the kinmrnlookupLinktext
	 */
	public static String getKinmrnlookupLinktext() {
		return KINMRNLOOKUP_LINKTEXT;
	}

	/**
	 * @return the kinMrnLookup
	 */
	public WebElement getKinMrnLookup() {
		return kinMrnLookup;
	}
	

}
