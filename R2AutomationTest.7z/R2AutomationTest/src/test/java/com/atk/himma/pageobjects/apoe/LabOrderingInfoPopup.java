package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class LabOrderingInfoPopup extends DriverWaitClass {
	public final static String LABORDERPOPUPFORM_ID = "LAB_ORDER_POPUP";
	@FindBy(id = LABORDERPOPUPFORM_ID)
	private WebElement labOrderPopupForm;

	public final static String SPECIMENSOURCE_ID = "SPEICIMEN_SOURCE";
	@FindBy(id = SPECIMENSOURCE_ID)
	private WebElement specimensource;

	public final static String SURGICALPROCEDURE_ID = "SURGICAL_PROCEDURE";
	@FindBy(id = SURGICALPROCEDURE_ID)
	private WebElement surgicalProcedure;

	public final static String CLINICALDIAGNOSIS_ID = "CLINICAL_DIAGNOSIS";
	@FindBy(id = CLINICALDIAGNOSIS_ID)
	private WebElement clinicalDiagnosis;

	public final static String CLINICALINFORMATION_ID = "CLINICAL_INFORMATION";
	@FindBy(id = CLINICALINFORMATION_ID)
	private WebElement clinicalInformation;

	public final static String URGENCY_ID = "URGENCY";
	@FindBy(id = URGENCY_ID)
	private WebElement urgency;

	public final static String PERFORMNGLOC_ID = "PERFORMING_LOCATION";
	@FindBy(id = PERFORMNGLOC_ID)
	private WebElement performingLoc;

	public final static String SPECIMEN_ID = "SPECIMEN";
	@FindBy(id = SPECIMEN_ID)
	private WebElement specimen;

	public final static String ORDINFODATETIMEIMG_XPATH = "//input[@id='PREF_DATE_TIME']/../img";
	@FindBy(xpath = ORDINFODATETIMEIMG_XPATH)
	private WebElement ordInfoDateTimeImg;

	public final static String NOWBUTTON_XPATH = "//div[@id='ui-datepicker-div']//button[@class='ui-datepicker-current ui-state-default ui-priority-primary ui-corner-all']";
	@FindBy(xpath = NOWBUTTON_XPATH)
	private WebElement nowBtn;

	public final static String ADDDEPTINSTRNBTN_ID = "ADD_DEP_INSTRUCTIONS";
	@FindBy(id = ADDDEPTINSTRNBTN_ID)
	private WebElement addDeptInstructionBtn;

	public final static String ADDDEPTINSTRNACTBTN_ID = "ADD_DEP_INSTRUCTIONS_ACTION";
	@FindBy(id = ADDDEPTINSTRNACTBTN_ID)
	private WebElement addDeptInstructionActBtn;

	public final static String CANCELDEPTINSTRNBTN_ID = "CANCEL_DEP_INSTRUCTIONS_ACTION";
	@FindBy(id = CANCELDEPTINSTRNBTN_ID)
	private WebElement cancelDeptInstructionBtn;

	public final static String DEPTINSTRNTEXT_ID = "DEP_INS_TEXT";
	@FindBy(id = DEPTINSTRNTEXT_ID)
	private WebElement deptInstrnText;

	public final static String ADDPATINSTRNBTN_ID = "ADD_PAT_INSTRUCTIONS";
	@FindBy(id = ADDPATINSTRNBTN_ID)
	private WebElement addPatInstructionBtn;

	public final static String ADDPATINSTRNACTBTN_ID = "ADD_PAT_INSTRUCTIONS_ACTION";
	@FindBy(id = ADDPATINSTRNACTBTN_ID)
	private WebElement addPatInstructionActBtn;

	public final static String CANCELPATINSTRNBTN_ID = "CANCEL_PAT_INSTRUCTIONS_ACTION";
	@FindBy(id = CANCELPATINSTRNBTN_ID)
	private WebElement cancelPatInstructionBtn;

	public final static String PATINSTRNTEXT_ID = "PAT_INS_TEXT";
	@FindBy(id = PATINSTRNTEXT_ID)
	private WebElement patInstrnText;

	public final static String APPLFREQCHKBOX_ID = "APPLICABLE_FREQUENCY";
	@FindBy(id = APPLFREQCHKBOX_ID)
	private WebElement applFreqChkBox;

	public final static String APPLFREQSTARTDATE_ID = "APP_FREQ_START_DATE_TIME";
	@FindBy(id = APPLFREQSTARTDATE_ID)
	private WebElement applFreqStartDate;

	public final static String APPLFREQSTARTDATETIMEIMG_XPATH = "//input[@id='APP_FREQ_START_DATE_TIME']/../img";
	@FindBy(xpath = APPLFREQSTARTDATETIMEIMG_XPATH)
	private WebElement applFreqStartDateTimeImg;

	public final static String APPLFREQENDDATE_ID = "APP_FREQ_START_DATE_TIME";
	@FindBy(id = APPLFREQENDDATE_ID)
	private WebElement applFreqEndDate;

	public final static String APPLFREQENDDATETIMEIMG_XPATH = "//input[@id='APP_FREQ_STOP_DATE_TIME']/../img";
	@FindBy(xpath = APPLFREQENDDATETIMEIMG_XPATH)
	private WebElement applFreqEndDateTimeImg;

	public final static String REPEATFREQ_ID = "REPEAT_FREQUENCY";
	@FindBy(id = REPEATFREQ_ID)
	private WebElement repeatFrequency;

	public final static String REPEATFREQTYPE_ID = "REPEAT_FREQUENCY_TYPE";
	@FindBy(id = REPEATFREQTYPE_ID)
	private WebElement repeatFrequencyType;

	public final static String LABNOOFREPET_ID = "LAB_NO_OF_REPETITION";
	@FindBy(id = LABNOOFREPET_ID)
	private WebElement labNoOfRepet;

	public final static String LABADDTOSEL_ID = "SAVE_ADD";
	@FindBy(id = LABADDTOSEL_ID)
	private WebElement labAddToSelList;

	public final static String LABORDERDTLRESET_ID = "LAB_ORDER_DETAIL_RESET";
	@FindBy(id = LABORDERDTLRESET_ID)
	private WebElement labOrderDetlReset;

	public void addLabOrderInfo(String[] orderEntryListData) {
		waitForElementId(LABORDERPOPUPFORM_ID);
		if (!orderEntryListData[59].isEmpty()) {
			new Select(urgency).selectByVisibleText(orderEntryListData[59]);
		}
		if (!orderEntryListData[60].isEmpty()) {
			new Select(performingLoc)
					.selectByVisibleText(orderEntryListData[60]);
		}
		if (!orderEntryListData[61].isEmpty()) {
			new Select(specimen).selectByVisibleText(orderEntryListData[61]);
		}
		deptInstrnText.clear();
		deptInstrnText.sendKeys(orderEntryListData[62]);
		patInstrnText.clear();
		patInstrnText.sendKeys(orderEntryListData[63]);
		if (Boolean.valueOf(orderEntryListData[64])) {
			applFreqChkBox.click();
			applFreqStartDate.clear();
			applFreqStartDate.sendKeys(orderEntryListData[65]);
			applFreqEndDate.clear();
			applFreqEndDate.sendKeys(orderEntryListData[66]);
			repeatFrequency.clear();
			repeatFrequency.sendKeys(orderEntryListData[67]);
			if (!orderEntryListData[68].isEmpty()) {
				new Select(repeatFrequencyType)
						.selectByVisibleText(orderEntryListData[68]);
			}
		}
		labAddToSelList.click();
	}

	public WebElement getLabOrderPopupForm() {
		return labOrderPopupForm;
	}

	public WebElement getSpecimensource() {
		return specimensource;
	}

	public WebElement getSurgicalProcedure() {
		return surgicalProcedure;
	}

	public WebElement getClinicalDiagnosis() {
		return clinicalDiagnosis;
	}

	public WebElement getClinicalInformation() {
		return clinicalInformation;
	}

	public WebElement getUrgency() {
		return urgency;
	}

	public WebElement getPerformingLoc() {
		return performingLoc;
	}

	public WebElement getSpecimen() {
		return specimen;
	}

	public WebElement getOrdInfoDateTimeImg() {
		return ordInfoDateTimeImg;
	}

	public WebElement getNowBtn() {
		return nowBtn;
	}

	public WebElement getAddDeptInstructionBtn() {
		return addDeptInstructionBtn;
	}

	public WebElement getAddDeptInstructionActBtn() {
		return addDeptInstructionActBtn;
	}

	public WebElement getCancelDeptInstructionBtn() {
		return cancelDeptInstructionBtn;
	}

	public WebElement getDeptInstrnText() {
		return deptInstrnText;
	}

	public WebElement getAddPatInstructionBtn() {
		return addPatInstructionBtn;
	}

	public WebElement getAddPatInstructionActBtn() {
		return addPatInstructionActBtn;
	}

	public WebElement getCancelPatInstructionBtn() {
		return cancelPatInstructionBtn;
	}

	public WebElement getPatInstrnText() {
		return patInstrnText;
	}

	public WebElement getApplFreqChkBox() {
		return applFreqChkBox;
	}

	public WebElement getApplFreqStartDate() {
		return applFreqStartDate;
	}

	public WebElement getApplFreqStartDateTimeImg() {
		return applFreqStartDateTimeImg;
	}

	public WebElement getApplFreqEndDate() {
		return applFreqEndDate;
	}

	public WebElement getApplFreqEndDateTimeImg() {
		return applFreqEndDateTimeImg;
	}

	public WebElement getRepeatFrequency() {
		return repeatFrequency;
	}

	public WebElement getRepeatFrequencyType() {
		return repeatFrequencyType;
	}

	public WebElement getLabNoOfRepet() {
		return labNoOfRepet;
	}

	public WebElement getLabAddToSelList() {
		return labAddToSelList;
	}

	public WebElement getLabOrderDetlReset() {
		return labOrderDetlReset;
	}

}
