package com.atk.himma.pageobjects.appointsched.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ResourceCalendarListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "resCalSearchForm";
	public final static String RESCALLISTTAB_XPATH = "//a[@title='Resource Calendar List']";
	public final static String CALENDERTYPE_ID = "resCalTypeSearchDD";
	public final static String MBU_ID = "mbusId";
	public final static String DEPARTMENT_ID = "deptId";
	public final static String SPECAILITY_ID = "specId";
	public final static String SUBSPECAILITY_ID = "subSpecId";
	public final static String RESCATEGORY_ID = "resourceCategory";
	public final static String RESTYPE_ID = "resourceTypeId";
	public final static String RESOURCENAME_NAME = "searchCriteria.resourceName";
	public final static String LOCATIONNAME_NAME = "searchCriteria.locationName";
	public final static String LOCATIONCODE_NAME = "searchCriteria.locationCode";
	public final static String RESOURCECODE_NAME = "searchCriteria.resourceCode";
	public final static String CALENDERSTATUS_NAME = "searchCriteria.calendarStatus";
	public final static String SEARCHBUTTON_ID = "CAL_LIST_SEARCH_BUTTON";
	public final static String RESETBUTTON_ID = "RES_LIST_RESET_BUTTON";
	
//	Grid
	public final static String GRID_ID = "resourceCalendarDetailsGrid";
	
//	For Calendar Type(Resource) in Grid
	public final static String GRID_RESOURCECODE_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_resource.resourceCode";
	public final static String GRID_RESOURCENAME_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_resource.resourceName.fullName";
	public final static String GRID_SPECIALTY_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_resource.specialityText";
	
//	For Calendar Type(Location) in Grid
	public final static String GRID_LOCATIONNAME_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_resource.locationName";
	public final static String GRID_LOCATIONCODE_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_resource.locationCode";
	
//	Resource and Location common in Grid
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_resource.departmentText";
	public final static String GRID_CALENDARPERIOD_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_calendarPeriod";
	public final static String GRID_SERVICELOCATION_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_location";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "resourceCalendarDetailsGrid_status";
	public final static String GRID_PAGERID = "sp_1_resourceCalendarDetailsGrid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_resourceCalendarDetailsGrid_pager']";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = RESCALLISTTAB_XPATH)
	private WebElement resCalListTab;
	
	@FindBy(id = CALENDERTYPE_ID)
	private WebElement calenderType;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SPECAILITY_ID)
	private WebElement specaility;
	
	@FindBy(id = SUBSPECAILITY_ID)
	private WebElement subSpecaility;
	
	@FindBy(id = RESCATEGORY_ID)
	private WebElement resCategory;
	
	@FindBy(id = RESTYPE_ID)
	private WebElement resType;
	
	@FindBy(name = RESOURCENAME_NAME)
	private WebElement resourceName;
	
	@FindBy(name = LOCATIONNAME_NAME)
	private WebElement locationName;
	
	@FindBy(name = LOCATIONCODE_NAME)
	private WebElement locationCode;
	
	@FindBy(name = RESOURCECODE_NAME)
	private WebElement resourceCode;
	
	@FindBy(name = CALENDERSTATUS_NAME)
	private WebElement calenderStatus;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(id = RESETBUTTON_ID)
	private WebElement resetButton;

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	// pager
	@FindBy(id = GRID_PAGERID)
	private WebElement searchPager;
	
	@FindBy(xpath = GRID_NEXTPAGE_XPATH)
	private WebElement nextPage;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the resCalListTab
	 */
	public WebElement getResCalListTab() {
		return resCalListTab;
	}

	/**
	 * @return the calenderType
	 */
	public WebElement getCalenderType() {
		return calenderType;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the specaility
	 */
	public WebElement getSpecaility() {
		return specaility;
	}

	/**
	 * @return the subSpecaility
	 */
	public WebElement getSubSpecaility() {
		return subSpecaility;
	}

	/**
	 * @return the resCategory
	 */
	public WebElement getResCategory() {
		return resCategory;
	}

	/**
	 * @return the resType
	 */
	public WebElement getResType() {
		return resType;
	}

	/**
	 * @return the resourceName
	 */
	public WebElement getResourceName() {
		return resourceName;
	}

	/**
	 * @return the resourceCode
	 */
	public WebElement getResourceCode() {
		return resourceCode;
	}

	/**
	 * @return the calenderStatus
	 */
	public WebElement getCalenderStatus() {
		return calenderStatus;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the searchGrid
	 */
	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the searchPager
	 */
	public WebElement getSearchPager() {
		return searchPager;
	}

	/**
	 * @return the nextPage
	 */
	public WebElement getNextPage() {
		return nextPage;
	}

	/**
	 * @return the locationName
	 */
	public WebElement getLocationName() {
		return locationName;
	}

	/**
	 * @return the locationCode
	 */
	public WebElement getLocationCode() {
		return locationCode;
	}

}
