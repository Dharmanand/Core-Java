package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class SensitivityPanelDetailsDefaultSec extends DriverWaitClass {
	public final static String ADDNEWBTN_XPATH = "//input[@value='Add New']";
	@FindBy(xpath = ADDNEWBTN_XPATH)
	private WebElement addNewBtn;

	public final static String SAVEBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	@FindBy(xpath = SAVEBTN_XPATH)
	private WebElement saveBtn;

	public final static String UPDATEBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Update']";
	@FindBy(xpath = UPDATEBTN_XPATH)
	private WebElement updateBtn;

	public final static String CANCELBTN_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	@FindBy(xpath = CANCELBTN_XPATH)
	private WebElement cancelBtn;

	public final static String SENSPANELCODE_NAME = "sensitivityPanel.sensitivityPanelCode";
	@FindBy(name = SENSPANELCODE_NAME)
	private WebElement sensPanelCode;

	public final static String SENSPANELSHNAME_ID = "SHORT_NAME";
	@FindBy(id = SENSPANELSHNAME_ID)
	private WebElement sensPanelShName;

	public final static String SENSPANELDESC_NAME = "sensitivityPanel.sensitivityPanelDescription";
	@FindBy(name = SENSPANELDESC_NAME)
	private WebElement sensPanelDesc;

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getSensPanelCode() {
		return sensPanelCode;
	}

	public WebElement getSensPanelShName() {
		return sensPanelShName;
	}

	public WebElement getSensPanelDesc() {
		return sensPanelDesc;
	}

}
