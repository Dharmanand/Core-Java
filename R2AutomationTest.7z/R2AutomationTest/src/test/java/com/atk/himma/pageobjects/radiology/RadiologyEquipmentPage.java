package com.atk.himma.pageobjects.radiology;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.pageobjects.radiology.sections.ConsumablesSection;
import com.atk.himma.pageobjects.radiology.sections.RadEquipmentFirstSection;
import com.atk.himma.pageobjects.radiology.sections.RadiologyDetailsSection;
import com.atk.himma.pageobjects.radiology.tabs.RadEquipmentList;
import com.atk.himma.util.DriverWaitClass;

public class RadiologyEquipmentPage extends DriverWaitClass {
	
	RadEquipmentList radEquipmentList;
	RadEquipmentFirstSection radEquipmentFirstSection;
	RadiologyDetailsSection radiologyDetailsSection;
	ConsumablesSection consumablesSection;
	
	public final static String RADEQUIPLINK_LINKTEXT = "Radiology Equipment";
	public final static String RADEQUIPLISTTAB_LINKTEXT = "Radiology Equipment List";
	public final static String RADEQUIPDETAILSTAB_LINKTEXT = "Radiology Equipment Details";

	public final static String FORM_ID = "EQUIPMENT_DETAILS_FORM";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Save']";
	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Update']";
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']/input[@value='Cancel']";

	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;
	
	@FindBy(linkText = RADEQUIPLINK_LINKTEXT)
	private WebElement radEquipMenuLink;

	@FindBy(linkText = RADEQUIPLISTTAB_LINKTEXT)
	private WebElement radEquipListTabLink;

	@FindBy(linkText = RADEQUIPDETAILSTAB_LINKTEXT)
	private WebElement radEquipDetailsTabLink;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @param form the form to set
	 */
	public void setForm(WebElement form) {
		this.form = form;
	}

	/**
	 * @param saveButton the saveButton to set
	 */
	public void setSaveButton(WebElement saveButton) {
		this.saveButton = saveButton;
	}

	/**
	 * @param updateButton the updateButton to set
	 */
	public void setUpdateButton(WebElement updateButton) {
		this.updateButton = updateButton;
	}

	/**
	 * @param cancelButton the cancelButton to set
	 */
	public void setCancelButton(WebElement cancelButton) {
		this.cancelButton = cancelButton;
	}

	/**
	 * @return the radEquipmentList
	 */
	public RadEquipmentList getRadEquipmentList() {
		return radEquipmentList;
	}

	/**
	 * @return the radEquipmentFirstSection
	 */
	public RadEquipmentFirstSection getRadEquipmentFirstSection() {
		return radEquipmentFirstSection;
	}

	/**
	 * @return the radiologyDetailsSection
	 */
	public RadiologyDetailsSection getRadiologyDetailsSection() {
		return radiologyDetailsSection;
	}

	/**
	 * @return the consumablesSection
	 */
	public ConsumablesSection getConsumablesSection() {
		return consumablesSection;
	}

	/**
	 * @return the radEquipMenuLink
	 */
	public WebElement getRadEquipMenuLink() {
		return radEquipMenuLink;
	}

	/**
	 * @return the radEquipListTabLink
	 */
	public WebElement getRadEquipListTabLink() {
		return radEquipListTabLink;
	}

	/**
	 * @return the radEquipDetailsTabLink
	 */
	public WebElement getRadEquipDetailsTabLink() {
		return radEquipDetailsTabLink;
	}

	/**
	 * @param radEquipmentList the radEquipmentList to set
	 */
	public void setRadEquipmentList(RadEquipmentList radEquipmentList) {
		this.radEquipmentList = radEquipmentList;
	}

	/**
	 * @param radEquipmentFirstSection the radEquipmentFirstSection to set
	 */
	public void setRadEquipmentFirstSection(
			RadEquipmentFirstSection radEquipmentFirstSection) {
		this.radEquipmentFirstSection = radEquipmentFirstSection;
	}

	/**
	 * @param radiologyDetailsSection the radiologyDetailsSection to set
	 */
	public void setRadiologyDetailsSection(
			RadiologyDetailsSection radiologyDetailsSection) {
		this.radiologyDetailsSection = radiologyDetailsSection;
	}

	/**
	 * @param consumablesSection the consumablesSection to set
	 */
	public void setConsumablesSection(ConsumablesSection consumablesSection) {
		this.consumablesSection = consumablesSection;
	}

	/**
	 * @param radEquipMenuLink the radEquipMenuLink to set
	 */
	public void setRadEquipMenuLink(WebElement radEquipMenuLink) {
		this.radEquipMenuLink = radEquipMenuLink;
	}

	/**
	 * @param radEquipListTabLink the radEquipListTabLink to set
	 */
	public void setRadEquipListTabLink(WebElement radEquipListTabLink) {
		this.radEquipListTabLink = radEquipListTabLink;
	}

	/**
	 * @param radEquipDetailsTabLink the radEquipDetailsTabLink to set
	 */
	public void setRadEquipDetailsTabLink(WebElement radEquipDetailsTabLink) {
		this.radEquipDetailsTabLink = radEquipDetailsTabLink;
	}
}
