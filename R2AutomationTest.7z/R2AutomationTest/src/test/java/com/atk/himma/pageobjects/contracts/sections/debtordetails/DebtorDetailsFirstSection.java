package com.atk.himma.pageobjects.contracts.sections.debtordetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class DebtorDetailsFirstSection extends DriverWaitClass {
	public final static String DEBTORCODE_ID = "DEBTOR_SCG_CODE";
	public final static String DEBTORSHNAME_NAME = "debtor.debtorShortName";
	public final static String DEBTORNAME_NAME = "debtor.debtorName";
	public final static String DEBTORNAMEAR_NAME = "debtor.debtorNameAr";
	public final static String MBULIST_NAME = "debtor.mbu";
	public final static String GLOBALDEBTORCHKBOX_ID = "DEB_GLOBAL_CHBOX_MAIN";
	public final static String DEBTORCATEGORY_ID = "DEBTOR_CATEGORY";
	public final static String DEBTORTYPE_ID = "DEBTOR_TYPE";

	@FindBy(id = DEBTORCODE_ID)
	private WebElement debtorCode;

	@FindBy(name = DEBTORSHNAME_NAME)
	private WebElement debtorShortName;

	@FindBy(name = DEBTORNAME_NAME)
	private WebElement debtorName;

	@FindBy(name = DEBTORNAMEAR_NAME)
	private WebElement debtorNameAr;

	@FindBy(name = MBULIST_NAME)
	private WebElement mbuList;

	@FindBy(id = GLOBALDEBTORCHKBOX_ID)
	private WebElement globalDebtorChkBox;

	@FindBy(id = DEBTORCATEGORY_ID)
	private WebElement debtorCategory;

	@FindBy(id = DEBTORTYPE_ID)
	private WebElement debtorType;

	public boolean isMandDebtorShName() {
		waitForElementName(DEBTORSHNAME_NAME);
		return isMandatoryField(debtorShortName);
	}

	public boolean isMandDebtorName() {
		waitForElementName(DEBTORNAME_NAME);
		return isMandatoryField(debtorName);
	}

	public boolean isMandMBU() {
		waitForElementName(MBULIST_NAME);
		return isMandatoryField(mbuList);
	}

	public void fillData(String[] debtorListData) throws Exception {
		waitForElementName(DEBTORSHNAME_NAME);
		sleepLong();
		debtorShortName.clear();
		debtorShortName.sendKeys(debtorListData[0]);
		sleepVeryShort();
		debtorName.clear();
		debtorName.sendKeys(debtorListData[1]);
		sleepVeryShort();
		debtorNameAr.clear();
		debtorNameAr.sendKeys(debtorListData[2]);
		if (!debtorListData[3].isEmpty()) {
			new Select(mbuList).selectByVisibleText(debtorListData[3]);
		}
		if (Boolean.valueOf(debtorListData[4])) {
			globalDebtorChkBox.click();
		}
		if (!debtorListData[5].isEmpty()) {
			new Select(debtorCategory).selectByVisibleText(debtorListData[5]);
		}
		if (!debtorListData[6].isEmpty()) {
			new Select(debtorType).selectByVisibleText(debtorListData[6]);
		}

	}

	public String getSelectedMBU() {
		return new Select(mbuList).getFirstSelectedOption().getText();
	}

	public String checkFieldValue() {
		String dbtrShName = debtorShortName.getAttribute("value");
		return dbtrShName;
	}

	public WebElement getDebtorCode() {
		return debtorCode;
	}

	public WebElement getDebtorShortName() {
		return debtorShortName;
	}

	public WebElement getDebtorName() {
		return debtorName;
	}

	public WebElement getDebtorNameAr() {
		return debtorNameAr;
	}

	public WebElement getMbuList() {
		return mbuList;
	}

	public WebElement getGlobalDebtorChkBox() {
		return globalDebtorChkBox;
	}

	public WebElement getDebtorCategory() {
		return debtorCategory;
	}

	public WebElement getDebtorType() {
		return debtorType;
	}

}
