package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class MBUFirstSection extends DriverWaitClass {

	public final static String MBUCODE_ID = "mbuCodeInfo";
	public final static String MBUNAME_ID = "mbuName";
	public final static String MBUNAMEAR_ID = "mbuNameAr";
	public final static String SHORTNAME_ID = "SHORT_NAME";
	public final static String MBUTYPE_NAME = "mbuSetup.mbuType";
	public final static String LICENSE_ID = "LICENSE";
	public final static String BLOODBANKLICENSE_ID = "BLOOD_BANK_LICENSE";
	public final static String LICENSEERROR_XPATH = "//label[@class='error' and @for='LICENSE']";
	public final static String MBULOGO_CLASS = "AttachedFiles";
	public final static String MBUWEBSITE_ID = "MBU_WEBSITE";
	public final static String BLOODBANKATTACHED_ID = "BLOOD_BANK_ATTACHED";
	public final static String USEGLOBALPRICELIST_ID = "USE_GLOBAL_PRICE_LIST";
	public final static String MBULOGO_ID = "MBU_LOGO";
	public final static String STANDARDBILLING_ID = "BILLING_PATTERNSB";
	public final static String BILLINGCLASSWISE_ID = "BILLING_PATTERNBCW";

	@FindBy(id = MBUCODE_ID)
	private WebElement mbuCode;

	@FindBy(id = MBUNAME_ID)
	private WebElement mbuName;

	@FindBy(id = MBUNAMEAR_ID)
	private WebElement mbuNameAr;

	@FindBy(id = SHORTNAME_ID)
	private WebElement shortName;

	@FindBy(name = MBUTYPE_NAME)
	private WebElement mbuType;

	@FindBy(id = LICENSE_ID)
	private WebElement license;
	
	@FindBy(id = BLOODBANKLICENSE_ID)
	private WebElement bloodBankLicense;

	@FindBy(xpath = LICENSEERROR_XPATH)
	private WebElement licenseLengthError;

	@FindBy(className = MBULOGO_CLASS)
	private WebElement mbuLOGOUploaded;

	@FindBy(id = MBUWEBSITE_ID)
	private WebElement mbuWebsite;

	@FindBy(id = BLOODBANKATTACHED_ID)
	private WebElement bloodBankAttached;

	@FindBy(id = USEGLOBALPRICELIST_ID)
	private WebElement useGlobalPriceList;

	@FindBy(xpath = MBULOGO_ID)
	private WebElement mbuLogo;

	@FindBy(id = STANDARDBILLING_ID)
	private WebElement standardBilling;

	@FindBy(id = BILLINGCLASSWISE_ID)
	private WebElement billingClassWise;

	public boolean checkMBUFirstSection(String[] mbuDatas)
			throws InterruptedException {
		boolean flag = false;
		waitForElementId(MBUFirstSection.MBUNAME_ID);
		flag = getMbuName().isDisplayed();
		flag = getLicense().isDisplayed() && flag;
		return flag;
	}

// 	Please enter no more than 50 characters.
	public String licenseTxtLengValid() throws Exception {
		waitForElementId(MBUFirstSection.MBUNAME_ID);
		return checkTxtLengValidation(license, 50, 2);
	}

	public boolean fillDatasOfFirstSection(String[] mbuDatas) throws InterruptedException
			  {
		waitForElementId(MBUFirstSection.MBUNAME_ID);
		sleepShort();
		new Select(getMbuType()).selectByVisibleText(mbuDatas[5]);
		getLicense().clear();
		getLicense().sendKeys(mbuDatas[6].trim());
		getMbuWebsite().clear();
		getMbuWebsite().sendKeys(mbuDatas[7].trim());
		selectOrUnSelectCheckBox(mbuDatas[8].trim(), getBloodBankAttached());
		if(getBloodBankAttached().isSelected())
			bloodBankLicense.sendKeys(mbuDatas[9].trim());
		selectOrUnSelectCheckBox(mbuDatas[10].trim(), getUseGlobalPriceList());
		if ("Standard Billing".equals(mbuDatas[12].trim()))
			getStandardBilling().click();
		else if ("Billing Class-Wise".equals(mbuDatas[12].trim()))
			getBillingClassWise().click();
		sleepVeryShort();
		return bloodBankLicense.getAttribute("value").trim().equals(mbuDatas[9].trim());
	}

	public String uploadMBULogo(String[] mbuDatas) throws InterruptedException {
		waitForElementId(MBUFirstSection.MBUNAME_ID);
		getMbuLogo().clear();
		getMbuLogo().sendKeys(mbuDatas[11]);
		waitForElementClassName(MBUFirstSection.MBULOGO_CLASS);
		sleepVeryShort();
		return getMbuLOGOUploaded().getText().trim();
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the mbuNameAr
	 */
	public WebElement getMbuNameAr() {
		return mbuNameAr;
	}

	/**
	 * @return the shortName
	 */
	public WebElement getShortName() {
		return shortName;
	}

	/**
	 * @return the mbuType
	 */
	public WebElement getMbuType() {
		return mbuType;
	}

	/**
	 * @return the license
	 */
	public WebElement getLicense() {
		return license;
	}

	/**
	 * @return the mbuWebsite
	 */
	public WebElement getMbuWebsite() {
		return mbuWebsite;
	}

	/**
	 * @return the bloodBankAttached
	 */
	public WebElement getBloodBankAttached() {
		return bloodBankAttached;
	}

	/**
	 * @return the useGlobalPriceList
	 */
	public WebElement getUseGlobalPriceList() {
		return useGlobalPriceList;
	}

	/**
	 * @return the mbuLogo
	 */
	public WebElement getMbuLogo() {
		return mbuLogo;
	}

	/**
	 * @return the licenseLengthError
	 */
	public WebElement getLicenseLengthError() {
		return licenseLengthError;
	}

	/**
	 * @return the mbuLOGOUploaded
	 */
	public WebElement getMbuLOGOUploaded() {
		return mbuLOGOUploaded;
	}

	/**
	 * @return the standardBilling
	 */
	public WebElement getStandardBilling() {
		return standardBilling;
	}

	/**
	 * @return the billingClassWise
	 */
	public WebElement getBillingClassWise() {
		return billingClassWise;
	}

	/**
	 * @return the bloodBankLicense
	 */
	public WebElement getBloodBankLicense() {
		return bloodBankLicense;
	}

}
