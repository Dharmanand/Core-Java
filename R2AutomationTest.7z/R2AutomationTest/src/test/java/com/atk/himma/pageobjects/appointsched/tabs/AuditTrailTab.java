package com.atk.himma.pageobjects.appointsched.tabs;

public class AuditTrailTab {

}
