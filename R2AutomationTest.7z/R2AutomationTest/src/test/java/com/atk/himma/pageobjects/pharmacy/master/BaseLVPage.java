package com.atk.himma.pageobjects.pharmacy.master;

public class BaseLVPage {

}
