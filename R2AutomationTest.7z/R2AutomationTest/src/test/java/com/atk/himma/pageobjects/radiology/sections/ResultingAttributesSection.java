package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ResultingAttributesSection extends DriverWaitClass{
	
	public final static String REPORTFORMATDD_ID = "reportFormatId";
	public final static String REPORTONDD_ID = "reportOnId";
	public final static String REPORTONTXT_ID = "reportOnId";
	public final static String MANDDUR_RESULTENTRYCB_ID = "mandatoryResult";
	public final static String SUBPARAMETERDD_ID = "subParamId";
	public final static String RESULTDESCTXT_ID = "resultDesc";
	public final static String ADDBUTTON_ID = "addNewResultParam";
	
//	-----------GRID--------------
	public final static String GRID_ID = "rsra_GRID";
	public final static String GRID_SUBPARAM_ARIA_DESCRIBEDBY = "rsra_GRID_subParamIdText";
	public final static String GRID_MANDATORY_ARIA_DESCRIBEDBY = "rsra_GRID_mandResultText";
	public final static String GRID_RESULTDESC_ARIA_DESCRIBEDBY = "rsra_GRID_resultDesc";
	public final static String GRID_PAGERID = "sp_1_rsra_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rsra_GRID_pager']";

	@FindBy(id = REPORTFORMATDD_ID)
	private WebElement reportFormatDD;
	
	@FindBy(id = REPORTONDD_ID)
	private WebElement reportOnDD;
	
	@FindBy(id = REPORTONTXT_ID)
	private WebElement reportOnTxt;
	
	@FindBy(id = MANDDUR_RESULTENTRYCB_ID)
	private WebElement mandDurResultEntryCB;
	
	@FindBy(id = SUBPARAMETERDD_ID)
	private WebElement subParaMeterDD;
	
	@FindBy(id = RESULTDESCTXT_ID)
	private WebElement resultDescTxt;
	
	@FindBy(id = ADDBUTTON_ID)
	private WebElement addButton;

	/**
	 * @return the reportFormatDD
	 */
	public WebElement getReportFormatDD() {
		return reportFormatDD;
	}

	/**
	 * @return the reportOnDD
	 */
	public WebElement getReportOnDD() {
		return reportOnDD;
	}

	/**
	 * @return the reportOnTxt
	 */
	public WebElement getReportOnTxt() {
		return reportOnTxt;
	}

	/**
	 * @return the mandDurResultEntryCB
	 */
	public WebElement getMandDurResultEntryCB() {
		return mandDurResultEntryCB;
	}

	/**
	 * @return the subParaMeterDD
	 */
	public WebElement getSubParaMeterDD() {
		return subParaMeterDD;
	}

	/**
	 * @return the resultDescTxt
	 */
	public WebElement getResultDescTxt() {
		return resultDescTxt;
	}

	/**
	 * @return the addButton
	 */
	public WebElement getAddButton() {
		return addButton;
	}
	
}
