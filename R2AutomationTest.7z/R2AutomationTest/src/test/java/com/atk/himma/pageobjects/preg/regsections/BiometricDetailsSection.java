package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class BiometricDetailsSection extends DriverWaitClass{

	public final static String SECTIONNAME_LINKTEXT = "Biometric Details";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Biometric Details')]/..";
	
	@FindBy(xpath=SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	private final static String UPLOADCAPTUREPATIENTPHOTO_XPATH = "//div[@id='bioDetails_documentPathPhotoFILE_UPLOAD']/input[@id='bioDetails_documentPathPhoto']";
	
	@FindBy(xpath=UPLOADCAPTUREPATIENTPHOTO_XPATH)
	private WebElement uploadCapturePatientPhoto;

	private final static String UPLOADCAPTUREPATIENTRETINA_XPATH = "//div[@id='bioDetails_documentPathRetinaFILE_UPLOAD']/input[@id='bioDetails_documentPathRetina']";
	
	@FindBy(xpath=UPLOADCAPTUREPATIENTRETINA_XPATH)
	private WebElement uploadCapturePatientRetina;

	private final static String UPLOADCAPTUREPATIENTTHUMBIMPRESSION_XPATH = "//div[@id='bioDetails_documentPathThumbFILE_UPLOAD']/input[@id='bioDetails_documentPathThumb']";
	
	@FindBy(xpath=UPLOADCAPTUREPATIENTTHUMBIMPRESSION_XPATH)
	private WebElement uploadCapturePatientThumbImpression;
	
	public void fillDatasOfBiometricDetailsSection(String[] excelData, WebDriverWait webDriverWait) throws InterruptedException
	{
//		getSectionName().click();
//		sleepVeryShort();
		if(!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute("class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getUploadCapturePatientPhoto()));
		getUploadCapturePatientPhoto().sendKeys(excelData[73].trim());
		getUploadCapturePatientRetina().sendKeys(excelData[74].trim());
		getUploadCapturePatientThumbImpression().sendKeys(excelData[75].trim());
		
	}
	
	/**
	 * @return the uploadCapturePatientPhoto
	 */
	public WebElement getUploadCapturePatientPhoto() {
		return uploadCapturePatientPhoto;
	}

	/**
	 * @return the uploadCapturePatientRetina
	 */
	public WebElement getUploadCapturePatientRetina() {
		return uploadCapturePatientRetina;
	}

	/**
	 * @return the uploadCapturePatientThumbImpression
	 */
	public WebElement getUploadCapturePatientThumbImpression() {
		return uploadCapturePatientThumbImpression;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the uploadcapturepatientphotoXpath
	 */
	public static String getUploadcapturepatientphotoXpath() {
		return UPLOADCAPTUREPATIENTPHOTO_XPATH;
	}

	/**
	 * @return the uploadcapturepatientretinaXpath
	 */
	public static String getUploadcapturepatientretinaXpath() {
		return UPLOADCAPTUREPATIENTRETINA_XPATH;
	}

	/**
	 * @return the uploadcapturepatientthumbimpressionXpath
	 */
	public static String getUploadcapturepatientthumbimpressionXpath() {
		return UPLOADCAPTUREPATIENTTHUMBIMPRESSION_XPATH;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
