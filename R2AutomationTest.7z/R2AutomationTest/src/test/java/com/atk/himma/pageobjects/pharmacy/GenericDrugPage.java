package com.atk.himma.pageobjects.pharmacy;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.pageobjects.pharmacy.sections.GenericDrugFirstSection;
import com.atk.himma.pageobjects.pharmacy.sections.GenericDrugsInfoSection;
import com.atk.himma.util.DriverWaitClass;

public class GenericDrugPage extends DriverWaitClass{
	
	private GenericDrugFirstSection genericDrugFirstSection;
	private GenericDrugsInfoSection genericDrugsInfoSection;

	public final String FORM_ID = "GENERIC_DRUG_DETAILS";
	public final String UPDATEBUTTON_CSS = ".buttoncontainer_vlrg_top > input[value=Update]";
	public final String CANCELBUTTON_CSS = ".buttoncontainer_vlrg_top > input[value=Cancel]";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = UPDATEBUTTON_CSS)
	private WebElement updateButton;

	@FindBy(css = CANCELBUTTON_CSS)
	private WebElement cancelButton;
	
	public GenericDrugFirstSection getGenericDrugFirstSection() {
		return genericDrugFirstSection;
	}

	public GenericDrugsInfoSection getGenericDrugsInfoSection() {
		return genericDrugsInfoSection;
	}

	public WebElement getForm() {
		return form;
	}

	public WebElement getUpdateButton() {
		return updateButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

}
