package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.master.UOMPage;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.UOMDetailsTab;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.UOMListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class UOMTest extends SeleniumDriverSetup {

	List<String[]> uomDatas;
	UOMPage uomPage;

	@Test(description = "Open Visit Category Page")
	public void openVisitCategoryPage() {
		uomPage = PageFactory.initElements(webDriver, UOMPage.class);
		uomPage = uomPage.clickOnUOMPageMenu(webDriver, webDriverWait);
		uomPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(uomPage);
		uomPage.waitForElementVisibilityOf(uomPage.getUomListTab().getForm());
		uomPage.waitForElementXpathExpression(UOMListTab.UOMLISTTAB_XPATH);
		Assert.assertEquals(uomPage.getPageTitle().getText().trim(),
				"Unit of Measurement");
	}

	// [Unit of Measurement] Open Form
	@Test(description = "Open Unit of Measurement Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkUOMMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		uomPage = PageFactory.initElements(webDriver, UOMPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		parentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(parentMenuList,
				"Unit of Measurement");
		uomPage.setWebDriver(webDriver);
		uomPage.setWebDriverWait(webDriverWait);
		uomPage.waitForElementXpathExpression(UOMPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Unit of Measurement")
				.get("[Unit of Measurement] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(UOMPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Unit of Measurement] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			uomPage = uomPage.clickOnUOMPageMenu(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(uomPage);
			uomPage.waitForPageLoaded(webDriver);
			uomPage.waitForElementId(UOMListTab.FORM_ID);
			uomPage.waitForElementXpathExpression(UOMListTab.UOMLISTTAB_XPATH);
			Assert.assertEquals(uomPage.getPageTitle().getText().trim(),
					"Unit of Measurement");
		}
	}
	
	@Test(description = "Open Visit Category Page", dependsOnMethods = { "openVisitCategoryPage" })
	public void test01ClickOnAddNewUOMButton() {
		uomPage.clickOnAddNewUOMButton();
		Assert.assertEquals(uomPage.getUomDetailsTab().getUomDetailsTab()
				.getAttribute("title").trim(), "Unit Of measurement Details",
				"Add New UOM Button not Clicked");
	}

	@Test(description = "Save UOM Data", dependsOnMethods = { "test01ClickOnAddNewUOMButton" })
	public void test02SaveUOMData() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		uomDatas = excelReader.read(properties.getProperty("uom"));
		for (String[] st : uomDatas) {
			Assert.assertEquals(
					uomPage.saveUOMData(st).contains("Update"),
					true, "Save failed");
			break;
		}
	}

	@Test(description = "Activate UOM", dependsOnMethods = "test02SaveUOMData")
	public void test03ActivateUOM() throws InterruptedException, IOException {
		Assert.assertEquals(uomPage.activateUOM().contains("Active"), true,
				"Fail to Activate UOM.");
	}

	@Test(description="Check Duplicate UOM Data", dependsOnMethods={"test02SaveUOMData"})
	public void test04SaveDuplicatePLData() throws InterruptedException, IOException {
		for (String st[] : uomDatas.subList(0, 1))
		{
			uomPage.waitForElementXpathExpression(UOMDetailsTab.ADDNEWBUTTON_XPATH);
			uomPage.getUomDetailsTab().getAddNewButton().click();
			uomPage.sleepShort();
			uomPage.waitForElementXpathExpression(UOMDetailsTab.SAVEBUTTON_XPATH);
			uomPage.sleepShort();
			Assert.assertTrue(uomPage.saveDuplicateData(st),"Fail to Check Duplicate UOM Data");
		}
	}
	
//	@Test(description = "Click On Cancel Button", dependsOnMethods = { "test04SaveDuplicatePLData" })
//	public void test05ClickOnCancelButton() throws InterruptedException {
//		uomPage.clickOnCancelButton();
//		Assert.assertEquals(uomPage.getUomListTab().getAddNewUOMButton()
//				.getAttribute("value").trim(), "Add New Unit of Measurement",
//				"'Cancel Button' click failed");
//	}

	@Test(description = "Search UOM From grid", dependsOnMethods = { "test04SaveDuplicatePLData" })
	public void test06SearchUOM() throws IOException, InterruptedException {
		for (String[] st : uomDatas) {
			Assert.assertEquals(uomPage.searchUOM(st), st[0].trim(),
					"'search UOM' failed");
			break;
		}
	}

	@Test(description = "Click On Edit Link", dependsOnMethods = { "test06SearchUOM" })
	public void test07ClickOnEditLink() throws IOException, InterruptedException {
		for (String[] st : uomDatas) {
			Assert.assertEquals(uomPage.clickOnEditLink(st), st[0].trim(),
					"'Edit link' click failed");
			break;
		}
	}

	@Test(description = "Update UOM Data", dependsOnMethods = { "test07ClickOnEditLink" })
	public void test08UpdateUOMData() throws IOException, InterruptedException {
		for (String[] st : uomDatas.subList(1, uomDatas.size() - 1)) {
			Assert.assertEquals(uomPage.updateUOMData(st).contains("Update"),
					true, "Update failed");
			break;
		}
	}

	@Test(description = "Click On Add New Button", dependsOnMethods = { "test08UpdateUOMData" })
	public void test09ClickOnAddNewButton() throws IOException, InterruptedException {
		Assert.assertEquals(uomPage.clickOnAddNewButton(), "Save",
				"Update failed");
	}

	@Test(description = "Save UOM With Conversion Factor", dependsOnMethods = { "test09ClickOnAddNewButton" })
	public void test10SaveUOMWithConvFactor() throws IOException,
			InterruptedException {
		for (String[] st : uomDatas.subList(2, uomDatas.size() - 1)) {
			Assert.assertEquals(
					uomPage.saveUOMWithConvFactor(st).contains(
							"Update"), true, "Save failed");
			break;
		}
	}

	@Test(description = "Click On Delete Link", dependsOnMethods = { "test10SaveUOMWithConvFactor" })
	public void test11ClickOnDeleteLink() throws IOException, InterruptedException {
		for (String[] st : uomDatas.subList(2, uomDatas.size() - 1)) {
			Assert.assertEquals(
					uomPage.clickOnDeleteLink(st).contains(
							"deleted successfully."), true, "Delete failed");
			break;
		}
	}
}
