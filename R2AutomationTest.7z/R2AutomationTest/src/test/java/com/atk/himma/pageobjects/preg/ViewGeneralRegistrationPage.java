package com.atk.himma.pageobjects.preg;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.atk.himma.util.DriverWaitClass;

public class ViewGeneralRegistrationPage extends DriverWaitClass{

	private final static String PAGETITLE_ID = "PAGE_TITLE";
	
	@FindBy(id=PAGETITLE_ID)
	private WebElement pageTitle;
	
	private final static String REGTYPE_XPATH = "//label[@id='GEN_REG_FRM_patiInfoDetails_registrationType' and @class='controlvalue label_highlight capsletter']";
	
	@FindBy(xpath=REGTYPE_XPATH)
	private WebElement regType;
	
	private final static String MRNNO_XPATH = "//fieldset[@class='inputgroup_2_wob']//span[@class='input_holder'][1]/label[@class='controlvalue']";
	
	@FindBy(xpath=MRNNO_XPATH)
	private WebElement mrnNo;

	private final static String EDITBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Edit']";
	
	@FindBy(xpath=EDITBUTTON_XPATH)
	private WebElement editButton;
	
	public GeneralRegistrationPage clickEditLinkInGrid(String mrnNO) {
			waitForElementXpathExpression(EDITBUTTON_XPATH);
			waitForElementXpathExpression(MRNNO_XPATH);
			waitForElementXpathExpression(REGTYPE_XPATH);
			waitForElementXpathExpression(EDITBUTTON_XPATH);
			if(getMrnNo().getText().trim().equals(mrnNO.trim()))
			{
				GeneralRegistrationPage genReg = PageFactory.initElements(
						webDriver, GeneralRegistrationPage.class);
				genReg.setWebDriver(webDriver);
				genReg.setWebDriverWait(webDriverWait);
				waitForElementVisibilityOf(genReg.getUpdateButton());
				waitForElementVisibilityOf(genReg.getNewRegistrationButton());
				return genReg;
			}
			return null;
	}
	
	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the regtypeXpath
	 */
	public static String getRegtypeXpath() {
		return REGTYPE_XPATH;
	}

	/**
	 * @return the regType
	 */
	public WebElement getRegType() {
		return regType;
	}

	/**
	 * @return the mrnnoXpath
	 */
	public static String getMrnnoXpath() {
		return MRNNO_XPATH;
	}

	/**
	 * @return the mrnNo
	 */
	public WebElement getMrnNo() {
		return mrnNo;
	}

	/**
	 * @return the editbuttonXpath
	 */
	public static String getEditbuttonXpath() {
		return EDITBUTTON_XPATH;
	}

	/**
	 * @return the editButton
	 */
	public WebElement getEditButton() {
		return editButton;
	}
	
}
