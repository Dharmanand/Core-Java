package com.atk.himma.pageobjects.sa.masters.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class EquipmentListTab extends DriverWaitClass {
	
	public final static String EQUIPLISTTAB_XPATH = "//a[@title='Equipment List']";
	@FindBy(xpath = EQUIPLISTTAB_XPATH)
	private WebElement equipListTab;
	
	public final static String QUICK_SEARCH_ID = "QUICK_SEARCH_TEXT";
	@FindBy(id = QUICK_SEARCH_ID)
	private WebElement quickSearch;

	public final static String ADDNEWBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Add New Equipment']";
	@FindBy(xpath = ADDNEWBUTTON_XPATH)
	private WebElement addNewEquipButton;
	
	public final static String SEARCHBUTTON_XPATH = "//form[@id='EQUIP_SEARCH']//input[@value='Search']";
	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement searchButton;

	public final static String ADVSEARCHBUTTON_ID = "EQUIP_ADV_SEARCH_BOTTON";
	@FindBy(id = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;

	public final static String ADVSEARCHDIV_ID = "EQUIP_ADV_SEARCH_DIV";
	@FindBy(id = ADVSEARCHDIV_ID)
	private WebElement advSearchDiv;

	public final static String MBU_ID = "EQUIP_ADV_SEARCH_DIV";
	@FindBy(id = MBU_ID)
	private WebElement mbu;

	public final static String DEPARTMENT_ID = "ADV_SEARCH_DEPT";
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;

	public final static String RESTYPE_ID = "ADV_SEARCH_RES";
	@FindBy(id = DEPARTMENT_ID)
	private WebElement resType;

	public final static String EQUSHORTNAME_ID = "ADV_SEARCH_SHORTNAME";
	@FindBy(id = EQUSHORTNAME_ID)
	private WebElement equipShortTime;

	public final static String EQUPNAME_ID = "ADV_SEARCH_EQPNAME";
	@FindBy(id = EQUPNAME_ID)
	private WebElement equipName;

	public final static String STATUS_ID = "MAIN_STATUS";
	@FindBy(id = STATUS_ID)
	private WebElement status;

	public final static String SEARCH_ID = "EQP_ADVNCD_SEARCH_BUT";
	@FindBy(id = SEARCH_ID)
	private WebElement advSearchDivButton;

	public final static String RESET_ID = "EQP_ADVNCD_SEARCH_RESET";
	@FindBy(id = RESET_ID)
	private WebElement advResetDivButton;

	// ---------------------------------------------- Grid Start -----------------------------------------
	public final static String GRID_ID = "EQUIP_SEARCH_GRID";

	@FindBy(id = GRID_ID)
	private WebElement searchGrid;

	public final static String GRID_EQUIPCODE_ARIA_DESCRIBEDBY = "EQUIP_SEARCH_GRID_equipmentCode";
	public final static String GRID_SHORTNAME_ARIA_DESCRIBEDBY = "EQUIP_SEARCH_GRID_shortName";
	public final static String GRID_EQUIPNAME_ARIA_DESCRIBEDBY = "EQUIP_SEARCH_GRID_equipmentName";
	public final static String GRID_DEPTTEXT_ARIA_DESCRIBEDBY = "EQUIP_SEARCH_GRID_deptText";
	public final static String GRID_MBUTEXT_ARIA_DESCRIBEDBY = "EQUIP_SEARCH_GRID_mbuText";

	public WebElement getQuickSearch() {
		return quickSearch;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	public WebElement getAdvSearchDiv() {
		return advSearchDiv;
	}

	public WebElement getMbu() {
		return mbu;
	}

	public WebElement getDepartment() {
		return department;
	}

	public WebElement getResType() {
		return resType;
	}

	public WebElement getEquipShortTime() {
		return equipShortTime;
	}

	public WebElement getEquipName() {
		return equipName;
	}

	public WebElement getStatus() {
		return status;
	}

	public WebElement getAdvSearchDivButton() {
		return advSearchDivButton;
	}

	public WebElement getAdvResetDivButton() {
		return advResetDivButton;
	}

	public WebElement getSearchGrid() {
		return searchGrid;
	}

	/**
	 * @return the addNewEquipButton
	 */
	public WebElement getAddNewEquipButton() {
		return addNewEquipButton;
	}

	/**
	 * @return the equipListTab
	 */
	public WebElement getEquipListTab() {
		return equipListTab;
	}
}
