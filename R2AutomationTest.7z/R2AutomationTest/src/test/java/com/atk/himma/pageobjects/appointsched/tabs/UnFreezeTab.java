package com.atk.himma.pageobjects.appointsched.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.pageobjects.appointsched.AppointmentDairy;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class UnFreezeTab extends DriverWaitClass implements StatusMessages,
		TopControls, RecordStatus {

	public final static String FORMNAME_ID = "UNFREEZ_SLOT";
	public final static String UNFREEZETAB_XPATH = "//li[@id='APP_TAB_UNFREEZE']//a[@title='Un Freeze']";

	@FindBy(xpath = UNFREEZETAB_XPATH)
	private WebElement unFreezeTab;

	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	public final static String SAVEBUTTON_ID = "UNFREEZE_ID";

	@FindBy(id = SAVEBUTTON_ID)
	private WebElement saveButton;

	public final static String CANCELBUTTON_ID = "UNFREEZE_BACK_TO_DAIRY";

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	public final static String STARTTIME_ID = "FreezeStartTime";

	@FindBy(id = STARTTIME_ID)
	private WebElement startTime;

	public final static String ENDTIME_ID = "selectedEndTime";

	@FindBy(id = ENDTIME_ID)
	private WebElement endTime;

	public final static String REASON_ID = "REASON_ID";

	@FindBy(id = REASON_ID)
	private WebElement reason;

	public final static String COMMENT_NAME = "freezingInfo.comments";

	@FindBy(name = COMMENT_NAME)
	private WebElement comment;

	public boolean isReasonMandatory() throws InterruptedException {
		waitForElementId(REASON_ID);
		sleepVeryShort();
		return isMandatoryField(reason);
	}

	public boolean fillDatas(String[] appointDatas) {
		endTime.clear();
		if (!appointDatas[9].trim().isEmpty())
			endTime.sendKeys(appointDatas[9].trim());
		new Select(reason).selectByVisibleText(appointDatas[10].trim());
		comment.clear();
		comment.sendKeys(appointDatas[11].trim());
		return comment.getAttribute("value").trim()
				.equals(appointDatas[11].trim());
	}

	public boolean saveDatas() throws InterruptedException {
		waitForElementId(SAVEBUTTON_ID);
		sleepVeryShort();
		saveButton.click();
		sleepShort();
		try {
			waitForElementXpathExpression(AppointmentDairy.BACKTOAPPOINTBUTTON_XPATH);
			waitForElementXpathExpression(AppointmentDairy.UNFROZENCONFMSG_XPATH);
			sleepVeryShort();
			return true;
		} catch (Exception e) {
			return true;
		}
	}

	/**
	 * @return the rnFreezeTab
	 */
	public WebElement getUnFreezeTab() {
		return unFreezeTab;
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the startTime
	 */
	public WebElement getStartTime() {
		return startTime;
	}

	/**
	 * @return the endTime
	 */
	public WebElement getEndTime() {
		return endTime;
	}

	/**
	 * @return the reason
	 */
	public WebElement getReason() {
		return reason;
	}

	/**
	 * @return the comment
	 */
	public WebElement getComment() {
		return comment;
	}
}
