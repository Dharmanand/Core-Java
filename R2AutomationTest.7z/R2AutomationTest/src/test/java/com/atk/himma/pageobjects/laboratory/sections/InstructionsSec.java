package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class InstructionsSec extends DriverWaitClass {
	public final static String INSTRSEC_XPATH = "//a[text()='Instructions']";
	@FindBy(xpath = INSTRSEC_XPATH)
	private WebElement instructions;

	public final static String INSTRADDROWBTN_ID = "LAB_TEST_INSTRUCTION_ADD";
	@FindBy(id = INSTRADDROWBTN_ID)
	private WebElement instrAddRowBtn;

	public final static String INSTRGRIDTBL_ID = "LAB_TEST_INSTRUCTION_GRID";
	@FindBy(id = INSTRGRIDTBL_ID)
	private WebElement instrGridTbl;

	public final static String GENDER_NAME = "genderId";
	@FindBy(name = GENDER_NAME)
	private WebElement gender;

	public final static String STARTAGEVAL_NAME = "startAge.ageInDays";
	@FindBy(name = STARTAGEVAL_NAME)
	private WebElement startAgeVal;

	public final static String STARTAGETYPE_NAME = "startAge.ageType";
	@FindBy(name = STARTAGETYPE_NAME)
	private WebElement startAgeType;

	public final static String ENDAGEVAL_NAME = "endAge.ageInDays";
	@FindBy(name = ENDAGEVAL_NAME)
	private WebElement endAgeVal;

	public final static String ENDAGETYPE_NAME = "endAge.ageType";
	@FindBy(name = ENDAGETYPE_NAME)
	private WebElement endAgeType;

	public final static String INSTRTYPE_NAME = "instructionTypeIdText";
	@FindBy(name = INSTRTYPE_NAME)
	private WebElement instrType;

	public final static String ADDINSTRPOPUPDIV_ID = "addInstructionId";
	@FindBy(id = ADDINSTRPOPUPDIV_ID)
	private WebElement addInstrPopUpDiv;

	public final static String INSTRTYPE_ID = "instrTypeId";
	@FindBy(id = INSTRTYPE_ID)
	private WebElement popUPinstrType;

	public final static String ADDINSTRGRIDTBL_ID = "LAB_TEST_ADD_INSTRUCTION_GRID";
	@FindBy(id = ADDINSTRGRIDTBL_ID)
	private WebElement addInstrGridTbl;

	public final static String INSTRLISTSUBMIT_ID = "LAB_TEST_INSTR_LIST_SUBMIT";
	@FindBy(id = INSTRLISTSUBMIT_ID)
	private WebElement instrListSubmit;

	public final static String INSTRLISTCANCEL_ID = "LAB_TEST_INSTR_LIST_CANCEL";
	@FindBy(id = INSTRLISTCANCEL_ID)
	private WebElement instrListCancel;

	public WebElement getInstructions() {
		return instructions;
	}

	public WebElement getInstrAddRowBtn() {
		return instrAddRowBtn;
	}

	public WebElement getInstrGridTbl() {
		return instrGridTbl;
	}

	public WebElement getGender() {
		return gender;
	}

	public WebElement getStartAgeVal() {
		return startAgeVal;
	}

	public WebElement getStartAgeType() {
		return startAgeType;
	}

	public WebElement getEndAgeVal() {
		return endAgeVal;
	}

	public WebElement getEndAgeType() {
		return endAgeType;
	}

	public WebElement getInstrType() {
		return instrType;
	}

	public WebElement getAddInstrPopUpDiv() {
		return addInstrPopUpDiv;
	}

	public WebElement getPopUPinstrType() {
		return popUPinstrType;
	}

	public WebElement getAddInstrGridTbl() {
		return addInstrGridTbl;
	}

	public WebElement getInstrListSubmit() {
		return instrListSubmit;
	}

	public WebElement getInstrListCancel() {
		return instrListCancel;
	}

}
