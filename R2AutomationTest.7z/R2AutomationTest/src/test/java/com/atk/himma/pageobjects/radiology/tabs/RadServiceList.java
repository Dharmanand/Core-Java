package com.atk.himma.pageobjects.radiology.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RadServiceList {
	
	public final static String QUICKSEARCH_ID = "searchText";
	public final static String SEARCHBUTTON_ID = "quickSearch";
	public final static String ADVSEARBUTTON_ID = "advancedSearch";
	public final static String EXPORTTOEXCELBUTTON_ID = "serviceSearch_grid_export_btn";

//	-----------GRID--------------
	public final static String GRID_ID = "serviceSearch_grid";
	public final static String GRID_SERVICECODE_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.serviceCode";
	public final static String GRID_SERVICENAME_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.serviceName";
	public final static String GRID_SPECIALTY_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.specialtyText";
	public final static String GRID_SUBSPECIALTY_ARIA_DESCRIBEDBY = "serviceSearch_grid_serviceInfo.subSpecialityText";
	public final static String GRID_DEPARTMENT_ARIA_DESCRIBEDBY = "equipment_detail_grid_department";
	public final static String GRID_MBU_ARIA_DESCRIBEDBY = "equipment_detail_grid_mainBusinessUnit";
	public final static String GRID_STATUS_ARIA_DESCRIBEDBY = "equipment_detail_grid_status";
	public final static String GRID_PAGERID = "sp_1_equipment_detail_grid_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_equipment_detail_grid_pager']";
	
	@FindBy(id = QUICKSEARCH_ID)
	private WebElement quickSearch;
	
	@FindBy(id = SEARCHBUTTON_ID)
	private WebElement searchButton;
	
	@FindBy(id = ADVSEARBUTTON_ID)
	private WebElement advSearchButton;
	
}
