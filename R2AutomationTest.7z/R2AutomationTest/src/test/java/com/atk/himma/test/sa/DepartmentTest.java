package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.masters.DepartmentPage;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class DepartmentTest extends SeleniumDriverSetup {
	DepartmentPage departmentPage;
	List<String[]> dssList;

	@Test(description = "Open Department Page")
	public void openDepartment() throws Exception {
		departmentPage = PageFactory.initElements(webDriver,
				DepartmentPage.class);
		departmentPage = departmentPage.clickOnDepartmentMenu(webDriver,
				webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		departmentPage.waitForElementVisibilityOf(departmentPage
				.getDepartment());
		Assert.assertTrue(departmentPage.getDepartment().isDisplayed());
	}

	@Test(description = "Map DSS", dependsOnMethods = { "openDepartment" })
	public void mapDepartmentSpecialtySubSpecialty() throws Exception {
		dssList = excelReader.read(properties.getProperty("DSS").trim());
		if (dssList != null && !dssList.isEmpty()) {
			for (String[] dssData : dssList) {
				departmentPage.mapDSS(dssData);
				Assert.assertTrue(departmentPage.searchGridData(dssData[0],
						dssData[1], dssData[2]));
			}
			departmentPage.saveDSS();
		}
	}

	@Test(dependsOnMethods = { "mapDepartmentSpecialtySubSpecialty" })
	public void editDSSMapping() throws Exception {
		
	}

	//[Department] Open Form
	@Test(description = "Check Department Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkDepartmentMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		departmentPage = PageFactory.initElements(webDriver,
				DepartmentPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> deptParentMenuList = new LinkedList<String>();
		deptParentMenuList.add("System Administration");
		deptParentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(deptParentMenuList, "Department");
		departmentPage.setWebDriver(webDriver);
		departmentPage.setWebDriverWait(webDriverWait);
		departmentPage
				.waitForElementXpathExpression(DepartmentPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Department")
				.get("[Department] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DepartmentPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Department] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			departmentPage = departmentPage.clickOnDepartmentMenu(webDriver,
					webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(departmentPage);
			departmentPage.waitForElementVisibilityOf(departmentPage
					.getDeptForm());
			departmentPage.sleepShort();
			Assert.assertEquals(departmentPage.getPageTitle().getText(),
					"Department");
		}
	}
}
