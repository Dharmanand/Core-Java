package com.atk.himma.pageobjects.mbuadmin.sections.packagedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class PackageParameters extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Package Parameters";

	public final static String PKGDURVALTXT_ID = "PKG_DURATION_TXT";
	public final static String PKGDURATVALUNIT_ID = "PKG_DURATION_UNIT";
	public final static String LENGTHOFSTAY_ID = "LENGTH_OF_STAY";
	public final static String GENERALRADIO_ID = "packagesDetails_visitType1";	
	public final static String VISITSPECRADIO_ID = "packagesDetails_visitType2";
	public final static String NOOFVISIT_ID = "NO_OF_VISIT";

	public final static String ISPHYSPEC_ID = "IS_PHYSICIAN_SPECIFIC";
	public final static String GRIDADDBUTTON_XPATH = "//td[@id='PHYSICIAN_SPECIFIC_GRID_pager_left']//div[@class='ui-pg-div']/span";
	
//	LookUp
	
	public final static String MBU_ID = "PHYSICIAN_SEARCH_MBU_NAME";
	public final static String DEPARTMENT_ID = "PHYSICIAN_SEARCH_DEPT";
	public final static String SPECIALTY_ID = "PHYSICIAN_SEARCH_SPEC";
	public final static String SUBSPECIALTY_ID = "PHYSICIAN_SEARCH_SUB_SPEC";

	public final static String DESIGNATION_ID = "PHYSICIAN_SEARCH_DESG";
	public final static String PHYSICIANCODE_ID = "PHYSICIAN_SEARCH_PHY_CODE";
	public final static String PHYSICIANNAME_ID = "PHYSICIAN_SEARCH_MBU";
	
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='Reset']";
	public final static String SUBMITBUTTON_XPATH = "PHYSICIAN_SEARCH_SUBMIT";
	public final static String CANCELBUTTON_XPATH = "PHYSICIAN_SEARCH_CANCEL";

//	
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Package Parameters')]/..";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(id = PKGDURVALTXT_ID)
	private WebElement pkgDurValTxt;
	
	@FindBy(id = PKGDURATVALUNIT_ID)
	private WebElement pkgDurValUnit;
	
	@FindBy(id = LENGTHOFSTAY_ID)
	private WebElement lengthOfStay;
	
	@FindBy(id = GENERALRADIO_ID)
	private WebElement generalRadioButton;
	
	@FindBy(id = VISITSPECRADIO_ID)
	private WebElement visitSpecRadio;
	
	@FindBy(id = NOOFVISIT_ID)
	private WebElement noOfVisit;
	
	@FindBy(id = ISPHYSPEC_ID)
	private WebElement isPhysicianSpecific;
	
	@FindBy(xpath = GRIDADDBUTTON_XPATH)
	private WebElement gridAddButton;
	
//	LookUp
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SPECIALTY_ID)
	private WebElement specialty;
	
	@FindBy(id = SUBSPECIALTY_ID)
	private WebElement subSpecialty;

	@FindBy(id = DESIGNATION_ID)
	private WebElement designation;
	
	@FindBy(id = PHYSICIANCODE_ID)
	private WebElement physicianCode;
	
	@FindBy(id = PHYSICIANNAME_ID)
	private WebElement physicianName;
	
	@FindBy(id = SEARCHBUTTON_XPATH)
	private WebElement searchButton;
	
	@FindBy(id = RESETBUTTON_XPATH)
	private WebElement resetButton;

	@FindBy(id = SUBMITBUTTON_XPATH)
	private WebElement submitButton;
	
	@FindBy(id = CANCELBUTTON_XPATH)
	private WebElement cancelButton;
	
	@FindBy(id = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the pkgDurValTxt
	 */
	public WebElement getPkgDurValTxt() {
		return pkgDurValTxt;
	}

	/**
	 * @return the pkgDurValUnit
	 */
	public WebElement getPkgDurValUnit() {
		return pkgDurValUnit;
	}

	/**
	 * @return the lengthOfStay
	 */
	public WebElement getLengthOfStay() {
		return lengthOfStay;
	}

	/**
	 * @return the generalRadioButton
	 */
	public WebElement getGeneralRadioButton() {
		return generalRadioButton;
	}

	/**
	 * @return the visitSpecRadio
	 */
	public WebElement getVisitSpecRadio() {
		return visitSpecRadio;
	}

	/**
	 * @return the noOfVisit
	 */
	public WebElement getNoOfVisit() {
		return noOfVisit;
	}

	/**
	 * @return the isPhysicianSpecific
	 */
	public WebElement getIsPhysicianSpecific() {
		return isPhysicianSpecific;
	}

	/**
	 * @return the gridAddButton
	 */
	public WebElement getGridAddButton() {
		return gridAddButton;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the specialty
	 */
	public WebElement getSpecialty() {
		return specialty;
	}

	/**
	 * @return the subSpecialty
	 */
	public WebElement getSubSpecialty() {
		return subSpecialty;
	}

	/**
	 * @return the designation
	 */
	public WebElement getDesignation() {
		return designation;
	}

	/**
	 * @return the physicianCode
	 */
	public WebElement getPhysicianCode() {
		return physicianCode;
	}

	/**
	 * @return the physicianName
	 */
	public WebElement getPhysicianName() {
		return physicianName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}
	
}
