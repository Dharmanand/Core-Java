package com.atk.himma.setup;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.ExcelReader;

public class SeleniumDriverSetup {

	protected final static String VALMSG_ISTDATEFORMAT = "Please enter a valid date/time(eg: "
			+ DateTimeConverter.currentISTDateFormat() + ")";
	protected static WebDriver webDriver;
	protected static WebDriverWait webDriverWait;
	protected static final ExcelReader excelReader = new ExcelReader();
	protected static Map<String, List<String>> masterDatas;
	protected static Map<String, List<String>> fullPrivUserDatas, privGrpDatas;
	protected static Map<String, List<String>> allPrivGrps;
	protected static String[] mergePatients;
	protected static String encounterNo;
	public static Properties properties;
	public static String scPath;
//	public static TestRecorder recorder;
	@BeforeSuite(groups = { "driverSetup" })
	public void getDriver() throws Exception {
		if (webDriver == null) {
//			recorder = new TestRecorder("E:/R2/R2AutomationTest/target/video/R2Automation",false);
//			recorder.start(); 
			webDriver = new FirefoxDriver();
			webDriverWait = new WebDriverWait(webDriver, 10);
			webDriver.manage().window().maximize();
			fullPrivUserDatas = new HashMap<String, List<String>>();
			privGrpDatas = new HashMap<String, List<String>>();
			if (properties == null) {
				properties = new Properties();
				properties.load(new FileInputStream(
						"src/test/resources/properties/config.properties"));
				scPath = "E:/R2/R2AutomationTest/target/screen-shots";
			}
		}
	}

	@AfterMethod(groups = { "driverSetup" })
	protected void failureScreenShot(ITestResult result) throws IOException {
		if (!result.isSuccess()) {
			File imageFile = ((TakesScreenshot) webDriver)
					.getScreenshotAs(OutputType.FILE);
			String failureImageFileName = result.getMethod().getMethodName()
					+ new SimpleDateFormat("MM-dd-yyyy_hh-ss")
							.format(new GregorianCalendar().getTime()) + ".png";
			File failureImageFile = new File(scPath + failureImageFileName);
			FileUtils.moveFile(imageFile, failureImageFile);
			Reporter.log("<h3 style='background-color:#FFB6C1'>FAIL: "
					+ result.getMethod().getDescription() + "[Test Name: "
					+ result.getMethod().getMethodName() + "] "
					+ "[Screen-Shot Link: <a href='file:///" + scPath
					+ failureImageFileName
					+ "'><font color='style='#CCCCFF''><I>"
					+ failureImageFileName + "</I></font></a>]</h3>");

			System.out.println("===================>>>>>>>>>>>>>> " + scPath
					+ failureImageFileName);

		} else {
			Reporter.log("<h3 style='background-color:#90EE90'>PASS: "
					+ result.getMethod().getDescription() + "[Test Name: "
					+ result.getMethod().getMethodName() + "]</h3>");
		}
	}

	@AfterSuite(groups = { "driverSetup" })
	public void closeDriver() throws Exception {
		webDriver.close();
		webDriver.quit();
//		recorder.stop();
	}

	protected void doDirtyFormCheck() {
		try {
			new WebDriverWait(webDriver, 2).until(ExpectedConditions
					.presenceOfAllElementsLocatedBy(By.id("MSG_DIALOG_YES")));
			webDriver.findElement(By.id("MSG_DIALOG_YES")).click();
		} catch (Exception e) {
			Reporter.log("<h3 style='background-color:#FFDAB9'>... We can ignore following exception as it is related to dirty form checking.</h3>");
		}
	}

	protected List<String> getParentMenuList() {
		return new LinkedList<String>();
	}

	protected void waitForElement(WebElement element) {
		webDriverWait.until(ExpectedConditions.visibilityOf(element));
	}

}
