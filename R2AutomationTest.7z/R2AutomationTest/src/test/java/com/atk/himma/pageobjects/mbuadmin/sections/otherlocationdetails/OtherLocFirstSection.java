package com.atk.himma.pageobjects.mbuadmin.sections.otherlocationdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class OtherLocFirstSection extends DriverWaitClass{
	
	public final static String LOCATIONCODE_ID = "locationCodeSeqNo";
	public final static String LOCSHORTNAME_ID = "shortName";
	public final static String LOCATIONNAME_ID = "locationName";
	public final static String MBU_ID = "MBU_LIST_TAB2";
	public final static String DEPARTMENT_ID = "DEPARTMENT_LIST_TAB2";
	public final static String LOCATIONCATEGORY_ID = "LOC_CATEGORY_LIST_TAB2";
	public final static String APPLYTOVISITCATNM_NAME = "multiselect_APPLY_TO_VISIT_CATEGORY";
	public final static String ISNURSSTAFFREQ_ID = "IS_NURSING_STAFF_REQUIRED";
	public final static String PHCOUNTRYCODE1_ID = "mainPhCountryCode";
	public final static String PHLOCALNO1_ID = "mainPhLocalNo";
	public final static String PHCOUNTRYCODE2_ID = "secPhCountryCode";
	public final static String PHLOCALNO2_ID = "secPhLocalNo";
	public final static String ISAGESPECIFIC_ID = "IS_AGE_SPECIFIC";
	public final static String MINAGE_ID = "MIN_AGE";
	public final static String MINAGETYPE_ID = "MIN_AGE_TYPE";
	public final static String MAXAGE_ID = "MAX_AGE";
	public final static String MAXAGETYPE_ID = "MAX_AGE_TYPE";
	public final static String ISGENDERSPECIFIC_ID = "IS_GENDER_SPECIFIC";
	public final static String GENDER_NAME = "multiselect_GENDER";
	
	@FindBy(id = LOCATIONCODE_ID)
	private WebElement locationCode;
	
	@FindBy(id = LOCSHORTNAME_ID)
	private WebElement locShortName;
	
	@FindBy(id = LOCATIONNAME_ID)
	private WebElement locationName;
	
	@FindBy(id = MBU_ID)
	private WebElement mbu;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = LOCATIONCATEGORY_ID)
	private WebElement locationCategory;
	
	@FindBy(name = APPLYTOVISITCATNM_NAME)
	private WebElement applyToVisitCatNM;
	
	@FindBy(id = ISNURSSTAFFREQ_ID)
	private WebElement isNurseStaffRequired;
	
	@FindBy(id = PHCOUNTRYCODE1_ID)
	private WebElement phCountryCode1;
	
	@FindBy(id = PHLOCALNO1_ID)
	private WebElement phone1;
	
	@FindBy(id = PHCOUNTRYCODE2_ID)
	private WebElement phCountryCode2;
	
	@FindBy(id = PHLOCALNO2_ID)
	private WebElement phone2;
	
	@FindBy(id = ISAGESPECIFIC_ID)
	private WebElement isAgeSpecific;
	
	@FindBy(id = MINAGE_ID)
	private WebElement minimumAge;
	
	@FindBy(id = MINAGETYPE_ID)
	private WebElement minAgeType;
	
	@FindBy(id = MAXAGE_ID)
	private WebElement maximumAge;
	
	@FindBy(id = MAXAGETYPE_ID)
	private WebElement maxAgeType;
	
	@FindBy(id = ISGENDERSPECIFIC_ID)
	private WebElement isGenderSpecific;
	
	@FindBy(name = GENDER_NAME)
	private WebElement genderName;

	public boolean isMandatoryLocShortNM() {
		return isMandatoryField(locShortName);
	}

	public boolean isMandatoryLocName() {
		return isMandatoryField(locationName);
	}

	public boolean isMandatoryMBU() {
		return isMandatoryField(mbu);
	}
	public boolean isMandatoryLocCategory() {
		return isMandatoryField(locationCategory);
	}

	public boolean fillDatas(String[] otherLocDatas)
			throws InterruptedException {
		waitForElementId(LOCATIONNAME_ID);
		sleepShort();
		locShortName.clear();
		locShortName.sendKeys(otherLocDatas[6].trim());
		locationName.clear();
		locationName.sendKeys(otherLocDatas[7].trim());
		
		if (!otherLocDatas[0].isEmpty())
			new Select(mbu).selectByVisibleText(otherLocDatas[0].trim());
		if (!otherLocDatas[8].isEmpty())
			new Select(department).selectByVisibleText(otherLocDatas[8].trim());
		if (!otherLocDatas[9].isEmpty())
			new Select(locationCategory).selectByVisibleText(otherLocDatas[9].trim());
		selectValueOfMultiselect(APPLYTOVISITCATNM_NAME, otherLocDatas[10].trim());
		selectOrUnSelectCheckBox(otherLocDatas[11].trim(), isNurseStaffRequired);
		if (!otherLocDatas[12].isEmpty())
		new Select(phCountryCode1).selectByVisibleText(otherLocDatas[12].trim());
		phone1.sendKeys(otherLocDatas[13].trim());
		if (!otherLocDatas[14].isEmpty())
			new Select(phCountryCode2).selectByVisibleText(otherLocDatas[14].trim());
		phone2.sendKeys(otherLocDatas[15].trim());
		selectOrUnSelectCheckBox(otherLocDatas[16].trim(), isAgeSpecific);
		if (isAgeSpecific.isSelected()) {
			minimumAge.clear();
			minimumAge.sendKeys(otherLocDatas[17].trim());
			new Select(minAgeType).selectByVisibleText(otherLocDatas[18].trim());
			maximumAge.clear();
			maximumAge.sendKeys(otherLocDatas[19].trim());
			new Select(maxAgeType).selectByVisibleText(otherLocDatas[20].trim());
		}
		selectOrUnSelectCheckBox(otherLocDatas[21].trim(), isGenderSpecific);
		if (isGenderSpecific.isSelected())
			selectValueOfMultiselect(GENDER_NAME, otherLocDatas[22].trim());
		return isGenderSpecific.isSelected() == Boolean.valueOf(otherLocDatas[23]
				.trim());
	}
	
	/**
	 * @return the locationCode
	 */
	public WebElement getLocationCode() {
		return locationCode;
	}

	/**
	 * @return the locShortName
	 */
	public WebElement getLocShortName() {
		return locShortName;
	}

	/**
	 * @return the locationName
	 */
	public WebElement getLocationName() {
		return locationName;
	}

	/**
	 * @return the mbu
	 */
	public WebElement getMbu() {
		return mbu;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the locationCategory
	 */
	public WebElement getLocationCategory() {
		return locationCategory;
	}

	/**
	 * @return the applyToVisitCatNM
	 */
	public WebElement getApplyToVisitCatNM() {
		return applyToVisitCatNM;
	}

	/**
	 * @return the isNurseStaffRequired
	 */
	public WebElement getIsNurseStaffRequired() {
		return isNurseStaffRequired;
	}

	/**
	 * @return the phCountryCode1
	 */
	public WebElement getPhCountryCode1() {
		return phCountryCode1;
	}

	/**
	 * @return the phone1
	 */
	public WebElement getPhone1() {
		return phone1;
	}

	/**
	 * @return the phCountryCode2
	 */
	public WebElement getPhCountryCode2() {
		return phCountryCode2;
	}

	/**
	 * @return the phone2
	 */
	public WebElement getPhone2() {
		return phone2;
	}

	/**
	 * @return the isAgeSpecific
	 */
	public WebElement getIsAgeSpecific() {
		return isAgeSpecific;
	}

	/**
	 * @return the minimumAge
	 */
	public WebElement getMinimumAge() {
		return minimumAge;
	}

	/**
	 * @return the minAgeType
	 */
	public WebElement getMinAgeType() {
		return minAgeType;
	}

	/**
	 * @return the maximumAge
	 */
	public WebElement getMaximumAge() {
		return maximumAge;
	}

	/**
	 * @return the maxAgeType
	 */
	public WebElement getMaxAgeType() {
		return maxAgeType;
	}

	/**
	 * @return the isGenderSpecific
	 */
	public WebElement getIsGenderSpecific() {
		return isGenderSpecific;
	}

	/**
	 * @return the genderName
	 */
	public WebElement getGenderName() {
		return genderName;
	}
	
}
