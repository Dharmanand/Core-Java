package com.atk.himma.pageobjects.mbuadmin.master.tabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class VisitCategoryDetailsTab extends DriverWaitClass{
	
	public final static String FORM_ID = "VISIT_CATEGORY_DETAILS";
	public final static String MBUCODE_NAME = "mainBusinessUnit.unitCode";
	public final static String MBUNAME_NAME = "mainBusinessUnit.unitName";
	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Save']";
	public final static String CANCEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_top']//input[@value='Cancel']";
	public final static String ADDRECORDGRIDBUTTON_XPATH = "//div[@class='ui-pg-div']//span[@class='ui-icon ui-icon-plus']";
	public final static String POPUPTITLE_ID = "ui-dialog-title-popUpVisitCategory";
	public final static String ADDRECORDPOPUP_ID = "POPUP_DETAILS";
	public final static String VISITCATEGORYNAME_ID = "OM_VISIT_CATEGORY";
	public final static String VISITTYPE_NAME = "multiselect_VISIT_TYPE";
	public final static String APPLICABLEBILLINGCLASS_NAME = "multiselect_BILLING_CLASS";
	public final static String ADDBUTTON_ID = "ADD_BUTTON";
	public final static String UPDATEBUTTON_ID = "UPDATE_BUTTON";
	public final static String CANCELBUTTON_ID = "CANCEL_BUTTON";
	public final static String GRID_ID = "GET_VISIT_CATEGORY_INFO"; 
	public final static String GRID_VISITCATEGORYNAME_ARIA_DESCRIBEDBY = "GET_VISIT_CATEGORY_INFO_baseLV.longDesc"; 
	public final static String GRID_VISITTYPE_ARIA_DESCRIBEDBY = "GET_VISIT_CATEGORY_INFO_";
	public final static String GRID_BILLINGCLASS_ARIA_DESCRIBEDBY = "GET_VISIT_CATEGORY_INFO_";
	
	@FindBy(id=FORM_ID)
	private WebElement form;
	
	@FindBy(name=MBUCODE_NAME)
	private WebElement mbuCode;
	
	@FindBy(name=MBUNAME_NAME)
	private WebElement mbuName;
	
	@FindBy(xpath=SAVEBUTTON_XPATH)
	private WebElement saveButton;
	
	@FindBy(xpath=CANCEBUTTON_XPATH)
	private WebElement canceButton;
	
//	----------------------------------------------  Grid Start -----------------------------------------
	
	@FindBy(xpath=ADDRECORDGRIDBUTTON_XPATH)
	private WebElement addRecordGridButton;
	
	@FindBy(id=ADDRECORDPOPUP_ID)
	private WebElement  addRecordPopup;
	
	@FindBy(id=VISITCATEGORYNAME_ID)
	private WebElement  visitCategoryName;
	
	public void clickOnVisitType(String visitType)
	{
		String visitTypeXpath = "//input[@title='"+visitType.trim()+"' and @name='"+VISITTYPE_NAME+"']";
		waitForElementXpathExpression(visitTypeXpath);
		if(!webDriver.findElement(By.xpath(visitTypeXpath)).isSelected())
		webDriver.findElement(By.xpath(visitTypeXpath)).click();
	}
	
	public void clickOnApplicableBillingClass(String billingClass)
	{
		String visitTypeXpath = "//input[@title='"+billingClass.trim()+"' and @name='"+APPLICABLEBILLINGCLASS_NAME+"']";
		waitForElementXpathExpression(visitTypeXpath);
		if(!webDriver.findElement(By.xpath(visitTypeXpath)).isSelected())
		webDriver.findElement(By.xpath(visitTypeXpath)).click();
	}

	@FindBy(id=POPUPTITLE_ID)
	private WebElement  popUpTitle;
	
	@FindBy(id=ADDBUTTON_ID)
	private WebElement  addButtonPopUp;
	
	@FindBy(id=UPDATEBUTTON_ID)
	private WebElement  updateButtonPopUp;
	
	@FindBy(id=CANCELBUTTON_ID)
	private WebElement  cancelButtonPopUp;

	/**
	 * @return the form
	 */
	public WebElement getForm() {
		return form;
	}

	/**
	 * @return the mbuCode
	 */
	public WebElement getMbuCode() {
		return mbuCode;
	}

	/**
	 * @return the mbuName
	 */
	public WebElement getMbuName() {
		return mbuName;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the canceButton
	 */
	public WebElement getCanceButton() {
		return canceButton;
	}

	/**
	 * @return the addRecordGridButton
	 */
	public WebElement getAddRecordGridButton() {
		return addRecordGridButton;
	}

	/**
	 * @return the addRecordPopup
	 */
	public WebElement getAddRecordPopup() {
		return addRecordPopup;
	}

	/**
	 * @return the visitCategoryName
	 */
	public WebElement getVisitCategoryName() {
		return visitCategoryName;
	}

	/**
	 * @return the addButtonPopUp
	 */
	public WebElement getAddButtonPopUp() {
		return addButtonPopUp;
	}

	/**
	 * @return the cancelButtonPopUp
	 */
	public WebElement getCancelButtonPopUp() {
		return cancelButtonPopUp;
	}

	/**
	 * @return the popUpTitle
	 */
	public WebElement getPopUpTitle() {
		return popUpTitle;
	}

	/**
	 * @return the updateButtonPopUp
	 */
	public WebElement getUpdateButtonPopUp() {
		return updateButtonPopUp;
	}

//	----------------------------------------------  Grid End -----------------------------------------
}
