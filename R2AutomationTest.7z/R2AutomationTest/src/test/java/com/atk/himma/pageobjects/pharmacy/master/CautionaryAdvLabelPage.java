package com.atk.himma.pageobjects.pharmacy.master;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.pharmacy.sections.CautAdvLabDetailsFirstSection;
import com.atk.himma.pageobjects.pharmacy.tabs.CautioanryAdvLabelListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;

public class CautionaryAdvLabelPage extends DriverWaitClass {

	CautioanryAdvLabelListTab cautioanryAdvLabelListTab;
	CautAdvLabDetailsFirstSection cautAdvLabDetailsFirstSection;

	public CautionaryAdvLabelPage setInstanceOfAllSection(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		cautioanryAdvLabelListTab = PageFactory.initElements(webDriver,
				CautioanryAdvLabelListTab.class);
		cautioanryAdvLabelListTab.setWebDriver(webDriver);
		cautioanryAdvLabelListTab.setWebDriverWait(webDriverWait);

		cautAdvLabDetailsFirstSection = PageFactory.initElements(webDriver,
				CautAdvLabDetailsFirstSection.class);
		cautAdvLabDetailsFirstSection.setWebDriver(webDriver);
		cautAdvLabDetailsFirstSection.setWebDriverWait(webDriverWait);

		CautionaryAdvLabelPage cautionaryAdvLabelPage = PageFactory
				.initElements(webDriver, CautionaryAdvLabelPage.class);
		cautionaryAdvLabelPage.setWebDriver(webDriver);
		cautionaryAdvLabelPage.setWebDriverWait(webDriverWait);
		return cautionaryAdvLabelPage;

	}

	public CautionaryAdvLabelPage checkCautAdvLabelLink(WebDriver webDriver,
			WebDriverWait webDriverWait) {

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(menuList,
				"Cautionary/ Advisory Label");
		CautionaryAdvLabelPage cautionaryAdvLabelPage = PageFactory
				.initElements(webDriver, CautionaryAdvLabelPage.class);
		return cautionaryAdvLabelPage;

	}

	public CautionaryAdvLabelPage clickCautAdvLabelMenu() throws Exception {

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Pharmacy");
		menuList.add("Masters ");
		menuSelector.clickOnTargetMenu(menuList, "Cautionary/ Advisory Label");
		CautionaryAdvLabelPage cautionaryAdvLabelPage = PageFactory
				.initElements(webDriver, CautionaryAdvLabelPage.class);
		cautionaryAdvLabelPage.setWebDriver(webDriver);
		cautionaryAdvLabelPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		waitForElementId(CautioanryAdvLabelListTab.GRID_ID);
		return cautionaryAdvLabelPage;

	}

	public void selORUnSelChemicalSubGrp(String chemicalSubGrps,
			boolean selectFlag) {

		String chemSubGrps[] = chemicalSubGrps.split("\\,");
		for (String chSubGrp : chemSubGrps) {
			WebElement element = webDriver
					.findElement(By.xpath("//span[contains(text(), '"
							+ chSubGrp.trim()
							+ "')]/../input[@name='multiselect_CHEMICAL_SUB_GROUP_ID']"));
			if ((!element.isSelected() && selectFlag)
					|| (element.isSelected() && !selectFlag))
				element.click();

		}
	}

	public boolean isMandatoryLabelCode() {
		return isMandatoryField(cautAdvLabDetailsFirstSection.getLabelCode());
	}

	public boolean isMandatoryLabelType() {
		return isMandatoryField(cautAdvLabDetailsFirstSection.getLabelType());
	}

	public boolean isMandatoryLabelDescription() {
		return isMandatoryField(cautAdvLabDetailsFirstSection
				.getLabelDescription());
	}

	public boolean fillCautAdvLabelDatas(String[] cautAdvLabDetailsDatas) {

		if (!cautAdvLabDetailsDatas[0].isEmpty()) {
			cautAdvLabDetailsFirstSection.getLabelCode().clear();
			cautAdvLabDetailsFirstSection.getLabelCode().sendKeys(
					cautAdvLabDetailsDatas[0].trim());
		}

		if (!cautAdvLabDetailsDatas[1].isEmpty()) {
			new Select(cautAdvLabDetailsFirstSection.getLabelType())
					.selectByVisibleText(cautAdvLabDetailsDatas[1].trim());
		}

		if (!cautAdvLabDetailsDatas[2].isEmpty()) {
			cautAdvLabDetailsFirstSection.getLabelDescription().clear();
			cautAdvLabDetailsFirstSection.getLabelDescription().sendKeys(
					cautAdvLabDetailsDatas[2].trim());
		}

		if (!cautAdvLabDetailsDatas[3].isEmpty()) {
			cautAdvLabDetailsFirstSection.getLabelDescriptionAr().clear();
			cautAdvLabDetailsFirstSection.getLabelDescriptionAr().sendKeys(
					cautAdvLabDetailsDatas[3].trim());
		}

		return new Select(cautAdvLabDetailsFirstSection.getLabelType())
				.getFirstSelectedOption().getText().trim() == cautAdvLabDetailsDatas[1]
				.trim();
	}

	public boolean saveData() {
		waitForElementCssSelector(CautAdvLabDetailsFirstSection.SAVEBUTTON_CSS);
		cautAdvLabDetailsFirstSection.getSaveButton().click();
		waitForElementCssSelector(CautAdvLabDetailsFirstSection.UPDATEBUTTON_CSS);
		return cautAdvLabDetailsFirstSection.getUpdateButton().isDisplayed();
	}

	public boolean updateData(String[] cautAdvLabDetailsDatas) {

		waitForElementCssSelector(CautAdvLabDetailsFirstSection.UPDATEBUTTON_CSS);
		if (!cautAdvLabDetailsDatas[0].isEmpty()) {
			cautAdvLabDetailsFirstSection.getLabelCode().clear();
			cautAdvLabDetailsFirstSection.getLabelCode().sendKeys(
					cautAdvLabDetailsDatas[0].trim());
		}

		if (!cautAdvLabDetailsDatas[1].isEmpty()) {
			new Select(cautAdvLabDetailsFirstSection.getLabelType())
					.selectByVisibleText(cautAdvLabDetailsDatas[1].trim());
		}

		if (!cautAdvLabDetailsDatas[2].isEmpty()) {
			cautAdvLabDetailsFirstSection.getLabelDescription().clear();
			cautAdvLabDetailsFirstSection.getLabelDescription().sendKeys(
					cautAdvLabDetailsDatas[2].trim());
		}

		if (!cautAdvLabDetailsDatas[3].isEmpty()) {
			cautAdvLabDetailsFirstSection.getLabelDescriptionAr().clear();
			cautAdvLabDetailsFirstSection.getLabelDescriptionAr().sendKeys(
					cautAdvLabDetailsDatas[3].trim());
		}
		cautAdvLabDetailsFirstSection.getUpdateButton().click();
		return new Select(cautAdvLabDetailsFirstSection.getLabelType())
				.getFirstSelectedOption().getText().trim() == cautAdvLabDetailsDatas[1]
				.trim();
	}

}
