package com.atk.himma.pageobjects.sa.admin.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class MainBusinessUnitsTab extends DriverWaitClass {
	public final static String MBUREGSETTINGSFORM_NAME = "regionalSettings";
	@FindBy(name = MBUREGSETTINGSFORM_NAME)
	private WebElement mbuRegSettingsForm;

	public final static String EDITDEFSETTINGSBTN_ID = "DEF_SETTINGS";
	@FindBy(id = EDITDEFSETTINGSBTN_ID)
	private WebElement editDefSettingsBtn;

	public WebElement getMbuRegSettingsForm() {
		return mbuRegSettingsForm;
	}

	public WebElement getEditDefSettingsBtn() {
		return editDefSettingsBtn;
	}

}
