package com.atk.himma.pageobjects.apoe;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class VitalsPopupPage extends DriverWaitClass {
	public final static String VITALSFORM_ID = "ADD_VITALSIGNS_POPUP";
	@FindBy(id = VITALSFORM_ID)
	private WebElement vitalsPopupForm;

	public final static String HEIGHT_ID = "HEIGHT";
	@FindBy(id = HEIGHT_ID)
	private WebElement vitalsPopupHeight;

	public final static String WEIGHT_ID = "WEIGHT";
	@FindBy(id = WEIGHT_ID)
	private WebElement vitalsPopupWeight;

	public final static String BMI_ID = "BMI";
	@FindBy(id = BMI_ID)
	private WebElement vitalsPopupBMI;

	public final static String BLOODPRESSURE_ID = "BLOOD_PRESSURE";
	@FindBy(id = BLOODPRESSURE_ID)
	private WebElement bloodPressure;

	public final static String TEMPERATURE_ID = "TEMPERATURE";
	@FindBy(id = TEMPERATURE_ID)
	private WebElement vitalsPopupTemperature;

	public final static String PULSE_ID = "PULSE";
	@FindBy(id = PULSE_ID)
	private WebElement vitalsPopupPulse;

	public final static String O2SATURATION_ID = "SATURATION";
	@FindBy(id = O2SATURATION_ID)
	private WebElement O2Saturation;

	public final static String RESPIRATORY_ID = "RESPIRATORY";
	@FindBy(id = RESPIRATORY_ID)
	private WebElement vitalsPopupRespiratory;

	public final static String ADDVITALSBTN_ID = "ADD_VITAL_SIGNS_POPUP_BUTTON";
	@FindBy(id = ADDVITALSBTN_ID)
	private WebElement addVitalsPopupBtn;

	public final static String UPDATEVITALSBTN_ID = "ADD_VITAL_SIGNS_POPUP_BUTTON";
	@FindBy(id = UPDATEVITALSBTN_ID)
	private WebElement updateVitalsPopupBtn;

	public final static String RESETVITALSBTN_XPATH = "CANCEL_VITAL_SIGNS";
	@FindBy(xpath = RESETVITALSBTN_XPATH)
	private WebElement resetVitalsBtn;

	public final static String VITALSGRIDTBL_ID = "VITAL_SIGNS_GRID";
	@FindBy(id = VITALSGRIDTBL_ID)
	private WebElement vitalsGridTbl;

	public final static String CANCELBTN_ID = "VITAL_SIGN_POPUP_CANCEL_BUTTON";
	@FindBy(id = CANCELBTN_ID)
	private WebElement cancelBtn;

	public final static String SUBMITBTN_ID = "SUBMIT_VITAL_BUTTON";
	@FindBy(id = SUBMITBTN_ID)
	private WebElement submitBtn;

	public void addVitalsDetails(String[] orderEntryListData) throws Exception {
		vitalsPopupHeight.clear();
		vitalsPopupHeight.sendKeys(orderEntryListData[11]);
		vitalsPopupWeight.clear();
		vitalsPopupWeight.sendKeys(orderEntryListData[12]);
		vitalsPopupBMI.clear();
		vitalsPopupBMI.sendKeys(orderEntryListData[13]);
		bloodPressure.clear();
		bloodPressure.sendKeys(orderEntryListData[14]);
		vitalsPopupTemperature.clear();
		vitalsPopupTemperature.sendKeys(orderEntryListData[15]);
		vitalsPopupPulse.clear();
		vitalsPopupPulse.sendKeys(orderEntryListData[16]);
		O2Saturation.clear();
		O2Saturation.sendKeys(orderEntryListData[17]);
		vitalsPopupRespiratory.clear();
		vitalsPopupRespiratory.sendKeys(orderEntryListData[18]);

	}

	public void clickResetVitalsBtn() {
		resetVitalsBtn.click();

	}

	public void clickAddVitalsBtn() {
		addVitalsPopupBtn.click();
		waitForElementId(VITALSGRIDTBL_ID);
	}

	public String checkVitalsDataGrid(String[] outPatientListData) {
		return waitAndGetGridFirstCellText(VITALSGRIDTBL_ID,
				"VITAL_SIGNS_GRID_height", outPatientListData[11]);
	}

	public boolean checkEditLink(String[] orderEntryListData) {
		waitForElementXpathExpression("//td[@aria-describedby='VITAL_SIGNS_GRID_height' and @title='"
				+ orderEntryListData[11] + "']/..//a[@title='Edit']");
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='VITAL_SIGNS_GRID_height' and @title='"
								+ orderEntryListData[11]
								+ "']/..//a[@title='Edit']")).isDisplayed();
	}

	public boolean checkRemoveLink(String[] orderEntryListData) {
		waitForElementXpathExpression("//td[@aria-describedby='VITAL_SIGNS_GRID_height' and @title='"
				+ orderEntryListData[11] + "']/..//a[@title='Delete']");
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='VITAL_SIGNS_GRID_height' and @title='"
								+ orderEntryListData[11]
								+ "']/..//a[@title='Delete']")).isDisplayed();
	}

	public void editVitalsDetails(String[] orderEntryListData) {
		clickOnGridAction("VITAL_SIGNS_GRID_height", orderEntryListData[11],
				"Edit");
		vitalsPopupWeight.clear();
		vitalsPopupWeight.sendKeys(orderEntryListData[12]);
		vitalsPopupBMI.clear();
		vitalsPopupBMI.sendKeys(orderEntryListData[13]);
		bloodPressure.clear();
		bloodPressure.sendKeys(orderEntryListData[14]);

	}

	public void clickUpdateVitalsBtn() throws Exception {
		updateVitalsPopupBtn.click();
		sleepVeryShort();
	}

	public String checkUpdatedVitalsDtl(String[] orderEntryListData) {
		return webDriver
				.findElement(
						By.xpath("//td[@aria-describedby='VITAL_SIGNS_GRID_weight' and @title='"
								+ orderEntryListData[12] + "'")).getText();
	}

	public boolean removeVitalsDetails(String[] orderEntryListData) {
		clickOnGridAction("ALLERGIES_POPUP_GRID_ID_allergyName",
				orderEntryListData[0], "Delete");
		boolean result = false;
		try {
			result = webDriver
					.findElement(
							By.xpath("//td[@aria-describedby='VITAL_SIGNS_GRID_height' and @title='"
									+ orderEntryListData[11] + "'"))
					.isDisplayed();
		} catch (Exception e) {

		}
		return result;
	}

	public void submitVitalsDetails() throws Exception {
		submitBtn.click();
		sleepShort();

	}

	public void clickCancelBtn() {
		cancelBtn.click();

	}

	public boolean isVitalsPopupDisplayed() {
		waitForElementId(VITALSFORM_ID);
		return vitalsPopupForm.isDisplayed();
	}

	public WebElement getVitalsPopupForm() {
		return vitalsPopupForm;
	}

	public WebElement getVitalsPopupHeight() {
		return vitalsPopupHeight;
	}

	public WebElement getVitalsPopupWeight() {
		return vitalsPopupWeight;
	}

	public WebElement getVitalsPopupBMI() {
		return vitalsPopupBMI;
	}

	public WebElement getBloodPressure() {
		return bloodPressure;
	}

	public WebElement getVitalsPopupTemperature() {
		return vitalsPopupTemperature;
	}

	public WebElement getVitalsPopupPulse() {
		return vitalsPopupPulse;
	}

	public WebElement getO2Saturation() {
		return O2Saturation;
	}

	public WebElement getVitalsPopupRespiratory() {
		return vitalsPopupRespiratory;
	}

	public WebElement getAddVitalsPopupBtn() {
		return addVitalsPopupBtn;
	}

	public WebElement getUpdateVitalsPopupBtn() {
		return updateVitalsPopupBtn;
	}

	public WebElement getResetVitalsBtn() {
		return resetVitalsBtn;
	}

	public WebElement getVitalsGridTbl() {
		return vitalsGridTbl;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

}
