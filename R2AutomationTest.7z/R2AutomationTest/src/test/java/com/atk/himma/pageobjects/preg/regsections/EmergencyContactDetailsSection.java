package com.atk.himma.pageobjects.preg.regsections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.util.DriverWaitClass;

public class EmergencyContactDetailsSection extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "Emergency Contact Details";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	private final static String PERSONNAME_NAME = "emrgconDetailsList[0].personName";

	@FindBy(name = PERSONNAME_NAME)
	private WebElement personName;

	private final static String RELATIONSHIP_NAME = "emrgconDetailsList[0].relation";

	@FindBy(name = RELATIONSHIP_NAME)
	private WebElement relationship;

	private final static String HOMEPHONECODE_ID = "emrgHomePhone0";

	@FindBy(id = HOMEPHONECODE_ID)
	private WebElement homePhoneCode;

	private final static String HOMEPHONENUMBER_ID = "emrgShmNo0";

	@FindBy(id = HOMEPHONENUMBER_ID)
	private WebElement homePhoneNumber;

	private final static String ADDRESS_ID = "address";

	@FindBy(id = ADDRESS_ID)
	private WebElement address;

	private final static String MOBILECODE_ID = "emrgMoblie0";

	@FindBy(id = MOBILECODE_ID)
	private WebElement mobileCode;

	private final static String MOBILENUMBER_ID = "emrgSmobpNo0";

	@FindBy(id = MOBILENUMBER_ID)
	private WebElement mobileNumber;

	private final static String WORKPHONECODE_ID = "emrgWorkPh0";

	@FindBy(id = WORKPHONECODE_ID)
	private WebElement workPhoneCode;

	private final static String WORKPHONENUMBER_ID = "emrgSworkNo0";

	@FindBy(id = WORKPHONENUMBER_ID)
	private WebElement workPhoneNumber;

	private final static String WORKPHONEEXTENSION_ID = "emrgSworkExtNo0";

	@FindBy(id = WORKPHONEEXTENSION_ID)
	private WebElement workPhoneExtension;

	private final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Emergency Contact Details')]/..";

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public void fillDatasOfEmergencyContactDetailsSection(String[] excelData,
			WebDriverWait webDriverWait) throws InterruptedException {
		// getSectionName().click();
		// sleepVeryShort();
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			getSectionName().click();
		webDriverWait.until(ExpectedConditions.visibilityOf(getPersonName()));
		getPersonName().clear();
		getPersonName().sendKeys(excelData[61].trim());
		new Select(getRelationship()).selectByVisibleText(excelData[62].trim());
		new Select(getHomePhoneCode())
				.selectByVisibleText(excelData[63].trim());
		getHomePhoneNumber().clear();
		getHomePhoneNumber().sendKeys(excelData[64].trim());
		getAddress().clear();
		getAddress().sendKeys(excelData[65].trim());
		new Select(getMobileCode()).selectByVisibleText(excelData[66].trim());
		getMobileNumber().clear();
		getMobileNumber().sendKeys(excelData[67].trim());
		new Select(getWorkPhoneCode())
				.selectByVisibleText(excelData[68].trim());
		getWorkPhoneNumber().clear();
		getWorkPhoneNumber().sendKeys(excelData[69].trim());
		getWorkPhoneExtension().clear();
		getWorkPhoneExtension().sendKeys(excelData[70].trim());
	}

	/**
	 * @return the webDriver
	 */
	public WebDriver getWebDriver() {
		return webDriver;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the personName
	 */
	public WebElement getPersonName() {
		return personName;
	}

	/**
	 * @return the relationship
	 */
	public WebElement getRelationship() {
		return relationship;
	}

	/**
	 * @return the homePhoneCode
	 */
	public WebElement getHomePhoneCode() {
		return homePhoneCode;
	}

	/**
	 * @return the homePhoneNumber
	 */
	public WebElement getHomePhoneNumber() {
		return homePhoneNumber;
	}

	/**
	 * @return the address
	 */
	public WebElement getAddress() {
		return address;
	}

	/**
	 * @return the mobileCode
	 */
	public WebElement getMobileCode() {
		return mobileCode;
	}

	/**
	 * @return the mobileNumber
	 */
	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the workPhoneCode
	 */
	public WebElement getWorkPhoneCode() {
		return workPhoneCode;
	}

	/**
	 * @return the workPhoneNumber
	 */
	public WebElement getWorkPhoneNumber() {
		return workPhoneNumber;
	}

	/**
	 * @return the workPhoneExtension
	 */
	public WebElement getWorkPhoneExtension() {
		return workPhoneExtension;
	}

	/**
	 * @return the sectionnameLinktext
	 */
	public static String getSectionnameLinktext() {
		return SECTIONNAME_LINKTEXT;
	}

	/**
	 * @return the personnameName
	 */
	public static String getPersonnameName() {
		return PERSONNAME_NAME;
	}

	/**
	 * @return the relationshipName
	 */
	public static String getRelationshipName() {
		return RELATIONSHIP_NAME;
	}

	/**
	 * @return the homephonecodeId
	 */
	public static String getHomephonecodeId() {
		return HOMEPHONECODE_ID;
	}

	/**
	 * @return the homephonenumberId
	 */
	public static String getHomephonenumberId() {
		return HOMEPHONENUMBER_ID;
	}

	/**
	 * @return the addressId
	 */
	public static String getAddressId() {
		return ADDRESS_ID;
	}

	/**
	 * @return the mobilecodeId
	 */
	public static String getMobilecodeId() {
		return MOBILECODE_ID;
	}

	/**
	 * @return the mobilenumberId
	 */
	public static String getMobilenumberId() {
		return MOBILENUMBER_ID;
	}

	/**
	 * @return the workphonecodeId
	 */
	public static String getWorkphonecodeId() {
		return WORKPHONECODE_ID;
	}

	/**
	 * @return the workphonenumberId
	 */
	public static String getWorkphonenumberId() {
		return WORKPHONENUMBER_ID;
	}

	/**
	 * @return the workphoneextensionId
	 */
	public static String getWorkphoneextensionId() {
		return WORKPHONEEXTENSION_ID;
	}

	/**
	 * @return the sectioncollapseexpandXpath
	 */
	public static String getSectioncollapseexpandXpath() {
		return SECTIONCOLLAPSEEXPAND_XPATH;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

}
