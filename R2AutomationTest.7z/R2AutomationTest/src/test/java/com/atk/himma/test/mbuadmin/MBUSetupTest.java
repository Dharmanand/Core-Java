package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.LoginPage;
import com.atk.himma.pageobjects.mbuadmin.MBUSetupPage;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.BusinessTimings;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.DWMParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.GeneralDetails;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.MoreAppParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.mbudetails.RegConfiguration;
import com.atk.himma.pageobjects.mbuadmin.tabs.MBUSetupListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class MBUSetupTest extends SeleniumDriverSetup {

	LoginPage loginPage;
	List<String[]> mbuSetupDatas;
	MBUSetupPage mbuSetupPage;

	@Test(description = "Open MBU Setup Page")
	public void openMBUSetupPage() throws InterruptedException {
		mbuSetupPage = PageFactory.initElements(webDriver, MBUSetupPage.class);
		mbuSetupPage = mbuSetupPage.clickOnMBUSetupMenu(webDriver,
				webDriverWait);
		mbuSetupPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(mbuSetupPage);
		mbuSetupPage.waitForElementVisibilityOf(mbuSetupPage
				.getMbuSetupListTab().getForm());
		mbuSetupPage.waitForElementId(MBUSetupListTab.FORM_ID);
		mbuSetupPage.sleepVeryShort();
		mbuSetupPage
				.waitForElementXpathExpression(MBUSetupListTab.SEARCHBUTTON_XPATH);
		mbuSetupPage.sleepVeryShort();
		Assert.assertEquals(mbuSetupPage.getMbuSetupListTab().getMbuListTab()
				.getAttribute("title").trim(), "Main Business Unit List",
				"Fail to open MBU Setup Page.");
	}

	/*
	 * 
	 * // [List Tab] Configure (Link in the search result grid)
	 */
	// [Main Business Unit] Open Form
	@Test(description = "Open MBU Setup Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkMBUSetupMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		mbuSetupPage = PageFactory.initElements(webDriver, MBUSetupPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(baseLVParentMenuList, "MBU Setup");
		mbuSetupPage.setWebDriver(webDriver);
		mbuSetupPage.setWebDriverWait(webDriverWait);
		mbuSetupPage.waitForElementXpathExpression(MBUSetupPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("MBU Setup")
				.get("[Main Business Unit] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(MBUSetupPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Main Business Unit] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			mbuSetupPage = mbuSetupPage.clickOnMBUSetupMenu(webDriver,
					webDriverWait);
			mbuSetupPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(mbuSetupPage);
			mbuSetupPage
					.waitForElementXpathExpression(MBUSetupListTab.SEARCHBUTTON_XPATH);
			mbuSetupPage.sleepShort();
			Assert.assertEquals(mbuSetupPage.getMbuSetupListTab()
					.getMbuListTab().getAttribute("title").trim(),
					"Main Business Unit List", "Fail to open MBU Setup Page.");
		}
	}

	@Test(description = "search MBU", dependsOnMethods = "openMBUSetupPage", groups={"MBUConfigureGrp"})
	public void test1SearchMBU() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		mbuSetupDatas = excelReader.read(properties.getProperty("MBUSetup"));
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.searchMBU(st).trim(),
					st[0].trim(), "Fail to Search MBU from Grid.");
	}

	@Test(description = "Click On Configure Link", dependsOnMethods = "test1SearchMBU", groups={"MBUConfigureGrp"})
	public void test2clickOnConfigLink() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.configureMBU(st).trim(),
					st[0].trim(), "Fail to Click On Configure Link.");
	}

	// first section
	@Test(description = "Check MBU First Section", dependsOnMethods = "test2clickOnConfigLink", groups={"MBUConfigureGrp"})
	public void test3CheckMBUFirstSec() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getMbuFirstSection()
					.checkMBUFirstSection(st), true,
					"First Section is not displayed yet.");
	}

	// General Details Section
	@Test(description = "Check General Details Section Open", dependsOnMethods = "test2clickOnConfigLink", groups={"MBUConfigureGrp"})
	public void test4CheckGenDetSecOpen() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getGeneralDetails()
				.checkGenDetSecOpen(), true,
				"Fill Datas of First Section has failed");
	}

	@Test(description = "Check Business Timing Section", dependsOnMethods = "test2clickOnConfigLink", groups={"MBUConfigureGrp"})
	public void test5CheckBusTimSection() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getBusinessTimings()
				.checkBusTimSection(), true,
				"Failed to Check Business Timing Section");
	}

	@Test(description = "Check Registration Configuration Section", dependsOnMethods = "test2clickOnConfigLink", groups={"MBUConfigureGrp"})
	public void test6CheckRegConfigSection() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getRegConfiguration()
				.checkRegConfigSection(), false,
				"Failed to Checked Registration Configuration Section");
	}

	// OPD Registration Section
	@Test(description = "Check OPD Registration Section", dependsOnMethods = "test2clickOnConfigLink", groups={"MBUConfigureGrp"})
	public void test7CheckOPDRegSection() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.checkOPDRegSection(), true,
				"Failed to Check OPD Registration Section");
	}

	// first section tests
	@Test(description = "Check License Text Length Validation", dependsOnMethods = "test3CheckMBUFirstSec", groups={"MBUConfigureGrp"})
	public void test8LicenseTxtLengValid() throws Exception {
		Assert.assertEquals(mbuSetupPage.getMbuFirstSection()
				.licenseTxtLengValid(),
				"Please enter no more than 50 characters.",
				"license text Length Validation failed.");
	}

	@Test(description = "Fill Datas of First Section", dependsOnMethods = "test3CheckMBUFirstSec", groups={"MBUConfigureGrp"})
	public void test9FillDatasOfFirstSec() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getMbuFirstSection()
					.fillDatasOfFirstSection(st), true,
					"Fill Datas of First Section has failed");
	}

	// General Details Section
	@Test(description = "Check General Details Section Open", dependsOnMethods = "test4CheckGenDetSecOpen", groups={"MBUConfigureGrp"})
	public void test10FillDatasOfGenDetSec() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
		Assert.assertEquals(mbuSetupPage.getGeneralDetails()
				.fillDatasOfGenDetSec(st), true,
				"Failed to Fill Datas of General Details Section");
	}

	@Test(description = "fill Datas of MBU Timings", dependsOnMethods = "test5CheckBusTimSection", groups={"MBUConfigureGrp"})
	public void test11FillDatasMBUTimings() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getBusinessTimings()
					.fillDatasMBUTimings(st), true,
					"Failed to Check Business Timing Section");
	}

	@Test(description = "Check Fill Datas Other Timings", dependsOnMethods = "test5CheckBusTimSection", groups={"MBUConfigureGrp"})
	public void test12FillDatasOtherTimings() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getBusinessTimings()
					.fillDatasOtherTimings(st), true,
					"Failed to fill Datas of Other Timings");
	}

	@Test(description = "Check Fill Datas Other Timings", dependsOnMethods = "test5CheckBusTimSection", groups={"MBUConfigureGrp"})
	public void test13FillDatasDailySession() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getBusinessTimings()
					.fillDatasDailySession(st), false,
					"Failed to fill Datas of Daily Session");
	}

	@Test(description = "Fill Datas in Registration Section", dependsOnMethods = "test6CheckRegConfigSection", groups={"MBUConfigureGrp"})
	public void test14FillDatasInSection() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getRegConfiguration()
					.fillDatasInSection(st), true,
					"Failed to Fill Datas in Registration Section");
	}

	@Test(description = "Check Mandatory Slot Interval", dependsOnMethods = "test7CheckOPDRegSection", groups={"MBUConfigureGrp"})
	public void test15IsMandSlotInterval() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandatorySlotInterval(), true,
				"Failed to Check Mandatory Slot Interval");
	}

	@Test(description = "Check Mandatory Slot Block Interval", dependsOnMethods = "test7CheckOPDRegSection", groups={"MBUConfigureGrp"})
	public void test16IsMandSlotBlInterval() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandSlotBlInterval(), true,
				"Failed to Check Mandatory Slot Block Interval");
	}

	@Test(description = "Check fill Datas Up To SMS Section", dependsOnMethods = "test7CheckOPDRegSection", groups={"MBUConfigureGrp"})
	public void test17FillDatasUpToSMSSec() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getOpdParameters()
					.fillDatasUpToSMSSection(st), true,
					"Failed to fill Datas Up To SMS Section");
	}

	@Test(description = "Check fill Datas To Consultation Charged", dependsOnMethods = "test7CheckOPDRegSection", groups={"MBUConfigureGrp"})
	public void test18IFillDatasToConsulChar() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getOpdParameters()
					.fillDatasToConsulCharged(st), true,
					"Failed to fill Datas To Consultation Charged");
	}

	@Test(description = "Check Mandatory Free Charge Pattern", dependsOnMethods = "test7CheckOPDRegSection", groups={"MBUConfigureGrp"})
	public void test19IsMandFreeChargePattern() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandFreeChargePattern(), true,
				"Failed to Check Mandatory Free Charge Pattern");
	}

	@Test(description = "Check fill Datas To Triage Consultation", dependsOnMethods = "test7CheckOPDRegSection", groups={"MBUConfigureGrp"})
	public void test20FillDatasToTriageConsul() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getOpdParameters()
					.fillDatasToTriageConsul(st), true,
					"Failed to fill Datas To Triage Consultation");
	}

	@Test(description = "Save MBU Datas", dependsOnMethods = "test20FillDatasToTriageConsul", groups={"MBUConfigureGrp"})
	public void test21SaveMBUDatas() throws InterruptedException, IOException {
		Assert.assertEquals(mbuSetupPage.saveDetailsPage().contains("Update"),
				true, "Failed to Save MBU Datas");
	}

	@Test(description = "Activate Record", dependsOnMethods = "test21SaveMBUDatas", groups={"MBUConfigureGrp"})
	public void test22ActivateRecord() throws InterruptedException {
		Assert.assertEquals(mbuSetupPage.activateRecord().contains("Active"),
				true, "Failed Activate Record");
	}

	@Test(description = "Sign Out", dependsOnMethods = "test22ActivateRecord", groups={"MBUConfigureGrp"})
	public void SignOut() throws Exception {
		loginPage = mbuSetupPage.signOut();
		Assert.assertEquals(loginPage.getLoginButton().getAttribute("value")
				.equals("Log In"), true, "Failed Sign Out");
	}

	@Test(description = "Sign-In", dependsOnMethods = "SignOut", groups={"MBUConfigureGrp"})
	public void login() throws Exception {
		excelReader.setInputFile(properties.getProperty("loginExcel"));
		Assert.assertEquals(loginPage.login(3,
				excelReader.read(properties.getProperty("loginSheetName"))),
				"User Home", "Failed Login");
		mbuSetupPage.clickOnMBUSetupMenu(webDriver, webDriverWait);
		mbuSetupPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(mbuSetupPage);
		mbuSetupPage.waitForElementVisibilityOf(mbuSetupPage
				.getMbuSetupListTab().getForm());
		mbuSetupPage.waitForElementId(MBUSetupListTab.FORM_ID);
		mbuSetupPage.sleepVeryShort();
		mbuSetupPage
				.waitForElementXpathExpression(MBUSetupListTab.SEARCHBUTTON_XPATH);
		mbuSetupPage.sleepVeryShort();
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.searchMBU(st).trim(),
					st[0].trim(), "Fail to Search MBU from Grid.");
	}
	
	@Test(description = "search MBU For edit", dependsOnMethods = { "openMBUSetupPage" }, groups={"MBUEditGrp"})
	public void test23SearchMBUForEdit() throws InterruptedException,
			IOException {
		mbuSetupPage.getMbuSetupListTab().getMbuListTab().click();
		mbuSetupPage.waitForElementXpathExpression(MBUSetupListTab.SEARCHBUTTON_XPATH);
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		mbuSetupDatas = excelReader.read(properties.getProperty("MBUSetup"));
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.searchMBU(st).trim(),
					st[0].trim(), "Fail to Search MBU from Grid.");
	}

	@Test(description = "Click On Edit Link", dependsOnMethods = "test23SearchMBUForEdit", groups={"MBUEditGrp"})
	public void test24ClickOnEditLink() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.editMBUSetup(st).trim(),
					st[0].trim(), "Fail to Click On Edit Link.");
	}

	@Test(description = "Check OPD Registration Section", dependsOnMethods = "test24ClickOnEditLink", groups={"MBUEditGrp"})
	public void test25CheckOPDRegSecAtEdit() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.checkOPDRegSection(), true,
				"Failed to Check OPD Registration Section");
	}

	@Test(description = "Failed to click on Add Button", dependsOnMethods = "test25CheckOPDRegSecAtEdit", groups={"MBUEditGrp"})
	public void test26ClickOnAddButton() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getOpdParameters()
					.clickOnAddButton(st), "Add Record",
					"Failed to click on Add Button");
	}

	@Test(description = "Check Mandatory Visit Category", dependsOnMethods = "test26ClickOnAddButton", groups={"MBUEditGrp"})
	public void test27IsMandVisitCategory() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandVisitCategory(), true,
				"Failed to Check Mandatory Visit Category");
	}

	@Test(description = "Check Mandatory Visit Type", dependsOnMethods = "test26ClickOnAddButton", groups={"MBUEditGrp"})
	public void test28IsMandVisitType() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandVisitCategory(), true,
				"Failed to Check Mandatory Visit Type");
	}

	@Test(description = "Check Mandatory FollowUps Allowed", dependsOnMethods = "test26ClickOnAddButton", groups={"MBUEditGrp"})
	public void test29IsMandFollowUpsAllowed() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandFollowUpsAllowed(), true,
				"Failed to Check Mandatory FollowUps Allowed");
	}

	@Test(description = "Check Mandatory Follow Ups Duration", dependsOnMethods = "test26ClickOnAddButton", groups={"MBUEditGrp"})
	public void test30IsMandFollowUpsDuration() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.isMandFollowUpsAllowed(), true,
				"Failed to Check Follow Ups Duration");
	}

	@Test(description = "fill Datas of PopUp", dependsOnMethods = "test26ClickOnAddButton", groups={"MBUEditGrp"})
	public void test31FillDatasToPopUp() throws InterruptedException,
			IOException {
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.getOpdParameters()
					.fillDatasToPopUp(st), true,
					"Failed to fill Datas of PopUp");
	}

	@Test(description = "Submit Visit Category Datas", dependsOnMethods = "test31FillDatasToPopUp", groups={"MBUEditGrp"})
	public void test32SubmitVisitCatDatas() throws InterruptedException,
			IOException {
		Assert.assertEquals(mbuSetupPage.getOpdParameters()
				.submitFollowUpDatas(), false,
				"Failed to Submit Visit Category Datas");
	}

	@Test(description = "Update MBU Datas", dependsOnMethods = "test32SubmitVisitCatDatas", groups={"MBUEditGrp"})
	public void test33UpdateMBUDatas() throws InterruptedException, IOException {
		Assert.assertEquals(
				mbuSetupPage.updateMBUDetails()
						.contains("updated successfully"), true,
				"Failed to update MBU Datas");
	}

	// Privileges check
	
	// [List Tab] Configure (Link in the search result grid)

		@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking More Appointment Parameters section privileges")
		public void checkConfigureLinkSecPrivil() throws Exception {
			boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
					webDriver,
					By.xpath(".//td[@title='"
							+ mbuSetupDatas.subList(0, 1).get(0)[0].trim()
							+ "']/..//a[text()='Configure']"));
			Assert.assertEquals(actualPrivilage, true,
					"Fail to check [List Tab] Configure (Link in the search result grid) privilege");
		}
	
	@Test(dependsOnMethods = { "checkMBUSetupMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Clinic for Privilege")
	public void searchMBUForPrivilege() throws Exception {
		mbuSetupPage.getMbuSetupListTab().getMbuListTab().click();
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		mbuSetupDatas = excelReader.read(properties.getProperty("MBUSetup"));
		for (String st[] : mbuSetupDatas.subList(0, 1))
			Assert.assertEquals(mbuSetupPage.searchMBU(st), st[0].trim(),
					"Fail to Search MBU result");
	}

	// [List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchMBUForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check View link for Privilege")
	public void checkViewLinkPrivilege() throws IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		mbuSetupDatas = excelReader.read(properties.getProperty("MBUSetup"));
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("MBU Setup")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ mbuSetupDatas.subList(0, 1).get(0)[0].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");
	}

	// [List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "searchMBUForPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Check Edit Link for Privilege")
	public void checkEditLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("MBU Setup")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ mbuSetupDatas.subList(0, 1).get(0)[0].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
		mbuSetupPage.clickOnGridAction(
				mbuSetupDatas.subList(0, 1).get(0)[1].trim(), "Edit");
		mbuSetupPage
				.waitForElementXpathExpression(MBUSetupPage.UPDATECONFMSG_XPATH);
	}

	// [Details Tab] [Section: General Details] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking General Details section privileges")
	public void checkGenDetailsSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("MBU Setup")
				.get("[Details Tab] [Section: General Details] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(GeneralDetails.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: General Details] View");
	}

	// [Details Tab] [Section: Business Timings] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Business Timings section privileges")
	public void checkBusTimingsSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("MBU Setup")
				.get("[Details Tab] [Section: Business Timings] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(BusinessTimings.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Business Timings] View");
	}

	// [Details Tab] [Section: Registration Configuration] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Registration Configuration section privileges")
	public void checkRegConfSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("MBU Setup")
				.get("[Details Tab] [Section: Registration Configuration] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(RegConfiguration.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Registration Configuration] View");
	}

	// [Details Tab] [Section: Out Patient Department Parameters] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking Out Patient Department Parameters section privileges")
	public void checkOutPatDepParSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("MBU Setup")
				.get("[Details Tab] [Section: Out Patient Department Parameters] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(RegConfiguration.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(
				actualPrivilege,
				expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Out Patient Department Parameters] View");
	}

	// [Details Tab] [Section: More Appointment Parameters] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking More Appointment Parameters section privileges")
	public void checkMoreAppParamSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("MBU Setup")
				.get("[Details Tab] [Section: More Appointment Parameters] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(MoreAppParameters.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: More Appointment Parameters] View");
	}

	// [Details Tab] [Section: Doctors Workbench Module Parameters] View
	@Test(dependsOnMethods = { "checkEditLinkPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "Checking More Appointment Parameters section privileges")
	public void checkDWMParamSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("MBU Setup")
				.get("[Details Tab] [Section: Doctors Workbench Module Parameters] View");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.linkText(DWMParameters.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(
				actualPrivilege,
				expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Doctors Workbench Module Parameters] View");
	}

	// [Details Tab] [Section: Audit Trail] View
	// [MBU Setup] Work On Global Masters

}
