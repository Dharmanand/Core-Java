package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.ClinicPage;
import com.atk.himma.pageobjects.mbuadmin.OtherLocationPage;
import com.atk.himma.pageobjects.mbuadmin.sections.clinicdetails.AppointmentParameters;
import com.atk.himma.pageobjects.mbuadmin.sections.otherlocationdetails.OtherLocFirstSection;
import com.atk.himma.pageobjects.mbuadmin.tabs.OtherLocListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class OtherLocationTest extends SeleniumDriverSetup {

	List<String[]> otherLocDatas;
	OtherLocationPage otherLocationPage;

	@Test(description = "Open Other Location Page")
	public void clickOnOtherLocMenu() throws InterruptedException {
		otherLocationPage = PageFactory.initElements(webDriver,
				OtherLocationPage.class);
		otherLocationPage = otherLocationPage.clickOnOtherLocMenu(webDriver,
				webDriverWait);
		otherLocationPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		otherLocationPage.waitForElementVisibilityOf(otherLocationPage
				.getOtherLocListTab().getSearchButton());
		Assert.assertEquals(otherLocationPage.getOtherLocListTab()
				.getOtherLocListTab().getAttribute("title").trim(),
				"Other Location List", "Fail to Open Other Location Page");
	}

// [Other Location] Open Form
	@Test(description = "Open Other Location Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkOtherLocMenuLink() throws InterruptedException,
			IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		otherLocationPage = PageFactory.initElements(webDriver,
				OtherLocationPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Other Location");
		otherLocationPage.setWebDriver(webDriver);
		otherLocationPage.setWebDriverWait(webDriverWait);
		otherLocationPage
				.waitForElementXpathExpression(OtherLocationPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[Other Location] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(OtherLocationPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Other Location] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			otherLocationPage = otherLocationPage.clickOnOtherLocMenu(
					webDriver, webDriverWait);
			otherLocationPage.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			otherLocationPage.waitForElementVisibilityOf(otherLocationPage
					.getOtherLocListTab().getSearchButton());
			Assert.assertEquals(otherLocationPage.getOtherLocListTab()
					.getOtherLocListTab().getAttribute("title").trim(),
					"Other Location List", "Fail to Open Other Location Page");
			otherLocationPage
					.waitForElementXpathExpression(OtherLocListTab.ADDNEWOTHERLOCBUTTON_XPATH);
			otherLocationPage.sleepVeryShort();
			otherLocationPage.getOtherLocListTab().getAddNewOtherLocButton()
					.click();
			otherLocationPage.waitForElementId(OtherLocFirstSection.MBU_ID);
			otherLocationPage
					.waitForElementId(OtherLocFirstSection.DEPARTMENT_ID);
			otherLocationPage.sleepShort();
		}
	}

	@Test(description = "click On Add New Button", dependsOnMethods = "clickOnOtherLocMenu")
	public void test1ClickOnAddNewButton() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		otherLocDatas = excelReader.read(properties.getProperty("otherLocation"));
		for (String st[] : otherLocDatas)
			Assert.assertEquals(otherLocationPage.clickOnAddNewOtherLoc(st),
					true, "Fail to click On Add New Button.");
	}

	@Test(description = "click Mandatory Location Short Name", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test2IsMandLocShortNM() {
		Assert.assertEquals(otherLocationPage.getOtherLocFirstSection()
				.isMandatoryLocShortNM(), true,
				"Fail to Mandatory Location Short Name.");
	}

	@Test(description = "click Mandatory Location", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test3IsMandLocName() {
		Assert.assertEquals(otherLocationPage.getOtherLocFirstSection()
				.isMandatoryLocName(), true, "Fail to click Mandatory Location");
	}

	@Test(description = "click Mandatory MBU", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test4IsMandMBU() {
		Assert.assertEquals(otherLocationPage.getOtherLocFirstSection()
				.isMandatoryMBU(), true, "Fail to Mandatory MBU.");
	}

	@Test(description = "click Mandatory Location Category", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test5IsMandLocCategory() {
		Assert.assertEquals(otherLocationPage.getOtherLocFirstSection()
				.isMandatoryLocCategory(), true,
				"Fail to click Mandatory Location Category");
	}

	@Test(description = "Fill datas of Other Location First Section", dependsOnMethods = "test1ClickOnAddNewButton")
	public void test6FillSerFirstSecDatas() throws InterruptedException {
		for (String st[] : otherLocDatas)
			Assert.assertEquals(otherLocationPage.getOtherLocFirstSection()
					.fillDatas(st), true,
					"Fail to Fill datas of Other Location First Section");
	}

	@Test(description = "check Subscribing Locations Section", dependsOnMethods = {
			"test1ClickOnAddNewButton"})
	public void test7CheckSubscriLocSection() throws InterruptedException {
		Assert.assertEquals(otherLocationPage.getSubscribingLocations()
				.checkSubscriLocSection(), true,
				"Fail to check Subscribing Locations Section");
	}

	@Test(description = "Fill datas of Subscribing Locations", dependsOnMethods = "test7CheckSubscriLocSection")
	public void test8FillSubscriLocDatas() throws InterruptedException {
		for (String st[] : otherLocDatas)
			Assert.assertEquals(otherLocationPage.getSubscribingLocations()
					.fillDatas(st), false,
					"Fail to Fill datas of Subscribing Locations");
	}

	@Test(description = "Save Service", dependsOnMethods = {
			"test8FillSubscriLocDatas" })
	public void test9SaveOtherLoc() throws InterruptedException, IOException {
		Assert.assertEquals(
				otherLocationPage.saveDetailsPage().contains("Update"), true,
				"Fail to Save Service.");
	}

	@Test(description = "Activate Service", dependsOnMethods = "test9SaveOtherLoc")
	public void test10ActivateOtherLoc() throws InterruptedException, IOException {
		Assert.assertEquals(otherLocationPage.activate().contains("Active"),
				true, "Fail to Activate Service.");
	}

	@Test(description="Check Duplicate other location Data", dependsOnMethods={"test9SaveOtherLoc"})
	public void test11SaveDuplicateOtherLoc() throws InterruptedException, IOException {
		for (String st[] : otherLocDatas)
		{
			otherLocationPage.waitForElementXpathExpression(OtherLocationPage.DETAILSUPDATEBUTTON_XPATH);
			otherLocationPage.getAddNewButton().click();
			otherLocationPage.waitForElementXpathExpression(OtherLocationPage.DETAILSSAVEBUTTON_XPATH);
			Assert.assertEquals(otherLocationPage.getOtherLocFirstSection()
					.fillDatas(st), true,
					"Fail to Fill datas of Other Location First Section");
				Assert.assertEquals(otherLocationPage.getSubscribingLocations()
						.fillDatas(st), false,
						"Fail to Fill datas of Subscribing Locations");
			Assert.assertTrue(otherLocationPage.saveDuplicateData(st),"Fail to Check Duplicate other location Data");
		}
	}
	
// [Details Tab] [Section: Subscribing Locations]
	@Test(dependsOnMethods = { "checkOtherLocMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Checking [Details Tab] [Section: Subscribing Locations] section privileges")
	public void checkAppointParamSecPrivil() {
		boolean actualPrivilege = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[Details Tab] [Section: Subscribing Locations]");
		boolean expectedPrivilege = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(AppointmentParameters.SECTIONNAME_LINKTEXT));
		Assert.assertEquals(actualPrivilege, expectedPrivilege,
				"Fail Privilege of [Details Tab] [Section: Subscribing Locations]");
	}

	@Test(dependsOnMethods = { "checkOtherLocMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Clinic for Privilege")
	public void searchOtherLocPrivilege() throws Exception {
		otherLocationPage.clickOtherLocListTab();
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		otherLocDatas = excelReader.read(properties.getProperty("otherLocation"));
		for (String st[] : otherLocDatas.subList(0, 1))
			Assert.assertEquals(
					otherLocationPage.searchOtherLocData(st[7].trim()),
					st[7].trim(), "Fail to Search Other location");
	}

// [List Tab] Add New (Button)
	@Test(dependsOnMethods = { "searchOtherLocPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Add New (Button) for Privilege")
	public void checkAddNewButtonPrivilege() throws IOException {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(OtherLocListTab.ADDNEWOTHERLOCBUTTON_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button)");
	}
	
// 	[List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchOtherLocPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] View (Link in the search result grid) link for Privilege")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ otherLocDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");
	}


// [List Tab] Edit (Link in the search result grid)
	@Test(dependsOnMethods = { "searchOtherLocPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Edit (Link in the search result grid) link for Privilege")
	public void checkEditLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[List Tab] Edit (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ otherLocDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='Edit']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit (Link in the search result grid) privilege");
	}

// [List Tab] Delete(Link in the search result grid)
	@Test(dependsOnMethods = { "searchOtherLocPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Delete(Link in the search result grid) link for Privilege")
	public void checkDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[List Tab] Delete(Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ otherLocDatas.subList(0, 1).get(0)[7].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete(Link in the search result grid) privilege");
	}

// [List Tab] Export to Excel (Button)
	@Test(dependsOnMethods = { "searchOtherLocPrivilege" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Export to Excel (Button) for Privilege")
	public void checkExpToExcelButPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Other Location")
				.get("[List Tab] Export to Excel (Button)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(OtherLocListTab.EXPORTTOEXCEL_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Export to Excel (Button) privilege");
	}

// [Details Tab] [Section: Audit Trail] View
}
