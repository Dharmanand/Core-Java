package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.contracts.RatePlanPage;
import com.atk.himma.pageobjects.contracts.sections.rateplandetails.PriceModifParametersSection;
import com.atk.himma.pageobjects.contracts.sections.rateplandetails.RatePlanTariffSection;
import com.atk.himma.pageobjects.contracts.tabs.RatePlanListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class RatePlanTest extends SeleniumDriverSetup {
	RatePlanPage ratePlanPage;
	List<String[]> ratePlanList;

	@Test(description = "Open Rate Plan Page")
	public void test001OpenRatePlanPage() throws Exception {
		ratePlanPage = PageFactory.initElements(webDriver, RatePlanPage.class);
		ratePlanPage = ratePlanPage.clickOnRatePlanMenu(webDriver,
				webDriverWait);
		ratePlanPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		Assert.assertNotNull(ratePlanPage);
		ratePlanPage.waitForElementVisibilityOf(ratePlanPage
				.getRatePlanListTab().getRatePlanForm());
		ratePlanPage.waitForElementVisibilityOf(ratePlanPage
				.getRatePlanListTab().getMbu());
		Assert.assertTrue(ratePlanPage.getRatePlanListTab().getMbu()
				.isDisplayed());

	}

	@Test(description = "Check For Add New Rate Plan Button", dependsOnMethods = { "test001OpenRatePlanPage" })
	public void test002CheckForAddNewRatePlanBtn() throws Exception {
		Assert.assertTrue(ratePlanPage.getRatePlanListTab().getAddNewRPBtn()
				.isDisplayed());
	}

	@Test(description = "Click On Add New Rate Plan Button", dependsOnMethods = { "test002CheckForAddNewRatePlanBtn" })
	public void test003ClickOnAddNewRatePlanBtn() throws Exception {
		ratePlanPage.getRatePlanListTab().clickAddNewRatePlan();
		ratePlanPage.waitForElementVisibilityOf(ratePlanPage
				.getRatePlanDetailsForm());
		ratePlanPage.waitForElementVisibilityOf(ratePlanPage
				.getRpDetailsFirstSection().getRatePlanName());
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.getRatePlanName().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Rate Plan Name Field", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test004ValidateRatePlanNameMandatoryField() throws Exception {
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.isMandRatePlanName());

	}

	@Test(description = "Validate Mandatory for Debtor Name Field", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test005ValidateDebtorNameMandatoryField() throws Exception {
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.isMandDebtorName());

	}

	@Test(description = "Validate Mandatory for Agreement Name Field", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test006ValidateAgrmntNameMandatoryField() throws Exception {
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.isMandAgrmntName());

	}

	@Test(description = "Validate Mandatory for MBU Name Field", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test007ValidateMBUNameMandatoryField() throws Exception {
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.isMandMBUName());

	}

	@Test(description = "Validate Mandatory for Effective Start Date Field", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test008ValidateStartDateMandatoryField() throws Exception {
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.isMandStartDate());

	}

	@Test(description = "Validate Mandatory for Effective End Date Field", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test009ValidateEndDateMandatoryField() throws Exception {
		Assert.assertTrue(ratePlanPage.getRpDetailsFirstSection()
				.isMandEndDate());

	}

	@Test(description = "Fill Rate Plan First Section Fields", dependsOnMethods = { "test003ClickOnAddNewRatePlanBtn" })
	public void test010AddRatePlanFirstSectionData() throws Exception {
		ratePlanList = excelReader.read(properties.getProperty("ratePlan"));
		if (ratePlanList != null && !ratePlanList.isEmpty()) {
			for (String[] ratePlanListData : ratePlanList.subList(0, 1)) {
				ratePlanPage.getRpDetailsFirstSection().fillData(
						ratePlanListData);
				Assert.assertEquals(ratePlanPage.getRpDetailsFirstSection()
						.getSelectedMBU(), ratePlanListData[9]);

			}
		}

	}

	@Test(description = "Fill Price Modification Parameters Section Fields", dependsOnMethods = { "test010AddRatePlanFirstSectionData" })
	public void test011AddPriceModificationParametersSectionData()
			throws Exception {
		if (ratePlanList != null && !ratePlanList.isEmpty()) {
			for (String[] ratePlanListData : ratePlanList.subList(0, 1)) {
				ratePlanPage.getPriceModifParametersSection()
						.addPriceModifParamData(ratePlanListData);

			}
		}

	}

	@Test(description = "Save Rate Plan", dependsOnMethods = { "test010AddRatePlanFirstSectionData" })
	public void test012SaveRatePlan() throws Exception {
		ratePlanPage.saveRatePlanDetails();
		Assert.assertTrue(ratePlanPage.getUpdateBtn().isEnabled()
				&& ratePlanPage.getAddNewBtn().isEnabled());
	}

	@Test(description = "Apply Version", dependsOnMethods = { "test012SaveRatePlan" })
	public void test013ApplyVersionForRatePlan() throws Exception {
		ratePlanPage.applyVersion();
		// Assert.assertFalse(ratePlanPage.getApplyVersionBtn().isEnabled());
		Assert.assertTrue(ratePlanPage.getPublishedLbl().isDisplayed());

	}

	// [Rate Plan] Open Form
	@Test(description = "Check Rate Plan Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckRatePlanPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		ratePlanPage = PageFactory.initElements(webDriver, RatePlanPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> rpParentMenuList = new LinkedList<String>();
		rpParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(rpParentMenuList, "Rate Plan");
		ratePlanPage.setWebDriver(webDriver);
		ratePlanPage.setWebDriverWait(webDriverWait);
		ratePlanPage.waitForElementXpathExpression(RatePlanPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Rate Plan").get("[Rate Plan] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RatePlanPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Rate Plan] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			ratePlanPage = ratePlanPage.clickOnRatePlanMenu(webDriver,
					webDriverWait);
			ratePlanPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(ratePlanPage);
			ratePlanPage.waitForElementVisibilityOf(ratePlanPage
					.getRatePlanListTab().getRatePlanForm());
			ratePlanPage.sleepShort();
			Assert.assertEquals(ratePlanPage.getPageTitle().getText(),
					"Rate Plan");
		}

	}

	// [List Tab] Add New Rate Plan (Button)
	@Test(description = "Check Add New Rate Plan Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckRatePlanPageMenuLink")
	public void test02CheckAddNewRatePlanBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Rate Plan")
				.get("[List Tab] Add New Rate Plan (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(RatePlanListTab.ADDNEWRPBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Add New Rate Plan (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckRatePlanPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		ratePlanList = excelReader.read(properties.getProperty("ratePlan"));
		for (String[] ratePlanData : ratePlanList) {
			ratePlanPage.getRatePlanListTab().searchRatePlanList(ratePlanData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Rate Plan")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RatePlanListTab.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckRatePlanPageMenuLink")
	public void test04CheckLink2Edit() throws Exception {
		ratePlanList = excelReader.read(properties.getProperty("ratePlan"));
		for (String[] ratePlanData : ratePlanList) {
			ratePlanPage.getRatePlanListTab().searchRatePlanList(ratePlanData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Rate Plan")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RatePlanListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		if (actualPrivilage)
			ratePlanPage.getRatePlanListTab()
					.clickEditLink(ratePlanList.get(0));
	}

	// [Details Tab][Section: Price Modification Parameters] View
	@Test(description = "Check Price Modification Parameters Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test04CheckLink2Edit")
	public void test05CheckPriceModifParamSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Rate Plan")
				.get("[Details Tab][Section: Price Modification Parameters] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(PriceModifParametersSection.PRICEMODIFPARAMSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Price Modification Parameters] View privilege");
	}

	// [Details Tab][Section: Price Modification Parameters] Non Rate Plan
	// Service Discount (Check box group)
	@Test(description = "Check Non Rate Plan Service Discount Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckPriceModifParamSec")
	public void test07CheckNonRPServDiscChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Rate Plan")
				.get("[Details Tab][Section: Price Modification Parameters] Non Rate Plan Service Discount (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(PriceModifParametersSection.NONRPSERVDISC_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Price Modification Parameters] Non Rate Plan Service Discount (Check box group) privilege");
	}

	// [Details Tab][Section: Rate Plan Tariff] View
	@Test(description = "Check Price Modification Parameters Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test04CheckLink2Edit")
	public void test06CheckRatePlanTariffSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Rate Plan")
				.get("[Details Tab][Section: Rate Plan Tariff] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.linkText(RatePlanTariffSection.RATEPLANTARIFFSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Rate Plan Tariff] View privilege");
	}

	// [Details Tab][Section: Rate Plan Tariff] Add Services (Button)
	@Test(description = "Check Add Services Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckRatePlanTariffSec")
	public void test08CheckAddServiceBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Rate Plan")
				.get("[Details Tab][Section: Rate Plan Tariff] Add Services (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(RatePlanTariffSection.ADDSERVBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Rate Plan Tariff] Add Services (Button) privilege");
	}

	// [Details Tab][Section: Rate Plan Tariff] View Services (Link in the grid)
	@Test(description = "Check View Services Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckRatePlanTariffSec")
	public void test09CheckViewServLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Rate Plan")
				.get("[Details Tab][Section: Rate Plan Tariff] View Services (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RatePlanTariffSection.VIEWSERVLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Rate Plan Tariff] View Services (Link in the grid) privilege");
	}

	// [Details Tab][Section: Audit Trail] View

	// [Details Tab][Popup: Export to Excel]

}