package com.atk.himma.pageobjects.radiology.sections;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class BillingScenarioSection extends DriverWaitClass{
	
	public final static String ADDROWBUTTON_ID = "addNewBillingInfo";

	// -----------GRID--------------
	public final static String GRID_ID = "rsbs_GRID";
	public final static String GRID_VISITCATEGORY_ARIA_DESCRIBEDBY = "rsbs_GRID_visitCatIds.value";
	public final static String GRID_BEFORESTAGE_ARIA_DESCRIBEDBY = "rsbs_GRID_billingStageId";
	public final static String GRID_ACTION_ARIA_DESCRIBEDBY = "rsbs_GRID_action";
	public final static String GRID_PAGERID = "sp_1_rsbs_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_rsbs_GRID_pager']";

	// -----------GRID's Fields--------------
	public final static String VISITCATEGORYBTN_XPATH = "//table[@id='"
			+ GRID_ID + "']";
	public final static String BEFORESTAGEDD_CSS = "td[aria-describedby='"+GRID_BEFORESTAGE_ARIA_DESCRIBEDBY+"'] select[name='billingStageId']";
//	public final static String ADDINSTRUCTIONACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/select/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Add Instruction']";
//	public final static String DELETEACTION_GE_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/select/../../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";
//	public final static String DELETEACTION_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Delete']";
//	public final static String EDITINSTRUCTIONACTION_XPATH = "//td[@aria-describedby='"+GRID_GENDER_ARIA_DESCRIBEDBY+"']/../td[@aria-describedby='"+GRID_ACTION_ARIA_DESCRIBEDBY+"']/a[text()='Edit Instruction']";
	
	@FindBy(id = ADDROWBUTTON_ID)
	private WebElement addRowButton;

	@FindBy(xpath = VISITCATEGORYBTN_XPATH)
	private WebElement visitCategoryBtn;

	@FindBy(xpath = BEFORESTAGEDD_CSS)
	private WebElement beforeStageDD;

	public void selectVisitCategory(String visitCategoryName) {
		String cssPath = "label input[type='checkbox'][title='"
				+ visitCategoryName.trim() + "']";
		waitForElementCssSelector(cssPath);
		webDriver.findElement(By.cssSelector(cssPath)).click();
	}

	/**
	 * @return the addRowButton
	 */
	public WebElement getAddRowButton() {
		return addRowButton;
	}

	/**
	 * @return the visitCategoryBtn
	 */
	public WebElement getVisitCategoryBtn() {
		return visitCategoryBtn;
	}

	/**
	 * @return the beforeStageDD
	 */
	public WebElement getBeforeStageDD() {
		return beforeStageDD;
	}
	
}
