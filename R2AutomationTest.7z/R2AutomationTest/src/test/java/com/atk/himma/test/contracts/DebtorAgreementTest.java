package com.atk.himma.test.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.contracts.DebtorAgreementPage;
import com.atk.himma.pageobjects.contracts.sections.approvallistdetails.ApprovalListDetailsSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.AgrmntDocumentsScanSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.AssociatedPoliciesSection;
import com.atk.himma.pageobjects.contracts.sections.debtoragrmntdetails.FinancialParametersSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.DebtorAgreementListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups = { "functionalTestGrp" })
public class DebtorAgreementTest extends SeleniumDriverSetup {
	private final static String STD_DISC_PATT = "Standard Discount Pattern",
			AGRMNT_RATEPLAN = "Agreement Rate Plan";
	DebtorAgreementPage debtorAgreementPage;
	List<String[]> debtorList;
	List<String[]> debtorAgrmntList;
	List<String[]> serviceExclusionList;
	List<String[]> icdExclusionList;
	List<String[]> itemExclusionList;
	List<String[]> serviceApprvlList;
	List<String[]> icdApprvlList;
	List<String[]> itemApprvlList;

	@Test(description = "Open Debtor Agreement Page")
	public void test001OpenDebtorAgreementPage() throws Exception {
		debtorAgreementPage = PageFactory.initElements(webDriver,
				DebtorAgreementPage.class);
		debtorAgreementPage = debtorAgreementPage.clickOnDebtorAgreementMenu(
				webDriver, webDriverWait);
		debtorAgreementPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		debtorAgrmntList = excelReader.read(properties
				.getProperty("debtorAgreement"));
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		icdExclusionList = excelReader.read(properties
				.getProperty("ICDExcListDetails"));
		itemExclusionList = excelReader.read(properties
				.getProperty("itemExcListDetails"));
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		icdApprvlList = excelReader.read(properties
				.getProperty("ICDApprvListDetails"));
		itemApprvlList = excelReader.read(properties
				.getProperty("itemApprvListDetails"));
		debtorList = excelReader.read(properties.getProperty("debtor"));

		Assert.assertNotNull(debtorAgreementPage);
		debtorAgreementPage.waitForElementVisibilityOf(debtorAgreementPage
				.getDebtorAgreementListTab().getDebtorAgrmntListForm());
		debtorAgreementPage.waitForElementVisibilityOf(debtorAgreementPage
				.getDebtorAgreementListTab().getMbuList());
		Assert.assertTrue(debtorAgreementPage.getDebtorAgreementListTab()
				.getMbuList().isDisplayed());

	}

	@Test(description = "Check For Add New Debtor Agreement Button", dependsOnMethods = { "test001OpenDebtorAgreementPage" })
	public void test002CheckForAddNewDebtorAgrmntBtn() throws Exception {
		Assert.assertTrue(debtorAgreementPage.getDebtorAgreementListTab()
				.getAddNewAgrmntBtn().isDisplayed());
	}

	@Test(description = "Click On Add New Debtor Agreement Button", dependsOnMethods = { "test002CheckForAddNewDebtorAgrmntBtn" })
	public void test003ClickOnAddNewDebtorAgrmntBtn() throws Exception {
		debtorAgreementPage.getDebtorAgreementListTab()
				.clickAddNewDebtorAgrmnt();
		debtorAgreementPage.waitForElementVisibilityOf(debtorAgreementPage
				.getAgrmntDetailsForm());
		debtorAgreementPage.waitForElementVisibilityOf(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().getAgrmntRefNum());
		Assert.assertTrue(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().getAgrmntRefNum()
				.isDisplayed());

	}

	@Test(description = "Validate Mandatory for Agreement Reference Number Field", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test004ValidateAgrmntRefNumMandatoryField() throws Exception {
		Assert.assertTrue(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().isMandAgrmntRefNumber());

	}

	@Test(description = "Validate Mandatory for Agreement Billing Type Field", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test005ValidateAgrmntBillingTypeMandatoryField()
			throws Exception {
		Assert.assertTrue(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().isMandAgrmntBillingType());

	}

	@Test(description = "Validate Mandatory for Debtor Name Field", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test006ValidateDebtorNameMandatoryField() throws Exception {
		Assert.assertTrue(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().isMandDebtorName());

	}

	@Test(description = "Validate Mandatory for MBU Field", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test007ValidateMBUNameMandatoryField() throws Exception {
		Assert.assertTrue(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().isMandMBUName());

	}

	@Test(description = "Validate Mandatory for Agreement Name Field", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test008ValidateAgreementNameMandatoryField() throws Exception {
		Assert.assertTrue(debtorAgreementPage
				.getDebtorAgrmntDetailsFirstSection().isMandAgreementName());

	}

	@Test(description = "Fill Debtor Agreement First Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test009AddDebtorAgrmntFirstSectionData() throws Exception {
		if (debtorAgrmntList != null && !debtorAgrmntList.isEmpty()) {
			for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
				debtorAgreementPage.getDebtorAgrmntDetailsFirstSection()
						.fillData(debtorAgrmntListData);
				Assert.assertEquals(debtorAgreementPage
						.getDebtorAgrmntDetailsFirstSection().getSelectedMBU(),
						debtorAgrmntListData[3]);
			}
		}

	}

	@Test(description = "Fill Agreement Documents Scan Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test010AddAgrmntDocumentScanSectionData() throws Exception {
		if (debtorAgrmntList != null && !debtorAgrmntList.isEmpty()) {
			for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
				debtorAgreementPage.getAgrmntDocumentsScanSection()
						.addAgrmntDocsData(debtorAgrmntListData);
				Assert.assertTrue(debtorAgreementPage
						.getAgrmntDocumentsScanSection().checkAgrmntDocGrid(
								debtorAgrmntListData));
			}
		}

	}

	@Test(description = "Fill Financial Parameters Section Fields", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test011AddFinancialParametersSectionData() throws Exception {
		if (debtorAgrmntList != null && !debtorAgrmntList.isEmpty()) {
			for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
				debtorAgreementPage.getFinancialParametersSection()
						.addFinancialParamData(debtorAgrmntListData);
				Assert.assertTrue(debtorAgreementPage
						.getFinancialParametersSection().getStdDiscPatternDiv()
						.isDisplayed()
						|| debtorAgreementPage.getFinancialParametersSection()
								.getAgrmntRatePlanDiv().isDisplayed());
			}
		}
	}

	@Test(description = "Fill Standard Discount Pattern/Agreement Specific Rate Plan", dependsOnMethods = { "test011AddFinancialParametersSectionData" })
	public void test012AddAgrmntTariffPatternData() throws Exception {
		if (debtorAgrmntList != null && !debtorAgrmntList.isEmpty()) {
			for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
				if (STD_DISC_PATT.equals(debtorAgrmntListData[46])) {
					debtorAgreementPage.getStandardDiscountPatternSection()
							.addStdDiscPatternData(debtorAgrmntListData);

				} else if (AGRMNT_RATEPLAN.equals(debtorAgrmntListData[46])) {
					debtorAgreementPage.getAgrmntSpecificRatePlanSection()
							.addAgrmntSpecRatePlanData(debtorAgrmntListData);
					Assert.assertEquals(debtorAgreementPage
							.getAgrmntSpecificRatePlanSection()
							.getItemLvlList().getAttribute("value"),
							debtorAgrmntListData[55]);

				}
			}
		}

	}

	@Test(description = "Expand Exclusion List Details Section", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test013ExpandExclusionListDetailsSection() throws Exception {
		debtorAgreementPage.collapseExpandExcSection();
		Assert.assertTrue(debtorAgreementPage.getExcSectionDiv().isDisplayed());

	}

	@Test(description = "Expand Approval List Details Section", dependsOnMethods = { "test003ClickOnAddNewDebtorAgrmntBtn" })
	public void test014ExpandApprovalListDetailsSection() throws Exception {
		debtorAgreementPage.collapseExpandApprvlSection();
		Assert.assertTrue(debtorAgreementPage.getApprvlSectionDiv()
				.isDisplayed());

	}

	@Test(description = "Add Service Pattern Exclusion List Details", dependsOnMethods = { "test013ExpandExclusionListDetailsSection" })
	public void test015AddServiceExclusionListDetailsData() throws Exception {
		if (serviceExclusionList != null && !serviceExclusionList.isEmpty()) {
			for (String[] serviceExclusionListData : serviceExclusionList
					.subList(2, 3)) {
				debtorAgreementPage.getExclusionListDetailsSection()
						.addServiceExclusionData(serviceExclusionListData);
				Assert.assertEquals(debtorAgreementPage
						.getExclusionListDetailsSection().getServiceLvlName()
						.getAttribute("value"), serviceExclusionListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Exclusion List Details", dependsOnMethods = { "test013ExpandExclusionListDetailsSection" })
	public void test016AddICDExclusionListDetailsData() throws Exception {
		if (icdExclusionList != null && !icdExclusionList.isEmpty()) {
			for (String[] icdExclusionListData : icdExclusionList.subList(2, 3)) {
				debtorAgreementPage.getExclusionListDetailsSection()
						.addICDExclusionData(icdExclusionListData);
				Assert.assertEquals(debtorAgreementPage
						.getExclusionListDetailsSection().getIcdPatternDesc()
						.getAttribute("value"), icdExclusionListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Exclusion List Details", dependsOnMethods = { "test013ExpandExclusionListDetailsSection" })
	public void test017AddItemExclusionListDetailsData() throws Exception {
		if (itemExclusionList != null && !itemExclusionList.isEmpty()) {
			for (String[] itemExclusionListData : itemExclusionList.subList(2,
					3)) {
				debtorAgreementPage.getExclusionListDetailsSection()
						.addItemExclusionData(itemExclusionListData);
				Assert.assertEquals(
						debtorAgreementPage.getExclusionListDetailsSection()
								.checkItemLevelData(itemExclusionListData),
						itemExclusionListData[1]);
			}
		}
	}

	@Test(description = "Add Service Pattern Approval List Details", dependsOnMethods = { "test014ExpandApprovalListDetailsSection" })
	public void test018AddServiceApprovalListDetailsData() throws Exception {
		if (serviceApprvlList != null && !serviceApprvlList.isEmpty()) {
			for (String[] serviceApprvlListData : serviceApprvlList.subList(2,
					3)) {
				debtorAgreementPage.getApprovalListDetailsSection()
						.addServiceApprvlData(serviceApprvlListData);
				Assert.assertEquals(debtorAgreementPage
						.getApprovalListDetailsSection().getServiceLvlName()
						.getAttribute("value"), serviceApprvlListData[7]);
			}

		}
	}

	@Test(description = "Add ICD Pattern Approval List Details", dependsOnMethods = { "test014ExpandApprovalListDetailsSection" })
	public void test019AddICDApprvlListDetailsData() throws Exception {
		if (icdApprvlList != null && !icdApprvlList.isEmpty()) {
			for (String[] icdApprvlListData : icdApprvlList.subList(2, 3)) {
				debtorAgreementPage.getApprovalListDetailsSection()
						.addICDApprvlData(icdApprvlListData);
				Assert.assertEquals(debtorAgreementPage
						.getApprovalListDetailsSection().getIcdDescription()
						.getAttribute("value"), icdApprvlListData[2]);
			}
		}
	}

	@Test(description = "Add Item Pattern Approval List Details", dependsOnMethods = { "test014ExpandApprovalListDetailsSection" })
	public void test020AddItemApprvlListDetailsData() throws Exception {
		if (itemApprvlList != null && !itemApprvlList.isEmpty()) {
			for (String[] itemApprvlListData : itemApprvlList.subList(2, 3)) {
				debtorAgreementPage.getApprovalListDetailsSection()
						.addItemApprvlData(itemApprvlListData);
				Assert.assertEquals(
						debtorAgreementPage.getApprovalListDetailsSection()
								.checkItemLevelData(itemApprvlListData),
						itemApprvlListData[1]);
			}
		}
	}

	@Test(description = "Save Debtor Agreement", dependsOnMethods = { "test009AddDebtorAgrmntFirstSectionData" })
	public void test021SaveDebtorAgreement() throws Exception {
		debtorAgreementPage.saveDebtorAgreementDetails();
		Assert.assertTrue(debtorAgreementPage.getUpdateBtn().isEnabled()
				&& debtorAgreementPage.getAddNewBtn().isEnabled());
	}

	@Test(description = "Activate Record", dependsOnMethods = { "test021SaveDebtorAgreement" })
	public void test022ActivateRecord() throws Exception {
		Assert.assertEquals(
				debtorAgreementPage.activateRecord().contains("Active"), true,
				"Failed Activate Record");

	}

	@Test(description = "Verify Agreements Associated to Debtor", dependsOnMethods = { "test022ActivateRecord" })
	public void test023VerifyDebtorAssociatedAgreements() throws Exception {
		if (debtorAgrmntList != null && !debtorAgrmntList.isEmpty()) {
			debtorAgreementPage.clickOnGoToDebtorBtn();
			for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
				Assert.assertTrue(debtorAgreementPage
						.verifyDebtorAssociatedAgreements(debtorAgrmntListData));

			}
		}

	}

	@Test(description = "Apply Exclusion List to Agreements", dependsOnMethods = { "test023VerifyDebtorAssociatedAgreements" })
	public void test024ApplyExcListToAgreements() throws Exception {
		debtorAgreementPage.collapseExpandDebtorExcSection();
		for (String[] debtorData : debtorList.subList(0, 1)) {
			debtorAgreementPage.getExclusionListDetailsSection()
					.applyExcListToAgrmnts(debtorData);
		}

	}

	@Test(description = "Apply Approval List to Agreements", dependsOnMethods = { "test023VerifyDebtorAssociatedAgreements" })
	public void test025ApplyApprvlListToAgreements() throws Exception {
		debtorAgreementPage.collapseExpandDebtorApprvlSection();
		for (String[] debtorData : debtorList.subList(0, 1)) {
			debtorAgreementPage.getApprovalListDetailsSection()
					.applyApprvlListToAgrmnts(debtorData);
		}

	}

	@Test(description = "Update Debtor Details", dependsOnMethods = { "test023VerifyDebtorAssociatedAgreements" })
	public void test026UpdateDebtorDetails() throws Exception {
		debtorAgreementPage.updateDebtorDetails();
	}

	@Test(description = "Search Agreement", dependsOnMethods = { "test023VerifyDebtorAssociatedAgreements" })
	public void test027SearchDebtorAgreement() throws Exception {
		debtorAgreementPage
				.clickOnDebtorAgreementMenu(webDriver, webDriverWait);
		for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
			debtorAgreementPage.getDebtorAgreementListTab()
					.searchDebtorAgreement(debtorAgrmntListData);
		}

	}

	@Test(description = "Verify Debtor Exclusion List Details in Agreement", dependsOnMethods = { "test027SearchDebtorAgreement" })
	public void test028VerifyDebtorExcListInAgrmnt() throws Exception {
		for (String[] serviceExcListData : serviceExclusionList.subList(1, 2)) {
			debtorAgreementPage.collapseExpandExcSection();
			Assert.assertTrue(debtorAgreementPage
					.getExclusionListDetailsSection().checkExcGrid(
							serviceExcListData));
		}

	}

	@Test(description = "Verify Debtor Approval List Details in Agreement", dependsOnMethods = { "test027SearchDebtorAgreement" })
	public void test029VerifyDebtorApprvlListInAgrmnt() throws Exception {
		for (String[] serviceApprvlListData : serviceApprvlList.subList(1, 2)) {
			debtorAgreementPage.collapseExpandApprvlSection();
			Assert.assertTrue(debtorAgreementPage
					.getApprovalListDetailsSection().checkApprvlGrid(
							serviceApprvlListData));

		}

	}

	@Test(description = "Verify Debtor Agreement Name in Policy Creation", dependsOnMethods = { "test027SearchDebtorAgreement" })
	public void test030VerifyDebtorAgrmntName() throws Exception {
		debtorAgreementPage.clickCreateNewPolicyBtn();
		for (String[] debtorAgrmntListData : debtorAgrmntList.subList(0, 1)) {
			Assert.assertEquals(debtorAgreementPage
					.verifyDebtorAgrmnt(debtorAgrmntListData),
					debtorAgrmntListData[9]);
		}

	}

	// [Debtor Agreement] Open Form
	@Test(description = "Check Debtor Agreement Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void test01CheckDebtorAgreementPageMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("ContractsExcel"));
		debtorAgreementPage = PageFactory.initElements(webDriver,
				DebtorAgreementPage.class);

		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> agrmntParentMenuList = new LinkedList<String>();
		agrmntParentMenuList.add("Contracts");
		menuSelector.mouseOverOnTargetMenu(agrmntParentMenuList,
				"Debtor Agreement");
		debtorAgreementPage.setWebDriver(webDriver);
		debtorAgreementPage.setWebDriverWait(webDriverWait);
		debtorAgreementPage
				.waitForElementXpathExpression(DebtorAgreementPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[Debtor Agreement] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorAgreementPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Debtor Agreement] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			debtorAgreementPage = debtorAgreementPage
					.clickOnDebtorAgreementMenu(webDriver, webDriverWait);
			debtorAgreementPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(debtorAgreementPage);
			debtorAgreementPage.waitForElementVisibilityOf(debtorAgreementPage
					.getDebtorAgreementListTab().getDebtorAgrmntListForm());
			debtorAgreementPage.sleepShort();
			Assert.assertEquals(debtorAgreementPage.getPageTitle().getText(),
					"Debtor Agreement");
		}

	}

	// [List Tab] Add New Debtor Agreement (Button)
	@Test(description = "Check Add New Debtor Agreement Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorAgreementPageMenuLink")
	public void test02CheckAddNewDebtorBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[List Tab] Add New Debtor Agreement (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(DebtorAgreementListTab.ADDNEWAGRMNTBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Add New Debtor Agreement (Button) privilege");
	}

	// [List Tab] View (Link in search result grid)
	@Test(description = "Check View Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorAgreementPageMenuLink")
	public void test03CheckLink1View() throws Exception {
		debtorAgrmntList = excelReader.read(properties
				.getProperty("debtorAgreement"));
		for (String[] debtorAgrmntData : debtorAgrmntList) {
			debtorAgreementPage.getDebtorAgreementListTab().searchAgrmntList(
					debtorAgrmntData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[List Tab] View (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorAgreementListTab.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] View (Link in search result grid) privilege");
	}

	// [List Tab] Delete (Link in search result grid)
	@Test(description = "Check Delete Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorAgreementPageMenuLink")
	public void test04CheckLink2Delete() throws Exception {
		debtorAgrmntList = excelReader.read(properties
				.getProperty("debtorAgreement"));
		for (String[] debtorAgrmntData : debtorAgrmntList) {
			debtorAgreementPage.getDebtorAgreementListTab().searchAgrmntList(
					debtorAgrmntData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[List Tab] Delete (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorAgreementListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Delete (Link in search result grid) privilege");
	}

	// [List Tab] Edit (Link in search result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test01CheckDebtorAgreementPageMenuLink")
	public void test05CheckLink3Edit() throws Exception {
		debtorAgrmntList = excelReader.read(properties
				.getProperty("debtorAgreement"));
		for (String[] debtorAgrmntData : debtorAgrmntList) {
			debtorAgreementPage.getDebtorAgreementListTab().searchAgrmntList(
					debtorAgrmntData);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[List Tab] Edit (Link in search result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(DebtorAgreementListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [List Tab] Edit (Link in search result grid) privilege");
		if (actualPrivilage)
			debtorAgreementPage.getDebtorAgreementListTab().clickEditLink(
					debtorAgrmntList.get(0));
	}

	// [Details Tab][Section: Agreement Documents Scan] View
	@Test(description = "Check Agreement Document Scan Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test06CheckAgrmntDocScanSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[Details Tab][Section: Agreement Documents Scan] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(AgrmntDocumentsScanSection.AGRMNTDOCSCANSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Agreement Documents Scan] View privilege");
	}

	// [Details Tab][Section: Agreement Documents Scan] Add Document (Button)
	@Test(description = "Check Add Document Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckAgrmntDocScanSec")
	public void test11CheckAddDocumentBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Agreement Documents Scan] Add Document (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.id(AgrmntDocumentsScanSection.ADDROWAGRMNTDOCBTN));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Agreement Documents Scan] Add Document (Button) privilege");
	}

	// [Details Tab][Section: Agreement Documents Scan] View Document (Link in
	// the grid)
	@Test(description = "Check View Document Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckAgrmntDocScanSec")
	public void test12CheckViewDocLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Agreement Documents Scan] View Document (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(AgrmntDocumentsScanSection.VIEWLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Agreement Documents Scan] View Document (Link in the grid) privilege");
	}

	// [Details Tab][Section: Agreement Documents Scan] Delete Document (Link in
	// the grid)
	@Test(description = "Check Delete Document Link", groups = "checkPrivilegesGrp", dependsOnMethods = "test06CheckAgrmntDocScanSec")
	public void test13CheckDeleteDocLink() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Agreement Documents Scan] Delete Document (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(AgrmntDocumentsScanSection.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Agreement Documents Scan] Delete Document (Link in the grid) privilege");
	}

	// [Details Tab][Section: Associated Policies] View
	@Test(description = "Check Associated Policies Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test07CheckAssociatedPoliciesSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[Details Tab][Section: Associated Policies] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(AssociatedPoliciesSection.ASSOCIATEDPOLSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Associated Policies] View privilege");
	}

	// [Details Tab][Section: Financial Parameters] View
	@Test(description = "Check Financial Parameters Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test08CheckFinancialParamSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[Details Tab][Section: Financial Parameters] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(FinancialParametersSection.FINANCIALPARAMETERSSEC_LINKTEXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Financial Parameters] View privilege");
	}

	// [Details Tab][Section: Financial Parameters] Credit Limit (Check box
	// group)
	@Test(description = "Check Credit Limit Check Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckFinancialParamSec")
	public void test14CheckCreditLimitChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Financial Parameters] Credit Limit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(FinancialParametersSection.CREDITLIMITCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Financial Parameters] Credit Limit (Check box group) privilege");
	}

	// [Details Tab][Section: Financial Parameters] Deposit (Check box group)
	@Test(description = "Check Deposit Check Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckFinancialParamSec")
	public void test15CheckDepositChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Financial Parameters] Deposit (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(FinancialParametersSection.DEPOSITCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Financial Parameters] Deposit (Check box group) privilege");
	}

	// [Details Tab][Section: Financial Parameters] Payment and Calculations
	// (Check box group)
	@Test(description = "Check Payment and Calculations Check Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckFinancialParamSec")
	public void test16CheckPaymentCalcChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Financial Parameters] Payment and Calculations (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(FinancialParametersSection.PAYMENTCALCULATIONS_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Financial Parameters] Payment and Calculations (Check box group) privilege");
	}

	// [Details Tab][Section: Financial Parameters] Claim Documentation
	// Requirement (Check box group)
	@Test(description = "Check Claim Doc Requirement Check Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test08CheckFinancialParamSec")
	public void test17CheckClaimDocReqChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Financial Parameters] Claim Documentation Requirement (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(FinancialParametersSection.CLAIMDOCREQ_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Financial Parameters] Claim Documentation Requirement (Check box group) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] View
	@Test(description = "Check Exclusion List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test09CheckExcListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[Details Tab][Section: Exclusion List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ExclusionListDetailsSection.EXCLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] View privilege");
		if (actualPrivilage)
			debtorAgreementPage.collapseExpandExcSection();
	}

	// [Details Tab][Section: Exclusion List Details] Add Record (Button)
	@Test(description = "Check Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test18CheckExcAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Exclusion List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Edit Record (Inline
	// editing in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test19CheckExcInlineEditRecord() throws Exception {
		serviceExclusionList = excelReader.read(properties
				.getProperty("serviceExcListDetails"));
		debtorAgreementPage.getExclusionListDetailsSection()
				.clickExcListRecord(serviceExclusionList.get(2));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.name(ExclusionListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link In Exc Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test20CheckDelLinkInExcGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ExclusionListDetailsSection.SERVEXCDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Exclusion List Details] Apply the Above Exclusion
	// List To (Check box group)
	@Test(description = "Check Apply the Above Exclusion List to Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test09CheckExcListDetailsSec")
	public void test21CheckApplyExcListToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Exclusion List Details] Apply the Above Exclusion List To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ExclusionListDetailsSection.APPLYEXCLISTTOPOLICYCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Exclusion List Details] Apply the Above Exclusion List To (Check box group) privilege");
	}

	// [Details Tab][Section: Approval List Details] View
	@Test(description = "Check Approval List Details Section", groups = "checkPrivilegesGrp", dependsOnMethods = "test05CheckLink3Edit")
	public void test10CheckApprvlListDetailsSec() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts").get("Debtor Agreement")
				.get("[Details Tab][Section: Approval List Details] View");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(
						webDriver,
						By.linkText(ApprovalListDetailsSection.APPRVLLISTDETAILSSEC_LINKTXT));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(expectedPrivilage, actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] View privilege");
		if (actualPrivilage)
			debtorAgreementPage.collapseExpandApprvlSection();
	}

	// [Details Tab][Section: Approval List Details] Add Record (Button)
	@Test(description = "Check Approval List Details Add Record Button", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test22CheckAppAddRecordBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Approval List Details] Add Record (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVADDROWBTN_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Add Record (Button) privilege");
	}

	// [Details Tab][Section: Approval List Details] Edit Record (Inline editing
	// in the grid)
	@Test(description = "Check Inline Edit Record", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test23CheckInlineEditRecord() throws Exception {
		serviceApprvlList = excelReader.read(properties
				.getProperty("serviceApprvListDetails"));
		debtorAgreementPage.getApprovalListDetailsSection()
				.clickApprvlListRecord(serviceApprvlList.get(2));
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor
				.testPrivilege(webDriver,
						By.name(ApprovalListDetailsSection.SERVLVLLIST_NAME));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Edit Record (Inline editing in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Delete Record (Link in the
	// grid)
	@Test(description = "Check Delete Link in Approval List Details Grid", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test24CheckDelLinkInApprvlGrid() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Approval List Details] Delete Record (Link in the grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(ApprovalListDetailsSection.SERVAPPRVLDELLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Delete Record (Link in the grid) privilege");
	}

	// [Details Tab][Section: Approval List Details] Apply the Above Approval
	// List To (Check box group)
	@Test(description = "Check Apply the Above Approval List to Chk Box", groups = "checkPrivilegesGrp", dependsOnMethods = "test10CheckApprvlListDetailsSec")
	public void test25CheckApplyApprvlToChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("Contracts")
				.get("Debtor Agreement")
				.get("[Details Tab][Section: Approval List Details] Apply the Above Approval List To (Check box group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.id(ApprovalListDetailsSection.APPLYAPPRVLLISTTOPOLCHKBOX_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				expectedPrivilage,
				actualPrivilage,
				"Fail to check [Details Tab][Section: Approval List Details] Apply the Above Approval List To (Check box group) privilege");
	}

	// [Details Tab][Section: Applicable Main Business Units] View

	// [Details Tab][Section: Audit Trail] View

}