package com.atk.himma.pageobjects.mbuadmin.sections.servicedetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ServiceLocation extends DriverWaitClass{
	
	public final static String SECTIONNAME_LINKTEXT = "Service  Location	";
	public final static String LOCCAT_ID = "LOCATION_CATEGORY";
	public final static String LOCATIONS_NAME = "multiselect_LOCATIONS";
	public final static String APPLYBUTTON_ID = "LOCATIONS_APPLY_BTN";
	public final static String ASSIGNLOCATIONS_ID = "root";
	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(id = LOCCAT_ID)
	private WebElement locCategory;
	
	@FindBy(name = LOCATIONS_NAME)
	private WebElement startDate;
	
	@FindBy(id = APPLYBUTTON_ID)
	private WebElement applyButton;

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the locCategory
	 */
	public WebElement getLocCategory() {
		return locCategory;
	}

	/**
	 * @return the startDate
	 */
	public WebElement getStartDate() {
		return startDate;
	}

	/**
	 * @return the applyButton
	 */
	public WebElement getApplyButton() {
		return applyButton;
	}
	
}
