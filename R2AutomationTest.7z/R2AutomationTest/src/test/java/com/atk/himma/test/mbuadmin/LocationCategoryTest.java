package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.master.LocationCategoryPage;
import com.atk.himma.pageobjects.mbuadmin.master.tabs.LocationCategoryMBUListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class LocationCategoryTest extends SeleniumDriverSetup {

	List<String[]> locationCategoryDatas;
	LocationCategoryPage locationCategoryPage;

	@Test(description = "open Visit Category Page")
	public void openVisitCategoryPage() {
		locationCategoryPage = PageFactory.initElements(webDriver,
				LocationCategoryPage.class);
		locationCategoryPage = locationCategoryPage
				.clickOnLocationCategoryMenu(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(locationCategoryPage);
		locationCategoryPage.setInstanceOfAllSection(webDriver, webDriverWait);
		locationCategoryPage.waitForElementVisibilityOf(locationCategoryPage
				.getLocationCategoryMBUListTab().getForm());
		locationCategoryPage
				.waitForElementXpathExpression(LocationCategoryMBUListTab.MBULISTTAB_XPATH);
		Assert.assertEquals(
				locationCategoryPage.getLocationCategoryMBUListTab()
						.getMbuListTab().getAttribute("title").trim(),
				"Main Business Unit List");
	}

	// [Location Category] Open Form
	@Test(description = "Open Location Category Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkLocCatMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		locationCategoryPage = PageFactory.initElements(webDriver,
				LocationCategoryPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		parentMenuList.add("Masters ");
		menuSelector.mouseOverOnTargetMenu(parentMenuList, "Location Category");
		locationCategoryPage.setWebDriver(webDriver);
		locationCategoryPage.setWebDriverWait(webDriverWait);
		locationCategoryPage
				.waitForElementXpathExpression(LocationCategoryPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Location Category")
				.get("[Location Category] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(LocationCategoryPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Location Category] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			locationCategoryPage = locationCategoryPage
					.clickOnLocationCategoryMenu(webDriver, webDriverWait);
			locationCategoryPage.setInstanceOfAllSection(webDriver,
					webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(locationCategoryPage);
			locationCategoryPage.setInstanceOfAllSection(webDriver,
					webDriverWait);
			locationCategoryPage
					.waitForElementVisibilityOf(locationCategoryPage
							.getLocationCategoryMBUListTab().getForm());
			locationCategoryPage
					.waitForElementXpathExpression(LocationCategoryMBUListTab.MBULISTTAB_XPATH);
			Assert.assertEquals(locationCategoryPage
					.getLocationCategoryMBUListTab().getMbuListTab()
					.getAttribute("title").trim(), "Main Business Unit List");
		}
	}
	
	@Test(description = "search MBU from Location Category", dependsOnMethods = { "openVisitCategoryPage" })
	public void test1SearchMBULocCategory() throws IOException, InterruptedException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		locationCategoryDatas = excelReader.read(properties.getProperty("locationCategory"));
		for (String st[] : locationCategoryDatas)
			Assert.assertEquals(locationCategoryPage.searchLocationCategory(st)
					.trim(), st[0].trim(), st[0].trim() + " search failed.");
	}

	@Test(description = "Click on Edit Link", dependsOnMethods = { "test1SearchMBULocCategory" })
	public void test2ClickOnEditLink() throws IOException {
		for (String st[] : locationCategoryDatas)
			Assert.assertEquals(
					locationCategoryPage.clickOnEditLink(st).trim(),
					st[0].trim(), " 'Edit link' click failed.");
	}

	@Test(description = "Save Location Category", dependsOnMethods = { "test2ClickOnEditLink" })
	public void test3SaveLocCategory() throws IOException, InterruptedException {
		for (String st[] : locationCategoryDatas)
			Assert.assertEquals(locationCategoryPage.saveLocationCategory(st)
					.trim().contains("updated successfully."), true, " Save failed.");
	}

	@Test(description = "Cancel Location Category", dependsOnMethods = { "test2ClickOnEditLink" })
	public void test4cancelLocCategory() throws IOException,
			InterruptedException {
		for (String st[] : locationCategoryDatas)
			Assert.assertEquals(locationCategoryPage.cancelLocationCategory(st)
					.trim(), st[0].trim(), st[0].trim() + " Cancel failed.");
	}

}
