package com.atk.himma.test.pharmacy;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.pharmacy.master.DrugComponentPage;
import com.atk.himma.pageobjects.pharmacy.tabs.DrugComponentListTab;
import com.atk.himma.setup.SeleniumDriverSetup;

public class DrugComponentTest extends SeleniumDriverSetup {
	
	DrugComponentPage drugComponentPage;
	List<String[]> drugComponentDatas;

	@Test
	public void test001checkDrugComponentLink() {

		drugComponentPage = PageFactory.initElements(webDriver,
				DrugComponentPage.class);
		drugComponentPage.setInstanceOfAllSection(webDriver, webDriverWait);
		drugComponentPage = drugComponentPage.checkDrugComponentLink(
				webDriver, webDriverWait);
		drugComponentPage
				.waitForElementXpathExpression(DrugComponentPage.DRUGCOMPONENTLINK_LINKTEXT);
		Assert.assertEquals(drugComponentPage.getDrugComponentLink().getText(),
				"Drug / Component",
				"Fail to Appear 'Drug / Component' Link");

	}

	@Test(dependsOnMethods = { "test001checkDrugComponentLink" })
	public void test002clickOnSolnDiluentMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("mrdExcel"));
		drugComponentDatas = excelReader.read(properties
				.getProperty("mrdSpecRequest"));
		drugComponentPage.clickOnDrugComponentMenu();
		doDirtyFormCheck();
		drugComponentPage.waitForElementId(DrugComponentListTab.GRID_ID);
		drugComponentPage
				.waitForElementId(DrugComponentListTab.ADDNEWGENDRUGBUTTON_ID);
		Assert.assertEquals(drugComponentPage.getDrugComponentListTab()
				.getSearchButton().getAttribute("value"), "Search",
				"Fail: to open MRD Desktop page");
	}

	@Test(dependsOnMethods = { "test002clickOnSolnDiluentMenuLink" })
	public void test003AddNewDrugCompBtn() throws Exception {
		Assert.assertTrue(drugComponentPage.clickOnAddNewDrugCompBtn(),
				"Fail to click 'Add New Drug / Component'");
	}

	@Test(dependsOnMethods = { "test003AddNewDrugCompBtn" })
	public void test004isReadonlyDrugCompCode() throws Exception {
		Assert.assertTrue(drugComponentPage.isReadonlyDrugCompCode(),
				"Fail to click 'test004isReadonlyDrugCompCode'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test005isMandatoryDrugCompDescr() throws Exception {
		Assert.assertTrue(drugComponentPage.isMandatoryDrugCompDescr(),
				"Fail to click 'test005isMandatoryDrugCompDescr'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test006isMandatoryDefaultUOM() throws Exception {
		Assert.assertTrue(drugComponentPage.isMandatoryDefaultUOM(),
				"Fail to click 'test006isMandatoryDefaultUOM'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test007isMandatoryRoute() throws Exception {
		Assert.assertTrue(drugComponentPage.isMandatoryRoute(),
				"Fail to click 'test007isMandatoryRoute'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test008isReadonlyItemCategory() throws Exception {
		Assert.assertTrue(drugComponentPage.isReadonlyItemCategory(),
				"Fail to click 'test007isReadonlyItemCategory'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test009fillSolutionDilutionDatas() throws Exception {
		for (String[] st : drugComponentDatas) {
			Assert.assertTrue(
					drugComponentPage.fillDrugComponentDatas(st),
					"Fail to click 'test009fillSolutionDilutionDatas'");
		}
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn",
			"test009fillSolutionDilutionDatas" })
	public void test010saveData() throws Exception {
		Assert.assertTrue(drugComponentPage.saveData(),
				"Fail to click 'test010saveData'");
	}

	@Test(dependsOnMethods = { "test010saveData" })
	public void test011updateData() throws Exception {
		for (String[] st : drugComponentDatas) {
			Assert.assertTrue(drugComponentPage.updateData(st),
					"Fail to click 'test011updateData'");
		}
	}

}
