package com.atk.himma.pageobjects.apoe.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class NonPharmacologicalTreatmentSection extends DriverWaitClass {
	public final static String NONPHARMTREATSEC_XPATH = "//a[text()='Non-Pharmacological Treatment']";
	@FindBy(xpath = NONPHARMTREATSEC_XPATH)
	private WebElement nonPharmTreatmentSec;

	public final static String NONPHARMNOTES_NAME = "consultationSummary.plan.nonPharmaligalNotes";
	@FindBy(name = NONPHARMNOTES_NAME)
	private WebElement nonPharmNotes;

	public void addNonPharmTreatSecData(String[] outPatientListData) {
		nonPharmNotes.clear();
		nonPharmNotes.sendKeys(outPatientListData[77]);

	}

	public WebElement getNonPharmTreatmentSec() {
		return nonPharmTreatmentSec;
	}

	public WebElement getNonPharmNotes() {
		return nonPharmNotes;
	}

	public boolean checkNonPharmTreatSec() {
		return nonPharmTreatmentSec.isDisplayed();
	}

}
