package com.atk.himma.test.pharmacy;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.pharmacy.master.SolutionDilutionPage;
import com.atk.himma.pageobjects.pharmacy.tabs.SolnDiluentListTab;
import com.atk.himma.setup.SeleniumDriverSetup;

public class SolutionDilutionTest extends SeleniumDriverSetup {

	SolutionDilutionPage solutionDilutionPage;
	List<String[]> solutionDilutionDatas;

	@Test
	public void test001checkSolDilLink() {

		solutionDilutionPage = PageFactory.initElements(webDriver,
				SolutionDilutionPage.class);
		solutionDilutionPage.setInstanceOfAllSection(webDriver, webDriverWait);
		solutionDilutionPage = solutionDilutionPage.checkSolnDiluentLink(
				webDriver, webDriverWait);
		solutionDilutionPage
				.waitForElementXpathExpression(SolutionDilutionPage.SOLDILMENULINK_XPATH);
		Assert.assertEquals(solutionDilutionPage.getSolDilMenuLink().getText(),
				"Solution / Diluent",
				"Fail to Appear 'Solution / Diluent' Link");

	}

	@Test(dependsOnMethods = { "checkSpecialRequestLink" })
	public void test002clickSpecReqMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("mrdExcel"));
		solutionDilutionDatas = excelReader.read(properties
				.getProperty("mrdSpecRequest"));
		solutionDilutionPage.clickOnSolnDiluentMenu();
		doDirtyFormCheck();
		solutionDilutionPage.waitForElementId(SolnDiluentListTab.GRID_ID);
		solutionDilutionPage
				.waitForElementCssSelector(SolnDiluentListTab.ADDNEWLEBELBUTTON_CSS);
		Assert.assertEquals(solutionDilutionPage.getSolnDiluentListTab()
				.getSearchButton().getAttribute("value"), "Search",
				"Fail: to open MRD Desktop page");
	}

	@Test(dependsOnMethods = { "test002clickSpecReqMenuLink" })
	public void test003clickOnAddNewSolnBtn() throws Exception {
		Assert.assertTrue(solutionDilutionPage.clickOnAddNewSolnBtn(),
				"Fail to click 'Add New Soln Btn'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test004isReadonlySolnDiluentCode() throws Exception {
		Assert.assertTrue(solutionDilutionPage.isReadonlySolnDiluentCode(),
				"Fail to click 'test004isReadonlySolnDiluentCode'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test005isMandatoryShortDescr() throws Exception {
		Assert.assertTrue(solutionDilutionPage.isMandatoryShortDescr(),
				"Fail to click 'test005isMandatoryShortDescr'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test006isMandatoryDefaultUOM() throws Exception {
		Assert.assertTrue(solutionDilutionPage.isMandatoryDefaultUOM(),
				"Fail to click 'test006isMandatoryDefaultUOM'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test007isMandatoryRoute() throws Exception {
		Assert.assertTrue(solutionDilutionPage.isMandatoryRoute(),
				"Fail to click 'test006isMandatoryDefaultUOM'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test008isReadonlyItemCategory() throws Exception {
		Assert.assertTrue(solutionDilutionPage.isReadonlyItemCategory(),
				"Fail to click 'test007isReadonlyItemCategory'");
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn" })
	public void test009fillSolutionDilutionDatas() throws Exception {
		for (String[] st : solutionDilutionDatas) {
			Assert.assertTrue(
					solutionDilutionPage.fillSolutionDilutionDatas(st),
					"Fail to click 'test008fillSolutionDilutionDatas'");
		}
	}

	@Test(dependsOnMethods = { "test003clickOnAddNewSolnBtn",
			"test009fillSolutionDilutionDatas" })
	public void test010saveData() throws Exception {
		Assert.assertTrue(solutionDilutionPage.saveData(),
				"Fail to click 'test010saveData'");
	}

	@Test(dependsOnMethods = { "test010saveData" })
	public void test011updateData() throws Exception {
		for (String[] st : solutionDilutionDatas) {
			Assert.assertTrue(solutionDilutionPage.updateData(st),
					"Fail to click 'test011updateData'");
		}
	}
}
