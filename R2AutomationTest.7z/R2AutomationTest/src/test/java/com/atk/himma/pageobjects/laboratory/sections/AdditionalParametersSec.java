package com.atk.himma.pageobjects.laboratory.sections;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class AdditionalParametersSec extends DriverWaitClass {
	public final static String ADDITIONALPARAMSEC_XPATH = "//a[text()='Additional Parameters ']";
	@FindBy(xpath = ADDITIONALPARAMSEC_XPATH)
	private WebElement additionalParamSec;

	public final static String ALLORGANISM_ID = "ALL_ORGANISMS";
	@FindBy(id = ALLORGANISM_ID)
	private WebElement allOrganism;

	public final static String BYORGANISMTYPE_ID = "BY_ORGANISM_TYPE";
	@FindBy(id = BYORGANISMTYPE_ID)
	private WebElement byOrganismType;

	public final static String ORGANISMTYPE_ID = "ADDPAR_ORGANISM_TYPE_ID";
	@FindBy(id = ORGANISMTYPE_ID)
	private WebElement organismType;

	public final static String ADDPARAMORGADDBTN_ID = "ADDPAR_ORG_MOVE";
	@FindBy(id = ADDPARAMORGADDBTN_ID)
	private WebElement addParamOrgAddBtn;

	public final static String ADDPARAMORGREMOVEBTN_ID = "ADDPAR_ORG_REMOVE";
	@FindBy(id = ADDPARAMORGREMOVEBTN_ID)
	private WebElement addParamOrgRemoveBtn;

	public final static String ADDPARAMANTIBIOADDBTN_ID = "ADDPAR_MOVE";
	@FindBy(id = ADDPARAMANTIBIOADDBTN_ID)
	private WebElement addParamAntiBioAddBtn;

	public final static String ADDPARAMANTIBIOREMOVEBTN_CSS = "#ADDPAR_MOVE ~ input";
	@FindBy(css = ADDPARAMANTIBIOREMOVEBTN_CSS)
	private WebElement addParamAntiBioRemoveBtn;

	public WebElement getAdditionalParamSec() {
		return additionalParamSec;
	}

	public WebElement getAllOrganism() {
		return allOrganism;
	}

	public WebElement getByOrganismType() {
		return byOrganismType;
	}

	public WebElement getOrganismType() {
		return organismType;
	}

	public WebElement getAddParamOrgAddBtn() {
		return addParamOrgAddBtn;
	}

	public WebElement getAddParamOrgRemoveBtn() {
		return addParamOrgRemoveBtn;
	}

	public WebElement getAddParamAntiBioAddBtn() {
		return addParamAntiBioAddBtn;
	}

	public WebElement getAddParamAntiBioRemoveBtn() {
		return addParamAntiBioRemoveBtn;
	}

}