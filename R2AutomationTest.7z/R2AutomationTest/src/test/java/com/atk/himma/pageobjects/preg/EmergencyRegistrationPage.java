package com.atk.himma.pageobjects.preg;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.preg.regsections.ContactDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.IdentificationDetailsSection;
import com.atk.himma.pageobjects.preg.regsections.PatientIdentifierSection;
import com.atk.himma.pageobjects.preg.regsections.PregFirstSection;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class EmergencyRegistrationPage extends DriverWaitClass implements RecordStatus, TopControls, StatusMessages{

	private PregFirstSection firstSection;

	private PatientIdentifierSection patientIdentifierSection;

	private IdentificationDetailsSection identificationDetailsSection;

	private ContactDetailsSection contactDetailsSection;

	private final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;
	
	public final static String regType_xpath = "//label[@id='EMER_REG_FRM_patiInfoDetails_registrationType' and @class='label_highlight capsletter']";
	
	public final static String SAVECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'save successfully Emer. Reg. datas')]";
	public final static String UPDATECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'Update successfully Emer. Reg. datas')]";
	public final static String DELETECONFMSG_XPATH = MSGENABLE_XPATH + "[contains(text(),'deleted successfully')]";
	
	@FindBy(xpath = SAVECONFMSG_XPATH)
	private WebElement saveConfMsg;
	
	@FindBy(xpath = UPDATECONFMSG_XPATH)
	private WebElement updateConfMsg;
	
	@FindBy(xpath = DELETECONFMSG_XPATH)
	private WebElement deleteConfMsg;
	
	@FindBy(xpath=regType_xpath)
	private WebElement regType;
	
	public final static String FORMNAME_ID = "EMER_REG_FRM";

	@FindBy(id = FORMNAME_ID)
	private WebElement formName;

	public final static String NEWREGISTRATIONBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']//input[@value='New Registration']";

	@FindBy(xpath = NEWREGISTRATIONBUTTON_XPATH)
	private WebElement newRegistrationButton;

	public final static String SAVEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']//input[@value='Save']";

	@FindBy(xpath = SAVEBUTTON_XPATH)
	private WebElement saveButton;

	public final static String UPDATEBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']/input[@value='Update']";

	@FindBy(xpath = UPDATEBUTTON_XPATH)
	private WebElement updateButton;

	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg']//input[@value='Cancel']";

	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement cancelButton;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;


	public void setInstanceOfAllSection(WebDriver webDriver, WebDriverWait webDriverWait) 
	{
		this.firstSection = PageFactory.initElements(webDriver, PregFirstSection.class);
		this.firstSection.setWebDriver(webDriver);
		this.firstSection.setWebDriverWait(webDriverWait);
		
		this.patientIdentifierSection = PageFactory.initElements(webDriver, PatientIdentifierSection.class);
		this.patientIdentifierSection.setWebDriver(webDriver);
		this.patientIdentifierSection.setWebDriverWait(webDriverWait);
		
		this.identificationDetailsSection = PageFactory.initElements(webDriver, IdentificationDetailsSection.class);
		this.identificationDetailsSection.setWebDriver(webDriver);
		this.identificationDetailsSection.setWebDriverWait(webDriverWait);
		
		this.contactDetailsSection = PageFactory.initElements(webDriver, ContactDetailsSection.class);
		this.contactDetailsSection.setWebDriver(webDriver);
		this.contactDetailsSection.setWebDriverWait(webDriverWait);
		
	}
	
	public EmergencyRegistrationPage clickOnEmerRegMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("Patient Registration");
		menuSelector.clickOnTargetMenu(baseLVParentMenuList,
				"Emergency Registration");
		EmergencyRegistrationPage emerRegObj = PageFactory.initElements(webDriver, EmergencyRegistrationPage.class);
		emerRegObj.setWebDriver(webDriver);
		emerRegObj.setWebDriverWait(webDriverWait);
		return emerRegObj;
	}
	
	public EmergencyRegistrationPage saveEmerRegPage(String[] st, WebDriver webDriver, WebDriverWait webDriverWait) throws InterruptedException
	{
		fillEmerRegData(st, webDriverWait);
		getSaveButton().click();
		return createPageFactoryObject(webDriver, webDriverWait);
	}
	
	public EmergencyRegistrationPage updateEmerRegPage(String[] st, WebDriver webDriver, WebDriverWait webDriverWait) throws InterruptedException
	{
		fillEmerRegData(st, webDriverWait);
		getUpdateButton().click();
		waitForElementXpathExpression(ACTIVATE_XPATH);
		return createPageFactoryObject(webDriver, webDriverWait);
	}
	
	public EmergencyRegistrationPage createPageFactoryObject(WebDriver webDriver, WebDriverWait webDriverWait)
	{
		EmergencyRegistrationPage emerRegObj = PageFactory.initElements(webDriver, EmergencyRegistrationPage.class);
		emerRegObj.setWebDriver(webDriver);
		emerRegObj.setWebDriverWait(webDriverWait);
		return emerRegObj;
	}
	
	public void fillEmerRegData(String[] st, WebDriverWait webDriverWait) throws InterruptedException
	{
		getFirstSection().fillDatasOfPregFirstSection(st, webDriverWait);
		getPatientIdentifierSection().fillDatasOfPatientIdentifier(st, webDriverWait);
		getIdentificationDetailsSection().fillDatasIdentificationDetails(st, webDriverWait);
		getContactDetailsSection().fillDatasContactDetails(st, webDriverWait);
	}
	
	
	/**
	 * @return the firstSection
	 */
	public PregFirstSection getFirstSection() {
		return firstSection;
	}

	/**
	 * @return the patientIdentifierSection
	 */
	public PatientIdentifierSection getPatientIdentifierSection() {
		return patientIdentifierSection;
	}

	/**
	 * @return the identificationDetailsSection
	 */
	public IdentificationDetailsSection getIdentificationDetailsSection() {
		return identificationDetailsSection;
	}

	/**
	 * @return the contactDetailsSection
	 */
	public ContactDetailsSection getContactDetailsSection() {
		return contactDetailsSection;
	}

	/**
	 * @return the pagetitleId
	 */
	public static String getPagetitleId() {
		return PAGETITLE_ID;
	}

	/**
	 * @return the pageTitle
	 */
	public WebElement getPageTitle() {
		return pageTitle;
	}

	/**
	 * @return the formnameId
	 */
	public static String getFormnameId() {
		return FORMNAME_ID;
	}

	/**
	 * @return the formName
	 */
	public WebElement getFormName() {
		return formName;
	}

	/**
	 * @return the newregistrationbuttonXpath
	 */
	public static String getNewregistrationbuttonXpath() {
		return NEWREGISTRATIONBUTTON_XPATH;
	}

	/**
	 * @return the newRegistrationButton
	 */
	public WebElement getNewRegistrationButton() {
		return newRegistrationButton;
	}

	/**
	 * @return the saveButton
	 */
	public WebElement getSaveButton() {
		return saveButton;
	}

	/**
	 * @return the updatebuttonXpath
	 */
	public static String getUpdatebuttonXpath() {
		return UPDATEBUTTON_XPATH;
	}

	/**
	 * @return the updateButton
	 */
	public WebElement getUpdateButton() {
		return updateButton;
	}

	/**
	 * @return the cancelbuttonXpath
	 */
	public static String getCancelbuttonXpath() {
		return CANCELBUTTON_XPATH;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the savebuttonXpath
	 */
	public static String getSavebuttonXpath() {
		return SAVEBUTTON_XPATH;
	}

	/**
	 * @return the regType
	 */
	public WebElement getRegType() {
		return regType;
	}

	/**
	 * @return the regtypeXpath
	 */
	public static String getRegtypeXpath() {
		return regType_xpath;
	}

	/**
	 * @return the statusMessage
	 */
	public WebElement getStatusMessage() {
		return statusMessage;
	}

	/**
	 * @return the saveConfMsg
	 */
	public WebElement getSaveConfMsg() {
		return saveConfMsg;
	}

	/**
	 * @return the updateConfMsg
	 */
	public WebElement getUpdateConfMsg() {
		return updateConfMsg;
	}

	/**
	 * @return the deleteConfMsg
	 */
	public WebElement getDeleteConfMsg() {
		return deleteConfMsg;
	}
}
