package com.atk.himma.pageobjects.sa.masters;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.sa.masters.tabs.BaseLoVDetailsTab;
import com.atk.himma.pageobjects.sa.masters.tabs.BaseLoVListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.StatusMessages;

public class BaseLVPage extends DriverWaitClass implements StatusMessages {
	private BaseLoVListTab baseLoVListTab;
	private BaseLoVDetailsTab baseLoVDetailsTab;

	public final static String MENULINK_XPATH = "//a[contains(text(),'System Administration')]/..//a[contains(text(),'Masters ')]/..//a[contains(text(),'Base LV')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		baseLoVListTab = PageFactory.initElements(webDriver,
				BaseLoVListTab.class);
		baseLoVListTab.setWebDriver(webDriver);
		baseLoVListTab.setWebDriverWait(webDriverWait);

		baseLoVDetailsTab = PageFactory.initElements(webDriver,
				BaseLoVDetailsTab.class);
		baseLoVDetailsTab.setWebDriver(webDriver);
		baseLoVDetailsTab.setWebDriverWait(webDriverWait);

	}

	public BaseLVPage clickOnBaseLVMenu(WebDriver webDriver,
			WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> baseLVParentMenuList = new LinkedList<String>();
		baseLVParentMenuList.add("System Administration");
		baseLVParentMenuList.add("Masters ");
		menuSelector.clickOnTargetMenu(baseLVParentMenuList, "Base LV");
		BaseLVPage baseLVPage = PageFactory.initElements(webDriver,
				BaseLVPage.class);
		baseLVPage.setWebDriver(webDriver);
		baseLVPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return baseLVPage;

	}

	public BaseLoVListTab getBaseLoVListTab() {
		return baseLoVListTab;
	}

	public BaseLoVDetailsTab getBaseLoVDetailsTab() {
		return baseLoVDetailsTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

}
