package com.atk.himma.pageobjects.appointsched;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.appointsched.sections.appointSections.PhysicianAvailability;
import com.atk.himma.pageobjects.appointsched.tabs.BookTab;
import com.atk.himma.pageobjects.appointsched.tabs.FreezeTab;
import com.atk.himma.pageobjects.appointsched.tabs.ReserveTab;
import com.atk.himma.pageobjects.appointsched.tabs.UnFreezeTab;
import com.atk.himma.util.DateTimeConverter;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.interfaces.StatusMessages;
import com.atk.himma.util.interfaces.TopControls;

public class AppointmentDairy extends DriverWaitClass implements
		StatusMessages, TopControls {

	public final static String DAIRY_ID = "DIARY_CONTENT";
	public final static String PHYSLABELNAME_XPATH = "//span[@class='buttoncontainer_vlrg_lft']/label[1]";
	public final static String VIEWWAITLISTBUTTON_ID = "VIEW_WAITLIST";
	public final static String ADDTOWAITLISTBUTTON_ID = "ADD_TO_WAITLIST";
	public final static String MSGDIALOGYES_XPATH = "//div[@id='ConfirmationMessage']//input[@id='MSG_DIALOG_YES']";
	public final static String BACKTOAPPOINTBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_lft']/input[@value='Back to Appointments']";
	public final static String FROZENCONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(), 'Frozen the Slots Successfully..')]";
	public final static String UNFROZENCONFMSG_XPATH = MSGENABLE_XPATH
			+ "[contains(text(), 'UnFreezed the Slots Successfully..')]";

	public final static String APPSLIPPAGE_ID = "pageContainer1";
	public final static String APPDAIRYVIEWDAIRY_XPATH = "//table[@id='recourceAvailableGrid']//a[contains(text(),'Morning')]";

	@FindBy(xpath = UNFROZENCONFMSG_XPATH)
	private WebElement unFrozenMsg;

	@FindBy(xpath = FROZENCONFMSG_XPATH)
	private WebElement frozenMsg;

	@FindBy(id = APPSLIPPAGE_ID)
	private WebElement appointSlipId;

	@FindBy(id = DAIRY_ID)
	private WebElement dairy;

	@FindBy(xpath = PHYSLABELNAME_XPATH)
	private WebElement physLabelName;

	@FindBy(id = VIEWWAITLISTBUTTON_ID)
	private WebElement viewWaitListButton;

	@FindBy(id = ADDTOWAITLISTBUTTON_ID)
	private WebElement addPatToWaitListButton;

	@FindBy(xpath = BACKTOAPPOINTBUTTON_XPATH)
	private WebElement backToAppointButton;

	@FindBy(xpath = MSGDIALOGYES_XPATH)
	private WebElement yesMsgButton;

	// ----------------------------------Reschedule Form----------------------

	public final static String RESCHEDULE_FORM_ID = "RESCHEDULE_FORM";
	public final static String PATREASON_ID = "PT_REASON_ID";
	public final static String RESCHEDULECOMMENTS_NAME = "appointmentInfo.rescheduleComments";
	public final static String RESCHESUBMITBUTTON_ID = "RESCHEDULE_SUBMIT";
	public final static String RESCHECANCELBUTTON_ID = "RESCHEDULE_CANCEL";

	@FindBy(id = RESCHEDULE_FORM_ID)
	private WebElement rescheduleForm;

	@FindBy(id = PATREASON_ID)
	private WebElement patReason;

	@FindBy(name = RESCHEDULECOMMENTS_NAME)
	private WebElement rescheduleComment;

	@FindBy(id = RESCHESUBMITBUTTON_ID)
	private WebElement rescheSubmitButton;

	@FindBy(id = RESCHECANCELBUTTON_ID)
	private WebElement rescheCancelButton;

	public PhysicianAvailability clickBackOnAppointButton()
			throws InterruptedException {
		waitForElementXpathExpression(BACKTOAPPOINTBUTTON_XPATH);
		backToAppointButton.click();
		PhysicianAvailability physicianAvailability = PageFactory.initElements(
				webDriver, PhysicianAvailability.class);
		physicianAvailability.setWebDriver(webDriver);
		physicianAvailability.setWebDriverWait(webDriverWait);
		waitForElementId(PhysicianAvailability.PHYSICIAN_ID);
		sleepVeryShort();
		return physicianAvailability;
	}

	public BookTab clickOnAppSlotForBook(String date, String timeSlotTime)
			throws InterruptedException {
		clickOnAppointSlot(date, timeSlotTime);
		waitForElementId(BookTab.FORMNAME_ID);
		sleepVeryShort();
		BookTab bookTab = PageFactory.initElements(webDriver, BookTab.class);
		bookTab.setWebDriver(webDriver);
		bookTab.setWebDriverWait(webDriverWait);
		return bookTab;
	}

	public FreezeTab clickOnAppSlotForFreeze(String date, String timeSlotTime)
			throws InterruptedException {
		clickOnAppointSlot(date, timeSlotTime);
		waitForElementId(BookTab.FORMNAME_ID);
		sleepVeryShort();
		FreezeTab freezeTab = PageFactory.initElements(webDriver,
				FreezeTab.class);
		freezeTab.setWebDriver(webDriver);
		freezeTab.setWebDriverWait(webDriverWait);
		waitForElementXpathExpression(FreezeTab.FREEZETAB_XPATH);
		sleepShort();
		freezeTab.getFreezeTab().click();
		waitForElementId(FreezeTab.FORMNAME_ID);
		sleepShort();
		return freezeTab;
	}

	public UnFreezeTab clickOnAppSlotForUnFreeze(String date,
			String timeSlotTime) throws InterruptedException {
		clickOnAppointSlot(date, timeSlotTime);
		waitForElementId(UnFreezeTab.FORMNAME_ID);
		sleepVeryShort();
		UnFreezeTab unFreezeTab = PageFactory.initElements(webDriver,
				UnFreezeTab.class);
		unFreezeTab.setWebDriver(webDriver);
		unFreezeTab.setWebDriverWait(webDriverWait);
		waitForElementXpathExpression(UnFreezeTab.UNFREEZETAB_XPATH);
		sleepShort();
		unFreezeTab.getUnFreezeTab().click();
		waitForElementId(UnFreezeTab.FORMNAME_ID);
		sleepShort();
		return unFreezeTab;
	}

	public ReserveTab clickOnAppSlotForReserve(String date, String timeSlotTime)
			throws InterruptedException {
		clickOnAppointSlot(date, timeSlotTime);
		waitForElementId(ReserveTab.FORMNAME_ID);
		sleepVeryShort();
		ReserveTab reserveTab = PageFactory.initElements(webDriver,
				ReserveTab.class);
		reserveTab.setWebDriver(webDriver);
		reserveTab.setWebDriverWait(webDriverWait);
		waitForElementXpathExpression(ReserveTab.RESERVETAB_XPATH);
		sleepShort();
		reserveTab.getReserveTab().click();
		waitForElementId(ReserveTab.FORMNAME_ID);
		sleepShort();
		return reserveTab;
	}

	private void clickOnAppointSlot(String date, String timeSlotTime)
			throws InterruptedException {
		String appointSlotXpath = "(//table[@class='fc-agenda-slots fc-subview']//tr/td[@class='fc-day-slot'])["
				+ Integer.toString(dateColumnNoCount(date))
				+ "]//td/div/div[contains(text(), '"
				+ timeSlotTime.trim()
				+ "')]";
		waitForElementXpathExpression(appointSlotXpath);
		sleepVeryShort();
		webDriver.findElement(By.xpath(appointSlotXpath)).click();
	}

	public boolean checkedBookedSlot(String slotTime, String mrnOrPatientName)
			throws InterruptedException {
		waitForElementXpathExpression("//div[@class='fc-event-head fc-event-skin' and @style='background-color:#BAFDF3']/div[contains(text(),'"
				+ slotTime.trim()
				+ "')]/../..//div[contains(text(),'"
				+ mrnOrPatientName.trim() + "')]");
		sleepVeryShort();
		return true;
	}

	public boolean checkFreezeSlot(String date, String timeSlotTime)
			throws InterruptedException {
		waitForElementXpathExpression(BACKTOAPPOINTBUTTON_XPATH);
		sleepVeryShort();
		String appointSlotXpath = "(//table[@class='fc-agenda-slots fc-subview']//tr/td[@class='fc-day-slot'])["
				+ Integer.toString(dateColumnNoCount(date))
				+ "]//td[@class='fc-slot-no-more-book']/div/div[contains(text(), '"
				+ timeSlotTime.trim() + "')]";
		waitForElementXpathExpression(appointSlotXpath);
		return true;
	}

	public boolean checkUnFreezeSlot(String date, String timeSlotTime)
			throws InterruptedException {
		try {
			waitForElementXpathExpression(BACKTOAPPOINTBUTTON_XPATH);
			sleepVeryShort();
			String appointSlotXpath = "(//table[@class='fc-agenda-slots fc-subview']//tr/td[@class='fc-day-slot'])["
					+ Integer.toString(dateColumnNoCount(date))
					+ "]//tr[@class='fc-slot-available fc-minor']/td/div/div[contains(text(), '"
					+ timeSlotTime.trim() + "')]";
			waitForElementXpathExpression(appointSlotXpath);
			sleepVeryShort();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean cancelBookedSlot(String slotTime, String mrnOrPatientName)
			throws InterruptedException {
		String bookedSlotXpath = "//div[@class='fc-event-head fc-event-skin' and @style='background-color:#BAFDF3']/div[contains(text(),'"
				+ slotTime.trim()
				+ "')]/../..//div[contains(text(),'"
				+ mrnOrPatientName.trim() + "')]";
		sleepMedium();
		waitForElementXpathExpression(bookedSlotXpath);
		webDriver.findElement(By.xpath(bookedSlotXpath)).click();
		sleepMedium();
		waitForElementId(BookTab.CANCELAPPOINT_ID);
		sleepVeryShort();
		BookTab bookTab = PageFactory.initElements(webDriver, BookTab.class);
		bookTab.setWebDriver(webDriver);
		bookTab.setWebDriverWait(webDriverWait);
		bookTab.getCancelAppointButton().click();
		waitForElementId(BookTab.FORMCANCELAPPOINT_ID);
		waitForElementId(BookTab.CANCELAPPOINTBUTTON_ID);
		sleepVeryShort();
		bookTab.getCancelAppPopUpButton().click();
		waitForElementXpathExpression(BACKTOAPPOINTBUTTON_XPATH);
		sleepVeryShort();
		try {
			new WebDriverWait(webDriver, 2).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath(bookedSlotXpath)));
			return false;
		} catch (Exception e) {
			return true;
		}
	}

	private int dateColumnNoCount(String date) throws InterruptedException {
		waitForElementXpathExpression("//table[@class='fc-agenda-days fc-border-separate']");
		sleepVeryShort();
		List<WebElement> titleDates = webDriver
				.findElements(By
						.xpath("(//table[@class='fc-agenda-days fc-border-separate']//tr)[1]//th"));
		int columnCount = 0;
		for (WebElement we : titleDates) {
			columnCount++;
			if (we.getText().contains(
					DateTimeConverter.getDateForAppointDairy(date).trim()))
				break;
		}
		if (columnCount > 5) {
			columnCount = 0;
			for (WebElement we : titleDates) {
				columnCount++;
				if (we.getText().contains(date.trim()))
					break;
			}
		}
		return columnCount;
	}

	public boolean noOfSlotsPerDay(String currentDate, int calculNoOfSlots)
			throws InterruptedException {
		String appointSlotXpath = "(//table[@class='fc-agenda-slots fc-subview']//tr/td[@class='fc-day-slot'])["
				+ Integer.toString(dateColumnNoCount(currentDate))
				+ "]//td/div/div[@style='position:relative;margin:0 0 0 11px;height:55px; padding:5px 0 0 5px;']";
		return webDriver.findElements(By.xpath(appointSlotXpath)).size() == calculNoOfSlots;
	}

	public void rescheduleAppointment(String dateFrom, String slotTimeFrom,
			String dateTo, String slotTimeTo, String searchPatient) throws InterruptedException {

		clickOnAppointSlot(dateFrom, slotTimeFrom);
		BookTab bookTab = PageFactory.initElements(webDriver, BookTab.class);
		bookTab.setWebDriver(webDriver);
		bookTab.setWebDriverWait(webDriverWait);
		bookTab.clickOnReschButton().clickOnAppSlotForBook(dateTo, slotTimeTo)
				.doQuickSearchPage(searchPatient);
		bookTab.sleepShort();
		bookTab.waitForElementId(BookTab.SAVE_ID);
		bookTab.getSaveBooking().click();
		waitForElementId(MSGDIALOG_NO_ID);
		bookTab.getMsgDialogNoButton().click();
	}

	/**
	 * @return the dairy
	 */
	public WebElement getDairy() {
		return dairy;
	}

	/**
	 * @return the physLabelName
	 */
	public WebElement getPhysLabelName() {
		return physLabelName;
	}

	/**
	 * @return the viewWaitListButton
	 */
	public WebElement getViewWaitListButton() {
		return viewWaitListButton;
	}

	/**
	 * @return the addPatToWaitListButton
	 */
	public WebElement getAddPatToWaitListButton() {
		return addPatToWaitListButton;
	}

	/**
	 * @return the backToAppointButton
	 */
	public WebElement getBackToAppointButton() {
		return backToAppointButton;
	}

	/**
	 * @return the yesMsgButton
	 */
	public WebElement getYesMsgButton() {
		return yesMsgButton;
	}

	/**
	 * @return the appointSlipId
	 */
	public WebElement getAppointSlipId() {
		return appointSlipId;
	}

	/**
	 * @return the frozenMsg
	 */
	public WebElement getFrozenMsg() {
		return frozenMsg;
	}

	/**
	 * @return the unFrozenMsg
	 */
	public WebElement getUnFrozenMsg() {
		return unFrozenMsg;
	}

	/**
	 * @return the rescheCancelButton
	 */
	public WebElement getRescheCancelButton() {
		return rescheCancelButton;
	}

	/**
	 * @return the rescheSubmitButton
	 */
	public WebElement getRescheSubmitButton() {
		return rescheSubmitButton;
	}

	/**
	 * @return the rescheduleComment
	 */
	public WebElement getRescheduleComment() {
		return rescheduleComment;
	}

	/**
	 * @return the patReason
	 */
	public WebElement getPatReason() {
		return patReason;
	}

	/**
	 * @return the rescheduleForm
	 */
	public WebElement getRescheduleForm() {
		return rescheduleForm;
	}

}
