package com.atk.himma.pageobjects.mbuadmin.sections.mbudetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.atk.himma.util.DriverWaitClass;

public class MoreAppParameters extends DriverWaitClass {

	public final static String SECTIONNAME_LINKTEXT = "More Appointment Parameters";
	public final static String ADDBUTTONGRID_XPATH = "//td[@id='MORE_APPT_PARAMETERS_GRID_pager_left']//div[@class='ui-pg-div']/span']";
	public final static String POPUPFORMID_ID = "MORE_APPT_PARAMETERS_FORM";
	public final static String POPUPTITLE_ID = "ui-dialog-title-moreApptParametersDialog";
	public final static String BILLINGTYPE_ID = "BILLING_TYPE";
	public final static String MOREAPPVISITCATEGORY_ID = "MORE_APP_VISIT_CATEGORY";
	public final static String MOREAPPVISITTYPE_ID = "MORE_APP_VISIT_TYPE";
	public final static String ENCCLOUSERDUR_ID = "ENC_CLOUSER_DUR";
	public final static String POSTBOXNUMBER_ID = "POST_BOX_NUMBER";
	public final static String MAXAPPTPERDAY_ID = "MAX_APPT_PER_DAY";
	public final static String SAMECLIBLODURATION_ID = "SAME_CLINIC_MULTIAPPT_BLOCK_DURATION";
	public final static String CLINOOFVISIT_ID = "SAME_CLINIC_NO_OF_VISIT";
	public final static String CLIDAYSPAN_ID = "SAME_CLINIC_DAY_SPAN";
	public final static String SAMESPECBLODURATION_ID = "SAME_SPECIALITY_MULTIAPPT_BLOCK_DURATION";
	public final static String SPECNOOFVISIT_ID = "SAME_SPL_NO_OF_VISIT";
	public final static String SPECDAYSPAN_ID = "SAME_SPL_DAY_SPAN";
	public final static String SUBMITBUTTON_ID = "//span[@class='buttoncontainer_mid']//input[@value='Submit']";
	public final static String CANCELBUTTON_ID = "//span[@class='buttoncontainer_mid']//input[@value='Cancel']";
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'More Appointment Parameters')]/..";
	public final static String GRIDID_ID = "MORE_APPT_PARAMETERS_GRID";
	public final static String GRID_BILLINGTYPE_ID = "MORE_APPT_PARAMETERS_GRID_billingTypeText";
	public final static String GRID_VISITCATEGORY_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_visitCategoryText";
	public final static String GRID_VISITTYPE_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_visitTypeText";
	public final static String GRID_ENCCLOUSERDURATION_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_encClouserDuration";
	public final static String GRID_NOOFVISITSCLINIC_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_sameClinicNOOfVisits";
	public final static String GRID_DAYSPAN_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_sameClinicDaySpan";
	public final static String GRID_NOOFVISITSSPEC_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_sameSplNOOfVisits";
	public final static String GRID_DAYSPANSPL_ARIA_DESCRIBEDBY = "MORE_APPT_PARAMETERS_GRID_sameSplDaySpan";
	public final static String GRID_PAGERID = "sp_1_MORE_APPT_PARAMETERS_GRID_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_MORE_APPT_PARAMETERS_GRID_pager']";

	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;

	@FindBy(xpath = ADDBUTTONGRID_XPATH)
	private WebElement addButtonGrid;

	@FindBy(id = POPUPFORMID_ID)
	private WebElement popupFormid;

	@FindBy(id = POPUPTITLE_ID)
	private WebElement popupTitle;

	@FindBy(id = BILLINGTYPE_ID)
	private WebElement billingType;

	@FindBy(id = MOREAPPVISITCATEGORY_ID)
	private WebElement moreappVisitCategory;

	@FindBy(id = MOREAPPVISITTYPE_ID)
	private WebElement moreappVisitType;

	@FindBy(id = ENCCLOUSERDUR_ID)
	private WebElement encClouserDur;

	@FindBy(id = POSTBOXNUMBER_ID)
	private WebElement postBoxNumber;

	@FindBy(id = MAXAPPTPERDAY_ID)
	private WebElement maxApptPerDay;

	@FindBy(id = SAMECLIBLODURATION_ID)
	private WebElement sameCliBloDuration;

	@FindBy(id = CLINOOFVISIT_ID)
	private WebElement cliNoOfVisit;

	@FindBy(id = CLIDAYSPAN_ID)
	private WebElement cliDaySpan;
	//
	@FindBy(id = SAMESPECBLODURATION_ID)
	private WebElement sameSpecBloDuration;

	@FindBy(id = SPECDAYSPAN_ID)
	private WebElement specDaySpan;

	@FindBy(id = SPECNOOFVISIT_ID)
	private WebElement specNoOfVisit;

	@FindBy(id = SUBMITBUTTON_ID)
	private WebElement submitButton;

	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;

	@FindBy(id = GRIDID_ID)
	private WebElement gridID;

	@FindBy(id = GRID_PAGERID)
	private WebElement gridPager;

	@FindBy(id = GRID_NEXTPAGE_XPATH)
	private WebElement gridNextPage;

	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;

	public boolean checkMoreAppointParams() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

	public String clickOnAddButton(String[] mbuDatas)
			throws InterruptedException {
		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			sectionName.click();
		waitForElementId(ADDBUTTONGRID_XPATH);
		sleepShort();
		addButtonGrid.click();
		waitForElementId(POPUPTITLE_ID);
		sleepVeryShort();
		return addButtonGrid.getText().trim();
	}

	public boolean isMandatoryBillingType() {
		waitForElementId(BILLINGTYPE_ID);
		return isMandatoryField(billingType);
	}

	public boolean isMandVisitType() {
		waitForElementId(MOREAPPVISITTYPE_ID);
		return isMandatoryField(moreappVisitType);
	}

	public boolean isMandVisitCategory() {
		waitForElementId(MOREAPPVISITCATEGORY_ID);
		return isMandatoryField(moreappVisitCategory);
	}

	public boolean fillDatasToPopUp(String[] mbuDatas)
			throws InterruptedException {
		new Select(billingType).selectByVisibleText(mbuDatas[0].trim());
		new Select(moreappVisitCategory)
				.selectByVisibleText(mbuDatas[0].trim());
		new Select(moreappVisitType).selectByVisibleText(mbuDatas[0].trim());
		encClouserDur.clear();
		encClouserDur.sendKeys(mbuDatas[0].trim());
		maxApptPerDay.clear();
		maxApptPerDay.sendKeys(mbuDatas[0].trim());
		selectOrUnSelectCheckBox(mbuDatas[0].trim(), sameCliBloDuration);
		if (sameCliBloDuration.isSelected()) {
			cliNoOfVisit.clear();
			cliNoOfVisit.sendKeys(mbuDatas[0].trim());
			cliDaySpan.clear();
			cliDaySpan.sendKeys(mbuDatas[0].trim());
		}

		selectOrUnSelectCheckBox(mbuDatas[0].trim(), sameSpecBloDuration);

		if (sameSpecBloDuration.isSelected()) {
			specNoOfVisit.clear();
			specNoOfVisit.sendKeys(mbuDatas[0].trim());
			specDaySpan.clear();
			specDaySpan.sendKeys(mbuDatas[0].trim());
		}
		return (specDaySpan.getAttribute("value").trim().equals(mbuDatas[0]
				.trim()));
	}

	public boolean submitFollowUpDatas() throws InterruptedException {
		waitForElementId(SUBMITBUTTON_ID);
		submitButton.click();
		waitForElementId(GRIDID_ID);
		sleepVeryShort();
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}

	public boolean cancelFollowUpDatas() throws InterruptedException {
		waitForElementId(CANCELBUTTON_ID);
		cancelButton.click();
		waitForElementId(GRIDID_ID);
		sleepVeryShort();
		return checkGridEmpty(GRIDID_ID, GRID_PAGERID);
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the addButtonGrid
	 */
	public WebElement getAddButtonGrid() {
		return addButtonGrid;
	}

	/**
	 * @return the popupFormid
	 */
	public WebElement getPopupFormid() {
		return popupFormid;
	}

	/**
	 * @return the popupTitle
	 */
	public WebElement getPopupTitle() {
		return popupTitle;
	}

	/**
	 * @return the billingType
	 */
	public WebElement getBillingType() {
		return billingType;
	}

	/**
	 * @return the moreappVisitCategory
	 */
	public WebElement getMoreappVisitCategory() {
		return moreappVisitCategory;
	}

	/**
	 * @return the moreappVisitType
	 */
	public WebElement getMoreappVisitType() {
		return moreappVisitType;
	}

	/**
	 * @return the encClouserDur
	 */
	public WebElement getEncClouserDur() {
		return encClouserDur;
	}

	/**
	 * @return the postBoxNumber
	 */
	public WebElement getPostBoxNumber() {
		return postBoxNumber;
	}

	/**
	 * @return the maxApptPerDay
	 */
	public WebElement getMaxApptPerDay() {
		return maxApptPerDay;
	}

	/**
	 * @return the sameCliBloDuration
	 */
	public WebElement getSameCliBloDuration() {
		return sameCliBloDuration;
	}

	/**
	 * @return the specNoOfVisit
	 */
	public WebElement getSpecNoOfVisit() {
		return specNoOfVisit;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the gridID
	 */
	public WebElement getGridID() {
		return gridID;
	}

	/**
	 * @return the gridPager
	 */
	public WebElement getGridPager() {
		return gridPager;
	}

	/**
	 * @return the gridNextPage
	 */
	public WebElement getGridNextPage() {
		return gridNextPage;
	}

	/**
	 * @return the cliNoOfVisit
	 */
	public WebElement getCliNoOfVisit() {
		return cliNoOfVisit;
	}

	/**
	 * @return the cliDaySpan
	 */
	public WebElement getCliDaySpan() {
		return cliDaySpan;
	}

	/**
	 * @return the specDaySpan
	 */
	public WebElement getSpecDaySpan() {
		return specDaySpan;
	}

	/**
	 * @return the sameSpecBloDuration
	 */
	public WebElement getSameSpecBloDuration() {
		return sameSpecBloDuration;
	}

	/**
	 * @param sameSpecBloDuration
	 *            the sameSpecBloDuration to set
	 */
	public void setSameSpecBloDuration(WebElement sameSpecBloDuration) {
		this.sameSpecBloDuration = sameSpecBloDuration;
	}

}
