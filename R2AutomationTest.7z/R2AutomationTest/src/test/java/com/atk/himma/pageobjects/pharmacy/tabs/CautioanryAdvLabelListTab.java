package com.atk.himma.pageobjects.pharmacy.tabs;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class CautioanryAdvLabelListTab extends DriverWaitClass{
	
	public final static String FORM_ID = "PCY_INST_LIST_PAGE";
	public final static String SEARCHTXT_ID = "TEXT_SEARCH_PCY_INST";
	public final static String SEARCHBUTTON_CSS = "#TEXT_SEARCH_PCY_INST + input";
	public final static String RESETBUTTON_CSS = "#SEARCH_BRANDED_DRUG_BUTTON ~ input[value='Reset']";
	public final static String ADDNEWLEBELBUTTON_CSS = ".buttoncontainer_vlrg_rgt input[value='Add New Label']";
	public final static String EXEXCELBUTTON_ID = "SEARCH_PCY_INST_LIST_export_btn";

	public final static String GRID_ID = "SEARCH_PCY_INST_LIST";
	public final static String GRID_INSTRUTYPETEXT_ARIA_DESCRIBEDBY = "SEARCH_PCY_INST_LIST_instructionTypeText";
	public final static String GRID_INSTRUDESC_ARIA_DESCRIBEDBY = "SEARCH_PCY_INST_LIST_instructionDesc";
	public final static String GRID_INSTRUDESCAR_ARIA_DESCRIBEDBY = "SEARCH_PCY_INST_LIST_instructionDescAr";
	public final static String GRID_PAGERID = "sp_1_SEARCH_PCY_INST_LIST_pager";
	public final static String GRID_NEXTPAGE_XPATH = "//td[@id='next_SEARCH_PCY_INST_LIST_pager']";

	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = SEARCHTXT_ID)
	private WebElement searchText;
	
	@FindBy(css = SEARCHBUTTON_CSS)
	private WebElement searchButton;
	
	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;
	
	@FindBy(css = ADDNEWLEBELBUTTON_CSS)
	private WebElement addNewLebelButton;
	
	@FindBy(id = EXEXCELBUTTON_ID)
	private WebElement excelButton;
	
	public WebElement getForm() {
		return form;
	}

	public WebElement getSearchText() {
		return searchText;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getResetButton() {
		return resetButton;
	}

	public WebElement getAddNewLebelButton() {
		return addNewLebelButton;
	}

	public WebElement getExcelButton() {
		return excelButton;
	}
	
}
