package com.atk.himma.pageobjects.mbuadmin.sections.pricelistdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.atk.himma.util.DriverWaitClass;

public class ServicePriceList extends DriverWaitClass{

	public final static String SECTIONNAME_LINKTEXT = "Service Price List";
	
	public final static String DEPARTMENT_ID = "SER_PRI_DEPARTMENT";
	public final static String SPECIALITY_ID = "SER_PRI_SPECIALITY";
	public final static String SUBSPECIALITY_ID = "SER_PRI_SUB_SPECIALITY";
	public final static String SERVICETYPE_ID = "SER_PRI_SERVICE_TYPE	";
	public final static String SERVICENAME_ID = "SER_PRI_SERVICE_NAME";
	public final static String SERVICECODE_ID = "SER_PRI_SERVICE_CODE";
	public final static String SHOWSERVICES_ID = "SHOW_SERVICES";
	public final static String ADDSERVICES_XPATH = "//input[@value='Add Services...']";
	public final static String APPLYFILTER_XPATH = "//input[@value='Apply Filter']";
	public final static String RESET_ID = "RESET_FORM";
	
	public final static String SECTIONCOLLAPSEEXPAND_XPATH = "//a[contains(text(), 'Service Price List')]/..";
	
//	POPUP
	public final static String PUSERFORM_ID = "ADD_SERVICES_FORM";
	public final static String PUSERTITLE_ID = "ui-dialog-title-ADD_SERVICES_POPUP_DIV";
	public final static String PUMBU_ID = "SERVICE_MBU_POPUP_NAME";
	public final static String PUDEPARTMENT_ID = "ADD_SERVICE_DEPARTMENT";
	public final static String PUSPECIALTY_ID = "ADD_SERVICE_SPECIALITY";
	public final static String PUSUBSPECIALITY_ID = "ADD_SERVICE_SUB_SPECIALITY";
	public final static String PUSERVICETYPE_ID = "ADD_SERVICE_TYPE";
	public final static String PUSERVICECODE_ID = "ADD_SERVICE_CODE";
	public final static String PUSERVICENAME_ID = "ADD_SERVICE_NAME";
	
	public final static String SEARCHBUTTON_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='Search']";
	public final static String RESETBUTTON_XPATH = "//span[@class='buttoncontainer_mid']//input[@value='Reset']";
	
	public final static String CANCELBUTTON_XPATH = "//span[@class='buttoncontainer_vlrg_rgt']//input[@value='Cancel']";
	public final static String SUBMITBUTTON_ID = "ADD_SER_BUTTON";
//	
	@FindBy(linkText = SECTIONNAME_LINKTEXT)
	private WebElement sectionName;
	
	@FindBy(id = DEPARTMENT_ID)
	private WebElement department;
	
	@FindBy(id = SPECIALITY_ID)
	private WebElement speciality;
	
	@FindBy(id = SUBSPECIALITY_ID)
	private WebElement subSpeciality;
	
	@FindBy(id = SERVICETYPE_ID)
	private WebElement serviceType;
	
	@FindBy(id = SERVICENAME_ID)
	private WebElement serviceName;
	
	@FindBy(id = SERVICECODE_ID)
	private WebElement serviceCode;
	
	@FindBy(id = SHOWSERVICES_ID)
	private WebElement showServices;
	
	@FindBy(xpath = ADDSERVICES_XPATH)
	private WebElement addServices;
	
	@FindBy(xpath = APPLYFILTER_XPATH)
	private WebElement applyFilter;
	
	@FindBy(id = RESET_ID)
	private WebElement reset;
	
	@FindBy(xpath = SECTIONCOLLAPSEEXPAND_XPATH)
	private WebElement sectionCollapseExpand;
	
	@FindBy(id = PUSERFORM_ID)
	private WebElement puSerForm;
	
	@FindBy(id = PUSERTITLE_ID)
	private WebElement puSerTitle;
	
	@FindBy(id = PUMBU_ID)
	private WebElement puMBU;
	
	@FindBy(id = PUDEPARTMENT_ID)
	private WebElement  puDepartment;
	
	@FindBy(id = PUSPECIALTY_ID)
	private WebElement  puSpecialty;
	
	@FindBy(id = PUSUBSPECIALITY_ID)
	private WebElement  puSubSpeciality;
	
	@FindBy(id = PUSERVICETYPE_ID)
	private WebElement  puServiceType;
	
	@FindBy(id = PUSERVICECODE_ID)
	private WebElement  puServiceCode;
	
	@FindBy(id = PUSERVICENAME_ID)
	private WebElement  puServiceName;
	
	@FindBy(xpath = SEARCHBUTTON_XPATH)
	private WebElement  searchButton;
	
	@FindBy(xpath = RESETBUTTON_XPATH)
	private WebElement  resetButton;
	
	@FindBy(xpath = CANCELBUTTON_XPATH)
	private WebElement  cancelButton;
	
	@FindBy(id = SUBMITBUTTON_ID)
	private WebElement  submitButton;

	
	public boolean checkServicePriceListOpen() throws InterruptedException {
		waitForElementLinkText(SECTIONNAME_LINKTEXT);
		if ("CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
				"class").trim()))
			return true;
		else
			return false;
	}

//	public void fillDatas(String[] mbuDatas)
//			throws InterruptedException {
//		waitForElementLinkText(SECTIONNAME_LINKTEXT);
//		if (!"CollapseExpand".equals(getSectionCollapseExpand().getAttribute(
//				"class").trim()))
//			getSectionName().click();
//		waitForElementId(DEPARTMENT_ID);
//		sleepVeryShort();
//	}

	
	/**
	 * @return the departmentId
	 */
	public static String getDepartmentId() {
		return DEPARTMENT_ID;
	}

	/**
	 * @return the addservicesXpath
	 */
	public static String getAddservicesXpath() {
		return ADDSERVICES_XPATH;
	}

	/**
	 * @return the applyfilterXpath
	 */
	public static String getApplyfilterXpath() {
		return APPLYFILTER_XPATH;
	}

	/**
	 * @return the puserformId
	 */
	public static String getPuserformId() {
		return PUSERFORM_ID;
	}

	/**
	 * @return the pusertitleId
	 */
	public static String getPusertitleId() {
		return PUSERTITLE_ID;
	}

	/**
	 * @return the pumbuId
	 */
	public static String getPumbuId() {
		return PUMBU_ID;
	}

	/**
	 * @return the pudepartmentId
	 */
	public static String getPudepartmentId() {
		return PUDEPARTMENT_ID;
	}

	/**
	 * @return the puspecialtyId
	 */
	public static String getPuspecialtyId() {
		return PUSPECIALTY_ID;
	}

	/**
	 * @return the puservicetypeId
	 */
	public static String getPuservicetypeId() {
		return PUSERVICETYPE_ID;
	}

	/**
	 * @return the puservicecodeId
	 */
	public static String getPuservicecodeId() {
		return PUSERVICECODE_ID;
	}

	/**
	 * @return the puservicenameId
	 */
	public static String getPuservicenameId() {
		return PUSERVICENAME_ID;
	}

	/**
	 * @return the cancelbuttonXpath
	 */
	public static String getCancelbuttonXpath() {
		return CANCELBUTTON_XPATH;
	}

	/**
	 * @return the sectionName
	 */
	public WebElement getSectionName() {
		return sectionName;
	}

	/**
	 * @return the department
	 */
	public WebElement getDepartment() {
		return department;
	}

	/**
	 * @return the speciality
	 */
	public WebElement getSpeciality() {
		return speciality;
	}

	/**
	 * @return the subSpeciality
	 */
	public WebElement getSubSpeciality() {
		return subSpeciality;
	}

	/**
	 * @return the serviceType
	 */
	public WebElement getServiceType() {
		return serviceType;
	}

	/**
	 * @return the serviceName
	 */
	public WebElement getServiceName() {
		return serviceName;
	}

	/**
	 * @return the serviceCode
	 */
	public WebElement getServiceCode() {
		return serviceCode;
	}

	/**
	 * @return the showServices
	 */
	public WebElement getShowServices() {
		return showServices;
	}

	/**
	 * @return the addServices
	 */
	public WebElement getAddServices() {
		return addServices;
	}

	/**
	 * @return the applyFilter
	 */
	public WebElement getApplyFilter() {
		return applyFilter;
	}

	/**
	 * @return the reset
	 */
	public WebElement getReset() {
		return reset;
	}

	/**
	 * @return the sectionCollapseExpand
	 */
	public WebElement getSectionCollapseExpand() {
		return sectionCollapseExpand;
	}

	/**
	 * @return the puSerForm
	 */
	public WebElement getPuSerForm() {
		return puSerForm;
	}

	/**
	 * @return the puSerTitle
	 */
	public WebElement getPuSerTitle() {
		return puSerTitle;
	}

	/**
	 * @return the puMBU
	 */
	public WebElement getPuMBU() {
		return puMBU;
	}

	/**
	 * @return the puDepartment
	 */
	public WebElement getPuDepartment() {
		return puDepartment;
	}

	/**
	 * @return the puSpecialty
	 */
	public WebElement getPuSpecialty() {
		return puSpecialty;
	}

	/**
	 * @return the puSubSpeciality
	 */
	public WebElement getPuSubSpeciality() {
		return puSubSpeciality;
	}

	/**
	 * @return the puServiceType
	 */
	public WebElement getPuServiceType() {
		return puServiceType;
	}

	/**
	 * @return the puServiceCode
	 */
	public WebElement getPuServiceCode() {
		return puServiceCode;
	}

	/**
	 * @return the puServiceName
	 */
	public WebElement getPuServiceName() {
		return puServiceName;
	}

	/**
	 * @return the searchButton
	 */
	public WebElement getSearchButton() {
		return searchButton;
	}

	/**
	 * @return the resetButton
	 */
	public WebElement getResetButton() {
		return resetButton;
	}

	/**
	 * @return the cancelButton
	 */
	public WebElement getCancelButton() {
		return cancelButton;
	}

	/**
	 * @return the submitButton
	 */
	public WebElement getSubmitButton() {
		return submitButton;
	}
	
}
