package com.atk.himma.test.mbuadmin;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.mbuadmin.RtoLAssignmentPage;
import com.atk.himma.pageobjects.mbuadmin.sections.restolocdetails.RtoLFirstSection;
import com.atk.himma.pageobjects.mbuadmin.tabs.RtoLAssignmentListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class RtoLAssignmentTest extends SeleniumDriverSetup {

	List<String[]> rtoLAssignDatas;
	RtoLAssignmentPage rtoLAssignmentPage;

	@Test(description = "Resource To Location Assignment")
	public void clickRtoLAssignmentMenu() throws InterruptedException {
		rtoLAssignmentPage = PageFactory.initElements(webDriver,
				RtoLAssignmentPage.class);
		rtoLAssignmentPage = rtoLAssignmentPage.clickOnRtoLAssignMenu(
				webDriver, webDriverWait);
		rtoLAssignmentPage.setInstanceOfAllSection(webDriver, webDriverWait);
		doDirtyFormCheck();
		Assert.assertNotNull(rtoLAssignmentPage);
		rtoLAssignmentPage
				.waitForElementXpathExpression(RtoLAssignmentListTab.SEARCHBUTTON_XPATH);
		rtoLAssignmentPage.sleepShort();
		Assert.assertEquals(rtoLAssignmentPage.getRtoLAssignmentListTab()
				.getResToLocListTab().getAttribute("title").trim(),
				"Assignment List", "Fail to Resource To Location Assignment");
	}

	// [Resource Location Assignment] Open Form
	@Test(description = "Open Resource Location Assignment Menu Link", groups = { "checkPrivilegesGrp" }, dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.login")
	public void checkRtoLMenuLink() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		rtoLAssignmentPage = PageFactory.initElements(webDriver,
				RtoLAssignmentPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> parentMenuList = new LinkedList<String>();
		parentMenuList.add("MBU Administration");
		menuSelector.mouseOverOnTargetMenu(parentMenuList,
				"Resource to Location Assignment");
		rtoLAssignmentPage.setWebDriver(webDriver);
		rtoLAssignmentPage.setWebDriverWait(webDriverWait);
		rtoLAssignmentPage
				.waitForElementXpathExpression(RtoLAssignmentPage.MENULINK_XPATH);
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Resource Location Assignment")
				.get("[Resource to Location Assignment] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RtoLAssignmentPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Resource to Location Assignment] Open Form privilege");
		if (actualPrivilage && expectedPrivilage) {
			rtoLAssignmentPage = rtoLAssignmentPage.clickOnRtoLAssignMenu(
					webDriver, webDriverWait);
			rtoLAssignmentPage
					.setInstanceOfAllSection(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(rtoLAssignmentPage);
			rtoLAssignmentPage
					.waitForElementXpathExpression(RtoLAssignmentListTab.SEARCHBUTTON_XPATH);
			rtoLAssignmentPage.sleepShort();
			Assert.assertEquals(rtoLAssignmentPage.getRtoLAssignmentListTab()
					.getResToLocListTab().getAttribute("title").trim(),
					"Assignment List",
					"Fail to Resource To Location Assignment");
		}
	}

	@Test(description = "search Resource Wise", dependsOnMethods = "clickRtoLAssignmentMenu")
	public void test1SearchResWise() throws InterruptedException, IOException {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		rtoLAssignDatas = excelReader.read(properties.getProperty("RtoLAssignment"));
		for (String st[] : rtoLAssignDatas)
			Assert.assertEquals(rtoLAssignmentPage.searchResourceWise(st)
					.trim(), st[5].trim(), "Fail to search Resource Wise");
	}

	@Test(description = "Define Resource Fees", dependsOnMethods = "test1SearchResWise")
	public void test2ClickOnAssignLocLink() throws InterruptedException, IOException {
		for (String st[] : rtoLAssignDatas)
			Assert.assertEquals(rtoLAssignmentPage.assignLocForResWise(st),
					true, "Fail to Define Resource Fees");
	}

	@Test(description = "fill Resource To Loc Datas", dependsOnMethods = "test2ClickOnAssignLocLink")
	public void test3FillRtoLFirstSecDatas() throws InterruptedException {
		for (String st[] : rtoLAssignDatas)
			Assert.assertEquals(rtoLAssignmentPage.getRtoLFirstSection()
					.fillRtoLFirstSecDatas(st), false,
					"Fail to fill Resource To Loc Datas");
	}

	@Test(description = "Save R to L Assign Datas", dependsOnMethods = "test3FillRtoLFirstSecDatas")
	public void test4SaveDatas() throws InterruptedException, IOException {
		Assert.assertEquals(
				rtoLAssignmentPage.saveDetailsPage().contains("Update"), true,
				"Failed to Save R to L Assign Datas");
	}

	@Test(description = "Activate Record", dependsOnMethods = "test4SaveDatas")
	public void test5ActivateRecord() throws InterruptedException, IOException {
		Assert.assertEquals(
				rtoLAssignmentPage.activateRtoLAssign().contains("Active"),
				true, "Failed Activate Record");
	}

	/*@Test(description = "Edit Resourcewise", dependsOnMethods = "test4SaveDatas")
	public void test6EditResourceWise() throws InterruptedException, IOException {
		for (String st[] : rtoLAssignDatas)
			Assert.assertEquals(rtoLAssignmentPage.editResWise(st), true,
					"Fail to Fill Resource Fees Datas");
	}*/

	@Test(dependsOnMethods = { "checkRtoLMenuLink" }, groups = { "checkPrivilegesGrp" }, description = "Search Price List for Privilege")
	public void searchResource() throws Exception {
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		rtoLAssignDatas = excelReader.read(properties.getProperty("RtoLAssignment"));
		for (String st[] : rtoLAssignDatas.subList(0, 1))
			Assert.assertEquals(rtoLAssignmentPage.searchResourceWise(st),
					st[5].trim(), "Fail to Search Price List");
	}

	// [List Tab] View (Link in the search result grid)
	@Test(dependsOnMethods = { "searchResource" }, groups = { "checkPrivilegesGrp" }, description = "[List Tab] View (Link in the search result grid)")
	public void checkViewLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Resource Location Assignment")
				.get("[List Tab] View (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ rtoLAssignDatas.subList(0, 1).get(0)[5].trim()
						+ "']/..//a[text()='View']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] View (Link in the search result grid) privilege");
	}

	// [List Tab] Assign Resource (Link in the search result grid)
	@Test(dependsOnMethods = { "searchResource" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Delete(Link in the search result grid) privilege")
	public void checkAssignResPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Resource Location Assignment")
				.get("[List Tab] Assign Resource (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ rtoLAssignDatas.subList(0, 1).get(0)[5].trim()
						+ "']/..//a[text()='AssignResource']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Assign Resource (Link in the search result grid) privilege");

	}

	@Test(dependsOnMethods = { "searchResource" }, groups = { "checkPrivilegesGrp" }, description = "check to click on Assign Resource privilege")
	public void clickOnAssignResLink() {
		rtoLAssignmentPage.waitForElementId(RtoLAssignmentListTab.GRID_ID);
		rtoLAssignmentPage.clickOnGridAction(
				rtoLAssignDatas.subList(0, 1).get(0)[5].trim(),
				"AssignResource");
		rtoLAssignmentPage.waitForElementId(RtoLFirstSection.GRIDID_ID);
		Assert.assertEquals(rtoLAssignmentPage.getRtoLFirstSection()
				.getResourceName().getText().trim(),
				rtoLAssignDatas.subList(0, 1).get(0)[8].trim(),
				"Fail click on Assign Resource Link");
	}

	// [Details Tab] [Assigned Location] Add (Icon in the bottom of the grid)
	@Test(dependsOnMethods = { "clickOnAssignResLink" }, groups = { "checkPrivilegesGrp" }, description = "check [Details Tab] [Assigned Location] Add (Icon in the bottom of the grid) privilege")
	public void checkAddbuttonPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Resource Location Assignment")
				.get("[Details Tab] [Assigned Location] Add (Icon in the bottom of the grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(RtoLFirstSection.ADDBUTTONGRID_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Assign Resource (Link in the search result grid) privilege");
	}

	// [Details Tab] [Assigned Location] Delete (Link in the grid)
	@Test(dependsOnMethods = { "clickOnAssignResLink" }, groups = { "checkPrivilegesGrp" }, description = "check [Details Tab] [Assigned Location] Delete (Link in the grid) privilege")
	public void checkDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Resource Location Assignment")
				.get("[Details Tab] [Assigned Location] Delete (Link in the grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ rtoLAssignDatas.subList(0, 1).get(0)[5].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Assign Resource (Link in the search result grid) privilege");

	}

	@Test(dependsOnMethods = {"clickOnAssignResLink"}, groups = { "checkPrivilegesGrp" }, description = "Search Price List for Privilege", alwaysRun = true)
	public void searchLocation() throws Exception {
		rtoLAssignmentPage.getRtoLAssignmentListTab().getResToLocListTab()
				.click();
		rtoLAssignmentPage.waitForElementId(RtoLAssignmentListTab.GRID_ID);
		excelReader.setInputFile(properties.getProperty("MBUAdminExcel"));
		rtoLAssignDatas = excelReader.read(properties.getProperty("RtoLAssignment"));
		for (String st[] : rtoLAssignDatas.subList(0, 1))
			Assert.assertEquals(rtoLAssignmentPage.searchLocationWise(st),
					st[8].trim(), "Fail to Search Price List");
	}

	// [List Tab] Assign Location (Link in the search result grid)
	@Test(dependsOnMethods = { "searchLocation" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Assign Location (Link in the search result grid) privilege")
	public void checkAssignLocPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Resource Location Assignment")
				.get("[List Tab] Assign Location (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ rtoLAssignDatas.subList(0, 1).get(0)[8].trim()
						+ "']/..//a[text()='Assign Location']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Assign Location (Link in the search result grid) privilege");
	}

	@Test(dependsOnMethods = { "checkAssignLocPrivilege","searchResource" }, groups = { "checkPrivilegesGrp" }, description = "check to click on Assign Resource privilege")
	public void clickOnAssLocationLink() throws InterruptedException {
		rtoLAssignmentPage
				.waitForElementId(RtoLAssignmentListTab.RESSEARCHGRID_ID);
		rtoLAssignmentPage.clickOnGridAction(
				rtoLAssignDatas.subList(0, 1).get(0)[8].trim(),
				"Assign Location");
		rtoLAssignmentPage.waitForElementId(RtoLFirstSection.MBU_ID);
		rtoLAssignmentPage.sleepShort();
		Assert.assertEquals(rtoLAssignmentPage.getRtoLFirstSection().getMbu()
				.getText(), rtoLAssignDatas.subList(0, 1).get(0)[8].trim(),
				"Fail click on Assign Resource Link");
	}

	// [Details Tab] [Resoruce List] Add (Icon in the bottom of the grid)
	@Test(dependsOnMethods = { "clickOnAssLocationLink" }, groups = { "checkPrivilegesGrp" }, description = "check [List Tab] Assign Location (Link in the search result grid) privilege")
	public void checkAssignPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration")
				.get("Resource Location Assignment")
				.get("[List Tab] Assign Location (Link in the search result grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ rtoLAssignDatas.subList(0, 1).get(0)[8].trim()
						+ "']/..//a[text()='Assign Location']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Assign Location (Link in the search result grid) privilege");
	}

	// [Details Tab] [Resoruce List] Delete (Link in the grid)
	@Test(dependsOnMethods = { "clickOnAssLocationLink" }, groups = { "checkPrivilegesGrp" }, description = "check [Details Tab] [Resoruce List] Delete (Link in the grid) privilege")
	public void checkResDeleteLinkPrivilege() {
		boolean expectedPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("MBU Administration").get("Resource Location Assignment")
				.get("[Details Tab] [Resoruce List] Delete (Link in the grid)");
		System.out.println("privFilter----------> " + expectedPrivilage);
		boolean actualPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver,
				By.xpath(".//td[@title='"
						+ rtoLAssignDatas.subList(0, 1).get(0)[8].trim()
						+ "']/..//a[text()='Delete']"));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Details Tab] [Resoruce List] Delete (Link in the grid) privilege");

	}
	// [Details Tab] [Section: Audit Trail] View
}
