package com.atk.himma.pageobjects.pharmacy;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ReturnMedicinePage {
	
	public final static String FORM_ID = "RETURN_MEDICINE_FORM";
	public final static String RETURNBUTTON_ID = "RETURN_RETURN_BUTTON";
	public final static String CANCELBUTTON_ID = "RETURN_CANCEL_BUTTON";
	public final static String QUICKSEARCHTXT_ID = "QUICK_SEARCH_RETURN_MEDICINE";
	public final static String QUICKSEARCHBUTTON_ID = "RETURN_MEDICINE_SEARCH";
	public final static String RESETBUTTON_CSS = "#RETURN_MEDICINE_SEARCH ~ .input_cancel";
	public final static String ITEMSEACRHTXT_ID = "RETURN_ITEM_SEACRH";
	public final static String ITEMSEACRHBUTTON_ID = "SEARCH_ITEM_IN_RETURN_PHY";
	public final static String SEARCHPERIOD_ID = "PCY_RET_SEARCH_PERIOD";
	
	@FindBy(id = FORM_ID)
	private WebElement form;
	
	@FindBy(id = RETURNBUTTON_ID)
	private WebElement returnButton;
	
	@FindBy(id = CANCELBUTTON_ID)
	private WebElement cancelButton;
	
	@FindBy(id = QUICKSEARCHTXT_ID)
	private WebElement quickSearchTxt;
	
	@FindBy(id = QUICKSEARCHBUTTON_ID)
	private WebElement quickSearchButton;
	
	@FindBy(css = RESETBUTTON_CSS)
	private WebElement resetButton;
	
	@FindBy(id = ITEMSEACRHBUTTON_ID)
	private WebElement itemSeacrhButton;
	
	@FindBy(id = ITEMSEACRHTXT_ID)
	private WebElement itemSeacrhTxt;
	
	@FindBy(id = SEARCHPERIOD_ID)
	private WebElement searchPeriod;

	public WebElement getForm() {
		return form;
	}

	public WebElement getReturnButton() {
		return returnButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getQuickSearchTxt() {
		return quickSearchTxt;
	}

	public WebElement getQuickSearchButton() {
		return quickSearchButton;
	}

	public WebElement getResetButton() {
		return resetButton;
	}

	public WebElement getItemSeacrhButton() {
		return itemSeacrhButton;
	}

	public WebElement getItemSeacrhTxt() {
		return itemSeacrhTxt;
	}

	public WebElement getSearchPeriod() {
		return searchPeriod;
	}
	
}
