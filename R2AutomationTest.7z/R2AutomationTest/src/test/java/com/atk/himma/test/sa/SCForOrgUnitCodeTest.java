package com.atk.himma.test.sa;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.sa.admin.SequenceCodeGeneratorPage;
import com.atk.himma.pageobjects.sa.admin.tabs.SequenceCodeDetailsTab;
import com.atk.himma.pageobjects.sa.admin.tabs.SequenceCodeListTab;
import com.atk.himma.setup.SeleniumDriverSetup;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.PrivilegesDataExecutor;

@Test(groups={"functionalTestGrp"})
public class SCForOrgUnitCodeTest extends SeleniumDriverSetup {
	SequenceCodeGeneratorPage sequenceCodeGeneratorPage;
	List<String[]> saScgList;

	@Test(description = "Open Sequence Code Generator Page")
	public void openSequenceCodeGenerator() throws Exception {
		sequenceCodeGeneratorPage = PageFactory.initElements(webDriver,
				SequenceCodeGeneratorPage.class);
		sequenceCodeGeneratorPage = sequenceCodeGeneratorPage
				.clickOnSequenceCodeGeneratorMenu(webDriver, webDriverWait);
		sequenceCodeGeneratorPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		Assert.assertNotNull(sequenceCodeGeneratorPage);
		sequenceCodeGeneratorPage
				.waitForElementVisibilityOf(sequenceCodeGeneratorPage
						.getSequenceCodeListTab().getSequenceCodeForm());
		Assert.assertTrue(sequenceCodeGeneratorPage.getSequenceCodeListTab()
				.getMbuName().isDisplayed());
	}

	@Test(description = "Create Org Unit Sequence Code", dependsOnMethods = { "openSequenceCodeGenerator" })
	public void createOrgUnitSequenceCode() throws Exception {
		saScgList = excelReader.read(properties.getProperty("SCG").trim());
		if (saScgList != null && !saScgList.isEmpty()) {
			sequenceCodeGeneratorPage.getSequenceCodeListTab()
					.addNewSequnceCode();
			sequenceCodeGeneratorPage
					.waitForElementVisibilityOf(sequenceCodeGeneratorPage
							.getSequenceCodeDetailsTab()
							.getSeqCodeDetailsForm());
			for (String[] scdata : saScgList.subList(0, 1)) {
				sequenceCodeGeneratorPage.getSequenceCodeDetailsTab()
						.addSeqCode(scdata);
				Assert.assertTrue(sequenceCodeGeneratorPage
						.getSequenceCodeDetailsTab().getUpdateBtn().isEnabled()
						&& sequenceCodeGeneratorPage
								.getSequenceCodeDetailsTab().searchGridData(
										scdata[5]));
			}
		}
	}

	// [Sequence Code Generator] Open Form
	@Test(description = "Checking for Sequence Code Generator Page Menu Link", groups = "checkPrivilegesGrp", dependsOnMethods = "com.atk.himma.test.sa.PrivilegeGroupsTest.setFullPrivileges")
	public void checkSequenceCodeGeneratorMenuLink() throws Exception {
		excelReader.setInputFile(properties.getProperty("SAExcel").trim());
		sequenceCodeGeneratorPage = PageFactory.initElements(webDriver,
				SequenceCodeGeneratorPage.class);
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> scgParentMenuList = new LinkedList<String>();
		scgParentMenuList.add("System Administration");
		scgParentMenuList.add("Admin ");
		menuSelector.mouseOverOnTargetMenu(scgParentMenuList,
				"Sequence Code Generator");
		sequenceCodeGeneratorPage.setWebDriver(webDriver);
		sequenceCodeGeneratorPage.setWebDriverWait(webDriverWait);
		sequenceCodeGeneratorPage
				.waitForElementXpathExpression(SequenceCodeGeneratorPage.MENULINK_XPATH);

		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Sequence Code Generation")
				.get("[Sequence Code Generator] Open Form");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(SequenceCodeGeneratorPage.MENULINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [Sequence Code Generator] Open Form privilege");

		if (actualPrivilage && expectedPrivilage) {
			sequenceCodeGeneratorPage = sequenceCodeGeneratorPage
					.clickOnSequenceCodeGeneratorMenu(webDriver, webDriverWait);
			sequenceCodeGeneratorPage.initPages(webDriver, webDriverWait);
			doDirtyFormCheck();
			Assert.assertNotNull(sequenceCodeGeneratorPage);
			sequenceCodeGeneratorPage
					.waitForElementVisibilityOf(sequenceCodeGeneratorPage
							.getSequenceCodeListTab().getSequenceCodeForm());
			sequenceCodeGeneratorPage.sleepShort();
			Assert.assertEquals(sequenceCodeGeneratorPage.getPageTitle()
					.getText(), "Sequence Code Generator");
		}
	}

	// [List Tab] Applicable to all MBUs (Checkbox in the Search Criteria group)
	@Test(description = "Checking for  Applicable to all MBUs Checkbox in the Search Criteria group", groups = "checkPrivilegesGrp", dependsOnMethods = "checkSequenceCodeGeneratorMenuLink")
	public void checkListTabApplicableToAllMBUsChkBox() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Sequence Code Generation")
				.get("[List Tab] Applicable to all MBUs  (Checkbox in the Search Criteria group)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(SequenceCodeListTab.APPLICABLETOALLMBUS_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [List Tab] Applicable to all MBUs  (Checkbox in the Search Criteria group) privilege");

	}

	// [List Tab] Edit (Link in the Search Result grid)
	@Test(description = "Check Edit Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkSequenceCodeGeneratorMenuLink")
	public void checkEditLink() throws Exception {
		saScgList = excelReader.read(properties.getProperty("SCG").trim());
		for (String[] scdata : saScgList.subList(2, 3)) {
			sequenceCodeGeneratorPage.getSequenceCodeListTab().searchSeqCodes(
					scdata);
		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Sequence Code Generation")
				.get("[List Tab] Edit  (Link in the Search Result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(SequenceCodeListTab.EDITLINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Edit  (Link in the Search Result grid) privilege");
	}

	// [List Tab] Delete (Link in the Search Result grid)
	@Test(description = "Check Delete Link", groups = "checkPrivilegesGrp", dependsOnMethods = "checkSequenceCodeGeneratorMenuLink")
	public void checkDeleteLink() throws Exception {
		saScgList = excelReader.read(properties.getProperty("SCG").trim());
		for (String[] scdata : saScgList.subList(2, 3)) {
			sequenceCodeGeneratorPage.getSequenceCodeListTab().searchSeqCodes(
					scdata);

		}
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Sequence Code Generation")
				.get("[List Tab] Delete (Link in the Search Result grid)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.xpath(SequenceCodeListTab.DELETELINK_XPATH));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Delete (Link in the Search Result grid) privilege");
	}

	// [List Tab] Add New (Button)
	@Test(description = "Checking for  Add New Sequence Code Button ", groups = "checkPrivilegesGrp", dependsOnMethods = "checkSequenceCodeGeneratorMenuLink")
	public void checkAddNewBtn() throws Exception {
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin").get("Sequence Code Generation")
				.get("[List Tab] Add New (Button)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(SequenceCodeListTab.ADDNEWCODESEQBTN_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(actualPrivilage, expectedPrivilage,
				"Fail to check [List Tab] Add New (Button) privilege");

	}

	// [Details Tab] Applicable to all MBUs (Checkbox in the Header section)
	@Test(description = "Checking for  Applicable to all MBUs Checkbox in the Details Tab", groups = "checkPrivilegesGrp", dependsOnMethods = "checkAddNewBtn")
	public void checkDetailsTabApplicableToAllMBUsChkBox() throws Exception {
		sequenceCodeGeneratorPage.getSequenceCodeListTab().addNewSequnceCode();
		boolean actualPrivilage = PrivilegesDataExecutor.allModCollecPrivileges
				.get("System Admin")
				.get("Sequence Code Generation")
				.get("[Details Tab] Applicable to all MBUs  (Checkbox in the Header section)");
		System.out.println("privFilter----------> " + actualPrivilage);
		boolean expectedPrivilage = PrivilegesDataExecutor.testPrivilege(
				webDriver, By.id(SequenceCodeDetailsTab.APPLTOALLMBU_ID));
		System.out
				.println("ExpectedPrivilage --------->> " + expectedPrivilage);
		Assert.assertEquals(
				actualPrivilage,
				expectedPrivilage,
				"Fail to check [Details Tab] Applicable to all MBUs  (Checkbox in the Header section) privilege");

	}

}
