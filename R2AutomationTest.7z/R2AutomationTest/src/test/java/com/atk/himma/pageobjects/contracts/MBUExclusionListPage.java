package com.atk.himma.pageobjects.contracts;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclDetailsFirstSection;
import com.atk.himma.pageobjects.contracts.sections.exclusionlistdetails.ExclusionListDetailsSection;
import com.atk.himma.pageobjects.contracts.tabs.ExclusionListTab;
import com.atk.himma.util.DriverWaitClass;
import com.atk.himma.util.MenuSelector;
import com.atk.himma.util.interfaces.RecordStatus;
import com.atk.himma.util.interfaces.StatusMessages;

public class MBUExclusionListPage extends DriverWaitClass implements
		StatusMessages, RecordStatus {
	private ExclusionListTab exclusionListTab;
	private ExclDetailsFirstSection exclDetailsFirstSection;
	private ExclusionListDetailsSection exclusionListDetailsSection;

	public static final String MENULINK_XPATH = "//a[contains(text(),'Contracts')]/..//a[contains(text(),'MBU Exclusion List')]";
	public final static String PAGETITLE_ID = "PAGE_TITLE";
	public final static String EXCLISTDETAILSFORM_ID = "mbuexclusionlistform";
	public final static String ADDNEWBTN_ID = "ADD_NEW_UPPER_BTN";
	public final static String COPYBTN_ID = "COPY_UPPER_BTN";
	public final static String SAVEBTN_ID = "SAVE_UPPER_BTN";
	public final static String UPDATEBTN_ID = "UPDATE_UPPER_BTN";
	public final static String CANCELBTN_ID = "EX_CANCEL_UPPER_BTN";
	

	@FindBy(id = PAGETITLE_ID)
	private WebElement pageTitle;

	@FindBy(xpath = MSGENABLE_XPATH)
	private WebElement statusMessage;

	@FindBy(id = EXCLISTDETAILSFORM_ID)
	private WebElement excListDetailsForm;

	@FindBy(id = ADDNEWBTN_ID)
	private WebElement addNewBtn;

	@FindBy(id = COPYBTN_ID)
	private WebElement copyBtn;

	@FindBy(id = SAVEBTN_ID)
	private WebElement saveBtn;

	@FindBy(id = UPDATEBTN_ID)
	private WebElement updateBtn;

	@FindBy(id = CANCELBTN_ID)
	private WebElement cancelBtn;

	@FindBy(id = ACTIVATE_ID)
	private WebElement activateRecord;

	public void initPages(WebDriver webDriver, WebDriverWait webDriverWait) {
		exclusionListTab = PageFactory.initElements(webDriver,
				ExclusionListTab.class);
		exclusionListTab.setWebDriver(webDriver);
		exclusionListTab.setWebDriverWait(webDriverWait);

		exclDetailsFirstSection = PageFactory.initElements(webDriver,
				ExclDetailsFirstSection.class);
		exclDetailsFirstSection.setWebDriver(webDriver);
		exclDetailsFirstSection.setWebDriverWait(webDriverWait);

		exclusionListDetailsSection = PageFactory.initElements(webDriver,
				ExclusionListDetailsSection.class);
		exclusionListDetailsSection.setWebDriver(webDriver);
		exclusionListDetailsSection.setWebDriverWait(webDriverWait);

	}

	public MBUExclusionListPage clickOnMBUExclusionListMenu(
			WebDriver webDriver, WebDriverWait webDriverWait) throws Exception {
		MenuSelector menuSelector = new MenuSelector(webDriver, webDriverWait);
		List<String> menuList = new LinkedList<String>();
		menuList.add("Contracts");
		menuSelector.clickOnTargetMenu(menuList, "MBU Exclusion List");
		MBUExclusionListPage mbuExclusionListPage = PageFactory.initElements(
				webDriver, MBUExclusionListPage.class);
		mbuExclusionListPage.setWebDriver(webDriver);
		mbuExclusionListPage.setWebDriverWait(webDriverWait);
		waitForPageLoaded(webDriver);
		return mbuExclusionListPage;
	}

	public void saveExclusionListDetails() throws Exception {
		saveBtn.click();
		waitForElementId(UPDATEBTN_ID);
		sleepShort();
	}

	public String activateRecord() throws Exception {
		return activateRecord(ACTIVATE_ID, MAINSTATUSLABEL_ID);
	}

	public void clickCopy() throws Exception {
		copyBtn.click();
		waitForElementId(UPDATEBTN_ID);
		sleepVeryShort();

	}

	public void clickAddMoreNewExcList() throws Exception {
		addNewBtn.click();
		doDirtyPopUpCheck();
		waitForElementId(SAVEBTN_ID);
		sleepVeryShort();

	}

	public void clickCancel() throws Exception {
		cancelBtn.click();
		doDirtyPopUpCheck();
		waitForElementId(ExclusionListTab.EXCLUSIONLISTGRIDDIV_ID);
		sleepVeryShort();

	}

	public ExclusionListTab getExclusionListTab() {
		return exclusionListTab;
	}

	public WebElement getPageTitle() {
		return pageTitle;
	}

	public WebElement getStatusMessage() {
		return statusMessage;
	}

	public ExclDetailsFirstSection getExclDetailsFirstSection() {
		return exclDetailsFirstSection;
	}

	public ExclusionListDetailsSection getExclusionListDetailsSection() {
		return exclusionListDetailsSection;
	}

	public WebElement getExcListDetailsForm() {
		return excListDetailsForm;
	}

	public WebElement getAddNewBtn() {
		return addNewBtn;
	}

	public WebElement getCopyBtn() {
		return copyBtn;
	}

	public WebElement getSaveBtn() {
		return saveBtn;
	}

	public WebElement getUpdateBtn() {
		return updateBtn;
	}

	public WebElement getCancelBtn() {
		return cancelBtn;
	}

	public WebElement getActivateRecord() {
		return activateRecord;
	}

}
