package com.atk.himma.test.cpoe;

import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.atk.himma.pageobjects.appointsched.EncounterPage;
import com.atk.himma.pageobjects.cpoe.ConsultationPage;
import com.atk.himma.pageobjects.desktop.DesktopDataPage;
import com.atk.himma.setup.SeleniumDriverSetup;

public class ConsultationTest extends SeleniumDriverSetup {

	DesktopDataPage desktopDataPage;
	ConsultationPage consultationPage;
	List<String[]> outPatientList;

	@Test(description = "Open Dr. Workbench Page")
	public void openDrWorkBenchPage() throws Exception {
		desktopDataPage = PageFactory.initElements(webDriver,
				DesktopDataPage.class);
		desktopDataPage = desktopDataPage.clickOnDrWorkBenchMenu(webDriver,
				webDriverWait);
		desktopDataPage.initPages(webDriver, webDriverWait);
		doDirtyFormCheck();
		excelReader
				.setInputFile("src//test//resources//excels//OutpatientDesktop.xls");
		Assert.assertNotNull(desktopDataPage);
		desktopDataPage.waitForElementVisibilityOf(desktopDataPage.getMbu());
		Assert.assertTrue(desktopDataPage.getMbu().isDisplayed());

	}

	@Test(description = "Validate Mandatory for Search From Date Field", dependsOnMethods = { "openDrWorkBenchPage" })
	public void validateFromDateMandatoryField() throws Exception {
		Assert.assertTrue(desktopDataPage.isMandFromDate());
	}

	@Test(description = "Fill Search Criteria Fields", dependsOnMethods = { "openDrWorkBenchPage" })
	public void fillSearchCriteriaData() throws Exception {
		outPatientList = excelReader.read("OutPatientDesktop");
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.fillSearchCriteria(outPatientListData);
			}
		}
	}

	@Test(description = "Search OutPatient(s) By Patient Filter Criteria", dependsOnMethods = { "openDrWorkBenchPage" })
	public void searchOutPatientsByPatient() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByPatient(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"drDeskGridList", outPatientListData[15]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Service Filter Criteria", dependsOnMethods = { "openDrWorkBenchPage" })
	public void searchOutPatientsByService() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.searchOutPatientsByService(outPatientListData);
				Assert.assertTrue(desktopDataPage.checkGridData(
						"drDeskGridList", outPatientListData[22]));
			}
		}

	}

	@Test(description = "Search OutPatient(s) By Physician", dependsOnMethods = { "openDrWorkBenchPage" })
	public void searchOutPatientsByPhysician() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				desktopDataPage.quickSearchOutPatients();
				Assert.assertTrue(desktopDataPage.checkGridData(
						"drDeskGridList", outPatientListData[12]));
			}
		}

	}

	@Test(description = "Verify that, Consultation link in Dr.Desktop navigates to Consultation page.", dependsOnMethods = { "openDrWorkBenchPage" })
	public void navigateToConsultationPage() throws Exception {
		consultationPage = PageFactory.initElements(webDriver,
				ConsultationPage.class);
		consultationPage.initPages(webDriver, webDriverWait);
		consultationPage.setWebDriver(webDriver);
		consultationPage.setWebDriverWait(webDriverWait);
		for (String[] outPatientListData : outPatientList) {
			Assert.assertEquals(
					desktopDataPage.clickOnConsultationLink(outPatientListData),
					"Consultation");
		}
	}

	@Test(description = "Select Encounter Number in Consultation First Section", dependsOnMethods = { "navigateToConsultationPage" })
	public void selectEncounterNumber() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				consultationPage.getConsultationFirstSection()
						.selectEncounterNumber(EncounterPage.encounterNumber,
								outPatientListData);
				Assert.assertEquals(consultationPage
						.getConsultationFirstSection().getEncounterNumTextBox()
						.getAttribute("value"), outPatientListData[23]);
			}
		}

	}

	@Test(description = "Add Physician Diagnosis Details", dependsOnMethods = { "navigateToConsultationPage" })
	public void addDiagnosisDetails() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				consultationPage.getDiagnosisDetailsSection()
						.clickOnDiagnosisLookup();
				consultationPage.getDiagnosisDetailsSection()
						.selectPhysDiagnosis(outPatientListData);
			}
		}

	}

	@Test(description = "Add Order Summary Details", dependsOnMethods = { "navigateToConsultationPage" })
	public void addOrderSummaryDetails() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				consultationPage.getOrderSummarySection().addOrder(
						outPatientListData);
				Assert.assertTrue(consultationPage.getOrderSummarySection()
						.checkOrderGridData(outPatientListData));
			}
		}
	}

	@Test(description = "Add External Order Summary Details", dependsOnMethods = { "navigateToConsultationPage" })
	public void addExternalOrderSummaryDetails() throws Exception {
		if (outPatientList != null && !outPatientList.isEmpty()) {
			for (String[] outPatientListData : outPatientList) {
				consultationPage.getExternalOrderSummarySection().addExtOrder(
						outPatientListData);
				Assert.assertTrue(consultationPage
						.getExternalOrderSummarySection()
						.checkExtOrderGridData(outPatientListData));
			}
		}
	}

	@Test(description = "Calculate Price", dependsOnMethods = { "addOrderSummaryDetails" })
	public void calculatePrice() throws Exception {
		Assert.assertTrue(consultationPage.getCalculatePriceBtn().isEnabled());
		Assert.assertEquals(
				consultationPage.calcPrice(),
				"Billing validation is done. Please click on Save and then Create Invoice to continue.");
	}

	@Test(description = "Save Consultation Data", dependsOnMethods = { "calculatePrice" })
	public void saveConsultationDetails() throws Exception {
		Assert.assertEquals(consultationPage.saveConsultationDetails(),
				"Print External Orders", "Save Fail");

	}

}
