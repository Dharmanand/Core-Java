package com.atk.himma.pageobjects.pharmacy;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PharmacyDesktopPage {

	public final static String FORM_ID = "PHARMACY_DESKTOP";
	public final static String SEARCHBUTTON_ID = "QUICK_SEARCH_BUTTON";
	public final static String CANCELBUTTON_ID = "QUICK_RESET";
	public final static String ADVSEARCHBUTTON_ID = "FLOTING_CRITERIA_PHARM_DESK_BT";
	public final static String RUNMANBUTTON_ID = "RUN_MAN_BTN";
	public final static String RETAILBUTTON_ID = "RETAIL_BTN";
	public final static String PROCESSBUTTON_ID = "PROCESS";
	public final static String RETURNBUTTON_ID = "RETURN_BUTTON_PHY_DESKTOP";
	public final static String QUICKSEARCHFIELD_ID = "QUICK_SEARCH_FIELD";
	public final static String VISIT_ID = "DESK_VISIT_CAT";
	
//	STATUS LIST
	public final static String ALLLINK_ID = "PCY_ORDER_ALL_ID";
	public final static String DISPENSEDLINK_ID = "PCY_DP_ID";
	public final static String ORDEREDLINK_ID = "PCY_OD_ID";
	public final static String PARTIALLYDISPANCEDLINK_ID = "PCY_PD_ID";
	public final static String PARTIALLYRETURNEDLINK_ID = "PCY_PR_ID";
	public final static String RETURNEDLINK_ID = "PCY_RT_ID";
	
//	ADVANCED SEARCH WINDOW	
	public final static String MBUTXT_ID = "SEARCH_MBU";
	public final static String SEARCHPERIOD_ID = "PCY_SEARCH_PERIOD";
	public final static String NOFILTER_ID = "BY_NO_FILTER";
	public final static String FILTERBY_PATIENT_ID = "BY_PATIENT";
	public final static String FILTERBY_REFFERED_PHYSICIAN_ID = "BY_REFFERED_PHYSICIAN";
	public final static String FILTERBY_ENCOUNTER_ID = "BY_ENCOUNTER";
	public final static String FILTERBY_LOCATION_ID = "BY_LOCATION";
	public final static String FILTERBY_ITEM_ID = "BY_ITEM";
	public final static String ADVSEARCHWINDOWBUTTON_ID = "ADVANCED_SEARCH";
	public final static String ADVRESETWINDOWBUTTON_ID = "ADVANCED_RESET";
	
	@FindBy(id = FORM_ID)
	private WebElement form;

	@FindBy(css = SEARCHBUTTON_ID)
	private WebElement searchButton;

	@FindBy(css = CANCELBUTTON_ID)
	private WebElement cancelButton;
	
	@FindBy(css = ADVSEARCHBUTTON_ID)
	private WebElement advSearchButton;
	
	@FindBy(css = RUNMANBUTTON_ID)
	private WebElement runManButton;
	
	@FindBy(css = RETAILBUTTON_ID)
	private WebElement retailButton;
	
	@FindBy(css = PROCESSBUTTON_ID)
	private WebElement processButton;
	
	@FindBy(css = RETURNBUTTON_ID)
	private WebElement returnButton;
	
	@FindBy(css = QUICKSEARCHFIELD_ID)
	private WebElement quickSearchField;
	
	@FindBy(css = VISIT_ID)
	private WebElement visit;
	
	@FindBy(css = ALLLINK_ID)
	private WebElement allLinnk;
	
	@FindBy(css = DISPENSEDLINK_ID)
	private WebElement dispensedLink;
	
	@FindBy(css = ORDEREDLINK_ID)
	private WebElement orderedLink;
	
	@FindBy(css = PARTIALLYDISPANCEDLINK_ID)
	private WebElement partiallyDispancedLink;
	
	@FindBy(css = RETURNEDLINK_ID)
	private WebElement returnedLink;
	
	@FindBy(id = MBUTXT_ID)
	private WebElement mbuText;
	
	@FindBy(id = SEARCHPERIOD_ID)
	private WebElement searchPeriod;
	
	@FindBy(id = NOFILTER_ID)
	private WebElement noFilter;
	
	@FindBy(id = FILTERBY_PATIENT_ID)
	private WebElement filterByPatient;
	
	@FindBy(id = FILTERBY_REFFERED_PHYSICIAN_ID)
	private WebElement filterByRefPhysician;
	
	@FindBy(id = FILTERBY_ENCOUNTER_ID)
	private WebElement filterByEncounter;
	
	@FindBy(id = FILTERBY_LOCATION_ID)
	private WebElement filterByLocation;
	
	@FindBy(id = FILTERBY_ITEM_ID)
	private WebElement filterByItem;
	
	@FindBy(id = ADVSEARCHWINDOWBUTTON_ID)
	private WebElement advSearchWindowButton;
	
	@FindBy(id = ADVRESETWINDOWBUTTON_ID)
	private WebElement advResetWindowButton;
	
	public WebElement getForm() {
		return form;
	}

	public WebElement getSearchButton() {
		return searchButton;
	}

	public WebElement getCancelButton() {
		return cancelButton;
	}

	public WebElement getAdvSearchButton() {
		return advSearchButton;
	}

	public WebElement getRunManButton() {
		return runManButton;
	}

	public WebElement getRetailButton() {
		return retailButton;
	}

	public WebElement getProcessButton() {
		return processButton;
	}

	public WebElement getReturnButton() {
		return returnButton;
	}

	public WebElement getQuickSearchField() {
		return quickSearchField;
	}

	public WebElement getVisit() {
		return visit;
	}

	public WebElement getAllLinnk() {
		return allLinnk;
	}

	public WebElement getDispensedLink() {
		return dispensedLink;
	}

	public WebElement getOrderedLink() {
		return orderedLink;
	}

	public WebElement getPartiallyDispancedLink() {
		return partiallyDispancedLink;
	}

	public WebElement getReturnedLink() {
		return returnedLink;
	}

	public WebElement getMbuText() {
		return mbuText;
	}

	public WebElement getSearchPeriod() {
		return searchPeriod;
	}

	public WebElement getNoFilter() {
		return noFilter;
	}

	public WebElement getFilterByPatient() {
		return filterByPatient;
	}

	public WebElement getFilterByRefPhysician() {
		return filterByRefPhysician;
	}

	public WebElement getFilterByEncounter() {
		return filterByEncounter;
	}

	public WebElement getFilterByLocation() {
		return filterByLocation;
	}

	public WebElement getFilterByItem() {
		return filterByItem;
	}

	public WebElement getAdvSearchWindowButton() {
		return advSearchWindowButton;
	}

	public WebElement getAdvResetWindowButton() {
		return advResetWindowButton;
	}

}
